<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE');

$db_file = 'users.json';

if (!file_exists($db_file)) {
    file_put_contents($db_file, json_encode(['users' => []]));
}

$data = json_decode(file_get_contents($db_file), true);

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    echo json_encode($data['users']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $action = $_GET['action'] ?? '';
    
    switch ($action) {
        case 'register':
            if (empty($input['username']) || empty($input['password'])) {
                echo json_encode(['success' => false, 'error' => 'Username and password required']);
                exit;
            }
            
            foreach ($data['users'] as $user) {
                if ($user['username'] === $input['username']) {
                    echo json_encode(['success' => false, 'error' => 'User already exists']);
                    exit;
                }
            }
            
            $new_user = [
                'username' => $input['username'],
                'password' => $input['password'],
                'created_at' => date('Y-m-d H:i:s'),
                'expiry' => $input['expiry'] ?? '7d',
                'status' => 'active'
            ];
            
            $data['users'][] = $new_user;
            file_put_contents($db_file, json_encode($data, JSON_PRETTY_PRINT));
            
            echo json_encode(['success' => true, 'message' => 'User registered successfully']);
            break;
            
        case 'login':
            if (empty($input['username']) || empty($input['password'])) {
                echo json_encode(['success' => false, 'error' => 'Username and password required']);
                exit;
            }
            
            foreach ($data['users'] as $user) {
                if ($user['username'] === $input['username'] && $user['password'] === $input['password']) {
                    echo json_encode([
                        'success' => true, 
                        'message' => 'Login successful',
                        'user' => $user
                    ]);
                    exit;
                }
            }
            
            echo json_encode(['success' => false, 'error' => 'Invalid credentials']);
            break;
            
        case 'check_key':
            $key = $_GET['key'] ?? '';
            if (empty($key)) {
                echo json_encode(['valid' => false, 'error' => 'Key required']);
                exit;
            }
            
            foreach ($data['users'] as $user) {
                if ($user['username'] === $key) {
                    echo json_encode([
                        'valid' => true,
                        'expiry' => $user['expiry'],
                        'message' => $user['message'] ?? 'Access granted'
                    ]);
                    exit;
                }
            }
            
            echo json_encode(['valid' => false, 'error' => 'Invalid key']);
            break;
            
        case 'delete':
            $username = $_GET['username'] ?? '';
            if (empty($username)) {
                echo json_encode(['success' => false, 'error' => 'Username required']);
                exit;
            }
            
            $found = false;
            $new_users = [];
            foreach ($data['users'] as $user) {
                if ($user['username'] === $username) {
                    $found = true;
                    continue; 
                }
                $new_users[] = $user;
            }
            
            if (!$found) {
                echo json_encode(['success' => false, 'error' => 'User not found']);
                exit;
            }
            
            $data['users'] = $new_users;
            file_put_contents($db_file, json_encode($data, JSON_PRETTY_PRINT));
            
            echo json_encode(['success' => true, 'message' => 'User deleted successfully']);
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $username = $_GET['username'] ?? '';
    if (empty($username)) {
        echo json_encode(['success' => false, 'error' => 'Username required']);
        exit;
    }
    
    $found = false;
    $new_users = [];
    foreach ($data['users'] as $user) {
        if ($user['username'] === $username) {
            $found = true;
            continue; 
        }
        $new_users[] = $user;
    }
    
    if (!$found) {
        echo json_encode(['success' => false, 'error' => 'User not found']);
        exit;
    }
    
    $data['users'] = $new_users;
    file_put_contents($db_file, json_encode($data, JSON_PRETTY_PRINT));
    
    echo json_encode(['success' => true, 'message' => 'User deleted successfully']);
}
?>