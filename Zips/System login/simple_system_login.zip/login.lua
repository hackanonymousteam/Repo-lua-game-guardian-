gg.setVisible(false)

local API_URL = "https://YOUR_SERVER_HERE/login_api.php"

local json = nil
if not pcall(function()
    json = load(gg.makeRequest("https://raw.githubusercontent.com/rxi/json.lua/master/json.lua").content)()
end) then
    json = require("json") or gg.alert("JSON library not available")
    if not json then return end
end

local function normalLogin()
    local info = gg.prompt(
        {"Username", "Password"},
        {"", ""},
        {"text", "text"}
    )
    
    if not info then return false end
    
    local userData = {
        username = info[1],
        password = info[2]
    }
    
    local response = gg.makeRequest(API_URL .. "?action=login", {
        ["Content-Type"] = "application/json"
    }, json.encode(userData))
    
    if type(response) ~= "table" or not response.content then
        gg.alert("❌ Connection error")
        return false
    end    
    local data = json.decode(response.content)   
    if data.success then
        gg.alert("✅ " .. data.message)
        return true, data.user
    else
        gg.alert("❌ " .. data.error)
        return false
    end
end

local function mainMenu()
    while true do
        local choice = gg.choice({
            "👤 Login",
            "❌ Exit"
        }, nil, " Login System")
        
        if not choice then break end
        
        if choice == 1 then           
            local success, userData = normalLogin()
            if success then
                gg.alert("Starting script...")
                --start your script here
                -- runMainScript()
                return true
            end      
        elseif choice == 2 then
            break
        end
    end
    return false
end


mainMenu()