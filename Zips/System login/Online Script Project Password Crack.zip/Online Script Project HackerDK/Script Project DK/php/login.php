<?php
include 'DB.php';
include 'Global.php';
//--Copyright -- @hackerdk_20
//--Support Please 
$data = json_decode(file_get_contents('php://input'),true);
$uname = $data["user"];
$pass = $data["pass"];
$uidup = $data["uid"];
//--Copyright -- @hackerdk_20
//--Support Please 
if($maintenance){
    $ackdata = "Servidor em Manutençao";
    die($ackdata);
}
//--Copyright -- @hackerdk_20
//--Support Please 
if($uname == null || preg_match("([a-zA-Z0-9]+)", $uname) === 0){
    $ackdata = "gg.alert('Usuario Invalido')";
    die($ackdata);
}

if($pass == null || !preg_match("([a-zA-Z0-9]+)", $pass) === 0){
    $ackdata = "gg.alert('Senha Invalida')";
    die($ackdata);
}
//--Copyright -- @hackerdk_20
//--Support Please 
$query = $con->query("SELECT * FROM `users` WHERE `username` = '".$uname."' AND `password` = '".$pass."'");
if($query->num_rows < 1){
    $ackdata = "gg.alert('Username or Password Incorrect')";
    die($ackdata);
}
//--Copyright -- @hackerdk_20
//--Support Please 
$res = $query->fetch_assoc();
if($res["registered"] == NULL){
    $query = $conn->query("UPDATE `users` SET `registered` = CURRENT_TIMESTAMP WHERE `username` = '".$uname."' AND `password` = '".$pass."'");
}
//--Copyright -- @hackerdk_20
//--Support Please 
if($res["UID"] == NULL){
    $query = $con->query("UPDATE `users` SET `UID` = '$uidup' WHERE `username` = '".$uname."' AND `password` = '".$pass."'");
}
//--Copyright -- @hackerdk_20
//--Support Please 
else if($res["UID"] != $uidup) {
    $ackdata = "gg.alert('Seu UID foi alterado!')";
    die($ackdata);
}
//--Copyright -- @hackerdk_20
//--Support Please 
if($res["expired"] < $res["registered"]){
    $ackdata = "gg.alert('Seu login expirou!')";
    die($ackdata);
}
$ackdata = file_get_contents("script"); // script location here
echo $ackdata ;
?>
//--Copyright -- @hackerdk_20
//--Support Please 