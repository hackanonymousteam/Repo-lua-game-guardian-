--Copyright -- @hackerdk_20
--Support Please 
function login()
Variable = {}
Variable["LoginURL"]= "https://hackerdk.com" ----- Paste your link Login.php here
Prompt = gg.prompt({"💡Username","💡Password","exit"},nil,{"text","text","checkbox"})
	if not Prompt then
	return
	end
	if Prompt[3] then
	return
	end
 file,err = io.open("/system/build.prop", "r")  -- uid
     if err then 
          print(err) 
          os.exit() 
     else 
          file = file:read("*a") 
     end 
     local uid = string.match(file, "ro.build.date.utc=(%w+)")

Variable["TempLogin"]  = '{"user":"'..Prompt[1]..'","pass":"'..Prompt[2]..'","uid":"'..uid..'"}'
--Copyright -- @hackerdk_20
--Support Please 
ResponseContent = gg.makeRequest(Variable["LoginURL"],nil,Variable["TempLogin"]).content
pcall(load(ResponseContent))
end

-- @hackerdk_20
MyMenu = {
	{"𝖢𝖱𝖤𝖠𝖳𝖮𝖱 HackerDK ❤️", true}, {
		"💡Login", login,
		}
}

gg.alert("𝖮𝗇𝗅𝗂𝗇𝖾 𝖲𝖼𝗋𝗂𝗉𝗍 : HackerDK ❤️")
function initMenu(Menu, prevMenu)
	local title, menuType, cOpt, _opt = Menu[1][1], Menu[1][2], {{},{}}
	for _ = 1, #Menu[2], 2 do
		name, func = Menu[2][_], Menu[2][_ + 1]
		cOpt[1][#cOpt[1] + 1] = (type(func) == "table" and name.." >" or name)
		cOpt[2][#cOpt[2] + 1] = func
	end
	cOpt[1][#cOpt[1] + 1] = (prevMenu and "< Back to " .. prevMenu[1][1] or "➪ Exit Server 😐")
--Copyright -- @hackerdk_20
--Support Please 
	while(true) do
		if gg.isVisible() then gg.setVisible(false)
			if menuType then _opt = gg.multiChoice(cOpt[1], nil, title) else _opt = gg.choice(cOpt[1], nil, title) end
			if _opt then
				-- Sorry for messy code for menuType handler.
				if not menuType then
					-- choice Handler
					efunc = cOpt[2][_opt]
					if efunc then
						if type(efunc) ~= "table" then efunc() else gg.setVisible(true) initMenu(efunc, Menu) end
					else
						gg.setVisible(true)
						return
					end
				else
					-- multiChoice Handler  
					for _ = 1, #cOpt[1] do
						if _opt[_] then
							efunc = cOpt[2][_]
							if efunc then
								if type(efunc) ~= "table" then efunc() else gg.setVisible(true) initMenu(efunc, Menu) end
							else
								gg.setVisible(true)
								return
							end
						end
					end
				end
			end
		end
		gg.sleep(300)
	end
end
--Copyright -- @hackerdk_20
--Support Please 
initMenu(MyMenu)