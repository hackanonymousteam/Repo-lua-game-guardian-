<?php

$start_hour = 7; 

if ($start_hour < 0 || $start_hour > 23) {
    echo "error.";
    exit;
}

$time_difference_hours = 6; // 6 hours

$start_datetime = new DateTime();
$start_datetime->setTime($start_hour, 0, 0); 

$interval = new DateInterval("PT{$time_difference_hours}H");

$end_datetime = clone $start_datetime; 
$end_datetime->add($interval);

$end_hour = (int)$end_datetime->format('H');
$end_day = (int)$end_datetime->format('d');

echo "Horário final: " . $end_hour . "<br>";
echo "Dia final: " . $end_day . "<br>";
echo "start: " . $start_hour;
?>