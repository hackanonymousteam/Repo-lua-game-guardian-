local response = gg.makeRequest("http://www.whatismyip.org")
local dateHeader = response.headers["Date"][1]

local day = string.format("%d", tonumber(dateHeader:match("(%d+)")))

local hour = string.format("%d", tonumber(os.date('%H')))

local request = gg.makeRequest('https://YOUR_SERVER_HERE/day.php')

if request == nil or request.content == nil then
    print('Error: failed to get reply.')
    return
end

local response = request.content

local hour_value, day_value, start_value = response:match("Horário final: (%d+)<br>Dia final: (%d+)<br>start: (%d+)")

if hour_value and day_value and start_value then
    
    local saved_hour = hour_value
    local saved_day = day_value
    local saved_start = start_value

    if hour > saved_start and hour < saved_hour then
        print("Login success")
    else
    print("error login")
        os.exit()
    end

    if day ~= saved_day then
        gg.alert("Day incorrect, script won't work this day")
        os.exit()
    end
else
    print("error getting info.")
    os.exit()
end