from flask import Flask, request
from datetime import datetime

app = Flask(__name__)

usuarios = {
    "admin": {"senha": "1234", "expira": "2024-12-31"},
    "user": {"senha": "senha", "expira": "2025-05-01"},
    "joao": {"senha": "abc123", "expira": "2025-04-10"},
    "maria": {"senha": "xyz789", "expira": "2026-01-01"}
}

@app.route('/')
def login():
    user = request.args.get("user")
    senha = request.args.get("pass")

    if user in usuarios:
        dados = usuarios[user]
        data_expira = datetime.strptime(dados["expira"], "%Y-%m-%d")
        hoje = datetime.now()

        if hoje > data_expira:
            return "Login error! (expired)"
        if senha == dados["senha"]:
            return "Login sucess!"

    return "Login invalid!"