

Step-by-step guide to run a simple login system with PythonAnywhere (automatic Flask mode):


---

1. Create an account

Go to https://www.pythonanywhere.com and create a free account.


---

2. Create a new Web App

Go to the Web tab in the top menu.

Click on "Add a new web app".

Choose a subdomain (e.g., myapp.pythonanywhere.com).

Select:

Flask (this was your correct choice)

Python 3.7x



PythonAnywhere will create the basic structure — some small adjustments might be needed.


---

3. Add your Flask code

1. Go to the Files tab (top menu).


2. Navigate to the folder:

/home/YOUR_USERNAME/mysite/


3. Open the file:

flask_app.py


4. Delete the default content and paste your own code.


5. Save the file.




---

4. Restart the Web App

1. Go to the Web tab.


2. Click the "Reload" button at the top of the page.




---

5. Test in your browser

Open in your browser:

https://YOUR_USERNAME.pythonanywhere.com/?user=admin&pass=1234

Possible responses:

Login OK! → if the username and password are correct and still valid.

Login error! (expired) → if the account has expired.

Login invalid! → if the username doesn’t exist or the password is incorrect.



