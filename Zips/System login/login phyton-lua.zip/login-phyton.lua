

local chat = gg.prompt({'enter user','enter pass'}, {}, {'text','text'})
if chat == nil then
    return
end

local duck = chat[1]
local duck2 = chat[2]

--replace YOUR_USER 

local res = gg.makeRequest('https://YOUR_USER.pythonanywhere.com/?user='..duck..'&pass='..duck2)
if res and res.content then
    print(res.content)
else
    gg.alert("Error internet")
end