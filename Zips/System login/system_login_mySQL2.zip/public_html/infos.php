<?php

$host = 'localhost'; 
$db   = 'your_db_name'; 
$user = 'your_user'; 
$pass = 'your_pass'; 

try {
    $connection = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    
    $query = "SELECT usuario, senha FROM usuarios";
    $stmt = $connection->prepare($query);
    $stmt->execute();

    
    if ($stmt->rowCount() > 0) {
       
        $usuarios = [];

        
        while ($linha = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $usuarios[] = "Usuário: " . $linha['usuario'] . " | Senha: " . $linha['senha'];
        }

        
        echo implode("<br>", $usuarios);
    } else {
        echo 'user no found.';
    }
} catch (PDOException $e) {
    die('Erro: ' . $e->getMessage());
}
$connection = null;
?>