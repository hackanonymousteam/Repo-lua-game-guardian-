<?php
$host = 'localhost'; 
$db   = 'your_db_name'; 
$user = 'your_user'; 
$pass = 'your_pass'; 
 
try {
    $connection = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    
    $usuario = isset($_GET['user']) ? $_GET['user'] : '';
    $senha = isset($_GET['pass']) ? $_GET['pass'] : '';

    
    $query = "SELECT senha FROM usuarios WHERE usuario = :usuario";
    $stmt = $connection->prepare($query);
    $stmt->bindParam(':usuario', $usuario);
    $stmt->execute();

    
    if ($stmt->rowCount() === 1) {
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $senhaArmazenada = $linha['senha'];

        
        if ($senha === $senhaArmazenada) {
            
            $cookieValue = bin2hex(random_bytes(16));

            
            $query = "SHOW COLUMNS FROM usuarios LIKE 'dispositivo_info_%'";
            $stmt = $connection->query($query);
            $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);

            
            $columnValuesStr = implode(', ', $columns);
            $query = "SELECT $columnValuesStr FROM usuarios WHERE usuario = :usuario";
            $stmt = $connection->prepare($query);
            $stmt->bindParam(':usuario', $usuario);
            $stmt->execute();
            $results = $stmt->fetch(PDO::FETCH_ASSOC);

            
            $isCookiePresent = false;
            $emptyColumnName = null;

            foreach ($results as $columnName => $value) {
                if ($value === $cookieValue) {
                    $isCookiePresent = true; 
                    break;
                }
                if (empty($value) && is_null($emptyColumnName)) {
                    $emptyColumnName = $columnName; 
                }
            }

           
            if (!$isCookiePresent) {
                if (!is_null($emptyColumnName)) {
                    
                    $updateQuery = "UPDATE usuarios SET `$emptyColumnName` = :cookieValue WHERE usuario = :usuario";
                    $stmt = $connection->prepare($updateQuery);
                    $stmt->bindParam(':cookieValue', $cookieValue);
                    $stmt->bindParam(':usuario', $usuario);
                    $stmt->execute();
                    echo 'true'; 
                } else {
                    
                    $deleteQuery = "DELETE FROM usuarios WHERE usuario = :usuario";
                    $stmt = $connection->prepare($deleteQuery);
                    $stmt->bindParam(':usuario', $usuario);
                    $stmt->execute();
                    echo 'user_deleted'; 
                }
            } else {
                echo 'true'; 
            }
        } else {
            echo 'false'; 
        }
    } else {
        echo 'false'; 
    }
} catch (PDOException $e) {
    die('Error: ' . $e->getMessage());
}

$connection = null;
?>