<?php
$host = 'localhost'; 
$db   = 'your_db_name'; 
$user = 'your_user'; 
$pass = 'your_pass'; 

try {
    
    $connection = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    
    if (isset($_GET['usuario']) && isset($_GET['novouser']) && isset($_GET['novopass'])) {
        $usuario = $_GET['usuario'];
        $novouser = $_GET['novouser'];
        $novopass = $_GET['novopass'];

        
        $checkUserQuery = "SELECT COUNT(*) FROM usuarios WHERE usuario = :novouser";
        $stmt = $connection->prepare($checkUserQuery);
        $stmt->bindParam(':novouser', $novouser);
        $stmt->execute();

        if ($stmt->fetchColumn() > 0) {
            echo 'Erro: user exists.';
        } else {
            
            $updateQuery = "UPDATE usuarios SET usuario = :novouser, senha = :novopass WHERE usuario = :usuario";
            $stmt = $connection->prepare($updateQuery);
            $stmt->bindParam(':novouser', $novouser);
            $stmt->bindParam(':novopass', $novopass);
            $stmt->bindParam(':usuario', $usuario);

            
            if ($stmt->execute()) {
                echo 'sucess.';
            } else {
                echo 'Erro: .';
            }
        }
    } else {
        echo 'Erro: no found parameters.';
    }
} catch (PDOException $e) {
    die('Erro : ' . $e->getMessage());
}

$connection = null;
?>