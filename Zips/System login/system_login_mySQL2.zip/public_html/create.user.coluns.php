<?php
$host = 'localhost'; 
$db   = 'your_db_name'; 
$user = 'your_user'; 
$pass = 'your_pass'; 

try {
    
    $connection = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    
    $createTableQuery = "
        CREATE TABLE IF NOT EXISTS usuarios (
            id INT AUTO_INCREMENT PRIMARY KEY,
            usuario VARCHAR(255) NOT NULL UNIQUE,
            senha VARCHAR(255) NOT NULL
        )
    ";
    $connection->exec($createTableQuery);

    if (isset($_GET['usuario']) && isset($_GET['senha'])) {
        $usuario = $_GET['usuario'];
        $senha = $_GET['senha'];

        
        $query = "SELECT COUNT(*) FROM usuarios WHERE usuario = :usuario";
        $stmt = $connection->prepare($query);
        $stmt->bindParam(':usuario', $usuario);
        $stmt->execute();
        
        if ($stmt->fetchColumn() > 0) {
            echo 'Erro: user exists.';
        } else {
            
            $query = "INSERT INTO usuarios (usuario, senha) VALUES (:usuario, :senha)";
            $stmt = $connection->prepare($query);
            $stmt->bindParam(':usuario', $usuario);
            $stmt->bindParam(':senha', $senha);

            
            if ($stmt->execute()) {
                
                for ($i = 1; $i <= 100; $i++) {
                    $columnName = "dispositivo_info_$i"; 

                    
                    $query = "SHOW COLUMNS FROM usuarios LIKE :columnName";
                    $stmt = $connection->prepare($query);
                    $stmt->bindParam(':columnName', $columnName);
                    $stmt->execute();

                   
                    if ($stmt->rowCount() === 0) {
                        $alterQuery = "ALTER TABLE usuarios ADD COLUMN $columnName TEXT";
                        $connection->exec($alterQuery);
                    }
                }

                echo 'Sucess.';
            } else {
                echo 'Erro:.';
            }
        }
    } else {
        echo 'Erro: parameters no found.';
    }
} catch (PDOException $e) {
    die('Erro: ' . $e->getMessage());
}

$connection = null;