<?php
  if (isset($_GET['pass'])) {
    if ($_GET['pass'] == "1234") {
      echo 'HOME = 1
function HOME()
  XS = gg.choice({
"                             |[  HACL 1  ]|",
"                             |[  HACL 2  ]|",
"                             |[  HACL 3  ]|",
"                               |[  EXIT  ]|",
 }, nil,nil)
  if XS == nil then
  else
  if XS == 1 then N1() end
  if XS == 2 then N2() end
  if XS == 3 then N3() end
  if XS == 4 then CLOSE()
 end
  end
  PUBGMH = -1
end


function N1()
 
end

function N2()

end

function N3()

end

function CLOSE()
  gg.skipRestoreState()
  os.exit()
  gg.setVisible(true)
end
while true do
  if gg.isVisible(true) then
PUBGMH = 1
gg.setVisible(false)
  end
  gg.clearResults()
  if PUBGMH == 1 then
HOME()
  end
end';
    }
  }
?>