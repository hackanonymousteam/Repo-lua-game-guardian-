gg.alert("hello user")
log = gg.prompt({"Enter password"})
local r = gg.makeRequest("https://YOUR_SERVER_HERE/gg.php?pass="..log[1]).content
pcall(load(r))