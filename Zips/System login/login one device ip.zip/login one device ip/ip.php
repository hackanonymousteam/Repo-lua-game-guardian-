<?php
$filename = __FILE__;
$ip = file_exists('ip.txt') ? file_get_contents('ip.txt') : 'xxx.xxx.xxx.xxx';

if (isset($_GET['ip'])) {
    $userIp = $_GET['ip'];
    
    // If this is the first request and IP is still default
    if ($ip === 'xxx.xxx.xxx.xxx') {
        // Update the stored IP
        file_put_contents('ip.txt', $userIp);
        $ip = $userIp;
        
        // Update the PHP file itself
        $scriptContent = file_get_contents($filename);
        $newContent = str_replace(
            '$ip = file_exists(\'ip.txt\') ? file_get_contents(\'ip.txt\') : \'xxx.xxx.xxx.xxx\';',
            '$ip = file_exists(\'ip.txt\') ? file_get_contents(\'ip.txt\') : \''.$userIp.'\';',
            $scriptContent
        );
        file_put_contents($filename, $newContent);
    }
    
    // Compare the IPs
    if ($userIp === $ip) {
        echo 'true';
    } else {
        echo 'false';
    }
} else {
    echo 'Error: IP parameter not provided';
}
?>