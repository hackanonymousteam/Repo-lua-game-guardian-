function checkIp()
    local Link = "https://browserleaks.com/ip"
    local bat = gg.makeRequest(Link).content

    if bat == nil then
        gg.alert("Failed to get IP address")
        os.exit()
    end

    local response = bat

    local function extractDataIPFromHTML(html)
        local pattern = 'data%-ip%="([%d%.]+)"'
        local dataIP = html:match(pattern)
        return dataIP
    end

    local dataIP = extractDataIPFromHTML(response)

    if not dataIP then
        gg.alert('Failed to extract IP address')
        os.exit()
    else
       -- print('IP USER:', dataIP)
        return dataIP
    end
end

function login()
    local dataIP = checkIp()
    local url = 'https://YOUR_SERVER/ip.php?ip='..dataIP

    local request = gg.makeRequest(url)

    if request == nil or request.content == nil then
        gg.alert('Error: Please check internet connection.')
        os.exit()
    end
    
    local response = request.content
    if response == 'true' then
        gg.alert('Login success!')
        -- Start your script here
    elseif response == 'false' then
        gg.alert('IP not authorized!')
        os.exit()
    else
        gg.alert('Unexpected error: ' .. response)
        os.exit()
    end
end

login()