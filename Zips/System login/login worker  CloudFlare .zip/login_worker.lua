local WORKER_URL = "https://YOUR_WORKER_HERE.workers.dev"
local ADMIN_TOKEN = ""

local logged = false
local session_token = nil

local function parse_json(text)
    local result = {}
    local success = pcall(function()
        local clean = text:gsub("%s+", "")
        if clean:sub(1,1) == "{" and clean:sub(-1,-1) == "}" then
            local content = clean:sub(2, -2)
            for pair in content:gmatch('[^,]+') do
                local key, value = pair:match('"([^"]+)":"?([^",]-)"?$')
                if key then
                    if value == "true" then
                        result[key] = true
                    elseif value == "false" then
                        result[key] = false
                    elseif tonumber(value) then
                        result[key] = tonumber(value)
                    else
                        result[key] = value
                    end
                end
            end
        end
    end)
    return result
end

local function req_get(url, token)
    local headers = {
        ["Accept"] = "application/json"
    }
    if token then
        headers["Authorization"] = "Bearer " .. token
    end
    return gg.makeRequest(url, headers)
end

local function login()
    local i = gg.prompt(
        {"Admin Token"},
        {""},
        {"text"}
    )
    if not i or i[1] == "" then return false end
    
    local token = i[1]
    local r = req_get(WORKER_URL .. "/admin/login?token=" .. token)
    
    if r and r.code == 200 then
        local data = parse_json(r.content)
        if data.login then
            logged = true
            session_token = token
            ADMIN_TOKEN = token
            gg.alert("Login successful")
            return true
            --start your logic here
        end
    end
    
    gg.alert("Invalid token")
    return false
end

login()