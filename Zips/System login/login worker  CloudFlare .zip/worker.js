const CORS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

function json(data, status = 200) {
    return new Response(JSON.stringify(data), {
        status,
        headers: { 'Content-Type': 'application/json', ...CORS },
    });
}

function html(body, status = 200) {
    return new Response(body, {
        status,
        headers: { 'Content-Type': 'text/html;charset=UTF-8', ...CORS },
    });
}

function loginPageHTML(error = '') {
    const errorHTML = error ? `<p style="color:#ff4444;margin-top:16px">${error}</p>` : '';
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
    <title>Admin Login</title>
    <style>
        *{margin:0;padding:0;box-sizing:border-box}
        body{font-family:system-ui,sans-serif;background:#0a0a0f;color:#e0e0e8;min-height:100vh;display:flex;align-items:center;justify-content:center}
        .card{background:#131320;border:1px solid #252540;border-radius:12px;padding:32px;width:100%;max-width:360px;text-align:center}
        h1{font-size:20px;font-weight:700;margin-bottom:20px;color:#ff4444}
        input{width:100%;padding:12px;background:#0a0a0f;border:1px solid #252540;border-radius:8px;color:#e0e0e8;font-size:14px;margin-bottom:12px;outline:none}
        input:focus{border-color:#c90000}
        button{width:100%;padding:12px;background:#c90000;color:#fff;border:none;border-radius:8px;font-weight:600;font-size:14px;cursor:pointer}
        button:hover{background:#ff4444}
        .methods{display:flex;gap:8px;margin-bottom:12px}
        .method{flex:1;padding:8px;background:#0a0a0f;border:1px solid #252540;border-radius:6px;color:#8888a0;cursor:pointer;font-size:12px}
        .method.active{background:#c90000;color:#fff;border-color:#c90000}
        .code{background:#0a0a0f;border:1px solid #252540;border-radius:8px;padding:12px;text-align:left;display:none}
        .code.active{display:block}
        code{color:#ff4444;font-size:12px;word-break:break-all}
        p{font-size:13px;color:#8888a0;margin-bottom:8px}
    </style>
</head>
<body>
    <div class="card">
        <h1>Admin Login</h1>
        
        <div class="methods">
            <div class="method active" onclick="showTab('form')">Form</div>
            <div class="method" onclick="showTab('get')">GET</div>
            <div class="method" onclick="showTab('json')">JSON</div>
        </div>

        <div id="tab-form" class="code active">
            <form method="POST" action="/admin/login">
                <input type="password" name="admin_token" placeholder="Admin token..." autocomplete="off">
                <button type="submit">Login</button>
            </form>
        </div>

        <div id="tab-get" class="code">
            <p>Acesse:</p>
            <code>/admin/login?token=SEU_TOKEN</code>
        </div>

        <div id="tab-json" class="code">
            <p>POST /admin/login</p>
            <code>{"admin_token":"SEU_TOKEN"}</code>
        </div>
        ${errorHTML}
    </div>

    <script>
        function showTab(tab){
            document.querySelectorAll('.method').forEach(m=>m.classList.remove('active'));
            document.querySelectorAll('.code').forEach(c=>c.classList.remove('active'));
            document.querySelector('.method[onclick*="'+tab+'"]').classList.add('active');
            document.getElementById('tab-'+tab).classList.add('active');
        }
    </script>
</body>
</html>`;
}

function adminPageHTML(token) {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Admin Panel</title>
    <style>
        *{margin:0;padding:0;box-sizing:border-box}
        body{font-family:system-ui,sans-serif;background:#0a0a0f;color:#e0e0e8;min-height:100vh;display:flex;align-items:center;justify-content:center}
        .card{background:#131320;border:1px solid #252540;border-radius:12px;padding:32px;text-align:center;max-width:400px}
        h1{font-size:24px;font-weight:700;color:#22c55e;margin-bottom:12px}
        p{color:#8888a0;font-size:14px;margin-bottom:8px}
        .token-box{background:#0a0a0f;border:1px solid #252540;border-radius:8px;padding:12px;margin-top:16px;text-align:left}
        .token-box code{color:#ff4444;font-size:11px;word-break:break-all}
        button{width:100%;padding:12px;background:#c90000;color:#fff;border:none;border-radius:8px;font-weight:600;font-size:14px;cursor:pointer;margin-top:16px}
        button:hover{background:#ff4444}
    </style>
</head>
<body>
    <div class="card">
        <h1>✅ Autenticado</h1>
        <p>Login realizado com sucesso.</p>
        <div class="token-box">
            <p style="font-size:12px;color:#8888a0;margin-bottom:8px">Seu token:</p>
            <code>${token}</code>
        </div>
        <button onclick="logout()">Sair</button>
    </div>
    <script>
        function logout(){
            window.location.href='/admin/login';
        }
    </script>
</body>
</html>`;
}

export default {
    async fetch(request, env) {

        try {
            if (request.method === 'OPTIONS') {
                return new Response(null, { headers: CORS });
            }

            const url = new URL(request.url);
            const path = url.pathname.replace(/\/+$/, '') || '/';
            

            const ADMIN_TOKEN = env.ADMIN_TOKEN || '';


            if (path === '/admin/login' && request.method === 'GET') {
                const token = url.searchParams.get('token') || '';
                
                if (token && token === ADMIN_TOKEN) {
                    return json({ login: true });
                }
                
                return html(loginPageHTML());
            }

            
            if (path === '/admin/login' && request.method === 'POST') {
                const contentType = request.headers.get('Content-Type') || '';
                let token = '';
                
                if (contentType.includes('application/json')) {
                    const body = await request.json().catch(() => ({}));
                    token = body.admin_token || '';
                } else {
                    const formData = await request.formData();
                    token = formData.get('admin_token') || '';
                }

                if (token && token === ADMIN_TOKEN) {
                    return json({ login: true });
                }
                
                return json({ login: false }, 401);
            }

            
            if (path === '/admin' && request.method === 'GET') {
                const authHeader = request.headers.get('Authorization') || '';
                const headerToken = authHeader.replace('Bearer ', '');
                const queryToken = url.searchParams.get('token') || '';
                const token = headerToken || queryToken;
                
                if (token && token === ADMIN_TOKEN) {
                    return html(adminPageHTML(token));
                }
                
                return json({ login: false, error: 'Token required' }, 401);
            }

            return json({ error: 'Not Found' }, 404);
            
        } catch (error) {
            return json({ 
                error: 'Internal Server Error', 
                message: error.message 
            }, 500);
        }
    }
};