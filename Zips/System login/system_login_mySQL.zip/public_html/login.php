<?php

$host = 'localhost'; 
$db   = 'your_db_name'; 
$user = 'your_user'; 
$pass = 'your_pass'; 
  
try {
    $connection = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $usuario = isset($_GET['user']) ? $_GET['user'] : '';
    $senha = isset($_GET['pass']) ? $_GET['pass'] : '';

    $query = "SELECT senha FROM usuarios WHERE usuario = :usuario";
    $stmt = $connection->prepare($query);
    $stmt->bindParam(':usuario', $usuario);
    $stmt->execute();

    if ($stmt->rowCount() === 1) {
        $linha = $stmt->fetch(PDO::FETCH_ASSOC);
        $senhaArmazenada = $linha['senha'];


        if ($senha === $senhaArmazenada) {
            echo 'true';
        } else {
            echo 'false';
        }
    } else {
        echo 'false';
    }
} catch (PDOException $e) {
    die('Error: ' . $e->getMessage());
}

$connection = null; 
?>