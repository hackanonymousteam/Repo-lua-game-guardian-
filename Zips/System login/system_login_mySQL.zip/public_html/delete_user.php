<?php

$host = 'localhost'; 
$db   = 'your_db_name'; 
$user = 'your_user'; 
$pass = 'your_pass'; 
 
try {
   
    $connection = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  
    if (isset($_GET['usuario'])) {
        $usuario = $_GET['usuario'];

        
        $query = "SELECT COUNT(*) FROM usuarios WHERE usuario = :usuario";
        $stmt = $connection->prepare($query);
        $stmt->bindParam(':usuario', $usuario);
        $stmt->execute();

       
        if ($stmt->fetchColumn() > 0) {
            
            $deleteQuery = "DELETE FROM usuarios WHERE usuario = :usuario";
            $stmt = $connection->prepare($deleteQuery);
            $stmt->bindParam(':usuario', $usuario);

            if ($stmt->execute()) {
                echo 'user delete sucess.';
            } else {
                echo 'Error.';
            }
        } else {
            echo 'Erro: user no found.';
        }
    } else {
        echo 'Erro: no get parameters.';
    }
} catch (PDOException $e) {
    die('Error: ' . $e->getMessage());
}


$connection = null;
?>