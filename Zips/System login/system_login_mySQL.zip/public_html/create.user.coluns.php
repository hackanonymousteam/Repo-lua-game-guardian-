<?php

$host = 'localhost'; 
$db   = 'your_db_name'; 
$user = 'your_user'; 
$pass = 'your_pass'; 
 

try {
    
    $connection = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  
    $createTableQuery = "
        CREATE TABLE IF NOT EXISTS usuarios (
            id INT AUTO_INCREMENT PRIMARY KEY,
            usuario VARCHAR(255) NOT NULL UNIQUE,
            senha VARCHAR(255) NOT NULL
        )
    ";
    $connection->exec($createTableQuery);

    
    if (isset($_GET['usuario']) && isset($_GET['senha'])) {
        $usuario = $_GET['usuario'];
        $senha = $_GET['senha'];

        $query = "SELECT COUNT(*) FROM usuarios WHERE usuario = :usuario";
        $stmt = $connection->prepare($query);
        $stmt->bindParam(':usuario', $usuario);
        $stmt->execute();
        
        if ($stmt->fetchColumn() > 0) {
            echo 'Erro: user exists.';
        } else {
            
            $query = "INSERT INTO usuarios (usuario, senha) VALUES (:usuario, :senha)";
            $stmt = $connection->prepare($query);
            $stmt->bindParam(':usuario', $usuario);
            $stmt->bindParam(':senha', $senha);

           
            if ($stmt->execute()) {
                echo 'Sucess.';
            } else {
                echo 'Error.';
            }
        }
    } else {
        echo 'Erro: no found values.';
    }
} catch (PDOException $e) {
    die('Error: ' . $e->getMessage());
}

$connection = null;