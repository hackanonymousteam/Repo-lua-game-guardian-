
function painelLua() 
enc = gg.choice({
"create users",
"remover users",
"edit info users",
"view info users",
"exit",
},0,"")
if enc == 1 then encv1() end
if enc == 2 then encv2() end
if enc == 3 then encv3() end
if enc == 4 then encv4() end
if enc == 5 then os.exit() end

BATMAN = -1
end
------------------------------------------------------------------------------------------------------------------
function encv1() 

function urlEncode(str)
    local url = str:gsub("([^%w])", function(c)
        return string.format("%%%02X", string.byte(c))
    end)
    return url:gsub(" ", "+")  
end

local chat = gg.prompt({'user', 'password'}, {}, {'text','text'})
if chat == nil then
    return
end

local user = chat[1]
local pass = chat[2]

local encoded_query = urlEncode(user)
local encoded_queryy = urlEncode(pass)

local url = 'https://YOUR_SERVER_HERE/create.user.coluns.php?usuario=' .. encoded_query .. '&senha=' .. encoded_queryy
                
local request = gg.makeRequest(url)

if request == nil or request.content == nil then
    print('Error.')
    os.exit()
    return
end

local response = request.content
    print(response)
    
    os.exit()
end

------------------------------------------------------------------------------------------------------------------
function encv2() 
    local url = 'https://YOUR_SERVER_HERE/infos.php'
    local request = gg.makeRequest(url)

    if request == nil or request.content == nil then
        print('Error .')
        return
    end

    local content = request.content
    local usuarios = {}
    
    for u, s in string.gmatch(content, "Usuário: ([^|]+) | Senha: ([^<]+)") do
        local usuario = u:match("^%s*(.-)%s*$")  
        local senha = s:match("^%s*(.-)%s*$")    
        
        if usuario and senha then
            table.insert(usuarios, {usuario = usuario, senha = senha})
        end
    end

    if #usuarios == 0 then
        print("no user found")
        gg.setVisible(true)
        os.exit()
        return
    end

    local options = {}
    for i, user in ipairs(usuarios) do
        table.insert(options, user.usuario)  
    end
    table.insert(options, 'Back')    

    local choice
    repeat
        choice = gg.choice(options, nil, 'select user for delete')
        if choice == nil then
            return 
        end
    until choice ~= nil

    if choice == #options then
        gg.alert('thanks for use my script ...')
    else
        local selected_usuario = usuarios[choice].usuario
        
        local url2 = 'https://YOUR_SERVER_HERE/delete_user.php?usuario=' .. selected_usuario
        local delete_request = gg.makeRequest(url2)

        if delete_request == nil or delete_request.content == nil then
            print('Error .')
            return
        end

        local delete_content = delete_request.content
        print(" sucess delete: " .. selected_usuario)
        gg.setVisible(true)
   os.exit()
 end
end
------------------------------------------------------------------------------------------------------------------

function encv3() 
    
    function urlEncode(str)
        local url = str:gsub("([^%w])", function(c)
            return string.format("%%%02X", string.byte(c))
        end)
        return url:gsub(" ", "+")  
    end

    local url = 'https://YOUR_SERVER_HERE/infos.php'
    local request = gg.makeRequest(url)

    if request == nil or request.content == nil then
        print('Error in acess infos.')
        return
    end

    local content = request.content
    local usuarios = {}
    
    for u, s in string.gmatch(content, "Usuário: ([^|]+) | Senha: ([^<]+)") do
        local usuario = u:match("^%s*(.-)%s*$")  
        local senha = s:match("^%s*(.-)%s*$")    
        
        if usuario and senha then
            table.insert(usuarios, {usuario = usuario, senha = senha})
        end
    end

    if #usuarios == 0 then
        print("no user found.")
        gg.setVisible(true)
        os.exit()
        
        return
    end

    local options = {}
    for i, user in ipairs(usuarios) do
        table.insert(options, user.usuario)  
    end
    table.insert(options, 'Back')    

    local choice
    repeat
        choice = gg.choice(options, nil, 'Select user for edit')
        if choice == nil then
            return 
        end
    until choice ~= nil

    if choice == #options then
        gg.alert('thanks for use my script ...')
    else
        local selected_usuario = usuarios[choice].usuario

        local chat = gg.prompt({' new user', ' new password'}, {}, {'text','text'})
        if chat == nil then
            return
        end

        local user = chat[1]
        local pass = chat[2]
        local encoded_query = urlEncode(user)
        local encoded_queryy = urlEncode(pass)

        local url3 = 'https://YOUR_SERVER_HERE/edit_users.php?usuario=' .. selected_usuario .. '&novouser=' .. encoded_query .. '&novopass=' .. encoded_queryy
        local login_request = gg.makeRequest(url3)

        if login_request == nil or login_request.content == nil then
            print('Error .')
            os.exit()
            return
        end
        print(login_request.content)
        gg.setVisible(true)
        os.exit()
        
    end
end

------------------------------------------------------------------------------------------------------------------

function encv4() 
    
    function urlEncode(str)
        local url = str:gsub("([^%w])", function(c)
            return string.format("%%%02X", string.byte(c))
        end)
        return url:gsub(" ", "+")  
    end

    local url = 'https://YOUR_SERVER_HERE/infos.php'
    local request = gg.makeRequest(url)

    if request == nil or request.content == nil then
        print('Error on acess infos.')
        os.exit()
        gg.setVisible(true)
        return
    end

    local content = request.content
    local usuarios = {}
    
    for u, s in string.gmatch(content, "Usuário: ([^|]+) | Senha: ([^<]+)") do
        local usuario = u:match("^%s*(.-)%s*$")  
        local senha = s:match("^%s*(.-)%s*$")    
        
        if usuario and senha then
            table.insert(usuarios, {usuario = usuario, senha = senha})
        end
    end

    if #usuarios == 0 then
        print("please select user.")
        return
    end

    local options = {}
    for i, user in ipairs(usuarios) do
        table.insert(options, user.usuario)  
    end
    table.insert(options, 'back')  

    local choice
    repeat
        choice = gg.choice(options, nil, 'Select User for view infos')
        if choice == nil then
            return 
        end
    until choice ~= nil

    if choice == #options then
        gg.alert('thanks for use my script ...')
    else
        local selected_usuario = usuarios[choice].usuario
        local selected_senha = usuarios[choice].senha  
        gg.alert('User: ' .. selected_usuario .. '\n pass: ' .. selected_senha)
        os.exit()
        gg.setVisible(true)
    end
   end

while(true)do if gg.isVisible(true)then BATMAN = 1 gg.setVisible(false)end
if BATMAN == 1 then painelLua()end
end