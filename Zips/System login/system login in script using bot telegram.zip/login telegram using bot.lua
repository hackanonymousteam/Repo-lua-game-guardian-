function urlencode(str)
    if str then
        str = string.gsub(str, "\n", "\r\n")
        str = string.gsub(str, "([^%w ])",
            function(c) return string.format("%%%02X", string.byte(c)) end)
        str = string.gsub(str, " ", "+")
    end
    return str
end

local CREDENTIALS_URL = "https://YOUR_SITE_HERE/users.txt" -- Replace!
local TELEGRAM_CONFIG_URL = "https://YOUR_SITE_HERE/config.bot.txt" -- Replace!
local SCRIPT_URL = "https://YOUR_SITE_HERE/linkYourScript.lua" -- Replace!
local IP_BANLIST_URL = "https://YOUR_SITE_HERE/ban.list.txt" -- Replace!

local function makeHttpRequest(url)
    local API = gg.makeRequest(url)
    return API
end

local function loadFromSite(url)
    local response = makeHttpRequest(url)
    if response and response.code == 200 and response.content then
        local func, err = load(response.content)
        if func then
            local success, result = pcall(func)
            if success then
                return result
            else
                gg.alert("Error executing loaded code: " .. tostring(result))
                return nil
            end
        else
            gg.alert("Error compiling code from Site: " .. tostring(err))
            return nil
        end
    else
        gg.alert("Error retrieving data from Site.")
        return nil
    end
end

local function getCurrentIp()
    local response = gg.makeRequest("https://api.ipify.org")
    if response and response.code == 200 and response.content then
        return response.content
    else
        gg.alert("Error retrieving IP address.")
        return nil
    end
end

local function sendTelegramMessage(botToken, chatId, message)
  local url = "https://api.telegram.org/bot" .. botToken .. "/sendMessage?chat_id=" .. chatId .. "&text=" .. urlencode(message)
  local response = gg.makeRequest(url)
  if not response or response.code ~= 200 then
    gg.alert("Error sending message to Telegram!")
  end
end

local function executeScriptFromSite(url)
  local response = makeHttpRequest(url)
  if response and response.code == 200 and response.content then
    local func, err = load(response.content)
    if func then
      local success, result = pcall(func)
        if success then
          return result
        else
          gg.alert("Error executing script from Site: " .. tostring(result))
          return nil
        end
    else
      gg.alert("Error compiling script from Site: " .. tostring(err))
      return nil
    end
  else
    gg.alert("Error retrieving script from Site.")
  end
end

local CREDENTIALS = loadFromSite(CREDENTIALS_URL)
if not CREDENTIALS then
    gg.alert("Failed to load credentials from Site. The script will be terminated.")
    os.exit()
end

local TELEGRAM_CONFIG = loadFromSite(TELEGRAM_CONFIG_URL)
if not TELEGRAM_CONFIG then
  gg.alert("Failed to load Telegram configuration from Site. The script will be terminated.")
  os.exit()
end

local IP_BANLIST = loadFromSite(IP_BANLIST_URL)
if IP_BANLIST == nil then
  gg.alert("Failed to load banned IP list from Site. The script will continue without IP checking.")
  IP_BANLIST = {} 
end

if not CREDENTIALS.ALLOWED_USERS then
    gg.alert("The credentials Site is missing the ALLOWED_USERS table. The script will be terminated.")
    os.exit()
end

if not TELEGRAM_CONFIG.BOT_TOKEN or not TELEGRAM_CONFIG.CHAT_ID then
  gg.alert("The Telegram configuration Site is missing BOT_TOKEN or CHAT_ID. The script will be terminated.")
  os.exit()
end

local function checkAccess(username, key)
  return CREDENTIALS.ALLOWED_USERS[username] == key
end

local prompts = {"@Username:", "Key:"}
local defaults = {"", ""}
local types = {"text", "text"}
local userInput = gg.prompt(prompts, defaults, types)

local telegramName = userInput[1] or nil
local userKey = userInput[2] or nil

local userIp = getCurrentIp()

local telegramMessage = ""

if telegramName and userKey then
    if IP_BANLIST[userIp] then
        telegramMessage = "[🚫] Attempted Login (Banned IP):\nUsername: " .. telegramName .. "\nIP: " .. userIp
        sendTelegramMessage(TELEGRAM_CONFIG.BOT_TOKEN, TELEGRAM_CONFIG.CHAT_ID, telegramMessage)
        gg.alert("Access denied. Your IP address is blocked.")
        os.exit()
    end

    if checkAccess(telegramName, userKey) then
        telegramMessage = "[✅] User Logged In:\nUsername: " .. telegramName .. "\nIP: " .. userIp
        sendTelegramMessage(TELEGRAM_CONFIG.BOT_TOKEN, TELEGRAM_CONFIG.CHAT_ID, telegramMessage)
        gg.toast("Access granted!")

        executeScriptFromSite(SCRIPT_URL)
    else
        telegramMessage = "[❌] Failed Login Attempt:\nUsername: " .. telegramName .. "\nIP: " .. userIp
        sendTelegramMessage(TELEGRAM_CONFIG.BOT_TOKEN, TELEGRAM_CONFIG.CHAT_ID, telegramMessage)
        gg.alert("Access denied. Incorrect username or key.")
        os.exit() 
    end
else
    telegramMessage = "[⚠️] Empty Login Attempt:\nIP: " .. userIp
    sendTelegramMessage(TELEGRAM_CONFIG.BOT_TOKEN, TELEGRAM_CONFIG.CHAT_ID, telegramMessage)
    gg.alert("Username and key must be entered.")
    os.exit() 
end