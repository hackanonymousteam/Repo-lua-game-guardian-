<?php

$servername = "localhost";
$username = "use_your_username";
$password = "use_your_pass";
$dbname = "use_your_dbname";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
                    }
?>
