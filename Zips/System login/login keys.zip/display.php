<?php


// Verifica login primeiro



// Função para gerar strings aleatórias
function generateRandomString($length) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

// Função para verificar e remover chaves expiradas
function removeExpiredKeys() {
    if (!file_exists('json_date.txt') || !file_exists('json_array.txt')) {
        return;
    }

    $dateData = json_decode(file_get_contents('json_date.txt'), true);
    $arrayData = json_decode(file_get_contents('json_array.txt'), true);
    $today = new DateTime();
    $modified = false;

    foreach ($dateData as $key => $expiryDate) {
        $expiry = DateTime::createFromFormat('d-m-Y', $expiryDate);
        if ($expiry < $today) {
            // Remove chave expirada
            unset($dateData[$key]);
            
            // Remove do array também
            $id = array_search($key, $arrayData);
            if ($id !== false) {
                unset($arrayData[$id]);
            }
            
            $modified = true;
        }
    }

    if ($modified) {
        file_put_contents('json_date.txt', json_encode($dateData));
        file_put_contents('json_array.txt', json_encode($arrayData));
    }
}

// Processa exclusão de chave
if (isset($_GET['del_key'])) {
    $delKey = $_GET['del_key'];
    
    // Remove do arquivo de datas
    $dateData = json_decode(file_get_contents('json_date.txt'), true);
    if (isset($dateData[$delKey])) {
        unset($dateData[$delKey]);
        file_put_contents('json_date.txt', json_encode($dateData));
    }
    
    // Remove do arquivo de array
    $arrayData = json_decode(file_get_contents('json_array.txt'), true);
    foreach ($arrayData as $id => $key) {
        if ($key === $delKey) {
            unset($arrayData[$id]);
            break;
        }
    }
    file_put_contents('json_array.txt', json_encode($arrayData));
    
    // Redireciona para evitar múltiplas deleções
    header("Location: display.php");
    exit;
}

// Gera novas chaves se os parâmetros foram enviados
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["generate"])) {
    $ndays = isset($_POST["ndays"]) ? (int)$_POST["ndays"] : 0;
    $nkey = isset($_POST["nkey"]) ? (int)$_POST["nkey"] : 0;
    
    if ($nkey > 0 && $ndays > 0) {
        $dateData = file_exists('json_date.txt') ? json_decode(file_get_contents('json_date.txt'), true) : array();
        $arrayData = file_exists('json_array.txt') ? json_decode(file_get_contents('json_array.txt'), true) : array();
        
        $today = new DateTime();
        $today->add(new DateInterval("P{$ndays}D"));
        $expiryDate = $today->format('d-m-Y');
        
        for ($i = 0; $i < $nkey; $i++) {
            $id = "s" . generateRandomString(11);
            $userPart = generateRandomString(12);
            $passPart = generateRandomString(8);
            $key = "$userPart:$passPart";
            
            $dateData[$key] = $expiryDate;
            $arrayData[$id] = $key;
        }
        
        file_put_contents('json_date.txt', json_encode($dateData));
        file_put_contents('json_array.txt', json_encode($arrayData));
        
        // Redireciona para evitar reenvio do formulário
        header("Location: display.php");
        exit;
    }
}

// Remove chaves expiradas sempre que a página é carregada
removeExpiredKeys();
?>

<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<head>
<style>
body {
    padding: 16px;
    font-family: Arial, sans-serif;
}
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
}
th, td {
  border: 1px solid black;
  padding: 15px;
  text-align: left;
}
#t01 tr:nth-child(even) {
  background-color: #eee;
}
#t01 tr:nth-child(odd) {
  background-color: #fff;
}
#t01 th {
  background-color: black;
  color: white;
}
.delete-btn {
  color: red;
  font-weight: bold;
  text-decoration: none;
  margin-left: 10px;
}
.form-container {
  margin-bottom: 20px;
  padding: 15px;
  border: 1px solid #ddd;
  border-radius: 5px;
}
</style>
</head>
<body>

<div class="form-container">
    <h3>Generate New Keys</h3>
    <form method="post" action="">
        <div>
            <label for="nkey">Number of Keys:</label>
            <input type="number" id="nkey" name="nkey" min="1" required>
        </div>
        <div>
            <label for="ndays">Valid for (days):</label>
            <input type="number" id="ndays" name="ndays" min="1" required>
        </div>
        <button type="submit" name="generate">Generate Keys</button>
    </form>
</div>

<?php
// Exibe a tabela de chaves
removeExpiredKeys(); // Verifica novamente antes de exibir

if (file_exists('json_date.txt') && file_exists('json_array.txt')) {
    $dateData = json_decode(file_get_contents('json_date.txt'), true);
    $arrayData = json_decode(file_get_contents('json_array.txt'), true);
    
    if (!empty($arrayData)) {
        echo '<table id="t01"><tr><th>ID</th><th>Expiry Date</th><th>Key</th><th>Action</th></tr>';
        
        $counter = 1;
        foreach ($arrayData as $id => $key) {
            if (isset($dateData[$key])) {
                $deleteLink = '<a class="delete-btn" href="?del_key=' . urlencode($key) . '" onclick="return confirm(\'Are you sure you want to delete this key?\')">&#128465;</a>';
                echo "<tr><td>$counter</td><td>{$dateData[$key]}</td><td>$key</td><td>$deleteLink</td></tr>";
                $counter++;
            }
        }
        
        echo '</table>';
    } else {
        echo '<p>No active keys available.</p>';
    }
} else {
    echo '<p>No keys generated yet.</p>';
}
?>

</body>
</html>