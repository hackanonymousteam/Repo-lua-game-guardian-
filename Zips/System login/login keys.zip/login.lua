local currentDate = os.date("%d-%m-%Y")

local function dateToTimestamp(dateStr)
    local day, month, year = dateStr:match("(%d+)-(%d+)-(%d+)")
    -- Converter strings para números inteiros
    return os.time({
        year = tonumber(year),
        month = tonumber(month),
        day = tonumber(day),
        hour = 0,
        min = 0,
        sec = 0
    })
end

local input = gg.prompt({"KEY"}, nil, {"text"})
if not input or not input[1] then 
    gg.alert("❌ No key provided!")
    os.exit() 
end

local inputKey = input[1]

local response = gg.makeRequest("https://YOUR_SERVER/display.php")
if not response or not response.content then
    gg.alert("❌ Failed to connect to server!")
    os.exit()
end

local html = response.content

local keyFound = false
local expiryDate = ""

-- Padrão para extrair ID, Data, Key e Action
for id, date, key in html:gmatch("<td>(.-)</td><td>(.-)</td><td>(.-)</td><td>.-></td></tr>") do
    if key == inputKey then
        keyFound = true
        expiryDate = date
        break
    end
end

if not keyFound then
    gg.alert("❌ Invalid key or key not found!")
    os.exit()
end

local currentTimestamp = dateToTimestamp(currentDate)
local expiryTimestamp = dateToTimestamp(expiryDate)

if currentTimestamp > expiryTimestamp then
    gg.alert(string.format(
        "⚠️ Key expired!\n\nKey: %s\nExpiry: %s\nCurrent: %s",
        inputKey, expiryDate, currentDate
    ))
    os.exit()
else
    local secondsRemaining = expiryTimestamp - currentTimestamp
    local daysRemaining = math.floor(secondsRemaining / 86400) -- 86400 = 60*60*24
    
    gg.alert(string.format(
        "✅ Valid key!\n\nKey: %s\nValid until: %s\nDays left: %d",
        inputKey, expiryDate, daysRemaining
    ))
end