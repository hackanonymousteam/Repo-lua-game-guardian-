<?php
$id = isset($_GET['id']) ? "s" . $_GET['id'] : '';
$key = isset($_GET['key']) ? $_GET['key'] : '';

if (empty($id) || empty($key)) {
    echo "1";
    exit;
}

// Verifica se o arquivo de datas existe
if (!file_exists('json_date.txt')) {
    echo "1";
    exit;
}

$dateData = json_decode(file_get_contents('json_date.txt'), true);
if (!isset($dateData[$key])) {
    echo "1";
    exit;
}

// Verifica o arquivo de array
if (!file_exists('json_array.txt')) {
    // Se não existe, cria com o novo par
    $arrayData = array($id => $key);
    file_put_contents('json_array.txt', json_encode($arrayData));
    echo $dateData[$key];
    exit;
}

$arrayData = json_decode(file_get_contents('json_array.txt'), true);

// Verifica se a chave já existe no array
if (in_array($key, $arrayData)) {
    $foundId = array_search($key, $arrayData);
    
    if ($id !== $foundId) {
        echo "2";
    } else {
        // Verifica se a chave está no formato user:pass
        if (strpos($key, ':') !== false) {
            list($userPart, $passPart) = explode(':', $key, 2);
            echo $dateData[$key];
        } else {
            echo "11";
        }
    }
} else {
    // Adiciona o novo par id => key
    $arrayData[$id] = $key;
    file_put_contents('json_array.txt', json_encode($arrayData));
    echo $dateData[$key];
}
?>