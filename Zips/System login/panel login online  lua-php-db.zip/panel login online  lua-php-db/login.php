<?php
session_start();
include('conexao.php');

if (empty($_POST['usuario']) || empty($_POST['senha'])) {
    echo 'erro_login';
    exit;
}

$usuario = mysqli_real_escape_string($conexao, $_POST['usuario']);
$senha = mysqli_real_escape_string($conexao, $_POST['senha']);

$query = "SELECT nome FROM usuario WHERE usuario = '{$usuario}' AND senha = md5('{$senha}')";
$result = mysqli_query($conexao, $query);

if (mysqli_num_rows($result) == 1) {
    $url = 'script.lua'; 
    header("Location: $url");
    exit;
} else {
    echo 'erro_login';
}
?>