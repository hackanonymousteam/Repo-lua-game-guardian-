gg.setVisible(true)

function encodeForm(data)
  local encoded = ""
  for k, v in pairs(data) do
    encoded = encoded .. k .. "=" .. v:gsub("([^%w ])", function(c)
      return string.format("%%%02X", string.byte(c))
    end):gsub(" ", "+") .. "&"
  end
  return encoded:sub(1, -2)
end

local input = gg.prompt({"User:", "password:"}, {}, {"text", "text"})
if not input then return end

local postData = encodeForm({
  usuario = input[1],
  senha = input[2]
})

local response = gg.makeRequest("https://YOUR_SERVER_HERE/login.php", {
  ["Content-Type"] = "application/x-www-form-urlencoded"
}, postData)

if not response or not response.content then
  gg.alert("Erro in reply.")
  return
end

if response.content:find("erro_login") then
  gg.alert("Erro in login.")
else
  local ok, func = pcall(load, response.content)
  if ok and func then
    pcall(func)
  else
    gg.alert("Erro execute script.")
  end
end

