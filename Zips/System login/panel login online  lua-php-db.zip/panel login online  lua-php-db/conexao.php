<?php
define('HOST', 'localhost'); //your server
define('USUARIO', 'test'); // your user database
define('SENHA', 'test');//your pass database
define('DB', 'test'); // name  database

$conexao = mysqli_connect(HOST, USUARIO, SENHA, DB) or die ('error');
?>