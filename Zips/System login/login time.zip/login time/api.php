<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$data_file = 'users.json';
$log_file = 'usage_log.txt';



function debugLog($message) {
    $timestamp = date('Y-m-d H:i:s');
    $debug_entry = "[$timestamp DEBUG] $message\n";
    file_put_contents('debug_log.txt', $debug_entry, FILE_APPEND);
}



if (!file_exists($data_file)) {
    file_put_contents($data_file, json_encode([]));
    debugLog("Arquivo users.json criado");
}



if (!is_writable($data_file)) {
    
    
    chmod($data_file, 0666);
    debugLog("Tentando dar permissão de escrita ao arquivo");
}



$users = json_decode(file_get_contents($data_file), true);
if ($users === null) {
    $users = [];
    debugLog("Erro ao decodificar JSON, array vazio criado");
}

$action = $_GET['action'] ?? '';
$key = $_GET['key'] ?? '';
$used_time = intval($_GET['used'] ?? 0);

debugLog("Ação: $action, Chave: $key, Tempo usado: $used_time");

function saveLog($message) {
    global $log_file;
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = "[$timestamp] $message\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND);
    debugLog("Log salvo: $message");
}

function findUserIndexByKey($key, $users) {
    foreach ($users as $index => $user) {
        if (isset($user['key']) && $user['key'] === $key) {
            return $index;
        }
    }
    return -1;
}

function saveUsers($users) {
    global $data_file;
    
    debugLog("Tentando salvar " . count($users) . " usuários");
    debugLog("Conteúdo antes de salvar: " . json_encode($users));
    
    $result = file_put_contents($data_file, json_encode($users, JSON_PRETTY_PRINT));
    
    if ($result === false) {
        debugLog("ERRO: Não foi possível escrever no arquivo!");
        debugLog("Permissões do arquivo: " . substr(sprintf('%o', fileperms($data_file)), -4));
        debugLog("É gravável? " . (is_writable($data_file) ? 'SIM' : 'NÃO'));
        return false;
    }
    
    debugLog("SUCESSO: file save with " . $result . " bytes");
    return true;
}

switch ($action) {
    case 'login':
    case 'check':
        debugLog("processing login/check: $key");
        $user_index = findUserIndexByKey($key, $users);
        
        if ($user_index !== -1) {
            $user = $users[$user_index];
            debugLog("Usuário encontrado: " . $user['username'] . ", Remaining: " . $user['remaining']);
            
            if ($user['remaining'] <= 0) {
                echo '{"status":"expired","message":"Time expired!","total_used":' . $user['used_time'] . '}';
                saveLog("LOGIN EXPIRED - Key: $key, User: {$user['username']}");
            } else {
                echo '{"status":"success","username":"' . $user['username'] . '","total_time":' . $user['total_time'] . ',"used_time":' . $user['used_time'] . ',"remaining":' . $user['remaining'] . ',"last_login":"' . date('Y-m-d H:i:s') . '"}';
                saveLog("LOGIN SUCCESS - Key: $key, User: {$user['username']}, Remaining: {$user['remaining']}s");
            }
        } else {
            echo '{"status":"error","message":"Invalid key!"}';
            saveLog("LOGIN ERROR - Invalid key: $key");
        }
        break;
        
    case 'heartbeat':
    case 'logout':
        debugLog("Processando $action para chave: $key, time used: $used_time");
        $user_index = findUserIndexByKey($key, $users);
        
        if ($user_index !== -1) {
            
            
            $old_used_time = $users[$user_index]['used_time'];
            $old_remaining = $users[$user_index]['remaining'];
            
            debugLog("ANTES - used_time: $old_used_time, remaining: $old_remaining");
            
            
            
            $users[$user_index]['used_time'] += $used_time;
            $users[$user_index]['remaining'] = $users[$user_index]['total_time'] - $users[$user_index]['used_time'];
            
            if ($users[$user_index]['remaining'] < 0) {
                $users[$user_index]['remaining'] = 0;
            }
            
            $new_used_time = $users[$user_index]['used_time'];
            $new_remaining = $users[$user_index]['remaining'];
            
            debugLog("DEPOIS - used_time: $new_used_time, remaining: $new_remaining");
            
            
            
            if (saveUsers($users)) {
                $user = $users[$user_index];
                
                if ($action == 'logout') {
                    echo '{"status":"success","message":"Logout completed!","used_time":' . $user['used_time'] . ',"remaining":' . $user['remaining'] . '}';
                    saveLog("LOGOUT - Key: $key, User: {$user['username']}, Used: {$used_time}s, Remaining: {$user['remaining']}s");
                } else {
                    if ($user['remaining'] <= 0) {
                        echo '{"status":"expired","message":"Time expired!","total_used":' . $user['used_time'] . '}';
                        saveLog("HEARTBEAT EXPIRED - Key: $key, User: {$user['username']}");
                    } else {
                        echo '{"status":"success","username":"' . $user['username'] . '","total_time":' . $user['total_time'] . ',"used_time":' . $user['used_time'] . ',"remaining":' . $user['remaining'] . '}';
                        saveLog("HEARTBEAT - Key: $key, User: {$user['username']}, Used: {$used_time}s, Remaining: {$user['remaining']}s");
                    }
                }
            } else {
                debugLog("ERROR!");
                echo '{"status":"error","message":"Server save error!"}';
                saveLog("SAVE ERROR - Failed to save users.json");
            }
        } else {
            echo '{"status":"error","message":"Invalid key!"}';
            saveLog("{$action} ERROR - Invalid key: $key");
        }
        break;
        
    default:
        echo '{"status":"error","message":"Invalid action!"}';
        saveLog("ERROR - Invalid action: $action");
}

debugLog("done\n");
?>