import "java.net.*"
import "java.io.*"
import "java.util.*"

local BASE_URL = "https://YOUR_SERVER_HERE/api.php" --replace 
local API_KEY = ""
local USER_DATA = {}
local HEARTBEAT_INTERVAL = 10
local SESSION_START = 0
local LOCAL_TIME_USED = 0

function formatTime(seconds)
if seconds <= 0 then return "00:00:00" end
local hours = math.floor(seconds / 3600)
local minutes = math.floor((seconds % 3600) / 60)
local secs = seconds % 60
return string.format("%02d:%02d:%02d", hours, minutes, secs)
end

function httpRequest(url)
local success, result = pcall(function()
local urlObj = URL(url)
local conn = urlObj:openConnection()
conn:setConnectTimeout(10000)
conn:setReadTimeout(10000)
conn:setRequestProperty("User-Agent", "TimeLicense/1.0")
conn:connect()
if conn:getResponseCode() == 200 then
local reader = BufferedReader(InputStreamReader(conn:getInputStream()))
local lines, line = {}, reader:readLine()
while line do table.insert(lines, line) line = reader:readLine() end
reader:close()
conn:disconnect()
return table.concat(lines, "\n")
else
conn:disconnect()
return nil
end
end)
return success and result or nil
end

function parseApiResponse(response)
if not response then return {status = "error"} end
local data = {}
data.status = response:match('"status":"(%w+)"') or "error"
data.message = response:match('"message":"([^"]+)"') or ""
data.username = response:match('"username":"([^"]+)"') or ""
data.total_time = tonumber(response:match('"total_time":(%d+)')) or 0
data.used_time = tonumber(response:match('"used_time":(%d+)')) or 0
data.remaining = tonumber(response:match('"remaining":(%d+)')) or 0
return data
end

function updateLocalTime()
local now = os.time()
if SESSION_START > 0 then
LOCAL_TIME_USED = LOCAL_TIME_USED + (now - SESSION_START)
end
SESSION_START = now
return LOCAL_TIME_USED
end

function getEstimatedRemaining()
if not USER_DATA.remaining then return 0 end
local estimated = USER_DATA.remaining - LOCAL_TIME_USED
return estimated > 0 and estimated or 0
end

function login()
gg.setVisible(true)
local input = gg.prompt({"Enter access key:"}, {}, {"text"})
if not input or input[1] == "" then
gg.alert("Login canceled!")
return false
end
API_KEY = input[1]:gsub("%s+", "")
gg.toast("Connecting...")
local response = httpRequest(BASE_URL .. "?action=login&key=" .. API_KEY)
if not response then
gg.alert("Connection error!")
return false
end
local data = parseApiResponse(response)
if data.status == "expired" then
gg.alert("TIME EXPIRED!")
return false
end
if data.status ~= "success" then
gg.alert("Error: " .. data.message)
return false
end
USER_DATA = {
username = data.username,
total_time = data.total_time,
used_time = data.used_time,
remaining = data.remaining
}
SESSION_START = os.time()
LOCAL_TIME_USED = 0
local info = "User: " .. USER_DATA.username .. "\n" ..
"Remaining: " .. formatTime(getEstimatedRemaining()) .. "\n" ..
"Total: " .. formatTime(USER_DATA.total_time)
gg.alert(info)
return true
end

function sendHeartbeat()
local timeUsed = updateLocalTime()
if timeUsed <= 0 then return true end
local response = httpRequest(BASE_URL .. "?action=heartbeat&key=" .. API_KEY .. "&used=" .. timeUsed)
if not response then return true end
local data = parseApiResponse(response)
if data.status == "success" then
USER_DATA.used_time = data.used_time
USER_DATA.remaining = data.remaining
LOCAL_TIME_USED = 0
return true
elseif data.status == "expired" then
gg.alert("TIME EXPIRED!")
return false
end
return true
end

function forceLogout()
local timeUsed = updateLocalTime()
httpRequest(BASE_URL .. "?action=logout&key=" .. API_KEY .. "&used=" .. timeUsed)
--gg.alert("Session ended!\nTime used: " .. formatTime(timeUsed))
return false
end

function normalLogout()
if gg.alert("Exit?", "Yes", "No") == 1 then
return forceLogout()
end
return true
end

function checkTime()
updateLocalTime()
if getEstimatedRemaining() <= 0 then
gg.alert("TIME EXPIRED!")
return forceLogout()
end
return true
end

function showMainMenu()
if not checkTime() then
return false
end
local menuOptions = {
"FUNCTION ONE",
"FUNCTION TWO", 
"FUNCTION THREE",
"EXIT"
}
local user_info = "User: " .. USER_DATA.username .. "\n" ..
"Remaining: " .. formatTime(getEstimatedRemaining()) .. "\n" ..
"Session: " .. formatTime(os.time() - SESSION_START) .. "\n" ..
"Total Time: " .. formatTime(USER_DATA.total_time)

local choice = gg.choice(menuOptions, "🌐 TIME LICENSING SYSTEM", user_info)
if choice == 0 then
return true
end

if choice == 1 then
gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("-0.50344371796;9.99999997e-7;-0.50291442871::9", gg.TYPE_FLOAT)
    gg.refineNumber("9.99999997e-7", gg.TYPE_FLOAT)
    gg.getResults(100)
    gg.editAll("-1", gg.TYPE_FLOAT)
    gg.clearResults()
    gg.toast(" HACK ACTIVATED")
    
elseif choice == 2 then

gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("-0.50344371796;9.99999997e-7;-0.50291442871::9", gg.TYPE_FLOAT)
    gg.refineNumber("9.99999997e-7", gg.TYPE_FLOAT)
    gg.getResults(100)
    gg.editAll("-1", gg.TYPE_FLOAT)
    gg.clearResults()
    gg.toast(" HACK ACTIVATED")

elseif choice == 3 then

gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("-0.50344371796;9.99999997e-7;-0.50291442871::9", gg.TYPE_FLOAT)
    gg.refineNumber("9.99999997e-7", gg.TYPE_FLOAT)
    gg.getResults(100)
    gg.editAll("-1", gg.TYPE_FLOAT)
    gg.clearResults()
    gg.toast(" HACK ACTIVATED")
    
elseif choice == 4 then
local confirm = gg.alert("Do you want to exit?", "Yes", "No")
if confirm == 1 then
forceLogout()
return false
end
end
return true
end

function mainLoop()
local running = true
local lastHeartbeat = os.time()
while running do
if os.time() - lastHeartbeat >= HEARTBEAT_INTERVAL then
if not sendHeartbeat() then
forceLogout()
running = false
end
lastHeartbeat = os.time()
end
if gg.isVisible(true) then
gg.setVisible(false)
if not showMainMenu() then
running = false
end
end
gg.sleep(1000)
end
end

function main()
gg.setVisible(false)
gg.clearResults()
if not login() then return end
--gg.toast("System ready!")
mainLoop()
end

local ok, err = pcall(main)
if not ok then
print("Error: " .. tostring(err))
--gg.alert("System error!")
end