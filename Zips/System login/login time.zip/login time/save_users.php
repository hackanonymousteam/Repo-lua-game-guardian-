<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$input = file_get_contents('php://input');
$users = json_decode($input, true);

if ($users !== null && is_array($users)) {
    file_put_contents('users.json', json_encode($users, JSON_PRETTY_PRINT));
    echo json_encode(['status' => 'success', 'message' => 'Users saved successfully']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid data received']);
}
?>