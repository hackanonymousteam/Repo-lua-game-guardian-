gg.alert("hello user")

local input = gg.prompt({"Enter password"})
if not input or not input[1] then
  gg.alert("Canceled")
  return
end

local ua = input[1]
local token = gg.getTargetInfo().packageName

local r = gg.makeRequest(
  "https://YOUR_SERVER_HERE/script.php?token=" .. token,
  { ["User-Agent"] = ua }
)

if not r or not r.content then
  gg.alert("Request failed")
  return
end
local KEY = 37

function decrypt(hex)
    local out = {}
    for i = 1, #hex, 2 do
        local byte = tonumber(hex:sub(i, i+1), 16)
        local d = (byte - KEY) % 256
        out[#out + 1] = string.char(d)
    end
    return table.concat(out)
end
local dec = decrypt(r.content)
pcall(load(dec))