local KEY = 37

local function tohex(s)
    return (s:gsub('.', function(c)
        return string.format('%02X', (string.byte(c) + KEY) % 256)
    end))
end

local script = [[


--paste your encrypt for encode here
gg.alert("invalid login")
os.exit()



]]

local enc = tohex(script)
print(enc)

gg.copyText(enc)


