gg.setVisible(true)

local FIREBASE_API_KEY = "your_api_key"
local FIREBASE_PROJECT_ID = "your_project"

local json = nil
if not pcall(function()
    json = load(gg.makeRequest("https://raw.githubusercontent.com/rxi/json.lua/master/json.lua").content)()
end) then
    json = require("json")
    if not json then
        gg.alert("JSON library not available")
        return
    end
end

local function tableToJson(tbl)
    if json then
        return json.encode(tbl)
    else
        local result = "{"
        for k, v in pairs(tbl) do
            if type(k) == "string" then
                result = result .. '"' .. k .. '":'
            end
            if type(v) == "string" then
                result = result .. '"' .. v .. '",'
            elseif type(v) == "number" then
                result = result .. tostring(v) .. ','
            elseif type(v) == "boolean" then
                result = result .. tostring(v) .. ','
            elseif type(v) == "table" then
                result = result .. tableToJson(v) .. ','
            end
        end
        result = result:sub(1, -2) .. "}"
        return result
    end
end

local function jsonToTable(jsonStr)
    if json then
        return json.decode(jsonStr)
    else
        local tbl = {}
        jsonStr = jsonStr:gsub("{", ""):gsub("}", "")
        for k, v in jsonStr:gmatch('"([^"]-)":"([^"]-)"') do
            tbl[k] = v
        end
        return tbl
    end
end

local function httpRequest(url, method, data, headers)
    local requestData = ""
    
    if data and (method == "POST" or method == "PUT") then
        if type(data) == "table" then
            requestData = tableToJson(data)
        else
            requestData = tostring(data)
        end
    end
    
    local requestHeaders = {
        ["Content-Type"] = "application/json",
        ["Accept"] = "application/json"
    }
    
    if headers then
        for _, header in ipairs(headers) do
            local key, value = header:match("([^:]+):%s*(.+)")
            if key and value then
                requestHeaders[key] = value
            end
        end
    end
    
    local response
    if method == "POST" then
        response = gg.makeRequest(url, requestHeaders, requestData)
    else
        response = gg.makeRequest(url, requestHeaders)
    end
    if response and response.code == 200 then
        return {
            success = true,
            data = response.content
        }
    else
        return {
            success = false,
            error = response and response.code or "Network error",
            data = response and response.content or ""
        }
    end
end

local function getRemoteConfig()
    gg.toast("Loading settings...")
    
    local url = "https://firebaseremoteconfig.googleapis.com/v1/projects/" .. 
                FIREBASE_PROJECT_ID .. "/namespaces/firebase:fetch?key=" .. FIREBASE_API_KEY
    
    local headers = {
        "Content-Type: application/json",
        "Accept: application/json"
    }
    
    local requestBody = {
        appId = "1:199800703133:android:abcdef123456",
        appInstanceId = "device_id_" .. tostring(math.random(100000, 999999)),
        appInstanceIdToken = "token_" .. tostring(math.random(100000, 999999)),
        languageCode = "pt-br"
    }
    
    local response = httpRequest(url, "POST", requestBody, headers)
    
    if response.success then
        local success, data = pcall(jsonToTable, response.data)
        
        if success and data and data.entries then
            local config = {}
            
            for key, value in pairs(data.entries) do
                config[key] = value
            end
            
            gg.toast("Settings loaded!")
            return config
        else
            gg.toast("Unexpected structure")
        end
    else
        gg.toast("Error loading from Firebase")
    end
end

local function validateLogin(username, password, remoteConfig)
    if not remoteConfig then
        return false, "Configuration not loaded"
    end
    
    if not remoteConfig.valid_users then
        return false, "User configuration not found"
    end
    
    local success, users = pcall(jsonToTable, remoteConfig.valid_users)
    if not success or type(users) ~= "table" then
        users = {}
        local userData = remoteConfig.valid_users:gsub("{", ""):gsub("}", ""):gsub('"', '')
        for user, pass in userData:gmatch("([%w_]+):([%w_]+)") do
            users[user] = pass
        end
    end
    
    if users[username] and users[username] == password then
        return true, "Valid login - Welcome, " .. username .. "!"
    else
        return false, "Invalid username or password"
    end
end

local function downloadAndExecuteScript(remoteConfig)
    if not remoteConfig then
        gg.alert("Configuration not loaded")
        return false
    end
    
    if remoteConfig.script_enabled ~= "true" then
        gg.alert("Script disabled at the moment")
        return false
    end
    
    if not remoteConfig.script_url then
        gg.alert("Script URL not configured")
        return false
    end
    
    local scriptUrl = remoteConfig.script_url
    
    BATMAN = gg.makeRequest(scriptUrl).content 
    if BATMAN == nil then os.exit() end 
    pcall(load(BATMAN)) 
    
    if remoteConfig.welcome_message then
        gg.alert(remoteConfig.welcome_message)
    end
end

local function run()
    local remoteConfig = getRemoteConfig()
    
    while true do
        local options = {
            "Login"
         --   "View Settings", 
         --   "Reload Config",
         --   "System Info",
        --    "Exit"
        }
        
        local title = "Remote Config login"
        if remoteConfig then
            title = title .. " | Config Loaded"
        else
            title = title .. " | No Config"
        end
        
        local choice = gg.choice(options, nil, title)
        
        if not choice then break end
        
        if choice == 1 then
            local inputs = gg.prompt({
                "Username:",
                "Password:"
            }, {
                "admin",
                "senha123"
            }, {"text", "text"})
            
            if inputs and inputs[1] and inputs[2] then
                local username = inputs[1]:gsub("%s+", "")
                local password = inputs[2]
                
                if username == "" or password == "" then
                    gg.alert("Please fill in username and password")
                else
                    local isValid, message = validateLogin(username, password, remoteConfig)
                    
                    gg.alert(message)
                    
                    if isValid then
                        
                        local downloadSuccess = downloadAndExecuteScript(remoteConfig)
                        
                        if not downloadSuccess then
                            gg.alert("Script not executed, but login was valid!")
                        end
                    end
                end
            end
            
        elseif choice == 2 then
            if remoteConfig then
                local info = "REMOTE SETTINGS:\n\n"
                local count = 0
                
                for key, value in pairs(remoteConfig) do
                    count = count + 1
                    if key == "valid_users" then
                        local users = {}
                        local success, userTable = pcall(jsonToTable, value)
                        if success and type(userTable) == "table" then
                            for user in pairs(userTable) do
                                table.insert(users, user)
                            end
                            info = info .. "• " .. key .. ": " .. table.concat(users, ", ") .. "\n"
                        else
                            info = info .. "• " .. key .. ": [user data]\n"
                        end
                    elseif key == "script_url" then
                        info = info .. "• " .. key .. ": " .. string.sub(tostring(value), 1, 50) .. "...\n"
                    else
                        info = info .. "• " .. key .. ": " .. tostring(value) .. "\n"
                    end
                end
                
                info = info .. "\nTotal settings: " .. count
                gg.alert(info)
            else
                gg.alert("No configuration loaded")
            end
            
        elseif choice == 3 then
            gg.toast("Reloading settings...")
            remoteConfig = getRemoteConfig()
            if remoteConfig then
                gg.alert("Settings reloaded successfully!")
            else
                gg.alert("Failed to reload settings")
            end
            
        elseif choice == 4 then
            local info = "SYSTEM INFORMATION\n\n"
            info = info .. "• Project: " .. FIREBASE_PROJECT_ID .. "\n"
            info = info .. "• API Key: " .. string.sub(FIREBASE_API_KEY, 1, 10) .. "..." .. "\n"
            info = info .. "• JSON Library: " .. (json and "Loaded" or "Not loaded") .. "\n"
            info = info .. "• Current Config: " .. (remoteConfig and "Loaded" or "Not loaded") .. "\n"
            
            if remoteConfig then
                info = info .. "\nSETTINGS:\n"
                info = info .. "• Script enabled: " .. (remoteConfig.script_enabled == "true" and "Yes" or "No") .. "\n"
                info = info .. "• Script URL: " .. (remoteConfig.script_url and "Configured" or "Not configured") .. "\n"
                info = info .. "• Message: " .. (remoteConfig.welcome_message or "Not configured") .. "\n"
            end
            
            gg.alert(info)
            
        elseif choice == 5 then
            gg.alert("Goodbye!")
            break
        end
    end
end

run()