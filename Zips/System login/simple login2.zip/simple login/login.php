<?php

$usuario = "Batman";
$senha = "Games";

if (!isset($_GET['user']) || !isset($_GET['senha'])) {
    echo 'false';
    exit;
} else {
    
    if ($_GET['user'] != $usuario || $_GET['senha'] != $senha) {
        echo 'false'; 
        exit;
    }
}

echo 'true';
?>