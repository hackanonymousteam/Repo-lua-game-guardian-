
function urlEncode(str)
    local url = str:gsub("([^%w])", function(c)
        return string.format("%%%02X", string.byte(c))
    end)
    return url:gsub(" ", "+")  
end

local chat = gg.prompt({'user', 'password'}, {}, {'text','text'})
if chat == nil then
    return
end

local user = chat[1]
local pass = chat[2]


local encoded_query = urlEncode(user)
local encoded_queryy = urlEncode(pass)
 
local url = 'https://YOUR_SERVER_HERE/login.php?user='..encoded_query..'&senha='..encoded_queryy
local request = gg.makeRequest(url)

if request == nil or request.content == nil then
    print('Error please check internet connection.')
    return
end


local response = request.content
if response == 'false' then
    print('User or password invalid.')
    os.exit()
elseif response == 'true' then
    gg.alert('Login sucess!')
else
    print('error unexpected: ' .. response)
end