

function file_exists(path)
  local file = io.open(path, "r")
  return file ~= nil
end

function main()
local filePath = gg.EXT_STORAGE .. '/08865446664456784.png'
 
  
    if file_exists(filePath) then
    --start your script here
    gg.alert("test")
  end
  
end


main()


