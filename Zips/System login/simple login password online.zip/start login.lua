local BatmanCheck = gg.makeRequest('http://YOUR_SERVER_HERE/login.lua').content
if BatmanCheck == nil then os.exit()
end

pcall(load(BatmanCheck))
local BatmanCheck =
gg.makeRequest('').content
if BatmanCheck == nil then os.exit() end
pcall(load(BatmanCheck))