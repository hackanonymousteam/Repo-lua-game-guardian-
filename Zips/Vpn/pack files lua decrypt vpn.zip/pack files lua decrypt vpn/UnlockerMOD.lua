x9ok = 1
function x9on()
while (true) do
if gg.isVisible(true) then 
x9A= 1
gg.clearResults()
gg.setVisible(false) 
end

x9B = 1
function x9B()
menu = gg.choice({
"〘 🔓 〙『 HTTP Injector 』\n",
"〘 🔓 〙『 Aplicativos Mais Usados 』\n",
"〘 🔓 〙『 HTTP Custom 』\n",
"〘 🔓 〙『 Payload de Qualquer Aplicativo 』\n",
"〘 🔓 〙『 Link De Atualização 』\n",
"〘 🔓 〙『 Usúario e Senha 』\n",
"〘 🔓 〙『 V2Ray 』\n",
"〘 🔓 〙『 Dump 』\n",
"〘 ❌ 〙『 Sair do Menu 』"},nil, (_G["os"]["date"]([[ 

Versão 2.0 x9.lua
Hoje é %d/%m/%Y 
São %H:%M:%S

『 📲 〙『@𝗻𝗲𝘁𝗳𝗿𝗲𝗲𝟬𝟴𝟬 - @𝗼𝗽𝗲𝗻𝗲𝗿𝘀_𝗻𝗲𝘄𝘀』]])))
 if menu == nil then x9P() end
 if menu == 1 then ehi() end
 if menu == 2 then x9C() end
 if menu == 3 then hc() end
 if menu == 4 then Payload() end
  if menu == 5 then link() end
 if menu == 6 then login() end
 if menu == 7 then V2Ray() end
 if menu == 8 then Dump() end
 if menu == 9 then EXIT() end
 x9A = -1
 
 
end

function ehi()

limit = true
targetInfo = gg.getTargetInfo()
app = targetInfo.packageName
local utf8 = {}
local bit = {
  data32 = {}
}
do
  do
    for SRD1_5_ = 1, 32 do
      bit.data32[SRD1_5_] = 2 ^ (32 - SRD1_5_)
    end
  end
end
local toby = string.byte
function utf8.charbytes(s, i)
  i = i or 1
  local c = string.byte(s, i)
  if c > 0 and c <= 127 then
    do return 1 end
    return
  end
  if c >= 194 and c <= 223 then
    do return 2 end
    return
  end
  if c >= 224 and c <= 239 then
    do return 3 end
    return
  end
  if c >= 240 and c <= 244 then
    return 4
  end
  return 1
end

local ded
function bit:d2b(arg)
  if arg == nil then
    return
  end
  local tr, c = {}, arg < 0
  if c then
    arg = 0 - arg
  end
  do
    do
      for SRD1_7_ = 1, 32 do
        if arg >= self.data32[SRD1_7_] then
          tr[SRD1_7_] = 1
          arg = arg - self.data32[SRD1_7_]
        else
          tr[SRD1_7_] = 0
        end
      end
    end
  end
  if c then
    tr = self:_bnot(tr)
    tr = self:b2d(tr) + 1
    tr = self:d2b(tr)
  end
  return tr
end

function bit:b2d(arg, neg)
  local nr = 0
  if arg[1] == 1 and neg == true then
    arg = self:_bnot(arg)
    nr = self:b2d(arg) + 1
    nr = 0 - nr
  else
    do
      for SRD1_7_ = 1, 32 do
        if arg[SRD1_7_] == 1 then
          nr = nr + 2 ^ (32 - SRD1_7_)
        end
      end
    end
  end
  return nr
end

function bit:_and(a, b)
  local op1 = self:d2b(a)
  local op2 = self:d2b(b)
  local r = {}
  do
    do
      for SRD1_9_ = 1, 32 do
        if op1[SRD1_9_] == 1 and op2[SRD1_9_] == 1 then
          r[SRD1_9_] = 1
        else
          r[SRD1_9_] = 0
        end
      end
    end
  end
  return self:b2d(r, true)
end

function bit:_or(a, b)
  local op1 = self:d2b(a)
  local op2 = self:d2b(b)
  local r = {}
  do
    do
      for SRD1_9_ = 1, 32 do
        if op1[SRD1_9_] == 1 or op2[SRD1_9_] == 1 then
          r[SRD1_9_] = 1
        else
          r[SRD1_9_] = 0
        end
      end
    end
  end
  return self:b2d(r, true)
end

function bit:_xor(a, b)
  local op1 = self:d2b(a)
  if op1 == nil then
    return nil
  end
  local op2 = self:d2b(b)
  if op2 == nil then
    return nil
  end
  local r = {}
  do
    do
      for SRD1_9_ = 1, 32 do
        if op1[SRD1_9_] == op2[SRD1_9_] then
          r[SRD1_9_] = 0
        else
          r[SRD1_9_] = 1
        end
      end
    end
  end
  return self:b2d(r, true)
end

local switch = {
  [1] = function(s, pos)
    local c1 = toby(s, pos)
    return c1
  end
  ,
  [2] = function(s, pos)
    local c1 = toby(s, pos)
    local c2 = toby(s, pos + 1)
    local int1 = bit:_and(31, c1)
    local int2 = bit:_and(63, c2)
    return bit:_or(bit:_lshift(int1, 6), int2)
  end
  ,
  [3] = function(s, pos)
    local c1 = toby(s, pos)
    local c2 = toby(s, pos + 1)
    local c3 = toby(s, pos + 2)
    local int1 = bit:_and(15, c1)
    local int2 = bit:_and(63, c2)
    local int3 = bit:_and(63, c3)
    local o2 = bit:_or(bit:_lshift(int1, 12), bit:_lshift(int2, 6))
    local dt = bit:_or(o2, int3)
    return dt
  end
  ,
  [4] = function(s, pos)
    local c1 = toby(s, pos)
    local c2 = toby(s, pos + 1)
    local c3 = toby(s, pos + 2)
    local c4 = toby(s, pos + 3)
    local int1 = bit:_and(15, c1)
    local int2 = bit:_and(63, c2)
    local int3 = bit:_and(63, c3)
    local int4 = bit:_and(63, c4)
    local o2 = bit:_or(bit:_lshift(int1, 18), bit:_lshift(int2, 12))
    local o3 = bit:_or(o2, bit:_lshift(int3, 6))
    local o4 = bit:_or(o3, int4)
    return o4
  end
  
}
function bit:_bnot(op1)
  local r = {}
  do
    do
      for SRD1_6_ = 1, 32 do
        if op1[SRD1_6_] == 1 then
          r[SRD1_6_] = 0
        else
          r[SRD1_6_] = 1
        end
      end
    end
  end
  return r
end

function bit:_not(a)
  local op1 = self:d2b(a)
  local r = self:_bnot(op1)
  return self:b2d(r, true)
end

function bit:charCodeAt(s)
  local pos, int, H, L = 1, 0, 0, 0
  local slen = string.len(s)
  local allByte = {}
  while pos <= slen do
    local tLen = utf8.charbytes(s, pos)
    if tLen >= 1 and tLen <= 4 then
      if tLen == 4 then
        int = switch[4](s, pos)
        H = math.floor((int - 65536) / 1024) + 55296
        L = (int - 65536) % 1024 + 56320
        table.insert(allByte, H)
        table.insert(allByte, L)
      else
        int = switch[tLen](s, pos)
        table.insert(allByte, int)
      end
    end
    pos = pos + tLen
  end
  return allByte
end

function bit:_rshift(a, n)
  local r = 0
  if a < 0 then
    r = 0 - self:_frshift(0 - a, n)
  elseif a >= 0 then
    r = self:_frshift(a, n)
  end
  return r
end

function bit:_frshift(a, n)
  local op1 = self:d2b(a)
  local r = self:d2b(0)
  local left = 32 - n
  if n < 32 and n > 0 then
    do
      for SRD1_9_ = left, 1, -1 do
        r[SRD1_9_ + n] = op1[SRD1_9_]
      end
    end
  end
  return self:b2d(r)
end

function bit:_lshift(a, n)
  local op1 = self:d2b(a)
  local r = self:d2b(0)
  if n < 32 and n > 0 then
    do
      for SRD1_8_ = n, 31 do
        r[SRD1_8_ - n + 1] = op1[SRD1_8_ + 1]
      end
    end
  end
  return self:b2d(r, true)
end

function trim(s)
  return s:match("^%s*(.*)"):match("(.-)%s*$")
end

local json = {}
local kind_of = function(obj)
  if type(obj) ~= "table" then
    return type(obj)
  end
  local i = 1
  do
    do
      for SRD1_5_ in pairs(obj) do
        if obj[i] ~= nil then
          i = i + 1
        else
          return "table"
        end
      end
    end
  end
  if i == 1 then
    do return "table" end
    return
  end
  return "array"
end

local escape_str = function(s)
  local in_char = {
    "\\",
    "\"",
    "/",
    "\b",
    "\f",
    "\n",
    "\r",
    "\t"
  }
  local out_char = {
    "\\",
    "\"",
    "/",
    "b",
    "f",
    "n",
    "r",
    "t"
  }
  do
    do
      for SRD1_6_, SRD1_7_ in ipairs(in_char) do
        s = s:gsub(SRD1_7_, "\\" .. out_char[SRD1_6_])
      end
    end
  end
  return s
end

local skip_delim = function(str, pos, delim, err_if_missing)
  pos = pos + #str:match("^%s*", pos)
  if str:sub(pos, pos) ~= delim then
    if err_if_missing then
      error("Esperado " .. delim .. " posição próxima " .. pos)
    end
    return pos, false
  end
  return pos + 1, true
end

local function parse_str_val(str, pos, val)
  val = val or ""
  local early_end_error = "Fim da entrada encontrado durante a análise da string."
  if pos > #str then
    error(early_end_error)
  end
  local c = str:sub(pos, pos)
  if c == "\"" then
    return val, pos + 1
  end
  if c ~= "\\" then
    return parse_str_val(str, pos + 1, val .. c)
  end
  local esc_map = {
    b = "\b",
    f = "\f",
    n = "\n",
    r = "\r",
    t = "\t"
  }
  local nextc = str:sub(pos + 1, pos + 1)
  if not nextc then
    error(early_end_error)
  end
  return parse_str_val(str, pos + 2, val .. (esc_map[nextc] or nextc))
end

local parse_num_val = function(str, pos)
  local num_str = str:match("^-?%d+%.?%d*[eE]?[+-]?%d*", pos)
  local val = tonumber(num_str)
  if not val then
    error("Erro ao analisar o número na posição " .. pos .. ".")
  end
  return val, pos + #num_str
end

function json.stringify(obj, as_key)
  local s = {}
  local kind = kind_of(obj)
  if kind == "array" then
    if as_key then
      error("Não é possível codificar array como chave.")
    end
    s[#s + 1] = "["
    do
      do
        for SRD1_7_, SRD1_8_ in ipairs(obj) do
          if SRD1_7_ > 1 then
            s[#s + 1] = ", "
          end
          s[#s + 1] = json.stringify(SRD1_8_)
        end
      end
    end
    s[#s + 1] = "]"
  elseif kind == "table" then
    if as_key then
      error("Não é possível codificar a tabela como chave.")
    end
    s[#s + 1] = "{"
    do
      do
        for SRD1_7_, SRD1_8_ in pairs(obj) do
          if #s > 1 then
            s[#s + 1] = ", "
          end
          s[#s + 1] = json.stringify(SRD1_7_, true)
          s[#s + 1] = ":"
          s[#s + 1] = json.stringify(SRD1_8_)
        end
      end
    end
    s[#s + 1] = "}"
  else
    if kind == "string" then
      do return "\"" .. escape_str(obj) .. "\"" end
      return
    end
    if kind == "number" then
      if as_key then
        return "\"" .. tostring(obj) .. "\""
      end
      do return tostring(obj) end
      return
    end
    if kind == "boolean" then
      do return tostring(obj) end
      return
    end
    if kind == "nil" then
      do return "null" end
      return
    end
    error("tipo unjsonificável,: " .. kind .. ".")
  end
  return table.concat(s)
end

json.null = {}
function json.parse(str, pos, end_delim)
  pos = pos or 1
  if pos > #str then
    error("Atingiu o fim inesperado da entrada ")
  end
  local pos = pos + #str:match("^%s*", pos)
  local first = str:sub(pos, pos)
  if first == "{" then
    do
      local obj, key, delim_found = {}, true, true
      pos = pos + 1
      while true do
        key, pos = json.parse(str, pos, "}")
        if key == nil then
          return obj, pos
        end
        if not delim_found then
          error("Vírgula faltando entre os itens do objeto.")
        end
        pos = skip_delim(str, pos, ":", true)
        obj[key], pos = json.parse(str, pos)
        pos, delim_found = skip_delim(str, pos, ",")
      end
    end
    return
  end
  if first == "[" then
    do
      local arr, val, delim_found = {}, true, true
      pos = pos + 1
      while true do
        val, pos = json.parse(str, pos, "]")
        if val == nil then
          return arr, pos
        end
        if not delim_found then
          error("Falta vírgula entre os itens do array.")
        end
        arr[#arr + 1] = val
        pos, delim_found = skip_delim(str, pos, ",")
      end
    end
    return
  end
  if first == "\"" then
    do return parse_str_val(str, pos + 1) end
    return
  end
  if first == "-" or first:match("%d") then
    do return parse_num_val(str, pos) end
    return
  end
  if first == end_delim then
    do return nil, pos + 1 end
    return
  end
  do
    local literals = {
      ["true"] = true,
      ["false"] = false,
      null = json.null
    }
    do
      do
        for SRD1_9_, SRD1_10_ in pairs(literals) do
          local lit_end = pos + #SRD1_9_ - 1
          if str:sub(pos, lit_end) == SRD1_9_ then
            return SRD1_10_, lit_end + 1
          end
        end
      end
    end
    local pos_info_str = "position " .. pos .. ": " .. str:sub(pos, pos + 10)
    error("Sintaxe json inválida começando em " .. pos_info_str)
  end
end

function enc(data, b)
  return (data:gsub(".", function(x)
    local r, b = "", x:byte()
    do
      do
        for SRD1_6_ = 8, 1, -1 do
          r = r .. (b % 2 ^ SRD1_6_ - b % 2 ^ (SRD1_6_ - 1) > 0 and "1" or "0")
        end
      end
    end
    return r
  end
  ) .. "0000"):gsub("%d%d%d?%d?%d?%d?", function(x)
    if #x < 6 then
      return ""
    end
    local c = 0
    do
      do
        for SRD1_5_ = 1, 6 do
          c = c + (x:sub(SRD1_5_, SRD1_5_) == "1" and 2 ^ (6 - SRD1_5_) or 0)
        end
      end
    end
    return b:sub(c + 1, c + 1)
  end
  ) .. ({
    "",
    "??",
    "?"
  })[#data % 3 + 1]
end

function dec(data, b)
  data = string.gsub(data, "[^" .. b .. "=]", "")
  return (data:gsub(".", function(x)
    if x == "?" then
      return ""
    end
    local r, f = "", b:find(x) - 1
    do
      do
        for SRD1_6_ = 6, 1, -1 do
          r = r .. (f % 2 ^ SRD1_6_ - f % 2 ^ (SRD1_6_ - 1) > 0 and "1" or "0")
        end
      end
    end
    return r
  end
  ):gsub("%d%d%d?%d?%d?%d?%d?%d?", function(x)
    if #x ~= 8 then
      return ""
    end
    local c = 0
    do
      do
        for SRD1_5_ = 1, 8 do
          c = c + (x:sub(SRD1_5_, SRD1_5_) == "1" and 2 ^ (8 - SRD1_5_) or 0)
        end
      end
    end
    return string.char(c)
  end
  ))
end

function ehix9(key, data)
  local preData, result
  preData = ""
  result = ""
  local bit_key = bit:charCodeAt(key)
  do
    local c = 0
    local c2 = 1
    while c < #data and not (c >= #data) do
      preData = preData .. string.char(tonumber(string.sub(data, c2, c + 2), 16))
      c = c + 2
      c2 = c2 + 2
    end
  end
  local bit_data = bit:charCodeAt(preData)
  do
    local a = 0
    local b = 0
    while a < #preData do
      if b >= #key then
        b = 0
      end
      a = a + 1
      b = b + 1
      local xor = bit:_xor(bit_data[a], bit_key[b])
      if xor ~= nil and xor < 256 then
        result = result .. string.char(bit:_xor(bit_data[a], bit_key[b]))
      end
    end
  end
  return result
end

function decryptEhi(salt, data)
  data = dec(string.reverse(data), "RkLC2QaVMPYgGJW/A4f7qzDb9e+t6Hr0Zp8OlNyjuxKcTw1o5EIimhBn3UvdSFXs?")
  return ehix9(salt, string.sub(data, 1, #data))
end

function decryptEhil(salt, data)
  data = dec(string.reverse(data), "t6uxKcTwhBn3UvRkLC2QaVM1o5A4f7Hr0Zp8OyjqzDb9e+dSFXsEIimPYgGJW/lN?")
  return ehix9(salt, string.sub(data, 1, #data))
end

function rwmem(Address, SizeOrBuffer)
  assert(Address ~= nil, "[rwmem]: error, endereço fornecido é nulo.")
  _rw = {}
  if type(SizeOrBuffer) == "number" then
    _ = ""
    do
      do
        for SRD1_5_ = 1, SizeOrBuffer do
          _rw[SRD1_5_] = {
            address = Address - 1 + SRD1_5_,
            flags = gg.TYPE_BYTE
          }
        end
      end
    end
    do
      do
        for SRD1_5_, SRD1_6_ in ipairs(gg.getValues(_rw)) do
          if SRD1_6_.value == 0 and limit == true then
            return _
          end
          _ = _ .. string.format("%02X", SRD1_6_.value & 255)
        end
      end
    end
    return _
  end
  Byte = {}
  SizeOrBuffer:gsub("..", function(x)
    Byte[#Byte + 1] = x
    _rw[#Byte] = {
      address = Address - 1 + #Byte,
      flags = gg.TYPE_BYTE,
      value = x .. "h"
    }
  end
  )
  gg.setValues(_rw)
end

function hexdecode(hex)
  return (hex:gsub("%x%x", function(digits)
    return string.char(tonumber(digits, 16))
  end
  ))
end

function hexencode(str)
  return (str:gsub(".", function(char)
    return string.format("%2x", char:byte())
  end
  ))
end

function Dec2Hex(nValue)
  nHexVal = string.format("%X", nValue)
  sHexVal = nHexVal .. ""
  return sHexVal
end

function ToInteger(number)
  return math.floor(tonumber(number) or error("Não foi possível transmitir '" .. tostring(number) .. "' enumerar.'"))
end

function save(data)
  io.open(gg.EXT_STORAGE .. "/Config Aqui.txt", "w"):write(data)
  gg.toast("✅Configuração Encontrada!")
end

function save2(data)
  io.open(gg.EXT_STORAGE .. "/Config Aqui.txt", "w"):write(json.stringify(data))
  gg.toast("✅Configuração Encontrada!")
end

function v2json(data)
  io.open(gg.EXT_STORAGE .. "/Config V2ray.txt", "w"):write(data)
end

function saveEhi(data)
  io.open(gg.EXT_STORAGE .. "/Config Ehi.txt", "w"):write(data)
end

local ehi, configSalt
local Http = {}
function Http:New(data)
  ehi = data
  if data.configSalt == "" then
    configSalt = "EVZJNI"
  else
    configSalt = data.configSalt
  end
end

function Http:Dec(key)
  if ehi.configVersionCode > 10000 then
    if ehi[key] then
      do return decryptEhil(configSalt, ehi[key]) end
      return
    end
    do return "N/A" end
    return
  end
  if ehi[key] then
    do return decryptEhi(configSalt, ehi[key]) end
    return
  end
  return "N/A"
end

function Http:TunnelType()
  if ehi.tunnelType == "ssl_proxy_payload_ssh" then
    do return "SSH ➔ TLS/SSL + Proxy ➔ Custom Payload" end
    return
  end
  if ehi.tunnelType == "http_obfs_shadowsocks" then
    do return "HTTP (Obfs) ➔ Shadowsocks" end
    return
  end
  if ehi.tunnelType == "ssl_ssh" then
    do return "SSL/TLS ➔ SSH" end
    return
  end
  if ehi.tunnelType == "proxy_payload_ssh" then
    do return "SSH ➔ HTTP Proxy ➔ Custom Payload" end
    return
  end
  if ehi.tunnelType == "proxy_ssh" then
    do return "SSH ➔ HTTP Proxy" end
    return
  end
  if ehi.tunnelType == "direct_ssh" then
    do return "SSH (Direct)" end
    return
  end
  if ehi.tunnelType == "direct_shadowsocks" then
    do return "Shadowsocks (Direct)" end
    return
  end
  if ehi.tunnelType == "dnstt_ssh" then
    do return "DNS ➔ DNSTT ➔ SSH" end
    return
  end
  if ehi.tunnelType == "ssl_proxy_ssh" then
    do return "HTTP Proxy ➔ SSL ➔ SSH" end
    return
  end
  if ehi.tunnelType == "ssl_shadowsocks" then
    do return "SSL/TLS (Stunnel) ➔ Shadowsocks" end
    return
  end
  if ehi.tunnelType == "tls_obfs_shadowsocks" then
    do return "SSL/TLS (Obfs) ➔ Shadowsocks" end
    return
  end
  if ehi.tunnelType == "proxy_shadowsocks" then
    do return "HTTP Proxy ➔ Shadowsocks" end
    return
  end
  if ehi.tunnelType == "proxy_payload_shadowsocks" then
    do return "HTTP Proxy ➔ Shadowsocks (Custom Payload)" end
    return
  end
  if ehi.v2ray_all_settings == "v2ray_all_settings" then
    do return "V2Ray" end
    return
  end
  if ehi.tunnelType == "direct_dnsurgent" then
    do return "Direct Dnsurgent" end
    return
  end
  if ehi.tunnelType == "sni_host_port" then
    do return "SSL/TLS" end
    return
  end
  if ehi.tunnelType == "direct_v2r_vmess" then
    do return "V2Ray" end
    return
  end
  if ehi.tunnelType == "v2rRawJson" then
    do return "v2json ➔ V2ray" end
    return
  end
  if ehi.tunnelType == "lock_all" then
    do return "lock ➔ V2ray" end
    return
  end
  if ehi.tunnelType == "unknown" then
    do return "HTTP Proxy ➔ SSH (Custom Payload)" end
    return
  end
  if ehi.tunnelType == "http_obfs" then
    do return "Shadowsocks ➔ HTTP Obfs" end
    return
  end
  if ehi.tunnelType == "direct_payload_ssh" then
    do return "SSH ➔ Direct ➔ Custom Payload" end
    return
  end
  return ehi.tunnelType
end

local includes = function(tab, val)
  do
    do
      for SRD1_5_, SRD1_6_ in ipairs(tab) do
        if SRD1_6_ == val then
          return true
        end
      end
    end
  end
  return false
end

local ssh_mode = {
  "ssl_proxy_payload_ssh",
  "direct_payload_ssh",
  "proxy_payload_ssh",
  "proxy_ssh",
  "dnstt_ssh",
  "ssl_shadowsocks",
  "tls_obfs_shadowsocks",
  "proxy_shadowsocks",
  "proxy_payload_shadowsocks",
  "direct_dnsurgent",
  "direct_v2r_vmess",
  "unknown",
  "v2rRawJson",
  "v2ray_all_settings",
  "http_obfs_shadowsocks",
  "direct_shadowsocks",
  "ssl_proxy_ssh",
  "direct_ssh",
  "sni_host_port",
  "ssl_ssh",
  "lock_all",
  "http_obfs"
}
function parseHttpInjector(data)
  local jsonData = json.parse(hexdecode(data))
  gg.toast("tá sentindo a energia?")
  print("@EhisOpeNer / @netfree080\n")
  Http:New(jsonData)
  if includes(ssh_mode, ehi.tunnelType) then
    message = ""
    if ehi.overwriteServerData ~= "" then
      serverData = json.parse(ehi.overwriteServerData)
      message = message .. "Substituir dados do servidor: " .. ehi.overwriteServerData .. [[


]]
      message = message .. "Sobrescrever porta proxy do servidor: " .. ehi.overwriteServerProxyPort .. [[


]]
      message = message .. "Sobrescrever Tipo Servidor: " .. ehi.overwriteServerType .. [[


]]
      message = message .. "Servidor Evozi: " .. serverData.name .. " (" .. serverData.ip .. [[
)

]]
    else
      message = message .. "SSH Host: " .. Http:Dec("host") .. "\n"
      message = message .. "Porta: " .. ehi.port .. "\n"
      message = message .. "Usuário: " .. Http:Dec("user") .. "\n"
      message = message .. "Senha: " .. Http:Dec("password") .. [[


]]
 end
    if ehi.remoteProxy then
      if ehi.remoteProxyUsername and ehi.remoteProxyUsername ~= "" then
        message = message .. "Proxy: " .. Http:Dec("remoteProxy") .. "\n"
        message = message .. "Usuário e Senha Proxy Auth: " .. Http:Dec("remoteProxyUsername") .. ":" .. Http:Dec("remoteProxyPassword") .. [[


]]
      end
      elseif ehi.overwriteServerData ~= "" then
      if ehi.tunnelType == "proxy_payload_ssh" then
    message = message .. "Proxy: " .. Http:Dec("remoteProxy") .. [[


]]
end
      elseif ehi.overwriteServerData ~= "" then
      if ehi.tunnelType == "ssl_proxy_payload_ssh" then
    message = message .. "Proxy: " .. Http:Dec("remoteProxy") .. [[


]]
message = message .. "SNI: " .. Http:Dec("sniHostname") .. [[


]]
end
      elseif ehi.overwriteServerData ~= "" then
      if ehi.tunnelType == "proxy_ssh" then
    message = message .. "Proxy: " .. Http:Dec("remoteProxy") .. [[


]]
      end
    elseif ehi.overwriteServerData ~= "" then
    if ehi.tunnelType == "ssl_ssh" then
      message = message .. "SNI: " .. Http:Dec("sniHostname") .. [[


]]
end
    elseif ehi.overwriteServerData ~= "" then
    if ehi.tunnelType == "sni_host_port" then
      message = message .. "SNI: " .. Http:Dec("sniHostname") .. [[


]]
    end
    elseif ehi.tunnelType == "direct_shadowsocks" then
      message = message .. "HTTP Obfs Settings: " .. Http:Dec("httpObfsSettings") .. [[


]]
      message = message .. "Shadowsocks Host: " .. Http:Dec("shadowsocksHost") .. "\n"
      message = message .. "Shadowsocks Porta: " .. ehi.shadowsocksPort .. "\n"
      message = message .. "Shadowsocks Senha: " .. Http:Dec("shadowsocksPassword") .. [[


]]
      message = message .. "EncryptMethod: " .. string.upper(ehi.shadowsocksEncryptionMethod) .. [[


]]
      message = message .. "V2rMuxConcurrency: " .. Http:Dec("v2rMuxConcurrency") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "ssl_shadowsocks" then
    message = message .. "Shadowsocks Host: " .. Http:Dec("shadowsocksHost") .. "\n"
      message = message .. "Shadowsocks Porta: " .. ehi.shadowsocksPort .. "\n"
      message = message .. "Shadowsocks Senha: " .. Http:Dec("shadowsocksPassword") .. [[


]]
      message = message .. "EncryptMethod: " .. string.upper(ehi.shadowsocksEncryptionMethod) .. [[


]]
      message = message .. "SNI: " .. Http:Dec("sniHostname") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "direct_payload_ssh" then
      message = message .. "Payload: " .. Http:Dec("payload") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "ssl_proxy_ssh" then
    message = message .. "Proxy: " .. Http:Dec("remoteProxy") .. [[


]]
message = message .. "SNI: " .. Http:Dec("sniHostname") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "sni_host_port" then
    message = message .. "SNI: " .. Http:Dec("sniHostname") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "ssl_proxy_payload_ssh" then
    message = message .. "Proxy: " .. Http:Dec("remoteProxy") .. [[


]]
message = message .. "SNI: " .. Http:Dec("sniHostname") .. [[


]]
      message = message .. "Payload: " .. Http:Dec("payload") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "proxy_payload_ssh" then
    message = message .. "Proxy: " .. Http:Dec("remoteProxy") .. [[


]]
      message = message .. "Payload: " .. Http:Dec("payload") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "proxy_ssh" then
    message = message .. "Proxy: " .. Http:Dec("remoteProxy") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "ssl_ssh" then
    message = message .. "SNI: " .. Http:Dec("sniHostname") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "direct_ssh" then
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "direct_v2r_vmess" then
      message = "v2rRawJson: " .. Http:Dec("v2rRawJson") .. [[


]]
      if ehi.v2rRawJson then
        v2json = Http:Dec("v2rRawJson")
        print(message)
        saveEhi(v2json)
        gg.copyText(v2json, false)
        gg.toast("copiou, farinha?")
        return
      end
      message = message .. "User Alter ID: " .. Http:Dec("v2rAlterId") .. "\n"
      message = message .. "V2Ray Host: " .. Http:Dec("v2rHost") .. "\n"
      message = message .. "v2rKcpHeaderType: " .. Http:Dec("v2rKcpHeaderType") .. "\n"
      message = message .. "v2rMuxConcurrency: " .. Http:Dec("v2rMuxConcurrency") .. "\n"
      message = message .. "v2rPassword: " .. Http:Dec("v2rPassword") .. "\n"
      message = message .. "v2rNetwork: " .. Http:Dec("v2rNetwork") .. "\n"
      message = message .. "v2rPort: " .. Http:Dec("v2rPort") .. "\n"
      message = message .. "v2rProtocol: " .. Http:Dec("v2rProtocol") .. "\n"
      message = message .. "v2rH2Host: " .. Http:Dec("v2rH2Host") .. "\n"
      message = message .. "v2rH2Path: " .. Http:Dec("v2rH2Path") .. "\n"
      message = message .. "v2rQuicHeaderType: " .. Http:Dec("v2rQuicHeaderType") .. "\n"
      message = message .. "v2rTcpHeaderType: " .. Http:Dec("v2rTcpHeaderType") .. "\n"
      message = message .. "v2rUserId: " .. Http:Dec("v2rUserId") .. "\n"
      message = message .. "v2rTlsSni: " .. Http:Dec("v2rTlsSni") .. "\n"
      message = message .. "v2rVlessSecurity: " .. Http:Dec("v2rVlessSecurity") .. "\n"
      message = message .. "v2rVmessSecurity: " .. Http:Dec("v2rVmessSecurity") .. "\n"
      message = message .. "v2rSsSecurity: " .. Http:Dec("v2rSsSecurity") .. "\n"
      message = message .. "v2rQuicSecurity: " .. Http:Dec("v2rQuicSecurity") .. "\n"
      message = message .. "Header Ws: " .. Http:Dec("v2rWsHeader") .. "\n"
      message = message .. "v2rWsPath: " .. Http:Dec("v2rWsPath") .. [[


]]
      message = message .. "v2rCoreType: " .. Http:Dec("v2rCoreType") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "dnstt_ssh" then
      message = message .. "Tipo de DNS: " .. ehi.dnsType .. "\n"
      message = message .. "DNS Resolver Address: " .. Http:Dec("dnsttDnsResolverAddr") .. "\n"
      message = message .. "DNSTT Nameserver: " .. Http:Dec("dnsttNameserver") .. "\n"
      message = message .. "DNSTT Public Key: " .. Http:Dec("dnsttPublicKey") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "tls_obfs_shadowsocks" then
      message = message .. "HTTP Obfs Settings: " .. Http:Dec("httpObfsSettings") .. [[


]]
      message = message .. "Shadowsocks Host: " .. Http:Dec("shadowsocksHost") .. "\n"
      message = message .. "Shadowsocks Porta: " .. ehi.shadowsocksPort .. "\n"
      message = message .. "Shadowsocks Senha: " .. Http:Dec("shadowsocksPassword") .. [[


]]
      message = message .. "SNI: " .. Http:Dec("sniHostname") .. [[


]]
      message = message .. "EncryptMethod: " .. string.upper(ehi.shadowsocksEncryptionMethod) .. [[


]]
      message = message .. "V2rMuxConcurrency: " .. Http:Dec("v2rMuxConcurrency") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "http_obfs_shadowsocks" then
      message = message .. "HTTP Obfs Settings: " .. Http:Dec("httpObfsSettings") .. [[


]]
      message = message .. "Shadowsocks Host: " .. Http:Dec("shadowsocksHost") .. "\n"
      message = message .. "Shadowsocks Porta: " .. ehi.shadowsocksPort .. "\n"
      message = message .. "Shadowsocks Senha: " .. Http:Dec("shadowsocksPassword") .. [[


]]
      message = message .. "EncryptMethod: " .. string.upper(ehi.shadowsocksEncryptionMethod) .. [[


]]
      message = message .. "V2rMuxConcurrency: " .. Http:Dec("v2rMuxConcurrency") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    gg.copyText(message, false)
    gg.toast(message .. [[

copiou, farinha?]])
    print(message)
    saveEhi(message)
  end
  os.exit()
end

function ehievozi()
  limit = true
  gg.clearResults()
  gg.setVisible(false)
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.searchNumber("h 7B 22 63 6F 6E 66 69 67 45 78 70 69 72 79 54 69 6D 65 73 74", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: configExpiryTimest")
    ehi_2 = true
  end
  if ehi_2 then
    gg.searchNumber("h 7B 22 63 6F 6E 66 69 67 49 64 65 6E 74 69 66 69 65 72 22 3A", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌❌Configuração Não Encontrada: configIdentifier")
      print([[

calma barboleta]])
      print("\nImporte o Arquivo Novamente, Espere 3 Segundos e Inicie o Script da Diversão\n\n")
      os.exit()
    end
  end
  gg.searchNumber("h7B", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1000)
  readedMem = rwmem(r[1].address, 40000)
  save(hexdecode(readedMem))
  do
    do
      for SRD1_5_, SRD1_6_ in ipairs(r) do
        r[SRD1_5_].flags = gg.TYPE_FLOAT
        r[SRD1_5_].value = "1000"
      end
    end
  end
  gg.setValues(r)
  gg.clearResults()
  parseHttpInjector(readedMem)
end
  
if app == "com.evozi.injector" then
  ehievozi()
elseif app == "com.evozi.injector.lite" then
  ehievozi()
else
  gg.toast("@netfree080")
  print("\n❌Seu aplicativo não é compatível\n\n")
end
gg.clearResults()
os.exit()
pcall(load(ehi))
prima()
end

function x9C()

limit = false
targetInfo = gg.getTargetInfo()
app = targetInfo.packageName
local utf8 = {}
local bit = {
  data32 = {}
}
do
  do
    for SRD1_5_ = 1, 32 do
      bit.data32[SRD1_5_] = 2 ^ (32 - SRD1_5_)
    end
  end
end
local toby = string.byte
function utf8.charbytes(s, i)
  i = i or 1
  local c = string.byte(s, i)
  if c > 0 and c <= 127 then
    do return 1 end
    return
  end
  if c >= 194 and c <= 223 then
    do return 2 end
    return
  end
  if c >= 224 and c <= 239 then
    do return 3 end
    return
  end
  if c >= 240 and c <= 244 then
    return 4
  end
  return 1
end

local ded
function bit:d2b(arg)
  if arg == nil then
    return
  end
  local tr, c = {}, arg < 0
  if c then
    arg = 0 - arg
  end
  do
    do
      for SRD1_7_ = 1, 32 do
        if arg >= self.data32[SRD1_7_] then
          tr[SRD1_7_] = 1
          arg = arg - self.data32[SRD1_7_]
        else
          tr[SRD1_7_] = 0
        end
      end
    end
  end
  if c then
    tr = self:_bnot(tr)
    tr = self:b2d(tr) + 1
    tr = self:d2b(tr)
  end
  return tr
end

function bit:b2d(arg, neg)
  local nr = 0
  if arg[1] == 1 and neg == true then
    arg = self:_bnot(arg)
    nr = self:b2d(arg) + 1
    nr = 0 - nr
  else
    do
      for SRD1_7_ = 1, 32 do
        if arg[SRD1_7_] == 1 then
          nr = nr + 2 ^ (32 - SRD1_7_)
        end
      end
    end
  end
  return nr
end

function bit:_and(a, b)
  local op1 = self:d2b(a)
  local op2 = self:d2b(b)
  local r = {}
  do
    do
      for SRD1_9_ = 1, 32 do
        if op1[SRD1_9_] == 1 and op2[SRD1_9_] == 1 then
          r[SRD1_9_] = 1
        else
          r[SRD1_9_] = 0
        end
      end
    end
  end
  return self:b2d(r, true)
end

function bit:_or(a, b)
  local op1 = self:d2b(a)
  local op2 = self:d2b(b)
  local r = {}
  do
    do
      for SRD1_9_ = 1, 32 do
        if op1[SRD1_9_] == 1 or op2[SRD1_9_] == 1 then
          r[SRD1_9_] = 1
        else
          r[SRD1_9_] = 0
        end
      end
    end
  end
  return self:b2d(r, true)
end

function bit:_xor(a, b)
  local op1 = self:d2b(a)
  if op1 == nil then
    return nil
  end
  local op2 = self:d2b(b)
  if op2 == nil then
    return nil
  end
  local r = {}
  do
    do
      for SRD1_9_ = 1, 32 do
        if op1[SRD1_9_] == op2[SRD1_9_] then
          r[SRD1_9_] = 0
        else
          r[SRD1_9_] = 1
        end
      end
    end
  end
  return self:b2d(r, true)
end

local switch = {
  [1] = function(s, pos)
    local c1 = toby(s, pos)
    return c1
  end
  ,
  [2] = function(s, pos)
    local c1 = toby(s, pos)
    local c2 = toby(s, pos + 1)
    local int1 = bit:_and(31, c1)
    local int2 = bit:_and(63, c2)
    return bit:_or(bit:_lshift(int1, 6), int2)
  end
  ,
  [3] = function(s, pos)
    local c1 = toby(s, pos)
    local c2 = toby(s, pos + 1)
    local c3 = toby(s, pos + 2)
    local int1 = bit:_and(15, c1)
    local int2 = bit:_and(63, c2)
    local int3 = bit:_and(63, c3)
    local o2 = bit:_or(bit:_lshift(int1, 12), bit:_lshift(int2, 6))
    local dt = bit:_or(o2, int3)
    return dt
  end
  ,
  [4] = function(s, pos)
    local c1 = toby(s, pos)
    local c2 = toby(s, pos + 1)
    local c3 = toby(s, pos + 2)
    local c4 = toby(s, pos + 3)
    local int1 = bit:_and(15, c1)
    local int2 = bit:_and(63, c2)
    local int3 = bit:_and(63, c3)
    local int4 = bit:_and(63, c4)
    local o2 = bit:_or(bit:_lshift(int1, 18), bit:_lshift(int2, 12))
    local o3 = bit:_or(o2, bit:_lshift(int3, 6))
    local o4 = bit:_or(o3, int4)
    return o4
  end
  
}
function bit:_bnot(op1)
  local r = {}
  do
    do
      for SRD1_6_ = 1, 32 do
        if op1[SRD1_6_] == 1 then
          r[SRD1_6_] = 0
        else
          r[SRD1_6_] = 1
        end
      end
    end
  end
  return r
end

function bit:_not(a)
  local op1 = self:d2b(a)
  local r = self:_bnot(op1)
  return self:b2d(r, true)
end

function bit:charCodeAt(s)
  local pos, int, H, L = 1, 0, 0, 0
  local slen = string.len(s)
  local allByte = {}
  while pos <= slen do
    local tLen = utf8.charbytes(s, pos)
    if tLen >= 1 and tLen <= 4 then
      if tLen == 4 then
        int = switch[4](s, pos)
        H = math.floor((int - 65536) / 1024) + 55296
        L = (int - 65536) % 1024 + 56320
        table.insert(allByte, H)
        table.insert(allByte, L)
      else
        int = switch[tLen](s, pos)
        table.insert(allByte, int)
      end
    end
    pos = pos + tLen
  end
  return allByte
end

function bit:_rshift(a, n)
  local r = 0
  if a < 0 then
    r = 0 - self:_frshift(0 - a, n)
  elseif a >= 0 then
    r = self:_frshift(a, n)
  end
  return r
end

function bit:_frshift(a, n)
  local op1 = self:d2b(a)
  local r = self:d2b(0)
  local left = 32 - n
  if n < 32 and n > 0 then
    do
      for SRD1_9_ = left, 1, -1 do
        r[SRD1_9_ + n] = op1[SRD1_9_]
      end
    end
  end
  return self:b2d(r)
end

function bit:_lshift(a, n)
  local op1 = self:d2b(a)
  local r = self:d2b(0)
  if n < 32 and n > 0 then
    do
      for SRD1_8_ = n, 31 do
        r[SRD1_8_ - n + 1] = op1[SRD1_8_ + 1]
      end
    end
  end
  return self:b2d(r, true)
end

function trim(s)
  return s:match("^%s*(.*)"):match("(.-)%s*$")
end

local json = {}
local kind_of = function(obj)
  if type(obj) ~= "table" then
    return type(obj)
  end
  local i = 1
  do
    do
      for SRD1_5_ in pairs(obj) do
        if obj[i] ~= nil then
          i = i + 1
        else
          return "table"
        end
      end
    end
  end
  if i == 1 then
    do return "table" end
    return
  end
  return "array"
end

local escape_str = function(s)
  local in_char = {
    "\\",
    "\"",
    "/",
    "\b",
    "\f",
    "\n",
    "\r",
    "\t"
  }
  local out_char = {
    "\\",
    "\"",
    "/",
    "b",
    "f",
    "n",
    "r",
    "t"
  }
  do
    do
      for SRD1_6_, SRD1_7_ in ipairs(in_char) do
        s = s:gsub(SRD1_7_, "\\" .. out_char[SRD1_6_])
      end
    end
  end
  return s
end

local skip_delim = function(str, pos, delim, err_if_missing)
  pos = pos + #str:match("^%s*", pos)
  if str:sub(pos, pos) ~= delim then
    if err_if_missing then
      error("Esperado " .. delim .. " posição próxima " .. pos)
    end
    return pos, false
  end
  return pos + 1, true
end

local function parse_str_val(str, pos, val)
  val = val or ""
  local early_end_error = "Fim da entrada encontrado durante a análise da string."
  if pos > #str then
    error(early_end_error)
  end
  local c = str:sub(pos, pos)
  if c == "\"" then
    return val, pos + 1
  end
  if c ~= "\\" then
    return parse_str_val(str, pos + 1, val .. c)
  end
  local esc_map = {
    b = "\b",
    f = "\f",
    n = "\n",
    r = "\r",
    t = "\t"
  }
  local nextc = str:sub(pos + 1, pos + 1)
  if not nextc then
    error(early_end_error)
  end
  return parse_str_val(str, pos + 2, val .. (esc_map[nextc] or nextc))
end

local parse_num_val = function(str, pos)
  local num_str = str:match("^-?%d+%.?%d*[eE]?[+-]?%d*", pos)
  local val = tonumber(num_str)
  if not val then
    error("Erro ao analisar o número na posição " .. pos .. ".")
  end
  return val, pos + #num_str
end

function json.stringify(obj, as_key)
  local s = {}
  local kind = kind_of(obj)
  if kind == "array" then
    if as_key then
      error("Não é possível codificar array como chave.")
    end
    s[#s + 1] = "["
    do
      do
        for SRD1_7_, SRD1_8_ in ipairs(obj) do
          if SRD1_7_ > 1 then
            s[#s + 1] = ", "
          end
          s[#s + 1] = json.stringify(SRD1_8_)
        end
      end
    end
    s[#s + 1] = "]"
  elseif kind == "table" then
    if as_key then
      error("Não é possível codificar a tabela como chave.")
    end
    s[#s + 1] = "{"
    do
      do
        for SRD1_7_, SRD1_8_ in pairs(obj) do
          if #s > 1 then
            s[#s + 1] = ", "
          end
          s[#s + 1] = json.stringify(SRD1_7_, true)
          s[#s + 1] = ":"
          s[#s + 1] = json.stringify(SRD1_8_)
        end
      end
    end
    s[#s + 1] = "}"
  else
    if kind == "string" then
      do return "\"" .. escape_str(obj) .. "\"" end
      return
    end
    if kind == "number" then
      if as_key then
        return "\"" .. tostring(obj) .. "\""
      end
      do return tostring(obj) end
      return
    end
    if kind == "boolean" then
      do return tostring(obj) end
      return
    end
    if kind == "nil" then
      do return "null" end
      return
    end
    error("tipo unjsonificável,: " .. kind .. ".")
  end
  return table.concat(s)
end

json.null = {}
function json.parse(str, pos, end_delim)
  pos = pos or 1
  if pos > #str then
    error("Atingiu o fim inesperado da entrada ")
  end
  local pos = pos + #str:match("^%s*", pos)
  local first = str:sub(pos, pos)
  if first == "{" then
    do
      local obj, key, delim_found = {}, true, true
      pos = pos + 1
      while true do
        key, pos = json.parse(str, pos, "}")
        if key == nil then
          return obj, pos
        end
        if not delim_found then
          error("Vírgula faltando entre os itens do objeto.")
        end
        pos = skip_delim(str, pos, ":", true)
        obj[key], pos = json.parse(str, pos)
        pos, delim_found = skip_delim(str, pos, ",")
      end
    end
    return
  end
  if first == "[" then
    do
      local arr, val, delim_found = {}, true, true
      pos = pos + 1
      while true do
        val, pos = json.parse(str, pos, "]")
        if val == nil then
          return arr, pos
        end
        if not delim_found then
          error("Falta vírgula entre os itens do array.")
        end
        arr[#arr + 1] = val
        pos, delim_found = skip_delim(str, pos, ",")
      end
    end
    return
  end
  if first == "\"" then
    do return parse_str_val(str, pos + 1) end
    return
  end
  if first == "-" or first:match("%d") then
    do return parse_num_val(str, pos) end
    return
  end
  if first == end_delim then
    do return nil, pos + 1 end
    return
  end
  do
    local literals = {
      ["true"] = true,
      ["false"] = false,
      null = json.null
    }
    do
      do
        for SRD1_9_, SRD1_10_ in pairs(literals) do
          local lit_end = pos + #SRD1_9_ - 1
          if str:sub(pos, lit_end) == SRD1_9_ then
            return SRD1_10_, lit_end + 1
          end
        end
      end
    end
    local pos_info_str = "position " .. pos .. ": " .. str:sub(pos, pos + 10)
    error("Sintaxe json inválida começando em " .. pos_info_str)
  end
end

function enc(data, b)
  return (data:gsub(".", function(x)
    local r, b = "", x:byte()
    do
      do
        for SRD1_6_ = 8, 1, -1 do
          r = r .. (b % 2 ^ SRD1_6_ - b % 2 ^ (SRD1_6_ - 1) > 0 and "1" or "0")
        end
      end
    end
    return r
  end
  ) .. "0000"):gsub("%d%d%d?%d?%d?%d?", function(x)
    if #x < 6 then
      return ""
    end
    local c = 0
    do
      do
        for SRD1_5_ = 1, 6 do
          c = c + (x:sub(SRD1_5_, SRD1_5_) == "1" and 2 ^ (6 - SRD1_5_) or 0)
        end
      end
    end
    return b:sub(c + 1, c + 1)
  end
  ) .. ({
    "",
    "??",
    "?"
  })[#data % 3 + 1]
end

function dec(data, b)
  data = string.gsub(data, "[^" .. b .. "=]", "")
  return (data:gsub(".", function(x)
    if x == "?" then
      return ""
    end
    local r, f = "", b:find(x) - 1
    do
      do
        for SRD1_6_ = 6, 1, -1 do
          r = r .. (f % 2 ^ SRD1_6_ - f % 2 ^ (SRD1_6_ - 1) > 0 and "1" or "0")
        end
      end
    end
    return r
  end
  ):gsub("%d%d%d?%d?%d?%d?%d?%d?", function(x)
    if #x ~= 8 then
      return ""
    end
    local c = 0
    do
      do
        for SRD1_5_ = 1, 8 do
          c = c + (x:sub(SRD1_5_, SRD1_5_) == "1" and 2 ^ (8 - SRD1_5_) or 0)
        end
      end
    end
    return string.char(c)
  end
  ))
end

function ehix9(key, data)
  local preData, result
  preData = ""
  result = ""
  local bit_key = bit:charCodeAt(key)
  do
    local c = 0
    local c2 = 1
    while c < #data and not (c >= #data) do
      preData = preData .. string.char(tonumber(string.sub(data, c2, c + 2), 16))
      c = c + 2
      c2 = c2 + 2
    end
  end
  local bit_data = bit:charCodeAt(preData)
  do
    local a = 0
    local b = 0
    while a < #preData do
      if b >= #key then
        b = 0
      end
      a = a + 1
      b = b + 1
      local xor = bit:_xor(bit_data[a], bit_key[b])
      if xor ~= nil and xor < 256 then
        result = result .. string.char(bit:_xor(bit_data[a], bit_key[b]))
      end
    end
  end
  return result
end

function Ehi(salt, data)
  data = dec(string.reverse(data), "RkLC2QaVMPYgGJW/A4f7qzDb9e+t6Hr0Zp8OlNyjuxKcTw1o5EIimhBn3UvdSFXs?")
  return ehix9(salt, string.sub(data, 1, #data))
end

function Ehil(salt, data)
  data = dec(string.reverse(data), "t6uxKcTwhBn3UvRkLC2QaVM1o5A4f7Hr0Zp8OyjqzDb9e+dSFXsEIimPYgGJW/lN?")
  return ehix9(salt, string.sub(data, 1, #data))
end

function rwmem(Address, SizeOrBuffer)
  assert(Address ~= nil, "[rwmem]: error, endereço fornecido é nulo.")
  _rw = {}
  if type(SizeOrBuffer) == "number" then
    _ = ""
    do
      do
        for SRD1_5_ = 1, SizeOrBuffer do
          _rw[SRD1_5_] = {
            address = Address - 1 + SRD1_5_,
            flags = gg.TYPE_BYTE
          }
        end
      end
    end
    do
      do
        for SRD1_5_, SRD1_6_ in ipairs(gg.getValues(_rw)) do
          if SRD1_6_.value == 0 and limit == true then
            return _
          end
          _ = _ .. string.format("%02X", SRD1_6_.value & 255)
        end
      end
    end
    return _
  end
  Byte = {}
  SizeOrBuffer:gsub("..", function(x)
    Byte[#Byte + 1] = x
    _rw[#Byte] = {
      address = Address - 1 + #Byte,
      flags = gg.TYPE_BYTE,
      value = x .. "h"
    }
  end
  )
  gg.setValues(_rw)
end

function hexdecode(hex)
  return (hex:gsub("%x%x", function(digits)
    return string.char(tonumber(digits, 16))
  end
  ))
end

function hexencode(str)
  return (str:gsub(".", function(char)
    return string.format("%2x", char:byte())
  end
  ))
end

function Dec2Hex(nValue)
  nHexVal = string.format("%X", nValue)
  sHexVal = nHexVal .. ""
  return sHexVal
end

function ToInteger(number)
  return math.floor(tonumber(number) or error("Não foi possível transmitir '" .. tostring(number) .. "' enumerar.'"))
end

function save(data)
  io.open(gg.EXT_STORAGE .. "/Config Aqui.txt", "w"):write(data)
  gg.toast("Configuração Encontrada!")
end

function save2(data)
  io.open(gg.EXT_STORAGE .. "/Config Aqui.txt", "w"):write(json.stringify(data))
  gg.toast("Configuração Encontrada!")
end

function hc(data)
  io.open(gg.EXT_STORAGE .. "/hc.txt", "w"):write(data)
  gg.toast("Configuração Encontrada!")
end

function v2json(data)
  io.open(gg.EXT_STORAGE .. "/v2ray.txt", "w"):write(data)
end

function saveEhi(data)
  io.open(gg.EXT_STORAGE .. "/ehi.txt", "w"):write(data)
end

local ehi, configSalt
local Http = {}
function Http:New(data)
  ehi = data
  if data.configSalt == "" then
    configSalt = "EVZJNI"
  else
    configSalt = data.configSalt
  end
end

function Http:Dec(key)
  if ehi.configVersionCode > 10000 then
    if ehi[key] then
      do return Ehil(configSalt, ehi[key]) end
      return
    end
    do return "N/A" end
    return
  end
  if ehi[key] then
    do return Ehi(configSalt, ehi[key]) end
    return
  end
  return "N/A"
end

function Http:TunnelType()
  if ehi.tunnelType == "ssl_proxy_payload_ssh" then
    do return "SSH ➔ TLS/SSL + Proxy ➔ Custom Payload" end
    return
  end
  if ehi.tunnelType == "http_obfs_shadowsocks" then
    do return "HTTP (Obfs) ➔ Shadowsocks" end
    return
  end
  if ehi.tunnelType == "ssl_ssh" then
    do return "SSL/TLS ➔ SSH" end
    return
  end
  if ehi.tunnelType == "proxy_payload_ssh" then
    do return "SSH ➔ HTTP Proxy ➔ Custom Payload" end
    return
  end
  if ehi.tunnelType == "proxy_ssh" then
    do return "SSH ➔ HTTP Proxy" end
    return
  end
  if ehi.tunnelType == "direct_ssh" then
    do return "SSH (Direct)" end
    return
  end
  if ehi.tunnelType == "direct_shadowsocks" then
    do return "Shadowsocks (Direct)" end
    return
  end
  if ehi.tunnelType == "dnstt_ssh" then
    do return "DNS ➔ DNSTT ➔ SSH" end
    return
  end
  if ehi.tunnelType == "ssl_proxy_ssh" then
    do return "HTTP Proxy ➔ SSL ➔ SSH" end
    return
  end
  if ehi.tunnelType == "ssl_shadowsocks" then
    do return "SSL/TLS (Stunnel) ➔ Shadowsocks" end
    return
  end
  if ehi.tunnelType == "tls_obfs_shadowsocks" then
    do return "SSL/TLS (Obfs) ➔ Shadowsocks" end
    return
  end
  if ehi.tunnelType == "proxy_shadowsocks" then
    do return "HTTP Proxy ➔ Shadowsocks" end
    return
  end
  if ehi.tunnelType == "proxy_payload_shadowsocks" then
    do return "HTTP Proxy ➔ Shadowsocks (Custom Payload)" end
    return
  end
  if ehi.v2ray_all_settings == "v2ray_all_settings" then
    do return "V2Ray" end
    return
  end
  if ehi.tunnelType == "direct_dnsurgent" then
    do return "Direct Dnsurgent" end
    return
  end
  if ehi.tunnelType == "sni_host_port" then
    do return "SSL/TLS" end
    return
  end
  if ehi.tunnelType == "direct_v2r_vmess" then
    do return "V2Ray" end
    return
  end
  if ehi.tunnelType == "v2rRawJson" then
    do return "v2json ➔ V2ray" end
    return
  end
  if ehi.tunnelType == "lock_all" then
    do return "lock ➔ V2ray" end
    return
  end
  if ehi.tunnelType == "unknown" then
    do return "HTTP Proxy ➔ SSH (Custom Payload)" end
    return
  end
  if ehi.tunnelType == "http_obfs" then
    do return "Shadowsocks ➔ HTTP Obfs" end
    return
  end
  if ehi.tunnelType == "direct_payload_ssh" then
    do return "SSH ➔ Direct ➔ Custom Payload" end
    return
  end
  return ehi.tunnelType
end

local includes = function(tab, val)
  do
    do
      for SRD1_5_, SRD1_6_ in ipairs(tab) do
        if SRD1_6_ == val then
          return true
        end
      end
    end
  end
  return false
end

local ssh_mode = {
  "ssl_proxy_payload_ssh",
  "direct_payload_ssh",
  "proxy_payload_ssh",
  "proxy_ssh",
  "dnstt_ssh",
  "ssl_shadowsocks",
  "tls_obfs_shadowsocks",
  "proxy_shadowsocks",
  "proxy_payload_shadowsocks",
  "direct_dnsurgent",
  "direct_v2r_vmess",
  "unknown",
  "v2rRawJson",
  "v2ray_all_settings",
  "http_obfs_shadowsocks",
  "direct_shadowsocks",
  "ssl_proxy_ssh",
  "direct_ssh",
  "sni_host_port",
  "ssl_ssh",
  "lock_all",
  "http_obfs"
}
function parseHttpInjector(data)
  local jsonData = json.parse(hexdecode(data))
  gg.toast("tá sentindo a energia?")
  print("@EhisOpeNer\n")
  Http:New(jsonData)
  if includes(ssh_mode, ehi.tunnelType) then
    message = ""
    if ehi.overwriteServerData ~= "" then
      serverData = json.parse(ehi.overwriteServerData)
      message = message .. "Substituir dados do servidor: " .. ehi.overwriteServerData .. [[


]]
      message = message .. "Sobrescrever porta proxy do servidor: " .. ehi.overwriteServerProxyPort .. [[


]]
      message = message .. "Sobrescrever Tipo Servidor: " .. ehi.overwriteServerType .. [[


]]
      message = message .. "Servidor Evozi: " .. serverData.name .. " (" .. serverData.ip .. [[
)

]]
    else
      message = message .. "SSH Host: " .. Http:Dec("host") .. "\n"
      message = message .. "Porta: " .. ehi.port .. "\n"
      message = message .. "Usuário: " .. Http:Dec("user") .. "\n"
      message = message .. "Senha: " .. Http:Dec("password") .. [[


]]
 end
    if ehi.remoteProxy then
      if ehi.remoteProxyUsername and ehi.remoteProxyUsername ~= "" then
        message = message .. "Proxy: " .. Http:Dec("remoteProxy") .. "\n"
        message = message .. "Usuário e Senha Proxy Auth: " .. Http:Dec("remoteProxyUsername") .. ":" .. Http:Dec("remoteProxyPassword") .. [[


]]
      end
      elseif ehi.overwriteServerData ~= "" then
      if ehi.tunnelType == "proxy_payload_ssh" then
    message = message .. "Proxy: " .. Http:Dec("remoteProxy") .. [[


]]
end
      elseif ehi.overwriteServerData ~= "" then
      if ehi.tunnelType == "ssl_proxy_payload_ssh" then
    message = message .. "Proxy: " .. Http:Dec("remoteProxy") .. [[


]]
message = message .. "SNI: " .. Http:Dec("sniHostname") .. [[


]]
end
      elseif ehi.overwriteServerData ~= "" then
      if ehi.tunnelType == "proxy_ssh" then
    message = message .. "Proxy: " .. Http:Dec("remoteProxy") .. [[


]]
      end
    elseif ehi.overwriteServerData ~= "" then
    if ehi.tunnelType == "ssl_ssh" then
      message = message .. "SNI: " .. Http:Dec("sniHostname") .. [[


]]
end
    elseif ehi.overwriteServerData ~= "" then
    if ehi.tunnelType == "sni_host_port" then
      message = message .. "SNI: " .. Http:Dec("sniHostname") .. [[


]]
    end
    elseif ehi.tunnelType == "direct_shadowsocks" then
      message = message .. "HTTP Obfs Settings: " .. Http:Dec("httpObfsSettings") .. [[


]]
      message = message .. "Shadowsocks Host: " .. Http:Dec("shadowsocksHost") .. "\n"
      message = message .. "Shadowsocks Porta: " .. ehi.shadowsocksPort .. "\n"
      message = message .. "Shadowsocks Senha: " .. Http:Dec("shadowsocksPassword") .. [[


]]
      message = message .. "EncryptMethod: " .. string.upper(ehi.shadowsocksEncryptionMethod) .. [[


]]
      message = message .. "V2rMuxConcurrency: " .. Http:Dec("v2rMuxConcurrency") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "ssl_shadowsocks" then
    message = message .. "Shadowsocks Host: " .. Http:Dec("shadowsocksHost") .. "\n"
      message = message .. "Shadowsocks Porta: " .. ehi.shadowsocksPort .. "\n"
      message = message .. "Shadowsocks Senha: " .. Http:Dec("shadowsocksPassword") .. [[


]]
      message = message .. "EncryptMethod: " .. string.upper(ehi.shadowsocksEncryptionMethod) .. [[


]]
      message = message .. "SNI: " .. Http:Dec("sniHostname") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "direct_payload_ssh" then
      message = message .. "Payload: " .. Http:Dec("payload") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "ssl_proxy_ssh" then
    message = message .. "Proxy: " .. Http:Dec("remoteProxy") .. [[


]]
message = message .. "SNI: " .. Http:Dec("sniHostname") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "sni_host_port" then
    message = message .. "SNI: " .. Http:Dec("sniHostname") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "ssl_proxy_payload_ssh" then
    message = message .. "Proxy: " .. Http:Dec("remoteProxy") .. [[


]]
message = message .. "SNI: " .. Http:Dec("sniHostname") .. [[


]]
      message = message .. "Payload: " .. Http:Dec("payload") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "proxy_payload_ssh" then
    message = message .. "Proxy: " .. Http:Dec("remoteProxy") .. [[


]]
      message = message .. "Payload: " .. Http:Dec("payload") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "proxy_ssh" then
    message = message .. "Proxy: " .. Http:Dec("remoteProxy") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "ssl_ssh" then
    message = message .. "SNI: " .. Http:Dec("sniHostname") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "direct_ssh" then
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "direct_v2r_vmess" then
      message = "v2rRawJson: " .. Http:Dec("v2rRawJson") .. [[


]]
      if ehi.v2rRawJson then
        v2json = Http:Dec("v2rRawJson")
        print(message)
        saveEhi(v2json)
        gg.copyText(v2json, false)
        gg.toast("copiou, farinha?")
        return
      end
      message = message .. "User Alter ID: " .. Http:Dec("v2rAlterId") .. "\n"
      message = message .. "V2Ray Host: " .. Http:Dec("v2rHost") .. "\n"
      message = message .. "v2rKcpHeaderType: " .. Http:Dec("v2rKcpHeaderType") .. "\n"
      message = message .. "v2rMuxConcurrency: " .. Http:Dec("v2rMuxConcurrency") .. "\n"
      message = message .. "v2rPassword: " .. Http:Dec("v2rPassword") .. "\n"
      message = message .. "v2rNetwork: " .. Http:Dec("v2rNetwork") .. "\n"
      message = message .. "v2rPort: " .. Http:Dec("v2rPort") .. "\n"
      message = message .. "v2rProtocol: " .. Http:Dec("v2rProtocol") .. "\n"
      message = message .. "v2rH2Host: " .. Http:Dec("v2rH2Host") .. "\n"
      message = message .. "v2rH2Path: " .. Http:Dec("v2rH2Path") .. "\n"
      message = message .. "v2rQuicHeaderType: " .. Http:Dec("v2rQuicHeaderType") .. "\n"
      message = message .. "v2rTcpHeaderType: " .. Http:Dec("v2rTcpHeaderType") .. "\n"
      message = message .. "v2rUserId: " .. Http:Dec("v2rUserId") .. "\n"
      message = message .. "v2rTlsSni: " .. Http:Dec("v2rTlsSni") .. "\n"
      message = message .. "v2rVlessSecurity: " .. Http:Dec("v2rVlessSecurity") .. "\n"
      message = message .. "v2rVmessSecurity: " .. Http:Dec("v2rVmessSecurity") .. "\n"
      message = message .. "v2rSsSecurity: " .. Http:Dec("v2rSsSecurity") .. "\n"
      message = message .. "v2rQuicSecurity: " .. Http:Dec("v2rQuicSecurity") .. "\n"
      message = message .. "Header Ws: " .. Http:Dec("v2rWsHeader") .. "\n"
      message = message .. "v2rWsPath: " .. Http:Dec("v2rWsPath") .. [[


]]
      message = message .. "v2rCoreType: " .. Http:Dec("v2rCoreType") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "dnstt_ssh" then
      message = message .. "Tipo de DNS: " .. ehi.dnsType .. "\n"
      message = message .. "DNS Resolver Address: " .. Http:Dec("dnsttDnsResolverAddr") .. "\n"
      message = message .. "DNSTT Nameserver: " .. Http:Dec("dnsttNameserver") .. "\n"
      message = message .. "DNSTT Public Key: " .. Http:Dec("dnsttPublicKey") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "tls_obfs_shadowsocks" then
      message = message .. "HTTP Obfs Settings: " .. Http:Dec("httpObfsSettings") .. [[


]]
      message = message .. "Shadowsocks Host: " .. Http:Dec("shadowsocksHost") .. "\n"
      message = message .. "Shadowsocks Porta: " .. ehi.shadowsocksPort .. "\n"
      message = message .. "Shadowsocks Senha: " .. Http:Dec("shadowsocksPassword") .. [[


]]
      message = message .. "SNI: " .. Http:Dec("sniHostname") .. [[


]]
      message = message .. "EncryptMethod: " .. string.upper(ehi.shadowsocksEncryptionMethod) .. [[


]]
      message = message .. "V2rMuxConcurrency: " .. Http:Dec("v2rMuxConcurrency") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    if ehi.tunnelType == "http_obfs_shadowsocks" then
      message = message .. "HTTP Obfs Settings: " .. Http:Dec("httpObfsSettings") .. [[


]]
      message = message .. "Shadowsocks Host: " .. Http:Dec("shadowsocksHost") .. "\n"
      message = message .. "Shadowsocks Porta: " .. ehi.shadowsocksPort .. "\n"
      message = message .. "Shadowsocks Senha: " .. Http:Dec("shadowsocksPassword") .. [[


]]
      message = message .. "EncryptMethod: " .. string.upper(ehi.shadowsocksEncryptionMethod) .. [[


]]
      message = message .. "V2rMuxConcurrency: " .. Http:Dec("v2rMuxConcurrency") .. [[


]]
      message = message .. "Tipo de Túnel: " .. Http:TunnelType() .. [[


]]
    end
    gg.copyText(message, false)
    gg.toast(message .. [[

copiou, farinha?]])
    print(message)
    saveEhi(message)
  end
  os.exit()
end

function HttpInjector()
  limit = true
  gg.clearResults()
  gg.setVisible(false)
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.searchNumber("h 7B 22 63 6F 6E 66 69 67 45 78 70 69 72 79 54 69 6D 65 73 74", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: configExpiryTimest")
    ehi_2 = true
  end
  if ehi_2 then
    gg.searchNumber("h 7B 22 63 6F 6E 66 69 67 49 64 65 6E 74 69 66 69 65 72 22 3A", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: configIdentifier")
      print([[

calma barboleta]])
      print("\nImporte o Arquivo Novamente, Espere 3 Segundos e Inicie o Script da Diversão\n\n")
      os.exit()
    end
  end
  gg.searchNumber("h7B", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1000)
  readedMem = rwmem(r[1].address, 30000)
  save(hexdecode(readedMem))
  do
    do
      for SRD1_5_, SRD1_6_ in ipairs(r) do
        r[SRD1_5_].flags = gg.TYPE_FLOAT
        r[SRD1_5_].value = "1000"
      end
    end
  end
  gg.setValues(r)
  gg.clearResults()
  parseHttpInjector(readedMem)
end

function HTTPCustom()
  gg.clearResults()
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.setVisible(true)
  gg.searchNumber("::443@", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: 443")
    hc_2 = true
  end
  if hc_2 then
    gg.searchNumber("h 3A 38 30 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 80")
      hc_3 = true
    end
  end
  if hc_3 then
    gg.searchNumber("h 3A 38 30 38 30 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 8080")
      hc_4 = true
    end
  end
  if hc_4 then
    gg.searchNumber("h 3a 32 32 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 22")
      hc_5 = true
    end
  end
  if hc_5 then
    limit = false
    gg.searchNumber("h 3a 32 32 32 32 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 2222")
      hc_6 = true
    end
  end
  if hc_6 then
    limit = false
    gg.searchNumber("h 3a 34 34 34 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 444")
      hc_7 = true
    end
  end
  if hc_7 then
    limit = false
    gg.searchNumber("h 3A 35 33 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 53")
      hc_8 = true
    end
  end
  if hc_8 then
    limit = false
    gg.searchNumber("h 55 70 67 72 61 64 65 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Upgrade")
      hc_9 = true
    end
  end
  if hc_9 then
    limit = false
    gg.searchNumber("h 5B 73 70 6C 69 74 50 73 69 70 68 6F 6E 5D 5B 73 70 6C 69 74 50 73 69 70 68 6F 6E 5D", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: splitPsiphon splitPsiphon")
      hc_10 = true
    end
  end
  if hc_10 then
    limit = false
    gg.searchNumber("h 23 20 43 6F 6E 66 69 67 20 66 6F 72 20 4F 70 65 6E 56 50 4E 20 32 2E 78", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: config for OpenVPN 2x")
      hc_11 = true
    end
  end
  if hc_11 then
    limit = false
    gg.searchNumber("h 5B 00 73 00 70 00 6C 00 69 00 74 00 43 00 6F 00 6E 00 66 00 69 00 67 00 5D", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: splitConfig")
      hc_12 = true
    end
  end
  if hc_12 then
    limit = false
    gg.searchNumber("h 22 69 73 4c 6f 67 69 6e 48 77 69 64 22 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: isLoginHwid")
      hc_13 = true
    end
  end
  if hc_13 then
    limit = false
    gg.searchNumber("h 20 22 64 6e 73 22 3a 20 7b", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: dns")
      hc_14 = true
    end
  end
  if hc_14 then
    limit = false
    gg.searchNumber("h 5b 63 72 6c 66 5d 48 6f 73 74 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: crlf Host")
      hc_15 = true
    end
  end
  if hc_15 then
    limit = false
    gg.searchNumber("h 7B 0A 09 09 22 69 6E 62 6F 75 6E 64", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: inbound")
      hc_16 = true
    end
  end
  if hc_16 then
    limit = false
    gg.searchNumber("h 75 70 67 72 61 64 65 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: upgrade")
      hc_17 = true
    end
  end
  if hc_17 then
    limit = false
    gg.searchNumber("h 41 43 4c 20 2f 20 48 54 54 50 2f", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: ACL HTTP")
      hc_18 = true
    end
  end
  if hc_18 then
    limit = false
    gg.searchNumber("h 43 4f 4e 4e 45 43 54 20 5b", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: CONNECT")
      hc_19 = true
    end
  end
  if hc_19 then
    limit = false
    gg.searchNumber("h 48 6f 73 74 3a 5b 72 6f 74 61 74 65 3d", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: rotate")
      hc_20 = true
    end
  end
  if hc_20 then
    gg.toast("❌Configuração Não Encontrada")
    print("Clique em Update e Inicie o Script Rápido!!!\n")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == false then
    r[1].address = r[1].address - 8192
  end
  readedMem = rwmem(r[1].address, 68000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function hc_ssc()
  gg.clearResults()
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.setVisible(true)
  gg.searchNumber("h 7B 22 61 62 22 3A", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: ab")
    ssc_2 = true
  end
  if ssc_2 then
    gg.searchNumber("h 55 70 67 72 61 64 65 3A", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Upgrade")
      ssc_3 = true
    end
  end
  if ssc_3 then
    gg.searchNumber("h 3A 38 30 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 80")
      ssc_4 = true
    end
  end
  if ssc_4 then
    gg.searchNumber("h 7B 0A 09 09 22 69 6E 62 6F 75 6E 64", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: inbound")
      ssc_5 = true
    end
  end
  if ssc_5 then
    gg.searchNumber("h 7B 0A 20 20 22 64 6E 73 22 3A 20 7B 0A 20 20 20 20 22 68 6F 73 74 73 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: dns hosts")
      ssc_6 = true
    end
  end
  if ssc_6 then
    gg.searchNumber("::443@", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 443")
      ssc_7 = true
    end
  end
  if ssc_7 then
    gg.searchNumber(":[crlf][crlf]", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: crlf")
      ssc_8 = true
    end
  end
  if ssc_8 then
    gg.searchNumber("h 48 6f 73 74 3a 5b 72 6f 74 61 74 65 3d", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: rotate")
      ssc_9 = true
    end
  end
  if ssc_9 then
    gg.toast("❌Configuração Não Encontrada")
    print("Clique em Update e Inicie o Script Rápido!!!\n")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == false then
    r[1].address = r[1].address - 8192
  end
  readedMem = rwmem(r[1].address, 40000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function TLSTunnel()
  limit = false
  gg.clearResults()
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.setVisible(true)
  gg.searchNumber("h 3A 30 3A 30 3A 74 72 75 65 3A", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: versi")
    tls_2 = true
  end
  if tls_2 then
    limit = false
    gg.searchNumber("h 33 35 39 3A 30 3A 30", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 359 h")
      tls_3 = true
    end
  end
  if tls_3 then
    gg.searchNumber("h 00 00 7b 00 22 00 41 00 22 00 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: A")
      tls_4 = true
    end
  end
  if tls_4 then
    limit = false
    gg.searchNumber(":357:0:0:", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("357")
      tls_5 = true
    end
  end
  if tls_5 then
    gg.searchNumber("h 63 69 70 68 65 72 31 2e 64 6f 46 69 6e 61 6c 28 63 72 79 70 74 6f 29", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: cipher1 doFinal crypto")
      tls_6 = true
    end
  end
  if tls_6 then
    limit = false
    gg.searchNumber("h 75 00 70 00 77 00 73 00", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: upws")
      tls_7 = true
    end
  end
  if tls_7 then
    limit = false
    gg.searchNumber("h 55 70 67 72 61 64 65 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Upgrade")
      tls_8 = true
    end
  end
  if tls_8 then
    limit = false
    gg.searchNumber("h 47 45 54 20 77 73", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: GET ws")
      tls_9 = true
    end
  end
  if tls_9 then
    limit = false
    gg.searchNumber("h 47 45 54 20 73 68 69", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: GET shi")
      tls_10 = true
    end
  end
  if tls_10 then
    limit = false
    gg.searchNumber("h 5b 68 6f 73 74 5d 5b 63 72 6c 66 5d", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: host crlf")
      tls_11 = true
    end
  end
  if tls_11 then
    gg.toast("❌Configuração Não Encontrada")
    print("❌Configuração Não Encontrada")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == false then
    r[1].address = r[1].address - 8192
  end
  readedMem = rwmem(r[1].address, 50000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function eV2ray()
  gg.clearResults()
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.setVisible(true)
  gg.searchNumber("h 7B 0A 20 20 22 69 6E 62 6F 75 6E 64", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: inbound")
    epro_2 = true
  end
  if epro_2 then
    gg.searchNumber("h 64 6e 73 22 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: dns")
      epro_3 = true
    end
  end
  if epro_3 then
    gg.searchNumber("h 6f 75 74 62 6f 75 6e 64 73 22 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: aspas outbounds")
      epro_4 = true
    end
  end
  if epro_4 then
    gg.searchNumber("h 22 69 6e 62 6f 75 6e 64 73 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: apsas inbounds")
      epro_5 = true
    end
  end
  if epro_5 then
    gg.toast("❌Configuração Não Encontrada")
    print("\nimporte o arquivo novamente ou inicie a VPN se quiser")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == false then
    r[1].address = r[1].address - 0x400
  end
  readedMem = rwmem(r[1].address, 50000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function NapsternetV()
  gg.clearResults()
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.setVisible(true)
  gg.searchNumber("h 22 76 65 72 73 69 6f 6e 69 6e 67 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: versioning")
    npv_2 = true
  end
  if npv_2 then
    gg.searchNumber("h 55 70 67 72 61 64 65 3A", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Upgrade")
      npv_3 = true
    end
  end
  if npv_3 then
    gg.searchNumber("h 7B 0A 09 09 22 69 6E 62 6F 75 6E 64", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: inbound")
      npv_4 = true
    end
  end
  if npv_4 then
    gg.searchNumber("h 70 73 69 70 68 6f 6e 43 6f 6e 66 69 67 22 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: psiphonConfig")
      npv_5 = true
    end
  end
  if npv_5 then
    limit = false
    gg.searchNumber("h 22 76 65 72 73 69 6f 6e 69 6e 67 22 65 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: versioning e")
      npv_6 = true
    end
  end
  if npv_6 then
    limit = false
    gg.searchNumber("h 7b 22 76 65 72 73 69 6f 6e 69 6e 67 22 3a 7b 22 63 6f 6e 66 69 67 54 79 70 65 22 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: versioning configType")
      npv_7 = true
    end
  end
  if npv_7 then
    gg.toast("❌Configuração Não Encontrada")
    print("❌Configuração Não Encontrada")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == false then
    r[1].address = r[1].address - 8192
  end
  readedMem = rwmem(r[1].address, 50000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function HATunnel()
  gg.clearResults()
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.setVisible(true)
  gg.searchNumber("h 7b 22 75 73 65 72 5f 69 64 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: user id")
    hat_2 = true
  end
  if hat_2 then
    gg.searchNumber("h 7b 5c 22 63 6f 6e 6e 65 63 74 69 6f 6e 5f 6d 6f 64 65 5c 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: connecion mode")
      hat_3 = true
    end
  end
  if hat_3 then
    limit = false
    gg.searchNumber("h7b22757365725f696422", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: id")
      hat_4 = true
    end
  end
  if hat_4 then
    limit = false
    gg.searchNumber("h 5c 22 6f 76 65 72 72 69 64 65 5f 70 72 69 6d 61 72 79 5f 68 6f 73 74 5c", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: override primary host")
      hat_5 = true
    end
  end
  if hat_5 then
    limit = false
    gg.searchNumber("h 61 63 63 65 73 73 5f 63 6f 64 65 22 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: acess code")
      hat_6 = true
    end
  end
  if hat_6 then
    gg.toast("❌Configuração Não Encontrada")
    print("❌Configuração Não Encontrada")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == false then
    r[1].address = r[1].address - 8192
  end
  readedMem = rwmem(r[1].address, 50000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function SocksHttpPlus()
  limit = true
  gg.clearResults()
  gg.setVisible(true)
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.searchNumber("h 7b 22 69 64 22 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada")
    print("❌Configuração Não Encontrada")
    os.exit()
  end
  gg.searchNumber("h7B", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1000)
  readedMem = rwmem(r[1].address, 50000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function DarkTunnel()
  gg.clearResults()
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.setVisible(true)
  gg.searchNumber("h537368436F6E6669674C6F636B6564C3A9537368436F6E666967", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: SshConfigLockedeSshConfig")
    dark_2 = true
  end
  if dark_2 then
    gg.searchNumber(":SshConfigLockedéSshConfig", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: SshConfigLockedÃ©SshConfig")
      dark_3 = true
    end
  end
  if dark_3 then
    gg.searchNumber(":SshConfigLocked", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: SshConfigLocked")
      dark_4 = true
    end
  end
  if dark_4 then
    gg.searchNumber("h 53 73 68 43 6F 6E 66 69 67 4C 6F 63 6B 65 64 C3 A9 53 73 68 43 6F 6E 66 69 67", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: SshConfigLockedÃ©SshConfig")
      dark_5 = true
    end
  end
  if dark_5 then
    gg.searchNumber("h 53 73 68 43 6F 6E 66 69 67 4C 6F 63 6B 65 64 C3 A9 53 73 68 43 6F 6E 66 69 67", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: SshConfigLockedÃ©SshConfig")
      dark_6 = true
    end
  end
  if dark_6 then
    gg.searchNumber("h 53 73 68 43 6F 6E 66 69 67 4C 6F 63 6B 65 64 C3 A9 53 73 68 43 6F 6E 66 69 67", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: SshConfigLockedÃ©SshConfig")
      dark_7 = true
    end
  end
  if dark_7 then
    gg.searchNumber("h 4d 65 73 73 61 67 65 22 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Message")
      dark_8 = true
    end
  end
  if dark_8 then
    gg.searchNumber("h 55 70 67 72 61 64 65 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Upgrade")
      dark_9 = true
    end
  end
  if dark_9 then
    gg.searchNumber("h 7b 22 48 6f 73 74 22 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Host")
      dark_10 = true
    end
  end
  if dark_10 then
    gg.searchNumber("h 69 6e 62 6f 75 6e 64 73", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: inbound")
      dark_11 = true
    end
  end
  if dark_11 then
    gg.toast("❌Configuração Não Encontrada")
    print("❌Configuração Não Encontrada")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == false then
    r[1].address = r[1].address - 0x400
  end
  readedMem = rwmem(r[1].address, 40000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function SocksHttp()
  limit = true
  gg.clearResults()
  gg.setVisible(true)
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.searchNumber("h 7b 22 73 73 68 53 65 72 76 65 72 22 3a 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada")
    print("❌Configuração Não Encontrada")
    os.exit()
  end
  gg.searchNumber("h7B", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1000)
  if limit == false then
    r[1].address = r[1].address - 0x
    end
  readedMem = rwmem(r[1].address, 40000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function NetModSyna()
  limit = true
  gg.clearResults()
  gg.setVisible(true)
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.searchNumber("h 7B 22 50 61 79 6C 6F 61 64 22 3A 7B 22 56 61 6C 75 65 22 3A", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada")
    print("❌Configuração Não Encontrada")
    os.exit()
  end
  gg.searchNumber("7Bh", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  readedMem = rwmem(r[1].address, 50000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function RezTunnel()
  gg.clearResults()
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.setVisible(true)
  gg.searchNumber("h 7B 5C 22 50 53 49 6E 73 74 61 6C 6C 5C 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: install")
    rez_2 = true
  end
  if rez_2 then
    gg.searchNumber("h 7b 22 50 53 49 6e 73 74 61 6c 6c 22 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: PSInstall 1")
      rez_3 = true
    end
  end
  if rez_3 then
    gg.searchNumber("h 50 53 49 6e 73 74 61 6c 6c 22 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: PSInstall 2")
      rez_4 = true
    end
  end
  if rez_4 then
    gg.searchNumber("h 48 6f 73 74 3a 5b 72 6f 74 61 74 65 3d", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada:  rotate")
      rez_5 = true
    end
  end
  if rez_5 then
    gg.searchNumber("h 7B 0A 20 20 20 20 22 56 65 72 73 69 6F 6E 22 3A 20", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Version Config full")
      rez_6 = true
    end
  end
  if rez_6 then
    gg.searchNumber("h 53 53 48 48 6f 73 74 22 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: SSHHost")
      rez_7 = true
    end
  end
  if rez_7 then
    gg.searchNumber("h 55 70 67 72 61 64 65 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Version Upgrade")
      rez_8 = true
    end
  end
  if rez_8 then
    gg.toast("❌Configuração Não Encontrada")
    print("❌Configuração Não Encontrada")
    os.exit()
  end
  local r = gg.getResults(1)
  if limit == true then
    r[1].address = r[1].address - 8192
  end
  readedMem = rwmem(r[1].address, 50000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function ApkCustom()
  gg.clearResults()
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.setVisible(true)
  gg.searchNumber("h 3A 34 34 33 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: 443")
    acm_2 = true
  end
  if acm_2 then
    gg.searchNumber("h 55 70 67 72 61 64 65 3A", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Upgrade")
      acm_3 = true
    end
  end
  if acm_3 then
    gg.searchNumber("h 3A 38 30 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 80")
      acm_4 = true
    end
  end
  if acm_4 then
    limit = true
    gg.searchNumber("h 7B 0A 09 09 22 69 6E 62 6F 75 6E 64", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: inbound")
      acm_5 = true
    end
  end
  if acm_5 then
    limit = false
    gg.searchNumber("h 7B 0A 20 20 22 64 6E 73 22 3A 20 7B 0A 20 20 20 20 22 68 6F 73 74 73 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: dns hosts")
      acm_6 = true
    end
  end
  if acm_6 then
    limit = false
    gg.searchNumber("h 3A 35 33 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 53")
      acm_7 = true
    end
  end
  if acm_7 then
    limit = false
    gg.searchNumber("h 5B 73 70 6C 69 74 50 73 69 70 68 6F 6E 5D 5B 73 70 6C 69 74 50 73 69 70 68 6F 6E 5D", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: splitPsiphon")
      acm_8 = true
    end
  end
  if acm_8 then
    gg.toast("❌Configuração Não Encontrada")
    print("❌Configuração Não Encontrada")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == false then
    r[1].address = r[1].address - 8192
  end
  readedMem = rwmem(r[1].address, 50000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function SocksIP()
  gg.clearResults()
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.setVisible(true)
  gg.searchNumber("h6E6577746F6F6C73776F726B732E636F6D2E736F636B7369702E7574696C732E536572536F636B73495068", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: network sip")
    sip_2 = true
  end
  if sip_2 then
    gg.searchNumber("h 55 70 67 72 61 64 65 3A", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Upgrade")
      sip_3 = true
    end
  end
  if sip_3 then
    gg.searchNumber("h 73 73 68 6f 63 65 61 6e", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: sshocean")
      sip_4 = true
    end
  end
  if sip_4 then
    gg.searchNumber("h 3A 38 30 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 80")
      sip_5 = true
    end
  end
  if sip_5 then
    limit = false
    gg.searchNumber("h 7B 0A 09 09 22 69 6E 62 6F 75 6E 64", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: inbound")
      sip_6 = true
    end
  end
  if sip_6 then
    limit = false
    gg.searchNumber("h 73 70 65 65 64 79 73 73 68 2e", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: dns hosts")
      sip_7 = true
    end
  end
  if sip_7 then
    limit = false
    gg.searchNumber("h 3A 35 33 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 53")
      sip_8 = true
    end
  end
  if sip_8 then
    limit = false
    gg.searchNumber("h 47 45 54 20 77", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: GET w")
      sip_9 = true
    end
  end
  if sip_9 then
    limit = false
    gg.searchNumber("h 5b 63 72 6c 66 5d 48 6f 73 74 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: crlf host")
      sip_10 = true
    end
  end
  if sip_10 then
    limit = false
    gg.searchNumber("h 48 6f 73 74 3a 5b 72 6f 74 61 74 65 3d", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: rotate")
      sip_11 = true
    end
  end
  if sip_11 then
    limit = false
    gg.searchNumber("h 3A 34 34 33 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 443")
      sip_12 = true
    end
  end
  if sip_12 then
    gg.toast("❌Configuração Não Encontrada")
    print("❌Configuração Não Encontrada")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == false then
    r[1].address = r[1].address - 8192
  end
  readedMem = rwmem(r[1].address, 20000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function StarkVPN()
  gg.clearResults()
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.setVisible(true)
  gg.searchNumber("h 7B 5C 22 63 6F 6E 66 69 67 5C 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: config barra")
    stk_2 = true
  end
  if stk_2 then
    gg.searchNumber("h 63 6f 6e 66 69 67 22 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: config aspas")
      stk_3 = true
    end
  end
  if stk_3 then
    limit = false
    gg.searchNumber("h 63 6f 6e 6e 65 63 74 69 6f 6e 5f 6d 6f 64 65 22 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: connection mode")
      stk_4 = true
    end
  end
  if stk_4 then
    gg.toast("❌Configuração Não Encontrada")
    print("❌Configuração Não Encontrada")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == false then
    r[1].address = r[1].address - 8192
  end
  readedMem = rwmem(r[1].address, 50000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function configjson()
  gg.clearResults()
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.setVisible(true)
  gg.searchNumber("h 7b a 22 56 65 72 73 69 6f 6e 22 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: Version")
    json_2 = true
  end
  if json_2 then
    gg.searchNumber("h 7b a 9 22 56 65 72 73 69 6f 6e 22 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Version")
      json_3 = true
    end
  end
  if json_3 then
    gg.searchNumber("h 7b a 20 20 22 56 65 72 73 69 6f 6e 22 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Version")
      json_4 = true
    end
  end
  if json_4 then
    gg.searchNumber("h 7b a 20 20 20 22 56 65 72 73 69 6f 6e 22 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Version")
      json_5 = true
    end
  end
  if json_5 then
    gg.searchNumber("h 55 70 67 72 61 64 65 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Upgrade")
      json_6 = true
    end
  end
  if json_6 then
    gg.searchNumber("h 7B 5C 22 56 65 72 73 69 6F 6E 5C 22 3A 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: inbound")
      json_7 = true
    end
  end
  if json_7 then
    gg.searchNumber("h 22 2c 22 52 65 6c 65 61 73 65 4e 6f 74 65 73 22 3a 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: ReleaseNotes")
      json_8 = true
    end
  end
  if json_8 then
    gg.toast("❌Configuração Não Encontrada")
    print("❌Configuração Não Encontrada")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == false then
    r[1].address = r[1].address - 8192
  end
  readedMem = rwmem(r[1].address, 70000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function TunnelCat()
  gg.clearResults()
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.setVisible(true)
  gg.searchNumber("h 7B 5C 22 65 78 70 6F 72 74 44 65 74 61 69 6C 73 5C 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: export D")
    cat_2 = true
  end
  if cat_2 then
    gg.searchNumber("h 7b 5c 22 65 78 70 6f 72 74 44 65 74 61 69 6c 73 5c 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: exportDetails")
      cat_3 = true
    end
  end
  if cat_3 then
    gg.searchNumber(";exportDetails", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: exportDe")
      cat_4 = true
    end
  end
  if cat_4 then
    gg.searchNumber("h 55 70 67 72 61 64 65 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Upgrade")
      cat_5 = true
    end
  end
  if cat_5 then
    gg.searchNumber("h 69 6e 62 6f 75 6e 64 73", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: inbound")
      cat_6 = true
    end
  end
  if cat_6 then
    gg.toast("❌Configuração Não Encontrada")
    print("❌Configuração Não Encontrada")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == false then
    r[1].address = r[1].address - 8192
  end
  readedMem = rwmem(r[1].address, 20000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function v2rayHybrid()
  gg.clearResults()
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.setVisible(true)
  gg.searchNumber("h 7B 5C 22 61 64 64 65 64 54 69 6D 65 5C 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: addedtime")
    hy_2 = true
  end
  if hy_2 then
    gg.searchNumber("h 7b 5c 22 61 64 64 65 64 54 69 6d 65 5c 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: added Time")
      hy_3 = true
    end
  end
  if hy_3 then
    gg.searchNumber(";addedTime", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: addedTime")
      hy_4 = true
    end
  end
  if hy_4 then
    gg.searchNumber("h 55 70 67 72 61 64 65 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Upgrade")
      cat_5 = true
    end
  end
  if hy_5 then
    gg.searchNumber("h 69 6e 62 6f 75 6e 64 73", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: inbound")
      hy_6 = true
    end
  end
  if hy_6 then
    gg.toast("❌Configuração Não Encontrada")
    print("❌Configuração Não Encontrada")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == false then
    r[1].address = r[1].address - 8192
  end
  readedMem = rwmem(r[1].address, 20000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function ARMod()
  gg.clearResults()
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.setVisible(true)
  gg.searchNumber(":[{\"AlterID\"", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: alter id")
    armo_2 = true
  end
  if armo_2 then
    gg.searchNumber("h 5b 7b 5c 22 41 6c 74 65 72 49 44 5c 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: alter")
      armo_3 = true
    end
  end
  if armo_3 then
    gg.searchNumber(";AlterID", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: addedTime")
      armo_4 = true
    end
  end
  if armo_4 then
    gg.searchNumber("h 55 70 67 72 61 64 65 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Upgrade")
      armo_5 = true
    end
  end
  if armo_5 then
    gg.searchNumber("h 69 6e 62 6f 75 6e 64 73", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: inbound")
      armo_6 = true
    end
  end
  if armo_6 then
    gg.toast("❌Configuração Não Encontrada")
    print("❌Configuração Não Encontrada")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == false then
    r[1].address = r[1].address - 8192
  end
  readedMem = rwmem(r[1].address, 20000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function WeTunnel()
  gg.clearResults()
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.setVisible(true)
  gg.searchNumber("h 7B 5C 22 50 53 49 6E 73 74 61 6C 6C 5C 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: install")
    we_2 = true
  end
  if we_2 then
    gg.searchNumber("h 7b 22 50 53 49 6e 73 74 61 6c 6c 22 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: PSInstall 1")
      we_3 = true
    end
  end
  if we_3 then
    gg.searchNumber("h 50 53 49 6e 73 74 61 6c 6c 22 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: PSInstall 2")
      we_4 = true
    end
  end
  if we_4 then
    gg.searchNumber("h 7B 5C 22 50 53 49 6E 73 74 61 6C 6C 5C 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada:  install 2")
      we_5 = true
    end
  end
  if we_5 then
    gg.searchNumber("h 7B 0A 20 20 20 20 22 56 65 72 73 69 6F 6E 22 3A 20", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Version Config full")
      we_6 = true
    end
  end
  if we_6 then
    gg.searchNumber("h 53 53 48 48 6f 73 74 22 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: SSHHost")
      we_7 = true
    end
  end
  if we_7 then
    gg.searchNumber("h 55 70 67 72 61 64 65 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Version Upgrade")
      we_8 = true
    end
  end
  if we_8 then
    gg.toast("❌Configuração Não Encontrada")
    print("❌Configuração Não Encontrada")
    os.exit()
  end
  local r = gg.getResults(1)
  if limit == true then
    r[1].address = r[1].address - 8192
  end
  readedMem = rwmem(r[1].address, 50000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function XrayPB()
  gg.clearResults()
  gg.setVisible(true)
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.searchNumber(";{\"addedTime\"", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: addedTime")
    pb_2 = true
  end
  if pb_2 then
    gg.searchNumber("h 7B 5C 22 61 64 64 65 64 54 69 6D 65 5C 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: added")
      pb_3 = true
    end
  end
  if pb_3 then
    gg.toast("❌Configuração Não Encontrada")
    print("❌Configuração Não Encontrada")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == true then
    r[1].address = r[1].address - 8192
  end
  readedMem = rwmem(r[1].address, 20000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function OpenTunnel()
  gg.clearResults()
  gg.setVisible(true)
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.searchNumber("h 3C 2F 65 6E 74 72 79 3E 0A 3C 65 6E 74 72 79 20 6B 65 79 3D", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: addedTime")
    tnl_2 = true
  end
  if tnl_2 then
    gg.searchNumber("h 3C 2F 65 6E 74 72 79 3E 0A 3C 65 6E 74 72 79 20 6B 65 79 3D", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: added")
      tnl_3 = true
    end
  end
  if tnl_3 then
    gg.toast("❌Configuração Não Encontrada")
    print("❌Configuração Não Encontrada")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == true then
    r[1].address = r[1].address - 8192
  end
  readedMem = rwmem(r[1].address, 20000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function sopass()
  gg.clearResults()
  gg.setVisible(true)
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.searchNumber(";{\"Password\"", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: pass")
    efbd_2 = true
  end
  if efbd_2 then
    gg.searchNumber("h 7b 5c 22 50 61 73 73 77 6f 72 64 5c 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Password barra")
      efbd_3 = true
    end
  end
  if efbd_3 then
    gg.toast("❌Configuração Não Encontrada")
    print("❌Configuração Não Encontrada")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == true then
    r[1].address = r[1].address - 8192
  end
  readedMem = rwmem(r[1].address, 40000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end

function kobra()
  gg.clearResults()
  gg.setVisible(true)
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.searchNumber(":Servidores", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: servidores")
    kobras_2 = true
  end
  if kobras_2 then
    gg.searchNumber(":Upgrade:", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Upgrade")
      kobras_3 = true
    end
  end
  if kobras_3 then
    gg.toast("❌Configuração Não Encontrada")
    print("❌Configuração Não Encontrada")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == false then
    r[1].address = r[1].address - 8192
  end
  readedMem = rwmem(r[1].address, 50000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
  end

function kobras()
  limit = true
  gg.clearResults()
  gg.setVisible(true)
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.searchNumber("h 7B 0A 20 20 20 20 22 53 65 72 76 69 64 6F 72 65 73 22 3A", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada")
    print("❌Configuração Não Encontrada")
    os.exit()
  end
  gg.searchNumber("h7B", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1000)
  readedMem = rwmem(r[1].address, 50000)
  save(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
end
  
if app == "com.evozi.injector" then
  HttpInjector()
elseif app == "com.evozi.injector.lite" then
  HttpInjector()
elseif app == "xyz.easypro.httpcustom" then
  HTTPCustom()
elseif app == "com.tlsvpn.tlstunnel" then
  TLSTunnel()
elseif app == "dev.epro.ssc" then
  hc_ssc()
elseif app == "dev.epro.e_v2ray" then
  eV2ray()
elseif app == "com.napsternetlabs.napsternetv" then
  NapsternetV()
elseif app == "com.newtoolsworks.sockstunnel" then
  SocksIP()
elseif app == "com.slipkprojects.sockshttp" then
  SocksHttp()
elseif app == "com.slipkprojects.sksplus" then
  SocksHttpPlus()
elseif app == "com.hatunnel.plus" then
  HATunnel()
elseif app == "team.dev.epro.apkcustom" then
  ApkCustom()
elseif app == "com.techoragontcptun" then
  RezTunnel()
elseif app == "net.darktunnel.app" then
  DarkTunnel()
elseif app == "com.tunnelcatvpn.android" then
  TunnelCat()
elseif app == "com.v2ray.hybrid" then
  v2rayHybrid()
elseif app == "com.one.vpnapp" then
  configjson()
  elseif app == "mau.miracle.mau" then
  configjson()
  elseif app == "onnet.miracle" then
  configjson()
elseif app == "com.hybrid.tunnel" then
  configjson()
elseif app == "com.gdmnetpro.vpn" then
  configjson()
elseif app == "com.trrorcloud.br" then
  configjson()
elseif app == "com.lockproig.vpn" then
  configjson()
elseif app == "app.hackkcah.xyz" then
  configjson()
elseif app == "com.handy.vpn" then
  configjson()
elseif app == "com.socketclay.http" then
  configjson()
elseif app == "com.internetinfinito.http" then
  configjson()
elseif app == "com.socketconexion.vps" then
  configjson()
elseif app == "com.fenix.vpn" then
  configjson()
elseif app == "com.turbovpn.app" then
  configjson()
elseif app == "com.mastercloudvpn.http" then
  configjson()
elseif app == "com.godiesan.vpn" then
  configjson()
elseif app == "com.cloud.focus" then
  configjson()
  elseif app == "com.upnet4gbr.telecom" then
  configjson()
  elseif app == "com.internetvpn.vpnff" then
  configjson()
elseif app == "com.doriaxvpn.http" then
  configjson()
elseif app == "com.sockslitepro.net" then
  configjson()
elseif app == "com.mnjnet.rev" then
  configjson()
elseif app == "br.com.litesshbrasil" then
  configjson()
elseif app == "istark.vpn.starkreloaded" then
  StarkVPN()
elseif app == "com.Internetshub.socks" then
  WeTunnel()
elseif app == "com.sihiver.xraypb" then
  XrayPB()
elseif app == "com.opentunnel.app" then
  OpenTunnel()
elseif app == "com.artunnel57" then
  ARMod()
elseif app == "com.ar.dev.bdvpninject" then
  sopass()
elseif app == "com.ef.dev.eftunnel" then
  sopass()
  elseif app == "kobras.vpn.ultra.max.miguel.pro" then
  kobras()
elseif app == "com.netmod.syna" then
  NetModSyna()
else
  gg.toast("@netfree080")
  print("\n❌O Aplicativo Não Está Na Lista\n\n")
end
gg.clearResults()
os.exit()
pcall(load(x9C))
prima()
end

function hc()

limit = false
targetInfo = gg.getTargetInfo()
app = targetInfo.packageName
local utf8 = {}
local bit = {
  data32 = {}
}
do
  do
    for SRD1_5_ = 1, 32 do
      bit.data32[SRD1_5_] = 2 ^ (32 - SRD1_5_)
    end
  end
end
local toby = string.byte
function utf8.charbytes(s, i)
  i = i or 1
  local c = string.byte(s, i)
  if c > 0 and c <= 127 then
    do return 1 end
    return
  end
  if c >= 194 and c <= 223 then
    do return 2 end
    return
  end
  if c >= 224 and c <= 239 then
    do return 3 end
    return
  end
  if c >= 240 and c <= 244 then
    return 4
  end
  return 1
end

local ded
function bit:d2b(arg)
  if arg == nil then
    return
  end
  local tr, c = {}, arg < 0
  if c then
    arg = 0 - arg
  end
  do
    do
      for SRD1_7_ = 1, 32 do
        if arg >= self.data32[SRD1_7_] then
          tr[SRD1_7_] = 1
          arg = arg - self.data32[SRD1_7_]
        else
          tr[SRD1_7_] = 0
        end
      end
    end
  end
  if c then
    tr = self:_bnot(tr)
    tr = self:b2d(tr) + 1
    tr = self:d2b(tr)
  end
  return tr
end

function bit:b2d(arg, neg)
  local nr = 0
  if arg[1] == 1 and neg == true then
    arg = self:_bnot(arg)
    nr = self:b2d(arg) + 1
    nr = 0 - nr
  else
    do
      for SRD1_7_ = 1, 32 do
        if arg[SRD1_7_] == 1 then
          nr = nr + 2 ^ (32 - SRD1_7_)
        end
      end
    end
  end
  return nr
end

function bit:_and(a, b)
  local op1 = self:d2b(a)
  local op2 = self:d2b(b)
  local r = {}
  do
    do
      for SRD1_9_ = 1, 32 do
        if op1[SRD1_9_] == 1 and op2[SRD1_9_] == 1 then
          r[SRD1_9_] = 1
        else
          r[SRD1_9_] = 0
        end
      end
    end
  end
  return self:b2d(r, true)
end

function bit:_or(a, b)
  local op1 = self:d2b(a)
  local op2 = self:d2b(b)
  local r = {}
  do
    do
      for SRD1_9_ = 1, 32 do
        if op1[SRD1_9_] == 1 or op2[SRD1_9_] == 1 then
          r[SRD1_9_] = 1
        else
          r[SRD1_9_] = 0
        end
      end
    end
  end
  return self:b2d(r, true)
end

function bit:_xor(a, b)
  local op1 = self:d2b(a)
  if op1 == nil then
    return nil
  end
  local op2 = self:d2b(b)
  if op2 == nil then
    return nil
  end
  local r = {}
  do
    do
      for SRD1_9_ = 1, 32 do
        if op1[SRD1_9_] == op2[SRD1_9_] then
          r[SRD1_9_] = 0
        else
          r[SRD1_9_] = 1
        end
      end
    end
  end
  return self:b2d(r, true)
end

local switch = {
  [1] = function(s, pos)
    local c1 = toby(s, pos)
    return c1
  end
  ,
  [2] = function(s, pos)
    local c1 = toby(s, pos)
    local c2 = toby(s, pos + 1)
    local int1 = bit:_and(31, c1)
    local int2 = bit:_and(63, c2)
    return bit:_or(bit:_lshift(int1, 6), int2)
  end
  ,
  [3] = function(s, pos)
    local c1 = toby(s, pos)
    local c2 = toby(s, pos + 1)
    local c3 = toby(s, pos + 2)
    local int1 = bit:_and(15, c1)
    local int2 = bit:_and(63, c2)
    local int3 = bit:_and(63, c3)
    local o2 = bit:_or(bit:_lshift(int1, 12), bit:_lshift(int2, 6))
    local dt = bit:_or(o2, int3)
    return dt
  end
  ,
  [4] = function(s, pos)
    local c1 = toby(s, pos)
    local c2 = toby(s, pos + 1)
    local c3 = toby(s, pos + 2)
    local c4 = toby(s, pos + 3)
    local int1 = bit:_and(15, c1)
    local int2 = bit:_and(63, c2)
    local int3 = bit:_and(63, c3)
    local int4 = bit:_and(63, c4)
    local o2 = bit:_or(bit:_lshift(int1, 18), bit:_lshift(int2, 12))
    local o3 = bit:_or(o2, bit:_lshift(int3, 6))
    local o4 = bit:_or(o3, int4)
    return o4
  end
  
}
function bit:_bnot(op1)
  local r = {}
  do
    do
      for SRD1_6_ = 1, 32 do
        if op1[SRD1_6_] == 1 then
          r[SRD1_6_] = 0
        else
          r[SRD1_6_] = 1
        end
      end
    end
  end
  return r
end

function bit:_not(a)
  local op1 = self:d2b(a)
  local r = self:_bnot(op1)
  return self:b2d(r, true)
end

function bit:charCodeAt(s)
  local pos, int, H, L = 1, 0, 0, 0
  local slen = string.len(s)
  local allByte = {}
  while pos <= slen do
    local tLen = utf8.charbytes(s, pos)
    if tLen >= 1 and tLen <= 4 then
      if tLen == 4 then
        int = switch[4](s, pos)
        H = math.floor((int - 65536) / 1024) + 55296
        L = (int - 65536) % 1024 + 56320
        table.insert(allByte, H)
        table.insert(allByte, L)
      else
        int = switch[tLen](s, pos)
        table.insert(allByte, int)
      end
    end
    pos = pos + tLen
  end
  return allByte
end

function bit:_rshift(a, n)
  local r = 0
  if a < 0 then
    r = 0 - self:_frshift(0 - a, n)
  elseif a >= 0 then
    r = self:_frshift(a, n)
  end
  return r
end

function bit:_frshift(a, n)
  local op1 = self:d2b(a)
  local r = self:d2b(0)
  local left = 32 - n
  if n < 32 and n > 0 then
    do
      for SRD1_9_ = left, 1, -1 do
        r[SRD1_9_ + n] = op1[SRD1_9_]
      end
    end
  end
  return self:b2d(r)
end

function bit:_lshift(a, n)
  local op1 = self:d2b(a)
  local r = self:d2b(0)
  if n < 32 and n > 0 then
    do
      for SRD1_8_ = n, 31 do
        r[SRD1_8_ - n + 1] = op1[SRD1_8_ + 1]
      end
    end
  end
  return self:b2d(r, true)
end

function trim(s)
  return s:match("^%s*(.*)"):match("(.-)%s*$")
end

local json = {}
local kind_of = function(obj)
  if type(obj) ~= "table" then
    return type(obj)
  end
  local i = 1
  do
    do
      for SRD1_5_ in pairs(obj) do
        if obj[i] ~= nil then
          i = i + 1
        else
          return "table"
        end
      end
    end
  end
  if i == 1 then
    do return "table" end
    return
  end
  return "array"
end

local escape_str = function(s)
  local in_char = {
    "\\",
    "\"",
    "/",
    "\b",
    "\f",
    "\n",
    "\r",
    "\t"
  }
  local out_char = {
    "\\",
    "\"",
    "/",
    "b",
    "f",
    "n",
    "r",
    "t"
  }
  do
    do
      for SRD1_6_, SRD1_7_ in ipairs(in_char) do
        s = s:gsub(SRD1_7_, "\\" .. out_char[SRD1_6_])
      end
    end
  end
  return s
end

local skip_delim = function(str, pos, delim, err_if_missing)
  pos = pos + #str:match("^%s*", pos)
  if str:sub(pos, pos) ~= delim then
    if err_if_missing then
      error("Esperado " .. delim .. " posição próxima " .. pos)
    end
    return pos, false
  end
  return pos + 1, true
end

local function parse_str_val(str, pos, val)
  val = val or ""
  local early_end_error = "Fim da entrada encontrado durante a análise da string."
  if pos > #str then
    error(early_end_error)
  end
  local c = str:sub(pos, pos)
  if c == "\"" then
    return val, pos + 1
  end
  if c ~= "\\" then
    return parse_str_val(str, pos + 1, val .. c)
  end
  local esc_map = {
    b = "\b",
    f = "\f",
    n = "\n",
    r = "\r",
    t = "\t"
  }
  local nextc = str:sub(pos + 1, pos + 1)
  if not nextc then
    error(early_end_error)
  end
  return parse_str_val(str, pos + 2, val .. (esc_map[nextc] or nextc))
end

local parse_num_val = function(str, pos)
  local num_str = str:match("^-?%d+%.?%d*[eE]?[+-]?%d*", pos)
  local val = tonumber(num_str)
  if not val then
    error("Erro ao analisar o número na posição " .. pos .. ".")
  end
  return val, pos + #num_str
end

function json.stringify(obj, as_key)
  local s = {}
  local kind = kind_of(obj)
  if kind == "array" then
    if as_key then
      error("Não é possível codificar array como chave.")
    end
    s[#s + 1] = "["
    do
      do
        for SRD1_7_, SRD1_8_ in ipairs(obj) do
          if SRD1_7_ > 1 then
            s[#s + 1] = ", "
          end
          s[#s + 1] = json.stringify(SRD1_8_)
        end
      end
    end
    s[#s + 1] = "]"
  elseif kind == "table" then
    if as_key then
      error("Não é possível codificar a tabela como chave.")
    end
    s[#s + 1] = "{"
    do
      do
        for SRD1_7_, SRD1_8_ in pairs(obj) do
          if #s > 1 then
            s[#s + 1] = ", "
          end
          s[#s + 1] = json.stringify(SRD1_7_, true)
          s[#s + 1] = ":"
          s[#s + 1] = json.stringify(SRD1_8_)
        end
      end
    end
    s[#s + 1] = "}"
  else
    if kind == "string" then
      do return "\"" .. escape_str(obj) .. "\"" end
      return
    end
    if kind == "number" then
      if as_key then
        return "\"" .. tostring(obj) .. "\""
      end
      do return tostring(obj) end
      return
    end
    if kind == "boolean" then
      do return tostring(obj) end
      return
    end
    if kind == "nil" then
      do return "null" end
      return
    end
    error("tipo unjsonificável,: " .. kind .. ".")
  end
  return table.concat(s)
end

json.null = {}
function json.parse(str, pos, end_delim)
  pos = pos or 1
  if pos > #str then
    error("Atingiu o fim inesperado da entrada ")
  end
  local pos = pos + #str:match("^%s*", pos)
  local first = str:sub(pos, pos)
  if first == "{" then
    do
      local obj, key, delim_found = {}, true, true
      pos = pos + 1
      while true do
        key, pos = json.parse(str, pos, "}")
        if key == nil then
          return obj, pos
        end
        if not delim_found then
          error("Vírgula faltando entre os itens do objeto.")
        end
        pos = skip_delim(str, pos, ":", true)
        obj[key], pos = json.parse(str, pos)
        pos, delim_found = skip_delim(str, pos, ",")
      end
    end
    return
  end
  if first == "[" then
    do
      local arr, val, delim_found = {}, true, true
      pos = pos + 1
      while true do
        val, pos = json.parse(str, pos, "]")
        if val == nil then
          return arr, pos
        end
        if not delim_found then
          error("Falta vírgula entre os itens do array.")
        end
        arr[#arr + 1] = val
        pos, delim_found = skip_delim(str, pos, ",")
      end
    end
    return
  end
  if first == "\"" then
    do return parse_str_val(str, pos + 1) end
    return
  end
  if first == "-" or first:match("%d") then
    do return parse_num_val(str, pos) end
    return
  end
  if first == end_delim then
    do return nil, pos + 1 end
    return
  end
  do
    local literals = {
      ["true"] = true,
      ["false"] = false,
      null = json.null
    }
    do
      do
        for SRD1_9_, SRD1_10_ in pairs(literals) do
          local lit_end = pos + #SRD1_9_ - 1
          if str:sub(pos, lit_end) == SRD1_9_ then
            return SRD1_10_, lit_end + 1
          end
        end
      end
    end
    local pos_info_str = "position " .. pos .. ": " .. str:sub(pos, pos + 10)
    error("Sintaxe json inválida começando em " .. pos_info_str)
  end
end

function enc(data, b)
  return (data:gsub(".", function(x)
    local r, b = "", x:byte()
    do
      do
        for SRD1_6_ = 8, 1, -1 do
          r = r .. (b % 2 ^ SRD1_6_ - b % 2 ^ (SRD1_6_ - 1) > 0 and "1" or "0")
        end
      end
    end
    return r
  end
  ) .. "0000"):gsub("%d%d%d?%d?%d?%d?", function(x)
    if #x < 6 then
      return ""
    end
    local c = 0
    do
      do
        for SRD1_5_ = 1, 6 do
          c = c + (x:sub(SRD1_5_, SRD1_5_) == "1" and 2 ^ (6 - SRD1_5_) or 0)
        end
      end
    end
    return b:sub(c + 1, c + 1)
  end
  ) .. ({
    "",
    "??",
    "?"
  })[#data % 3 + 1]
end

function dec(data, b)
  data = string.gsub(data, "[^" .. b .. "=]", "")
  return (data:gsub(".", function(x)
    if x == "?" then
      return ""
    end
    local r, f = "", b:find(x) - 1
    do
      do
        for SRD1_6_ = 6, 1, -1 do
          r = r .. (f % 2 ^ SRD1_6_ - f % 2 ^ (SRD1_6_ - 1) > 0 and "1" or "0")
        end
      end
    end
    return r
  end
  ):gsub("%d%d%d?%d?%d?%d?%d?%d?", function(x)
    if #x ~= 8 then
      return ""
    end
    local c = 0
    do
      do
        for SRD1_5_ = 1, 8 do
          c = c + (x:sub(SRD1_5_, SRD1_5_) == "1" and 2 ^ (8 - SRD1_5_) or 0)
        end
      end
    end
    return string.char(c)
  end
  ))
end

function rwmem(Address, SizeOrBuffer)
  assert(Address ~= nil, "[rwmem]: error, endereço fornecido é nulo.")
  _rw = {}
  if type(SizeOrBuffer) == "number" then
    _ = ""
    do
      do
        for SRD1_5_ = 1, SizeOrBuffer do
          _rw[SRD1_5_] = {
            address = Address - 1 + SRD1_5_,
            flags = gg.TYPE_BYTE
          }
        end
      end
    end
    do
      do
        for SRD1_5_, SRD1_6_ in ipairs(gg.getValues(_rw)) do
          if SRD1_6_.value == 0 and limit == true then
            return _
          end
          _ = _ .. string.format("%02X", SRD1_6_.value & 255)
        end
      end
    end
    return _
  end
  Byte = {}
  SizeOrBuffer:gsub("..", function(x)
    Byte[#Byte + 1] = x
    _rw[#Byte] = {
      address = Address - 1 + #Byte,
      flags = gg.TYPE_BYTE,
      value = x .. "h"
    }
  end
  )
  gg.setValues(_rw)
end

function hexdecode(hex)
  return (hex:gsub("%x%x", function(digits)
    return string.char(tonumber(digits, 16))
  end
  ))
end

function hexencode(str)
  return (str:gsub(".", function(char)
    return string.format("%2x", char:byte())
  end
  ))
end

function Dec2Hex(nValue)
  nHexVal = string.format("%X", nValue)
  sHexVal = nHexVal .. ""
  return sHexVal
end

function ToInteger(number)
  return math.floor(tonumber(number) or error("Não foi possível transmitir '" .. tostring(number) .. "' enumerar.'"))
end

function hc(data)
  io.open(gg.EXT_STORAGE .. "/Config HC.txt", "w"):write(data)
  gg.toast("Configuração Encontrada!")
end

function save2(data)
  io.open(gg.EXT_STORAGE .. "/Config Aqui.txt", "w"):write(json.stringify(data))
  gg.toast("Configuração Encontrada!")
end

function hc(data)
  io.open(gg.EXT_STORAGE .. "/Config HC.txt", "w"):write(data)
  gg.toast("Configuração Encontrada!")
end

function v2json(data)
  io.open(gg.EXT_STORAGE .. "/Config V2ray.txt", "w"):write(data)
end

  limit = true
  gg.clearResults()
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.setVisible(true)
  gg.searchNumber("h 3A 34 34 33 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: 443")
    hc_2 = true
  end
  if hc_2 then
  limit = false
    gg.searchNumber("h 3A 38 30 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 80")
      hc_3 = true
    end
  end
  if hc_3 then
  limit = false
    gg.searchNumber("h 3A 38 30 38 30 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 8080")
      hc_4 = true
    end
  end
  if hc_4 then
  limit = false
    gg.searchNumber("h 3a 32 32 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 22")
      hc_5 = true
    end
  end
  if hc_5 then
    limit = false
    gg.searchNumber("h 3a 32 32 32 32 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 2222")
      hc_6 = true
    end
  end
  if hc_6 then
    limit = false
    gg.searchNumber("h 3a 34 34 34 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 444")
      hc_7 = true
    end
  end
  if hc_7 then
    limit = false
    gg.searchNumber("h 3A 35 33 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 53")
      hc_8 = true
    end
  end
  if hc_8 then
    limit = false
    gg.searchNumber("h 3a 31 31 39 34 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 1194")
      hc_9 = true
    end
  end
  if hc_9 then
    limit = false
    gg.searchNumber("h 3a 38 37 39 39 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 8799")
      hc_10 = true
    end
  end
  if hc_10 then
    limit = false
    gg.searchNumber("h 3a 38 30 38 38 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 8088")
      hc_11 = true
    end
  end
  if hc_11 then
    limit = false
    gg.searchNumber("h 3a 32 30 35 32 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 2052")
      hc_12 = true
    end
  end
  if hc_12 then
    limit = false
    gg.searchNumber("h 3a 32 30 35 32 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 143")
      hc_13 = true
    end
  end
  if hc_13 then
    limit = false
    gg.searchNumber("h 3a 32 30 38 32 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 2082")
      hc_14 = true
    end
  end
  if hc_14 then
    limit = false
    gg.searchNumber("h 3a 34 34 32 40", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: 442")
      hc_15 = true
    end
  end
  if hc_15 then
    limit = false
    gg.searchNumber("h 2e 6d 79 2e 69 64 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: my id")
      hc_16 = true
    end
  end
  if hc_16 then
    limit = false
    gg.searchNumber("h 2e 6f 6e 6c 69 6e 65 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: online")
      hc_17 = true
    end
  end
  if hc_17 then
    limit = false
    gg.searchNumber("h 2e 6e 65 74 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: net")
      hc_18 = true
    end
  end
  if hc_18 then
    limit = false
    gg.searchNumber("h 2e 6d 6c 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: ml")
      hc_19 = true
    end
  end
  if hc_19 then
    limit = false
    gg.searchNumber("h 2e 63 6c 6f 75 64 66 72 6f 6e 74 2e 6e 65 74 3a", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: cloudfront")
      hc_20 = true
    end
  end
  if hc_20 then
    gg.toast("❌Configuração Não Encontrada")
    print("importe o Arquivo Novamente!!!\n")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == false then
    r[1].address = r[1].address - 1000
  end
  readedMem = rwmem(r[1].address, 50000)
  hc(hexdecode(readedMem))
  gg.toast("Aplicativo Desbloqueado")
  print("Configuração Encontrada!\n\no arquivo está em: /sdcard/Config HC.txt")
  gg.clearResults()
os.exit()
pcall(load(hc))
prima()
end

function Payload()

limit = false

local utf8 = {}
local bit = {
  data32 = {}
}
do
  do
    for SRD1_5_ = 1, 32 do
      bit.data32[SRD1_5_] = 2 ^ (32 - SRD1_5_)
    end
  end
end
local toby = string.byte
function utf8.charbytes(s, i)
  i = i or 1
  local c = string.byte(s, i)
  if c > 0 and c <= 127 then
    do return 1 end
    return
  end
  if c >= 194 and c <= 223 then
    do return 2 end
    return
  end
  if c >= 224 and c <= 239 then
    do return 3 end
    return
  end
  if c >= 240 and c <= 244 then
    return 4
  end
  return 1
end

local ded
function bit:d2b(arg)
  if arg == nil then
    return
  end
  local tr, c = {}, arg < 0
  if c then
    arg = 0 - arg
  end
  do
    do
      for SRD1_7_ = 1, 32 do
        if arg >= self.data32[SRD1_7_] then
          tr[SRD1_7_] = 1
          arg = arg - self.data32[SRD1_7_]
        else
          tr[SRD1_7_] = 0
        end
      end
    end
  end
  if c then
    tr = self:_bnot(tr)
    tr = self:b2d(tr) + 1
    tr = self:d2b(tr)
  end
  return tr
end

function bit:b2d(arg, neg)
  local nr = 0
  if arg[1] == 1 and neg == true then
    arg = self:_bnot(arg)
    nr = self:b2d(arg) + 1
    nr = 0 - nr
  else
    do
      for SRD1_7_ = 1, 32 do
        if arg[SRD1_7_] == 1 then
          nr = nr + 2 ^ (32 - SRD1_7_)
        end
      end
    end
  end
  return nr
end

function bit:_and(a, b)
  local op1 = self:d2b(a)
  local op2 = self:d2b(b)
  local r = {}
  do
    do
      for SRD1_9_ = 1, 32 do
        if op1[SRD1_9_] == 1 and op2[SRD1_9_] == 1 then
          r[SRD1_9_] = 1
        else
          r[SRD1_9_] = 0
        end
      end
    end
  end
  return self:b2d(r, true)
end

function bit:_or(a, b)
  local op1 = self:d2b(a)
  local op2 = self:d2b(b)
  local r = {}
  do
    do
      for SRD1_9_ = 1, 32 do
        if op1[SRD1_9_] == 1 or op2[SRD1_9_] == 1 then
          r[SRD1_9_] = 1
        else
          r[SRD1_9_] = 0
        end
      end
    end
  end
  return self:b2d(r, true)
end

function bit:_xor(a, b)
  local op1 = self:d2b(a)
  if op1 == nil then
    return nil
  end
  local op2 = self:d2b(b)
  if op2 == nil then
    return nil
  end
  local r = {}
  do
    do
      for SRD1_9_ = 1, 32 do
        if op1[SRD1_9_] == op2[SRD1_9_] then
          r[SRD1_9_] = 0
        else
          r[SRD1_9_] = 1
        end
      end
    end
  end
  return self:b2d(r, true)
end

local switch = {
  [1] = function(s, pos)
    local c1 = toby(s, pos)
    return c1
  end
  ,
  [2] = function(s, pos)
    local c1 = toby(s, pos)
    local c2 = toby(s, pos + 1)
    local int1 = bit:_and(31, c1)
    local int2 = bit:_and(63, c2)
    return bit:_or(bit:_lshift(int1, 6), int2)
  end
  ,
  [3] = function(s, pos)
    local c1 = toby(s, pos)
    local c2 = toby(s, pos + 1)
    local c3 = toby(s, pos + 2)
    local int1 = bit:_and(15, c1)
    local int2 = bit:_and(63, c2)
    local int3 = bit:_and(63, c3)
    local o2 = bit:_or(bit:_lshift(int1, 12), bit:_lshift(int2, 6))
    local dt = bit:_or(o2, int3)
    return dt
  end
  ,
  [4] = function(s, pos)
    local c1 = toby(s, pos)
    local c2 = toby(s, pos + 1)
    local c3 = toby(s, pos + 2)
    local c4 = toby(s, pos + 3)
    local int1 = bit:_and(15, c1)
    local int2 = bit:_and(63, c2)
    local int3 = bit:_and(63, c3)
    local int4 = bit:_and(63, c4)
    local o2 = bit:_or(bit:_lshift(int1, 18), bit:_lshift(int2, 12))
    local o3 = bit:_or(o2, bit:_lshift(int3, 6))
    local o4 = bit:_or(o3, int4)
    return o4
  end
  
}
function bit:_bnot(op1)
  local r = {}
  do
    do
      for SRD1_6_ = 1, 32 do
        if op1[SRD1_6_] == 1 then
          r[SRD1_6_] = 0
        else
          r[SRD1_6_] = 1
        end
      end
    end
  end
  return r
end

function bit:_not(a)
  local op1 = self:d2b(a)
  local r = self:_bnot(op1)
  return self:b2d(r, true)
end

function bit:charCodeAt(s)
  local pos, int, H, L = 1, 0, 0, 0
  local slen = string.len(s)
  local allByte = {}
  while pos <= slen do
    local tLen = utf8.charbytes(s, pos)
    if tLen >= 1 and tLen <= 4 then
      if tLen == 4 then
        int = switch[4](s, pos)
        H = math.floor((int - 65536) / 1024) + 55296
        L = (int - 65536) % 1024 + 56320
        table.insert(allByte, H)
        table.insert(allByte, L)
      else
        int = switch[tLen](s, pos)
        table.insert(allByte, int)
      end
    end
    pos = pos + tLen
  end
  return allByte
end

function bit:_rshift(a, n)
  local r = 0
  if a < 0 then
    r = 0 - self:_frshift(0 - a, n)
  elseif a >= 0 then
    r = self:_frshift(a, n)
  end
  return r
end

function bit:_frshift(a, n)
  local op1 = self:d2b(a)
  local r = self:d2b(0)
  local left = 32 - n
  if n < 32 and n > 0 then
    do
      for SRD1_9_ = left, 1, -1 do
        r[SRD1_9_ + n] = op1[SRD1_9_]
      end
    end
  end
  return self:b2d(r)
end

function bit:_lshift(a, n)
  local op1 = self:d2b(a)
  local r = self:d2b(0)
  if n < 32 and n > 0 then
    do
      for SRD1_8_ = n, 31 do
        r[SRD1_8_ - n + 1] = op1[SRD1_8_ + 1]
      end
    end
  end
  return self:b2d(r, true)
end

function trim(s)
  return s:match("^%s*(.*)"):match("(.-)%s*$")
end

local json = {}
local kind_of = function(obj)
  if type(obj) ~= "table" then
    return type(obj)
  end
  local i = 1
  do
    do
      for SRD1_5_ in pairs(obj) do
        if obj[i] ~= nil then
          i = i + 1
        else
          return "table"
        end
      end
    end
  end
  if i == 1 then
    do return "table" end
    return
  end
  return "array"
end

local escape_str = function(s)
  local in_char = {
    "\\",
    "\"",
    "/",
    "\b",
    "\f",
    "\n",
    "\r",
    "\t"
  }
  local out_char = {
    "\\",
    "\"",
    "/",
    "b",
    "f",
    "n",
    "r",
    "t"
  }
  do
    do
      for SRD1_6_, SRD1_7_ in ipairs(in_char) do
        s = s:gsub(SRD1_7_, "\\" .. out_char[SRD1_6_])
      end
    end
  end
  return s
end

local skip_delim = function(str, pos, delim, err_if_missing)
  pos = pos + #str:match("^%s*", pos)
  if str:sub(pos, pos) ~= delim then
    if err_if_missing then
      error("Esperado " .. delim .. " posição próxima " .. pos)
    end
    return pos, false
  end
  return pos + 1, true
end

local function parse_str_val(str, pos, val)
  val = val or ""
  local early_end_error = "Fim da entrada encontrado durante a análise da string."
  if pos > #str then
    error(early_end_error)
  end
  local c = str:sub(pos, pos)
  if c == "\"" then
    return val, pos + 1
  end
  if c ~= "\\" then
    return parse_str_val(str, pos + 1, val .. c)
  end
  local esc_map = {
    b = "\b",
    f = "\f",
    n = "\n",
    r = "\r",
    t = "\t"
  }
  local nextc = str:sub(pos + 1, pos + 1)
  if not nextc then
    error(early_end_error)
  end
  return parse_str_val(str, pos + 2, val .. (esc_map[nextc] or nextc))
end

local parse_num_val = function(str, pos)
  local num_str = str:match("^-?%d+%.?%d*[eE]?[+-]?%d*", pos)
  local val = tonumber(num_str)
  if not val then
    error("Erro ao analisar o número na posição " .. pos .. ".")
  end
  return val, pos + #num_str
end

function json.stringify(obj, as_key)
  local s = {}
  local kind = kind_of(obj)
  if kind == "array" then
    if as_key then
      error("Não é possível codificar array como chave.")
    end
    s[#s + 1] = "["
    do
      do
        for SRD1_7_, SRD1_8_ in ipairs(obj) do
          if SRD1_7_ > 1 then
            s[#s + 1] = ", "
          end
          s[#s + 1] = json.stringify(SRD1_8_)
        end
      end
    end
    s[#s + 1] = "]"
  elseif kind == "table" then
    if as_key then
      error("Não é possível codificar a tabela como chave.")
    end
    s[#s + 1] = "{"
    do
      do
        for SRD1_7_, SRD1_8_ in pairs(obj) do
          if #s > 1 then
            s[#s + 1] = ", "
          end
          s[#s + 1] = json.stringify(SRD1_7_, true)
          s[#s + 1] = ":"
          s[#s + 1] = json.stringify(SRD1_8_)
        end
      end
    end
    s[#s + 1] = "}"
  else
    if kind == "string" then
      do return "\"" .. escape_str(obj) .. "\"" end
      return
    end
    if kind == "number" then
      if as_key then
        return "\"" .. tostring(obj) .. "\""
      end
      do return tostring(obj) end
      return
    end
    if kind == "boolean" then
      do return tostring(obj) end
      return
    end
    if kind == "nil" then
      do return "null" end
      return
    end
    error("tipo unjsonificável,: " .. kind .. ".")
  end
  return table.concat(s)
end

json.null = {}
function json.parse(str, pos, end_delim)
  pos = pos or 1
  if pos > #str then
    error("Atingiu o fim inesperado da entrada ")
  end
  local pos = pos + #str:match("^%s*", pos)
  local first = str:sub(pos, pos)
  if first == "{" then
    do
      local obj, key, delim_found = {}, true, true
      pos = pos + 1
      while true do
        key, pos = json.parse(str, pos, "}")
        if key == nil then
          return obj, pos
        end
        if not delim_found then
          error("Vírgula faltando entre os itens do objeto.")
        end
        pos = skip_delim(str, pos, ":", true)
        obj[key], pos = json.parse(str, pos)
        pos, delim_found = skip_delim(str, pos, ",")
      end
    end
    return
  end
  if first == "[" then
    do
      local arr, val, delim_found = {}, true, true
      pos = pos + 1
      while true do
        val, pos = json.parse(str, pos, "]")
        if val == nil then
          return arr, pos
        end
        if not delim_found then
          error("Falta vírgula entre os itens do array.")
        end
        arr[#arr + 1] = val
        pos, delim_found = skip_delim(str, pos, ",")
      end
    end
    return
  end
  if first == "\"" then
    do return parse_str_val(str, pos + 1) end
    return
  end
  if first == "-" or first:match("%d") then
    do return parse_num_val(str, pos) end
    return
  end
  if first == end_delim then
    do return nil, pos + 1 end
    return
  end
  do
    local literals = {
      ["true"] = true,
      ["false"] = false,
      null = json.null
    }
    do
      do
        for SRD1_9_, SRD1_10_ in pairs(literals) do
          local lit_end = pos + #SRD1_9_ - 1
          if str:sub(pos, lit_end) == SRD1_9_ then
            return SRD1_10_, lit_end + 1
          end
        end
      end
    end
    local pos_info_str = "position " .. pos .. ": " .. str:sub(pos, pos + 10)
    error("Sintaxe json inválida começando em " .. pos_info_str)
  end
end

function enc(data, b)
  return (data:gsub(".", function(x)
    local r, b = "", x:byte()
    do
      do
        for SRD1_6_ = 8, 1, -1 do
          r = r .. (b % 2 ^ SRD1_6_ - b % 2 ^ (SRD1_6_ - 1) > 0 and "1" or "0")
        end
      end
    end
    return r
  end
  ) .. "0000"):gsub("%d%d%d?%d?%d?%d?", function(x)
    if #x < 6 then
      return ""
    end
    local c = 0
    do
      do
        for SRD1_5_ = 1, 6 do
          c = c + (x:sub(SRD1_5_, SRD1_5_) == "1" and 2 ^ (6 - SRD1_5_) or 0)
        end
      end
    end
    return b:sub(c + 1, c + 1)
  end
  ) .. ({
    "",
    "??",
    "?"
  })[#data % 3 + 1]
end

function dec(data, b)
  data = string.gsub(data, "[^" .. b .. "=]", "")
  return (data:gsub(".", function(x)
    if x == "?" then
      return ""
    end
    local r, f = "", b:find(x) - 1
    do
      do
        for SRD1_6_ = 6, 1, -1 do
          r = r .. (f % 2 ^ SRD1_6_ - f % 2 ^ (SRD1_6_ - 1) > 0 and "1" or "0")
        end
      end
    end
    return r
  end
  ):gsub("%d%d%d?%d?%d?%d?%d?%d?", function(x)
    if #x ~= 8 then
      return ""
    end
    local c = 0
    do
      do
        for SRD1_5_ = 1, 8 do
          c = c + (x:sub(SRD1_5_, SRD1_5_) == "1" and 2 ^ (8 - SRD1_5_) or 0)
        end
      end
    end
    return string.char(c)
  end
  ))
end

function rwmem(Address, SizeOrBuffer)
  assert(Address ~= nil, "[rwmem]: error, endereço fornecido é nulo.")
  _rw = {}
  if type(SizeOrBuffer) == "number" then
    _ = ""
    do
      do
        for SRD1_5_ = 1, SizeOrBuffer do
          _rw[SRD1_5_] = {
            address = Address - 1 + SRD1_5_,
            flags = gg.TYPE_BYTE
          }
        end
      end
    end
    do
      do
        for SRD1_5_, SRD1_6_ in ipairs(gg.getValues(_rw)) do
          if SRD1_6_.value == 0 and limit == true then
            return _
          end
          _ = _ .. string.format("%02X", SRD1_6_.value & 255)
        end
      end
    end
    return _
  end
  Byte = {}
  SizeOrBuffer:gsub("..", function(x)
    Byte[#Byte + 1] = x
    _rw[#Byte] = {
      address = Address - 1 + #Byte,
      flags = gg.TYPE_BYTE,
      value = x .. "h"
    }
  end
  )
  gg.setValues(_rw)
end

function hexdecode(hex)
  return (hex:gsub("%x%x", function(digits)
    return string.char(tonumber(digits, 16))
  end
  ))
end

function hexencode(str)
  return (str:gsub(".", function(char)
    return string.format("%2x", char:byte())
  end
  ))
end

function Dec2Hex(nValue)
  nHexVal = string.format("%X", nValue)
  sHexVal = nHexVal .. ""
  return sHexVal
end

function ToInteger(number)
  return math.floor(tonumber(number) or error("❌ Não foi possível transmitir '" .. tostring(number) .. "' enumerar.'"))
end

function payload(data)
  io.open(gg.EXT_STORAGE .. "/Config Aqui.txt", "w"):write(data)
  gg.toast("✅ Configuração Encontrada!")
end

function save2(data)
  io.open(gg.EXT_STORAGE .. "/Config Aqui.txt", "w"):write(json.stringify(data))
  gg.toast("✅ Configuração Encontrada!")
end

function Payload(data)
  io.open(gg.EXT_STORAGE .. "/Config Aqui.txt", "w"):write(data)
  gg.toast("✅ Configuração Encontrada!")
end

function v2json(data)
  io.open(gg.EXT_STORAGE .. "/Config Aqui.txt", "w"):write(data)
end

function teste(data)
  io.open(gg.EXT_STORAGE .. "/Config Aqui.txt", "w"):write(data)
  gg.toast("✅ Configuração Encontrada!")
end


limit = false

  gg.clearResults()
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.setVisible(true)
  gg.searchNumber("h 7B 0A 20 20 20 20 22 56 65 72 73 69 6F 6E", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: Version")
    hc_2 = true
  end
  if hc_2 then
    gg.searchNumber("h 22 56 65 72 73 69 6F 6E 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Version")
      hc_3 = true
    end
end
if hc_3 then
    gg.searchNumber("h 22 73 74 61 74 75 73 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: Version")
      hc_4 = true
    end
  end
  if hc_4 then
    gg.toast("❌Configuração Não Encontrada")
    print("Clique em Update e Inicie o Script Rápido!!!\n")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == false then
    r[1].address = r[1].address - 1000    
  end
  readedMem = rwmem(r[1].address, 60000)
  payload(hexdecode(readedMem))
  gg.toast("✅ Configuração Encontrado")
  print("✅ Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
  gg.clearResults()
  gg.toast("@netfree080")
  print("\n@netfree080\n\n")
gg.clearResults()
os.exit()
pcall(load(Payload))
prima()
end
 
function link()
limit = false

local utf8 = {}
local bit = {
  data32 = {}
}
do
  do
    for SRD1_5_ = 1, 32 do
      bit.data32[SRD1_5_] = 2 ^ (32 - SRD1_5_)
    end
  end
end
local toby = string.byte
function utf8.charbytes(s, i)
  i = i or 1
  local c = string.byte(s, i)
  if c > 0 and c <= 127 then
    do return 1 end
    return
  end
  if c >= 194 and c <= 223 then
    do return 2 end
    return
  end
  if c >= 224 and c <= 239 then
    do return 3 end
    return
  end
  if c >= 240 and c <= 244 then
    return 4
  end
  return 1
end

local ded
function bit:d2b(arg)
  if arg == nil then
    return
  end
  local tr, c = {}, arg < 0
  if c then
    arg = 0 - arg
  end
  do
    do
      for SRD1_7_ = 1, 32 do
        if arg >= self.data32[SRD1_7_] then
          tr[SRD1_7_] = 1
          arg = arg - self.data32[SRD1_7_]
        else
          tr[SRD1_7_] = 0
        end
      end
    end
  end
  if c then
    tr = self:_bnot(tr)
    tr = self:b2d(tr) + 1
    tr = self:d2b(tr)
  end
  return tr
end

function bit:b2d(arg, neg)
  local nr = 0
  if arg[1] == 1 and neg == true then
    arg = self:_bnot(arg)
    nr = self:b2d(arg) + 1
    nr = 0 - nr
  else
    do
      for SRD1_7_ = 1, 32 do
        if arg[SRD1_7_] == 1 then
          nr = nr + 2 ^ (32 - SRD1_7_)
        end
      end
    end
  end
  return nr
end

function bit:_and(a, b)
  local op1 = self:d2b(a)
  local op2 = self:d2b(b)
  local r = {}
  do
    do
      for SRD1_9_ = 1, 32 do
        if op1[SRD1_9_] == 1 and op2[SRD1_9_] == 1 then
          r[SRD1_9_] = 1
        else
          r[SRD1_9_] = 0
        end
      end
    end
  end
  return self:b2d(r, true)
end

function bit:_or(a, b)
  local op1 = self:d2b(a)
  local op2 = self:d2b(b)
  local r = {}
  do
    do
      for SRD1_9_ = 1, 32 do
        if op1[SRD1_9_] == 1 or op2[SRD1_9_] == 1 then
          r[SRD1_9_] = 1
        else
          r[SRD1_9_] = 0
        end
      end
    end
  end
  return self:b2d(r, true)
end

function bit:_xor(a, b)
  local op1 = self:d2b(a)
  if op1 == nil then
    return nil
  end
  local op2 = self:d2b(b)
  if op2 == nil then
    return nil
  end
  local r = {}
  do
    do
      for SRD1_9_ = 1, 32 do
        if op1[SRD1_9_] == op2[SRD1_9_] then
          r[SRD1_9_] = 0
        else
          r[SRD1_9_] = 1
        end
      end
    end
  end
  return self:b2d(r, true)
end

local switch = {
  [1] = function(s, pos)
    local c1 = toby(s, pos)
    return c1
  end
  ,
  [2] = function(s, pos)
    local c1 = toby(s, pos)
    local c2 = toby(s, pos + 1)
    local int1 = bit:_and(31, c1)
    local int2 = bit:_and(63, c2)
    return bit:_or(bit:_lshift(int1, 6), int2)
  end
  ,
  [3] = function(s, pos)
    local c1 = toby(s, pos)
    local c2 = toby(s, pos + 1)
    local c3 = toby(s, pos + 2)
    local int1 = bit:_and(15, c1)
    local int2 = bit:_and(63, c2)
    local int3 = bit:_and(63, c3)
    local o2 = bit:_or(bit:_lshift(int1, 12), bit:_lshift(int2, 6))
    local dt = bit:_or(o2, int3)
    return dt
  end
  ,
  [4] = function(s, pos)
    local c1 = toby(s, pos)
    local c2 = toby(s, pos + 1)
    local c3 = toby(s, pos + 2)
    local c4 = toby(s, pos + 3)
    local int1 = bit:_and(15, c1)
    local int2 = bit:_and(63, c2)
    local int3 = bit:_and(63, c3)
    local int4 = bit:_and(63, c4)
    local o2 = bit:_or(bit:_lshift(int1, 18), bit:_lshift(int2, 12))
    local o3 = bit:_or(o2, bit:_lshift(int3, 6))
    local o4 = bit:_or(o3, int4)
    return o4
  end
  
}
function bit:_bnot(op1)
  local r = {}
  do
    do
      for SRD1_6_ = 1, 32 do
        if op1[SRD1_6_] == 1 then
          r[SRD1_6_] = 0
        else
          r[SRD1_6_] = 1
        end
      end
    end
  end
  return r
end

function bit:_not(a)
  local op1 = self:d2b(a)
  local r = self:_bnot(op1)
  return self:b2d(r, true)
end

function bit:charCodeAt(s)
  local pos, int, H, L = 1, 0, 0, 0
  local slen = string.len(s)
  local allByte = {}
  while pos <= slen do
    local tLen = utf8.charbytes(s, pos)
    if tLen >= 1 and tLen <= 4 then
      if tLen == 4 then
        int = switch[4](s, pos)
        H = math.floor((int - 65536) / 1024) + 55296
        L = (int - 65536) % 1024 + 56320
        table.insert(allByte, H)
        table.insert(allByte, L)
      else
        int = switch[tLen](s, pos)
        table.insert(allByte, int)
      end
    end
    pos = pos + tLen
  end
  return allByte
end

function bit:_rshift(a, n)
  local r = 0
  if a < 0 then
    r = 0 - self:_frshift(0 - a, n)
  elseif a >= 0 then
    r = self:_frshift(a, n)
  end
  return r
end

function bit:_frshift(a, n)
  local op1 = self:d2b(a)
  local r = self:d2b(0)
  local left = 32 - n
  if n < 32 and n > 0 then
    do
      for SRD1_9_ = left, 1, -1 do
        r[SRD1_9_ + n] = op1[SRD1_9_]
      end
    end
  end
  return self:b2d(r)
end

function bit:_lshift(a, n)
  local op1 = self:d2b(a)
  local r = self:d2b(0)
  if n < 32 and n > 0 then
    do
      for SRD1_8_ = n, 31 do
        r[SRD1_8_ - n + 1] = op1[SRD1_8_ + 1]
      end
    end
  end
  return self:b2d(r, true)
end

function trim(s)
  return s:match("^%s*(.*)"):match("(.-)%s*$")
end

local json = {}
local kind_of = function(obj)
  if type(obj) ~= "table" then
    return type(obj)
  end
  local i = 1
  do
    do
      for SRD1_5_ in pairs(obj) do
        if obj[i] ~= nil then
          i = i + 1
        else
          return "table"
        end
      end
    end
  end
  if i == 1 then
    do return "table" end
    return
  end
  return "array"
end

local escape_str = function(s)
  local in_char = {
    "\\",
    "\"",
    "/",
    "\b",
    "\f",
    "\n",
    "\r",
    "\t"
  }
  local out_char = {
    "\\",
    "\"",
    "/",
    "b",
    "f",
    "n",
    "r",
    "t"
  }
  do
    do
      for SRD1_6_, SRD1_7_ in ipairs(in_char) do
        s = s:gsub(SRD1_7_, "\\" .. out_char[SRD1_6_])
      end
    end
  end
  return s
end

local skip_delim = function(str, pos, delim, err_if_missing)
  pos = pos + #str:match("^%s*", pos)
  if str:sub(pos, pos) ~= delim then
    if err_if_missing then
      error("Esperado " .. delim .. " posição próxima " .. pos)
    end
    return pos, false
  end
  return pos + 1, true
end

local function parse_str_val(str, pos, val)
  val = val or ""
  local early_end_error = "Fim da entrada encontrado durante a análise da string."
  if pos > #str then
    error(early_end_error)
  end
  local c = str:sub(pos, pos)
  if c == "\"" then
    return val, pos + 1
  end
  if c ~= "\\" then
    return parse_str_val(str, pos + 1, val .. c)
  end
  local esc_map = {
    b = "\b",
    f = "\f",
    n = "\n",
    r = "\r",
    t = "\t"
  }
  local nextc = str:sub(pos + 1, pos + 1)
  if not nextc then
    error(early_end_error)
  end
  return parse_str_val(str, pos + 2, val .. (esc_map[nextc] or nextc))
end

local parse_num_val = function(str, pos)
  local num_str = str:match("^-?%d+%.?%d*[eE]?[+-]?%d*", pos)
  local val = tonumber(num_str)
  if not val then
    error("Erro ao analisar o número na posição " .. pos .. ".")
  end
  return val, pos + #num_str
end

function json.stringify(obj, as_key)
  local s = {}
  local kind = kind_of(obj)
  if kind == "array" then
    if as_key then
      error("Não é possível codificar array como chave.")
    end
    s[#s + 1] = "["
    do
      do
        for SRD1_7_, SRD1_8_ in ipairs(obj) do
          if SRD1_7_ > 1 then
            s[#s + 1] = ", "
          end
          s[#s + 1] = json.stringify(SRD1_8_)
        end
      end
    end
    s[#s + 1] = "]"
  elseif kind == "table" then
    if as_key then
      error("Não é possível codificar a tabela como chave.")
    end
    s[#s + 1] = "{"
    do
      do
        for SRD1_7_, SRD1_8_ in pairs(obj) do
          if #s > 1 then
            s[#s + 1] = ", "
          end
          s[#s + 1] = json.stringify(SRD1_7_, true)
          s[#s + 1] = ":"
          s[#s + 1] = json.stringify(SRD1_8_)
        end
      end
    end
    s[#s + 1] = "}"
  else
    if kind == "string" then
      do return "\"" .. escape_str(obj) .. "\"" end
      return
    end
    if kind == "number" then
      if as_key then
        return "\"" .. tostring(obj) .. "\""
      end
      do return tostring(obj) end
      return
    end
    if kind == "boolean" then
      do return tostring(obj) end
      return
    end
    if kind == "nil" then
      do return "null" end
      return
    end
    error("tipo unjsonificável,: " .. kind .. ".")
  end
  return table.concat(s)
end

json.null = {}
function json.parse(str, pos, end_delim)
  pos = pos or 1
  if pos > #str then
    error("Atingiu o fim inesperado da entrada ")
  end
  local pos = pos + #str:match("^%s*", pos)
  local first = str:sub(pos, pos)
  if first == "{" then
    do
      local obj, key, delim_found = {}, true, true
      pos = pos + 1
      while true do
        key, pos = json.parse(str, pos, "}")
        if key == nil then
          return obj, pos
        end
        if not delim_found then
          error("Vírgula faltando entre os itens do objeto.")
        end
        pos = skip_delim(str, pos, ":", true)
        obj[key], pos = json.parse(str, pos)
        pos, delim_found = skip_delim(str, pos, ",")
      end
    end
    return
  end
  if first == "[" then
    do
      local arr, val, delim_found = {}, true, true
      pos = pos + 1
      while true do
        val, pos = json.parse(str, pos, "]")
        if val == nil then
          return arr, pos
        end
        if not delim_found then
          error("Falta vírgula entre os itens do array.")
        end
        arr[#arr + 1] = val
        pos, delim_found = skip_delim(str, pos, ",")
      end
    end
    return
  end
  if first == "\"" then
    do return parse_str_val(str, pos + 1) end
    return
  end
  if first == "-" or first:match("%d") then
    do return parse_num_val(str, pos) end
    return
  end
  if first == end_delim then
    do return nil, pos + 1 end
    return
  end
  do
    local literals = {
      ["true"] = true,
      ["false"] = false,
      null = json.null
    }
    do
      do
        for SRD1_9_, SRD1_10_ in pairs(literals) do
          local lit_end = pos + #SRD1_9_ - 1
          if str:sub(pos, lit_end) == SRD1_9_ then
            return SRD1_10_, lit_end + 1
          end
        end
      end
    end
    local pos_info_str = "position " .. pos .. ": " .. str:sub(pos, pos + 10)
    error("Sintaxe json inválida começando em " .. pos_info_str)
  end
end

function enc(data, b)
  return (data:gsub(".", function(x)
    local r, b = "", x:byte()
    do
      do
        for SRD1_6_ = 8, 1, -1 do
          r = r .. (b % 2 ^ SRD1_6_ - b % 2 ^ (SRD1_6_ - 1) > 0 and "1" or "0")
        end
      end
    end
    return r
  end
  ) .. "0000"):gsub("%d%d%d?%d?%d?%d?", function(x)
    if #x < 6 then
      return ""
    end
    local c = 0
    do
      do
        for SRD1_5_ = 1, 6 do
          c = c + (x:sub(SRD1_5_, SRD1_5_) == "1" and 2 ^ (6 - SRD1_5_) or 0)
        end
      end
    end
    return b:sub(c + 1, c + 1)
  end
  ) .. ({
    "",
    "??",
    "?"
  })[#data % 3 + 1]
end

function dec(data, b)
  data = string.gsub(data, "[^" .. b .. "=]", "")
  return (data:gsub(".", function(x)
    if x == "?" then
      return ""
    end
    local r, f = "", b:find(x) - 1
    do
      do
        for SRD1_6_ = 6, 1, -1 do
          r = r .. (f % 2 ^ SRD1_6_ - f % 2 ^ (SRD1_6_ - 1) > 0 and "1" or "0")
        end
      end
    end
    return r
  end
  ):gsub("%d%d%d?%d?%d?%d?%d?%d?", function(x)
    if #x ~= 8 then
      return ""
    end
    local c = 0
    do
      do
        for SRD1_5_ = 1, 8 do
          c = c + (x:sub(SRD1_5_, SRD1_5_) == "1" and 2 ^ (8 - SRD1_5_) or 0)
        end
      end
    end
    return string.char(c)
  end
  ))
end

function rwmem(Address, SizeOrBuffer)
  assert(Address ~= nil, "[rwmem]: error, endereço fornecido é nulo.")
  _rw = {}
  if type(SizeOrBuffer) == "number" then
    _ = ""
    do
      do
        for SRD1_5_ = 1, SizeOrBuffer do
          _rw[SRD1_5_] = {
            address = Address - 1 + SRD1_5_,
            flags = gg.TYPE_BYTE
          }
        end
      end
    end
    do
      do
        for SRD1_5_, SRD1_6_ in ipairs(gg.getValues(_rw)) do
          if SRD1_6_.value == 0 and limit == true then
            return _
          end
          _ = _ .. string.format("%02X", SRD1_6_.value & 255)
        end
      end
    end
    return _
  end
  Byte = {}
  SizeOrBuffer:gsub("..", function(x)
    Byte[#Byte + 1] = x
    _rw[#Byte] = {
      address = Address - 1 + #Byte,
      flags = gg.TYPE_BYTE,
      value = x .. "h"
    }
  end
  )
  gg.setValues(_rw)
end

function hexdecode(hex)
  return (hex:gsub("%x%x", function(digits)
    return string.char(tonumber(digits, 16))
  end
  ))
end

function hexencode(str)
  return (str:gsub(".", function(char)
    return string.format("%2x", char:byte())
  end
  ))
end

function Dec2Hex(nValue)
  nHexVal = string.format("%X", nValue)
  sHexVal = nHexVal .. ""
  return sHexVal
end

function ToInteger(number)
  return math.floor(tonumber(number) or error("Não foi possível transmitir '" .. tostring(number) .. "' enumerar.'"))
end

function link(data)
  io.open(gg.EXT_STORAGE .. "/Link Update Aqui.txt", "w"):write(data)
  gg.toast("te peguei Lionel Richie!")
end 

limit = false

  gg.clearResults()
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.setVisible(true)
  gg.searchNumber("h 68 74 74 70 73 3A 2F 2F 70 61 73 74 65 2E 61 6E 61 73 6F 72 2E 63 6F 6D 2F 70 61 73 74 65 2E 70 68 70 3F 72 61 77 26 69 64 3D", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada")
    hc_2 = true
  end
  if hc_2 then
    gg.searchNumber("h 68 74 74 70 73 3A 2F 2F 70 61 73 74 65 62 69 6E 2E 63 6F 6D 2F 72 61 77 2F", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada")
      hc_3 = true
    end
end
if hc_3 then
    gg.searchNumber("h 68 74 74 70 73 3A 2F 2F 70 74 2E 74 65 78 74 62 69 6E 2E 6E 65 74 2F 72 61 77 2F", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada")
      hc_4 = true
    end
  end
  if hc_4 then
    gg.searchNumber("h 68 74 74 70 73 3A 2F 2F 62 69 74 62 69 6E 2E 69 74 2F", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada")
      hc_5 = true
    end
  end
  if hc_5 then
    gg.searchNumber("h 68 74 74 70 73 3A 2F 2F 77 77 77 2E 64 72 6F 70 62 6F 78 2E 63 6F 6D 2F", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada")
      hc_6 = true
    end
  end
    if hc_6 then
    gg.searchNumber("h 68 74 74 70 73 3A 2F 2F 72 61 77 2E 67 69 74 68 75 62 75 73 65 72 63 6F 6E 74 65 6E 74 2E 63 6F 6D 2F", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada")
      hc_7 = true
    end
  end
      if hc_7 then
    gg.searchNumber("h 68 74 74 70 73 3A 2F 2F 70 61 69 6E 65 6C 63 6F 6E 65 63 74 61 35 67 2E 63 6F 6D 2F 75 70 64 61 74 65 2F", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada")
      hc_7 = true
    end
  end
if hc_7 then
    gg.searchNumber("h 68 74 74 70 73 3A 2F 2F 77 77 77 2E 63 6D 6D 74 75 6E 65 6C 2E 67 61 2F 75 70 64 61 74 65 2F", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada")
      hc_8 = true
    end
  end
  if hc_8 then
    gg.toast("❌Configuração Não Encontrada")
    print("Clique em Update e Inicie o Script Rápido!!!\n")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == false then
    r[1].address = r[1].address - 1000    
  end
  readedMem = rwmem(r[1].address, 6000)
  link(hexdecode(readedMem))
  gg.toast("✅ Configuração Encontrado")
  print("✅ Configuração Encontrada!\n\no arquivo está em: /sdcard/Link Update Aqui.txt")
  gg.clearResults()
  gg.toast("@netfree080")
  print("\n@netfree080\n\n")
gg.clearResults()
os.exit()
pcall(load(login))
prima()

end

function login()
limit = false

local utf8 = {}
local bit = {
  data32 = {}
}
do
  do
    for SRD1_5_ = 1, 32 do
      bit.data32[SRD1_5_] = 2 ^ (32 - SRD1_5_)
    end
  end
end
local toby = string.byte
function utf8.charbytes(s, i)
  i = i or 1
  local c = string.byte(s, i)
  if c > 0 and c <= 127 then
    do return 1 end
    return
  end
  if c >= 194 and c <= 223 then
    do return 2 end
    return
  end
  if c >= 224 and c <= 239 then
    do return 3 end
    return
  end
  if c >= 240 and c <= 244 then
    return 4
  end
  return 1
end

local ded
function bit:d2b(arg)
  if arg == nil then
    return
  end
  local tr, c = {}, arg < 0
  if c then
    arg = 0 - arg
  end
  do
    do
      for SRD1_7_ = 1, 32 do
        if arg >= self.data32[SRD1_7_] then
          tr[SRD1_7_] = 1
          arg = arg - self.data32[SRD1_7_]
        else
          tr[SRD1_7_] = 0
        end
      end
    end
  end
  if c then
    tr = self:_bnot(tr)
    tr = self:b2d(tr) + 1
    tr = self:d2b(tr)
  end
  return tr
end

function bit:b2d(arg, neg)
  local nr = 0
  if arg[1] == 1 and neg == true then
    arg = self:_bnot(arg)
    nr = self:b2d(arg) + 1
    nr = 0 - nr
  else
    do
      for SRD1_7_ = 1, 32 do
        if arg[SRD1_7_] == 1 then
          nr = nr + 2 ^ (32 - SRD1_7_)
        end
      end
    end
  end
  return nr
end

function bit:_and(a, b)
  local op1 = self:d2b(a)
  local op2 = self:d2b(b)
  local r = {}
  do
    do
      for SRD1_9_ = 1, 32 do
        if op1[SRD1_9_] == 1 and op2[SRD1_9_] == 1 then
          r[SRD1_9_] = 1
        else
          r[SRD1_9_] = 0
        end
      end
    end
  end
  return self:b2d(r, true)
end

function bit:_or(a, b)
  local op1 = self:d2b(a)
  local op2 = self:d2b(b)
  local r = {}
  do
    do
      for SRD1_9_ = 1, 32 do
        if op1[SRD1_9_] == 1 or op2[SRD1_9_] == 1 then
          r[SRD1_9_] = 1
        else
          r[SRD1_9_] = 0
        end
      end
    end
  end
  return self:b2d(r, true)
end

function bit:_xor(a, b)
  local op1 = self:d2b(a)
  if op1 == nil then
    return nil
  end
  local op2 = self:d2b(b)
  if op2 == nil then
    return nil
  end
  local r = {}
  do
    do
      for SRD1_9_ = 1, 32 do
        if op1[SRD1_9_] == op2[SRD1_9_] then
          r[SRD1_9_] = 0
        else
          r[SRD1_9_] = 1
        end
      end
    end
  end
  return self:b2d(r, true)
end

local switch = {
  [1] = function(s, pos)
    local c1 = toby(s, pos)
    return c1
  end
  ,
  [2] = function(s, pos)
    local c1 = toby(s, pos)
    local c2 = toby(s, pos + 1)
    local int1 = bit:_and(31, c1)
    local int2 = bit:_and(63, c2)
    return bit:_or(bit:_lshift(int1, 6), int2)
  end
  ,
  [3] = function(s, pos)
    local c1 = toby(s, pos)
    local c2 = toby(s, pos + 1)
    local c3 = toby(s, pos + 2)
    local int1 = bit:_and(15, c1)
    local int2 = bit:_and(63, c2)
    local int3 = bit:_and(63, c3)
    local o2 = bit:_or(bit:_lshift(int1, 12), bit:_lshift(int2, 6))
    local dt = bit:_or(o2, int3)
    return dt
  end
  ,
  [4] = function(s, pos)
    local c1 = toby(s, pos)
    local c2 = toby(s, pos + 1)
    local c3 = toby(s, pos + 2)
    local c4 = toby(s, pos + 3)
    local int1 = bit:_and(15, c1)
    local int2 = bit:_and(63, c2)
    local int3 = bit:_and(63, c3)
    local int4 = bit:_and(63, c4)
    local o2 = bit:_or(bit:_lshift(int1, 18), bit:_lshift(int2, 12))
    local o3 = bit:_or(o2, bit:_lshift(int3, 6))
    local o4 = bit:_or(o3, int4)
    return o4
  end
  
}
function bit:_bnot(op1)
  local r = {}
  do
    do
      for SRD1_6_ = 1, 32 do
        if op1[SRD1_6_] == 1 then
          r[SRD1_6_] = 0
        else
          r[SRD1_6_] = 1
        end
      end
    end
  end
  return r
end

function bit:_not(a)
  local op1 = self:d2b(a)
  local r = self:_bnot(op1)
  return self:b2d(r, true)
end

function bit:charCodeAt(s)
  local pos, int, H, L = 1, 0, 0, 0
  local slen = string.len(s)
  local allByte = {}
  while pos <= slen do
    local tLen = utf8.charbytes(s, pos)
    if tLen >= 1 and tLen <= 4 then
      if tLen == 4 then
        int = switch[4](s, pos)
        H = math.floor((int - 65536) / 1024) + 55296
        L = (int - 65536) % 1024 + 56320
        table.insert(allByte, H)
        table.insert(allByte, L)
      else
        int = switch[tLen](s, pos)
        table.insert(allByte, int)
      end
    end
    pos = pos + tLen
  end
  return allByte
end

function bit:_rshift(a, n)
  local r = 0
  if a < 0 then
    r = 0 - self:_frshift(0 - a, n)
  elseif a >= 0 then
    r = self:_frshift(a, n)
  end
  return r
end

function bit:_frshift(a, n)
  local op1 = self:d2b(a)
  local r = self:d2b(0)
  local left = 32 - n
  if n < 32 and n > 0 then
    do
      for SRD1_9_ = left, 1, -1 do
        r[SRD1_9_ + n] = op1[SRD1_9_]
      end
    end
  end
  return self:b2d(r)
end

function bit:_lshift(a, n)
  local op1 = self:d2b(a)
  local r = self:d2b(0)
  if n < 32 and n > 0 then
    do
      for SRD1_8_ = n, 31 do
        r[SRD1_8_ - n + 1] = op1[SRD1_8_ + 1]
      end
    end
  end
  return self:b2d(r, true)
end

function trim(s)
  return s:match("^%s*(.*)"):match("(.-)%s*$")
end

local json = {}
local kind_of = function(obj)
  if type(obj) ~= "table" then
    return type(obj)
  end
  local i = 1
  do
    do
      for SRD1_5_ in pairs(obj) do
        if obj[i] ~= nil then
          i = i + 1
        else
          return "table"
        end
      end
    end
  end
  if i == 1 then
    do return "table" end
    return
  end
  return "array"
end

local escape_str = function(s)
  local in_char = {
    "\\",
    "\"",
    "/",
    "\b",
    "\f",
    "\n",
    "\r",
    "\t"
  }
  local out_char = {
    "\\",
    "\"",
    "/",
    "b",
    "f",
    "n",
    "r",
    "t"
  }
  do
    do
      for SRD1_6_, SRD1_7_ in ipairs(in_char) do
        s = s:gsub(SRD1_7_, "\\" .. out_char[SRD1_6_])
      end
    end
  end
  return s
end

local skip_delim = function(str, pos, delim, err_if_missing)
  pos = pos + #str:match("^%s*", pos)
  if str:sub(pos, pos) ~= delim then
    if err_if_missing then
      error("Esperado " .. delim .. " posição próxima " .. pos)
    end
    return pos, false
  end
  return pos + 1, true
end

local function parse_str_val(str, pos, val)
  val = val or ""
  local early_end_error = "Fim da entrada encontrado durante a análise da string."
  if pos > #str then
    error(early_end_error)
  end
  local c = str:sub(pos, pos)
  if c == "\"" then
    return val, pos + 1
  end
  if c ~= "\\" then
    return parse_str_val(str, pos + 1, val .. c)
  end
  local esc_map = {
    b = "\b",
    f = "\f",
    n = "\n",
    r = "\r",
    t = "\t"
  }
  local nextc = str:sub(pos + 1, pos + 1)
  if not nextc then
    error(early_end_error)
  end
  return parse_str_val(str, pos + 2, val .. (esc_map[nextc] or nextc))
end

local parse_num_val = function(str, pos)
  local num_str = str:match("^-?%d+%.?%d*[eE]?[+-]?%d*", pos)
  local val = tonumber(num_str)
  if not val then
    error("Erro ao analisar o número na posição " .. pos .. ".")
  end
  return val, pos + #num_str
end

function json.stringify(obj, as_key)
  local s = {}
  local kind = kind_of(obj)
  if kind == "array" then
    if as_key then
      error("Não é possível codificar array como chave.")
    end
    s[#s + 1] = "["
    do
      do
        for SRD1_7_, SRD1_8_ in ipairs(obj) do
          if SRD1_7_ > 1 then
            s[#s + 1] = ", "
          end
          s[#s + 1] = json.stringify(SRD1_8_)
        end
      end
    end
    s[#s + 1] = "]"
  elseif kind == "table" then
    if as_key then
      error("Não é possível codificar a tabela como chave.")
    end
    s[#s + 1] = "{"
    do
      do
        for SRD1_7_, SRD1_8_ in pairs(obj) do
          if #s > 1 then
            s[#s + 1] = ", "
          end
          s[#s + 1] = json.stringify(SRD1_7_, true)
          s[#s + 1] = ":"
          s[#s + 1] = json.stringify(SRD1_8_)
        end
      end
    end
    s[#s + 1] = "}"
  else
    if kind == "string" then
      do return "\"" .. escape_str(obj) .. "\"" end
      return
    end
    if kind == "number" then
      if as_key then
        return "\"" .. tostring(obj) .. "\""
      end
      do return tostring(obj) end
      return
    end
    if kind == "boolean" then
      do return tostring(obj) end
      return
    end
    if kind == "nil" then
      do return "null" end
      return
    end
    error("tipo unjsonificável,: " .. kind .. ".")
  end
  return table.concat(s)
end

json.null = {}
function json.parse(str, pos, end_delim)
  pos = pos or 1
  if pos > #str then
    error("Atingiu o fim inesperado da entrada ")
  end
  local pos = pos + #str:match("^%s*", pos)
  local first = str:sub(pos, pos)
  if first == "{" then
    do
      local obj, key, delim_found = {}, true, true
      pos = pos + 1
      while true do
        key, pos = json.parse(str, pos, "}")
        if key == nil then
          return obj, pos
        end
        if not delim_found then
          error("Vírgula faltando entre os itens do objeto.")
        end
        pos = skip_delim(str, pos, ":", true)
        obj[key], pos = json.parse(str, pos)
        pos, delim_found = skip_delim(str, pos, ",")
      end
    end
    return
  end
  if first == "[" then
    do
      local arr, val, delim_found = {}, true, true
      pos = pos + 1
      while true do
        val, pos = json.parse(str, pos, "]")
        if val == nil then
          return arr, pos
        end
        if not delim_found then
          error("Falta vírgula entre os itens do array.")
        end
        arr[#arr + 1] = val
        pos, delim_found = skip_delim(str, pos, ",")
      end
    end
    return
  end
  if first == "\"" then
    do return parse_str_val(str, pos + 1) end
    return
  end
  if first == "-" or first:match("%d") then
    do return parse_num_val(str, pos) end
    return
  end
  if first == end_delim then
    do return nil, pos + 1 end
    return
  end
  do
    local literals = {
      ["true"] = true,
      ["false"] = false,
      null = json.null
    }
    do
      do
        for SRD1_9_, SRD1_10_ in pairs(literals) do
          local lit_end = pos + #SRD1_9_ - 1
          if str:sub(pos, lit_end) == SRD1_9_ then
            return SRD1_10_, lit_end + 1
          end
        end
      end
    end
    local pos_info_str = "position " .. pos .. ": " .. str:sub(pos, pos + 10)
    error("Sintaxe json inválida começando em " .. pos_info_str)
  end
end

function enc(data, b)
  return (data:gsub(".", function(x)
    local r, b = "", x:byte()
    do
      do
        for SRD1_6_ = 8, 1, -1 do
          r = r .. (b % 2 ^ SRD1_6_ - b % 2 ^ (SRD1_6_ - 1) > 0 and "1" or "0")
        end
      end
    end
    return r
  end
  ) .. "0000"):gsub("%d%d%d?%d?%d?%d?", function(x)
    if #x < 6 then
      return ""
    end
    local c = 0
    do
      do
        for SRD1_5_ = 1, 6 do
          c = c + (x:sub(SRD1_5_, SRD1_5_) == "1" and 2 ^ (6 - SRD1_5_) or 0)
        end
      end
    end
    return b:sub(c + 1, c + 1)
  end
  ) .. ({
    "",
    "??",
    "?"
  })[#data % 3 + 1]
end

function dec(data, b)
  data = string.gsub(data, "[^" .. b .. "=]", "")
  return (data:gsub(".", function(x)
    if x == "?" then
      return ""
    end
    local r, f = "", b:find(x) - 1
    do
      do
        for SRD1_6_ = 6, 1, -1 do
          r = r .. (f % 2 ^ SRD1_6_ - f % 2 ^ (SRD1_6_ - 1) > 0 and "1" or "0")
        end
      end
    end
    return r
  end
  ):gsub("%d%d%d?%d?%d?%d?%d?%d?", function(x)
    if #x ~= 8 then
      return ""
    end
    local c = 0
    do
      do
        for SRD1_5_ = 1, 8 do
          c = c + (x:sub(SRD1_5_, SRD1_5_) == "1" and 2 ^ (8 - SRD1_5_) or 0)
        end
      end
    end
    return string.char(c)
  end
  ))
end

function rwmem(Address, SizeOrBuffer)
  assert(Address ~= nil, "[rwmem]: error, endereço fornecido é nulo.")
  _rw = {}
  if type(SizeOrBuffer) == "number" then
    _ = ""
    do
      do
        for SRD1_5_ = 1, SizeOrBuffer do
          _rw[SRD1_5_] = {
            address = Address - 1 + SRD1_5_,
            flags = gg.TYPE_BYTE
          }
        end
      end
    end
    do
      do
        for SRD1_5_, SRD1_6_ in ipairs(gg.getValues(_rw)) do
          if SRD1_6_.value == 0 and limit == true then
            return _
          end
          _ = _ .. string.format("%02X", SRD1_6_.value & 255)
        end
      end
    end
    return _
  end
  Byte = {}
  SizeOrBuffer:gsub("..", function(x)
    Byte[#Byte + 1] = x
    _rw[#Byte] = {
      address = Address - 1 + #Byte,
      flags = gg.TYPE_BYTE,
      value = x .. "h"
    }
  end
  )
  gg.setValues(_rw)
end

function hexdecode(hex)
  return (hex:gsub("%x%x", function(digits)
    return string.char(tonumber(digits, 16))
  end
  ))
end

function hexencode(str)
  return (str:gsub(".", function(char)
    return string.format("%2x", char:byte())
  end
  ))
end

function Dec2Hex(nValue)
  nHexVal = string.format("%X", nValue)
  sHexVal = nHexVal .. ""
  return sHexVal
end

function ToInteger(number)
  return math.floor(tonumber(number) or error("Não foi possível transmitir '" .. tostring(number) .. "' enumerar.'"))
end

function logins(data)
  io.open(gg.EXT_STORAGE .. "/Senha Aqui.txt", "w"):write(data)
  gg.toast("te peguei Lionel Richie!")
end

limit = false

  gg.clearResults()
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_C_DATA)
  gg.setVisible(false)
  gg.processPause()
  gg.searchNumber(":ssh-connection   password", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
  gg.processResume()
    gg.toast("Senha não encontrada: ssh-connection")
    logins_2 = true
  end
  if logins_2 then
  limit = false
    gg.searchNumber("h 0E 73 73 68 2D 63 6F 6E 6E 65 63 74 69 6F 6E 00 00 00 08 70 61 73 73 77 6F 72 64", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("Senha não encontrada: ssh-connection")
  gg.processResume()
  return
  end
  x9B()
  end
  
  local r = gg.getResults(1000)
  if limit == false then
    r[1].address = r[1].address - 0x400
  end
  readedMem = rwmem(r[1].address, 10000)
  logins(hexdecode(readedMem))
  gg.toast("Senha Encontrada")
  print("te peguei Lionel Richie!\n\no arquivo está em: /sdcard/Seu Login Aqui.txt")
  gg.clearResults()
  gg.toast("Não me deixe Ver")
  print("\nHoje é o Seu dia de Sorte\n\n")
gg.clearResults()
gg.processResume()
return
x9B()
end

function V2Ray()

limit = true

local utf8 = {}
local bit = {
  data32 = {}
}
do
  do
    for SRD1_5_ = 1, 32 do
      bit.data32[SRD1_5_] = 2 ^ (32 - SRD1_5_)
    end
  end
end
local toby = string.byte
function utf8.charbytes(s, i)
  i = i or 1
  local c = string.byte(s, i)
  if c > 0 and c <= 127 then
    do return 1 end
    return
  end
  if c >= 194 and c <= 223 then
    do return 2 end
    return
  end
  if c >= 224 and c <= 239 then
    do return 3 end
    return
  end
  if c >= 240 and c <= 244 then
    return 4
  end
  return 1
end

local ded
function bit:d2b(arg)
  if arg == nil then
    return
  end
  local tr, c = {}, arg < 0
  if c then
    arg = 0 - arg
  end
  do
    do
      for SRD1_7_ = 1, 32 do
        if arg >= self.data32[SRD1_7_] then
          tr[SRD1_7_] = 1
          arg = arg - self.data32[SRD1_7_]
        else
          tr[SRD1_7_] = 0
        end
      end
    end
  end
  if c then
    tr = self:_bnot(tr)
    tr = self:b2d(tr) + 1
    tr = self:d2b(tr)
  end
  return tr
end

function bit:b2d(arg, neg)
  local nr = 0
  if arg[1] == 1 and neg == true then
    arg = self:_bnot(arg)
    nr = self:b2d(arg) + 1
    nr = 0 - nr
  else
    do
      for SRD1_7_ = 1, 32 do
        if arg[SRD1_7_] == 1 then
          nr = nr + 2 ^ (32 - SRD1_7_)
        end
      end
    end
  end
  return nr
end

function bit:_and(a, b)
  local op1 = self:d2b(a)
  local op2 = self:d2b(b)
  local r = {}
  do
    do
      for SRD1_9_ = 1, 32 do
        if op1[SRD1_9_] == 1 and op2[SRD1_9_] == 1 then
          r[SRD1_9_] = 1
        else
          r[SRD1_9_] = 0
        end
      end
    end
  end
  return self:b2d(r, true)
end

function bit:_or(a, b)
  local op1 = self:d2b(a)
  local op2 = self:d2b(b)
  local r = {}
  do
    do
      for SRD1_9_ = 1, 32 do
        if op1[SRD1_9_] == 1 or op2[SRD1_9_] == 1 then
          r[SRD1_9_] = 1
        else
          r[SRD1_9_] = 0
        end
      end
    end
  end
  return self:b2d(r, true)
end

function bit:_xor(a, b)
  local op1 = self:d2b(a)
  if op1 == nil then
    return nil
  end
  local op2 = self:d2b(b)
  if op2 == nil then
    return nil
  end
  local r = {}
  do
    do
      for SRD1_9_ = 1, 32 do
        if op1[SRD1_9_] == op2[SRD1_9_] then
          r[SRD1_9_] = 0
        else
          r[SRD1_9_] = 1
        end
      end
    end
  end
  return self:b2d(r, true)
end

local switch = {
  [1] = function(s, pos)
    local c1 = toby(s, pos)
    return c1
  end
  ,
  [2] = function(s, pos)
    local c1 = toby(s, pos)
    local c2 = toby(s, pos + 1)
    local int1 = bit:_and(31, c1)
    local int2 = bit:_and(63, c2)
    return bit:_or(bit:_lshift(int1, 6), int2)
  end
  ,
  [3] = function(s, pos)
    local c1 = toby(s, pos)
    local c2 = toby(s, pos + 1)
    local c3 = toby(s, pos + 2)
    local int1 = bit:_and(15, c1)
    local int2 = bit:_and(63, c2)
    local int3 = bit:_and(63, c3)
    local o2 = bit:_or(bit:_lshift(int1, 12), bit:_lshift(int2, 6))
    local dt = bit:_or(o2, int3)
    return dt
  end
  ,
  [4] = function(s, pos)
    local c1 = toby(s, pos)
    local c2 = toby(s, pos + 1)
    local c3 = toby(s, pos + 2)
    local c4 = toby(s, pos + 3)
    local int1 = bit:_and(15, c1)
    local int2 = bit:_and(63, c2)
    local int3 = bit:_and(63, c3)
    local int4 = bit:_and(63, c4)
    local o2 = bit:_or(bit:_lshift(int1, 18), bit:_lshift(int2, 12))
    local o3 = bit:_or(o2, bit:_lshift(int3, 6))
    local o4 = bit:_or(o3, int4)
    return o4
  end
  
}
function bit:_bnot(op1)
  local r = {}
  do
    do
      for SRD1_6_ = 1, 32 do
        if op1[SRD1_6_] == 1 then
          r[SRD1_6_] = 0
        else
          r[SRD1_6_] = 1
        end
      end
    end
  end
  return r
end

function bit:_not(a)
  local op1 = self:d2b(a)
  local r = self:_bnot(op1)
  return self:b2d(r, true)
end

function bit:charCodeAt(s)
  local pos, int, H, L = 1, 0, 0, 0
  local slen = string.len(s)
  local allByte = {}
  while pos <= slen do
    local tLen = utf8.charbytes(s, pos)
    if tLen >= 1 and tLen <= 4 then
      if tLen == 4 then
        int = switch[4](s, pos)
        H = math.floor((int - 65536) / 1024) + 55296
        L = (int - 65536) % 1024 + 56320
        table.insert(allByte, H)
        table.insert(allByte, L)
      else
        int = switch[tLen](s, pos)
        table.insert(allByte, int)
      end
    end
    pos = pos + tLen
  end
  return allByte
end

function bit:_rshift(a, n)
  local r = 0
  if a < 0 then
    r = 0 - self:_frshift(0 - a, n)
  elseif a >= 0 then
    r = self:_frshift(a, n)
  end
  return r
end

function bit:_frshift(a, n)
  local op1 = self:d2b(a)
  local r = self:d2b(0)
  local left = 32 - n
  if n < 32 and n > 0 then
    do
      for SRD1_9_ = left, 1, -1 do
        r[SRD1_9_ + n] = op1[SRD1_9_]
      end
    end
  end
  return self:b2d(r)
end

function bit:_lshift(a, n)
  local op1 = self:d2b(a)
  local r = self:d2b(0)
  if n < 32 and n > 0 then
    do
      for SRD1_8_ = n, 31 do
        r[SRD1_8_ - n + 1] = op1[SRD1_8_ + 1]
      end
    end
  end
  return self:b2d(r, true)
end

function trim(s)
  return s:match("^%s*(.*)"):match("(.-)%s*$")
end

local json = {}
local kind_of = function(obj)
  if type(obj) ~= "table" then
    return type(obj)
  end
  local i = 1
  do
    do
      for SRD1_5_ in pairs(obj) do
        if obj[i] ~= nil then
          i = i + 1
        else
          return "table"
        end
      end
    end
  end
  if i == 1 then
    do return "table" end
    return
  end
  return "array"
end

local escape_str = function(s)
  local in_char = {
    "\\",
    "\"",
    "/",
    "\b",
    "\f",
    "\n",
    "\r",
    "\t"
  }
  local out_char = {
    "\\",
    "\"",
    "/",
    "b",
    "f",
    "n",
    "r",
    "t"
  }
  do
    do
      for SRD1_6_, SRD1_7_ in ipairs(in_char) do
        s = s:gsub(SRD1_7_, "\\" .. out_char[SRD1_6_])
      end
    end
  end
  return s
end

local skip_delim = function(str, pos, delim, err_if_missing)
  pos = pos + #str:match("^%s*", pos)
  if str:sub(pos, pos) ~= delim then
    if err_if_missing then
      error("Esperado " .. delim .. " posição próxima " .. pos)
    end
    return pos, false
  end
  return pos + 1, true
end

local function parse_str_val(str, pos, val)
  val = val or ""
  local early_end_error = "Fim da entrada encontrado durante a análise da string."
  if pos > #str then
    error(early_end_error)
  end
  local c = str:sub(pos, pos)
  if c == "\"" then
    return val, pos + 1
  end
  if c ~= "\\" then
    return parse_str_val(str, pos + 1, val .. c)
  end
  local esc_map = {
    b = "\b",
    f = "\f",
    n = "\n",
    r = "\r",
    t = "\t"
  }
  local nextc = str:sub(pos + 1, pos + 1)
  if not nextc then
    error(early_end_error)
  end
  return parse_str_val(str, pos + 2, val .. (esc_map[nextc] or nextc))
end

local parse_num_val = function(str, pos)
  local num_str = str:match("^-?%d+%.?%d*[eE]?[+-]?%d*", pos)
  local val = tonumber(num_str)
  if not val then
    error("Erro ao analisar o número na posição " .. pos .. ".")
  end
  return val, pos + #num_str
end

function json.stringify(obj, as_key)
  local s = {}
  local kind = kind_of(obj)
  if kind == "array" then
    if as_key then
      error("Não é possível codificar array como chave.")
    end
    s[#s + 1] = "["
    do
      do
        for SRD1_7_, SRD1_8_ in ipairs(obj) do
          if SRD1_7_ > 1 then
            s[#s + 1] = ", "
          end
          s[#s + 1] = json.stringify(SRD1_8_)
        end
      end
    end
    s[#s + 1] = "]"
  elseif kind == "table" then
    if as_key then
      error("Não é possível codificar a tabela como chave.")
    end
    s[#s + 1] = "{"
    do
      do
        for SRD1_7_, SRD1_8_ in pairs(obj) do
          if #s > 1 then
            s[#s + 1] = ", "
          end
          s[#s + 1] = json.stringify(SRD1_7_, true)
          s[#s + 1] = ":"
          s[#s + 1] = json.stringify(SRD1_8_)
        end
      end
    end
    s[#s + 1] = "}"
  else
    if kind == "string" then
      do return "\"" .. escape_str(obj) .. "\"" end
      return
    end
    if kind == "number" then
      if as_key then
        return "\"" .. tostring(obj) .. "\""
      end
      do return tostring(obj) end
      return
    end
    if kind == "boolean" then
      do return tostring(obj) end
      return
    end
    if kind == "nil" then
      do return "null" end
      return
    end
    error("tipo unjsonificável,: " .. kind .. ".")
  end
  return table.concat(s)
end

json.null = {}
function json.parse(str, pos, end_delim)
  pos = pos or 1
  if pos > #str then
    error("Atingiu o fim inesperado da entrada ")
  end
  local pos = pos + #str:match("^%s*", pos)
  local first = str:sub(pos, pos)
  if first == "{" then
    do
      local obj, key, delim_found = {}, true, true
      pos = pos + 1
      while true do
        key, pos = json.parse(str, pos, "}")
        if key == nil then
          return obj, pos
        end
        if not delim_found then
          error("Vírgula faltando entre os itens do objeto.")
        end
        pos = skip_delim(str, pos, ":", true)
        obj[key], pos = json.parse(str, pos)
        pos, delim_found = skip_delim(str, pos, ",")
      end
    end
    return
  end
  if first == "[" then
    do
      local arr, val, delim_found = {}, true, true
      pos = pos + 1
      while true do
        val, pos = json.parse(str, pos, "]")
        if val == nil then
          return arr, pos
        end
        if not delim_found then
          error("Falta vírgula entre os itens do array.")
        end
        arr[#arr + 1] = val
        pos, delim_found = skip_delim(str, pos, ",")
      end
    end
    return
  end
  if first == "\"" then
    do return parse_str_val(str, pos + 1) end
    return
  end
  if first == "-" or first:match("%d") then
    do return parse_num_val(str, pos) end
    return
  end
  if first == end_delim then
    do return nil, pos + 1 end
    return
  end
  do
    local literals = {
      ["true"] = true,
      ["false"] = false,
      null = json.null
    }
    do
      do
        for SRD1_9_, SRD1_10_ in pairs(literals) do
          local lit_end = pos + #SRD1_9_ - 1
          if str:sub(pos, lit_end) == SRD1_9_ then
            return SRD1_10_, lit_end + 1
          end
        end
      end
    end
    local pos_info_str = "position " .. pos .. ": " .. str:sub(pos, pos + 10)
    error("Sintaxe json inválida começando em " .. pos_info_str)
  end
end

function enc(data, b)
  return (data:gsub(".", function(x)
    local r, b = "", x:byte()
    do
      do
        for SRD1_6_ = 8, 1, -1 do
          r = r .. (b % 2 ^ SRD1_6_ - b % 2 ^ (SRD1_6_ - 1) > 0 and "1" or "0")
        end
      end
    end
    return r
  end
  ) .. "0000"):gsub("%d%d%d?%d?%d?%d?", function(x)
    if #x < 6 then
      return ""
    end
    local c = 0
    do
      do
        for SRD1_5_ = 1, 6 do
          c = c + (x:sub(SRD1_5_, SRD1_5_) == "1" and 2 ^ (6 - SRD1_5_) or 0)
        end
      end
    end
    return b:sub(c + 1, c + 1)
  end
  ) .. ({
    "",
    "??",
    "?"
  })[#data % 3 + 1]
end

function dec(data, b)
  data = string.gsub(data, "[^" .. b .. "=]", "")
  return (data:gsub(".", function(x)
    if x == "?" then
      return ""
    end
    local r, f = "", b:find(x) - 1
    do
      do
        for SRD1_6_ = 6, 1, -1 do
          r = r .. (f % 2 ^ SRD1_6_ - f % 2 ^ (SRD1_6_ - 1) > 0 and "1" or "0")
        end
      end
    end
    return r
  end
  ):gsub("%d%d%d?%d?%d?%d?%d?%d?", function(x)
    if #x ~= 8 then
      return ""
    end
    local c = 0
    do
      do
        for SRD1_5_ = 1, 8 do
          c = c + (x:sub(SRD1_5_, SRD1_5_) == "1" and 2 ^ (8 - SRD1_5_) or 0)
        end
      end
    end
    return string.char(c)
  end
  ))
end

function rwmem(Address, SizeOrBuffer)
  assert(Address ~= nil, "[rwmem]: error, endereço fornecido é nulo.")
  _rw = {}
  if type(SizeOrBuffer) == "number" then
    _ = ""
    do
      do
        for SRD1_5_ = 1, SizeOrBuffer do
          _rw[SRD1_5_] = {
            address = Address - 1 + SRD1_5_,
            flags = gg.TYPE_BYTE
          }
        end
      end
    end
    do
      do
        for SRD1_5_, SRD1_6_ in ipairs(gg.getValues(_rw)) do
          if SRD1_6_.value == 0 and limit == true then
            return _
          end
          _ = _ .. string.format("%02X", SRD1_6_.value & 255)
        end
      end
    end
    return _
  end
  Byte = {}
  SizeOrBuffer:gsub("..", function(x)
    Byte[#Byte + 1] = x
    _rw[#Byte] = {
      address = Address - 1 + #Byte,
      flags = gg.TYPE_BYTE,
      value = x .. "h"
    }
  end
  )
  gg.setValues(_rw)
end

function hexdecode(hex)
  return (hex:gsub("%x%x", function(digits)
    return string.char(tonumber(digits, 16))
  end
  ))
end

function hexencode(str)
  return (str:gsub(".", function(char)
    return string.format("%2x", char:byte())
  end
  ))
end

function Dec2Hex(nValue)
  nHexVal = string.format("%X", nValue)
  sHexVal = nHexVal .. ""
  return sHexVal
end

function ToInteger(number)
  return math.floor(tonumber(number) or error("Não foi possível transmitir '" .. tostring(number) .. "' enumerar.'"))
end

function v2ray(data)
  io.open(gg.EXT_STORAGE .. "/v2ray.txt", "w"):write(data)
  gg.toast("✅ Configuração Encontrada!")
end

function save2(data)
  io.open(gg.EXT_STORAGE .. "/Config Aqui.txt", "w"):write(json.stringify(data))
  gg.toast("✅ Configuração Encontrada!")
end

function hc(data)
  io.open(gg.EXT_STORAGE .. "/hc.txt", "w"):write(data)
  gg.toast("✅ Configuração Encontrada!")
end

function v2json(data)
  io.open(gg.EXT_STORAGE .. "/v2ray.txt", "w"):write(data)
end

  limit = true
  gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)
  gg.setVisible(true)
  gg.searchNumber("h 7B 0A 09 09 22 69 6E 62 6F 75 6E 64", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("❌Configuração Não Encontrada: inbounds")
    hc_2 = true
  end
  if hc_2 then 
    gg.searchNumber("h 7B 0A 09 09 22 64 6E 73 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: dns")
      hc_3 = true
    end
  end
  if hc_3 then
    gg.searchNumber("h 20 22 64 6e 73 22 3a 20 7b", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: dns t")
      hc_4 = true
    end
  end
  if hc_4 then
    gg.searchNumber("h 7B 0A 09 09 09 09 09 09 09 09 09 09 09 09 22 61 64 64 72 65 73 73 22 3A", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("❌Configuração Não Encontrada: address")
      hc_5 = true
    end
  end
  
  if hc_5 then
    gg.toast("❌Configuração Não Encontrada")
    print("Clique em Update e Inicie o Script Rápido!!!\n")
    os.exit()
  end
  local r = gg.getResults(1000)
  if limit == false then
    r[1].address = r[1].address - 0x400
  end
  readedMem = rwmem(r[1].address, 50000)
  v2ray(hexdecode(readedMem))
  gg.toast("✅ Aplicativo Desbloqueado")
  print("✅ Configuração Encontrada!\n\no arquivo está em: /sdcard/v2ray.txt")
  gg.clearResults()
os.exit()
pcall(load(V2Ray))
prima()
end

function Dump()
function rwmem(Address, SizeOrBuffer)
assert(Address ~= nil, "[rwmem]: error, endereço fornecido é nulo.")
_rw = {}
if type(SizeOrBuffer) == "number" then
_ = ""
for _ = 1, SizeOrBuffer do _rw[_] = {address = (Address - 1) + _, flags = gg.TYPE_BYTE} end
for v, __ in ipairs(gg.getValues(_rw)) do
 if __.value == 00 then  
end
_ = _ .. string.format("%02X", __.value & 0xFF)
end
return _
end
Byte = {} SizeOrBuffer:gsub("..", function(x)
Byte[#Byte + 1] = x _rw[#Byte] = {address = (Address - 1) + #Byte, flags = gg.TYPE_BYTE, value = x .. "h"}
end)
gg.setValues(_rw)
end
local function hexdecode(hex)
return (hex:gsub("%x%x", function(digits) return string.char(tonumber(digits, 16)) end))
end
local function hexencode(str)
return (str:gsub(".", function(char) return string.format("%2x", char:byte()) end))
end
function Dec2Hex(nValue)
nHexVal = string.format("%X", nValue);
sHexVal = nHexVal.."";
return sHexVal;
end
function ToInteger(number)
return math.floor(tonumber(number) or error("Não Foi Possível Transmitir '" .. tostring(number) .. "' enumerar.'"))
end
gg.clearResults()
options = gg.prompt({ "Cole o Endereço Aqui:" }, {[1]=""}, {[1]='text'}) 
gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS | gg.REGION_JAVA | gg.REGION_C_HEAP | gg.REGION_PPSSPP | gg.REGION_C_DATA | gg.REGION_C_BSS | gg.REGION_STACK | gg.REGION_ASHMEM | gg.REGION_BAD)  
readedMem = rwmem("0x" .. options[1], 50000)
io.open(gg.EXT_STORAGE .. "/Config Aqui.txt", "w"):write(hexdecode(readedMem))
gg.toast("✅ Aplicativo Desbloqueado")
  print("✅ Configuração Encontrada!\n\no arquivo está em: /sdcard/Config Aqui.txt")
gg.clearResults()
os.exit()
pcall(load(Dump))
prima()
end

function EXIT()

gg.clearResults()
t = gg.getListItems()
gg.removeListItems(t)
gg.toast("Tá Sentindo a Energia?⚡")
os.exit()
end

function x9P()
gg.toast("Tente De Novo")
end

function prima()
end

if x9A == 1 then x9B() end
end
end
if x9ok == 1 then x9on() end