limit = false
function rwmem(Address, SizeOrBuffer)
    assert(Address ~= nil, "[rwmem]: error, provided address is nil.")
    _rw = {}
    if type(SizeOrBuffer) == "number" then
        _ = ""
        for _ = 1, SizeOrBuffer do _rw[_] = { address = (Address - 1) + _, flags = gg.TYPE_BYTE } end
        for v, __ in ipairs(gg.getValues(_rw)) do
            if __.value == 00 and limit == true then
                return _
            end
            _ = _ .. string.format("%02X", __.value & 0xFF)
        end
        return _
    end
    Byte = {}
    SizeOrBuffer:gsub("..", function(x)
        Byte[#Byte + 1] = x
        _rw[#Byte] = { address = (Address - 1) + #Byte, flags = gg.TYPE_BYTE, value = x .. "h" }
    end)
    gg.setValues(_rw)
end

function hexdecode(hex)
    return (hex:gsub("%x%x", function(digits) return string.char(tonumber(digits, 16)) end))
end

function hexencode(str)
    return (str:gsub(".", function(char) return string.format("%2x", char:byte()) end))
end

function Dec2Hex(nValue)
    nHexVal = string.format("%X", nValue)
    sHexVal = nHexVal .. ""
    return sHexVal
end

function ToInteger(number)
    return math.floor(tonumber(number) or error("Could not cast '" .. tostring(number) .. "' to number.'"))
end

function save(data)
ProgressBar = "║░░░░░░░░░░░░░░░║";for x = 1,15,1 do gg.sleep(50) ProgressBar = ProgressBar:gsub("░","▓",1);gg.toast(ProgressBar) end
    io.open(gg.EXT_STORAGE .. "/decrypt.txt", "w"):write(hexdecode(data))
end

gg.setRanges(gg.REGION_JAVA_HEAP)
gg.setVisible(false)
gg.searchNumber(":Upgrade", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
local r = gg.getResults(1)
if #r < 1 then
    gg.toast("Bypass failed")
    hc_method2 = true
end

if hc_method2 then 
gg.searchNumber(":[crlf]", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
local r = gg.getResults(1)
if #r < 1 then
    gg.toast("Bypass failed")
    hc_method3 = true
end
end
if hc_method3 then
    print("Bypass failed")
    os.exit()
end

local r = gg.getResults(100)
if limit == false then
    r[1].address = r[1].address - 0x500
end

readedMem = rwmem(r[1].address, 5000)
save(readedMem)
gg.clearResults()

local file = io.open("/sdcard/decrypt.txt", 'rb')
local content = file:read(9000)
file:close()
local sshfile = io.open("/sdcard/decrypt.txt", 'rb')
local sshcontent = sshfile:read(3400)
sshfile:close()

local PAYLOADD = string.match(sshcontent, "[a-zA-Z]+[\x20]+.*[\x5bcrlf\x5d]+.")  or "_"
local user = {}
for i = 1, #PAYLOADD - 1 do
table.insert(user, PAYLOADD:sub(i,i))
end
PAYLOADD = table.concat(user, "")

local SSH = string.match(sshcontent, "[0-9a-zA-Zx\x2e\x2d]+:[%d]+@[%w\x2e\x2d]+:[%w]+")  or ""
local shs = {}
for i = 1, #SSH - 1 do
table.insert(shs, SSH:sub(i,i))
end
SSH = table.concat(shs, "")

local proxy = string.match(content, "[%w\x2e]+[\x3a][%d]+")

local result = {
	[1] = {
    ['NAME'] = "\n",
    ['DATA'] = PAYLOADD
    },
    [2] = {
    ['NAME'] = "",
    ['DATA'] = proxy
    },
    [21] = {
    ['NAME'] = "\n",
    ['DATA'] = SSH
    },
 
  }
  
      local message = "HTTP Custom\nVersion 5.1.26-RC77\n"
      for index, keys in ipairs(result) do
        if result[index] and result[index]['DATA'] then 
          local names = result[index]['NAME']
          local value = result[index]['DATA']
  
          message = message..names..""..value.."\n\n"
           end
            end

            message = message.."Request (Type) : Payload & Proxy"
      gg.alert(message, "(Copy Here)")
      io.open('/sdcard/Bypass.txt', 'w'):write(message)
      gg.copyText(message, false)
      gg.toast("by mobasniff")
   --   print("Pubkey value: "..result[16]['DATA'])
    save(hexdecode(readedMem))
  gg.clearResults()