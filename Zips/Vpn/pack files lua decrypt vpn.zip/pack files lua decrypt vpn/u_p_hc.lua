function obterEntradaSSH()
  local texto = gg.prompt({"Cole ssh criptografado: "}, nil, {"text"})
  if texto == nil then
    os.exit()
  end
  return texto[1]
end

function salvarTextoEmArquivo(texto, caminhoArquivo)
  local arquivo = io.open(caminhoArquivo, "w")
  arquivo:write(texto)
  arquivo:close()
end

function lerTextoDeArquivo(caminhoArquivo)
  local arquivo = io.open(caminhoArquivo, "r")
  local conteudo = arquivo:read("*all")
  arquivo:close()
  return conteudo
end

function modificarConteudo(conteudo)
  local resultado = ""

  local padrao = "%.([%d-]+)"

  for i = 0, 99 do
    local conteudoModificado = conteudo:gsub(padrao, function(captura)
      local numero = tonumber(captura)
      return '.' .. (numero - i)
    end)

    resultado = resultado .. conteudoModificado .. "\n\n"
  end

  for i = -99, 0 do
    local conteudoModificado = conteudo:gsub(padrao, function(captura)
      local numero = tonumber(captura)
      return '.' .. (numero + math.abs(i))
    end)

    resultado = resultado .. conteudoModificado .. "\n\n"
  end

  -- Lidar com finais separados por ":"
  local partes = {}
  for parte in conteudo:gmatch("[^:]+") do
    partes[#partes + 1] = parte
  end

  for _, parte in ipairs(partes) do
    resultado = resultado .. parte .. "\n\n"
  end

  return resultado
end

function ehCaracterValido(char)
  return char >= "0" and char <= "9" or
         char >= "a" and char <= "z" or
         char >= "A" and char <= "Z" or
         char == " " or
         char == "." or
         char == "_" or
         char == "-" or
         char == "@" or
         char == ".." or
         char == "..." or
         char == "~" or
         char == "&" or
         char == "#" or
         char == "ç" or
         char == "*" or
         char == "***" or
         char == "**" or
         char == "****" or
         char == "*****" or
         char == "!" or
         char == "?" or
         char == "+" or
         char == "'" or
         char == ":" or
         char == "á" or
         char == "é" or
         char == "í" or
         char == "ó" or
         char == "ú" or
         char == "â" or
         char == "ê" or
         char == "î" or
         char == "ô" or
         char == "û" or
         char == "ã" or
         char == "õ" or
         char == "ç" or
         char == "à" or
         char == "è" or
         char == "ì" or
         char == "ò" or
         char == "ù" or
         char == "ä" or
         char == "ë" or
         char == "ï" or
         char == "ö" or
         char == "ü"
end

function descriptografar(texto)
  local dadosDescriptografados = ""
  local padraoDeCifra = "([%-%d]+)%.(%-?%d+)"
  for numero, deslocamento in texto:gmatch(padraoDeCifra) do
    local numeroDecimal = tonumber(numero)
    local quantidadeDeslocada = tonumber(deslocamento)
    local caractereDescriptografado = string.char(((numeroDecimal // (2 ^ quantidadeDeslocada)) % 256))
    if ehCaracterValido(caractereDescriptografado) then
      dadosDescriptografados = dadosDescriptografados .. caractereDescriptografado
    end
  end
  return dadosDescriptografados
end

function processarEImprimirLinhas(linhas, caminhoArquivoSaida)
  local resultadosDescriptografados = {}

  for sshCriptografado in linhas do
    if string.find(sshCriptografado, ":") then
      local usuario, senha = sshCriptografado:match("([^:]+):([^:]+)")
      local decUsuario = descriptografar(usuario)
      local decSenha = descriptografar(senha)
      local resultado = "Usuário: " .. decUsuario .. "\nSenha: " .. decSenha .. "\nSSH Descriptografado: " .. decUsuario .. ":" .. decSenha .. "\n---\n"
      table.insert(resultadosDescriptografados, resultado)
      print(resultado)
    end
  end

  local arquivoSaida = io.open(caminhoArquivoSaida, "w")
  if arquivoSaida then
    for _, linha in ipairs(resultadosDescriptografados) do
      arquivoSaida:write(linha)
    end
    arquivoSaida:close()
    print("Dados descriptografados salvos corretamente em ssh_resultados.txt")
  else
    print("Erro: Não é possível abrir o arquivo de saída")
  end
end

function processarSSH()
  local caminhoArquivoEntrada = "ssh_dump.txt"
  local caminhoArquivoSaida = "ssh_resultados.txt"

  local entradaSSH = obterEntradaSSH()

  salvarTextoEmArquivo(entradaSSH, caminhoArquivoEntrada)

  local conteudo = lerTextoDeArquivo(caminhoArquivoEntrada)

  local resultadoModificado = modificarConteudo(conteudo)
  salvarTextoEmArquivo(resultadoModificado, caminhoArquivoEntrada)

  local linhasEntrada = io.lines(caminhoArquivoEntrada)
  processarEImprimirLinhas(linhasEntrada, caminhoArquivoSaida)
end

processarSSH()
