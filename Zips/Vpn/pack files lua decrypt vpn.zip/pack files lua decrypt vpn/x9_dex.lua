gg.clearResults()
gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_ASHMEM | gg.REGION_BAD | gg.REGION_C_ALLOC | gg.REGION_C_BSS | gg.REGION_C_DATA | gg.REGION_C_HEAP | gg.REGION_CODE_APP | gg.REGION_CODE_SYS | gg.REGION_JAVA | gg.REGION_JAVA_HEAP | gg.REGION_OTHER | gg.REGION_PPSSPP | gg.REGION_STACK | gg.REGION_VIDEO)

gg.toast("como vai, garotão?")
gg.searchNumber("175662436", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)

resultCounts = gg.getResultsCount()
gg.toast("Localizar pai em 10 segundos".. resultCounts .."roubando dex")
results = gg.getResults(resultCounts)

for i=1 , resultCounts do
gg.toast("Aumentando sinal ".. i .." localizando ".. resultCounts .." item",true)
  
  startAddr = results[i].address
  
  local the035Temp = {}
  the035Temp[1] = {}
  the035Temp[1].address = startAddr + 4
  the035Temp[1].flags = gg.TYPE_DWORD
  the035Temp = gg.getValues(the035Temp)
  if the035Temp[1].value == 3486512 then
   
    local fileSizeTemp = {}
    fileSizeTemp[1] = {}
    fileSizeTemp[1].address = startAddr + 32
    fileSizeTemp[1].flags = gg.TYPE_DWORD
    fileSizeTemp = gg.getValues(fileSizeTemp)
    moveSize = fileSizeTemp[1].value
    
    endAddr = fileSizeTemp[1].address + moveSize
    packageName = gg.getTargetPackage()
    gg.dumpMemory(startAddr,endAddr,"/storage/emulated/0/classes_dex/".. packageName)
  end
end

gg.clearResults()
gg.toast("Pai encontrado")
gg.alert("te peguei, Lionel Richie! /storage/emulated/0/classes_dex/".. packageName);
