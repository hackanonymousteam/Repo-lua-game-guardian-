-- information !!
-- Change the string if it is inaccurate

limit = false
function rwmem(Address, SizeOrBuffer)
    assert(Address ~= nil, "[rwmem]: error, provided address is nil.")
    _rw = {}
    if type(SizeOrBuffer) == "number" then
        _ = ""
        for _ = 1, SizeOrBuffer do _rw[_] = { address = (Address - 1) + _, flags = gg.TYPE_BYTE } end
        for v, __ in ipairs(gg.getValues(_rw)) do
            if __.value == 00 and limit == true then
                return _
            end
            _ = _ .. string.format("%02X", __.value & 0xFF)
        end
        return _
    end
    Byte = {}
    SizeOrBuffer:gsub("..", function(x)
        Byte[#Byte + 1] = x
        _rw[#Byte] = { address = (Address - 1) + #Byte, flags = gg.TYPE_BYTE, value = x .. "h" }
    end)
    gg.setValues(_rw)
end

function hexdecode(hex)
    return (hex:gsub("%x%x", function(digits) return string.char(tonumber(digits, 16)) end))
end

function hexencode(str)
    return (str:gsub(".", function(char) return string.format("%2x", char:byte()) end))
end

function Dec2Hex(nValue)
    nHexVal = string.format("%X", nValue)
    sHexVal = nHexVal .. ""
    return sHexVal
end

function ToInteger(number)
    return math.floor(tonumber(number) or error("Could not cast '" .. tostring(number) .. "' to number.'"))
end

function save(data)
gg.toast("Unlock Success ⚡")
    io.open(gg.EXT_STORAGE .. "/decrypt.txt", "w"):write(hexdecode(data))
end

gg.setRanges(gg.REGION_JAVA_HEAP | gg.REGION_ANONYMOUS)
gg.setVisible(false)

gg.searchNumber(":lf]", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
local r = gg.getResults(1)
if #r < 1 then   
    hc_method2 = true
end
if hc_method2 then 
gg.searchNumber(":80@", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
local r = gg.getResults(1)
if #r < 1 then  
    hc_method3 = true
end
end
if hc_method3 then 
gg.searchNumber(":inbounds", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
local r = gg.getResults(1)
if #r < 1 then    
    hc_method4 = true
end
end
if hc_method4 then 
gg.searchNumber(":443@", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
local r = gg.getResults(1)
if #r < 1 then  
    hc_method5 = true
end
end
if hc_method5 then 
gg.searchNumber(":# Config for OpenVPN 2.x", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
local r = gg.getResults(1)
if #r < 1 then    
    hc_method6 = true
end
end
if hc_method6 then 
gg.searchNumber(':22@', gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
local r = gg.getResults(1)
if #r < 1 then    
    hc_method7 = true
end
end
if hc_method7 then 
gg.searchNumber(":143@", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
local r = gg.getResults(1)
if #r < 1 then    
    hc_method8 = true
end
end
if hc_method8 then 
gg.searchNumber(':dns.', gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
local r = gg.getResults(1)
if #r < 1 then    
    hc_method9 = true
end
end
if hc_method9 then 
gg.searchNumber(':FRONTED-', gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
local r = gg.getResults(1)
if #r < 1 then  
    hc_method10 = true
end
end
if hc_method10 then
gg.alert("Failed All Key 💩")
os.exit()
end

local r = gg.getResults(1000)
if limit == false then
    r[1].address = r[1].address - 0x200
end

readedMem = rwmem(r[1].address, 19000)
save(readedMem)
gg.clearResults()

local file = io.open("/sdcard/decrypt.txt", 'rb')
local content = file:read(20000)
file:close()
local sshfile = io.open("/sdcard/decrypt.txt", 'rb')
local sshcontent = sshfile:read(1000)
sshfile:close()

function obterEntradaSSH()
  local texto = gg.prompt({"Cole ssh criptografado: "}, nil, {"text"})
  
  if texto == nil then
    os.exit()
  end
  
  return texto[1]
end

function salvarTextoEmArquivo(texto, caminhoArquivo)
  if texto == nil or texto == "" then
    return nil, "Texto inválido"
  end
  
  if caminhoArquivo == nil or caminhoArquivo == "" then
    return nil, "Caminho de arquivo inválido"
  end
  
  local arquivo = io.open(caminhoArquivo, "w")
  if arquivo == nil then
    return nil, "Não foi possível abrir o arquivo"
  end
  
  arquivo:write(texto)
  arquivo:close()
  
  return true
end

function lerTextoDeArquivo(caminhoArquivo)
  if caminhoArquivo == nil or caminhoArquivo == "" then
    return nil, "Caminho de arquivo inválido"
  end
  
  local arquivo = io.open(caminhoArquivo, "r")
  if arquivo == nil then
    return nil, "Não foi possível abrir o arquivo"
  end
  
  local conteudo = arquivo:read("*all")
  arquivo:close()
  
  if conteudo == nil then
    return nil, "Não foi possível ler o conteúdo do arquivo"
  end
  
  return conteudo
end

local hcRegex = {}
hcRegex["sshEnc"] = "([%w.-]-):(%d+)@([%d-.]+):([%d-.]+)"
hcRegex["sshNormal"] = "([%w.-]-):(%d+)@(%w+):(%w+)"

function save(val1, val2, val11, val22, val3, car)
    local outputFileName = "/sdcard/decrypt.txt"

    -- Abre o arquivo no modo de escrita no diretório do script
    local outputFile = io.open(outputFileName, "a")

    if outputFile then
        -- Construir a string com os valores a serem salvos
        local data = string.format("%s, %s, %s, %s, %s, %s\n", val1, val2, val11, val22, val3, car)
        outputFile:write(data)
        print("")
        outputFile:close()
    else
        print("Falha ao abrir o arquivo de saída")
    end
end

function bitwiseAntigo(val1, val2)
  return string.char((tonumber(val1) // (2 ^ tonumber(val2))) % 256)
end

function extract(data, iv)
  local new_data = ""
  for val1, val2 in string.gmatch(data, "(-?%d+)%.(-?%d+)") do
    local val11 = tonumber(val1) - iv
    local val22 = tonumber(val2) - iv
    local val3 = ((val11 // (2 ^ val22)) % 256)
    local car = string.char(val3)
    -- Linhas de depuração
     --print(val1, val2, val11, 2 ^ val22, val3, car)
     --save(val1, val2, val11, val22, val3, car)
     --save(val1, val2, val1, val2, val3, car)
    new_data = new_data .. car
  end
  if verificaString(new_data) then
    return new_data
  else
    new_data = ""
    for val1, val2 in string.gmatch(data, "(-?%d+)%.(-?%d+)") do
      car = bitwiseAntigo(val1, val2)
      new_data = new_data .. car
    end
    return new_data
  end
end

function verificaString(str)
  for i=1, #str do
    local char = str:sub(i,i)
    local ascii = string.byte(char)
    if ascii < 0 or ascii > 255 then
      return false
    end
  end
  return true
end

function calculaIv(user, senha)
  if type(user) ~= "string" or type(senha) ~= "string" then
    return nil, "Usuário e senha devem ser strings"
  end
  
  local countU = 0
  local countP = 0
  for match in user:gmatch("(-?%d+)%.(-?%d+)") do
    countU = countU + 1
  end
  for match in senha:gmatch("(-?%d+)%.(-?%d+)") do
    countP = countP + 1
  end   
  
  return countU, countP
end

function dec_user_pass(user, userIv, pasw, passIv)
    return extract(user, userIv), extract(pasw, passIv)
end

local function exibirEInserir(arquivoSaida, label, texto)
   
    local sucesso, erro = arquivoSaida:write(label .. ": " .. texto .. "\n\n")

    if not sucesso then
        print("Erro ao escrever no arquivo de saída: " .. erro)
    end
end

function processarSSHx()
    local caminhoArquivoEntrada = "/sdcard/decrypt.txt"
    local caminhoArquivoSaida = "/sdcard/hc.txt"

    local entradaSSH = lerTextoDeArquivo(caminhoArquivoEntrada)

    if not entradaSSH then
        print("Erro ao ler o arquivo de entrada")
        return
    end

    local sshHost, sshPort, sshU, sshP = string.match(entradaSSH, hcRegex["sshEnc"])

    if not sshHost or not sshPort or not sshU or not sshP then
        print("")
        return
    end

    local userIv, senhaIv = calculaIv(sshU, sshP)

    if not userIv or not senhaIv then
        print("Erro ao calcular as IVs")
        return
    end

    local sshUser, sshSenha = dec_user_pass(sshU, userIv, sshP, senhaIv)

    if not sshUser or not sshSenha then
        result = "No Encrypt"
        return
    end

    -- Criar ou abrir o arquivo de saída
    local arquivoSaida = io.open(caminhoArquivoSaida, "a")

    if not arquivoSaida then
        result = "No Encrypt"
        return
    end

    -- Concatenar os resultados
local saida = "\nHost: \"" .. (sshHost or " ") .. "\""
saida = saida .. "\nPort: \"" .. (sshPort or " ") .. "\""
saida = saida .. "\nUsername: \"" .. (sshUser or " ") .. "\""
saida = saida .. "\nPassword: \"" .. (sshSenha or " ") .. "\""
host = (sshHost)
port = (sshPort)
hostt = (sshUser)
pas = (sshSenha)
result = (sshHost ..":".. sshPort .."@".. sshUser ..":".. sshSenha)
    -- Exibir e salvar os resultados
    exibirEInserir(arquivoSaida, " ", saida)
    
-- Fechar o arquivo de saída
    arquivoSaida:close()
end    

processarSSHx()

function payloadx9()
function payload()
    -- Função para remover bytes nulos do início e do final do texto
    local function removeNullBytes(texto)
        return texto:gsub("^[%z]+", ""):gsub("[%z]+$", "")
    end

    -- Função para tentar encontrar palavras-chave e salvar informações
    local function tentarEncontrarPalavrasChave(conteudo, palavrasChave, label)
        conteudo = removeNullBytes(conteudo)

        for _, palavraChave in ipairs(palavrasChave) do
            local inicio, fim = conteudo:find(palavraChave)

            if inicio then
                local inicioJSON = inicio
                local fimJSON = fim

                -- Percorre para trás até encontrar o início real do JSON
                while inicioJSON > 1 and conteudo:sub(inicioJSON - 1, inicioJSON - 1) ~= "\0" do
                    inicioJSON = inicioJSON - 1
                end

                -- Percorre para frente até encontrar o final real do JSON
                while fimJSON < #conteudo and conteudo:sub(fimJSON + 1, fimJSON + 1) ~= "\0" do
                    fimJSON = fimJSON + 1
                end

                local texto = conteudo:sub(inicioJSON, fimJSON)

                -- Exibe e salva no arquivo
                local pay = texto
                teste = (texto) or false
                local arquivoSaida = io.open("/sdcard/hc.txt", "a")

                if not arquivoSaida then
                    print("Falha ao abrir o arquivo de saída.")
                    return
                end

                arquivoSaida:write(label .. ": " .. texto .. "\n")
                arquivoSaida:close()

                return true
            end
        end

        return false
    end

    -- Função para decodificar a payload e salvar no arquivo /sdcard/decrypt.txt
    local function payloadx()
        local arquivo = io.open("/sdcard/decrypt.txt", "rb")

        if not arquivo then
            print("Falha ao abrir o arquivo de entrada.")
            return
        end

        local conteudo = arquivo:read("*a")
        arquivo:close()

        local keywordsPayload = {"PATCH%/", "crlf%]", "Upgrade:", "GET / HTTP%/", "User-Agent", "protocol%]", "lf%]Host:", "lf%host:", "%[host", "host:", "Host:", "%[app_", "%[r", "\\r", "\\n", "\\r\\n", "%[Protocol%]", "lf%]"}
        local labelPayload = "Payload"

        -- Testa todas as palavras-chave para o Payload
        local encontrouPayload = tentarEncontrarPalavrasChave(conteudo, keywordsPayload, labelPayload)

        if encontrouPayload then
            print("")
        else
            teste = " "
        end
    end

    local caminhoArquivoEntrada = "/sdcard/decrypt.txt" -- caminho do arquivo de entrada
    local caminhoArquivoSaida = "/sdcard/hc.txt" -- caminho do arquivo de saída

    payloadx()
end

payload()
end

payloadx9()

function ovpnx9()
function ovpn()
    -- Função para remover bytes nulos do início e do final do texto
    local function removeNullBytes(texto)
        return texto:gsub("^[%z]+", ""):gsub("[%z]+$", "")
    end

    -- Função para tentar encontrar palavras-chave e salvar informações
    local function tentarEncontrarPalavrasChave(conteudo, palavrasChave, label)
        conteudo = removeNullBytes(conteudo)

        for _, palavraChave in ipairs(palavrasChave) do
            local inicio, fim = conteudo:find(palavraChave)

            if inicio then
                local inicioJSON = inicio
                local fimJSON = fim

                -- Percorre para trás até encontrar o início real do JSON
                while inicioJSON > 1 and conteudo:sub(inicioJSON - 1, inicioJSON - 1) ~= "\0" do
                    inicioJSON = inicioJSON - 1
                end

                -- Percorre para frente até encontrar o final real do JSON
                while fimJSON < #conteudo and conteudo:sub(fimJSON + 1, fimJSON + 1) ~= "\0" do
                    fimJSON = fimJSON + 1
                end

                local texto = conteudo:sub(inicioJSON, fimJSON)

                -- Exibe e salva no arquivo
                local pay = texto
                testedd = (texto) or false
                local arquivoSaida = io.open("/sdcard/hc.txt", "a")


                if not arquivoSaida then
                    print("Falha ao abrir o arquivo de saída.")
                    return
                end

                arquivoSaida:write(label .. ": " .. texto .. "")
                arquivoSaida:close()

                return true
            end
        end

        return false
    end

    -- Função para decodificar a payload e salvar no arquivo /sdcard/decrypt.txt
    local function ovpnx()
        local arquivo = io.open("/sdcard/decrypt.txt", "rb")

        if not arquivo then
            print("Falha ao abrir o arquivo de entrada.")
            return
        end

        local conteudo = arquivo:read("*a")
        arquivo:close()

   local keywordsOpenVPN = {"auth%-user%-pass", "dev tun", "%<ca%>", "%<%/ca%>"}
    local labelOpenVPN = "\nOpenVPN"

    -- Testa todas as palavras-chave para o OpenVPN
    local encontrouOpenVPN = tentarEncontrarPalavrasChave(conteudo, keywordsOpenVPN, labelOpenVPN)

    if encontrouOpenVPN then
        print("")
    else
        testedd = " "
    end
end


    local caminhoArquivoEntrada = "/sdcard/decrypt.txt" -- caminho do arquivo de entrada
    local caminhoArquivoSaida = "/sdcard/hc.txt" -- caminho do arquivo de saída

    ovpnx()
end

ovpn()
end

ovpnx9()

function v2rayx9()
function v2ray()
    -- Função para remover bytes nulos do início e do final do texto
    local function removeNullBytes(texto)
        return texto:gsub("^[%z]+", ""):gsub("[%z]+$", "")
    end

    -- Função para tentar encontrar palavras-chave e salvar informações
    local function tentarEncontrarPalavrasChave(conteudo, palavrasChave, label)
        conteudo = removeNullBytes(conteudo)

        for _, palavraChave in ipairs(palavrasChave) do
            local inicio, fim = conteudo:find(palavraChave)

            if inicio then
                local inicioJSON = inicio
                local fimJSON = fim

                -- Percorre para trás até encontrar o início real do JSON
                while inicioJSON > 1 and conteudo:sub(inicioJSON - 1, inicioJSON - 1) ~= "\0" do
                    inicioJSON = inicioJSON - 1
                end

                -- Percorre para frente até encontrar o final real do JSON
                while fimJSON < #conteudo and conteudo:sub(fimJSON + 1, fimJSON + 1) ~= "\0" do
                    fimJSON = fimJSON + 1
                end

                local texto = conteudo:sub(inicioJSON, fimJSON)

                -- Exibe e salva no arquivo
                local pay = texto
                testeddd = (texto)
                local arquivoSaida = io.open("/sdcard/hc.txt", "a")

                if not arquivoSaida then
                    print("Falha ao abrir o arquivo de saída.")
                    return
                end

                arquivoSaida:write(label .. ": " .. texto .. "")
                arquivoSaida:close()

                return true
            end
        end

        return false
    end

    -- Função para decodificar a payload e salvar no arquivo /sdcard/decrypt.txt
    local function v2rayx()
        local arquivo = io.open("/sdcard/decrypt.txt", "rb")

        if not arquivo then
            print("Falha ao abrir o arquivo de entrada.")
            return
        end

        local conteudo = arquivo:read("*a")
        arquivo:close()

   local keywordsV2ray = {"inbounds", "outbounds", "vless:\\/\\/", "vmess:\\/\\/", "trojan:\\/\\/"}
    local labelV2ray = ""

    -- Testa todas as palavras-chave para o OpenVPN
    local encontrouV2ray = tentarEncontrarPalavrasChave(conteudo, keywordsV2ray, labelV2ray)

    if encontrouV2ray then
        print("")
    else
        testeddd= " "
    end
end


    local caminhoArquivoEntrada = "/sdcard/decrypt.txt" -- caminho do arquivo de entrada
    local caminhoArquivoSaida = "/sdcard/hc.txt" -- caminho do arquivo de saída

    v2rayx()
end

v2ray()
end

v2rayx9()

-- Don't move this string
local start = "=====[HC DECRYPTOR]=====\n========================\n"
local final = "========================"

-- Payload filter string and ssh no encrypt
local PAYLOADD = string.match(sshcontent, "[a-zA-Z]+[\x20]+.*[\x5blf\x5d+]+") or " "
local SSH = string.match(sshcontent, "[0-9a-zA-Zx\x2e\x2d]+:[%d]+@[%w\x2e\x2d]+:[%w]+.")

-- Psiphon filter string
local psiph = string.match(content, '[%S]+FRONTED') or " "
local psi = string.match(content, '%FRONTED.-[%w]+[%S][%w]+') or " "

-- Proxy filter string & SNI
local proxy = string.match(content, "%w+.[%w\x2e]+[\x3a][%d]+\0") or " "
local sni = string.match(content, "[%w%.-]+:%d%d+[^😈]-\0([%w%.-]-%.[%w.-]-)\0") or " "

-- slowdns filter string
local pubkey = string.match(content, "[a-zA-Z0-9-]+[a-zA-Z]+[a-zA-Z]+[1,63]+%d%w+") or " "
local dns = string.match(content, "%d%d+[^😈]-\0([%d%.-]-%.[%d.-]-)\0") or " "
local server = string.match(content, "%w%w+[^😈]-\0([%w%.-]-%.[%w.-]-)\0\0") or " "

-- More filter string
local life = string.match(content, "%d%d%d%d[\45]%d%d[\45]%d%d[\32]%d%d[\58]%d%d") or "lifeTime"
local versi = string.match(content, "645") or "645"
local xX = os.date("%d/%m/%Y %I:%M:%S") or " "
local hwid = string.match(content, "false") or "false"
local udpw = string.match(content, "7300") or "7300"

-- do not edit this string
local message = start

local function MobaTeams(label, value)
  if value and value ~= "" then
    message = message .. '[</>] [' .. label .. '] = ' .. value .. '\n'
  end
end

MobaTeams("payload", PAYLOADD)
MobaTeams("expiry", life)
MobaTeams("server_ssh", result)
MobaTeams("server_ssh", SSH)
MobaTeams("openvpn_cerf", testedd)
MobaTeams("proxy_port", proxy)
MobaTeams("sni_ssl", sni)
MobaTeams("udgpw_port", udpgw)
MobaTeams("lock_hwid", hwid)
MobaTeams("psiphon_auth", psiph)
MobaTeams("psiphon_protocol", psi)
MobaTeams("v2ray_cfg", testeddd)
MobaTeams("name_server", server)
MobaTeams("dns_host", dns)
MobaTeams("public_key", pubkey)

if message ~= "" then
  message = message .. final
  gg.alert(message, 'copy json')
  gg.copyText(message, false)
end

local f = io.open("/sdcard/hc.txt", "w")
f:write(message)
print([[
telegram t.me/mobasniff
]])
f:close()
gg.setVisible(false)