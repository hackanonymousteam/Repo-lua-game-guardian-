limit = false
  function rwmem(Address, SizeOrBuffer)
    assert(Address ~= nil, "[rwmem]: error, provided address is nil.")
    _rw = {}
    if type(SizeOrBuffer) == "number" then
      _ = ""
      do
        do
          for _FORV_5_ = 1, SizeOrBuffer do
            _rw[_FORV_5_] = {
              address = Address - 1 + _FORV_5_,
              flags = gg.TYPE_BYTE
            }
          end
        end
      end
      do
        do
          for _FORV_5_, _FORV_6_ in ipairs(gg.getValues(_rw)) do
            if _FORV_6_.value == 0 and limit == true then
              return _
            end
            _ = _ .. string.format("%02X", _FORV_6_.value & 255)
          end
        end
      end
      return _
    end
    Byte = {}
    SizeOrBuffer:gsub("..", function(x)
      Byte[#Byte + 1] = x
      _rw[#Byte] = {
        address = Address - 1 + #Byte,
        flags = gg.TYPE_BYTE,
        value = x .. "h"
      }
    end
    )
    gg.setValues(_rw)
  end
  
  function hexdecode(hex)
    return (hex:gsub("%x%x", function(digits)
      return string.char(tonumber(digits, 16))
    end
    ))
  end
  
  function hexencode(str)
    return (str:gsub(".", function(char)
      return string.format("%2x", char:byte())
    end
    ))
  end
  
  function Dec2Hex(nValue)
    nHexVal = string.format("%X", nValue)
    sHexVal = nHexVal .. ""
    return sHexVal
  end
  
  function ToInteger(number)
    return math.floor(tonumber(number) or error("Could not cast '" .. tostring(number) .. "' to number.'"))
  end
  
  function save(data)
    local function hexencode_spasi(str)
      return (str:gsub(".", function(char)
          return string.format("%02x ", char:byte())
      end))
    end

    local function checkMatch(key, str)
      result = nil
      
      for index, value in ipairs(key) do
          result = str:match(value)
          if result then 
              break 
          end
      end
      
      return result
    end

    local function strip(s)
      return (s:gsub("^%s*(.-)%s*$", "%1"))
    end

    local function prosesData(data)
    

      local function findExpDate(tbl)
          local key = {
              "%d%d%d%d[\45]%d%d[\45]%d%d[\32]%d%d[\58]%d%d",
              "lifeTime"
          } 
          local result = nil
          
          for index_tbl, value_tbl in ipairs(tbl) do
  
              for index_key, value_key in ipairs(key) do
                  
                  if value_tbl:match(value_key) then
                      result = index_tbl
                  end
  
              end
          end
          return result
      end
  
      local function splitString(str, separator)
          local match_1, match_2 = str:match("(.-)"..separator.."(.*)")
          local tbl = {}
  
          no = 1
          while (match_2:match("(.-)"..separator.."(.*)") and no < 100) do
      
              match_1, match_2 = match_2:match("(.-)"..separator.."(.*)")
      
              if hexdecode(match_1):match("[^\x20]+") then
                  table.insert(tbl, strip(hexdecode(match_1):gsub("[^\x20-\x7e]+","")))
              else 
                  table.insert(tbl,"n/a")
              end
              
              no = no + 1
          end
  
          return tbl
      end
      
  
      local function fixedConfig(index, tbl)
          local result_fixedConfig = {}
          local beginIndex = index - 4
          local lastIndex = beginIndex + 31
  
          for i = beginIndex, lastIndex do
              table.insert(result_fixedConfig, tbl[i])
          end
  
          return result_fixedConfig
      end
      data = hexencode_spasi(data)
      data = data:gsub("00", "20")
      data = data:gsub("20", "z")
      data = data:gsub("66 61 6c 73 65", "F A L S E")     
      data = data:gsub("\n", "")
      data = data:gsub("\x20", "")
      local separator = data:match("FALSE[\x7a]+(.-)[\x7a]+")
      data = data:gsub(separator, "0a56616c647947616e74656e67")
      separator = "0a56616c647947616e74656e67"
      data = data:gsub("z", "20")
      data = data:gsub("FALSE", "66616c7365")

      local result = splitString(data, separator)
      local assemblyPointIndex = findExpDate(result)
      local getConfig = fixedConfig(assemblyPointIndex, result)
  
      return getConfig
    end
    local function getOutput(tbl)
      local cfgRegex = {
        [1] = {
            ["name"] = "[</>] Payload",["regex"] = "[a-zA-Z]+[\x20]+.*[\x5bcrlf\x5d]+"     
        },
        [2] = {
            ["name"] = "[</>] Proxy",["regex"] = "[%w\x2e]+[\x3a][%d]+"
        },
        [93] = {
            ["name"] = "[</>] BlockRoot",["regex"] = "(.*)"
        },
        [94] = {
            ["name"] = "[</>] ExtraSniffer",["regex"] = "(.*)"
        },
        [5] = {
            ["name"] = "[</>] Expiration",["regex"] = "(.*)"
        },
--
--        
        [8] = {
            ["name"] = "[</>] SSH",["regex"] = "[0-9a-zA-Zx\x2e\x2d]+:[%d]+@[%w\x2e\x2d]+:[%w]+"
        },
        [99] = {
            ["name"] = "[</>] ProviderLock",["regex"] = "(.*)"
        },
        [10] = {
            ["name"] = "[</>] ProviderID",["regex"] = "[0-9]"
        },
        [111] = {
            ["name"] = "[</>] OpenVPN-Cerf",["regex"] = "(.*)"
        },
        [112] = {
            ["name"] = "[</>] OpenVPN-User:Pass",["regex"] = "(.*)"
        },
        [13] = {
            ["name"] = "[</>] SNI",["regex"] = "[%w\x2e\x2d]+[\x2e]+[%w]+"
        },

        [15] = {
            ["name"] = "[</>] PortUDPGW",["regex"] = "(.*)"
        },
        [17] = {
            ["name"] = "[</>] LockHWID",["regex"] = "(.*)"
        },
        [18] = {
            ["name"] = "[</>] ValueHWID",["regex"] = "(.*)"
        },
        [19] = {
            ["name"] = "[</>] NickPowered",["regex"] = "(.*)"
        },
        [22] = {
            ["name"] = "[</>] BypassPassword",["regex"] = "(.*)"
        },
        [23] = {
            ["name"] = "[</>] Password",["regex"] = "[a-zA-Z0-9]"
        },
--    
        [23] = {
            ["name"] = "[</>] PsiphonAuthorizon",["regex"] = "(.*)"
            },
        [25] = {
            ["name"] = "[</>] PsiphonAuthorizon",["regex"] = "[\x5b]\x22.*]"
--  
        },
        [27] = {
            ["name"] = "[</>] V2Ray",["regex"] = '/({"inbounds.*)/gm'
        },
        [28] = {
            ["name"] = "[</>] VersionApp",["regex"] = "(.*)"
        },
        [30] = {
            ["name"] = "[</>] NameServer",["regex"] = "[%w\x2e\x2d]+[\x2e]+[%w]+"
        },
        [31] = {
            ["name"] = "[</>] PublicKey",["regex"] = "[a-f0-9]+[32,64,50,66,61,6c,73,65]+"
        },
        [32] = {
            ["name"] = "[</>] DNS\n━━━━━━━━━━━━━━━━━━━━━━",["regex"] = "[%w\x2e\x2d]+[\x2e]+[%w]+"
        }
    }
      
      
      local message = "━━━━━━━━━━━━━━━━━━━━━━\n[</>] DECRYPT ➔ HTTP CUSTOM\n[</>] DIRECT FROM ➔ LUA\n━━━━━━━━━━━━━━━━━━━━━━\n"
            for index, value in ipairs(tbl) do
           if cfgRegex[index] and value:match(cfgRegex[index]["regex"]) then
              local namaKonten = cfgRegex[index]["name"]
              local valueRegexKonten = value:match(cfgRegex[index]["regex"])
    
              message = message..namaKonten.."  : `"..valueRegexKonten.."`\n"
           end
            end

           message = message..""
            return message
        end

        local contentToDecrypt = hexdecode(data)
        contentToDecrypt = prosesData(hexdecode(data))
        local hasil = getOutput(contentToDecrypt)
        io.open(gg.EXT_STORAGE .. "/Genzy.txt", "w"):write(hexdecode(data))
        gg.alert(hasil)
        io.open(gg.EXT_STORAGE .. "/hc.txt", "w"):write(hasil)
        gg.copyText(hasil, false)
        gg.toast(hasil)
    end
    
    gg.clearResults()
    gg.setRanges(gg.REGION_JAVA_HEAP)
  gg.searchNumber(":GET / HTTP/", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
  local r = gg.getResults(1)
  if #r < 1 then
    gg.toast("Loading")
    hc_method2 = true
  end
  if hc_method2 then
    gg.searchNumber("Host: ", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("Loading")
      hc_method3 = true
    end
  end
  if hc_method3 then
    gg.searchNumber("h 7B 0A 09 09 22 64 6E 73 22", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("Loading")
      hc_method4 = true
    end
  end
  if hc_method4 then
    gg.searchNumber(":[crlf]", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("Loading")
      hc_method5 = true
    end
  end
  if hc_method5 then
    gg.searchNumber("Upgrade: websocket", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("Loading")
      hc_method6 = true
    end
  end
  if hc_method6 then
    gg.searchNumber(":GET wss:", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("Loading")
      hc_method7 = true
    end
  end
  if hc_method7 then
    gg.searchNumber(":[splitPsiphon][splitPsiphon]", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("Loading")
      hc_method8 = true
    end
  end
  
  if hc_method8 then
    gg.searchNumber(":[splitPsiphon]", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local r = gg.getResults(1)
    if #r < 1 then
      gg.toast("Gagal !")
      hc_method9 = true
    end
  end
  if hc_method9 then
    print("gagal: import Kembali config dengan benar!")
    os.exit()
  end
  local r = gg.getResults(100)
  if limit == false then
    r[1].address = r[1].address - 5678
  end
  readedMem = rwmem(r[1].address, 10000)
  save(readedMem)
  gg.clearResults()
os.exit()
