-- Função para salvar dados em um arquivo local (json_x.txt)
function save(data)
    local outputFileName = "json_x.txt"

    -- Abre o arquivo no modo de escrita no diretório do script
    local outputFile = io.open(outputFileName, "w")

    if outputFile then
        outputFile:write(data) -- Abre o arquivo "json_x.txt" em modo de escrita e escreve o valor contido na variável data.
        gg.toast("🔓 Te peguei, Lionel Richie!")
        outputFile:close()  -- Fecha o arquivo imediatamente após escrever nele
    else
        gg.alert("Pai não encontrado")
    end
end

-- Função para ler o conteúdo do arquivo salvo
function readSaveData()
    local inputFileName = "json_x.txt"

    -- Abre o arquivo no modo de leitura no diretório do script
    local inputFile = io.open(inputFileName, "r")

    if inputFile then
        local data = inputFile:read("*all") -- Lê todo o conteúdo do arquivo
        inputFile:close()  -- Fecha o arquivo
        return data
    else
        return nil
    end
end

-- Função 1 personalizada para decodificar uma string hexadecimal em ASCII
function hdx(hex)
    -- Verifica se hex é uma string válida
    if hex == nil or type(hex) ~= "string" then
        print("Erro: Dados de entrada inválidos para a função hdx.")
        return
    end

    -- Adiciona a letra "D" no final da string hexadecimal
    hex = hex .. "D"

    -- A função `gsub` percorre a string hexadecimal e a converte em caracteres ASCII
    return (string.gsub(hex, "%x%x", function(digits)
        -- A função `tonumber` converte os dígitos hexadecimais em números inteiros
        -- E então, a função `string.char` converte o número em um caractere ASCII correspondente
        return string.char(tonumber(digits, 16))
    end))
end

-- Função 2 personalizada para decodificar uma string hexadecimal em ASCII
function hd(hex)
    return (hex:gsub("%x%x", function(digits) return string.char(tonumber(digits, 16)) end))
end  -- Finaliza a definição da função hd

-- Nessa função, o objetivo é converter uma string hexadecimal em uma string ASCII. A função recebe um parâmetro chamado `hex`, que representa a string em formato hexadecimal a ser convertida.

-- A função utiliza o método `gsub()` para percorrer a string `hex` e substituir cada par de dígitos hexadecimais ("%x%x") pelo caractere ASCII correspondente utilizando a função anônima definida como argumento para `gsub()`. Dentro dessa função anônima, a string de dígitos hexadecimais é convertida em um número decimal utilizando a função `tonumber()`, e então esse número é convertido em um caractere ASCII utilizando a função `string.char()`. O caractere resultante da conversão é retornado como resultado da função `hd()`.

-- Função 3 personalizada para decodificar uma string hexadecimal em ASCII
function hds(hex)
    -- Verifica se hex é uma string válida
    if hex == nil or type(hex) ~= "string" then
        print("Erro: Dados de entrada inválidos para a função hds.")
        return
    end

    -- A função `gsub` percorre a string hexadecimal e a converte em caracteres ASCII
    return (string.gsub(hex, "%x%x", function(digits)
        -- A função `tonumber` converte os dígitos hexadecimais em números inteiros
        -- E então, a função `string.char` converte o número em um caractere ASCII correspondente
        return string.char(tonumber(digits, 16))
    end))
end

-- Função Hentai exibe Primeiro as Primas
function hentai() -- A função "hentai()" tem um nome genérico e pode ser substituído por qualquer outro, se você está comprometido, altere

gg.clearResults() -- `gg.clearResults()`: Essa linha de código limpa todos os resultados que foram obtidos anteriormente, caso haja algum.

results = gg.getListItems() -- `results = gg.getListItems()`: Aqui, uma lista de resultados é obtida usando a função `getListItems()`.

gg.removeListItems(results) -- `gg.removeListItems(results)`: Essa linha de código remove todos os itens da lista de resultados obtidos. Isso é feito para garantir que não haja nenhuma interferência ou sobreposição com outros resultados.

-- Exibe o valor em hexadecimal para a cor branca nula 
print(hd("E385A4")) -- branco nulo

-- Primeiro as primas
print(hd("E2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A1BFE2A09BE2A09BE2A08BE2A089E2A099E2A0BBE2A0BFE2A0BFE2A0BFE2A0BFE2A2BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BF0AE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A1BFE2A083E2A084E2A084E2A084E2A084E2A084E2A084E2A084E2A084E2A0B9E2A3BFE2A3BFE2A3B6E2A3B6E2A3A6E2A3ACE2A2B9E2A3BFE2A3BF0AE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A083E2A084E2A084E2A084E2A3B0E2A3A7E2A180E2A084E2A084E2A084E2A084E2A088E2A299E2A18BE2A3BFE2A3BFE2A3BFE2A2B8E2A3BFE2A3BF0AE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A084E2A084E2A0B0E2A0BCE2A2AFE2A3BFE2A3BFE2A3A6E2A384E2A084E2A084E2A084E2A088E2A2A1E2A3BFE2A3BFE2A3BFE2A2B8E2A3BFE2A3BF0AE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A084E2A084E2A0B8E2A0A4E2A095E2A09BE2A099E2A0B7E2A3BFE2A186E2A084E2A084E2A084E2A3B8E2A3BFE2A3BFE2A18FE2A3BCE2A3BFE2A3BF0AE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A187E2A084E2A084E2A084E2A084E2A084E2A084E2A084E2A084E2A084E2A084E2A084E2A084E2A3B4E2A3BFE2A3BFE2A3BFE2A2A1E2A3BFE2A3BFE2A3BF0AE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A19FE2A084E2A084E2A084E2A084E2A084E2A384E2A084E2A280E2A084E2A084E2A280E2A3A4E2A3BEE2A3BFE2A3BFE2A3BFE2A283E2A3BEE2A3BFE2A3BFE2A3BF0AE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A0BFE2A39BE2A3A1E2A384E2A380E2A084E2A0A0E2A2B4E2A3BFE2A3BFE2A1BFE2A384E2A3B4E2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A283E2A3BEE2A3BFE2A3BFE2A3BFE2A3BF0AE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A18FE2A3BCE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3A9E2A1BDE2A181E2A2B8E2A3BFE2A3BFE2A3BFE2A3BFE2A3BF0AE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A283E2A3BFE2A3BFE2A29FE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3AEE2A2ABE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A39FE2A2BFE2A083E2A084E2A2BBE2A3BFE2A3BFE2A3BFE2A3BF0AE2A3BFE2A3BFE2A3BFE2A3BFE2A1BFE2A3B8E2A09FE2A3B5E2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BEE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3B7E2A384E2A2B0E2A184E2A2BFE2A3BFE2A3BFE2A3BF0AE2A3BFE2A3BFE2A3BFE2A3BFE2A187E2A08FE2A3BCE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3A6E2A0B9E2A18EE2A3BFE2A3BFE2A3BF0AE2A3ADE2A38DE2A09BE2A0BFE2A084E2A2B0E2A08BE2A189E2A0B9E2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A099E2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A19FE2A281E2A099E2A186E2A2A1E2A3BFE2A3BFE2A3BF0AE2A0BBE2A3BFE2A186E2A084E2A3A4E2A088E2A2A3E2A388E2A3A0E2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A08FE2A384E2A0BBE2A3BFE2A3BFE2A3BFE2A3BFE2A3BFE2A386E2A388E2A3B4E2A083E2A3BFE2A3BFE2A3BFE2A3BF0AE2A180E2A088E2A2BFE2A084E2A3BFE2A187E2A084E2A099E2A0BFE2A3BFE2A1BFE2A0BFE2A28BE2A3A5E2A3BEE2A3BFE2A3B7E2A38CE2A0BBE2A2BFE2A3BFE2A3BFE2A1BFE2A09FE2A3A1E2A3BEE2A3BFE2A3BFE2A0BFE2A28B0AE2A09BE2A0B3E2A084E2A2A0E2A3BFE2A087E2A084E2A3B7E2A191E2A2B6E2A3B6E2A2BFE2A3BFE2A3BFE2A3BFE2A3BDE2A3BFE2A3BFE2A3BFE2A3B6E2A3B6E2A190E2A3B6E2A3BFE2A0BFE2A09BE2A3A9E2A184E2A084E2A2B8")) -- `print desenho hentai`: Essa linha exibe o conteúdo específico de hentai, utilizando o comando "print" para exibir e separar casais

os.exit() -- `os.exit()`: Por fim, a função encerra a execução do programa e você continua virgem
end

-- Função para verificar se um elemento está presente em uma tabela
function contains(table, element)
    for _, value in ipairs(table) do
        if value == element then
           return true
        end
    end
    return false
end

-- Função para ler a memória
function rwmem(Address, SizeOrBuffer, Mod)
    -- Verifica se o endereço fornecido não é nulo
    assert(Address ~= nil, "[rwmem]: endereço nulo, não erre de novo")

    -- Inicializa variáveis locais
    local result = ""
    local rw = {}
    local ly = {}
    local ly_v2 = {}

    -- Verifica se SizeOrBuffer é um número
    if type(SizeOrBuffer) == "number" then
        -- Cria uma tabela rw com endereços consecutivos a partir do Address
        for i = 1, SizeOrBuffer do
            rw[i] = {address = Address + i - 1, flags = gg.TYPE_BYTE}
        end

        -- Itera sobre os valores obtidos da memória
        for _, value in ipairs(gg.getValues(rw)) do
            -- Modo 1: busca por padrão específico
            if Mod == 1 and value.value == 93 then
                -- Obtém valores em torno do ponto de interesse
                for ap = 1, 3 do
                    ly[ap] = {address = value.address + ap, flags = gg.TYPE_BYTE}
                end
                local res = gg.getValues(ly)
                
                -- Verifica padrões para determinar o início e fim de um bloco JSON
                if res[1].value == 10 and res[2].value == 125 or
                   res[1].value == 125 or
                   res[1].value == 32 and res[2].value == 125 or
                   res[2].value == 10 and res[3].value == 125 then
                    return "7B" .. result .. "5D7D"
                end
            end

            -- Modo 2: busca por outro padrão específico
            if Mod == 2 and value.value == 125 then
                -- Obtém valores em torno do ponto de interesse
                for ap2 = 1, 3 do
                    ly_v2[ap2] = {address = value.address + ap2, flags = gg.TYPE_BYTE}
                end
                local res = gg.getValues(ly_v2)
                
                -- Verifica padrões para determinar o início e fim de um bloco JSON
                if res[1].value == 93 or
                   res[1].value == 10 and res[2].value == 93 or
                   res[1].value == 32 and res[2].value == 93 or
                   res[2].value == 10 and res[3].value == 93 then
                    return result .. "5D7D"
                end
            end

            -- Converte o valor para hexadecimal e adiciona ao resultado
            result = result .. string.format("%02X", value.value & 0xFF)
        end

        return result
    end

    -- Se SizeOrBuffer não for um número, presume-se que seja uma string
    local Byte = {}
    SizeOrBuffer:gsub("..", function(x)
        -- Cria uma tabela Byte com os valores da string
        Byte[#Byte + 1] = x
        rw[#Byte] = {address = Address + #Byte - 1, flags = gg.TYPE_BYTE, value = x .. "h"}
    end)

    -- Define valores na memória com base na string fornecida
    gg.setValues(rw)
end

-- Aplica novos valores aos resultados (adaptar conforme necessário)
-- Itera sobre os resultados e define seus valores como 1000 (flags: TYPE_FLOAT)
function applyNewValues(results)
    for _, result in ipairs(results) do
        result.flags = gg.TYPE_FLOAT
        result.value = "1000"
    end
end

function strToHex(str)
    local hex = ""  -- Inicializa uma variável vazia para armazenar a representação hexadecimal da string.
    for i = 1, #str do  -- Percorre cada caractere da string.
        local char = string.byte(str, i)  -- Converte o caractere atual em um valor numérico correspondente ao seu código ASCII.
        hex = hex .. string.format("%02X", char)  -- Formata o valor numérico como uma sequência hexadecimal de 2 dígitos, e adiciona na string hex.
    end
    return hex  -- Retorna a representação hexadecimal da string.
end  -- Finaliza a definição da função strToHex.

-- Nessa função, o objetivo é converter uma string em uma representação hexadecimal. A função recebe um parâmetro chamado `str`, que representa a string a ser convertida.

-- A função itera sobre cada caractere da string utilizando um loop `for`, de 1 até o comprimento da string (`#str`). A cada iteração, o caractere atual é convertido em um valor numérico correspondente ao seu código ASCII utilizando a função `string.byte()`. Em seguida, o valor numérico é formatado como uma sequência hexadecimal de 2 dígitos utilizando a função `string.format()`, e essa sequência é concatenada à string `hex`. 

-- Ao final das iterações, a função retorna a representação hexadecimal da string, que foi armazenada na variável `hex`.

local keywordPattern = nil  -- Declaração inicial da variável keywordPattern como nil.

function promptUserForKeyword()
    if not keywordPattern then  -- Verifica se a variável keywordPattern ainda é nula.
        local dlgPrompt = gg.prompt({"Diga qual é o meu nome: "}, nil, {"text"})  -- Exibe uma caixa de diálogo para o usuário inserir um valor.

        if dlgPrompt and dlgPrompt[1] then  -- Verifica se a caixa de diálogo foi exibida e se o usuário digitou um valor.
            keywordPattern = dlgPrompt[1]  -- Atribui o valor digitado pelo usuário à variável keywordPattern.
            gg.toast("Localizar pai em 10s: " .. keywordPattern)  -- Exibe uma mensagem toast com o valor digitado pelo usuário.
        else
            gg.alert(hd("7072696D6569726F206173207072696D6173"))  -- Executa a função hd() para exibir um alerta com uma string hexadecimal.
            print(hd("5245494E4943494152203D20726561627265206120646976657273C3A36FF09F909D0A434F50494152203D207065727665727469646F20F09F988FF09F949E0A4F4B203D2066696E616C697A6172E298A0EFB88F"))  -- Executa a função hd() para imprimir uma string hexadecimal.
            hentai()  -- Chama uma função chamada hentai() que está definida lá em cima, gatilho
            return nil  -- Retorna nulo para indicar que não foi possível obter um padrão de palavras-chave.
        end
    end

    return keywordPattern  -- Retorna o padrão de palavras-chave obtido do usuário ou anteriormente armazenado.
end  -- Finaliza a definição da função promptUserForKeyword.

-- Nesse trecho de código, temos a função `promptUserForKeyword()`, cujo objetivo é exibir uma caixa de diálogo para o usuário inserir um valor e retorná-lo como um padrão de palavras-chave.

-- Inicialmente, a função verifica se a variável `keywordPattern` está vazia usando o condicional `if not keywordPattern`. Caso esteja vazia, a função exibe a caixa de diálogo `dlgPrompt` para o usuário inserir um valor através do `gg.prompt()`. Se o usuário inserir um valor válido, esse valor é atribuído à variável `keywordPattern` e uma mensagem toast é exibida com o valor. Caso contrário, um alerta contendo uma string hexadecimal é exibido através do `gg.alert()`, em seguida, outra string hexadecimal é impressa na saída padrão do console utilizando o `print()`, uma função chamada `hentai()` é chamada (que não foi definida neste trecho de código) e finalmente, a função retorna nulo (`nil`) indicando que não foi possível obter um padrão de palavras-chave.

-- Caso a variável `keywordPattern` não esteja vazia, a função simplesmente retorna o valor já armazenado anteriormente na variável `keywordPattern`.

-- Função para limpar os resultados
function clearResults()
    gg.clearResults()
end

-- Offset inicial para obter um bloco mais extenso
-- local startOffset = -15806

-- Offset final para limitar o tamanho do bloco
-- local endOffset = 50000

-- Mantenha o registro da última posição capturada
-- local lastCapturedAddress = nil

-- Mantenha o registro do último bloco de memória capturado
-- local lastCapturedMemoryBlock = nil

-- Lista para armazenar os resultados de busca
local searchResults = {}

-- Função na lógica de @LightXVD para capturar JSON da memória e salvar em um único arquivo
-- Função para capturar e salvar JSON da memória
function captureAndSaveJsonMemory()

    -- Torna o coletor de impostos invisível
    gg.setVisible(false)
    
    -- Limpa os resultados antigos antes de cada busca
    clearResults()

-- Se você quiser predefinir as faixas de pesquisa antecipadamente, descomente uma delas, edite como quiser

-- gg.setRanges(gg.REGION_JAVA_HEAP) -- Define as faixas de pesquisa antes de cada busca

-- Define o intervalo de endereços para a região de alocação C, JAVA HEAP e ANONYMOUS
-- gg.setRanges(gg.REGION_C_ALLOC | gg.REGION_JAVA_HEAP | gg.REGION_ANONYMOUS)

-- gg.setRanges(gg.REGION_C_ALLOC) -- Define as faixas de pesquisa antes de cada busca
    
    -- Solicita a palavra-chave personalizada do usuário
    local userInput = promptUserForKeyword()

    -- Verifica se o usuário inseriu alguma palavra-chave
    if not userInput or userInput == "" then
        gg.toast("Calma aí, Paizão")
        return
    end

    -- Converte a palavra-chave para o formato hex
    local keywordPattern = "h " .. strToHex(userInput)
    
    -- Realiza a busca na memória para encontrar a palavra-chave dentro do JSON
    gg.searchNumber(keywordPattern, gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
    local resultsKeyword = gg.getResults(1000)
    
    -- Limpa os resultados de pesquisa existentes
    clearResults()
    
    -- Verifica se há resultados de pesquisa disponíveis
    if next(resultsKeyword) ~= nil then
        -- Exibe uma mensagem de toast com a palavra chave encontrada
        gg.toast("Pai encontrado: " .. hd(keywordPattern))
    else
        -- Exibe um alerta com a palavra chave não encontrada
        gg.alert("Palavra chave " .. hd(keywordPattern) .. " não encontrada")
        -- Exibe uma mensagem de toast com a palavra chave não encontrada
        gg.toast("Palavra chave " .. hd(keywordPattern) .. " não encontrada.")
        gg.alert(hd("63616C6D612C20626172626F6C65746120F09FA68B0A696D706F727465206F206172717569766F206E6F76616D656E746520650A65786563757465206F2073637269707420646120736F72746520656D203320736567756E646F73"))
    print(hd("5245494E4943494152203D20726561627265206120646976657273C3A36FF09F909D0A434F50494152203D207065727665727469646F20F09F988FF09F949E0A4F4B203D2066696E616C697A6172E298A0EFB88F"))
    print("Pai não encontrado: " .. hd(keywordPattern) .. " , foco, Leonard, foco!")
    hentai()
        return
    end

    for _, keywordAddress in ipairs(resultsKeyword) do
        local jsonStart = keywordAddress.address
        local jsonEnd = jsonStart

        -- Percorre para trás até encontrar o início real do JSON
        while rwmem(jsonStart - 1, 1, 1) ~= "00" do
            jsonStart = jsonStart - 1
        end

        -- Percorre para frente até encontrar o final do JSON
        while rwmem(jsonEnd, 1, 1) ~= "00" do
            jsonEnd = jsonEnd + 1
        end

        local memoryBlock = rwmem(jsonStart, jsonEnd - jsonStart, 1)
        local capturedJson = string.sub(memoryBlock, 1, -2)  -- Remove o último byte nulo

        -- Atualiza o arquivo com o conteúdo JSON
        -- Salva os dados
save(hdx(capturedJson, false)) -- Chama a função save() passando o valor retornado pela função hdx(capturedJson) como argumento.
        
        applyNewValues(searchResults)
        -- Limpa os resultados de pesquisa novamente
        clearResults()
        
        -- Exibe uma mensagem de toast com a palavra chave encontrada
        gg.toast("Pai encontrado: " .. hd(keywordPattern))

        -- Limpa os resultados de pesquisa novamente
        clearResults()

        -- Itera sobre os resultados e define seus valores como 1000 (flags: TYPE_FLOAT)
        for i, result in ipairs(resultsKeyword) do
            result.flags = gg.TYPE_FLOAT
            result.value = "1000"
        end

        -- Define os novos valores
        gg.setValues(resultsKeyword)

        -- Limpa os resultados de pesquisa mais uma vez (repetição redundante)
        clearResults()
        
        gg.toast(hdx(capturedJson))  -- Mostra uma mensagem rápida na tela, utilizando o valor retornado pela função hdx(capturedJson).

gg.alert(hdx(capturedJson))  -- Mostra uma caixa de diálogo com o valor retornado pela função hdx(capturedJson).

-- Lê o conteúdo salvo
local savedData = readSaveData()

-- Copia para a área de transferência se houver dados salvos
if savedData then
    gg.copyText(savedData) -- Copia o valor retornado pela função hdx(capturedJson) para a área de transferência.
    print(hdx(capturedJson))  -- Mostra o resultado do valor retornado pela função hdx(capturedJson).
end

return capturedJson, jsonStart  -- Retorna as variáveis capturedJson e jsonStart como resultados da função.

end  -- Finaliza a função definida anteriormente.

gg.toast("Chegou tão perto")  -- Mostra uma mensagem rápida na tela com o texto "Chegou tão perto".
end

--[[
function findJsonBoundaries(memoryBlock)
    local jsonStart, jsonEnd

    -- Encontrar o início do JSON ignorando caracteres inválidos
    local startPos = memoryBlock:find('{"', 1, true)

    if startPos then
        jsonStart = startPos
    else
        return nil, nil  -- Não encontrou o padrão de início do JSON
    end

    -- Encontrar o final do JSON
    local lastBrace = memoryBlock:match('.*}()')

    if lastBrace then
        jsonEnd = lastBrace - 1
    end

    return jsonStart, jsonEnd
end
]]--

local keywordPattern = promptUserForKeyword()
local hexPattern = "h " .. strToHex(keywordPattern)

captureAndSaveJsonMemory()