local version = "1.0"

local request = gg.makeRequest('https://hastebin.skyra.pw/raw/elasamacin')

if request ~= nil and request.content ~= nil then
    local response = request.content
    local onlineVersion = response:match('"version"%s*:%s*"(.-)"')
    local downloadLink = response:match('"link"%s*:%s*"(.-)"')
    
    if version ~= onlineVersion then
        gg.alert('new update. updating...')
        
        local downloadRequest = gg.makeRequest(downloadLink)        
        if downloadRequest ~= nil and downloadRequest.content ~= nil then
            local newScript = downloadRequest.content
            
local name = 'new.version.lua'

local path = "/sdcard/"

local file = io.open(path .. name, "wb")
if file then
    file:write(newScript)
    file:close()
    gg.alert('new script  updated save in ' .. path .. name)
else
    gg.alert('failed to save new script updated.')
end
end
end
end