--creator this painel @batmangamesS
--not change credits
-- my channel https://t.me/BatmanGamesChannel


function painel() 
enc = gg.choice({
"upload file",
"delete file",
"link file",
"download file",
"exit"
},0,"")
if enc == 1 then encv1() end
if enc == 2 then encv2() end
if enc == 3 then encv3() end
if enc == 4 then encv4() end
if enc == 5 then os.exit() end

BATMAN = -1
end
--------------------------------------------------------------------------------------------------------
function encv1() 

function urlDecode(encodedStr)
    local decodedStr = encodedStr:gsub('%%(%x%x)', function(hex)
        return string.char(tonumber(hex, 16))
    end)
    return decodedStr
end

function getKey()
    local chave_oculta
    repeat
        chave_oculta = math.random(1, 255)
    until chave_oculta >= 1 and chave_oculta <= 255
    return chave_oculta
end

function enc(str)
    local chave_oculta = getKey()
    local hash = ''
    local tamanho_str = #str
    for i = 1, tamanho_str do
        local byte = str:byte(i) or 0
        local valor = byte + chave_oculta
        valor = valor % 256
        hash = hash .. string.format('%02x', valor)
    end
    return string.format("%03d%s", chave_oculta, hash)
end

function uploadFile(filePath, fileName)

    gg.alert("Wait, it will encode the file and then send it to the server")
   
 local file = io.open(filePath, "rb")
    if not file then
        gg.alert("Erro open file.")
        return
    end
    
    local data = file:read('*a')
    file:close()
    
    local fileContentBase64 = enc(data)
    
    local postData = "hash=" .. urlDecode(fileContentBase64) .. "&filename=" .. urlDecode(fileName)

    local headers = {
        ["Content-Type"] = "application/x-www-form-urlencoded"
    }

local url = "http://YOUR_SERVER_HERE/Server_script/upload_script.php"
 
   local response = gg.makeRequest(url, headers, postData)

    if type(response) == "table" then
        
        if response.content == "true" then
            gg.alert("Upload  sucess!")
            os.exit()
        else
            gg.alert("Erro  upload: " .. response.content)
        end
    else
        gg.alert("Erro request: " .. response)
    end
end

g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end

while true do
  g.info = gg.prompt({
    'Select file to upload:'
  
  }, g.info, {
    'file' -- 1
  })

  if g.info == nil then
    return
  end

  local myFile = g.info[1]

  local FileName = myFile:match("[^/]+$")

  gg.saveVariable(g.info, g.config)
  g.last = myFile

  uploadFile(g.last, FileName)
end
 end
--------------------------------------------------------------------------------------------------------
function encv2() 

local request = gg.makeRequest('http://YOUR_SERVER_HERE/Server_script/uploads/list.php')
local response = request.content

local pattern = '<p>(.-)</p>'
local paragraphs = {}
local filenames = {}

for content in response:gmatch(pattern) do
    
    if not (content:find('list.php') or content:find('delete.php')) then
        table.insert(paragraphs, content)
        table.insert(filenames, content)  
    end
end

table.insert(paragraphs, 'exit')

local choice
repeat
    choice = gg.choice(paragraphs, nil, 'SELECT FILE:')
    if choice == nil then
        return 
    end
until choice ~= nil

if choice == #paragraphs then
    gg.alert('thanks to use my script...')
else
    
    local filename = filenames[choice]
    
    local fileRequest = gg.makeRequest('http://YOUR_SERVER_HERE/Server_script/uploads/delete.php?file=' .. filename)
    local fileResponse = fileRequest.content
    
     gg.alert(fileResponse)
end
end
--------------------------------------------------------------------------------------------------------
function encv3() 

local request = gg.makeRequest('http://YOUR_SERVER_HERE/Server_script/uploads/list.php')
local response = request.content

local pattern = '<p>(.-)</p>'
local paragraphs = {}
local filenames = {}

for content in response:gmatch(pattern) do
    
    if not (content:find('list.php') or content:find('delete.php')) then
        table.insert(paragraphs, content)
        table.insert(filenames, content)  
    end
end

table.insert(paragraphs, 'exit')

local choice
repeat
    choice = gg.choice(paragraphs, nil, 'SELECT FILE:')
    if choice == nil then
        return 
    end
until choice ~= nil

if choice == #paragraphs then
    gg.alert('thanks for use my script...')
else
    local filename = filenames[choice]
local fileRequest = gg.makeRequest('http://YOUR_SERVER_HERE/Server_script/domain.php')
local fileResponse = fileRequest.content

local finalURL = 'http://'..fileResponse .. '/Server_script/uploads/' .. filename

gg.alert(finalURL)

gg.copyText(finalURL)

print(finalURL)

end
end
--------------------------------------------------------------------------------------------------------
function encv4() 

local request = gg.makeRequest('http://YOUR_SERVER_HERE/Server_script/uploads/list.php')
local response = request.content

local pattern = '<p>(.-)</p>'
local paragraphs = {}
local filenames = {}

for content in response:gmatch(pattern) do
    
    if not (content:find('list.php') or content:find('delete.php')) then
        table.insert(paragraphs, content)
        table.insert(filenames, content)  
    end
end

table.insert(paragraphs, 'exit')

local choice
repeat
    choice = gg.choice(paragraphs, nil, 'SELECT FILE:')
    if choice == nil then
        return 
    end
until choice ~= nil

if choice == #paragraphs then
    gg.alert('thanks for use my script...')
else
        local filename = filenames[choice]
    
local fileRequest = gg.makeRequest('http://YOUR_SERVER_HERE/Server_script/domain.php')
local fileResponse = fileRequest.content

local finalURL = 'http://'..fileResponse .. '/Server_script/uploads/' .. filename

    local image_content = gg.makeRequest(finalURL).content
    if image_content == nil then
        gg.alert('Failed to download .')
        return
    end
    
    local path = "/sdcard/Download/"
    gg.alert('Downloading file')
    
    local file = io.open(path .. filename, "wb")
    if file then
        file:write(image_content)
        file:close()
        gg.alert('saved in ' .. path .. filename)
    else
        gg.alert('Failed to save file.')
    end
    end
end
--------------------------------------------------------------------------------------------------------

while(true)do if gg.isVisible(true)then BATMAN = 1 gg.setVisible(false)end
if BATMAN == 1 then painel()end
end 