<?php

$baseDir = dirname(__FILE__);


$fileName = isset($_GET['file']) ? $_GET['file'] : '';


if ($fileName) {
    
    $filePath = $baseDir . '/' . $fileName;

    
    if (file_exists($filePath)) {
        
        if (unlink($filePath)) {
            echo json_encode(["status" => "sucess", "msg" => "file deleted sucess."]);
        } else {
            echo json_encode(["status" => "erro", "msg" => "Erro ."]);
        }
    } else {
        echo json_encode(["status" => "erro", "msg" => "file no found."]);
    }
} else {
    echo json_encode(["status" => "erro", "msg" => "invalid filename."]);
}
?>