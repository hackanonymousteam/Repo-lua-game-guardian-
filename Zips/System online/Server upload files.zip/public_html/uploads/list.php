<?php

$diretorio = __DIR__; 

if ($handle = opendir($diretorio)) {
    echo "<h1>files in folder '$diretorio'</h1>";
    
    
    while (false !== ($arquivo = readdir($handle))) {
        
        if ($arquivo != "." && $arquivo != "..") {
            
            echo "<p>$arquivo</p>";
        }
    }
    
    
    closedir($handle);
} else {
    echo "erro open folder.";
}
?>