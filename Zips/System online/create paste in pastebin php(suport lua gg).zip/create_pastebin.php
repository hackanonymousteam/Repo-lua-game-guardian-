<?php

$api_dev_key = isset($_GET['api_dev_key']) ? $_GET['api_dev_key'] : '';
$api_paste_code = isset($_GET['api_paste_code']) ? $_GET['api_paste_code'] : 'Texto padrão'; // Texto padrão se não for fornecido

if (!$api_dev_key) {
    echo "required key .";
    exit;
}

$api_paste_private = '1'; // 1 = no listed
$api_paste_name = 'my_simple_paste';
$api_paste_expire_date = 'N'; // never
$api_paste_format = 'text';

$api_paste_name = urlencode($api_paste_name);
$api_paste_code = urlencode($api_paste_code);

$url = 'https://pastebin.com/api/api_post.php';
$ch = curl_init($url);

curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'api_option=paste&api_paste_private='.$api_paste_private.'&api_paste_name='.$api_paste_name.'&api_paste_expire_date='.$api_paste_expire_date.'&api_paste_format='.$api_paste_format.'&api_dev_key='.$api_dev_key.'&api_paste_code='.$api_paste_code);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

$response = curl_exec($ch);
curl_close($ch);

if (strpos($response, 'Bad API request') === false && !empty($response)) {
    
    $paste_key = trim($response);
    $paste_url = "https://pastebin.com/$paste_key";
    echo "Sucess! link paste: <a href='$paste_url' target='_blank'>$paste_url</a>";
} else {
    
    echo "Erro: $response";
}
?>