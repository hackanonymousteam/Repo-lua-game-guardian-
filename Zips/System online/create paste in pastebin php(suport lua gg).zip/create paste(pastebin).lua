local function urlencode(char)
    local byte = string.byte(char)
    local hex = string.format("%02X", byte)
    return "%" .. hex
end

local function url_encode(str)
    local encoded_str = ""
    for i = 1, #str do
        local char = string.sub(str, i, i)
        if char:match("[^%w%-_%.~]") then
            encoded_str = encoded_str .. urlencode(char)
        else
            encoded_str = encoded_str .. char
        end
    end
    return encoded_str:gsub(" ", "+")
end

local chat = gg.prompt({'Enter your API key (Pastebin)'}, {}, {'text'})
if chat == nil or #chat == 0 then
    print('API key not provided.')
    return
end
local duck = chat[1]

local chatt = gg.prompt({'Enter your text'}, {}, {'text'})
if chatt == nil or #chatt == 0 then
    print('Pastebin code not provided.')
    return
end
local chup = chatt[1]

local encoded_str = url_encode(chup)

local request = gg.makeRequest('https://YOUR_SERVER_HERE/create_pastebin.php?api_dev_key=' .. duck .. '&api_paste_code=' .. encoded_str)

if request == nil or request.content == nil then
    print('Error: No response received.')
    return
end

local response = request.content
local function extract_link(response)
    
    local last_part = response:match("https://pastebin.com/([^/]+)</a>")
    if last_part then
        return "https://pastebin.com/" .. last_part
    else
        return nil
    end
end

local extracted_link = extract_link(response)

if extracted_link then
    print("Success! Paste link: " .. extracted_link)
else
    print("Error: Link not found.")
end