local function myHash_from_file(file_path)
    local A = 0x67452301
    local B = 0xefcdab89
    local C = 0x98badcfe
    local D = 0x10325476

    local S11, S12, S13, S14 = 7, 12, 17, 22
    local S21, S22, S23, S24 = 5, 9, 14, 20
    local S31, S32, S33, S34 = 4, 11, 16, 23
    local S41, S42, S43, S44 = 6, 10, 15, 21

    local function F(x, y, z) return (x & y) | (~x & z) end
    local function G(x, y, z) return (x & z) | (y & ~z) end
    local function H(x, y, z) return x ~ y ~ z end
    local function I(x, y, z) return y ~ (x | ~z) end

    local function process(func, a, b, c, d, x, s, ac)
        a = (a + func(b, c, d) + x + ac) & 0xFFFFFFFF
        return (((a << s) | (a >> (32 - s))) + b) & 0xFFFFFFFF
    end

    local function padMessage(s)
        local len = #s
        local bitLen = len * 8
        s = s .. "\x80"
        while (#s % 64) ~= 56 do
            s = s .. "\x00"
        end
        for i = 1, 8 do
            s = s .. string.char(bitLen & 0xFF)
            bitLen = bitLen >> 8
        end
        return s
    end

    local function processBlocks(s)
        for i = 1, #s, 64 do
            local block = {A, B, C, D}
            local X = {}
            for j = 0, 15 do
                X[j] = 0
                for k = 1, 4 do
                    X[j] = X[j] + (s:byte(i + j * 4 + k - 1) << ((k - 1) * 8))
                end
            end

            A = process(F, A, B, C, D, X[0], S11, 0xd76aa478)
            D = process(F, D, A, B, C, X[1], S12, 0xe8c7b756)
            C = process(F, C, D, A, B, X[2], S13, 0x242070db)
            B = process(F, B, C, D, A, X[3], S14, 0xc1bdceee)

            A = process(G, A, B, C, D, X[5], S21, 0xf57c0faf)
            D = process(G, D, A, B, C, X[6], S22, 0x4787c62a)
            C = process(G, C, D, A, B, X[7], S23, 0xa8304613)
            B = process(G, B, C, D, A, X[8], S24, 0xb00327c8)

            A = process(H, A, B, C, D, X[0], S31, 0x04881d05)
            D = process(H, D, A, B, C, X[7], S32, 0xd9d4d039)
            C = process(H, C, D, A, B, X[14], S33, 0xe6db99e5)
            B = process(H, B, C, D, A, X[5], S34, 0x1fa27cf8)

            A = process(I, A, B, C, D, X[12], S41, 0x21e1cde6)
            D = process(I, D, A, B, C, X[15], S42, 0xc33707d6)
            C = process(I, C, D, A, B, X[2], S43, 0xf4d50d87)
            B = process(I, B, C, D, A, X[9], S44, 0x455a14ed)

            A = (A + block[1]) & 0xFFFFFFFF
            B = (B + block[2]) & 0xFFFFFFFF
            C = (C + block[3]) & 0xFFFFFFFF
            D = (D + block[4]) & 0xFFFFFFFF
        end
    end

    local function read_file_in_blocks(file_path)
        local f, err = io.open(file_path, "rb")
        if not f then
            return nil, "Erro open file: " .. (err or "file no found")
        end

        local content = ""
        while true do
            local block = f:read(4096)
            if not block then break end
            content = content .. block
        end

        f:close()
        return content
    end

    local file_content, err = read_file_in_blocks(file_path)
    if not file_content then
        return nil, err
    end

    file_content = padMessage(file_content)
    processBlocks(file_content)

    local function toHex(num)
        return string.format("%02x", num)
    end

    return toHex(A) .. toHex(B) .. toHex(C) .. toHex(D)
end

local file_path = gg.getFile()

local myHash_hash, err = myHash_from_file(file_path)

if myHash_hash then
    print("Hash file : " ..myHash_hash)
else
    print("Erro: " .. err)
end

local url = 'http://YOUR_SERVER_HERE/my_hash.txt'

local request = gg.makeRequest(url)
if not request or not request.content then
    gg.alert('Erro request online')
    return
end

local graf = request.content

if graf then
    if graf == myHash_hash then
        print("verify hash sucess")
    else
        gg.alert("file modified")
        os.exit()
    end
else
    print("Erro: " .. err)
end