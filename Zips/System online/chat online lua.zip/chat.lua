local inicio = gg.choice({
    "🗃️ Send Message 🗃️",
    "❇️ Read Messages ❇️",
    "❌ Exit ❌"
})

function urlencode(str)
    str = string.gsub(str, "\n", "\r\n")
    str = string.gsub(str, "([^%w])", function(c)
        return string.format("%%%02X", string.byte(c))
    end)
    str = string.gsub(str, " ", "+")
    return str
end

function START1()
    local chat = gg.prompt({'Send your text'}, {}, {'text'})
    if chat == nil then
        return
    end

    local duck = chat[1]
    
    local url = 'http://YOUR_SERVER_HERE/send.php?texto='..urlencode(duck)
    local request = gg.makeRequest(url)
    if request == nil or request.content == nil then
        print('Error getting reply.')
        return
    end

    local response = request.content
    gg.alert(response)
end

function START2()
    local url = 'http://YOUR_SERVER_HERE/read.php'
    local request = gg.makeRequest(url)
    if request == nil or request.content == nil then
        print('Error getting reply.')
        return
    end

    local response = request.content
    gg.alert(response)
end

if inicio == 1 then
    START1()
elseif inicio == 2 then
    START2()
elseif inicio == 3 then
    
else

    print("Invalid choice.")
end