
local my_gg = "YOUR_PACKAGE_GAME_GUARDIAN_HERE" --  replace with (your package name gg)

local block 
local graf = gg.PACKAGE

if graf then
    if graf == my_gg then
      block = false
    else
        block = true
    end
else
    gg.alert("Failed to get the package name")
    os.exit()
end

local Link = "https://browserleaks.com/ip"
local bat = gg.makeRequest(Link).content

if bat == nil then
    os.exit()
end

local response = bat

local function extractDataIPFromHTML(html)
    local pattern = 'data%-ip%="([%d%.]+)"'
    local dataIP = html:match(pattern)
    return dataIP
end

local dataIP = extractDataIPFromHTML(response)

if not dataIP then
    print('Error.')
else
    
end

local Link2 = 'http://YOUR_SERVER_HERE/check.ip.php?ip=' .. dataIP .. '&check=' .. tostring(block)
local bat3 = gg.makeRequest(Link2).content

if bat3 == nil then
    os.exit()
end

local response = bat3
gg.alert(response)

local LinkJSON = 'http://YOUR_SERVER_HERE/ips.json'
local bat4 = gg.makeRequest(LinkJSON).content

if bat4 == nil then
    os.exit()
end

local function extractDataFromJSON(json)
    
    local pattern = '"(.-)"'
    local result = {}

    for match in json:gmatch(pattern) do
        table.insert(result, match)  
    end

    return result  
end

local result = extractDataFromJSON(bat4)

local ipFound = false
for _, ip in ipairs(result) do
    if dataIP == ip then
        ipFound = true
        break
    end
end

if ipFound then
    gg.alert("ip blocked")
else
    
    gg.alert("check success")
end