<?php

$jsonFile = 'ips.json';
 
function lerJson($jsonFile) {
    if (file_exists($jsonFile)) {
        $conteudo = file_get_contents($jsonFile);
        return json_decode($conteudo, true);
    }
    return [];
}


function escreverJson($jsonFile, $dados) {
    file_put_contents($jsonFile, json_encode($dados, JSON_PRETTY_PRINT));
}


$ip = isset($_GET['ip']) ? $_GET['ip'] : null;
$check = isset($_GET['check']) ? $_GET['check'] : null;


if ($ip !== null && ($check === 'true' || $check === 'false')) {
    
    $dados = lerJson($jsonFile);

    
    if ($check === 'true' && !in_array($ip, $dados)) {
        
        $dados[] = $ip;  
        escreverJson($jsonFile, $dados);
    }

    
    echo "Checking...";
} else {
    
    echo "erro.";
}
?>