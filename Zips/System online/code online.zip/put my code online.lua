
local chat = gg.prompt({'Enter your code here'}, {}, {'text'})
if chat == nil then
    return
end

local duck = chat[1]

local request = gg.makeRequest('http://YOUR_SERVER_HERE/Text_server.php?text='..duck)


if request.status == 200 then
    gg.alert('error!')
else
    gg.alert('Sucess.')
    print('code save in http://YOUR_SERVER_HERE/my.code.lua')
end