<?php
error_reporting(0);


function store_text_data($text) {
    $file = 'my.code.lua'; 
    
    $handle = fopen($file, 'a');
    
    if ($handle === false) {
        exit("⚠ Failed to open file ⚠");
    }

    
    fwrite($handle, $text . "\n");
    fwrite($handle, "----------------------\n");

    
    fclose($handle);
}


if (isset($_GET['text'])) {
    $text = trim($_GET['text']);
    
    if (empty($text)) {
        exit("⚠ error: empty text ⚠");
    }

    
    store_text_data($text);

    exit("Success ✅");
} else {
    exit("⚠ error: no text parameter ⚠");
}
?>