
function encv1() 

function urlDecode(encodedStr)
    local decodedStr = encodedStr:gsub('%%(%x%x)', function(hex)
        return string.char(tonumber(hex, 16))
    end)
    return decodedStr
end

function getKey()
    local chave_oculta
    repeat
        chave_oculta = math.random(1, 255)
    until chave_oculta >= 1 and chave_oculta <= 255
    return chave_oculta
end

function enc(str)
    local chave_oculta = getKey()
    local hash = ''
    local tamanho_str = #str
    for i = 1, tamanho_str do
        local byte = str:byte(i) or 0
        local valor = byte + chave_oculta
        valor = valor % 256
        hash = hash .. string.format('%02x', valor)
    end
    return string.format("%03d%s", chave_oculta, hash)
end

function uploadFile(filePath, fileName)

    gg.alert("wait... encoding file")
   
 local file = io.open(filePath, "rb")
    if not file then
        gg.alert("Erro open file.")
        return
    end
    local data = file:read('*a')
    file:close()
    
    local fileContentBase64 = enc(data)
    local postData = "hash=" .. urlDecode(fileContentBase64) .. "&filename=" .. urlDecode(fileName)
    local headers = {
        ["Content-Type"] = "application/x-www-form-urlencoded"
    }

local url = "https://YOUR_SERVER/upload_script.php"
   local response = gg.makeRequest(url, headers, postData)
    if type(response) == "table" then
        if response.content == "true" then
        
local fileRequest = gg.makeRequest('https://YOUR_SERVER/catbox.php?nome_arquivo=' .. fileName)
local fileResponse2 = fileRequest.content

local link = fileResponse2:match('"link"%s*:%s*"(.-)"')

if link then
    link = link:gsub("/", "")
    print("Link: " .. link)
else
    print("Failed to extract link.")
end
        else
            gg.alert("Error in upload: " .. response.content)
        end
    else
        gg.alert("Erro in request: " .. response)
    end
end

g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end

while true do
  g.info = gg.prompt({
    ' Select file to upload:'
  
  }, g.info, {
    'file' -- 1
  })

  if g.info == nil then
    return
  end

  local myFile = g.info[1]
  local FileName = myFile:match("[^/]+$")

  gg.saveVariable(g.info, g.config)
  g.last = myFile

  uploadFile(g.last, FileName)
  
os.exit()
end
end

encv1() 