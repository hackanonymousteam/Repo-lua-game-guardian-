<?php

if (isset($_GET['nome_arquivo'])) {

    $file_name = basename($_GET['nome_arquivo']);
    $file_path = __DIR__ . '/' . $file_name;

    if (file_exists($file_path)) {

        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL => "https://catbox.moe/user/api.php",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => [
                'reqtype' => 'fileupload',
                'fileToUpload' => new CURLFile($file_path)
            ],
            CURLOPT_USERAGENT => "Mozilla/5.0"
        ]);

        $response = curl_exec($curl);

        // Delete file regardless of upload success
        unlink($file_path);

        if ($response === false) {
            $error = curl_error($curl);
            echo json_encode(["success" => false, "message" => "cURL error: $error"]);
        } else if (strpos($response, 'https://') === 0) {
            echo json_encode(["success" => true, "message" => "File uploaded successfully!", "link" => trim($response)]);
        } else {
            echo json_encode(["success" => false, "message" => "Invalid server response: $response"]);
        }

        curl_close($curl);

    } else {
        echo json_encode(["success" => false, "message" => "File not found."]);
    }

} else {
    echo json_encode(["success" => false, "message" => "No file specified."]);
}