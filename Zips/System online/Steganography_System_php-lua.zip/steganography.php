<?php

header('Content-Type: application/json');

define('MAX_UPLOAD', 10 * 1024 * 1024); // 10MB

// ========================
// UTIL
// ========================

function respond($array) {
    echo json_encode($array);
    exit;
}

function validatePng($path) {
    if (!file_exists($path)) return false;
    $info = getimagesize($path);
    return $info && $info[2] === IMAGETYPE_PNG;
}

function cleanTemp($path) {
    if (file_exists($path)) unlink($path);
}

// ========================
// ENCODE
// ========================

function encodeFileInImage($imagePath, $fileContent, $fileName, $outputPath) {

    if (!validatePng($imagePath)) {
        return ['error' => 'Invalid PNG image'];
    }

    $img = imagecreatefrompng($imagePath);
    imagepalettetotruecolor($img);

    $width  = imagesx($img);
    $height = imagesy($img);

    $header = json_encode([
        'name' => $fileName,
        'size' => strlen($fileContent)
    ]) . "|";

    $data = $header . $fileContent;

    $totalBits = strlen($data) * 8;
    $capacity  = $width * $height * 3;

    if ($totalBits > $capacity) {
        imagedestroy($img);
        return [
            'error' => 'File too large for this image',
            'capacity_bytes' => floor($capacity / 8),
            'needed_bytes'   => strlen($data)
        ];
    }

    $bitPointer = 0;

    for ($y = 0; $y < $height; $y++) {
        for ($x = 0; $x < $width; $x++) {

            $rgb = imagecolorat($img, $x, $y);

            $r = ($rgb >> 16) & 0xFF;
            $g = ($rgb >> 8) & 0xFF;
            $b = $rgb & 0xFF;

            foreach (['r','g','b'] as $channel) {

                if ($bitPointer >= $totalBits) break 3;

                $byteIndex = intdiv($bitPointer, 8);
                $bitIndex  = 7 - ($bitPointer % 8);
                $bit = (ord($data[$byteIndex]) >> $bitIndex) & 1;

                if ($channel === 'r') $r = ($r & 0xFE) | $bit;
                if ($channel === 'g') $g = ($g & 0xFE) | $bit;
                if ($channel === 'b') $b = ($b & 0xFE) | $bit;

                $bitPointer++;
            }

            $newColor = ($r << 16) | ($g << 8) | $b;
            imagesetpixel($img, $x, $y, $newColor);
        }
    }

    imagepng($img, $outputPath);
    imagedestroy($img);

    return ['success' => true];
}

// ========================
// DECODE
// ========================

function decodeFileFromImage($imagePath) {

    if (!validatePng($imagePath)) {
        return false;
    }

    $img = imagecreatefrompng($imagePath);

    $width  = imagesx($img);
    $height = imagesy($img);

    $bits = "";
    $data = "";

   
    for ($y = 0; $y < $height; $y++) {
        for ($x = 0; $x < $width; $x++) {

            $rgb = imagecolorat($img, $x, $y);

            $bits .= (($rgb >> 16) & 1);
            $bits .= (($rgb >> 8) & 1);
            $bits .= ($rgb & 1);
        }
    }

    imagedestroy($img);

   
    for ($i = 0; $i < strlen($bits); $i += 8) {
        $byte = substr($bits, $i, 8);
        if (strlen($byte) < 8) break;
        $data .= chr(bindec($byte));
    }

    
    $pos = strpos($data, '|');
    if ($pos === false) return false;

    $metaJson = substr($data, 0, $pos);
    $meta = json_decode($metaJson, true);

    if (!$meta || !isset($meta['size'])) return false;

    $content = substr($data, $pos + 1, $meta['size']);

    return [
        'name' => $meta['name'],
        'content' => $content,
        'size' => $meta['size']
    ];
}

// ========================
// ROUTER
// ========================

if (!isset($_POST['action'])) {
    respond(['success' => false, 'message' => 'No action specified']);
}

$action = $_POST['action'];

// ------------------------
// ENCODE
// ------------------------

if ($action === 'encode') {

    if (!isset($_FILES['image']) || !isset($_FILES['file'])) {
        respond(['success' => false, 'message' => 'Missing files']);
    }

    if ($_FILES['file']['size'] > MAX_UPLOAD) {
        respond(['success' => false, 'message' => 'File exceeds max upload limit']);
    }

    $imageTmp = $_FILES['image']['tmp_name'];
    $fileTmp  = $_FILES['file']['tmp_name'];
    $fileName = $_FILES['file']['name'];

    $fileContent = file_get_contents($fileTmp);

    $outputPath = sys_get_temp_dir() . "/encoded_" . time() . ".png";

    $result = encodeFileInImage($imageTmp, $fileContent, $fileName, $outputPath);

    if (isset($result['error'])) {
        respond(['success' => false, 'message' => $result['error']] + $result);
    }

    $encodedImage = file_get_contents($outputPath);
    cleanTemp($outputPath);

    respond([
        'success' => true,
        'image_data' => base64_encode($encodedImage)
    ]);
}

// ------------------------
// DECODE
// ------------------------

if ($action === 'decode') {

    if (!isset($_FILES['image'])) {
        respond(['success' => false, 'message' => 'Missing image']);
    }

    $imageTmp = $_FILES['image']['tmp_name'];

    $decoded = decodeFileFromImage($imageTmp);

    if (!$decoded) {
        respond(['success' => false, 'message' => 'Failed to decode image']);
    }

    respond([
        'success'   => true,
        'file_name' => $decoded['name'],
        'file_size' => $decoded['size'],
        'file_data' => base64_encode($decoded['content'])
    ]);
}

respond(['success' => false, 'message' => 'Invalid action']);