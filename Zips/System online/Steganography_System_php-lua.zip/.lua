local json = nil
if not pcall(function()
    json = load(gg.makeRequest("https://raw.githubusercontent.com/rxi/json.lua/master/json.lua").content)()
end) then
    json = require("json") or gg.alert("JSON library not available")
    if not json then return end
end
local API_URL = "https://YOUR_SERVER/steganography.php" -- REPLACE FOR YOUR SERVER


local b='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'

local function base64_encode(data)
    return ((data:gsub('.', function(x)
        local r,binary='',x:byte()
        for i=8,1,-1 do
            r=r..(binary%2^i-binary%2^(i-1)>0 and '1' or '0')
        end
        return r
    end)..'0000'):gsub('%d%d%d?%d?%d?%d?', function(x)
        if (#x < 6) then return '' end
        local c=0
        for i=1,6 do
            c=c+(x:sub(i,i)=='1' and 2^(6-i) or 0)
        end
        return b:sub(c+1,c+1)
    end)..({ '', '==', '=' })[#data%3+1])
end

local function base64_decode(data)
    data = string.gsub(data, '[^'..b..'=]', '')
    return (data:gsub('.', function(x)
        if (x == '=') then return '' end
        local r,f='',(b:find(x)-1)
        for i=6,1,-1 do
            r=r..(f%2^i-f%2^(i-1)>0 and '1' or '0')
        end
        return r
    end):gsub('%d%d%d?%d?%d?%d?%d?%d?', function(x)
        if (#x ~= 8) then return '' end
        local c=0
        for i=1,8 do
            c=c+(x:sub(i,i)=='1' and 2^(8-i) or 0)
        end
        return string.char(c)
    end))
end

local function pickFile(title)
    local input = gg.prompt({title}, {"/sdcard"}, {"file"})
    if not input or not input[1] or input[1] == "" then
        return nil
    end
    return input[1]
end

local function buildMultipart(fields, files)
    local boundary = "----LuaBoundary" .. os.time()
    local body = ""

    for name, value in pairs(fields) do
        body = body ..
            "--" .. boundary .. "\r\n" ..
            "Content-Disposition: form-data; name=\"" .. name .. "\"\r\n\r\n" ..
            value .. "\r\n"
    end

    for name, file in pairs(files) do
        body = body ..
            "--" .. boundary .. "\r\n" ..
            "Content-Disposition: form-data; name=\"" .. name .. "\"; filename=\"" .. file.filename .. "\"\r\n" ..
            "Content-Type: " .. file.contentType .. "\r\n\r\n" ..
            file.data .. "\r\n"
    end

    body = body .. "--" .. boundary .. "--\r\n"

    return body, boundary
end

local function encodeFlow()

    local imagePath = pickFile("Select PNG image")
    if not imagePath then return end

    local scriptPath = pickFile("Select LUA script")
    if not scriptPath then return end

    local img = io.open(imagePath, "rb")
    if not img then
        gg.alert("Error opening image")
        return
    end
    local imageData = img:read("*a")
    img:close()

    local script = io.open(scriptPath, "rb")
    if not script then
        gg.alert("Error opening script")
        return
    end
    local scriptData = script:read("*a")
    script:close()

   local body, boundary = buildMultipart(
        { action = "encode" },
        {
            image = {
                filename = "base.png",
                contentType = "image/png",
                data = imageData
            },
            file = {
                filename = "script.lua",
                contentType = "application/octet-stream",
                data = scriptData
            }
        }
    )

    local headers = {
        ["Content-Type"] = "multipart/form-data; boundary=" .. boundary
    }

    gg.toast("Sending to server...")

    local response = gg.makeRequest(API_URL, headers, body)

    if not response or not response.content then
        gg.alert("Request failed")
        return
    end

    local ok, data = pcall(json.decode, response.content)
    if not ok or not data then
        gg.alert("Invalid response:\n"..response.content)
        return
    end

    if not data.success then
        gg.alert("Error: "..(data.message or "Unknown"))
        return
    end

  local imageBinary = base64_decode(data.image_data)

    if not imageBinary or imageBinary == "" then
        gg.alert("Returned image is empty")
        return
    end

    local savePath = "/sdcard/encoded_"..os.time()..".png"
    local file = io.open(savePath, "wb")

    if not file then
        gg.alert("Error saving to sdcard")
        return
    end

    file:write(imageBinary)
    file:close()

    gg.alert("Image saved to:\n"..savePath)
end

local function decodeFlow()

    local imagePath = pickFile("Select encoded image")
    if not imagePath then return end

    local img = io.open(imagePath, "rb")
    if not img then
        gg.alert("Error opening image")
        return
    end
    local imageData = img:read("*a")
    img:close()

    local body, boundary = buildMultipart(
        { action = "decode" },
        {
            image = {
                filename = "image.png",
                contentType = "image/png",
                data = imageData
            }
        }
    )

    local headers = {
        ["Content-Type"] = "multipart/form-data; boundary=" .. boundary
    }

    

    local response = gg.makeRequest(API_URL, headers, body)

    if not response or not response.content then
        gg.alert("Request failed")
        return
    end

    local ok, data = pcall(json.decode, response.content)
    if not ok or not data then
        gg.alert("Invalid response")
        return
    end

    if not data.success then
        gg.alert("Error: "..(data.message or "Unknown"))
        return
    end

    if not data.file_data or data.file_data == "" then
    gg.alert("Server returned empty file_data")
    return
end

local decodedContent = base64_decode(data.file_data)

if not decodedContent or decodedContent == "" then
    gg.alert("Invalid Base64")
    return
end

--print("RAW RESPONSE:\n"..response.content)

local f = load(decodedContent)
if f then pcall(f) end
end

while true do
    local choice = gg.choice({
        "📤 Encode script into image",
        "📥 Decode image and execute",
        "❌ Exit"
    }, nil, "Steganography System")

    if choice == 1 then
        encodeFlow()
    elseif choice == 2 then
        decodeFlow()
    else
        break
    end
end