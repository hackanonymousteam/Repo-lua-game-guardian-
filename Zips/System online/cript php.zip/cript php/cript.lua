g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end

 gg.alert([[
encrypt simple  hash online using lua and php

by Batman Games🍿 

My telegram @batmangamesS 
]])

while true do
  g.info = gg.prompt({
    '📂 Select file :', -- 1
    '📂 Select folder  :' -- 2
  }, g.info, {
    'file', -- 1
    'path' -- 2
  })

  gg.saveVariable(g.info, g.config)
  g.last = g.info[1]
  if loadfile(g.last) == nil then
    gg.alert("⚠️ Script not Found! ⚠️")
    return
  else
    g.out = g.last:match("[^/]+$")
    g.out = g.out:gsub(".lua", ".Batman")
    g.out = g.info[2] .. "/" .. g.out .. ".lua"
  end

  local file = io.open(g.last, "r")
  local DATA = file:read('*a')
  file:close()
  
function getKey()
    local chave_oculta
    repeat
        chave_oculta = math.random(1, 255)
    until chave_oculta >= 1 and chave_oculta <= 255
    return chave_oculta
end

function enc(str)
    local chave_oculta = getKey()
    local hash = ''
    local tamanho_str = #str

    for i = 1, tamanho_str do
        local byte = str:byte(i) or 0
        local valor = byte + chave_oculta
        valor = valor % 256
        hash = hash .. string.format('%02x', valor)
    end
    return string.format("%03d%s", chave_oculta, hash)
end
  DATA = enc(DATA)
 
  local descript_code = [[
  
  local encrypted_code = "]] .. DATA .. [["
    
local function decode_html_entities(str)
    local entities = {
        ["&quot;"] = '"',
        ["&apos;"] = "'",
        ["&lt;"] = "<",
        ["&gt;"] = ">",
        ["&amp;"] = "&"
    }
    return (str:gsub("(&%w+;)", entities))
end

local decrypted_code = encrypted_code

--replace to cript.php in your server

local url = 'http://YOUR_SERVER/cript.php?hash='..decrypted_code

local request = gg.makeRequest(url)
if request == nil or request.content == nil then
    gg.alert('Error.')
    return
end

local graf = decode_html_entities(request.content)

pcall(load(graf))

]]

  DATA = descript_code

io.open(g.out,"w"):write(DATA):close()

--io.open(g.out,"w"):write(string.gsub(string.dump(load(DATA), true), 'LuaR', 'LuaR', 1)):close()
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
ClU = '📂 File Saved To: '..g.out..'\n'
gg.alert(ClU, '')
print("\n▬▬▬▬▬▬▬▬▬▬▬▬▬\n📂 File Saved To :" .. g.out .. "\n▬▬▬▬▬▬▬▬▬▬▬▬▬")
return 
end