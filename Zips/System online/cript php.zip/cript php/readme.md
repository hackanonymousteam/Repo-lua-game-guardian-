Upload the crypt.php file on your server and use the lua script to make the request.

 This lua script and php can be changed according to your need.

 Can also be used other cryptographic standard and 
 protections .

this is just an example.