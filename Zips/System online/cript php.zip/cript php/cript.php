<?php
function dec($hash_com_chave) {

    $chave_oculta = intval(substr($hash_com_chave, 0, 3));

    $hash = substr($hash_com_chave, 3);
    $str = '';

    $tamanho_hash = strlen($hash);


    for ($i = 0; $i < $tamanho_hash; $i += 2) {
        
        $hash_byte = hexdec(substr($hash, $i, 2));

        $byte_original = ($hash_byte - $chave_oculta) % 256;

        $str .= chr($byte_original);
    }

    return $str;
}


if (isset($_GET['hash'])) {
    $hash_com_chave = $_GET['hash'];
    $texto_original = dec($hash_com_chave);
    echo " " . htmlspecialchars($texto_original, ENT_QUOTES, 'UTF-8');
} else {
    echo "hash no found";
}
?>