<?php
// SMTP Settings - Replace the placeholders with your actual email settings
ini_set('SMTP', 'smtp.yourdomain.com'); // SMTP server address (e.g., 'mail.yourdomain.com')
ini_set('smtp_port', 587); // SMTP server port (usually 587 for TLS, 465 for SSL)
ini_set('sendmail_from', 'youremail@yourdomain.com'); // The email address to be used as the "from" address

if (isset($_GET['email'])) {

    $to = $_GET['email']; 
} else {
    
    die("Please enter an email address.");
}

$subject = 'Email test';
$message = "
<html>
<head>
  <title> E-mail test</title>
</head>
<body>
  <h1>hi !</h1>
  <p>this email is test <b>HTML</b>.</p>
  <p>thanks for use this service</p>
</body>
</html>
";

$headers = "From: noreply@YOUR_SERVER.com\r\n";
$headers .= "Reply-To: noreply@YOUR_SERVER.com\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";

if (filter_var($to, FILTER_VALIDATE_EMAIL)) {
    if (mail($to, $subject, $message, $headers)) {
        echo "sucess sended $to!";
    } else {
        echo "error.";
    }
} else {
    echo "invalid e-mail.";
}
?>