local chat = gg.prompt({'Enter email'}, {}, {'text'})
if chat == nil then
    return
end

local duck = chat[1]
local request = gg.makeRequest('https://YOUR_SERVER_HERE/email.php?email='..duck)

if request == nil or request.content == nil then
    print('error get reply .')
    return
end

local response = request.content

    print(response)
