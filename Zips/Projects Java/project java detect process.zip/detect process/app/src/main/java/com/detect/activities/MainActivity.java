package com.detect.activities;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.detect.R;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private StringBuilder dbgLog;
    private TextView processListTextView;
    private StringBuilder vSpaceLog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Caminho do diretório do aplicativo
        String caminhoApp = "/data/data/com.chaozhuo.gameassistant/virtual/data/user/0/com.detect";
        dbgLog = new StringBuilder();

        // Nome a ser pesquisado nas libs
        String nameToSearch = "libm.so"; // Altere para o nome desejado

        checkMaps(dbgLog, nameToSearch);

        // Exibe o log gerado pelo checkMaps
        showAlert(dbgLog.toString());

        // Verifica o espaço virtual
        setVSpace(this, caminhoApp);

        processListTextView = findViewById(R.id.processListTextView);

        // Lista processos em execução
        listRunningProcesses();
    }

    // Método para verificar espaço virtual
    private void setVSpace(Context context, String files) {
        String vpkg = null;
        boolean mntExpand = false;
        String vSpaceName = "Octopus NBM";  
        boolean vSpace = false;  
        String vSpacePkg = null; 
        boolean vSpaceGuest = false;

        // Ajusta o caminho caso esteja em "/mnt/expand/"
        if (files.startsWith("/mnt/expand/")) {
            files = files.replace("/mnt/expand/" + files.split("/", -1)[3], "/data");
            mntExpand = true;
        }

        // Identifica o pacote a partir do caminho
        if (files.startsWith("/data/data/")) {
            vpkg = files.split("/", -1)[3];
        } else if (files.startsWith("/data/user/")) {
            vpkg = files.split("/", -1)[4];
        }

        if (vpkg != null) {
            String mainPackage = "com.detect"; 
            vSpace = !vpkg.startsWith(mainPackage);
            vSpacePkg = vpkg;
            vSpaceGuest = vpkg.contains("vmos");
        }

        String resultado = "vSpace: " + vSpace + "\n" +
            "vSpacePkg: " + vSpacePkg + "\n" +
            "vSpaceGuest: " + vSpaceGuest + "\n" +
            "vSpaceName: " + vSpaceName;

        new AlertDialog.Builder(context)
            .setTitle("Resultado de vSpace")
            .setMessage(resultado)
            .setPositiveButton("OK", null)
            .show();
    }

    // Método para verificar mapeamentos de memória
    private void checkMaps(StringBuilder dbg, String name) {
        BufferedReader br = null;
        try {
            try {
				br = new BufferedReader(new FileReader("/proc/self/maps"));
			} catch (FileNotFoundException e) {}
            String line;
            try {
				while ((line = br.readLine()) != null) {
					int pos = line.indexOf(name);
					if (pos >= 0) {
						int start = pos;
						while (start > 0 && line.charAt(start) > ' ') {
							start--;
						}
						if (start < pos) {
							dbg.append("\n").append(line.substring(start).trim());
						}
					}
				}
			} catch (IOException e) {}
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // Método para exibir um alerta
    private void showAlert(String message) {
        new AlertDialog.Builder(this)
            .setTitle("Resultado da Pesquisa")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show();
    }

    // Método para listar os processos em execução
    private void listRunningProcesses() {
        ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (activityManager != null) {
            List<ActivityManager.RunningAppProcessInfo> runningProcesses = activityManager.getRunningAppProcesses();
            String[] processNames = new String[runningProcesses.size()];

            for (int i = 0; i < runningProcesses.size(); i++) {
                ActivityManager.RunningAppProcessInfo process = runningProcesses.get(i);
                processNames[i] = process.processName; 
            }

            new AlertDialog.Builder(this)
                .setTitle("Processos em Execução")
                .setAdapter(new ProcessAdapter(this, processNames), null)
                .setPositiveButton("OK", null)
                .show();
        }
    }

    // Adapter para mostrar os processos e permitir clique
    private class ProcessAdapter extends ArrayAdapter<String> {
        private final Context context;
        private final String[] processNames;

        public ProcessAdapter(Context context, String[] processNames) {
            super(context, R.layout.process_item, processNames);
            this.context = context;
            this.processNames = processNames;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.process_item, parent, false);
            }

            TextView processNameTextView = convertView.findViewById(R.id.process_name);
            ImageView processIconImageView = convertView.findViewById(R.id.process_icon);

        final    String processName = processNames[position];
            processNameTextView.setText(processName);

            // Obtém o ícone do aplicativo
            ApplicationInfo appInfo;
            try {
                appInfo = context.getPackageManager().getApplicationInfo(processName, 0);
                Drawable icon = context.getPackageManager().getApplicationIcon(appInfo);
                processIconImageView.setImageDrawable(icon);
            } catch (PackageManager.NameNotFoundException e) {
                processIconImageView.setImageDrawable(null);
            }

            // Define o listener sem lambda
            convertView.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						listLibrariesOfProcess(processName);
					}
				});

            return convertView;
        }
    }

    // Método para listar as bibliotecas de um processo
    // Método para listar as bibliotecas de um processo
	// Método para listar as bibliotecas de um processo
	private void listLibrariesOfProcess(String processName) {
		List<String> libraries = new ArrayList<>();
		String pid = getProcessId(processName); // Obtém o PID do processo selecionado
		if (pid != null) {
			BufferedReader br = null;
			try {
				br = new BufferedReader(new FileReader("/proc/" + pid + "/maps")); // Abre o arquivo maps do processo específico
				String line;
				while ((line = br.readLine()) != null) {
					// Filtra as linhas para incluir apenas as bibliotecas (normalmente localizadas em /lib ou /vendor/lib)
					if (line.contains(".so")) { // Ajuste aqui para filtrar apenas bibliotecas
						libraries.add(line.trim());
					}
				}
			} catch (IOException e) {
				libraries.add("Erro ao ler as bibliotecas para o processo: " + processName);
			} finally {
				if (br != null) {
					try {
						br.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		} else {
			libraries.add("Processo não encontrado: " + processName);
		}

		// Exibe as bibliotecas filtradas em um AlertDialog
		new AlertDialog.Builder(this)
			.setTitle("Bibliotecas de " + processName)
			.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, libraries), null)
			.setPositiveButton("OK", null)
			.show();
	}
    // Método para obter o PID de um processo
    private String getProcessId(String processName) {
        ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (activityManager != null) {
            List<ActivityManager.RunningAppProcessInfo> runningProcesses = activityManager.getRunningAppProcesses();
            for (ActivityManager.RunningAppProcessInfo process : runningProcesses) {
                if (process.processName.equals(processName)) {
                    return String.valueOf(process.pid);
                }
            }
        }
        return null; // Retorna null se o processo não for encontrado
    }
}
