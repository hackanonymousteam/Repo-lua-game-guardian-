package com.detect.activities;
import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.io.BufferedReader;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;

public class tools {
    }
