#include <pthread.h>
#include <jni.h>
#include <src/Includes/Utils.h>
#if defined(__aarch64__) //Compile for arm64 lib only
#include <src/And64InlineHook/And64InlineHook.hpp>
#else //Compile for armv7 lib only. Do not worry about greyed out highlighting code, it still works
#include <src/Substrate/SubstrateHook.h>
#endif
#include "KittyMemory/MemoryPatch.h"
#include "Includes/Logger.h"

extern "C" {

JNIEXPORT jstring JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_Title(
        JNIEnv *env,
        jobject activityObject) {
    return env->NewStringUTF("By Batman Games");
}
JNIEXPORT jstring JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_Heading(
        JNIEnv *env,
        jobject activityObject) {
    
    return env->NewStringUTF("Mod Menu");
}
JNIEXPORT jstring JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_Icon(
        JNIEnv *env,
        jobject activityObject) {
    //link image
	
    return env->NewStringUTF("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQe3HfLjUB0oEotGNRYmy9iL39qYKVBjQuGZIMfWMe8_g&s");
}
JNIEXPORT jint JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_IconSize(
        JNIEnv *env,
        jobject activityObject) {
    return 70;
}

JNIEXPORT jobjectArray  JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_getFeatureList(
        JNIEnv *env,
        jobject activityObject) {
    jobjectArray ret;

    const char *features[] = {
		  "TextClock_",
		  "SeekBar_Fly hack_0_10",
	      "RadioButton_Aimbot",
		  "RadioButton_Magic Bullet",
		  "RadioButton_god mode",
		  "Checkbox_unlimited money",
		  "Checkbox_ghost hack",
		  "Checkbox_speed hack",

		 };
	
    int Total_Feature = (sizeof features /
                         sizeof features[0]); //Now you dont have to manually update the number everytime;

    ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"),
                                             env->NewStringUTF(""));
    int i;
    for (i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
    return (ret);
}

struct My_Patches {
  MemoryPatch fly;
MemoryPatch fly1;
MemoryPatch fly2;
MemoryPatch fly3;
MemoryPatch fly4;
MemoryPatch fly5;
MemoryPatch fly6;
MemoryPatch fly7;
MemoryPatch fly8;
MemoryPatch fly9;
MemoryPatch fly10;
	MemoryPatch Aimbot;
	MemoryPatch Magic;
	MemoryPatch GodMode;
	MemoryPatch Money;
	MemoryPatch Ghost;
	MemoryPatch Speed;
} Patches;

bool fly;
bool fly1;
bool fly2;
bool fly3;
bool fly4;
bool fly5;
bool fly6;
bool fly7;
bool fly8;
bool fly9;
bool fly10;
bool Aimbot;
bool Magic;
bool GodMode;
bool Money;
bool Ghost;
bool Speed;

const char *libName = "libunity.so";

JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_Changes(
        JNIEnv *env,
        jobject activityObject,
        jint feature,
        jint value) {

    __android_log_print(ANDROID_LOG_VERBOSE, "Mod Menu", "Feature: = %d", feature);
    __android_log_print(ANDROID_LOG_VERBOSE, "Mod Menu", "Value: = %d", value);

    switch (feature) {
        
		 case 0:
			 
    fly = !fly; 
    if (fly > 0) {
        Patches.fly.Modify(); // Modifica a antena se o valor for exatamente 1
       } else if (fly > 1) {
        Patches.fly1.Modify(); 
   
		} else if (fly > 2) {
		Patches.fly2.Modify(); 
   
		} else if (fly > 3) {
		Patches.fly3.Modify(); 
   
		} else if (fly > 4) {
		Patches.fly4.Modify(); 
   
		} else if (fly > 5) {
			Patches.fly5.Modify(); 
   
		} else if (fly > 6) {
		Patches.fly6.Modify(); 
   
		} else if (fly > 7) {
			
			Patches.fly7.Modify(); 
   
		} else if (fly > 8) {
		Patches.fly8.Modify(); 
   
		} else if (fly > 9) {
			
			Patches.fly9.Modify(); 
   
		} else if (fly > 10) {
		Patches.fly10.Modify(); 
  
		}

    break;
	
		 case 1:
            Aimbot= !Aimbot;
            if (Aimbot) {
                Patches.Aimbot.Modify();
            } else {
                Patches.Aimbot.Restore();
            }
            break;
		
	    case 2:
            Magic= !Magic;
            if (Magic) {
                Patches.Magic.Modify();
            } else {
                Patches.Magic.Restore();
            }
            break;
			
		case 3:
            GodMode= !GodMode;
            if (GodMode) {
                Patches.GodMode.Modify();
            } else {
                Patches.GodMode.Restore();
            }
            break;
			
		case 4:
            Money= !Money;
            if (Money) {
                Patches.Money.Modify();
            } else {
                Patches.Money.Restore();
            }
            break;
		
	    case 5:
            Ghost= !Ghost;
            if (Ghost) {
                Patches.Ghost.Modify();
            } else {
                Patches.Ghost.Restore();
            }
            break;
			
			case 6:
			
            Speed= !Speed;
            if (Ghost) {
                Patches.Speed.Modify();
            } else {
                Patches.Speed.Restore();
            }
            break;
	}
   
}

}	


		void *hack_thread(void *) {
    LOGI("Loading...");

    ProcMap il2cppMap;
    do {
        il2cppMap = KittyMemory::getLibraryMap("libunity.so");
        sleep(1);
    } while (!il2cppMap.isValid());

	Patches.fly = MemoryPatch("libunity.so", 0x1E52A4, "\x00\x00\xa0\x40", 4);
	
	Patches.fly1 = MemoryPatch("libunity.so", 0x1E52A4, "\x00\x00\xa0\x40", 4);
	
	Patches.fly2 = MemoryPatch("libunity.so", 0x1E52A4, "\x00\x00\xa0\x40", 4);
	
	Patches.fly3 = MemoryPatch("libunity.so", 0xee5f90, "\xcd\xcc\xcc\x3e", 4);
	Patches.fly4 = MemoryPatch("libunity.so", 0xee5f90, "\x9a\x99\x19\x3f", 4);
	Patches.fly5 = MemoryPatch("libunity.so", 0xee5f90, "\xcd\xcc\x4c\x3f", 4);
	Patches.fly6 = MemoryPatch("libunity.so", 0xee5f90, "\x00\x00\x80\x3f", 4);
	Patches.fly7 = MemoryPatch("libunity.so", 0xee5f90, "\x00\x00\x00\x40", 4);
	Patches.fly8 = MemoryPatch("libunity.so", 0xee5f90, "\x00\x00\x40\x40", 4);
	Patches.fly9 = MemoryPatch("libunity.so", 0xee5f90, "\x00\x00\x80\x40", 4);
	Patches.fly10 = MemoryPatch("libunity.so", 0xee5f90, "\x00\x00\xa0\x40", 4);
	
	
	Patches.Aimbot = MemoryPatch("libunity.so", 0x1E52A4, "\x00\x00\xa0\x40", 4);
	

	Patches.Magic = MemoryPatch("libunity.so", 0x1E52A4, "\x00\x00\x96\x43", 4);
	
	Patches.GodMode = MemoryPatch("libunity.so", 0x1E52A4, "\x00\x00\x96\x43", 4);
	
	Patches.Money = MemoryPatch("libunity.so", 0x1E52A4, "\x00\x00\x96\x43", 4);
	

	Patches.Ghost = MemoryPatch("libunity.so", 0x1E52A4, "\x00\x00\xa0\x40", 4);
	

	Patches.Speed = MemoryPatch("libunity.so", 0x1E52A4, "\x00\x00\x00\x00", 4);
	
	}
	
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);

    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);

    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM *vm, void *reserved) {}
