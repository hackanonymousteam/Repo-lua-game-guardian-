package uk.lgl.modmenu;

import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.text.Html;
import android.text.InputFilter;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Objects;

import static uk.lgl.modmenu.StaticActivity.cacheDir;



public class FloatingModMenuService extends Service {
    private MediaPlayer FXPlayer;
    public View mFloatingView;
    private Button close;
	private Button Kll;
    private Button ffid;
    private LinearLayout mButtonPanel;
    public RelativeLayout mCollapsed;
    public LinearLayout mExpanded;
    private RelativeLayout mRootContainer;
    public WindowManager mWindowManager;
    public WindowManager.LayoutParams params;
    private LinearLayout patches;
    private FrameLayout rootFrame;
    private ImageView startimage;
    private LinearLayout view1;
    private LinearLayout view2;

    private AlertDialog alert;
    private EditText edittextvalue;
	
    private static final String TAG = "Mod Menu";

    private LinearLayout.LayoutParams hr;

	private View close2;

    //initialize methods from the native library
    public static native String Toast();

    private native String Title();

    private native String Heading();

    private native String Icon();

    private native int IconSize();

    public native void Changes(int feature, int value);

    private native String[] getFeatureList();

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    //Override our Start Command so the Service doesnt try to recreate itself when the App is closed
    public int onStartCommand(Intent intent, int i, int i2) {
        return Service.START_NOT_STICKY;
    }

    //When this Class is called the code in this function will be executed
    @Override
    public void onCreate() {
        super.onCreate();
        //A little message for the user when he opens the app
        //Toast.makeText(this, Toast(), Toast.LENGTH_LONG).show();
        //Init Lib

        // When you change the lib name, change also on Android.mk file
        // Both must have same name
        System.loadLibrary("MyLibName");

        initFloating();
        initAlertDiag();
        final Handler handler = new Handler();
        handler.post(new Runnable() {
                public void run() {
                  //  Thread();
                    handler.postDelayed(this, 1000);
                }
            });
    }

    //Here we write the code for our Menu
    private void initFloating() {
        this.rootFrame = new FrameLayout(this);
        this.mRootContainer = new RelativeLayout(this);
        this.mCollapsed = new RelativeLayout(this);
        this.mExpanded = new LinearLayout(this);
        this.view1 = new LinearLayout(this);
        this.patches = new LinearLayout(this);
        this.view2 = new LinearLayout(this);
        this.mButtonPanel = new LinearLayout(this);



        RelativeLayout relativeLayout = new RelativeLayout(this);
        relativeLayout.setLayoutParams(new RelativeLayout.LayoutParams(-20, -1));
        relativeLayout.setPadding(10, 10, 10, 10);
        relativeLayout.setVerticalGravity(16);


        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(300, -20);
        layoutParams.addRule(11);

		close = new Button(this);
        close.setText("Hide");
        close.setTextColor(Color.parseColor("#FF000000"));
        close.setLayoutParams(layoutParams);
		android.graphics.drawable.GradientDrawable GIGABGI = new android.graphics.drawable.GradientDrawable();
		GIGABGI.setColor(Color.parseColor("#ffffff"));;
		GIGABGI.setStroke(3, Color.parseColor("#000000"));
		close.setBackground(GIGABGI);
		
		relativeLayout.addView(this.close);
        

		
		
		
		
		
		
 
        rootFrame.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
		mRootContainer.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
		mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
		mCollapsed.setVisibility(View.VISIBLE);

		startimage = new ImageView(getBaseContext());
		startimage.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
		int applyDimension = (int) TypedValue.applyDimension(1, (float) IconSize(), getResources().getDisplayMetrics());
		startimage.getLayoutParams().height = applyDimension;
		startimage.getLayoutParams().width = applyDimension;
		startimage.requestLayout();
		startimage.setScaleType(ImageView.ScaleType.FIT_XY);
		((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(10);

// URL da imagem
		//String imageUrl = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQe3HfLjUB0oEotGNRYmy9iL39qYKVBjQuGZIMfWMe8_g&s";// Criação da AsyncTask para fazer a requisição da imagem
		new AsyncTask<String, Void, Bitmap>() {
			@Override
			protected Bitmap doInBackground(String... params) {
				try {
					// Fazendo a requisição da imagem e retornando o Bitmap
					URL url = new URL(params[0]);
					HttpURLConnection connection = (HttpURLConnection) url.openConnection();
					connection.setDoInput(true);
					connection.connect();
					InputStream inputStream = connection.getInputStream();
					return BitmapFactory.decodeStream(inputStream);
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			}

			@Override
			protected void onPostExecute(Bitmap result) {
				if (result != null) {
					// Definindo a imagem no ImageView
					startimage.setImageBitmap(result);
					startimage.setImageAlpha(200);
				}
			}
		}.execute(Icon());
        
        this.mExpanded.setVisibility(8);
        this.mExpanded.setBackgroundColor(Color.parseColor("#00B0FF"));
        this.mExpanded.setGravity(17);
        this.mExpanded.setOrientation(1);
        this.mExpanded.setPadding(5, 0, 5, 0);
        this.mExpanded.setLayoutParams(new LinearLayout.LayoutParams(dp(260), -2));
        this.mExpanded.getBackground().setAlpha(250);
        android.graphics.drawable.GradientDrawable DFIABBI = new android.graphics.drawable.GradientDrawable();
        DFIABBI.setColor(Color.parseColor("#00000000"));
        DFIABBI.setCornerRadius(10);
        DFIABBI.setStroke(5, Color.parseColor("#FF00B0FF"));
        this.mExpanded.setBackgroundColor(Color.parseColor("#ff000000"));

        ScrollView scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(190)));
        scrollView.setBackgroundColor(Color.parseColor("WHITE"));
        scrollView.getBackground().setAlpha(250);


        this.patches.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        this.patches.setOrientation(1);


        this.hr = new LinearLayout.LayoutParams(-1, -1);
        this.hr.setMargins(0, 0, 0, 5);


        this.mButtonPanel.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));


        TextView textView = new TextView(this);
        textView.setTextSize(50);
        textView.setText(Title());
        textView.setTextColor(Color.WHITE);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setTextSize(20.0f);
        textView.setPadding(10, 25, 10, 5);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 17;
        textView.setLayoutParams(layoutParams2);


        TextView textView2 = new TextView(this);
        textView2.setTextSize(50);
        textView2.setText(Heading());
        textView2.setTextColor(Color.WHITE);
        textView2.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);
        textView2.setTextSize(10.0f);
        textView2.setPadding(10, 5, 10, 10);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams3.gravity = 17;
        textView2.setLayoutParams(layoutParams3);


		
        new LinearLayout.LayoutParams(-1, dp(25)).topMargin = dp(2);
        rootFrame.addView(mRootContainer);
        mRootContainer.addView(mCollapsed);
        mRootContainer.addView(mExpanded);


        mCollapsed.addView(startimage);
        mExpanded.addView(textView);
        mExpanded.addView(textView2);
        mExpanded.addView(view1);
        mExpanded.addView(scrollView);
        scrollView.addView(patches);
        mExpanded.addView(view2);
        mExpanded.addView(relativeLayout);
        mFloatingView = rootFrame;
        if (Build.VERSION.SDK_INT >= 26) {
            params = new WindowManager.LayoutParams(-2, -2, 2038, 8, -3);
        } else {
            params = new WindowManager.LayoutParams(-2, -2, 2002, 8, -3);
        }
        WindowManager.LayoutParams layoutParams4 = params;
        layoutParams4.gravity = 51;
        layoutParams4.x = 0;
        layoutParams4.y = 100;
        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        mWindowManager.addView(mFloatingView, params);
        RelativeLayout relativeLayout2 = mCollapsed;
        LinearLayout linearLayout = mExpanded;
        mFloatingView.setOnTouchListener(onTouchListener());
        startimage.setOnTouchListener(onTouchListener());

        initMenuButton(relativeLayout2, linearLayout);
        CreateMenuList();
    }

    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = mCollapsed;
            final View expandedView = mExpanded;
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = motionEvent.getRawX();
                        initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - initialTouchY);

                        //The check for Xdiff <10 && YDiff< 10 because sometime elements moves a little while clicking.
                        //So that is click event.
                        if (rawX < 10 && rawY < 10 && isViewCollapsed()) {
                            //When user clicks on the image view of the collapsed layout,
                            //visibility of the collapsed layout will be changed to "View.GONE"
                            //and expanded view will become visible.
                            collapsedView.setVisibility(View.GONE);
                            expandedView.setVisibility(View.VISIBLE);
                           // playSound(Uri.fromFile(new File(cacheDir + "OpenMenu.ogg")));
                            
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        //Calculate the X and Y coordinates of the view.
                        params.x = initialX + ((int) (motionEvent.getRawX() - initialTouchX));
                        params.y = initialY + ((int) (motionEvent.getRawY() - initialTouchY));

                        //Update the layout with new X & Y coordinate
                        mWindowManager.updateViewLayout(mFloatingView, params);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }

    //Initialize event handlers for buttons, etc.
    private void initMenuButton(final View view2, final View view3) {
        startimage.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    view2.setVisibility(View.GONE);
                    view3.setVisibility(View.VISIBLE);
 
                }
            });
			
		//Kll
		
        close.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    view2.setVisibility(View.VISIBLE);
                    view2.setAlpha(0.95f);
                    view3.setVisibility(View.GONE);
                  //  playSound(Uri.fromFile(new File(cacheDir + "Back.ogg")));
                    //Log.i("LGL", "Close");
                }
            });
    }

	
	
    private void CreateMenuList() {
        String[] listFT = getFeatureList();
        for (int i = 0; i < listFT.length; i++) {
            final int feature = i;
            String str = listFT[i];
            if (str.contains("Toggle_")) {

                
			} else if (str.contains("Category_")) {
                addCategory(str.replace("Category_", ""));
            } else if (str.contains("Checkbox_")) {
                addCheckbox(str.replace("Checkbox_", ""), new InterfaceBtn() {
                        public void OnWrite() {
                            Changes(feature, 0);
                        }
                    });
		
		
          
					
				
			
						
						
			} else if (str.contains("Category_")) {
                addCategory(str.replace("Category_", ""));
            } else if (str.contains("RadioButton_")) {
                addRadioButton(str.replace("RadioButton_", ""), new InterfaceBtn() {
                        public void OnWrite() {
                            Changes(feature, 0);
                        }
                    });
					
			} else if (str.contains("Category_")) {
                addCategory(str.replace("Category_", ""));
            } else if (str.contains("RadioButton_")) {
                addRadioButton(str.replace("RadioButton_", ""), new InterfaceBtn() {
                        public void OnWrite() {
                            Changes(feature, 0);
                        }
                    });
				
					
			
					
			} else if (str.contains("Category_")) {
                addCategory(str.replace("Category_", ""));
            } else if (str.contains("TextClock_")) {
                addTextClock(str.replace("TextClock_", ""), new InterfaceBtn() {
                        public void OnWrite() {
                            Changes(feature, 0);
                        }
                    });
				
			
			} else if (str.contains("SeekBar_")) {
                String[] split = str.split("_");
                addSeekBar(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
                        public void OnWrite(int i) {
                            Changes(feature, i);
                        }
                    });

				
					
           }}}

    private TextView textView2;
    private String featureNameExt;
    private int featureNum;
    private EditTextValue txtValue;

    public class EditTextValue {
        private int val;

        public void setValue(int i) {
            val = i;
        }

        public int getValue() {
            return val;
        }
    }

    
    private void initAlertDiag() {
        LinearLayout linearLayout1 = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout1.setPadding(10, 5, 0, 5);
        linearLayout1.setOrientation(LinearLayout.VERTICAL);
        linearLayout1.setGravity(17);
        linearLayout1.setLayoutParams(layoutParams);
        linearLayout1.setBackgroundColor(Color.parseColor("BLACK"));

        int i = Build.VERSION.SDK_INT >= 26 ? 2038 : 2002;
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        linearLayout.setBackgroundColor(Color.parseColor("BLACK"));
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        frameLayout.addView(linearLayout);

        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='roboto'>Tap OK to apply changes. Tap outside to cancel</font>"));
        textView.setTextColor(Color.parseColor("#DEEDF6"));
        textView.setLayoutParams(layoutParams);

        edittextvalue = new EditText(this);
        edittextvalue.setLayoutParams(layoutParams);
        edittextvalue.setMaxLines(1);
        edittextvalue.setWidth(convertDipToPixels(300));
        edittextvalue.setTextColor(Color.parseColor("#93a6ae"));
        edittextvalue.setTextSize(13.0f);
        edittextvalue.setHintTextColor(Color.parseColor("#434d52"));
        edittextvalue.setInputType(InputType.TYPE_CLASS_NUMBER);
        edittextvalue.setKeyListener(DigitsKeyListener.getInstance("0123456789-"));

        InputFilter[] FilterArray = new InputFilter[1];
        FilterArray[0] = new InputFilter.LengthFilter(10);
        edittextvalue.setFilters(FilterArray);

        
        alert = new AlertDialog.Builder(this, 2).create();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Objects.requireNonNull(alert.getWindow()).setType(i);
        }
        linearLayout1.addView(textView);
        linearLayout1.addView(edittextvalue);
     //   linearLayout1.addView(button);
        alert.setView(linearLayout1);
    }

    
    private void addCategory(String text) {
        TextView textView = new TextView(this);
        textView.setBackgroundColor(Color.parseColor("#00000000"));
        textView.setText(text);
        textView.setGravity(17);
        textView.setTextSize(14.0f);
        textView.setTextColor(Color.parseColor("WHITE"));
        textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(10, 5, 0, 5);
        patches.addView(textView);
    }

    

    
	public void addCheckbox(String feature, final InterfaceBtn interfaceBtn) {
		// Criar o CheckBox
		final CheckBox checkBox = new CheckBox(this);
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
		);
		layoutParams.setMargins(7, 5, 7, 5);
		checkBox.setLayoutParams(layoutParams);
		checkBox.setTextSize(13.0f);
		checkBox.setTextColor(Color.parseColor("BLACK"));
		checkBox.setText(feature); // Define o texto do CheckBox

		// Configurar o comportamento do clique
		checkBox.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					interfaceBtn.OnWrite();
					if (checkBox.isChecked()) {
						toastC4F(getApplicationContext(), "ON", Color.RED, 20, Color.WHITE, 20, 3);
						
						} else {
							toastC4F(getApplicationContext(), "OFF", Color.RED, 20, Color.WHITE, 20, 3);
							}
				}
			});

		// Adicionar o CheckBox ao container principal
		patches.addView(checkBox);
	}
			
	
	public void addRadioButton(String feature, final InterfaceBtn interfaceBtn) {
	// Criar o RadioButton
		final RadioButton radioButton = new RadioButton(this);
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
		);
		layoutParams.setMargins(7, 5, 7, 5);
		radioButton.setLayoutParams(layoutParams);
		radioButton.setTextSize(13.0f);
		radioButton.setTextColor(Color.parseColor("BLACK"));
		radioButton.setText(feature); // Define o texto do RadioButton (substitui o texto ao lado)

		// Configurar o comportamento de desmarcar
		radioButton.setOnClickListener(new View.OnClickListener() {
				private boolean isSelected = false;

				@Override
				public void onClick(View v) {
					interfaceBtn.OnWrite();
					if (isSelected) {
						radioButton.setChecked(false);
						toastC4F(getApplicationContext(), "OFF", Color.RED, 20, Color.WHITE, 20, 3);
						
						isSelected = false;
					} else {
						radioButton.setChecked(true);
						toastC4F(getApplicationContext(), "ON", Color.RED, 20, Color.WHITE, 20, 3);
						
						isSelected = true;
					}
				}
			});

		// Adicionar o RadioButton ao container principal
		patches.addView(radioButton);
	}

    
	
	
	

	public void addTextClock(String feature, final InterfaceBtn interfaceBtn) {
    // Criar o TextClock
		final TextClock textClock = new TextClock(this);

		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
			

			LinearLayout.LayoutParams.WRAP_CONTENT
			);
		layoutParams.setMargins(150, 5, 150, 5);
		
		
		textClock.setLayoutParams(layoutParams);

		// Configurar o formato de exibição da hora e data
		textClock.setFormat12Hour("hh:mm:ss a"); // Formato para 12 horas
		textClock.setFormat24Hour("HH:mm:ss");  // Formato para 24 horas
		textClock.setTextColor(Color.WHITE);
		textClock.setTextSize(20);
		textClock.setBackgroundColor(Color.BLACK);

		// Configurar clique para interagir com o TextClock
		textClock.setOnClickListener(new View.OnClickListener() {
        @Override
				public void onClick(View v) {
				interfaceBtn.OnWrite();
					}
				});

		// Adicionar o TextClock ao container principal
		patches.addView(textClock);
		}
		
		
		
	private void addSeekBar(String str, int progress, int max, InterfaceInt sb) {
		final LinearLayout linearLayout = new LinearLayout(this);
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
		linearLayout.setPadding(20, 20, 20, 20);
		linearLayout.setOrientation(LinearLayout.HORIZONTAL);
		linearLayout.setGravity(Gravity.CENTER_VERTICAL);
		linearLayout.setLayoutParams(layoutParams);
		linearLayout.setBackgroundColor(Color.WHITE);

		// Texto descritivo
		final TextView textView = new TextView(this);
		textView.setText(str + ": " + progress);
		textView.setTextSize(16);
		textView.setTextColor(Color.BLACK);

		// Criação do SeekBar
		SeekBar seekBar = new SeekBar(this);
		seekBar.setScaleY(0.5f);  // Diminui a altura do SeekBar
		LinearLayout.LayoutParams seekBarParams = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
		seekBarParams.setMargins(20, 0, 0, 0);
		seekBar.setLayoutParams(seekBarParams);
		seekBar.setMax(max);
		seekBar.setProgress(progress);

		// Personalização da barra de progresso com uma linha fina
		GradientDrawable progressDrawable = new GradientDrawable();
		progressDrawable.setColor(Color.GRAY);  // Cor da barra
		progressDrawable.setCornerRadius(5);  // Arredondamento leve
		progressDrawable.setSize(0, 8);  // Altura bem fina

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
			seekBar.setProgressDrawableTiled(progressDrawable);
		} else {
			seekBar.setProgressDrawable(progressDrawable);
		}

		// Thumb minimalista
		GradientDrawable thumbDrawable = new GradientDrawable();
		thumbDrawable.setColor(Color.DKGRAY);  // Cor do thumb
		thumbDrawable.setSize(30, 30);  // Thumb pequeno
		thumbDrawable.setShape(GradientDrawable.OVAL);
		seekBar.setThumb(thumbDrawable);
		final String str3 = str;
		final InterfaceInt sb3 = sb;
		final int initialProgress = progress;
		seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onStartTrackingTouch(SeekBar seekBar) {
					linearLayout.setBackgroundColor(Color.LTGRAY);
				}

				@Override
				public void onStopTrackingTouch(SeekBar seekBar) {
					linearLayout.setBackgroundColor(Color.WHITE);
				}

				@Override
				public void onProgressChanged(SeekBar seekBar, int i, boolean fromUser) {
					if (i < initialProgress) {
						seekBar.setProgress(initialProgress);
						sb3.OnWrite(initialProgress);
						textView.setText(str3 + ": " + initialProgress);
					} else {
						sb3.OnWrite(i);
						textView.setText(str3 + ": " + i);
					}
				}
			});

		linearLayout.addView(textView);
		linearLayout.addView(seekBar);
		this.patches.addView(linearLayout);
	}
    boolean delayed;

    
    public boolean isViewCollapsed() {
        return mFloatingView == null || mCollapsed.getVisibility() == View.VISIBLE;
    }

    //For our image a little converter
    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

    //Destroy our View
    public void onDestroy() {
        super.onDestroy();
        View view = mFloatingView;
        if (view != null) {
            mWindowManager.removeView(view);
        }
    }

 
    private interface InterfaceBtn {
        void OnWrite();
    }

    private interface InterfaceInt {
        void OnWrite(int i);
    }

    private interface InterfaceBool {
        void OnWrite(boolean z);
    }

    private interface InterfaceStr {
        void OnWrite(String s);
    }
	private  interface SW {
        void OnWrite(boolean z);
    }
	
	public static void toastC4F(Context c, String msg, int textColor, int textSize, int bgColor, int cornerRadius, int position) {
		Toast c4f = Toast.makeText(c, msg, Toast.LENGTH_LONG);
		View vw = c4f.getView();
		TextView textView = vw.findViewById(android.R.id.message);
		textView.setTextSize(textSize);
		textView.setTextColor(textColor);
		textView.setGravity(Gravity.CENTER);

		GradientDrawable gD = new GradientDrawable();
		gD.setColor(bgColor);
		gD.setCornerRadius(cornerRadius);
		vw.setBackgroundDrawable(gD);
		vw.setPadding(15, 10, 15, 10);
		vw.setElevation(10);

		switch (position) {
			case 1:
				c4f.setGravity(Gravity.TOP, 0, 150);
				break;

			case 2:
				c4f.setGravity(Gravity.CENTER, 0, 0);
				break;

			case 3:
				c4f.setGravity(Gravity.BOTTOM, 0, 150);
				break;
		}
		c4f.show();
	}
	
}
