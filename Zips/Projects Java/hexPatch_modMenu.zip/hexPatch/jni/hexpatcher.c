#include <jni.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <dlfcn.h>
#include <android/log.h>
#include <stdio.h>
#include <errno.h>
#include <stdint.h>

#define LOG_TAG "HexPatch"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

JNIEXPORT jlongArray JNICALL
Java_com_hello_simplejni_FloatingHexPatcher_findPattern(JNIEnv *env, 
                                                        jobject thiz, 
                                                        jstring lib_name,
                                                        jbyteArray pattern,
                                                        jint pattern_size) {
    const char *lib_name_str = (*env)->GetStringUTFChars(env, lib_name, NULL);
    jbyte *pattern_bytes = (*env)->GetByteArrayElements(env, pattern, NULL);
    
    LOGI("═══════════════════════════════════════");
    LOGI("           BUSCA DE PADRÃO             ");
    LOGI("═══════════════════════════════════════");
    LOGI("Library: %s", lib_name_str);
    LOGI("Tamanho do padrão: %d bytes", pattern_size);
    

    FILE *maps = fopen("/proc/self/maps", "r");
    if(!maps) {
        LOGE("❌ ERRO: Não pude abrir /proc/self/maps");
        (*env)->ReleaseStringUTFChars(env, lib_name, lib_name_str);
        (*env)->ReleaseByteArrayElements(env, pattern, pattern_bytes, JNI_ABORT);
        return NULL;
    }
    
    char line[512];
    void *lib_base = NULL;
    size_t lib_size = 0;
    int library_found = 0;
    
    LOGI("🔍 Procurando library no processo atual...");
    while(fgets(line, sizeof(line), maps)) {
        if(strstr(line, lib_name_str)) {
            unsigned long start, end;
            char perms[8];
            if(sscanf(line, "%lx-%lx %7s", &start, &end, perms) == 3) {
                if(strstr(perms, "r-xp")) {
                    lib_base = (void*)start;
                    lib_size = end - start;
                    library_found = 1;
                    LOGI("✅ Library encontrada: %p", lib_base);
                    LOGI("📏 Tamanho: 0x%zx bytes", lib_size);
                    break;
                }
            }
        }
    }
    fclose(maps);
    
    if(!library_found) {
        LOGI("❌ Library %s não encontrada no processo", lib_name_str);
        (*env)->ReleaseStringUTFChars(env, lib_name, lib_name_str);
        (*env)->ReleaseByteArrayElements(env, pattern, pattern_bytes, JNI_ABORT);
        return NULL;
    }
    
    jlong *found_offsets = malloc(100 * sizeof(jlong));
    if (!found_offsets) {
        LOGE("❌ Falha na alocação de memória");
        (*env)->ReleaseStringUTFChars(env, lib_name, lib_name_str);
        (*env)->ReleaseByteArrayElements(env, pattern, pattern_bytes, JNI_ABORT);
        return NULL;
    }
    
    int found_count = 0;
    const int max_results = 100;
    size_t offset;
    
    LOGI("🔍 Procurando padrão na memória...");
    
    for(offset = 0; offset < lib_size - pattern_size && found_count < max_results; offset++) {
        if(memcmp((char*)lib_base + offset, pattern_bytes, pattern_size) == 0) {
            found_offsets[found_count] = (jlong)offset;
            found_count++;
            LOGI("🎯 Padrão %d em: 0x%zx", found_count, offset);
        }
        
        // Log de progresso a cada 64KB
        if(offset % 0x10000 == 0 && offset > 0) {
            float progress = (float)offset / lib_size * 100.0f;
            LOGI("📊 Progresso: 0x%zx/0x%zx (%.1f%%)", offset, lib_size, progress);
        }
    }
    
    LOGI("═══════════════════════════════════════");
    LOGI("            BUSCA CONCLUÍDA            ");
    LOGI("📈 Total de padrões encontrados: %d", found_count);
    LOGI("═══════════════════════════════════════");
    
    jlongArray result = NULL;
    if(found_count > 0) {
        result = (*env)->NewLongArray(env, found_count);
        if (result != NULL) {
            (*env)->SetLongArrayRegion(env, result, 0, found_count, found_offsets);
        }
    } else {
        LOGI("ℹ️ Nenhum padrão encontrado");
    }
    
    free(found_offsets);
    (*env)->ReleaseStringUTFChars(env, lib_name, lib_name_str);
    (*env)->ReleaseByteArrayElements(env, pattern, pattern_bytes, JNI_ABORT);
    return result;
}

JNIEXPORT jint JNICALL
Java_com_hello_simplejni_FloatingHexPatcher_applyPatch(JNIEnv *env, 
                                                       jobject thiz, 
                                                       jstring lib_name, 
                                                       jlongArray offsets,
                                                       jbyteArray new_pattern,
                                                       jint pattern_size) {
    const char *lib_name_str = (*env)->GetStringUTFChars(env, lib_name, NULL);
    jsize num_offsets = (*env)->GetArrayLength(env, offsets);
    jlong *offset_array = (*env)->GetLongArrayElements(env, offsets, NULL);
    jbyte *new_pattern_bytes = (*env)->GetByteArrayElements(env, new_pattern, NULL);
    
    LOGI("═══════════════════════════════════════");
    LOGI("          APLICAÇÃO DE PATCH           ");
    LOGI("═══════════════════════════════════════");
    LOGI("Library: %s", lib_name_str);
    LOGI("Offsets para patch: %d", num_offsets);
    LOGI("Tamanho do patch: %d bytes", pattern_size);
    
    void *lib_base = NULL;
    size_t lib_size = 0;
    
    FILE *maps = fopen("/proc/self/maps", "r");
    if (!maps) {
        LOGE("❌ Não foi possível abrir /proc/self/maps");
        (*env)->ReleaseStringUTFChars(env, lib_name, lib_name_str);
        (*env)->ReleaseLongArrayElements(env, offsets, offset_array, JNI_ABORT);
        (*env)->ReleaseByteArrayElements(env, new_pattern, new_pattern_bytes, JNI_ABORT);
        return 0;
    }
    
    char line[512];
    int library_found = 0;
    while(fgets(line, sizeof(line), maps)) {
        if(strstr(line, lib_name_str) && strstr(line, "r-xp")) {
            unsigned long start, end;
            if(sscanf(line, "%lx-%lx", &start, &end) == 2) {
                lib_base = (void*)start;
                lib_size = end - start;
                library_found = 1;
                LOGI("✅ Library encontrada: %p", lib_base);
                break;
            }
        }
    }
    fclose(maps);
    
    if(!library_found) {
        LOGE("❌ Não foi possível encontrar a library no processo");
        (*env)->ReleaseStringUTFChars(env, lib_name, lib_name_str);
        (*env)->ReleaseLongArrayElements(env, offsets, offset_array, JNI_ABORT);
        (*env)->ReleaseByteArrayElements(env, new_pattern, new_pattern_bytes, JNI_ABORT);
        return 0;
    }
    
    long page_size = sysconf(_SC_PAGESIZE);
    if (page_size == -1) {
        LOGE("❌ Não foi possível obter o tamanho da página");
        (*env)->ReleaseStringUTFChars(env, lib_name, lib_name_str);
        (*env)->ReleaseLongArrayElements(env, offsets, offset_array, JNI_ABORT);
        (*env)->ReleaseByteArrayElements(env, new_pattern, new_pattern_bytes, JNI_ABORT);
        return 0;
    }
    
    uintptr_t page_start = (uintptr_t)lib_base & ~(page_size - 1);
    uintptr_t page_end = ((uintptr_t)lib_base + lib_size + page_size - 1) & ~(page_size - 1);
    size_t total_protect_size = page_end - page_start;
    
    LOGI("🔒 Alterando proteção da memória...");
    LOGI("📄 Page range: %p - %p (0x%zx bytes)", 
         (void*)page_start, (void*)page_end, total_protect_size);
    
    if(mprotect((void*)page_start, total_protect_size, PROT_READ | PROT_WRITE | PROT_EXEC) == -1) {
        LOGE("❌ mprotect falhou: %s", strerror(errno));
        (*env)->ReleaseStringUTFChars(env, lib_name, lib_name_str);
        (*env)->ReleaseLongArrayElements(env, offsets, offset_array, JNI_ABORT);
        (*env)->ReleaseByteArrayElements(env, new_pattern, new_pattern_bytes, JNI_ABORT);
        return 0;
    }
    LOGI("✅ Proteção alterada com sucesso");
    
    int success_count = 0;
    int i;
    
    LOGI("🔧 Aplicando patches...");
    for(i = 0; i < num_offsets; i++) {
        jlong offset = offset_array[i];
        
        if(offset >= 0 && (offset + pattern_size) <= lib_size) {
            void *target_addr = (char*)lib_base + offset;
            
            // Aplicar o novo padrão
            memcpy(target_addr, new_pattern_bytes, pattern_size);
            success_count++;
            
            LOGI("✅ Patch %d OK [0x%llx]", success_count, (long long)offset);
        } else {
            LOGE("❌ Offset inválido: 0x%llx", (long long)offset);
        }
    }
    
    // Sincronizar e restaurar proteção
    msync((void*)page_start, total_protect_size, MS_SYNC);
    mprotect((void*)page_start, total_protect_size, PROT_READ | PROT_EXEC);
    LOGI("✅ Proteção restaurada");
    
    LOGI("═══════════════════════════════════════");
    LOGI("           PATCHES CONCLUÍDOS          ");
    LOGI("✅ Patches aplicados com sucesso: %d/%d", success_count, num_offsets);
    LOGI("═══════════════════════════════════════");
    
    (*env)->ReleaseStringUTFChars(env, lib_name, lib_name_str);
    (*env)->ReleaseLongArrayElements(env, offsets, offset_array, JNI_ABORT);
    (*env)->ReleaseByteArrayElements(env, new_pattern, new_pattern_bytes, JNI_ABORT);
    return success_count;
}

JNIEXPORT jint JNICALL
Java_com_hello_simplejni_FloatingHexPatcher_verifyPatch(JNIEnv *env, 
                                                        jobject thiz,
                                                        jstring lib_name,
                                                        jlongArray offsets,
                                                        jbyteArray expected_pattern,
                                                        jint pattern_size) {
    const char *lib_name_str = (*env)->GetStringUTFChars(env, lib_name, NULL);
    jsize num_offsets = (*env)->GetArrayLength(env, offsets);
    jlong *offset_array = (*env)->GetLongArrayElements(env, offsets, NULL);
    jbyte *expected_bytes = (*env)->GetByteArrayElements(env, expected_pattern, NULL);
    
    LOGI("═══════════════════════════════════════");
    LOGI("           VERIFICAÇÃO DE PATCH        ");
    LOGI("═══════════════════════════════════════");
    
    void *lib_base = NULL;
    size_t lib_size = 0;
    
    FILE *maps = fopen("/proc/self/maps", "r");
    if (!maps) {
        LOGE("❌ Não foi possível abrir /proc/self/maps");
        (*env)->ReleaseStringUTFChars(env, lib_name, lib_name_str);
        (*env)->ReleaseLongArrayElements(env, offsets, offset_array, JNI_ABORT);
        (*env)->ReleaseByteArrayElements(env, expected_pattern, expected_bytes, JNI_ABORT);
        return 0;
    }
    
    char line[512];
    int library_found = 0;
    while(fgets(line, sizeof(line), maps)) {
        if(strstr(line, lib_name_str) && strstr(line, "r-xp")) {
            unsigned long start, end;
            if(sscanf(line, "%lx-%lx", &start, &end) == 2) {
                lib_base = (void*)start;
                lib_size = end - start;
                library_found = 1;
                LOGI("✅ Library encontrada: %p", lib_base);
                break;
            }
        }
    }
    fclose(maps);
    
    if(!library_found) {
        LOGE("❌ Não foi possível encontrar a library no processo");
        (*env)->ReleaseStringUTFChars(env, lib_name, lib_name_str);
        (*env)->ReleaseLongArrayElements(env, offsets, offset_array, JNI_ABORT);
        (*env)->ReleaseByteArrayElements(env, expected_pattern, expected_bytes, JNI_ABORT);
        return 0;
    }
    
    int verified_count = 0;
    int i;
    
    LOGI("🔍 Verificando patches...");
    for(i = 0; i < num_offsets; i++) {
        jlong offset = offset_array[i];
        
        if(offset >= 0 && (offset + pattern_size) <= lib_size) {
            void *target_addr = (char*)lib_base + offset;
            
            if(memcmp(target_addr, expected_bytes, pattern_size) == 0) {
                verified_count++;
                LOGI("✅ Patch %d verificado [0x%llx]", verified_count, (long long)offset);
            } else {
                LOGI("❌ Patch não verificado [0x%llx]", (long long)offset);
            }
        }
    }
    
    LOGI("═══════════════════════════════════════");
    LOGI("        VERIFICAÇÃO CONCLUÍDA          ");
    LOGI("✅ Patches verificados: %d/%d", verified_count, num_offsets);
    LOGI("═══════════════════════════════════════");
    
    (*env)->ReleaseStringUTFChars(env, lib_name, lib_name_str);
    (*env)->ReleaseLongArrayElements(env, offsets, offset_array, JNI_ABORT);
    (*env)->ReleaseByteArrayElements(env, expected_pattern, expected_bytes, JNI_ABORT);
    return verified_count;
}
