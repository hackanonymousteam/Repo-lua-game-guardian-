APP_ABI := armeabi-v7a  # Compila para ARM 32-bit e 64-bit
APP_PLATFORM := android-21        # Define a versão mínima do Android
APP_OPTIM := release              # Otimização para release
