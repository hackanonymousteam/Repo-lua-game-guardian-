LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

# Nome do módulo (deve corresponder ao nome da biblioteca no System.loadLibrary)
LOCAL_MODULE    := hexpatcher

# Arquivos fonte
LOCAL_SRC_FILES := hexpatcher.c



LOCAL_LDLIBS += -llog

# Força o uso do conjunto de instruções ARM
LOCAL_ARM_MODE := arm

include $(BUILD_SHARED_LIBRARY)
