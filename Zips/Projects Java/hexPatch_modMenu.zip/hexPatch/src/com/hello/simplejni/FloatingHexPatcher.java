package com.hello.simplejni;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;

public class FloatingHexPatcher {
    static {
        System.loadLibrary("hexpatcher");
    }

    private static WindowManager windowManager;
    private static WindowManager.LayoutParams floatButtonParams;
    private static View floatButton;
    private static View menuView;
    private static boolean isMenuDisplayed = false;
    private static boolean isMove = false;
    private static int touchStartX, touchStartY;

    private static TextView tvStatus, tvProgress, tvResults;
    private static ScrollView scrollResults;
    private static Button btnPatch1, btnPatch2, btnPatch3, btnClose;
    private static LinearLayout mainLayout;

    private static Handler uiHandler;

    public static native long[] findPattern(String libName, byte[] pattern, int patternSize);
    public static native int applyPatch(String libName, long[] offsets, byte[] newPattern, int patternSize);
    public static native int verifyPatch(String libName, long[] offsets, byte[] expectedPattern, int patternSize);

    public static void initialize(Context context) {
        setupHandler();
        createMenuView(context);

        if (!Settings.canDrawOverlays(context)) {
            requestOverlayPermission(context);
        }
    }

    private static void setupHandler() {
        uiHandler = new Handler(Looper.getMainLooper());
    }

    private static void createMenuView(final Context context) {
        mainLayout = new LinearLayout(context);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setBackgroundColor(Color.parseColor("#CC1E1E1E"));
        mainLayout.setPadding(20, 20, 20, 20);

        TextView title = new TextView(context);
        title.setText("Hex Patcher - Memory Editor");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 20);
        mainLayout.addView(title);

        tvStatus = new TextView(context);
        tvStatus.setText("Status: Ready");
        tvStatus.setTextColor(Color.GREEN);
        tvStatus.setTextSize(14);
        mainLayout.addView(tvStatus);

        tvProgress = new TextView(context);
        tvProgress.setText("Progress: Waiting...");
        tvProgress.setTextColor(Color.YELLOW);
        tvProgress.setTextSize(12);
        mainLayout.addView(tvProgress);

        tvResults = new TextView(context);
        tvResults.setText("=== HEX PATCHER STARTED ===\nSelect a patch to apply\n");
        tvResults.setTextColor(Color.WHITE);
        tvResults.setTextSize(10);
        tvResults.setPadding(0, 20, 0, 20);

        scrollResults = new ScrollView(context);
        scrollResults.setLayoutParams(new LinearLayout.LayoutParams(
										  LinearLayout.LayoutParams.MATCH_PARENT, 
										  100));
        scrollResults.addView(tvResults);
        mainLayout.addView(scrollResults);

        btnPatch1 = new Button(context);
        btnPatch1.setText("Black Sky");
        btnPatch1.setBackgroundColor(Color.parseColor("#FF2196F3"));
        btnPatch1.setTextColor(Color.WHITE);
        btnPatch1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					applyGodModePatch(context);
				}
			});

        btnPatch2 = new Button(context);
        btnPatch2.setText("Alpha Color");
        btnPatch2.setBackgroundColor(Color.parseColor("#FF4CAF50"));
        btnPatch2.setTextColor(Color.WHITE);
        btnPatch2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					applyAmmoPatch(context);
				}
			});

        btnPatch3 = new Button(context);
        btnPatch3.setText("Camera View");
        btnPatch3.setBackgroundColor(Color.parseColor("#FFFF9800"));
        btnPatch3.setTextColor(Color.WHITE);
        btnPatch3.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					applySpeedPatch(context);
					applyNoRecoilPatch(context);
					applyNoRecoilPatch2(context);
				}
			});

        btnClose = new Button(context);
        btnClose.setText("Close Menu");
        btnClose.setBackgroundColor(Color.parseColor("#FFF44336"));
        btnClose.setTextColor(Color.WHITE);
        btnClose.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					closeMenu();
					showFloatButton(context);
				}
			});

        mainLayout.addView(btnPatch1);
        mainLayout.addView(btnPatch2);
        mainLayout.addView(btnPatch3);
        mainLayout.addView(btnClose);

        menuView = mainLayout;
    }

    private static byte[] getGodModeSearchPattern() {
        return new byte[] { 
            (byte)0xA4, (byte)0x70, (byte)0x7D, (byte)0x3F,
            (byte)0x3A, (byte)0xCD, (byte)0x13, (byte)0x3F,
            (byte)0x0A, (byte)0xD7, (byte)0x23, (byte)0x3C,
            (byte)0xBD, (byte)0x37, (byte)0x86, (byte)0x35
        };
    }

    private static byte[] getGodModeReplacePattern() {
        return new byte[] { 
            (byte)0xA4, (byte)0x70, (byte)0x7D, (byte)0x3F,
            (byte)0x3A, (byte)0xCD, (byte)0x13, (byte)0x3F,
            (byte)0x0A, (byte)0xD7, (byte)0x23, (byte)0x3C,
            (byte)0x00, (byte)0x00, (byte)0x80, (byte)0xBF
        };
    }

    private static byte[] getAmmoSearchPattern() {
        return new byte[] {
            (byte)0xF0, (byte)0x8F, (byte)0xBD, (byte)0xE8,
            (byte)0x6F, (byte)0x12, (byte)0x83, (byte)0x3A
        };
    }

    private static byte[] getAmmoReplacePattern() {
        return new byte[] {
            (byte)0xF0, (byte)0x8F, (byte)0xBD, (byte)0xE8,
            (byte)0x00, (byte)0xC0, (byte)0x79, (byte)0x44
        };
    }

    private static byte[] getSpeedSearchPattern() {
        return new byte[] {
            (byte)0xF0, (byte)0x88, (byte)0xBD, (byte)0xE8,
            (byte)0x00, (byte)0x00, (byte)0xB4, (byte)0x43,
            (byte)0xDB, (byte)0x0F, (byte)0x49, (byte)0x40
        };
    }

    private static byte[] getSpeedReplacePattern() {
        return new byte[] {
            (byte)0xF0, (byte)0x88, (byte)0xBD, (byte)0xE8,
            (byte)0x00, (byte)0x00, (byte)0x7A, (byte)0x43,
            (byte)0xDB, (byte)0x0F, (byte)0x49, (byte)0x40
        };
    }

    private static byte[] getNoRecoilSearchPattern() {
        return new byte[] {
            (byte)0x70, (byte)0x80, (byte)0xBD, (byte)0xE8,
            (byte)0x00, (byte)0x00, (byte)0xB4, (byte)0x43,
            (byte)0xDB, (byte)0x0F, (byte)0x49, (byte)0x40
        };
    }

    private static byte[] getNoRecoilReplacePattern() {
        return new byte[] {
            (byte)0x70, (byte)0x80, (byte)0xBD, (byte)0xE8,
            (byte)0x00, (byte)0x00, (byte)0x7A, (byte)0x43,
            (byte)0xDB, (byte)0x0F, (byte)0x49, (byte)0x40
        };
    }

    private static byte[] getNoRecoilSearchPattern2() {
        return new byte[] {
            (byte)0x00, (byte)0x00, (byte)0xB4, (byte)0x43,
            (byte)0xDB, (byte)0x0F, (byte)0x49, (byte)0x40
        };
    }

    private static byte[] getNoRecoilReplacePattern2() {
        return new byte[] {
            (byte)0x00, (byte)0x00, (byte)0x7A, (byte)0x43,
            (byte)0xDB, (byte)0x0F, (byte)0x49, (byte)0x40
        };
    }

    private static void applyGodModePatch(final Context context) {
        startHexPatch(context, 
                      "Black Sky", 
                      getGodModeSearchPattern(),
                      getGodModeReplacePattern(),
                      new String[]{"libunity.so"});
    }

    private static void applyAmmoPatch(final Context context) {
        startHexPatch(context,
                      "Alpha Color",
                      getAmmoSearchPattern(),
                      getAmmoReplacePattern(),
                      new String[]{"libunity.so"});
    }

    private static void applySpeedPatch(final Context context) {
        startHexPatch(context,
                      "Camera View",
                      getSpeedSearchPattern(),
                      getSpeedReplacePattern(),
                      new String[]{"libunity.so"});
    }

    private static void applyNoRecoilPatch(final Context context) {
        startHexPatch(context,
                      "Camera View",
                      getNoRecoilSearchPattern(),
                      getNoRecoilReplacePattern(),
                      new String[]{"libunity.so"});
    }

    private static void applyNoRecoilPatch2(final Context context) {
        startHexPatch(context,
                      "Camera View",
                      getNoRecoilSearchPattern2(),
                      getNoRecoilReplacePattern2(),
                      new String[]{"libunity.so"});
    }

    private static void startHexPatch(final Context context, 
                                      final String patchName,
                                      final byte[] searchPattern,
                                      final byte[] replacePattern,
                                      final String[] libNames) {
        Thread patchThread = new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						updateStatus("Applying " + patchName + "...");
						clearResults();
						addToResults(patchName);
						addToResults("Searching for pattern...");

						boolean patchApplied = false;

						for (String libName : libNames) {
							addToResults("Searching in: " + libName);

							long[] offsets = findPattern(libName, searchPattern, searchPattern.length);

							if (offsets != null && offsets.length > 0) {
								addToResults("Pattern found in " + libName);
								addToResults("Offsets found: " + offsets.length);

								int result = applyPatch(libName, offsets, replacePattern, replacePattern.length);

								if (result > 0) {
									addToResults("Patch applied successfully!");
									addToResults("Modified offsets: " + result);
									updateStatus(patchName + " OK");
									showToast(context, patchName + " applied successfully!");
									patchApplied = true;
									break;
								} else {
									addToResults("Failed to apply patch in " + libName);
								}
							} else {
								addToResults("Pattern not found in " + libName);
							}
						}

						if (!patchApplied) {
							addToResults("Try in another game/app");
							updateStatus(patchName + " Failed");
							showToast(context, patchName + " - Pattern not found");
						}

					} catch (final Exception e) {
						addToResults("Error: " + e.getMessage());
						updateStatus("Error in " + patchName);
						showToast(context, "Error: " + e.getClass().getSimpleName());
						e.printStackTrace();
					}
				}
			});

        patchThread.start();
    }

    public static void showFloatWindow(Context context) {
        if (Settings.canDrawOverlays(context)) {
            showFloatButton(context);
        } else {
            requestOverlayPermission(context);
        }
    }

    private static void showFloatButton(final Context context) {
        windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        floatButtonParams = new WindowManager.LayoutParams();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            floatButtonParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            floatButtonParams.type = WindowManager.LayoutParams.TYPE_PHONE;
        }

        floatButton = new View(context);

        Drawable iconDrawable = ContextCompat.getDrawable(context, android.R.drawable.ic_menu_manage);
        if (iconDrawable != null) {
            floatButton.setBackground(iconDrawable);
        } else {
            floatButton.setBackgroundColor(Color.parseColor("#FF4CAF50"));
        }

        floatButton.setOnTouchListener(new FloatingButtonTouchListener());
        floatButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (!isMove) {
						showMenu(context);
					}
				}
			});

        floatButtonParams.format = PixelFormat.TRANSLUCENT;
        floatButtonParams.gravity = Gravity.START | Gravity.TOP;
        floatButtonParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        floatButtonParams.width = 80;
        floatButtonParams.height = 80;
        floatButtonParams.x = 50;
        floatButtonParams.y = 200;

        try {
            windowManager.addView(floatButton, floatButtonParams);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void showMenu(Context context) {
        if (menuView == null) {
            initialize(context);
        }

        WindowManager menuWindowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        WindowManager.LayoutParams menuParams = new WindowManager.LayoutParams();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            menuParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            menuParams.type = WindowManager.LayoutParams.TYPE_PHONE;
        }

        menuParams.format = PixelFormat.TRANSLUCENT;
        menuParams.gravity = Gravity.CENTER;
        menuParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        menuParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
        menuParams.height = WindowManager.LayoutParams.WRAP_CONTENT;

        try {
            if (floatButton != null) {
                windowManager.removeView(floatButton);
            }
            menuWindowManager.addView(menuView, menuParams);
            isMenuDisplayed = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void closeMenu() {
        try {
            if (menuView != null) {
                WindowManager menuWM = (WindowManager) menuView.getContext().getSystemService(Context.WINDOW_SERVICE);
                menuWM.removeView(menuView);
                isMenuDisplayed = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static class FloatingButtonTouchListener implements View.OnTouchListener {
        @Override
        public boolean onTouch(View view, MotionEvent motionEvent) {
            switch (motionEvent.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    isMove = false;
                    touchStartX = (int) motionEvent.getRawX();
                    touchStartY = (int) motionEvent.getRawY();
                    break;

                case MotionEvent.ACTION_MOVE:
                    int rawX = (int) motionEvent.getRawX();
                    int rawY = (int) motionEvent.getRawY();
                    int dx = rawX - touchStartX;
                    int dy = rawY - touchStartY;

                    if (Math.abs(dx) > 5 || Math.abs(dy) > 5) {
                        isMove = true;
                    }

                    touchStartX = rawX;
                    touchStartY = rawY;
                    floatButtonParams.x += dx;
                    floatButtonParams.y += dy;
                    windowManager.updateViewLayout(floatButton, floatButtonParams);
                    break;

                case MotionEvent.ACTION_UP:
                    if (isMove) {
                        isMove = false;
                        return true;
                    }
                    break;
            }
            return false;
        }
    }

    private static void requestOverlayPermission(Context context) {
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                   Uri.parse("package:" + context.getPackageName()));
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    private static void updateStatus(final String text) {
        uiHandler.post(new Runnable() {
				@Override
				public void run() {
					tvStatus.setText("Status: " + text);
				}
			});
    }

    private static void updateProgress(final String text) {
        uiHandler.post(new Runnable() {
				@Override
				public void run() {
					tvProgress.setText("Progress: " + text);
				}
			});
    }

    private static void addToResults(final String text) {
        uiHandler.post(new Runnable() {
				@Override
				public void run() {
					String current = tvResults.getText().toString();
					tvResults.setText(current + "\n" + text);

					scrollResults.post(new Runnable() {
							@Override
							public void run() {
								scrollResults.fullScroll(View.FOCUS_DOWN);
							}
						});
				}
			});
    }

    private static void clearResults() {
        uiHandler.post(new Runnable() {
				@Override
				public void run() {
					tvResults.setText("");
				}
			});
    }

    private static void showToast(final Context context, final String text) {
        uiHandler.post(new Runnable() {
				@Override
				public void run() {
					Toast.makeText(context, text, Toast.LENGTH_SHORT).show();
				}
			});
    }

    public static void destroy() {
        try {
            if (floatButton != null && windowManager != null) {
                windowManager.removeView(floatButton);
            }
            if (menuView != null) {
                WindowManager menuWM = (WindowManager) menuView.getContext().getSystemService(Context.WINDOW_SERVICE);
                menuWM.removeView(menuView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
