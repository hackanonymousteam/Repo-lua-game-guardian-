package com.hello.simplejni;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Context;
import android.util.Log;
import java.util.ArrayList;


public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    
        FloatingHexPatcher.initialize(this);
        FloatingHexPatcher.showFloatWindow(this);

   
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        FloatingHexPatcher.destroy();
    }
}
