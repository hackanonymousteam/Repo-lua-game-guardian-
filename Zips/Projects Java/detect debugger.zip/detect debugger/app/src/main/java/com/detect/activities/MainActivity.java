package com.detect.activities;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.widget.TextView;
import com.detect.R;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;

public class MainActivity extends Activity {
    private TextView processListTextView;

    private Set<String> ignoredPackages;

    private boolean suspiciousProcessFound = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        processListTextView = findViewById(R.id.processListTextView);


        ignoredPackages = new HashSet<>(Arrays.asList(
											"com.detect" 
										));

        
        listRunningProcesses();


        new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {
					if (!suspiciousProcessFound) {
						finish(); 
						}
				}
			}, 20000); 
    }

    private void listRunningProcesses() {
        ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (activityManager != null) {
            List<ActivityManager.RunningAppProcessInfo> runningProcesses = activityManager.getRunningAppProcesses();
            StringBuilder alertMessage = new StringBuilder();


            Set<String> checkedMainPackages = new HashSet<>();


            Map<String, List<String>> mainToSubprocessMap = new HashMap<>();

            for (ActivityManager.RunningAppProcessInfo process : runningProcesses) {
                String processName = process.processName;
                String pid = String.valueOf(process.pid);


                if (ignoredPackages.contains(processName)) {
                    continue; 
                }


                boolean isSubprocess = false;
                for (String mainPackage : checkedMainPackages) {
                    if (processName.startsWith(mainPackage)) {
                        isSubprocess = true;
                        mainToSubprocessMap.get(mainPackage).add(processName); 
                        break;
                    }
                }

                  if (!isSubprocess) {
                    checkedMainPackages.add(processName);
                    mainToSubprocessMap.put(processName, new ArrayList<>()); // Inicializa a lista de subprocessos
                }
            }

         
            for (String mainPackage : checkedMainPackages) {
            
                if (mainToSubprocessMap.get(mainPackage).size() > 0) {
                    continue; 
                }

              
                for (ActivityManager.RunningAppProcessInfo process : runningProcesses) {
                    String processName = process.processName;
                    String pid = String.valueOf(process.pid);

                    if (processName.equals(mainPackage)) {
                      
                        if (isBeingDebugged(pid)) {
                            alertMessage.append("Warning: ").append(processName).append("\n")
                                .append("PID: ").append(pid).append("\n\n");
                            suspiciousProcessFound = true; 
                        }

                    
                        if (isAccessingMemoryTools(pid)) {
                            alertMessage.append("Debugger ").append(processName).append("\n")
                                .append("PID: ").append(pid).append("\n\n");
                            suspiciousProcessFound = true; 
                        }
                    }
                }
            }

            
            if (alertMessage.length() > 0) {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Malware detected")
                    .setMessage(alertMessage.toString())
                    .setCancelable(false)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            System.exit(0); 
                        }
                    })
                    .show();
            }
        }
    }

  
    private boolean isBeingDebugged(String pid) {
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader("/proc/" + pid + "/status"));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("TracerPid")) {
                    int tracerPid = Integer.parseInt(line.split(":")[1].trim());
                    return tracerPid > 0;   
                     }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return false;
    }

   
    private boolean isAccessingMemoryTools(String pid) {
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader("/proc/" + pid + "/maps"));
            String line;
            while ((line = reader.readLine()) != null) {
             
                if (line.contains("libgg.so") || line.contains("libdvm.so") || line.contains("libart.so")) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return false;
    }
}
