package com.detect.activities;
import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class processNotification extends Service {
    
		private static final String CHANNEL_ID = "ProcessMonitorChannel";
		private Set<String> ignoredPackages;

		@Override
		public void onCreate() {
			super.onCreate();

			ignoredPackages = new HashSet<>();
			ignoredPackages.add("com.detect");

			createNotificationChannel();

			Notification notification = buildNotification("Monitoring running processes...");
			startForeground(1, notification);

			startProcessMonitoring();
		}

		private void startProcessMonitoring() {
			new Thread(new Runnable() {
					@Override
					public void run() {
						while (true) {
							if (listRunningProcesses()) {
								stopSelf(); 
								System.exit(0);
								return;
							}

							try {
								Thread.sleep(5000); 
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}
					}
				}).start();
		}

		private boolean listRunningProcesses() {
			ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
			if (activityManager != null) {
				List<ActivityManager.RunningAppProcessInfo> runningProcesses = activityManager.getRunningAppProcesses();

				for (ActivityManager.RunningAppProcessInfo process : runningProcesses) {
					String processName = process.processName;
					String pid = String.valueOf(process.pid);

					if (ignoredPackages.contains(processName)) {
						continue;
					}

					if (isBeingDebugged(pid)) {
						sendNotificationAndStop("Debugger detected: " + processName + " (PID: " + pid + ")");
						return true; 
					}

					if (isAccessingMemoryTools(pid)) {
						sendNotificationAndStop("Memory tool detected: " + processName + " (PID: " + pid + ")");
						return true; 
					}
				}
			}
			return false; 
		}

		private boolean isBeingDebugged(String pid) {
			BufferedReader reader = null;
			try {
				reader = new BufferedReader(new FileReader("/proc/" + pid + "/status"));
				String line;
				while ((line = reader.readLine()) != null) {
					if (line.startsWith("TracerPid")) {
						int tracerPid = Integer.parseInt(line.split(":")[1].trim());
						return tracerPid > 0;
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				if (reader != null) {
					try {
						reader.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			return false;
		}

		private boolean isAccessingMemoryTools(String pid) {
			BufferedReader reader = null;
			try {
				reader = new BufferedReader(new FileReader("/proc/" + pid + "/maps"));
				String line;
				while ((line = reader.readLine()) != null) {
					if (line.contains("libgg.so") || line.contains("libdvm.so") || line.contains("libart.so")) {
						return true;
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				if (reader != null) {
					try {
						reader.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			return false;
		}

		private void sendNotificationAndStop(String message) {
			Notification notification = buildNotification(message);
			NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
			if (manager != null) {
				manager.notify(1, notification);
			}
		}

		private void createNotificationChannel() {
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
				NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Process Monitor Service",
                    NotificationManager.IMPORTANCE_HIGH
				);

				NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
				if (manager != null) {
					manager.createNotificationChannel(channel);
				}
			}
		}

		private Notification buildNotification(String contentText) {
			Notification.Builder builder;
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
				builder = new Notification.Builder(this, CHANNEL_ID);
			} else {
				builder = new Notification.Builder(this);
			}

			return builder
                .setContentTitle("Process Monitor")
                .setContentText(contentText)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .build();
		}

		@Override
		public IBinder onBind(Intent intent) {
			return null;
		}

		@Override
		public int onStartCommand(Intent intent, int flags, int startId) {
			return START_STICKY;
		}

		@Override
		public void onDestroy() {
			super.onDestroy();
		}
	}
