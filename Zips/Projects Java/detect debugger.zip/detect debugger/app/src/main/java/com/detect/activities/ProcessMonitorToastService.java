package com.detect.activities;

import android.app.ActivityManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ProcessMonitorToastService extends Service {
    private Set<String> ignoredPackages;
		private boolean suspiciousProcessFound = false;

		@Override
		public void onCreate() {
			super.onCreate();

			ignoredPackages = new HashSet<>(Arrays.asList("com.detect")); 
			
			startProcessMonitoring();
		}

		private void startProcessMonitoring() {
			new Thread(new Runnable() {
					@Override
					public void run() {
						while (true) {
							if (listRunningProcesses()) {
							
								stopSelf();  
								System.exit(0); 
								return;
							}

						
							try {
								Thread.sleep(10000); // 10 seconds
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}
					}
				}).start();
		}

		private boolean listRunningProcesses() {
			ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
			if (activityManager != null) {
				List<ActivityManager.RunningAppProcessInfo> runningProcesses = activityManager.getRunningAppProcesses();
				StringBuilder alertMessage = new StringBuilder();

				for (ActivityManager.RunningAppProcessInfo process : runningProcesses) {
					String processName = process.processName;
					String pid = String.valueOf(process.pid);

					if (ignoredPackages.contains(processName)) {
						continue;
					}

					if (isBeingDebugged(pid)) {
						alertMessage.append("Debugging Detected: ").append(processName).append("\n")
							.append("PID: ").append(pid).append("\n\n");
						suspiciousProcessFound = true;
					}

					if (isAccessingMemoryTools(pid)) {
						alertMessage.append("Memory Tool Detected: ").append(processName).append("\n")
							.append("PID: ").append(pid).append("\n\n");
						suspiciousProcessFound = true;
					}
				}

				if (suspiciousProcessFound) {
					showAlert(alertMessage.toString());
					return true; 
				}
			}
			return false; 
		}

		private boolean isBeingDebugged(String pid) {
			BufferedReader reader = null;
			try {
				reader = new BufferedReader(new FileReader("/proc/" + pid + "/status"));
				String line;
				while ((line = reader.readLine()) != null) {
					if (line.startsWith("TracerPid")) {
						int tracerPid = Integer.parseInt(line.split(":")[1].trim());
						return tracerPid > 0;
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				if (reader != null) {
					try {
						reader.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			return false;
		}

		private boolean isAccessingMemoryTools(String pid) {
			BufferedReader reader = null;
			try {
				reader = new BufferedReader(new FileReader("/proc/" + pid + "/maps"));
				String line;
				while ((line = reader.readLine()) != null) {
					if (line.contains("libgg.so") || line.contains("libdvm.so") || line.contains("libart.so")) {
						return true;
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				if (reader != null) {
					try {
						reader.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			return false;
		}

		private void showAlert(final String message) {
			Handler handler = new Handler(Looper.getMainLooper());
			handler.post(new Runnable() {
					@Override
					public void run() {
						
						Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
					}
				});
		}

		@Override
		public IBinder onBind(Intent intent) {
			return null;
		}
	}
