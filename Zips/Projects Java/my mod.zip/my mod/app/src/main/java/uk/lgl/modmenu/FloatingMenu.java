package uk.lgl.modmenu;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androtrainer.Flags;
import androtrainer.MemoryScanner;
import androtrainer.Ranges;

public class FloatingMenu {
	
	public static native void F1(); 
	public static native void F2(); 
	public static native void F3(); 
	public static native void F4(); 
	public static native void F5(); 
	public static native void F6(); 
	public static native void F7(); 
	
	public static native void F1off(); 
	public static native void F2off(); 
	public static native void F3off(); 
	public static native void F4off(); 
	public static native void F5off(); 
	public static native void F6off(); 
	
	static {
	System.loadLibrary("AnaGaby"); 
	}
    private static final int EXTERNAL_STORAGE_REQ_CODE = 0;

    public static boolean bu1 = false, bu2 = false, bu3 = false, 
	bu4 = false, bu5 = false, bu6 = false, bu7 = false;

    private static boolean isMove = false;

    private static WindowManager.LayoutParams floatButtonParams;
    private static WindowManager windowManager;
    private static ImageButton floatButton;
    private static WindowManager.LayoutParams menuParams;
    private static WindowManager menuWindowManager;
    private static View menuView;
    private static int touchStartX, touchStartY;

    private static Switch switch1, switch2, switch3, switch4, switch5, switch6, switch7;

    public static boolean isMenuDisplayed = false;

    public static void checkFloatViewPermission(Context context) {
        if (Settings.canDrawOverlays(context)) {
            return;
        }
        //Toast.makeText(context, "Ative a permissão de janela flutuante", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, 
								   Uri.parse("package:" + context.getPackageName()));
        context.startActivity(intent);
    }

    public static void initialize(Context context) {
        // Create menu view
        menuView = createMenuView(context);

        // Check permissions
        if (context.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) 
            != PackageManager.PERMISSION_GRANTED) {
            ((Activity)context).requestPermissions(
                new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 
                EXTERNAL_STORAGE_REQ_CODE);
        }
    }

    private static View createMenuView(final Context context) {
        LinearLayout menuLayout = new LinearLayout(context);
        menuLayout.setOrientation(LinearLayout.VERTICAL);
        menuLayout.setBackgroundColor(Color.parseColor("#88000000"));
        menuLayout.setPadding(20, 20, 20, 20);

        // Add title
        TextView title = new TextView(context);
        title.setText("Batman Mod");
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setGravity(Gravity.CENTER);
        menuLayout.addView(title);

        // Add switches
        switch1 = createSwitch(context, "Black sky", bu1);
        switch2 = createSwitch(context, "Wallhack", bu2);
        switch3 = createSwitch(context, "Camera hack", bu3);
        switch4 = createSwitch(context, "Fly hack", bu4);
        switch5 = createSwitch(context, "remove sound", bu5);
        switch6 = createSwitch(context, "Magic color", bu6);
        switch7 = createSwitch(context, "autokill", bu7);

        menuLayout.addView(switch1);
        menuLayout.addView(switch2);
        menuLayout.addView(switch3);
        menuLayout.addView(switch4);
        menuLayout.addView(switch5);
        menuLayout.addView(switch6);
        menuLayout.addView(switch7);

        Button closeButton = new Button(context);
        closeButton.setText("Close");
        closeButton.setBackgroundColor(Color.parseColor("#FF6200EE"));
        closeButton.setTextColor(Color.WHITE);
        closeButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					closeMenu();
					showFloatButton(context);
				}
			});

        menuLayout.addView(closeButton);
        return menuLayout;
    }

    private static Switch createSwitch(Context context, String text, boolean isChecked) {
        Switch switchButton = new Switch(context);
        switchButton.setText(text);
        switchButton.setTextColor(Color.WHITE);
        switchButton.setChecked(isChecked);
        switchButton.setOnCheckedChangeListener(new SwitchListener(context));
        return switchButton;
    }

    public static boolean getChecked(int i) {
        switch (i) {
            case 1: return bu2;
            case 2: return bu3;
            case 3: return bu4;
            case 4: return bu5;
            case 5: return bu6;
            case 6: return bu7;
            default: return false;
        }
    }

    public static void showFloatWindow(Context context) {
        if (Settings.canDrawOverlays(context)) {
            showFloatButton(context);
        } else {
           // Toast.makeText(context, "Falha ao criar janela flutuante", Toast.LENGTH_LONG).show();
            checkFloatViewPermission(context);
        }
    }

    private static void showFloatButton(final Context context) {
        windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        floatButtonParams = new WindowManager.LayoutParams();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            floatButtonParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            floatButtonParams.type = WindowManager.LayoutParams.TYPE_PHONE;
        }

        floatButton = new ImageButton(context);
        floatButton.setImageResource(android.R.drawable.ic_menu_manage);
        floatButton.setBackgroundColor(Color.TRANSPARENT);
        floatButton.setOnTouchListener(new FloatingButtonTouchListener());

        floatButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (!isMove) {
						showMenu(context);
					}
				}
			});

        floatButtonParams.format = PixelFormat.TRANSLUCENT;
        floatButtonParams.gravity = Gravity.START | Gravity.TOP;
        floatButtonParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        floatButtonParams.width = 120;
        floatButtonParams.height = 120;
        floatButtonParams.x = 300;
        floatButtonParams.y = 0;

        try {
            windowManager.addView(floatButton, floatButtonParams);
        } catch (Exception e) {
            e.printStackTrace();
          //  Toast.makeText(context, "Erro ao exibir botão flutuante", Toast.LENGTH_SHORT).show();
        }
    }

    private static void showMenu(Context context) {
        if (menuView == null) {
            initialize(context);
        }

        menuWindowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        menuParams = new WindowManager.LayoutParams();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            menuParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            menuParams.type = WindowManager.LayoutParams.TYPE_PHONE;
        }

        menuParams.format = PixelFormat.TRANSLUCENT;
        menuParams.gravity = Gravity.START | Gravity.TOP;
        menuParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        menuParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
        menuParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        menuParams.x = floatButtonParams.x;
        menuParams.y = floatButtonParams.y;

        try {
            windowManager.removeView(floatButton);
            menuWindowManager.addView(menuView, menuParams);
            isMenuDisplayed = true;
        } catch (Exception e) {
            e.printStackTrace();
            }}

    private static void closeMenu() {
        try {
            if (menuView != null && menuWindowManager != null) {
                menuWindowManager.removeView(menuView);
                isMenuDisplayed = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static class FloatingButtonTouchListener implements View.OnTouchListener {
        @Override
        public boolean onTouch(View view, MotionEvent motionEvent) {
            switch (motionEvent.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    isMove = false;
                    touchStartX = (int) motionEvent.getRawX();
                    touchStartY = (int) motionEvent.getRawY();
                    break;

                case MotionEvent.ACTION_MOVE:
                    int rawX = (int) motionEvent.getRawX();
                    int rawY = (int) motionEvent.getRawY();
                    int dx = rawX - touchStartX;
                    int dy = rawY - touchStartY;

                    if (Math.abs(dx) > 5 || Math.abs(dy) > 5) {
                        isMove = true;
                    }

                    touchStartX = rawX;
                    touchStartY = rawY;
                    floatButtonParams.x += dx;
                    floatButtonParams.y += dy;
                    windowManager.updateViewLayout(floatButton, floatButtonParams);
                    break;

                case MotionEvent.ACTION_UP:
                    if (isMove) {
                        isMove = false;
                        return true;
                    }
                    break;
            }
            return false;
        }
    }

    private static class SwitchListener implements CompoundButton.OnCheckedChangeListener {
        private Context context;

        public SwitchListener(Context context) {
            this.context = context;
        }

		@Override
		public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {

			if (compoundButton == switch1) {
				bu1 = isChecked;
				if (isChecked) {
					FloatingMenu.F1();
					Toast.makeText(context, " ON", Toast.LENGTH_SHORT).show();
				} else {
					FloatingMenu.F1off();
					Toast.makeText(context, " OFF", Toast.LENGTH_SHORT).show();
				}

			} else if (compoundButton == switch2) {
				bu2 = isChecked;
				if (isChecked) {
					FloatingMenu.F2();
					Toast.makeText(context, " ON", Toast.LENGTH_SHORT).show();
				} else {
					FloatingMenu.F2off();
					Toast.makeText(context, " OFF", Toast.LENGTH_SHORT).show();
				}

			} else if (compoundButton == switch3) {
				bu3 = isChecked;
				if (isChecked) {
					FloatingMenu.F3();
					Toast.makeText(context, " ON", Toast.LENGTH_SHORT).show();
				} else {
					FloatingMenu.F3off();
					Toast.makeText(context, " OFF", Toast.LENGTH_SHORT).show();
				}

			} else if (compoundButton == switch4) {
				bu4 = isChecked;
				if (isChecked) {
					FloatingMenu.F4();
					Toast.makeText(context, " ON", Toast.LENGTH_SHORT).show();
				} else {
					FloatingMenu.F4off();
					Toast.makeText(context, " OFF", Toast.LENGTH_SHORT).show();
				}

			} else if (compoundButton == switch5) {
				bu5 = isChecked;
				if (isChecked) {
					FloatingMenu.F5();
					Toast.makeText(context, " ON", Toast.LENGTH_SHORT).show();
				} else {
					FloatingMenu.F5off();
					Toast.makeText(context, " OFF", Toast.LENGTH_SHORT).show();
				}

			} else if (compoundButton == switch6) {
				bu6 = isChecked;
				if (isChecked) {
					final MemoryScanner gg = new MemoryScanner();
					gg.setRanges(new int[]{Ranges.ANONYMOUS});
					gg.searchNumber("2.25", Flags.FLOAT);
					gg.refineNumber("2.25", Flags.FLOAT, 0x0);
					gg.refineNumber("2.25", Flags.FLOAT, 0x0);
					gg.refineNumber("2.25", Flags.FLOAT, 0x0);
					gg.refineNumber("2.25", Flags.FLOAT, 0x0);
					gg.getResults(Flags.FLOAT);
					gg.editAll("999", Flags.FLOAT, 0x0);
					gg.clearResults();
					Toast.makeText(context, "ON", Toast.LENGTH_SHORT).show();
				} else {
					final MemoryScanner gg = new MemoryScanner();
					gg.setRanges(new int[]{Ranges.ANONYMOUS});
					gg.searchNumber("999", Flags.FLOAT);
					gg.refineNumber("999", Flags.FLOAT, 0x0);
					gg.refineNumber("999", Flags.FLOAT, 0x0);
					gg.refineNumber("999", Flags.FLOAT, 0x0);
					gg.refineNumber("999", Flags.FLOAT, 0x0);
					gg.getResults(Flags.FLOAT);
					gg.editAll("2.25", Flags.FLOAT, 0x0);
					gg.clearResults();
					Toast.makeText(context, " OFF", Toast.LENGTH_SHORT).show();
				}

			} else if (compoundButton == switch7) {
				bu7 = isChecked;
				if (isChecked) {
					FloatingMenu.F7();
					Toast.makeText(context, "Switch 7 ON", Toast.LENGTH_SHORT).show();
				} else {
					Toast.makeText(context, "Switch 7 OFF", Toast.LENGTH_SHORT).show();
				}
			}
		}}}
