#ifndef ANDROID_MOD_MENU_HOOK_H
#define ANDROID_MOD_MENU_HOOK_H
#include <src/Unity/Vector3.hpp>
#include <src/Unity/Quaternion.hpp>
#include <src/Unity/Vector2.hpp>
#include "Global.h"
using namespace std;



//bool (*IsSameTeam)(void *_this, void* p1, void* p2) = (bool(*)(void *, void*, void*))getRealOffset(Global.IsSameTeam);

//void* (*getPlayerByIndex)(void* match, uint8_t index) = (void*(*)(void *, uint8_t))getRealOffset(Global.Player_Index);

//bool (*AttackableEntity_GetIsDead)(void *attackableEntity) = (bool (*)(void *))getRealOffset(Global.AttackableEntity_GetIsDead);

//bool (*AttackableEntity_IsVisible)(void *attackableEntity) = (bool (*)(void *))getRealOffset(Global.AttackableEntity_IsVisible);





static monoString *U3DStr(const char *str) {
    monoString *(*String_CreateString)(void *_this, const char *str) = (monoString * (*)(void *, const char *))getRealOffset(0x1A3F1F0);
    return String_CreateString(NULL, str);
}

static monoString *FormatCount(int enemy, int bot) {
    char buf[128] = {0};
    sprintf(buf, "[Enimigos:%d Bots:%d]", enemy, bot);
    return U3DStr(buf);
}

static monoString *U3DStrFormat(float distance) {
    char buffer[128] = {0};
    sprintf(buffer, " [Metros: %.f ]", distance);
    return U3DStr(buffer);
}




static void spofNick(void *players) {
    void (*_spof_nick)(void *player, monoString *nick) = (void (*)(void *, monoString *))getRealOffset(0x1A3F1F0);
    _spof_nick(players, U3DStr("Black Modder"));
}

/*


static monoString* get_NickName(void *player) {
    monoString* (*_get_NickName)(void *players) = (monoString * (*)(void *))getRealOffset(Global.get_NickName);
    return _get_NickName(player);
}






/*

static bool get_IsSighting(void *player) {
    bool (*_get_IsSighting)(void *players) = (bool (*)(void *))getRealOffset(Global.get_IsSighting);
    return _get_IsSighting(player);
}


*/
















#endif
