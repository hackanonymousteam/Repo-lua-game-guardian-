#pragma once

#include <vector>
#include <string>
#include <cstdint>

namespace FloatScanner {

    struct ScanResult {
        uintptr_t address;
        float value;
    };

    std::vector<ScanResult> scanFloat(const char* libraryName, float value, bool useCache = false);
    std::vector<ScanResult> refineScan(const std::vector<ScanResult>& previousResults, float newValue);
    bool writeFloat(uintptr_t address, float newValue);
    float readFloat(uintptr_t address);

}
