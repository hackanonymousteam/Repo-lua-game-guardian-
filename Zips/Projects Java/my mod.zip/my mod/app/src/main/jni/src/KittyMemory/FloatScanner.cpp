#include "FloatScanner.h"
#include "KittyMemory.h"
#include "MemoryPatch.h"

#include <cstring>

namespace FloatScanner {

    std::vector<ScanResult> scanFloat(const char* libraryName, float value, bool useCache) {
        std::vector<ScanResult> results;

        KittyMemory::ProcMap map = KittyMemory::getLibraryMap(libraryName);
        if (!map.isValid())
            return results;

        uintptr_t start = reinterpret_cast<uintptr_t>(map.startAddr);
        uintptr_t end = reinterpret_cast<uintptr_t>(map.endAddr);

        for (uintptr_t addr = start; addr < end; addr += sizeof(float)) {
            float currentVal;
            KittyMemory::memRead(&currentVal, reinterpret_cast<void*>(addr), sizeof(float));
            if (currentVal == value) {
                ScanResult res;
                res.address = addr;
                res.value = currentVal;
                results.push_back(res);
            }
        }

        return results;
    }

    std::vector<ScanResult> refineScan(const std::vector<ScanResult>& previousResults, float newValue) {
        std::vector<ScanResult> refined;

        for (const auto& res : previousResults) {
            float currentVal;
            KittyMemory::memRead(&currentVal, reinterpret_cast<void*>(res.address), sizeof(float));
            if (currentVal == newValue) {
                ScanResult r = res;
                r.value = currentVal;
                refined.push_back(r);
            }
        }

        return refined;
    }

    bool writeFloat(uintptr_t address, float newValue) {
        
        MemoryPatch patch((void*)address, &newValue, sizeof(float));
        return patch.Modify();
    }

    float readFloat(uintptr_t address) {
        float value = 0;
        KittyMemory::memRead(&value, reinterpret_cast<void*>(address), sizeof(float));
        return value;
    }
}
