#include <src/Includes/Utils.h>
#include "Hook.h" 
#include "Includes/Logger.h"
#include "Includes/obfuscator.hpp"
#include <pthread.h>
#include <jni.h>
#include <src/Includes/Utils.h>
#if defined(__aarch64__) //Compile for arm64 lib only
#include <src/And64InlineHook/And64InlineHook.hpp>
#else //Compile for armv7 lib only. Do not worry about greyed out highlighting code, it still works
#include <src/Substrate/SubstrateHook.h>
#endif
#include "KittyMemory/MemoryPatch.h"
#include "KittyMemory/FloatScanner.h"

#define HOOK(offset, ptr, orig) MSHookFunction((void *)getRealOffset(offset), (void *)ptr, (void **)&orig)

extern "C" {

struct My_Patches {
    MemoryPatch func1;
    MemoryPatch func2;
    MemoryPatch func3;
	MemoryPatch func4;
	MemoryPatch func5;
	MemoryPatch func6;
	MemoryPatch func7;
    MemoryPatch func8;
    MemoryPatch func9;
    MemoryPatch func10;
} hexPatches;

bool isLibraryLoaded(const char *libName) {
    void *handle = dlopen(libName, RTLD_NOW);
    if (handle) {
        dlclose(handle);
        return true;
    }
    return false;
}

extern "C"
JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingMenu_F1(JNIEnv *env, jobject obj) {
    if (isLibraryLoaded("libunity.so")) {
        hexPatches.func1 = MemoryPatch("libunity.so", 0x38DE28, "\x00\x00\x80\xBF", 4);
        bool result = hexPatches.func1.Modify();
        if (result) {
            LOGI("Patch aplicado com sucesso!");
        } else {
            LOGI("Falha ao aplicar patch.");
        }
    } else {
        LOGI("libil2cpp.so não carregada.");
    }
}

extern "C"
JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingMenu_F1off(JNIEnv *env, jobject obj) {
    if (isLibraryLoaded("libunity.so")) {
        bool result = hexPatches.func1.Restore();
        if (result) {
            LOGI("Patch restaurado com sucesso!");
        } else {
            LOGI("Falha ao restaurar patch.");
        }
    } else {
        LOGI("libunity.so não carregada.");
    }
}


JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingMenu_F2(JNIEnv *env, jobject obj) {
    if (isLibraryLoaded("libunity.so")) {
        hexPatches.func2 = MemoryPatch("libunity.so", 0xA81D9C, "\x00\x00\x80\xBF", 4);
        bool result = hexPatches.func2.Modify();
        if (result) {
            LOGI("Patch aplicado com sucesso!");
        } else {
            LOGI("Falha ao aplicar patch.");
        }
    } else {
        LOGI("libunity.so não carregada.");
    }
}

JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingMenu_F2off(JNIEnv *env, jobject obj) {
    if (isLibraryLoaded("libunity.so")) {
        bool result = hexPatches.func2.Restore();
        if (result) {
            LOGI("Patch aplicado com sucesso!");
        } else {
            LOGI("Falha ao aplicar patch.");
        }
    } else {
        LOGI("libunity.so não carregada.");
    }
}

JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingMenu_F3(JNIEnv *env, jobject obj) {
    if (isLibraryLoaded("libunity.so")) {
        hexPatches.func3 = MemoryPatch("libunity.so", 0x3DBF44, "\x00\x00\x96\x43", 4);
        bool result = hexPatches.func3.Modify();
        if (result) {
            LOGI("Patch aplicado com sucesso!");
        } else {
            LOGI("Falha ao aplicar patch.");
        }
    } else {
        LOGI("libunity.so não carregada.");
    }
}

JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingMenu_F3off(JNIEnv *env, jobject obj) {
    if (isLibraryLoaded("libunity.so")) {
       // hexPatches.func3 = MemoryPatch("libunity.so", 0x3DBF44, "\x00\x00\x96\x43", 4);
        bool result = hexPatches.func3.Restore();
        if (result) {
            LOGI("Patch aplicado com sucesso!");
        } else {
            LOGI("Falha ao aplicar patch.");
        }
    } else {
        LOGI("libunity.so não carregada.");
    }
}

JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingMenu_F4(JNIEnv *env, jobject obj) {
    if (isLibraryLoaded("libunity.so")) {
        hexPatches.func4 = MemoryPatch("libunity.so", 0x1D54AC, "\x00\x00\x48\x42", 4);
        bool result = hexPatches.func4.Modify();
        if (result) {
            LOGI("Patch aplicado com sucesso!");
        } else {
            LOGI("Falha ao aplicar patch.");
        }
    } else {
        LOGI("libunity.so não carregada.");
    }
}

JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingMenu_F4off(JNIEnv *env, jobject obj) {
    if (isLibraryLoaded("libunity.so")) {
       // hexPatches.func4 = MemoryPatch("libunity.so", 0x1D54AC, "\x00\x00\x48\x42", 4);
        bool result = hexPatches.func4.Restore();
        if (result) {
            LOGI("Patch aplicado com sucesso!");
        } else {
            LOGI("Falha ao aplicar patch.");
        }
    } else {
        LOGI("libunity.so não carregada.");
    }
}


JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingMenu_F5(JNIEnv *env, jobject obj) {
    if (isLibraryLoaded("libunity.so")) {
        hexPatches.func5 = MemoryPatch("libunity.so", 0xA6EA60, "\x00\x00\x00\x00", 4);
        bool result = hexPatches.func5.Modify();
        if (result) {
            LOGI("Patch aplicado com sucesso!");
        } else {
            LOGI("Falha ao aplicar patch.");
        }
    } else {
        LOGI("libunity.so não carregada.");
    }
}

JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingMenu_F5off(JNIEnv *env, jobject obj) {
    if (isLibraryLoaded("libunity.so")) {
      //  hexPatches.func5 = MemoryPatch("libunity.so", 0xA6EA60, "\x00\x00\x00\x00", 4);
        bool result = hexPatches.func5.Restore();
        if (result) {
            LOGI("Patch aplicado com sucesso!");
        } else {
            LOGI("Falha ao aplicar patch.");
        }
    } else {
        LOGI("libunity.so não carregada.");
    }
}

extern "C"
JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingMenu_F7(JNIEnv *env, jobject obj) {
    if (isLibraryLoaded("libunity.so")) {
		auto results = FloatScanner::scanFloat("libunity.so", 1.0f);
    results = FloatScanner::refineScan(results, 1.0f);
    if (!results.empty()) {
        FloatScanner::writeFloat(results[0].address, 9.0f);
    }
		
    } else {
        LOGI("libunity.so não carregada.");
    }
}


void *hack_thread(void *) {
    LOGI("Loading...");

    ProcMap il2cppMap;
    do {
        il2cppMap = KittyMemory::getLibraryMap("libunity.so");
        sleep(1);
    } while (!il2cppMap.isValid());
return NULL;
} 

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
    return JNI_VERSION_1_6;
}
}
