package com.floatingMenu.activities;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;
import com.floatingMenu.R;
import java.util.Map;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
     //   setContentView(R.layout.activity_main);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
                return;
            }
        }

        showModMenu();
    }

    private void showModMenu() {
        FloatingModMenu.showModMenu(this, new FloatingModMenu.MenuCallback() {
				@Override
				public void onMenuResult(Map<String, Boolean> checkboxStates, 
										 Map<String, Float> sliderValues, 
										 String selectedItems, 
										 String[] originalItems) {

					if (originalItems == null) return;

					for (int i = 0; i < originalItems.length; i++) {
						String itemName = originalItems[i];
						String itemKey = "item_" + i;

						boolean isActive = checkboxStates.containsKey(itemKey) && checkboxStates.get(itemKey);

						if (isActive) {
							if (itemName.equals("Aimbot")) {
								try {
									/*String originalValue = "gg.alert('by batman')";
									String param1 = originalValue;
									int param2 = 0;
									String param3 = "";

									android.ext.Script script = new android.ext.Script(param1, param2, param3);
									android.ext.Script result = script.c_();
*/
									Toast.makeText(MainActivity.this, "AIMBOT ACTIVATED", Toast.LENGTH_SHORT).show();
								} catch (Exception e) {
									e.printStackTrace();
								}
							} else if (itemName.equals("speed")) {
								Toast.makeText(MainActivity.this, "SPEED ACTIVATED", Toast.LENGTH_SHORT).show();
							} else if (itemName.equals("fly hack")) {
								Toast.makeText(MainActivity.this, "FLY HACK ACTIVATED", Toast.LENGTH_SHORT).show();
							} else if (itemName.equals("god mode")) {
								Toast.makeText(MainActivity.this, "GOD MODE ACTIVATED", Toast.LENGTH_SHORT).show();
							} else if (itemName.equals("bypass")) {
								Toast.makeText(MainActivity.this, "BYPASS ACTIVATED", Toast.LENGTH_SHORT).show();
							}
						}
					}
				}
			}, "Aimbot", "speed", "fly hack", "god mode", "bypass");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Settings.canDrawOverlays(this) && !FloatingModMenu.isVisible()) {
                showModMenu();
            }
        }
    }
}
