package com.floatingMenu.activities;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class FloatingModMenu {

    public interface MenuCallback {
        void onMenuResult(Map<String, Boolean> checkboxStates, Map<String, Float> sliderValues, 
                          String selectedItems, String[] originalItems);
    }

    private static View floatingIconView;
    private static View floatingMenuView;
    private static WindowManager windowManager;
    private static WebView webView;
    private static WindowManager.LayoutParams iconParams;
    private static WindowManager.LayoutParams menuParams;
    private static boolean isMenuVisible = false;
    private static Handler handler = new Handler();
    private static Map<String, Boolean> menuState = new ConcurrentHashMap<>();
    private static Map<String, Float> sliderValues = new ConcurrentHashMap<>();
    private static MenuCallback callback;
    private static boolean isWaitingForResult = false;
    private static String[] originalItemsArray;

    private static final int ICON_SIZE = 80;
    private static final int MENU_WIDTH = 600;
    private static final int MENU_HEIGHT = 375;

    public class JavaScriptInterface {
        @JavascriptInterface
        public void closeMenu() {
            hideMenu();
        }

		@JavascriptInterface
		public void confirmSelection() {
			handler.post(new Runnable() {
					@Override
					public void run() {
						hideMenu();
						if (callback != null && originalItemsArray != null) {
							Map<String, Boolean> statesCopy = new HashMap<>(menuState);
							Map<String, Float> slidersCopy = new HashMap<>(sliderValues);
							String selectedItems = generateSelectedItemsString();
							callback.onMenuResult(statesCopy, slidersCopy, selectedItems, originalItemsArray);
						}
					}
				});
		}
        @JavascriptInterface
        public void toggleFunction(String functionId, boolean enabled) {
            menuState.put(functionId, enabled);
        }

        @JavascriptInterface
        public void updateSlider(String sliderId, float value) {
            sliderValues.put(sliderId, value);
        }

        @JavascriptInterface
        public String getCurrentMenuState() {
            StringBuilder stateJson = new StringBuilder("{");
            boolean first = true;
            for (Map.Entry<String, Boolean> entry : menuState.entrySet()) {
                if (!first) stateJson.append(",");
                stateJson.append("\"").append(entry.getKey()).append("\":").append(entry.getValue());
                first = false;
            }
            stateJson.append("}");
            return stateJson.toString();
        }
    }

    private static class IconView extends View {
        private Paint paint;
        private Path trianglePath;
        private boolean isPressed = false;

        public IconView(Context context) {
            super(context);
            init();
        }

        private void init() {
            paint = new Paint();
            paint.setAntiAlias(true);
            trianglePath = new Path();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            paint.setColor(isPressed ? Color.parseColor("#FF8C00") : Color.parseColor("#FFA500"));
            paint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(getWidth() / 2, getHeight() / 2, getWidth() / 2 - 5, paint);

            paint.setColor(Color.WHITE);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(3);
            canvas.drawCircle(getWidth() / 2, getHeight() / 2, getWidth() / 2 - 5, paint);

            int centerX = getWidth() / 2;
            int centerY = getHeight() / 2;
            int triangleSize = getWidth() / 4;

            trianglePath.reset();
            trianglePath.moveTo(centerX - triangleSize, centerY - triangleSize / 2);
            trianglePath.lineTo(centerX + triangleSize, centerY - triangleSize / 2);
            trianglePath.lineTo(centerX, centerY + triangleSize);
            trianglePath.close();

            paint.setColor(Color.WHITE);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawPath(trianglePath, paint);
        }

        public void setPressedState(boolean pressed) {
            isPressed = pressed;
            invalidate();
        }
    }

    public static void showModMenu(final Context context, final MenuCallback menuCallback, String... items) {
        callback = menuCallback;
        isWaitingForResult = true;
        originalItemsArray = items;

        if (menuState.isEmpty()) {
            for (int i = 0; i < items.length; i++) {
                menuState.put("item_" + i, false);
            }
        }

        createFloatingIcon(context);
        setupMenu(context, items);
    }

    private static void createFloatingIcon(Context context) {
        if (floatingIconView != null) return;

        windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);

        iconParams = new WindowManager.LayoutParams(
            ICON_SIZE,
            ICON_SIZE,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        );

        iconParams.gravity = Gravity.TOP | Gravity.START;
        iconParams.x = 50;
        iconParams.y = 100;

        final IconView iconView = new IconView(context);
        iconView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					toggleMenu();
				}
			});

        iconView.setOnTouchListener(new View.OnTouchListener() {
				private float initialX, initialY;
				private int initialTouchX, initialTouchY;
				private boolean isDragging = false;
				private boolean isLongPress = false;
				private Handler longPressHandler = new Handler();
				private Runnable longPressRunnable = new Runnable() {
					@Override
					public void run() {
						isLongPress = true;
						iconView.setPressedState(true);
						closeAll();
						if (callback != null) {
							callback.onMenuResult(new HashMap<String, Boolean>(), 
												  new HashMap<String, Float>(), 
												  "CANCELLED", 
												  new String[0]);
						}
						isWaitingForResult = false;
						originalItemsArray = null;
					}
				};

				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
						case MotionEvent.ACTION_DOWN:
							initialX = iconParams.x;
							initialY = iconParams.y;
							initialTouchX = (int) event.getRawX();
							initialTouchY = (int) event.getRawY();
							isDragging = false;
							isLongPress = false;

							longPressHandler.postDelayed(longPressRunnable, 1000);
							iconView.setPressedState(true);
							return true;

						case MotionEvent.ACTION_MOVE:
							int dx = (int) event.getRawX() - initialTouchX;
							int dy = (int) event.getRawY() - initialTouchY;

							if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
								longPressHandler.removeCallbacks(longPressRunnable);
								isLongPress = false;

								isDragging = true;
								iconParams.x = (int) (initialX + dx);
								iconParams.y = (int) (initialY + dy);
								updateIconLayout();

								if (isMenuVisible && menuParams != null) {
									menuParams.x = iconParams.x;
									menuParams.y = iconParams.y + ICON_SIZE + 10;
									updateMenuLayout();
								}
								return true;
							}
							return true;

						case MotionEvent.ACTION_UP:
							longPressHandler.removeCallbacks(longPressRunnable);
							iconView.setPressedState(false);

							if (isLongPress) {
								return true;
							}

							if (isDragging) {
								return true;
							}

							v.performClick();
							return true;

						case MotionEvent.ACTION_CANCEL:
							longPressHandler.removeCallbacks(longPressRunnable);
							iconView.setPressedState(false);
							break;
					}
					return false;
				}
			});

        floatingIconView = iconView;
        windowManager.addView(floatingIconView, iconParams);
    }

    private static void setupMenu(Context context, final String... items) {
        menuParams = new WindowManager.LayoutParams(
            MENU_WIDTH,
            MENU_HEIGHT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        );

        menuParams.gravity = Gravity.TOP | Gravity.START;
        menuParams.x = iconParams.x;
        menuParams.y = iconParams.y + ICON_SIZE + 10;

        FrameLayout menuLayout = new FrameLayout(context);
        menuLayout.setBackgroundColor(Color.TRANSPARENT);

        webView = new WebView(context);
        webView.setLayoutParams(new FrameLayout.LayoutParams(
                                    FrameLayout.LayoutParams.MATCH_PARENT,
                                    FrameLayout.LayoutParams.MATCH_PARENT
                                ));

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setSupportZoom(false);
        webSettings.setBuiltInZoomControls(false);
        webSettings.setDisplayZoomControls(false);
        webSettings.setDefaultFontSize(12);

        webView.addJavascriptInterface(new FloatingModMenu().new JavaScriptInterface(), "Android");

        webView.setWebViewClient(new WebViewClient() {
				@Override
				public void onPageFinished(WebView view, String url) {
					injectMenuItems(items);
				}
			});

        String htmlContent = getHTMLContent();
        webView.loadDataWithBaseURL(null, htmlContent, "text/html", "UTF-8", null);

        webView.setBackgroundColor(Color.TRANSPARENT);
        menuLayout.addView(webView);
        floatingMenuView = menuLayout;
    }

    private static void toggleMenu() {
        handler.post(new Runnable() {
				@Override
				public void run() {
					if (isMenuVisible) {
						hideMenu();
					} else {
						showMenu();
					}
				}
			});
    }

    private static void showMenu() {
        if (floatingMenuView != null && !isMenuVisible && windowManager != null) {
            menuParams.x = iconParams.x;
            menuParams.y = iconParams.y + ICON_SIZE + 10;

            windowManager.addView(floatingMenuView, menuParams);
            isMenuVisible = true;

            webView.loadUrl("javascript:showMenuPanel()");
            injectMenuItems(originalItemsArray);
        }
    }

    private static void hideMenu() {
        if (floatingMenuView != null && isMenuVisible && windowManager != null) {
            windowManager.removeView(floatingMenuView);
            isMenuVisible = false;
        }
    }

    private static void injectMenuItems(String... items) {
        if (items == null || items.length == 0) return;

        try {
            StringBuilder itemsJson = new StringBuilder("[");
            for (int i = 0; i < items.length; i++) {
                if (i > 0) itemsJson.append(",");
                itemsJson.append("\"").append(escapeJS(items[i])).append("\"");
            }
            itemsJson.append("]");

            String jsCode = String.format(
                "window.menuItems = %s; window.currentMenuState = %s; initializeDynamicMenu();",
                itemsJson.toString(),
                "Android.getCurrentMenuState()"
            );
            webView.loadUrl("javascript:" + jsCode);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String escapeJS(String str) {
        return str.replace("'", "\\'")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r");
    }

    private static String generateSelectedItemsString() {
        if (originalItemsArray == null || originalItemsArray.length == 0) {
            return "NO_ITEMS_SELECTED";
        }

        StringBuilder result = new StringBuilder();
        boolean hasSelected = false;

        for (int i = 0; i < originalItemsArray.length; i++) {
            String itemKey = "item_" + i;
            boolean isSelected = menuState.containsKey(itemKey) && menuState.get(itemKey);

            if (isSelected) {
                if (hasSelected) {
                    result.append(",");
                }

                result.append(originalItemsArray[i]).append(":").append("ON");
                hasSelected = true;
            }
        }

        if (!sliderValues.isEmpty()) {
            if (hasSelected) {
                result.append(" | ");
            }
            result.append("SLIDERS:");
            boolean firstSlider = true;
            for (Map.Entry<String, Float> entry : sliderValues.entrySet()) {
                if (!firstSlider) result.append(",");
                result.append(entry.getKey()).append("=").append(entry.getValue());
                firstSlider = false;
            }
        }

        return result.length() > 0 ? result.toString() : "ALL_DISABLED";
    }

    private static void updateIconLayout() {
        if (windowManager != null && floatingIconView != null) {
            windowManager.updateViewLayout(floatingIconView, iconParams);
        }
    }

    private static void updateMenuLayout() {
        if (windowManager != null && floatingMenuView != null && isMenuVisible) {
            windowManager.updateViewLayout(floatingMenuView, menuParams);
        }
    }

    private static String getHTMLContent() {
        return "<!DOCTYPE html>\n" +
            "<html lang=\"en\">\n" +
            "<head>\n" +
            "  <meta charset=\"UTF-8\">\n" +
            "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, user-scalable=no\">\n" +
            "  <title>Mod Menu</title>\n" +
            "  <style>\n" +
            "  :root {\n" +
            "    --primary-color: rgb(255, 165 ,0);\n" +
            "    --dark-color: rgb(230, 135, 0);\n" +
            "  }\n" +
            "  * {\n" +
            "    margin: 0;\n" +
            "    padding: 0;\n" +
            "    box-sizing: border-box;\n" +
            "  }\n" +
            "  html, body {\n" +
            "    width: 100%;\n" +
            "    height: 100%;\n" +
            "    background: transparent !important;\n" +
            "    overflow: hidden;\n" +
            "  }\n" +
            "  body {\n" +
            "    color: white;\n" +
            "    background: black;\n" +
            "    font-family: monospace;\n" +
            "    user-select: none;\n" +
            "  }\n" +
            "  .menu-panel {\n" +
            "    z-index: 499;\n" +
            "    border: 1px solid var(--primary-color);\n" +
            "    border-radius: 0.7em;\n" +
            "    box-shadow: 0 0 7px var(--primary-color);\n" +
            "    position: absolute;\n" +
            "    left: 0; top: 0;\n" +
            "    background: black;\n" +
            "    display: none;\n" +
            "    font-family: monospace;\n" +
            "    width: 100%;\n" +
            "    height: 100%;\n" +
            "    overflow: hidden;\n" +
            "  }\n" +
            "  .menu-header {\n" +
            "    display: flex;\n" +
            "    align-items: center;\n" +
            "    padding: 10px;\n" +
            "    border-bottom: 1px solid var(--primary-color);\n" +
            "    justify-content: space-between;\n" +
            "  }\n" +
            "  .menu-content {\n" +
            "    padding: 15px;\n" +
            "    height: calc(100% - 120px);\n" +
            "    overflow-y: auto;\n" +
            "  }\n" +
            "  .menu-footer {\n" +
            "    padding: 10px;\n" +
            "    border-top: 1px solid var(--primary-color);\n" +
            "    display: flex;\n" +
            "    justify-content: flex-end;\n" +
            "    gap: 10px;\n" +
            "  }\n" +
            "  .action-btn {\n" +
            "    padding: 8px 20px;\n" +
            "    border: 1px solid var(--primary-color);\n" +
            "    background: rgba(255, 165, 0, 0.1);\n" +
            "    color: var(--primary-color);\n" +
            "    border-radius: 5px;\n" +
            "    cursor: pointer;\n" +
            "    font-family: monospace;\n" +
            "    font-size: 14px;\n" +
            "  }\n" +
            "  .action-btn:hover {\n" +
            "    background: rgba(255, 165, 0, 0.3);\n" +
            "  }\n" +
            "  .tabs {\n" +
            "    display: flex;\n" +
            "    border-bottom: 1px solid var(--primary-color);\n" +
            "  }\n" +
            "  .tab {\n" +
            "    padding: 8px 15px;\n" +
            "    cursor: pointer;\n" +
            "    border: 1px solid transparent;\n" +
            "    border-bottom: none;\n" +
            "  }\n" +
            "  .tab.active {\n" +
            "    color: var(--primary-color);\n" +
            "    border: 1px solid var(--primary-color);\n" +
            "    border-bottom: 1px solid black;\n" +
            "    background: rgba(255, 165, 0, 0.1);\n" +
            "  }\n" +
            "  .tab-content {\n" +
            "    display: none;\n" +
            "    padding: 15px 0;\n" +
            "  }\n" +
            "  .tab-content.active {\n" +
            "    display: block;\n" +
            "  }\n" +
            "  .menu-item {\n" +
            "    display: flex;\n" +
            "    align-items: center;\n" +
            "    margin: 10px 0;\n" +
            "    padding: 8px;\n" +
            "    border: 1px solid var(--primary-color);\n" +
            "    border-radius: 5px;\n" +
            "    background: rgba(255, 165, 0, 0.05);\n" +
            "  }\n" +
            "  .checkbox {\n" +
            "    width: 20px;\n" +
            "    height: 20px;\n" +
            "    display: flex;\n" +
            "    justify-content: center;\n" +
            "    align-items: center;\n" +
            "    color: var(--primary-color);\n" +
            "    border: 1px solid var(--primary-color);\n" +
            "    border-radius: 3px;\n" +
            "    cursor: pointer;\n" +
            "    margin-right: 10px;\n" +
            "    font-size: 12px;\n" +
            "  }\n" +
            "  .item-label {\n" +
            "    color: var(--primary-color);\n" +
            "    font-size: 14px;\n" +
            "    flex-grow: 1;\n" +
            "  }\n" +
            "  .slider-container {\n" +
            "    display: flex;\n" +
            "    align-items: center;\n" +
            "    margin: 10px 0;\n" +
            "  }\n" +
            "  .slider-label {\n" +
            "    color: var(--primary-color);\n" +
            "    width: 100px;\n" +
            "    font-size: 14px;\n" +
            "  }\n" +
            "  .slider-value {\n" +
            "    color: var(--primary-color);\n" +
            "    width: 50px;\n" +
            "    text-align: right;\n" +
            "    font-size: 14px;\n" +
            "  }\n" +
            "  input[type=\"range\"] {\n" +
            "    -webkit-appearance: none;\n" +
            "    width: 200px;\n" +
            "    height: 8px;\n" +
            "    background: transparent;\n" +
            "    border: 1px solid var(--primary-color);\n" +
            "    border-radius: 4px;\n" +
            "    margin: 0 10px;\n" +
            "  }\n" +
            "  input[type=\"range\"]::-webkit-slider-runnable-track {\n" +
            "    height: 4px;\n" +
            "    background: linear-gradient(to right, #000, var(--dark-color));\n" +
            "    border-radius: 4em;\n" +
            "  }\n" +
            "  input[type=\"range\"]::-webkit-slider-thumb {\n" +
            "    -webkit-appearance: none;\n" +
            "    width: 18px;\n" +
            "    height: 18px;\n" +
            "    background: var(--primary-color);\n" +
            "    border-radius: 50%;\n" +
            "    margin-top: -7px;\n" +
            "  }\n" +
            "  </style>\n" +
            "</head>\n" +
            "<body>\n" +
            "  <div class=\"menu-panel\" id=\"menuPanel\">\n" +
            "    <div class=\"menu-header\">\n" +
            "      <span style=\"color: var(--primary-color); font-size: 18px; font-weight: bold;\">MOD MENU</span>\n" +
            "      <span style=\"color: #888; font-size: 12px;\">by Batman Games</span>\n" +
            "    </div>\n" +
            "    <div class=\"tabs\" id=\"tabs\">\n" +
            "      <div class=\"tab active\" data-tab=\"styles\">Styles</div>\n" +
            "      <div class=\"tab\" data-tab=\"player\">Player</div>\n" +
            "    </div>\n" +
            "    <div class=\"menu-content\">\n" +
            "      <div class=\"tab-content active\" id=\"tab-styles\">\n" +
            "        <div class=\"slider-container\">\n" +
            "          <span class=\"slider-label\">Opacity:</span>\n" +
            "          <input type=\"range\" min=\"0\" max=\"10\" value=\"10\" class=\"opacity-slider\">\n" +
            "          <span class=\"slider-value\" id=\"opacity-value\">1.0</span>\n" +
            "        </div>\n" +
            "        <div class=\"slider-container\">\n" +
            "          <span class=\"slider-label\">R:</span>\n" +
            "          <input type=\"range\" min=\"0\" max=\"255\" value=\"255\" class=\"color-slider R\">\n" +
            "          <span class=\"slider-value\" id=\"r-value\">255</span>\n" +
            "        </div>\n" +
            "        <div class=\"slider-container\">\n" +
            "          <span class=\"slider-label\">G:</span>\n" +
            "          <input type=\"range\" min=\"0\" max=\"255\" value=\"165\" class=\"color-slider G\">\n" +
            "          <span class=\"slider-value\" id=\"g-value\">165</span>\n" +
            "        </div>\n" +
            "        <div class=\"slider-container\">\n" +
            "          <span class=\"slider-label\">B:</span>\n" +
            "          <input type=\"range\" min=\"0\" max=\"255\" value=\"0\" class=\"color-slider B\">\n" +
            "          <span class=\"slider-value\" id=\"b-value\">0</span>\n" +
            "        </div>\n" +
            "      </div>\n" +
            "      <div class=\"tab-content\" id=\"tab-player\">\n" +
            "        <div id=\"player-items\"></div>\n" +
            "      </div>\n" +
            "    </div>\n" +
            "    <div class=\"menu-footer\">\n" +
            "      <button class=\"action-btn\" id=\"confirmBtn\">OK</button>\n" +
            "    </div>\n" +
            "  </div>\n" +
            "\n" +
            "  <script>\n" +
            "  var menuPanel = document.getElementById('menuPanel');\n" +
            "  var playerItemsContainer = document.getElementById('player-items');\n" +
            "  \n" +
            "  function showMenuPanel() {\n" +
            "    menuPanel.style.display = 'block';\n" +
            "    initializeMenu();\n" +
            "  }\n" +
            "  \n" +
            "  function initializeMenu() {\n" +
            "    document.getElementById('confirmBtn').addEventListener('click', function() {\n" +
            "      Android.confirmSelection();\n" +
            "    });\n" +
            "    \n" +
            "    var tabs = document.querySelectorAll('.tab');\n" +
            "    for (var i = 0; i < tabs.length; i++) {\n" +
            "      tabs[i].addEventListener('click', function() {\n" +
            "        var tabName = this.getAttribute('data-tab');\n" +
            "        switchTab(tabName);\n" +
            "      });\n" +
            "    }\n" +
            "    \n" +
            "    setupStyleSliders();\n" +
            "  }\n" +
            "  \n" +
            "  function switchTab(tabName) {\n" +
            "    var tabs = document.querySelectorAll('.tab');\n" +
            "    for (var i = 0; i < tabs.length; i++) {\n" +
            "      tabs[i].classList.remove('active');\n" +
            "    }\n" +
            "    \n" +
            "    var activeTab = document.querySelector('.tab[data-tab=\"' + tabName + '\"]');\n" +
            "    if (activeTab) activeTab.classList.add('active');\n" +
            "    \n" +
            "    var contents = document.querySelectorAll('.tab-content');\n" +
            "    for (var i = 0; i < contents.length; i++) {\n" +
            "      contents[i].classList.remove('active');\n" +
            "    }\n" +
            "    \n" +
            "    var activeContent = document.getElementById('tab-' + tabName);\n" +
            "    if (activeContent) activeContent.classList.add('active');\n" +
            "  }\n" +
            "  \n" +
            "  function setupStyleSliders() {\n" +
            "    var opacitySlider = document.querySelector('.opacity-slider');\n" +
            "    var opacityValue = document.getElementById('opacity-value');\n" +
            "    if (opacitySlider) {\n" +
            "      opacitySlider.addEventListener('input', function() {\n" +
            "        var value = this.value;\n" +
            "        var opacity = value > 9 ? '1.0' : '0.' + value;\n" +
            "        opacityValue.textContent = opacity;\n" +
            "        menuPanel.style.opacity = opacity;\n" +
            "      });\n" +
            "    }\n" +
            "    \n" +
            "    var colorSliders = document.querySelectorAll('.color-slider');\n" +
            "    var rValue = document.getElementById('r-value');\n" +
            "    var gValue = document.getElementById('g-value');\n" +
            "    var bValue = document.getElementById('b-value');\n" +
            "    \n" +
            "    function updateColors() {\n" +
            "      var r = document.querySelector('.R').value;\n" +
            "      var g = document.querySelector('.G').value;\n" +
            "      var b = document.querySelector('.B').value;\n" +
            "      \n" +
            "      rValue.textContent = r;\n" +
            "      gValue.textContent = g;\n" +
            "      bValue.textContent = b;\n" +
            "      \n" +
            "      document.documentElement.style.setProperty('--primary-color', 'rgb(' + r + ', ' + g + ', ' + b + ')');\n" +
            "      \n" +
            "      var darkR = Math.max(0, r - 100);\n" +
            "      var darkG = Math.max(0, g - 100);\n" +
            "      var darkB = Math.max(0, b - 100);\n" +
            "      document.documentElement.style.setProperty('--dark-color', 'rgb(' + darkR + ', ' + darkG + ', ' + darkB + ')');\n" +
            "    }\n" +
            "    \n" +
            "    for (var i = 0; i < colorSliders.length; i++) {\n" +
            "      colorSliders[i].addEventListener('input', updateColors);\n" +
            "    }\n" +
            "  }\n" +
            "  \n" +
            "  function initializeDynamicMenu() {\n" +
            "    if (!window.menuItems || !Array.isArray(window.menuItems)) return;\n" +
            "    \n" +
            "    playerItemsContainer.innerHTML = '';\n" +
            "    \n" +
            "    var currentState = {};\n" +
            "    if (window.currentMenuState) {\n" +
            "      try {\n" +
            "        currentState = JSON.parse(window.currentMenuState);\n" +
            "      } catch(e) {\n" +
            "        console.log('Error parsing menu state:', e);\n" +
            "      }\n" +
            "    }\n" +
            "    \n" +
            "    for (var i = 0; i < window.menuItems.length; i++) {\n" +
            "      var itemName = window.menuItems[i];\n" +
            "      var itemId = 'item_' + i;\n" +
            "      \n" +
            "      var itemDiv = document.createElement('div');\n" +
            "      itemDiv.className = 'menu-item';\n" +
            "      \n" +
            "      var checkbox = document.createElement('div');\n" +
            "      checkbox.className = 'checkbox';\n" +
            "      checkbox.setAttribute('data-id', itemId);\n" +
            "      \n" +
            "      var label = document.createElement('span');\n" +
            "      label.className = 'item-label';\n" +
            "      label.textContent = itemName;\n" +
            "      \n" +
            "      itemDiv.appendChild(checkbox);\n" +
            "      itemDiv.appendChild(label);\n" +
            "      playerItemsContainer.appendChild(itemDiv);\n" +
            "      \n" +
            "      (function(checkbox, itemId) {\n" +
            "        var isChecked = currentState[itemId] || false;\n" +
            "        checkbox.textContent = isChecked ? '✅' : '❌';\n" +
            "        \n" +
            "        checkbox.addEventListener('click', function() {\n" +
            "          isChecked = !isChecked;\n" +
            "          this.textContent = isChecked ? '✅' : '❌';\n" +
            "          Android.toggleFunction(itemId, isChecked);\n" +
            "        });\n" +
            "      })(checkbox, itemId);\n" +
            "    }\n" +
            "  }\n" +
            "  </script>\n" +
            "</body>\n" +
            "</html>";
    }

    public static void closeAll() {
        hideMenu();

        if (floatingIconView != null && windowManager != null) {
            try {
                windowManager.removeView(floatingIconView);
                floatingIconView = null;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (floatingMenuView != null && windowManager != null) {
            try {
                windowManager.removeView(floatingMenuView);
                floatingMenuView = null;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        webView = null;
        windowManager = null;
        isMenuVisible = false;
        originalItemsArray = null;
        callback = null;
        isWaitingForResult = false;

        menuState.clear();
        sliderValues.clear();
    }

    public static boolean isVisible() {
        return floatingIconView != null;
    }

    public static boolean isMenuOpen() {
        return isMenuVisible;
    }

    public static boolean isWaitingForResult() {
        return isWaitingForResult;
    }
}
