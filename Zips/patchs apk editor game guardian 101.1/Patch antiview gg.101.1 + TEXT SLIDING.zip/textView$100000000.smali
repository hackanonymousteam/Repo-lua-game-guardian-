.class Landroid/app/textView$100000000;
.super Ljava/lang/Object;
.source "TextView.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/app/textView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# instance fields
.field private final this$0:Landroid/app/textView;


# direct methods
.method constructor <init>(Landroid/app/textView;)V
    .registers 7

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Landroid/app/textView$100000000;->this$0:Landroid/app/textView;

    return-void
.end method

.method static access$0(Landroid/app/textView$100000000;)Landroid/app/textView;
    .registers 5

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Landroid/app/textView$100000000;->this$0:Landroid/app/textView;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 33
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Landroid/app/textView$100000000;->this$0:Landroid/app/textView;

    invoke-virtual {v2}, Landroid/app/textView;->anu()V

    .line 34
    move-object v2, v0

    iget-object v2, v2, Landroid/app/textView$100000000;->this$0:Landroid/app/textView;

    move-object v3, v0

    const/16 v4, 0x2710

    int-to-long v4, v4

    invoke-virtual {v2, v3, v4, v5}, Landroid/app/textView;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v2

    return-void
.end method
