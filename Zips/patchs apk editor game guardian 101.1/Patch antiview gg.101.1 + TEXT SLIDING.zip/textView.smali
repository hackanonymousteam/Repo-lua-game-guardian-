.class public Landroid/app/textView;
.super Landroid/widget/TextView;
.source "TextView.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/app/textView$100000001;,
        Landroid/app/textView$100000000;
    }
.end annotation


# instance fields
.field private abdul_delay:J

.field private abdul_index:I

.field private abdul_text:Ljava/lang/CharSequence;

.field private characterAdder:Ljava/lang/Runnable;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 10

    .prologue
    .line 18
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    move-object v4, v1

    invoke-direct {v3, v4}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v3, v0

    const/16 v4, 0x1f4

    int-to-long v4, v4

    iput-wide v4, v3, Landroid/app/textView;->abdul_delay:J

    move-object v3, v0

    new-instance v4, Landroid/app/textView$100000001;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    move-object v6, v0

    invoke-direct {v5, v6}, Landroid/app/textView$100000001;-><init>(Landroid/app/textView;)V

    iput-object v4, v3, Landroid/app/textView;->characterAdder:Ljava/lang/Runnable;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 12

    .prologue
    .line 23
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    move-object v5, v1

    move-object v6, v2

    invoke-direct {v4, v5, v6}, Landroid/widget/TextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    move-object v4, v0

    const/16 v5, 0x1f4

    int-to-long v5, v5

    iput-wide v5, v4, Landroid/app/textView;->abdul_delay:J

    move-object v4, v0

    new-instance v5, Landroid/app/textView$100000001;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    move-object v7, v0

    invoke-direct {v6, v7}, Landroid/app/textView$100000001;-><init>(Landroid/app/textView;)V

    iput-object v5, v4, Landroid/app/textView;->characterAdder:Ljava/lang/Runnable;

    .line 25
    move-object v4, v0

    invoke-virtual {v4}, Landroid/app/textView;->star()V

    return-void
.end method

.method static synthetic access$L1000000(Landroid/app/textView;)Ljava/lang/CharSequence;
    .registers 5

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Landroid/app/textView;->abdul_text:Ljava/lang/CharSequence;

    move-object v0, v3

    return-object v0
.end method

.method static synthetic access$L1000001(Landroid/app/textView;)I
    .registers 5

    move-object v0, p0

    move-object v3, v0

    iget v3, v3, Landroid/app/textView;->abdul_index:I

    move v0, v3

    return v0
.end method

.method static synthetic access$L1000002(Landroid/app/textView;)J
    .registers 6

    move-object v0, p0

    move-object v3, v0

    iget-wide v3, v3, Landroid/app/textView;->abdul_delay:J

    move-wide v0, v3

    return-wide v0
.end method

.method static synthetic access$S1000000(Landroid/app/textView;Ljava/lang/CharSequence;)V
    .registers 8

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Landroid/app/textView;->abdul_text:Ljava/lang/CharSequence;

    return-void
.end method

.method static synthetic access$S1000001(Landroid/app/textView;I)V
    .registers 8

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    iput v5, v4, Landroid/app/textView;->abdul_index:I

    return-void
.end method

.method static synthetic access$S1000002(Landroid/app/textView;J)V
    .registers 11

    move-object v0, p0

    move-wide v1, p1

    move-object v5, v0

    move-wide v6, v1

    iput-wide v6, v5, Landroid/app/textView;->abdul_delay:J

    return-void
.end method


# virtual methods
.method public anu()V
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 42
    move-object v0, p0

    move-object v4, v0

    const/16 v5, 0x50

    int-to-long v5, v5

    :try_start_5
    invoke-virtual {v4, v5, v6}, Landroid/app/textView;->lamaCharacter(J)V

    .line 43
    move-object v4, v0

    invoke-virtual {v4}, Landroid/app/textView;->getText()Ljava/lang/CharSequence;

    move-result-object v4

    invoke-interface {v4}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_1e

    .line 45
    move-object v4, v0

    const-string v5, "Remod? - Please Dont Change Credit!"

    invoke-virtual {v4, v5}, Landroid/app/textView;->textTyping(Ljava/lang/CharSequence;)V

    .line 54
    :goto_1d
    return-void

    .line 49
    :cond_1e
    move-object v4, v0

    move-object v5, v0

    invoke-virtual {v5}, Landroid/app/textView;->getText()Ljava/lang/CharSequence;

    move-result-object v5

    invoke-interface {v5}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/app/textView;->textTyping(Ljava/lang/CharSequence;)V
    :try_end_2b
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_2b} :catch_2c

    goto :goto_1d

    :catch_2c
    move-exception v4

    move-object v2, v4

    .line 54
    move-object v4, v0

    invoke-virtual {v4}, Landroid/app/textView;->getContext()Landroid/content/Context;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuffer;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    invoke-direct {v6}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v6, Ljava/lang/StringBuffer;

    move-object v8, v6

    move-object v6, v8

    move-object v7, v8

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    const-string v7, "Error:\n"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    move-object v7, v2

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/Object;)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v5

    const-string v6, "\n by.Channel World Art Tunnel"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x1

    invoke-static {v4, v5, v6}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v4

    invoke-virtual {v4}, Landroid/widget/Toast;->show()V

    goto :goto_1d
.end method

.method public findID(Ljava/lang/String;Ljava/lang/String;)I
    .registers 11

    .prologue
    .line 82
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-virtual {v4}, Landroid/app/textView;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    move-object v5, v1

    move-object v6, v2

    move-object v7, v0

    invoke-virtual {v7}, Landroid/app/textView;->getContext()Landroid/content/Context;

    move-result-object v7

    invoke-virtual {v7}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v5, v6, v7}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v4

    move v0, v4

    return v0
.end method

.method public lamaCharacter(J)V
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J)V"
        }
    .end annotation

    .prologue
    .line 78
    move-object v0, p0

    move-wide v1, p1

    move-object v4, v0

    move-wide v5, v1

    iput-wide v5, v4, Landroid/app/textView;->abdul_delay:J

    return-void
.end method

.method public star()V
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 29
    move-object v0, p0

    new-instance v4, Landroid/app/textView$100000000;

    move-object v8, v4

    move-object v4, v8

    move-object v5, v8

    move-object v6, v0

    invoke-direct {v5, v6}, Landroid/app/textView$100000000;-><init>(Landroid/app/textView;)V

    move-object v2, v4

    .line 36
    move-object v4, v0

    move-object v5, v2

    const/16 v6, 0x64

    int-to-long v6, v6

    invoke-virtual {v4, v5, v6, v7}, Landroid/app/textView;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v4

    return-void
.end method

.method public textTyping(Ljava/lang/CharSequence;)V
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/CharSequence;",
            ")V"
        }
    .end annotation

    .prologue
    .line 71
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Landroid/app/textView;->abdul_text:Ljava/lang/CharSequence;

    .line 72
    move-object v3, v0

    const/4 v4, 0x0

    iput v4, v3, Landroid/app/textView;->abdul_index:I

    .line 73
    move-object v3, v0

    move-object v4, v0

    iget-object v4, v4, Landroid/app/textView;->characterAdder:Ljava/lang/Runnable;

    invoke-virtual {v3, v4}, Landroid/app/textView;->removeCallbacks(Ljava/lang/Runnable;)Z

    move-result v3

    .line 74
    move-object v3, v0

    move-object v4, v0

    iget-object v4, v4, Landroid/app/textView;->characterAdder:Ljava/lang/Runnable;

    move-object v5, v0

    iget-wide v5, v5, Landroid/app/textView;->abdul_delay:J

    invoke-virtual {v3, v4, v5, v6}, Landroid/app/textView;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v3

    return-void
.end method
