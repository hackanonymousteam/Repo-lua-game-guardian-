.class Landroid/app/textView$100000001;
.super Ljava/lang/Object;
.source "TextView.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/app/textView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000001"
.end annotation


# instance fields
.field private final this$0:Landroid/app/textView;


# direct methods
.method constructor <init>(Landroid/app/textView;)V
    .registers 7

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Landroid/app/textView$100000001;->this$0:Landroid/app/textView;

    return-void
.end method

.method static access$0(Landroid/app/textView$100000001;)Landroid/app/textView;
    .registers 5

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Landroid/app/textView$100000001;->this$0:Landroid/app/textView;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .registers 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 62
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Landroid/app/textView$100000001;->this$0:Landroid/app/textView;

    move-object v3, v0

    iget-object v3, v3, Landroid/app/textView$100000001;->this$0:Landroid/app/textView;

    invoke-static {v3}, Landroid/app/textView;->access$L1000000(Landroid/app/textView;)Ljava/lang/CharSequence;

    move-result-object v3

    const/4 v4, 0x0

    move-object v5, v0

    iget-object v5, v5, Landroid/app/textView$100000001;->this$0:Landroid/app/textView;

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    invoke-static {v6}, Landroid/app/textView;->access$L1000001(Landroid/app/textView;)I

    move-result v6

    move-object v9, v5

    move v10, v6

    move v5, v10

    move-object v6, v9

    move v7, v10

    const/4 v8, 0x1

    add-int/lit8 v7, v7, 0x1

    invoke-static {v6, v7}, Landroid/app/textView;->access$S1000001(Landroid/app/textView;I)V

    invoke-interface {v3, v4, v5}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/app/textView;->setText(Ljava/lang/CharSequence;)V

    .line 63
    move-object v2, v0

    iget-object v2, v2, Landroid/app/textView$100000001;->this$0:Landroid/app/textView;

    invoke-static {v2}, Landroid/app/textView;->access$L1000001(Landroid/app/textView;)I

    move-result v2

    move-object v3, v0

    iget-object v3, v3, Landroid/app/textView$100000001;->this$0:Landroid/app/textView;

    invoke-static {v3}, Landroid/app/textView;->access$L1000000(Landroid/app/textView;)Ljava/lang/CharSequence;

    move-result-object v3

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v3

    if-gt v2, v3, :cond_4b

    .line 65
    move-object v2, v0

    iget-object v2, v2, Landroid/app/textView$100000001;->this$0:Landroid/app/textView;

    move-object v3, v0

    move-object v4, v0

    iget-object v4, v4, Landroid/app/textView$100000001;->this$0:Landroid/app/textView;

    invoke-static {v4}, Landroid/app/textView;->access$L1000002(Landroid/app/textView;)J

    move-result-wide v4

    invoke-virtual {v2, v3, v4, v5}, Landroid/app/textView;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v2

    :cond_4b
    return-void
.end method
