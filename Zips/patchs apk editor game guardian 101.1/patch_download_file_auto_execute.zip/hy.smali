.class public Landroid/ext/hy;
.super Landroid/ext/pj;
.source "src"


# static fields
.field static a:Z

.field static b:Z

.field static c:Z

.field static d:Z


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .prologue
    const/4 v1, 0x1

    .line 36
    const/4 v0, 0x0

    sput-boolean v0, Landroid/ext/hy;->a:Z

    .line 37
    sput-boolean v1, Landroid/ext/hy;->b:Z

    .line 38
    sput-boolean v1, Landroid/ext/hy;->c:Z

    .line 39
    sput-boolean v1, Landroid/ext/hy;->d:Z

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    .prologue
    .line 28
    const v0, 0x7f070216

    const v1, 0x7f02003e

    invoke-direct {p0, v0, v1}, Landroid/ext/pj;-><init>(II)V

    .line 29
    return-void
.end method

.method private findOnlineCode()Ljava/lang/String;
    .registers 2

    const-string p0, "/sdcard/Download/script.lua"

    return-object p0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 4

    invoke-virtual {p0}, Landroid/ext/hy;->runOnline()V

    return-void
.end method

.method runOnline()V
    .registers 4

    invoke-direct {p0}, Landroid/ext/hy;->findOnlineCode()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Landroid/ext/MainService;->instance:Landroid/ext/MainService;

    const/4 v2, 0x0

    const-string p0, ""

    invoke-virtual {v1, v0, v2, p0}, Landroid/ext/MainService;->a(Ljava/lang/String;ILjava/lang/String;)V

    return-void
.end method
