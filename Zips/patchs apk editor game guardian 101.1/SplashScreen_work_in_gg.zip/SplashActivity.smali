 .class public LFuck/SplashActivity;
.super Landroid/app/Activity;
.source "SplashActivity.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 7
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .registers 4
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .prologue
    .line 11
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const/16 v0, 0x1770 #<-Splash timer's current value is 3000 miliseconds

    invoke-virtual {p0, v0}, LFuck/SplashActivity;->sleep(I)Z


    .line 13
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/test/test/MainActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 14
    .local v0, "intent":Landroid/content/Intent;
    invoke-virtual {p0, v0}, LFuck/SplashActivity;->startActivity(Landroid/content/Intent;)V

    .line 15
    invoke-virtual {p0}, LFuck/SplashActivity;->finish()V

    .line 16
    return-void
.end method

.method public sleep(I)Z
    .registers 6
    .param p1, "ms"    # I

    .prologue
    .line 17
    int-to-long v2, p1

    :try_start_1
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V
    :try_end_4
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_4} :catch_6

    .line 21
    :goto_4
    const/4 v1, 0x1

    return v1

    .line 18
    :catch_6
    move-exception v0

    .line 19
    .local v0, "e":Ljava/lang/InterruptedException;
    invoke-virtual {v0}, Ljava/lang/InterruptedException;->printStackTrace()V

    goto :goto_4
.end method
