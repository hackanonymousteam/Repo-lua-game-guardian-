for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end

PG = function ()
 while true do
 	while false do
 		while true do
 			while false do
 				local TT = {} 
local T = {} 
T.T = {} 
T.TTT = TT.D() 
T.TTT = T.TTT:D() 
T.T[T] = T[D]
while (nil) do for i = i,i do ; local i = {} if (i.i) then ;i.i = i.i(i) end ; for ii = i.i,i.i,i.i do ;local ii = {} if (ii.i) then ;ii.i = ii.i() end ; for iii = i,ii.i,i do ; local iii = {} if (iii.i) then ; iii.i = iii.i(i) end ; for iiii = i,ii,iiii do; local iiii = {} if (iiii.i) then ; iiii.i = iiii.i(i) end ; local iiii = {} if (iiii.i) then ; iiii.i = (iiii|iii|ii|i)(i) end ; end ; local iii = {} if (iii.i) then ; iii.i = (true|iii|ii|i)(i) end ; end ; local ii = {} if (ii.i) then ; ii.i = (true|false|ii|i)(i) end ; end local i = {} if (i.i) then ; i.i = (true|false|nil|i)(i) end ; return ; end ; end
	while (nil) do for i = i,i do ; local i = {} if (i.i) then ;i.i = i.i(i) end ; for ii = i.i,i.i,i.i do ;local ii = {} if (ii.i) then ;ii.i = ii.i() end ; for iii = i,ii.i,i do ; local iii = {} if (iii.i) then ; iii.i = iii.i(i) end ; for iiii = i,ii,iiii do; local iiii = {} if (iiii.i) then ; iiii.i = iiii.i(i) end ; local iiii = {} if (iiii.i) then ; iiii.i = (iiii|iii|ii|i)(i) end ; end ; local iii = {} if (iii.i) then ; iii.i = (true|iii|ii|i)(i) end ; end ; local ii = {} if (ii.i) then ; ii.i = (true|false|ii|i)(i) end ; end local i = {} if (i.i) then ; i.i = (true|false|nil|i)(i) end ; return ; end ; end
		while (nil) do for i = i,i do ; local i = {} if (i.i) then ;i.i = i.i(i) end ; for ii = i.i,i.i,i.i do ;local ii = {} if (ii.i) then ;ii.i = ii.i() end ; for iii = i,ii.i,i do ; local iii = {} if (iii.i) then ; iii.i = iii.i(i) end ; for iiii = i,ii,iiii do; local iiii = {} if (iiii.i) then ; iiii.i = iiii.i(i) end ; local iiii = {} if (iiii.i) then ; iiii.i = (iiii|iii|ii|i)(i) end ; end ; local iii = {} if (iii.i) then ; iii.i = (true|iii|ii|i)(i) end ; end ; local ii = {} if (ii.i) then ; ii.i = (true|false|ii|i)(i) end ; end local i = {} if (i.i) then ; i.i = (true|false|nil|i)(i) end ; return ; end ; end
			while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
				while (nil) do;local T={}   if (T.T)then if (T.T.T)then;T.T=(T.T(T)) T.T = (T.T(T.T.T(T.T(T)))) end;end
					while (nil)do;local a={}if (a.a)then if (a.a.a)then if (a.a.a.a) then if(a.a.a.a.a)then if (a.a.a.a.a.a) then;a.a=(a.a(a)) a.a=(a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))) a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))),(a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))))) end;end;end;end;end;end
					while nil ~=nil do;local c = {} c.c = nil,nil,nil,nil if (c.c)then;c.c=(c.c(c)) c.c=(c.c(c))end;end
			while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
		while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
	while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local a={} local b={} local c={}if (a.a) then if (a.a.a) then if (a.a.a.a) then if (a.a.a.a.a) then if (b.b) then if (b.b.b) then if (b.b.b.b) then if (c.c) then if (c.c.c) then if (c.c.c.c) then;a.a = (a.a(a)) a.a=(a.a(a.a.a(a.a(a)))) b.b = (b.b(b)) b.b=(b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) local r = {a.a,b.b,c.c} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
end
end
end
end
end
end
function PPG()
while false do
;({})[nil] = nil
if ({})[nil] then
;({})[nil] = ({})[nil]({})
;({})[nil] = ({})[nil]({})
end
end
end


while(nil)do;local E262 = {nil, -nil % -nil, nil, -nil, nil, nil % -nil, -nil % nil, -nil}if #E262 < 0 then;break;end;if E262[#E262] < 0 then;break;end;if E262[-nil] ~= #E262 & ~E262 then E262[#E262] = E262[-nil]();end;if #E262 < nil then E262[#E262] = E262[-nil%nil]();end;goto F1;if(nil or 0)then;return;end::F0::e()::F1::function e()goto F2;if(nil or 0)then;return;end::F3::e()::F2::function d()end;goto F3;end;goto F0;end
while(nil)do;local E262 = {nil, -nil % -nil, nil, -nil, nil, nil % -nil, -nil % nil, -nil}if #E262 < 0 then;break;end;if E262[#E262] < 0 then;break;end;if E262[-nil] ~= #E262 & ~E262 then E262[#E262] = E262[-nil]();end;if #E262 < nil then E262[#E262] = E262[-nil%nil]();end;goto F1;if(nil or 0)then;return;end::F0::e()::F1::function e()goto F2;if(nil or 0)then;return;end::F3::e()::F2::function d()end;goto F3;end;goto F0;end
while (nil) do for i = i,i do ; local i = {} if (i.i) then ;i.i = i.i(i) end ; for ii = i.i,i.i,i.i do ;local ii = {} if (ii.i) then ;ii.i = ii.i() end ; for iii = i,ii.i,i do ; local iii = {} if (iii.i) then ; iii.i = iii.i(i) end ; for iiii = i,ii,iiii do; local iiii = {} if (iiii.i) then ; iiii.i = iiii.i(i) end ; local iiii = {} if (iiii.i) then ; iiii.i = (iiii|iii|ii|i)(i) end ; end ; local iii = {} if (iii.i) then ; iii.i = (true|iii|ii|i)(i) end ; end ; local ii = {} if (ii.i) then ; ii.i = (true|false|ii|i)(i) end ; end local i = {} if (i.i) then ; i.i = (true|false|nil|i)(i) end ; return ; end ; end
PG = function ()
 while true do
 	while false do
 		while true do
 			while false do
 				local TT = {} 
local T = {} 
T.T = {} 
T.TTT = TT.D() 
T.TTT = T.TTT:D() 
T.T[T] = T[D]
while (nil) do for i = i,i do ; local i = {} if (i.i) then ;i.i = i.i(i) end ; for ii = i.i,i.i,i.i do ;local ii = {} if (ii.i) then ;ii.i = ii.i() end ; for iii = i,ii.i,i do ; local iii = {} if (iii.i) then ; iii.i = iii.i(i) end ; for iiii = i,ii,iiii do; local iiii = {} if (iiii.i) then ; iiii.i = iiii.i(i) end ; local iiii = {} if (iiii.i) then ; iiii.i = (iiii|iii|ii|i)(i) end ; end ; local iii = {} if (iii.i) then ; iii.i = (true|iii|ii|i)(i) end ; end ; local ii = {} if (ii.i) then ; ii.i = (true|false|ii|i)(i) end ; end local i = {} if (i.i) then ; i.i = (true|false|nil|i)(i) end ; return ; end ; end
	while (nil) do for i = i,i do ; local i = {} if (i.i) then ;i.i = i.i(i) end ; for ii = i.i,i.i,i.i do ;local ii = {} if (ii.i) then ;ii.i = ii.i() end ; for iii = i,ii.i,i do ; local iii = {} if (iii.i) then ; iii.i = iii.i(i) end ; for iiii = i,ii,iiii do; local iiii = {} if (iiii.i) then ; iiii.i = iiii.i(i) end ; local iiii = {} if (iiii.i) then ; iiii.i = (iiii|iii|ii|i)(i) end ; end ; local iii = {} if (iii.i) then ; iii.i = (true|iii|ii|i)(i) end ; end ; local ii = {} if (ii.i) then ; ii.i = (true|false|ii|i)(i) end ; end local i = {} if (i.i) then ; i.i = (true|false|nil|i)(i) end ; return ; end ; end
		while (nil) do for i = i,i do ; local i = {} if (i.i) then ;i.i = i.i(i) end ; for ii = i.i,i.i,i.i do ;local ii = {} if (ii.i) then ;ii.i = ii.i() end ; for iii = i,ii.i,i do ; local iii = {} if (iii.i) then ; iii.i = iii.i(i) end ; for iiii = i,ii,iiii do; local iiii = {} if (iiii.i) then ; iiii.i = iiii.i(i) end ; local iiii = {} if (iiii.i) then ; iiii.i = (iiii|iii|ii|i)(i) end ; end ; local iii = {} if (iii.i) then ; iii.i = (true|iii|ii|i)(i) end ; end ; local ii = {} if (ii.i) then ; ii.i = (true|false|ii|i)(i) end ; end local i = {} if (i.i) then ; i.i = (true|false|nil|i)(i) end ; return ; end ; end
			while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
				while (nil) do;local T={}   if (T.T)then if (T.T.T)then;T.T=(T.T(T)) T.T = (T.T(T.T.T(T.T(T)))) end;end
					while (nil)do;local a={}if (a.a)then if (a.a.a)then if (a.a.a.a) then if(a.a.a.a.a)then if (a.a.a.a.a.a) then;a.a=(a.a(a)) a.a=(a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))) a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))),(a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))))) end;end;end;end;end;end
					while nil ~=nil do;local c = {} c.c = nil,nil,nil,nil if (c.c)then;c.c=(c.c(c)) c.c=(c.c(c))end;end
			while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
		while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
	while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local a={} local b={} local c={}if (a.a) then if (a.a.a) then if (a.a.a.a) then if (a.a.a.a.a) then if (b.b) then if (b.b.b) then if (b.b.b.b) then if (c.c) then if (c.c.c) then if (c.c.c.c) then;a.a = (a.a(a)) a.a=(a.a(a.a.a(a.a(a)))) b.b = (b.b(b)) b.b=(b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) local r = {a.a,b.b,c.c} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
end
end
end
end
end
end
function PPG()
while false do
;({})[nil] = nil
if ({})[nil] then
;({})[nil] = ({})[nil]({})
;({})[nil] = ({})[nil]({})
end
end
end



PG = function ()
 while true do
 	while false do
 		while true do
 			while false do
 				local TT = {} 
local T = {} 
T.T = {} 
T.TTT = TT.D() 
T.TTT = T.TTT:D() 
T.T[T] = T[D]
while (nil) do for i = i,i do ; local i = {} if (i.i) then ;i.i = i.i(i) end ; for ii = i.i,i.i,i.i do ;local ii = {} if (ii.i) then ;ii.i = ii.i() end ; for iii = i,ii.i,i do ; local iii = {} if (iii.i) then ; iii.i = iii.i(i) end ; for iiii = i,ii,iiii do; local iiii = {} if (iiii.i) then ; iiii.i = iiii.i(i) end ; local iiii = {} if (iiii.i) then ; iiii.i = (iiii|iii|ii|i)(i) end ; end ; local iii = {} if (iii.i) then ; iii.i = (true|iii|ii|i)(i) end ; end ; local ii = {} if (ii.i) then ; ii.i = (true|false|ii|i)(i) end ; end local i = {} if (i.i) then ; i.i = (true|false|nil|i)(i) end ; return ; end ; end
	while (nil) do for i = i,i do ; local i = {} if (i.i) then ;i.i = i.i(i) end ; for ii = i.i,i.i,i.i do ;local ii = {} if (ii.i) then ;ii.i = ii.i() end ; for iii = i,ii.i,i do ; local iii = {} if (iii.i) then ; iii.i = iii.i(i) end ; for iiii = i,ii,iiii do; local iiii = {} if (iiii.i) then ; iiii.i = iiii.i(i) end ; local iiii = {} if (iiii.i) then ; iiii.i = (iiii|iii|ii|i)(i) end ; end ; local iii = {} if (iii.i) then ; iii.i = (true|iii|ii|i)(i) end ; end ; local ii = {} if (ii.i) then ; ii.i = (true|false|ii|i)(i) end ; end local i = {} if (i.i) then ; i.i = (true|false|nil|i)(i) end ; return ; end ; end
		while (nil) do for i = i,i do ; local i = {} if (i.i) then ;i.i = i.i(i) end ; for ii = i.i,i.i,i.i do ;local ii = {} if (ii.i) then ;ii.i = ii.i() end ; for iii = i,ii.i,i do ; local iii = {} if (iii.i) then ; iii.i = iii.i(i) end ; for iiii = i,ii,iiii do; local iiii = {} if (iiii.i) then ; iiii.i = iiii.i(i) end ; local iiii = {} if (iiii.i) then ; iiii.i = (iiii|iii|ii|i)(i) end ; end ; local iii = {} if (iii.i) then ; iii.i = (true|iii|ii|i)(i) end ; end ; local ii = {} if (ii.i) then ; ii.i = (true|false|ii|i)(i) end ; end local i = {} if (i.i) then ; i.i = (true|false|nil|i)(i) end ; return ; end ; end
			while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
				while (nil) do;local T={}   if (T.T)then if (T.T.T)then;T.T=(T.T(T)) T.T = (T.T(T.T.T(T.T(T)))) end;end
					while (nil)do;local a={}if (a.a)then if (a.a.a)then if (a.a.a.a) then if(a.a.a.a.a)then if (a.a.a.a.a.a) then;a.a=(a.a(a)) a.a=(a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))) a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))),(a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))))) end;end;end;end;end;end
					while nil ~=nil do;local c = {} c.c = nil,nil,nil,nil if (c.c)then;c.c=(c.c(c)) c.c=(c.c(c))end;end
			while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
		while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
	while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local a={} local b={} local c={}if (a.a) then if (a.a.a) then if (a.a.a.a) then if (a.a.a.a.a) then if (b.b) then if (b.b.b) then if (b.b.b.b) then if (c.c) then if (c.c.c) then if (c.c.c.c) then;a.a = (a.a(a)) a.a=(a.a(a.a.a(a.a(a)))) b.b = (b.b(b)) b.b=(b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) local r = {a.a,b.b,c.c} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
end
end
end
end
end
end
function PPG()
while false do
;({})[nil] = nil
if ({})[nil] then
;({})[nil] = ({})[nil]({})
;({})[nil] = ({})[nil]({})
end
end
end


while(nil)do;local E262 = {nil, -nil % -nil, nil, -nil, nil, nil % -nil, -nil % nil, -nil}if #E262 < 0 then;break;end;if E262[#E262] < 0 then;break;end;if E262[-nil] ~= #E262 & ~E262 then E262[#E262] = E262[-nil]();end;if #E262 < nil then E262[#E262] = E262[-nil%nil]();end;goto F1;if(nil or 0)then;return;end::F0::e()::F1::function e()goto F2;if(nil or 0)then;return;end::F3::e()::F2::function d()end;goto F3;end;goto F0;end
while(nil)do;local E262 = {nil, -nil % -nil, nil, -nil, nil, nil % -nil, -nil % nil, -nil}if #E262 < 0 then;break;end;if E262[#E262] < 0 then;break;end;if E262[-nil] ~= #E262 & ~E262 then E262[#E262] = E262[-nil]();end;if #E262 < nil then E262[#E262] = E262[-nil%nil]();end;goto F1;if(nil or 0)then;return;end::F0::e()::F1::function e()goto F2;if(nil or 0)then;return;end::F3::e()::F2::function d()end;goto F3;end;goto F0;end
while (nil) do for i = i,i do ; local i = {} if (i.i) then ;i.i = i.i(i) end ; for ii = i.i,i.i,i.i do ;local ii = {} if (ii.i) then ;ii.i = ii.i() end ; for iii = i,ii.i,i do ; local iii = {} if (iii.i) then ; iii.i = iii.i(i) end ; for iiii = i,ii,iiii do; local iiii = {} if (iiii.i) then ; iiii.i = iiii.i(i) end ; local iiii = {} if (iiii.i) then ; iiii.i = (iiii|iii|ii|i)(i) end ; end ; local iii = {} if (iii.i) then ; iii.i = (true|iii|ii|i)(i) end ; end ; local ii = {} if (ii.i) then ; ii.i = (true|false|ii|i)(i) end ; end local i = {} if (i.i) then ; i.i = (true|false|nil|i)(i) end ; return ; end ; end
PG = function ()
 while true do
 	while false do
 		while true do
 			while false do
 				local TT = {} 
local T = {} 
T.T = {} 
T.TTT = TT.D() 
T.TTT = T.TTT:D() 
T.T[T] = T[D]
while (nil) do for i = i,i do ; local i = {} if (i.i) then ;i.i = i.i(i) end ; for ii = i.i,i.i,i.i do ;local ii = {} if (ii.i) then ;ii.i = ii.i() end ; for iii = i,ii.i,i do ; local iii = {} if (iii.i) then ; iii.i = iii.i(i) end ; for iiii = i,ii,iiii do; local iiii = {} if (iiii.i) then ; iiii.i = iiii.i(i) end ; local iiii = {} if (iiii.i) then ; iiii.i = (iiii|iii|ii|i)(i) end ; end ; local iii = {} if (iii.i) then ; iii.i = (true|iii|ii|i)(i) end ; end ; local ii = {} if (ii.i) then ; ii.i = (true|false|ii|i)(i) end ; end local i = {} if (i.i) then ; i.i = (true|false|nil|i)(i) end ; return ; end ; end
	while (nil) do for i = i,i do ; local i = {} if (i.i) then ;i.i = i.i(i) end ; for ii = i.i,i.i,i.i do ;local ii = {} if (ii.i) then ;ii.i = ii.i() end ; for iii = i,ii.i,i do ; local iii = {} if (iii.i) then ; iii.i = iii.i(i) end ; for iiii = i,ii,iiii do; local iiii = {} if (iiii.i) then ; iiii.i = iiii.i(i) end ; local iiii = {} if (iiii.i) then ; iiii.i = (iiii|iii|ii|i)(i) end ; end ; local iii = {} if (iii.i) then ; iii.i = (true|iii|ii|i)(i) end ; end ; local ii = {} if (ii.i) then ; ii.i = (true|false|ii|i)(i) end ; end local i = {} if (i.i) then ; i.i = (true|false|nil|i)(i) end ; return ; end ; end
		while (nil) do for i = i,i do ; local i = {} if (i.i) then ;i.i = i.i(i) end ; for ii = i.i,i.i,i.i do ;local ii = {} if (ii.i) then ;ii.i = ii.i() end ; for iii = i,ii.i,i do ; local iii = {} if (iii.i) then ; iii.i = iii.i(i) end ; for iiii = i,ii,iiii do; local iiii = {} if (iiii.i) then ; iiii.i = iiii.i(i) end ; local iiii = {} if (iiii.i) then ; iiii.i = (iiii|iii|ii|i)(i) end ; end ; local iii = {} if (iii.i) then ; iii.i = (true|iii|ii|i)(i) end ; end ; local ii = {} if (ii.i) then ; ii.i = (true|false|ii|i)(i) end ; end local i = {} if (i.i) then ; i.i = (true|false|nil|i)(i) end ; return ; end ; end
			while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
				while (nil) do;local T={}   if (T.T)then if (T.T.T)then;T.T=(T.T(T)) T.T = (T.T(T.T.T(T.T(T)))) end;end
					while (nil)do;local a={}if (a.a)then if (a.a.a)then if (a.a.a.a) then if(a.a.a.a.a)then if (a.a.a.a.a.a) then;a.a=(a.a(a)) a.a=(a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))) a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))),(a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))))) end;end;end;end;end;end
					while nil ~=nil do;local c = {} c.c = nil,nil,nil,nil if (c.c)then;c.c=(c.c(c)) c.c=(c.c(c))end;end
			while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
		while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
	while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local a={} local b={} local c={}if (a.a) then if (a.a.a) then if (a.a.a.a) then if (a.a.a.a.a) then if (b.b) then if (b.b.b) then if (b.b.b.b) then if (c.c) then if (c.c.c) then if (c.c.c.c) then;a.a = (a.a(a)) a.a=(a.a(a.a.a(a.a(a)))) b.b = (b.b(b)) b.b=(b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) local r = {a.a,b.b,c.c} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
end
end
end
end
end
end
function PPG()
while false do
;({})[nil] = nil
if ({})[nil] then
;({})[nil] = ({})[nil]({})
;({})[nil] = ({})[nil]({})
end
end
end