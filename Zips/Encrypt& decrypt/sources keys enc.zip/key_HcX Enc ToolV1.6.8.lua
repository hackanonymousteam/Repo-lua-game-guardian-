  
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = 1,1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = _G['tonumber']('1'),1024 do  
   log[i] = log[1] 
 end
 for i=1,10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]], 1048576) 
 for i = _G['tonumber']('1'),1024 do  
   log[i] = log[1] 
 end
 for i= _G['tonumber']('1'),10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]],_G['tonumber']('1048576')) 
 for i = _G['tonumber']('1'),1024 do  
   log[i] = log[1] 
 end
 for i= _G['tonumber']('1'),10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]],_G['tonumber']('1048576')) 
 for i = _G['tonumber']('1'),1024 do  
   log[i] = log[1] 
 end
 for i= _G['tonumber']('1'),10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({_G['tonumber']('61'),91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({74,97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]],_G['tonumber']('1048576')) 
 for i = _G['tonumber']('1'),1024 do  
   log[i] = log[1] 
 end
 for i= _G['tonumber']('1'),10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({_G['tonumber']('61'),91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,97})) then
print(string.char(table.unpack({233,148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]],_G['tonumber']('1048576')) 
 for i = _G['tonumber']('1'),1024 do  
   log[i] = log[1] 
 end
 for i= _G['tonumber']('1'),10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({_G['tonumber']('61'),91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,97})) then
print(string.char(table.unpack({_G['tonumber']('233'),148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({233,147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]],_G['tonumber']('1048576')) 
 for i = _G['tonumber']('1'),1024 do  
   log[i] = log[1] 
 end
 for i= _G['tonumber']('1'),10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({_G['tonumber']('61'),91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,97})) then
print(string.char(table.unpack({_G['tonumber']('233'),148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({_G['tonumber']('233'),147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({61,91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]],_G['tonumber']('1048576')) 
 for i = _G['tonumber']('1'),1024 do  
   log[i] = log[1] 
 end
 for i= _G['tonumber']('1'),10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,97})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({_G['tonumber']('61'),91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,97})) then
print(string.char(table.unpack({_G['tonumber']('233'),148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({_G['tonumber']('233'),147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({_G['tonumber']('61'),91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]],_G['tonumber']('1048576')) 
 for i = _G['tonumber']('1'),1024 do  
   log[i] = log[1] 
 end
 for i= _G['tonumber']('1'),10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,_G['tonumber']('97')})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({_G['tonumber']('61'),91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,97})) then
print(string.char(table.unpack({_G['tonumber']('233'),148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({_G['tonumber']('233'),147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({_G['tonumber']('61'),91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]],_G['tonumber']('1048576')) 
 for i = _G['tonumber']('1'),1024 do  
   log[i] = log[1] 
 end
 for i= _G['tonumber']('1'),10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,_G['tonumber']('97')})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({_G['tonumber']('61'),91,74,97,118,97,_G['tonumber']('93')})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,97})) then
print(string.char(table.unpack({_G['tonumber']('233'),148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({_G['tonumber']('233'),147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({_G['tonumber']('61'),91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]],_G['tonumber']('1048576')) 
 for i = _G['tonumber']('1'),1024 do  
   log[i] = log[1] 
 end
 for i= _G['tonumber']('1'),10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,_G['tonumber']('97')})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({_G['tonumber']('61'),91,74,97,118,97,_G['tonumber']('93')})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,_G['tonumber']('97')})) then
print(string.char(table.unpack({_G['tonumber']('233'),148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,33})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({_G['tonumber']('233'),147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({_G['tonumber']('61'),91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]],_G['tonumber']('1048576')) 
 for i = _G['tonumber']('1'),1024 do  
   log[i] = log[1] 
 end
 for i= _G['tonumber']('1'),10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,_G['tonumber']('97')})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({_G['tonumber']('61'),91,74,97,118,97,_G['tonumber']('93')})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,_G['tonumber']('97')})) then
print(string.char(table.unpack({_G['tonumber']('233'),148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,_G['tonumber']('33')})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({_G['tonumber']('233'),147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,100})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({_G['tonumber']('61'),91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]],_G['tonumber']('1048576')) 
 for i = _G['tonumber']('1'),1024 do  
   log[i] = log[1] 
 end
 for i= _G['tonumber']('1'),10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,_G['tonumber']('97')})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({_G['tonumber']('61'),91,74,97,118,97,_G['tonumber']('93')})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,_G['tonumber']('97')})) then
print(string.char(table.unpack({_G['tonumber']('233'),148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,_G['tonumber']('33')})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({_G['tonumber']('233'),147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,_G['tonumber']('100')})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({_G['tonumber']('61'),91,74,97,118,97,93})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]],_G['tonumber']('1048576')) 
 for i = _G['tonumber']('1'),1024 do  
   log[i] = log[1] 
 end
 for i= _G['tonumber']('1'),10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
 
do    local SHcX=load
local load=function() end
x=debug.getinfo(load)
if x.short_src==gg.getFile() then
load=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(load)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,_G['tonumber']('97')})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({_G['tonumber']('61'),91,74,97,118,97,_G['tonumber']('93')})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=debug.getinfo(gg.searchNumber)
if x.short_src==gg.getFile() then
gg.searchNumber=SHcX
else
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
x=debug.getinfo(gg.searchNumber)
if x.what~=string.char(table.unpack({_G['tonumber']('74'),97,118,_G['tonumber']('97')})) then
print(string.char(table.unpack({_G['tonumber']('233'),148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,_G['tonumber']('33')})).."".._G['string']['char'](_G['tonumber']('010'))..""..string.char(table.unpack({_G['tonumber']('233'),147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,_G['tonumber']('100')})))
print("修改器必须等于等于90.0")
os.exit()
while true do end
end
if x.source ~= string.char(table.unpack({_G['tonumber']('61'),91,74,97,118,97,_G['tonumber']('93')})) then
print("修改器必须等于等于90.0")
os.exit()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]],_G['tonumber']('1048576')) 
 for i = _G['tonumber']('1'),1024 do  
   log[i] = log[1] 
 end
 for i= _G['tonumber']('1'),10 do
  _G[c][d](log,log,log)
 end
end



local Gbg="load"
for i=tonumber("1"),tonumber("100000") do
_G[Gbg](" ")
end

gg.toast("KEY DEC BY BATMAN GAMES")
  local _='\n　　 へ　　　　   ／|\n　　/＼7　　   ∠＿/\n　 /　│ 👑　 ／　／\n　│　Z ＿,＜　／　　 /`ヽ\n　│　　　　　ヽ　　 /　　〉\n　 Y　　　　　  `　 /　／\n　ｲ●　､　●　　⊂⊃ 〈　　\n　()　 へ　　　　|　＼〈\n　　>ｰ ､_　 ィ　 │ ／／\n　 / へ　　 /　ﾉ＜| ＼＼\n　 ヽ_ﾉ　　(_／　 │／／\n　　7　　　　　　　|／\n　　＞―r￣￣`ｰ―＿  |\n🛡🔒⚠️#🇭 🇨 🇽 V_1.6.8 #⚠️🔒🛡 \n-------------------------------------------------\n\n列子:脚本作者:HcX-伟\n\n-------------------------------------------------\n @By HcX-伟\n '    

local HcXweiNB=function(_)  local FLI9d3={ 
	[ 1] = { 
		[1] = 293,
		[2] = 188,
		[3] = 286,
		[4] = 313,
		[5] = 315,
		[6] = 152,
		[7] = 342,
		[8] = 193,
	},
	[ 2] = { 
		[1] = 355,
		[2] = 206,
		[3] = 114,
		[4] = 184,
		[5] = 148,
		[6] = 158,
		[7] = 192,
		[8] = 334,
	},
	[ 3] = { 
		[1] = 352,
	},
	[ 4] = { 
		[1] = 139,
	},
	[ 5] = { 
		[1] = 175,
	},
	[ 6] = { 
		[1] = 298,
	},
	[ 7] = { 
		[1] = 174,
		[2] = 192,
		[3] = 341,
		[4] = 156,
		[5] = 253,
		[6] = 276,
		[7] = 177,
		[8] = 259,
	},
	[ 8] = { 
		[1] = 247,
	},
	[ 9] = { 
		[1] = 67,
		[2] = 84,
		[3] = 218,
		[4] = 122,
		[5] = 159,
	},
	[10] = { 
		[1] = 243,
		[2] = 162,
		[3] = 314,
		[4] = 329,
		[5] = 154,
	},
}
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local ooOo00OoO0O=[[]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local OoOoOoOO0=[[t]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local OoO00oo00=[[a]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local Oo0o0o0o0=[[b]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local O00oOooo0=[[l]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local OoO00oOO0=[[e]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local OoO0OoOO0=[[c]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local OoOoOoO00=[[o]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local OoOOoo000=[[n]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local Oo0O=[[string]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local oOoOOOo00=[[u]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local OoOOo000o=[[m]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local OoO0o000o=[[r]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local oOo0=[[char]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local OOOO=[[0]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local o0000=[[1]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local Ooooo=[[2]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local oO00O=[[3]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local OO00o=[[4]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local OOOoO=[[5]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local oO00oo=[[6]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local oooOO0=[[7]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local oo00ooO=[[8]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

local OoO0oOO=[[9]]
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

while true do
  if FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000)] then
if    OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o  then
           local kELHRm={ 
	[ 1] = { 
		[1] = 177,
		[2] = 77,
		[3] = 171,
		[4] = 197,
		[5] = 201,
		[6] = 47,
		[7] = 232,
		[8] = 90,
	},
	[ 2] = { 
		[1] = 239,
		[2] = 95,
		[3] = 4,
		[4] = 67,
		[5] = 39,
		[6] = 60,
		[7] = 91,
		[8] = 220,
	},
	[ 3] = { 
		[1] = 247,
	},
	[ 4] = { 
		[1] = 84,
	},
	[ 5] = { 
		[1] = 124,
	},
	[ 6] = { 
		[1] = 244,
	},
	[ 7] = { 
		[1] = 58,
		[2] = 81,
		[3] = 231,
		[4] = 39,
		[5] = 144,
		[6] = 178,
		[7] = 76,
		[8] = 145,
	},
	[ 8] = { 
		[1] = 199,
	},
	[ 9] = { 
		[1] = 18,
		[2] = 36,
		[3] = 170,
		[4] = 74,
		[5] = 111,
	},
	[10] = { 
		[1] = 131,
		[2] = 65,
		[3] = 209,
		[4] = 215,
		[5] = 39,
	},
}
local i_,i=nil,nil
  if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

for i=_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000),#FLI9d3 do
  for i_=_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000),#FLI9d3[i] do
      if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

    FLI9d3[i][i_]= _G[Oo0O][oOo0]( FLI9d3[i][i_] - kELHRm[i][i_] )
      if nil then
   local _,__,___,____,_____,______,_______=nil,nil,nil,nil,nil,nil,nil
    local __={} ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_
     for _=__,___,____ do if _==#__ then break end end while #__[_][__][_]>=__[_][_][___] do return true end if #__[_][___][__]>=#__[__][__][___] then 
     return false
      end if _[__..___..___.._] then while ___[__..___][__..___..___..__._] do
       return __ 
       end end
        local __={}
         for _=__,___,____ do
          __[_]={} __[_][__]={} __[_][__][_]=_ if _==#__ then break end end
           ___={} ___[___]=___ ___[__]=_____ ___[___]=___ ___[____]=_ 
           
           end 

   end
end
end
end
break
end





do

      local k,v=nil,nil

local S=_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](Ooooo..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oO00O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](OO00o..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](OOOoO..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oO00oo..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oooOO0..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oo00ooO..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)]})

local t=_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](Ooooo..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](Ooooo..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](Ooooo..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](Ooooo..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oO00O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](Ooooo..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](OO00o..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](Ooooo..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](OOOoO..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](Ooooo..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oO00oo..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](Ooooo..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oooOO0..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](Ooooo..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oo00ooO..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)]})
local iiiiii,iiiiiii,iiiiiiii,iiiiiiiii,iiiiiiiiii,iiiiiiiiiii,iiiiiiiiiiiii=_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oO00O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)]}),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](OO00o..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)]}),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](OOOoO..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)]}),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oO00oo..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)]}),_G,1,#_G[S](_G)
local i= _G[_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oooOO0..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oooOO0..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](Ooooo..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oooOO0..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oO00O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oooOO0..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](OO00o..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oooOO0..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](OOOoO..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oooOO0..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oO00oo..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oooOO0..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oooOO0..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oooOO0..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oo00ooO..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)]})](_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oo00ooO..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)]}))
local ii={}
local iiiii=iiiiii..iiiiii

local iiii,iii=iiiiii..iiiiii..iiiiiiii..iiiiiii,iiiiii..iiiiii..iiiiiiii..iiiiiiiii
ii[iii]=false
ii[iiii]=false
local iiiiiiiiiiiiiiiii=iiiiiiiiiiiii<=_G[t](_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](OoO0oOO..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](OoO0oOO..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](Ooooo..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](OoO0oOO..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oO00O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](OoO0oOO..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](OO00o..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](OoO0oOO..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](OOOoO..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)]}))
while iiiiiiiiiiiiiiiii do
end
for k,v in _G[_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..OOOO..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..OOOO..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](Ooooo..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..OOOO..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](oO00O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..OOOO..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](OO00o..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)],FLI9d3[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..OOOO..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](OOOoO..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O..ooOo00OoO0O)]})](iiiiiiiiii) do
i=i+iiiiiiiiiii
end
while ii[iiiii..i]==ii[iiiii..iiiii] do
             
end
end end      HcXweiNB(_)  HcXweiNB=nil









     local HcXweiNB=function(_)         if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end    local OoO0oOO00o=[[x]]   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local ooOo00OoO0O=[[]]   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local OoOoOoOO0=[[t]]  local OoOoOoO00oo=[[pcall]]    if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local OoO00oo00=[[a]]   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local Oo0o0o0o0=[[b]]   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local O00oOooo0=[[l]]   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local OoO00oOO0=[[e]]  if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end    local Oo0O=[[string]]  if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end   local oOoOOOo00=[[u]]   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local OoOOo000o=[[m]]   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local OoO0o000o=[[r]]   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end   local OoO0OoOO0=[[c]]   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local OoOoOoO00=[[o]]   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local OoOOoo000=[[n]]   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local Oo0O=[[string]]   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local oOoOOOo00=[[u]]   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local OoOOo000o=[[m]]   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local OoO0o000o=[[r]]  if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local oOo0=[[char]]  if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local OOOO=[[0]]  if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local o0000=[[1]]  if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local Ooooo=[[2]]   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local oO00O=[[3]]  if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local OO00o=[[4]]  if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local OOOoO=[[5]]  if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local oO00oo=[[6]]  if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local oooOO0=[[7]]  if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local oo00ooO=[[8]]  if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local OoO0oOO=[[9]]  if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local ooOOO00o=[[-]]  if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local oOOo000oo=[[+]]  if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local ooooOOo000=[[E]]  if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local oOO000OO0o=[[e]]  if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end  local ooo00OOo00o=[[.]]   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end     
local EfICQXH={ -- table(39ae6a8)
	[  1] = { -- table(92b95c1)
		[1] = oO00O..Ooooo..oO00O,
		[2] = oO00O..OO00o..oooOO0,
		[3] = o0000..Ooooo..oO00O,
		[4] = Ooooo..OOOO..Ooooo,
		[5] = o0000..OoO0oOO..OOOoO,
	},
	[  2] = { -- table(375c166)
		[1] = Ooooo..Ooooo..o0000,
		[2] = o0000..OOOO..oo00ooO,
		[3] = o0000..OOOoO..oooOO0,
		[4] = oO00O..oO00O..OO00o,
		[5] = Ooooo..o0000..OO00o,
		[6] = oO00O..OOOO..OoO0oOO,
		[7] = Ooooo..oooOO0..oo00ooO,
	},
	[  3] = { -- table(4f49ca7)
		[1] = oO00O..OOOO..Ooooo,
		[2] = Ooooo..OO00o..OOOO,
	},
	[  4] = { -- table(40bc554)
		[1] = o0000..oo00ooO..Ooooo,
		[2] = oO00O..o0000..OO00o,
		[3] = oO00O..OOOO..OoO0oOO,
		[4] = o0000..oo00ooO..Ooooo,
		[5] = oO00O..oO00O..oo00ooO,
		[6] = o0000..oO00oo..Ooooo,
		[7] = o0000..oO00oo..oooOO0,
	},
	[  5] = { -- table(21accfd)
		[1] = oO00O..OOOoO..oO00O,
		[2] = o0000..Ooooo..OOOoO,
		[3] = o0000..oO00oo..Ooooo,
		[4] = oO00O..OOOoO..oooOO0,
		[5] = oO00O..oO00oo..o0000,
	},
	[  6] = { -- table(88c8df2)
		[ 1] = oO00O..oooOO0..oo00ooO,
		[ 2] = Ooooo..OoO0oOO..oO00O,
		[ 3] = o0000..OoO0oOO..oo00ooO,
		[ 4] = Ooooo..oo00ooO..o0000,
		[ 5] = oO00O..oO00O..oO00O,
		[ 6] = oO00O..OOOoO..OO00o,
		[ 7] = Ooooo..OoO0oOO..OOOoO,
		[ 8] = Ooooo..OOOoO..OO00o,
		[ 9] = Ooooo..oo00ooO..OOOoO,
		[10] = Ooooo..OoO0oOO..oO00oo,
		[11] = Ooooo..oO00oo..oO00oo,
		[12] = Ooooo..OoO0oOO..OOOoO,
		[13] = oO00O..OOOoO..oooOO0,
		[14] = OO00o..OOOO..OOOO,
		[15] = oO00O..oO00O..oO00oo,
		[16] = oO00O..Ooooo..oO00O,
		[17] = oO00O..OOOO..OO00o,
		[18] = Ooooo..oO00oo..OO00o,
		[19] = Ooooo..OoO0oOO..OoO0oOO,
		[20] = Ooooo..OoO0oOO..OOOoO,
		[21] = o0000..oO00oo..OOOoO,
		[22] = Ooooo..OO00o..oO00oo,
		[23] = oO00O..OOOoO..Ooooo,
		[24] = oO00O..o0000..OO00o,
		[25] = OO00o..o0000..oooOO0,
		[26] = Ooooo..oo00ooO..OO00o,
		[27] = Ooooo..OoO0oOO..oO00O,
		[28] = oO00O..OOOO..oo00ooO,
		[29] = o0000..oO00oo..OoO0oOO,
		[30] = o0000..OOOoO..o0000,
		[31] = Ooooo..oO00O..o0000,
	},
	[  7] = { -- table(2445c43)
		[1] = oO00O..oO00O..OoO0oOO,
		[2] = o0000..Ooooo..Ooooo,
	},
	[  8] = { -- table(a09e2c0)
		[1] = Ooooo..oo00ooO..oO00O,
		[2] = Ooooo..OoO0oOO..OOOoO,
		[3] = o0000..oO00oo..oO00oo,
		[4] = Ooooo..oooOO0..OoO0oOO,
	},
	[  9] = { -- table(9cc3bf9)
		[1] = oO00O..o0000..OO00o,
		[2] = Ooooo..oO00O..OOOoO,
		[3] = Ooooo..oooOO0..oooOO0,
		[4] = oO00O..OOOoO..OO00o,
		[5] = o0000..oO00oo..oooOO0,
	},
	[ 10] = { -- table(1d1973e)
		[1] = Ooooo..oooOO0..oooOO0,
		[2] = Ooooo..oooOO0..oO00oo,
		[3] = o0000..OoO0oOO..oO00O,
		[4] = o0000..OOOoO..OOOO,
		[5] = o0000..oo00ooO..Ooooo,
		[6] = oO00O..oO00O..oO00O,
		[7] = Ooooo..OOOO..Ooooo,
	},
	[ 11] = { -- table(a46799f)
		[1] = Ooooo..oo00ooO..OOOoO,
		[2] = o0000..Ooooo..oo00ooO,
		[3] = o0000..Ooooo..Ooooo,
		[4] = o0000..Ooooo..OOOO,
		[5] = o0000..oo00ooO..OOOoO,
		[6] = o0000..Ooooo..o0000,
	},
	[ 12] = { -- table(90a6aec)
		[1] = o0000..Ooooo..OoO0oOO,
		[2] = oO00O..o0000..oO00oo,
		[3] = o0000..o0000..OoO0oOO,
		[4] = oO00O..o0000..OOOO,
	},
	[ 13] = { -- table(48b9eb5)
		[1] = Ooooo..Ooooo..o0000,
		[2] = Ooooo..o0000..Ooooo,
		[3] = Ooooo..OO00o..oo00ooO,
		[4] = Ooooo..OOOoO..oo00ooO,
		[5] = o0000..OOOO..oooOO0,
	},
	[ 14] = { -- table(ecbe94a)
		[1] = oO00O..Ooooo..Ooooo,
		[2] = Ooooo..oo00ooO..o0000,
		[3] = o0000..oo00ooO..OO00o,
		[4] = o0000..OOOO..oo00ooO,
		[5] = o0000..OOOoO..OoO0oOO,
		[6] = Ooooo..OOOoO..oO00O,
	},
	[ 15] = { -- table(72310bb)
		[1] = Ooooo..Ooooo..oO00O,
		[2] = Ooooo..OOOO..OO00o,
		[3] = o0000..oooOO0..o0000,
		[4] = o0000..OoO0oOO..OOOO,
		[5] = oO00O..o0000..oo00ooO,
		[6] = Ooooo..oo00ooO..o0000,
		[7] = Ooooo..OoO0oOO..OO00o,
		[8] = Ooooo..o0000..OoO0oOO,
	},
	[ 16] = { -- table(4a949d8)
		[1] = Ooooo..OOOoO..oO00O,
		[2] = o0000..oO00O..OOOoO,
	},
	[ 17] = { -- table(5a47131)
		[1] = Ooooo..Ooooo..oO00O,
		[2] = oO00O..oO00O..Ooooo,
		[3] = o0000..o0000..oo00ooO,
		[4] = Ooooo..OO00o..oo00ooO,
		[5] = o0000..OO00o..OO00o,
		[6] = o0000..oO00O..oO00O,
		[7] = o0000..oO00oo..o0000,
		[8] = oO00O..Ooooo..OO00o,
	},
	[ 18] = { -- table(e675016)
		[1] = Ooooo..oO00O..OOOO,
		[2] = o0000..oO00O..oooOO0,
	},
	[ 19] = { -- table(367fd97)
		[1] = o0000..OoO0oOO..oO00oo,
		[2] = o0000..OOOoO..OoO0oOO,
		[3] = o0000..oooOO0..o0000,
		[4] = oO00O..oO00O..OOOoO,
		[5] = o0000..OoO0oOO..OoO0oOO,
	},
	[ 20] = { -- table(c552b84)
		[ 1] = Ooooo..oO00O..oO00oo,
		[ 2] = Ooooo..OOOO..OoO0oOO,
		[ 3] = oO00O..OOOoO..oO00O,
		[ 4] = oO00O..OOOoO..OoO0oOO,
		[ 5] = Ooooo..oooOO0..oo00ooO,
		[ 6] = Ooooo..oO00oo..OOOO,
		[ 7] = OO00o..Ooooo..oO00oo,
		[ 8] = o0000..oo00ooO..oO00oo,
		[ 9] = Ooooo..OOOO..OOOO,
		[10] = Ooooo..OO00o..oo00ooO,
		[11] = o0000..OoO0oOO..OOOoO,
		[12] = Ooooo..OOOoO..o0000,
		[13] = OO00o..o0000..Ooooo,
		[14] = o0000..OoO0oOO..Ooooo,
		[15] = OO00o..Ooooo..oO00oo,
		[16] = Ooooo..OO00o..oO00O,
		[17] = o0000..oo00ooO..OoO0oOO,
		[18] = oO00O..oooOO0..oO00O,
		[19] = OO00o..o0000..OoO0oOO,
		[20] = Ooooo..o0000..OOOoO,
		[21] = Ooooo..oooOO0..o0000,
		[22] = OO00o..oo00ooO..oO00O,
		[23] = oO00O..OOOoO..OO00o,
		[24] = Ooooo..oo00ooO..o0000,
		[25] = oO00O..o0000..OoO0oOO,
		[26] = Ooooo..OO00o..oo00ooO,
		[27] = oO00O..o0000..oO00O,
		[28] = Ooooo..oo00ooO..OO00o,
		[29] = Ooooo..OOOO..OOOoO,
		[30] = Ooooo..OO00o..oO00O,
		[31] = oO00O..OOOO..o0000,
	},
	[ 21] = { -- table(f9def6d)
		[1] = o0000..OO00o..OOOO,
		[2] = Ooooo..oo00ooO..Ooooo,
	},
	[ 22] = { -- table(8057a2)
		[1] = oO00O..o0000..o0000,
		[2] = oO00O..OO00o..OOOO,
		[3] = oO00O..OOOO..OoO0oOO,
		[4] = o0000..oO00oo..Ooooo,
	},
	[ 23] = { -- table(aa4dc33)
		[1] = Ooooo..oO00oo..Ooooo,
		[2] = Ooooo..OOOO..OO00o,
		[3] = oO00O..o0000..OO00o,
		[4] = Ooooo..oo00ooO..OOOoO,
		[5] = oO00O..OO00o..oO00oo,
		[6] = Ooooo..oO00O..oO00oo,
	},
	[ 24] = { -- table(5bb7bf0)
		[1] = oO00O..OO00o..oO00oo,
		[2] = Ooooo..OOOO..oO00O,
		[3] = Ooooo..oO00oo..oo00ooO,
		[4] = o0000..OoO0oOO..OOOoO,
	},
	[ 25] = { -- table(c371569)
		[1] = o0000..OO00o..OoO0oOO,
		[2] = o0000..oo00ooO..oO00oo,
		[3] = o0000..OOOO..o0000,
		[4] = Ooooo..oooOO0..oO00O,
		[5] = o0000..oO00oo..Ooooo,
	},
	[ 26] = { -- table(4304bee)
		[1] = Ooooo..o0000..OOOoO,
		[2] = oO00O..OO00o..OOOoO,
		[3] = Ooooo..OO00o..OO00o,
		[4] = o0000..OOOoO..oO00oo,
		[5] = o0000..OO00o..OO00o,
		[6] = o0000..o0000..OOOoO,
	},
	[ 27] = { -- table(7c7088f)
		[1] = oO00O..oO00oo..OOOoO,
		[2] = o0000..OO00o..oO00O,
		[3] = Ooooo..oooOO0..OOOO,
		[4] = o0000..oooOO0..o0000,
		[5] = oO00O..oO00oo..o0000,
		[6] = o0000..OOOoO..o0000,
		[7] = Ooooo..oO00O..OoO0oOO,
		[8] = oO00O..oO00O..OO00o,
	},
	[ 28] = { -- table(1f4671c)
		[1] = o0000..oO00O..oO00O,
		[2] = o0000..o0000..oO00O,
	},
	[ 29] = { -- table(8229f25)
		[1] = oO00O..oO00O..OO00o,
		[2] = Ooooo..OO00o..oooOO0,
		[3] = oO00O..oO00O..OO00o,
		[4] = o0000..Ooooo..OO00o,
		[5] = Ooooo..OOOoO..OoO0oOO,
		[6] = oO00O..OO00o..OOOoO,
		[7] = Ooooo..OoO0oOO..oO00O,
		[8] = Ooooo..oO00oo..OOOO,
	},
	[ 30] = { -- table(ed938fa)
		[1] = o0000..Ooooo..Ooooo,
		[2] = Ooooo..OO00o..OoO0oOO,
	},
	[ 31] = { -- table(d359eab)
		[1] = oO00O..OOOoO..OOOO,
		[2] = o0000..oO00O..o0000,
		[3] = o0000..OoO0oOO..oooOO0,
		[4] = Ooooo..o0000..OOOoO,
		[5] = oO00O..o0000..OoO0oOO,
	},
	[ 32] = { -- table(96ed908)
		[ 1] = oO00O..OOOoO..oO00O,
		[ 2] = Ooooo..Ooooo..o0000,
		[ 3] = Ooooo..OOOoO..OOOoO,
		[ 4] = OO00o..OOOoO..OO00o,
		[ 5] = Ooooo..oO00oo..OO00o,
		[ 6] = Ooooo..oO00O..OoO0oOO,
		[ 7] = OO00o..o0000..oO00O,
		[ 8] = oO00O..oooOO0..OOOO,
		[ 9] = oO00O..OOOoO..OO00o,
		[10] = OO00o..OOOoO..oo00ooO,
		[11] = oO00O..o0000..OOOO,
		[12] = Ooooo..oo00ooO..OOOO,
		[13] = oO00O..OoO0oOO..OOOoO,
		[14] = oO00O..Ooooo..oO00oo,
		[15] = oO00O..OoO0oOO..OOOoO,
		[16] = OO00o..Ooooo..OoO0oOO,
		[17] = Ooooo..oo00ooO..oO00oo,
		[18] = Ooooo..OoO0oOO..OO00o,
		[19] = OO00o..oooOO0..oo00ooO,
		[20] = Ooooo..OOOoO..oooOO0,
		[21] = Ooooo..oO00oo..oooOO0,
		[22] = OO00o..Ooooo..Ooooo,
		[23] = OO00o..o0000..OOOO,
		[24] = Ooooo..o0000..oO00oo,
		[25] = Ooooo..oO00O..oO00oo,
		[26] = oO00O..OOOO..oo00ooO,
		[27] = Ooooo..OOOoO..oO00oo,
		[28] = oO00oo..oO00oo,
		[29] = o0000..o0000..OOOO,
		[30] = Ooooo..OOOoO..o0000,
		[31] = o0000..o0000..o0000,
	},
	[ 33] = { -- table(e8308a1)
		[1] = Ooooo..OO00o..OO00o,
		[2] = o0000..OOOoO..OOOoO,
	},
	[ 34] = { -- table(7f1eac6)
		[1] = o0000..o0000..OO00o,
		[2] = Ooooo..oO00oo..oO00oo,
		[3] = oO00O..o0000..oO00oo,
		[4] = oO00O..Ooooo..Ooooo,
	},
	[ 35] = { -- table(2ad7a87)
		[1] = oO00O..o0000..Ooooo,
		[2] = oO00O..OOOO..oO00O,
		[3] = oO00O..o0000..Ooooo,
		[4] = oO00O..oO00O..OOOoO,
		[5] = o0000..o0000..oO00oo,
	},
	[ 36] = { -- table(a9c7db4)
		[1] = oO00O..oO00O..OoO0oOO,
		[2] = Ooooo..o0000..o0000,
		[3] = oO00O..o0000..OO00o,
		[4] = Ooooo..oO00oo..oO00O,
		[5] = Ooooo..oO00oo..oO00oo,
		[6] = Ooooo..oO00O..oo00ooO,
		[7] = oO00O..OOOO..oo00ooO,
	},
	[ 37] = { -- table(268ddd)
		[1] = oO00O..oO00O..oo00ooO,
		[2] = Ooooo..oo00ooO..OoO0oOO,
	},
	[ 38] = { -- table(591ed52)
		[1] = oO00O..OO00o..OOOoO,
		[2] = oO00O..o0000..oo00ooO,
		[3] = Ooooo..oO00O..OOOO,
		[4] = oO00O..OOOO..oooOO0,
		[5] = o0000..oo00ooO..OO00o,
		[6] = oO00O..oO00O..OO00o,
		[7] = o0000..oo00ooO..oO00O,
	},
	[ 39] = { -- table(4dd3823)
		[1] = oO00O..oO00O..OOOO,
		[2] = o0000..oo00ooO..OOOO,
		[3] = o0000..OoO0oOO..oO00O,
		[4] = o0000..oO00O..OO00o,
		[5] = oO00O..OOOO..oooOO0,
	},
	[ 40] = { -- table(75dc120)
		[ 1] = Ooooo..oO00O..oo00ooO,
		[ 2] = OO00o..OOOO..Ooooo,
		[ 3] = Ooooo..OO00o..Ooooo,
		[ 4] = oO00O..OOOoO..oooOO0,
		[ 5] = o0000..oO00oo..OO00o,
		[ 6] = OO00o..Ooooo..OOOoO,
		[ 7] = oO00O..o0000..OoO0oOO,
		[ 8] = oO00O..OOOO..oo00ooO,
		[ 9] = o0000..oO00oo..OoO0oOO,
		[10] = oO00O..oo00ooO..Ooooo,
		[11] = OO00o..o0000..oO00oo,
		[12] = oO00O..o0000..OOOoO,
		[13] = oO00O..oO00O..oO00oo,
		[14] = o0000..oooOO0..oO00O,
		[15] = oO00O..OOOoO..OOOoO,
		[16] = oO00O..OO00o..OoO0oOO,
		[17] = oO00O..OoO0oOO..oO00oo,
		[18] = oO00O..OO00o..o0000,
		[19] = Ooooo..oO00oo..OoO0oOO,
		[20] = oO00O..OoO0oOO..oo00ooO,
		[21] = Ooooo..OOOoO..oo00ooO,
		[22] = oO00O..o0000..oO00oo,
		[23] = Ooooo..oo00ooO..OOOoO,
		[24] = Ooooo..oO00O..o0000,
		[25] = Ooooo..OoO0oOO..oo00ooO,
		[26] = oO00O..OOOoO..Ooooo,
		[27] = o0000..oooOO0..OoO0oOO,
		[28] = o0000..oO00oo..oo00ooO,
		[29] = OoO0oOO..OOOO,
		[30] = Ooooo..Ooooo..oO00O,
		[31] = o0000..oO00oo..Ooooo,
	},
	[ 41] = { -- table(2832ad9)
		[1] = Ooooo..oO00O..oooOO0,
		[2] = o0000..OO00o..oO00O,
	},
	[ 42] = { -- table(5bd8c9e)
		[1] = Ooooo..Ooooo..oO00O,
		[2] = Ooooo..o0000..OO00o,
		[3] = oO00O..OOOO..OO00o,
		[4] = oO00O..o0000..OoO0oOO,
	},
	[ 43] = { -- table(2c1337f)
		[1] = oO00O..Ooooo..oo00ooO,
		[2] = o0000..o0000..oooOO0,
		[3] = Ooooo..OO00o..oO00O,
		[4] = o0000..o0000..OoO0oOO,
		[5] = oO00O..OO00o..Ooooo,
	},
	[ 44] = { -- table(d2dcf4c)
		[1] = Ooooo..oO00O..oo00ooO,
		[2] = Ooooo..OO00o..o0000,
		[3] = oO00O..OO00o..oO00oo,
		[4] = o0000..Ooooo..o0000,
		[5] = oO00O..OO00o..OO00o,
		[6] = oO00O..Ooooo..OO00o,
		[7] = o0000..oO00O..OO00o,
	},
	[ 45] = { -- table(2729b95)
		[1] = o0000..oO00O..o0000,
		[2] = o0000..oooOO0..oooOO0,
		[3] = o0000..oooOO0..o0000,
		[4] = Ooooo..oooOO0..OO00o,
		[5] = o0000..oO00oo..oo00ooO,
		[6] = oO00O..OOOO..OO00o,
	},
	[ 46] = { -- table(71d4aa)
		[1] = o0000..oooOO0..OOOoO,
		[2] = oO00O..OO00o..OOOO,
		[3] = OoO0oOO..oo00ooO,
		[4] = oO00O..o0000..oooOO0,
	},
	[ 47] = { -- table(4bf889b)
		[1] = Ooooo..o0000..oo00ooO,
		[2] = Ooooo..OoO0oOO..oooOO0,
		[3] = o0000..OO00o..OoO0oOO,
		[4] = Ooooo..OO00o..OOOoO,
		[5] = o0000..OO00o..o0000,
	},
	[ 48] = { -- table(40e9438)
		[1] = oO00O..o0000..oo00ooO,
		[2] = o0000..Ooooo..oO00O,
		[3] = o0000..OoO0oOO..o0000,
		[4] = oO00O..Ooooo..OO00o,
		[5] = o0000..OOOoO..oO00oo,
		[6] = o0000..OoO0oOO..OoO0oOO,
	},
	[ 49] = { -- table(6ae5c11)
		[1] = Ooooo..OoO0oOO..OO00o,
		[2] = Ooooo..OoO0oOO..Ooooo,
		[3] = Ooooo..OoO0oOO..oO00oo,
		[4] = o0000..oO00oo..oO00oo,
		[5] = Ooooo..oooOO0..oo00ooO,
		[6] = o0000..OOOO..oooOO0,
		[7] = o0000..Ooooo..OOOoO,
		[8] = oO00O..OOOO..o0000,
	},
	[ 50] = { -- table(e709176)
		[1] = Ooooo..oooOO0..oooOO0,
		[2] = oooOO0..OoO0oOO,
	},
	[ 51] = { -- table(9841377)
		[1] = oO00O..OOOoO..OoO0oOO,
		[2] = Ooooo..o0000..OoO0oOO,
		[3] = Ooooo..oO00oo..OoO0oOO,
		[4] = oO00O..OO00o..OOOoO,
		[5] = Ooooo..Ooooo..o0000,
		[6] = Ooooo..OOOO..oooOO0,
		[7] = o0000..o0000..oO00oo,
		[8] = oO00O..OOOO..oooOO0,
	},
	[ 52] = { -- table(34bbe4)
		[1] = oooOO0..oO00O,
		[2] = oO00oo..OOOoO,
	},
	[ 53] = { -- table(e0ba84d)
		[1] = Ooooo..OOOoO..oooOO0,
		[2] = o0000..OoO0oOO..OOOO,
		[3] = o0000..OO00o..OO00o,
		[4] = o0000..oO00oo..oO00O,
		[5] = o0000..OO00o..oo00ooO,
	},
	[ 54] = { -- table(cc4f02)
		[1] = o0000..oooOO0..oO00O,
		[2] = Ooooo..oo00ooO..OOOoO,
		[3] = o0000..Ooooo..OOOoO,
		[4] = o0000..oO00oo..oO00O,
		[5] = Ooooo..OO00o..Ooooo,
		[6] = Ooooo..OOOO..oo00ooO,
	},
	[ 55] = { -- table(49c7013)
		[1] = Ooooo..OOOO..oo00ooO,
		[2] = oO00O..OOOoO..oO00oo,
		[3] = oO00O..OOOO..Ooooo,
		[4] = Ooooo..OOOO..oO00O,
	},
	[ 56] = { -- table(273b250)
		[1] = Ooooo..OO00o..OO00o,
		[2] = o0000..OO00o..OoO0oOO,
		[3] = Ooooo..o0000..OO00o,
		[4] = o0000..oooOO0..oooOO0,
		[5] = oO00O..OO00o..OOOoO,
	},
	[ 57] = { -- table(5777c49)
		[1] = Ooooo..OoO0oOO..oo00ooO,
		[2] = Ooooo..OoO0oOO..o0000,
		[3] = Ooooo..oo00ooO..o0000,
		[4] = o0000..OoO0oOO..OoO0oOO,
		[5] = Ooooo..OOOO..oo00ooO,
		[6] = o0000..Ooooo..oo00ooO,
	},
	[ 58] = { -- table(534594e)
		[1] = o0000..oo00ooO..oO00oo,
		[2] = oO00O..OO00o..OoO0oOO,
		[3] = o0000..oO00O..OoO0oOO,
		[4] = Ooooo..oo00ooO..oO00oo,
		[5] = oO00O..OO00o..Ooooo,
		[6] = Ooooo..OOOO..oooOO0,
		[7] = o0000..OO00o..OOOoO,
		[8] = o0000..oO00O..oo00ooO,
	},
	[ 59] = { -- table(ad3fa6f)
		[1] = o0000..oO00O..oo00ooO,
		[2] = o0000..oO00oo..OOOoO,
		[3] = Ooooo..Ooooo..Ooooo,
	},
	[ 60] = { -- table(369a37c)
		[1] = o0000..oo00ooO..oo00ooO,
		[2] = o0000..Ooooo..oO00oo,
		[3] = o0000..oO00O..o0000,
		[4] = oO00O..OOOO..Ooooo,
		[5] = oO00O..oO00oo..oO00O,
		[6] = o0000..OO00o..OoO0oOO,
		[7] = Ooooo..OOOO..o0000,
		[8] = Ooooo..oooOO0..OOOoO,
	},
	[ 61] = { -- table(1b29405)
		[1] = o0000..oooOO0..oo00ooO,
		[2] = o0000..oooOO0..OO00o,
	},
	[ 62] = { -- table(300bc5a)
		[1] = o0000..oo00ooO..oO00O,
		[2] = Ooooo..oO00O..OoO0oOO,
		[3] = Ooooo..oO00oo..OOOO,
		[4] = Ooooo..OO00o..oO00oo,
		[5] = Ooooo..OoO0oOO..oo00ooO,
		[6] = o0000..OOOoO..OO00o,
	},
	[ 63] = { -- table(84fce8b)
		[1] = oO00O..OO00o..oO00oo,
		[2] = oO00O..Ooooo..OOOO,
		[3] = o0000..OOOO..o0000,
		[4] = oO00O..oO00oo..Ooooo,
	},
	[ 64] = { -- table(56b7b68)
		[1] = oO00O..OOOoO..oO00oo,
		[2] = oO00O..OOOoO..oooOO0,
		[3] = oO00O..oO00O..oo00ooO,
		[4] = Ooooo..o0000..OOOO,
		[5] = o0000..OOOoO..Ooooo,
		[6] = Ooooo..Ooooo..o0000,
		[7] = Ooooo..oO00oo..OOOoO,
		[8] = Ooooo..oooOO0..OOOoO,
	},
	[ 65] = { -- table(8cd6b81)
		[1] = OoO0oOO..oO00oo,
		[2] = OOOoO..oooOO0,
		[3] = o0000..OO00o..oO00O,
	},
	[ 66] = { -- table(cfe4426)
		[1] = oO00O..oO00oo..OOOoO,
		[2] = Ooooo..OoO0oOO..oO00oo,
		[3] = oO00O..o0000..o0000,
		[4] = o0000..o0000..o0000,
		[5] = o0000..oooOO0..OOOO,
		[6] = o0000..oO00oo..OOOO,
	},
	[ 67] = { -- table(c6ac867)
		[1] = o0000..oO00O..OOOoO,
		[2] = Ooooo..oO00O..o0000,
		[3] = Ooooo..OoO0oOO..OoO0oOO,
		[4] = Ooooo..Ooooo..Ooooo,
	},
	[ 68] = { -- table(930e614)
		[1] = oO00O..OOOO..o0000,
		[2] = o0000..Ooooo..OOOoO,
		[3] = oO00O..OO00o..OOOoO,
		[4] = oO00O..OO00o..oooOO0,
		[5] = o0000..oO00oo..oO00oo,
	},
	[ 69] = { -- table(7643ebd)
		[1] = oO00O..oO00O..OO00o,
		[2] = Ooooo..oO00oo..OOOO,
		[3] = Ooooo..o0000..oo00ooO,
		[4] = Ooooo..oO00O..oO00O,
		[5] = o0000..Ooooo..OOOoO,
		[6] = oO00O..Ooooo..OoO0oOO,
	},
	[ 70] = { -- table(3fa7cb2)
		[1] = o0000..oooOO0..OOOoO,
		[2] = o0000..oo00ooO..OO00o,
		[3] = o0000..oO00O..oO00oo,
		[4] = Ooooo..OO00o..oo00ooO,
		[5] = Ooooo..OO00o..OO00o,
		[6] = oO00O..Ooooo..Ooooo,
		[7] = o0000..OOOoO..OO00o,
		[8] = o0000..oooOO0..oo00ooO,
	},
	[ 71] = { -- table(7518403)
		[1] = o0000..oooOO0..oO00O,
		[2] = Ooooo..OoO0oOO..OOOoO,
		[3] = oooOO0..oooOO0,
	},
	[ 72] = { -- table(1404f80)
		[1] = o0000..OoO0oOO..OoO0oOO,
		[2] = Ooooo..o0000..OoO0oOO,
		[3] = oO00O..o0000..OOOoO,
		[4] = Ooooo..OO00o..oooOO0,
		[5] = o0000..oo00ooO..oooOO0,
		[6] = o0000..Ooooo..OO00o,
		[7] = oO00O..Ooooo..oO00O,
		[8] = oO00O..OOOO..OO00o,
	},
	[ 73] = { -- table(d9b09b9)
		[1] = oo00ooO..OoO0oOO,
		[2] = Ooooo..OOOoO..OOOO,
		[3] = Ooooo..OOOoO..Ooooo,
	},
	[ 74] = { -- table(60fb1fe)
		[1] = o0000..OoO0oOO..oo00ooO,
		[2] = oO00O..OOOoO..o0000,
		[3] = Ooooo..oo00ooO..oO00O,
		[4] = o0000..OO00o..o0000,
		[5] = Ooooo..oO00O..oO00oo,
	},
	[ 75] = { -- table(55e5d5f)
		[ 1] = OO00o..oooOO0..oO00oo,
		[ 2] = Ooooo..oooOO0..oO00O,
		[ 3] = oO00O..Ooooo..OoO0oOO,
		[ 4] = Ooooo..oO00oo..OOOoO,
		[ 5] = Ooooo..OoO0oOO..Ooooo,
		[ 6] = oO00O..OOOO..oo00ooO,
		[ 7] = Ooooo..oO00oo..Ooooo,
		[ 8] = o0000..oO00oo..OO00o,
		[ 9] = Ooooo..OO00o..OoO0oOO,
		[10] = OO00o..oooOO0..OO00o,
		[11] = Ooooo..OO00o..Ooooo,
		[12] = oO00O..OO00o..oooOO0,
		[13] = Ooooo..OOOoO..oO00O,
		[14] = oO00O..OoO0oOO..OoO0oOO,
		[15] = oO00O..oO00O..o0000,
		[16] = OO00o..oO00O..Ooooo,
		[17] = o0000..OoO0oOO..oO00oo,
		[18] = o0000..oooOO0..OoO0oOO,
		[19] = oO00O..oO00oo..OoO0oOO,
		[20] = oO00O..oO00O..oooOO0,
		[21] = oO00O..oooOO0..OoO0oOO,
		[22] = oO00O..OO00o..OoO0oOO,
		[23] = o0000..OoO0oOO..oO00oo,
		[24] = o0000..oO00oo..oO00O,
		[25] = oO00O..Ooooo..oO00oo,
		[26] = oO00O..Ooooo..OOOoO,
		[27] = oO00O..OOOO..oO00oo,
		[28] = Ooooo..oo00ooO..oooOO0,
		[29] = Ooooo..o0000..oO00O,
		[30] = o0000..OO00o..oO00oo,
		[31] = oo00ooO..OO00o,
	},
	[ 76] = { -- table(1ae3ac)
		[1] = oO00O..Ooooo..oooOO0,
		[2] = Ooooo..oo00ooO..oo00ooO,
	},
	[ 77] = { -- table(fd98875)
		[1] = o0000..OO00o..oO00O,
		[2] = Ooooo..OOOO..o0000,
		[3] = o0000..oO00O..oO00oo,
		[4] = Ooooo..Ooooo..oO00O,
	},
	[ 78] = { -- table(6b0f00a)
		[1] = o0000..OOOoO..OoO0oOO,
		[2] = o0000..OOOoO..OoO0oOO,
		[3] = oO00O..OO00o..oO00oo,
		[4] = oO00O..Ooooo..Ooooo,
		[5] = Ooooo..OO00o..Ooooo,
		[6] = oO00O..Ooooo..OOOoO,
	},
	[ 79] = { -- table(435707b)
		[1] = Ooooo..oooOO0..OoO0oOO,
		[2] = oO00O..o0000..OOOO,
		[3] = Ooooo..OOOoO..oO00oo,
		[4] = oO00O..oO00oo..OOOO,
	},
	[ 80] = { -- table(d288e98)
		[1] = Ooooo..OOOoO..OOOoO,
		[2] = oO00O..Ooooo..Ooooo,
		[3] = o0000..OO00o..oO00oo,
		[4] = Ooooo..OOOoO..OOOoO,
		[5] = Ooooo..OoO0oOO..OoO0oOO,
	},
	[ 81] = { -- table(74736f1)
		[1] = Ooooo..o0000..OOOO,
		[2] = oO00O..oO00oo..oO00O,
		[3] = Ooooo..OOOO..OoO0oOO,
		[4] = o0000..oo00ooO..oO00O,
		[5] = Ooooo..oO00oo..o0000,
		[6] = Ooooo..o0000..oo00ooO,
	},
	[ 82] = { -- table(b7602d6)
		[1] = Ooooo..OO00o..o0000,
		[2] = Ooooo..OOOO..oO00O,
		[3] = Ooooo..oO00oo..OOOoO,
		[4] = oO00O..OOOO..OoO0oOO,
		[5] = o0000..oo00ooO..oooOO0,
		[6] = Ooooo..OOOO..oO00O,
		[7] = Ooooo..oO00oo..Ooooo,
		[8] = o0000..OOOoO..OoO0oOO,
	},
	[ 83] = { -- table(da09957)
		[1] = o0000..OOOO..OO00o,
		[2] = Ooooo..oO00oo..oo00ooO,
	},
	[ 84] = { -- table(c63fc44)
		[1] = o0000..oo00ooO..OoO0oOO,
		[2] = Ooooo..o0000..OoO0oOO,
		[3] = o0000..Ooooo..oO00O,
		[4] = Ooooo..oooOO0..OOOO,
		[5] = o0000..oooOO0..OOOoO,
		[6] = Ooooo..o0000..o0000,
		[7] = Ooooo..o0000..OoO0oOO,
		[8] = Ooooo..oooOO0..o0000,
	},
	[ 85] = { -- table(e07512d)
		[1] = Ooooo..OO00o..OoO0oOO,
		[2] = o0000..o0000..oo00ooO,
	},
	[ 86] = { -- table(9a77662)
		[1] = Ooooo..oO00O..oo00ooO,
		[2] = o0000..OoO0oOO..OOOO,
		[3] = Ooooo..oo00ooO..o0000,
		[4] = o0000..o0000..oO00O,
		[5] = oO00O..o0000..OoO0oOO,
	},
	[ 87] = { -- table(42b73f3)
		[ 1] = oO00O..oo00ooO..OoO0oOO,
		[ 2] = OO00o..Ooooo..OoO0oOO,
		[ 3] = oO00O..oO00O..oo00ooO,
		[ 4] = Ooooo..oo00ooO..OO00o,
		[ 5] = oO00O..OO00o..OOOO,
		[ 6] = Ooooo..OOOO..oo00ooO,
		[ 7] = Ooooo..oooOO0..Ooooo,
		[ 8] = OO00o..OOOO..oO00O,
		[ 9] = Ooooo..OOOoO..o0000,
		[10] = OO00o..OOOO..OO00o,
		[11] = o0000..OoO0oOO..oO00O,
		[12] = Ooooo..OO00o..OOOoO,
		[13] = OO00o..oooOO0..OOOoO,
		[14] = Ooooo..Ooooo..OoO0oOO,
		[15] = Ooooo..OO00o..oo00ooO,
		[16] = Ooooo..OOOoO..oo00ooO,
		[17] = oO00O..oo00ooO..oO00O,
		[18] = o0000..OOOoO..oO00O,
		[19] = oO00O..OoO0oOO..OOOoO,
		[20] = oO00O..o0000..oo00ooO,
		[21] = oO00O..oO00O..oooOO0,
		[22] = oO00O..OOOoO..OOOoO,
		[23] = o0000..oo00ooO..oO00O,
		[24] = o0000..oO00oo..o0000,
		[25] = Ooooo..oo00ooO..oO00oo,
		[26] = oO00O..oo00ooO..oO00oo,
		[27] = Ooooo..o0000..oo00ooO,
		[28] = o0000..Ooooo..o0000,
		[29] = o0000..OOOO..OOOoO,
		[30] = o0000..oooOO0..o0000,
		[31] = OoO0oOO..OOOoO,
	},
	[ 88] = { -- table(4c698b0)
		[1] = Ooooo..OoO0oOO..oO00oo,
		[2] = oO00O..oO00O..oO00oo,
	},
	[ 89] = { -- table(334d329)
		[1] = o0000..OoO0oOO..OoO0oOO,
		[2] = o0000..OO00o..oo00ooO,
		[3] = o0000..oooOO0..oo00ooO,
		[4] = oO00O..oO00oo..oo00ooO,
	},
	[ 90] = { -- table(8a96ae)
		[1] = Ooooo..Ooooo..OOOoO,
		[2] = oO00O..oO00oo..oO00O,
		[3] = o0000..oo00ooO..OOOO,
		[4] = Ooooo..Ooooo..OoO0oOO,
		[5] = oO00O..Ooooo..oooOO0,
		[6] = o0000..OO00o..OoO0oOO,
		[7] = Ooooo..o0000..o0000,
		[8] = o0000..oooOO0..oo00ooO,
	},
	[ 91] = { -- table(d7f5c4f)
		[1] = o0000..OOOoO..OOOO,
		[2] = o0000..oooOO0..OOOO,
		[3] = OoO0oOO..o0000,
		[4] = oO00O..OOOO..oO00oo,
		[5] = o0000..Ooooo..oO00O,
		[6] = Ooooo..OOOoO..OOOoO,
		[7] = oooOO0..OoO0oOO,
	},
	[ 92] = { -- table(1748fdc)
		[1] = oO00O..Ooooo..oO00oo,
		[2] = o0000..oO00O..Ooooo,
		[3] = o0000..Ooooo..oO00O,
		[4] = o0000..oooOO0..oo00ooO,
		[5] = oO00O..OOOO..oO00O,
		[6] = Ooooo..OoO0oOO..oO00O,
		[7] = Ooooo..o0000..Ooooo,
		[8] = Ooooo..oo00ooO..OOOO,
	},
	[ 93] = { -- table(29e78e5)
		[1] = Ooooo..o0000..o0000,
	},
	[ 94] = { -- table(c6d6fba)
		[1] = oO00O..oO00O..oo00ooO,
		[2] = Ooooo..oO00O..oo00ooO,
		[3] = Ooooo..oo00ooO..OoO0oOO,
		[4] = oO00O..OOOoO..OOOO,
		[5] = o0000..OOOoO..OOOO,
		[6] = Ooooo..oooOO0..oooOO0,
		[7] = oO00O..OOOoO..oO00O,
		[8] = oO00O..OOOO..OOOoO,
	},
	[ 95] = { -- table(67f6e6b)
		[1] = o0000..OO00o..OOOO,
	},
	[ 96] = { -- table(9a8cdc8)
		[1] = oO00O..Ooooo..oO00O,
		[2] = Ooooo..oooOO0..Ooooo,
		[3] = o0000..oooOO0..oO00O,
		[4] = o0000..oo00ooO..OoO0oOO,
	},
	[ 97] = { -- table(c42be61)
		[1] = Ooooo..oO00O..OO00o,
		[2] = Ooooo..oO00oo..Ooooo,
		[3] = o0000..oO00oo..OoO0oOO,
		[4] = Ooooo..oO00oo..OOOO,
		[5] = o0000..OOOoO..OO00o,
		[6] = o0000..OOOoO..OOOO,
		[7] = o0000..oO00O..OOOO,
		[8] = Ooooo..oooOO0..OO00o,
	},
	[ 98] = { -- table(e72cd86)
		[1] = o0000..OO00o..OO00o,
	},
	[ 99] = { -- table(d248647)
		[1] = o0000..oo00ooO..OOOO,
		[2] = oO00O..oO00oo..o0000,
		[3] = Ooooo..o0000..OOOoO,
		[4] = oO00O..oooOO0..Ooooo,
		[5] = o0000..oO00O..o0000,
		[6] = Ooooo..oo00ooO..o0000,
		[7] = Ooooo..Ooooo..oO00oo,
		[8] = o0000..oO00oo..Ooooo,
	},
	[100] = { -- table(b60fe74)
		[1] = o0000..OOOoO..oo00ooO,
		[2] = o0000..oO00O..OoO0oOO,
		[3] = OoO0oOO..oo00ooO,
		[4] = o0000..OOOO..oooOO0,
		[5] = oooOO0..o0000,
		[6] = OOOoO..o0000,
	},
	[101] = { -- table(78bdf9d)
		[1] = OoO0oOO..OOOoO,
	},
	[102] = { -- table(51e3c12)
		[1] = o0000..oooOO0..oO00oo,
		[2] = o0000..oooOO0..OO00o,
	},
	[103] = { -- table(c193fe3)
		[1] = Ooooo..oooOO0..o0000,
		[2] = Ooooo..oO00oo..OOOoO,
		[3] = Ooooo..OOOO..oo00ooO,
		[4] = o0000..Ooooo..oO00O,
		[5] = oO00O..oO00oo..Ooooo,
	},
	[104] = { -- table(4c98de0)
		[ 1] = oO00O..OOOO..OO00o,
		[ 2] = o0000..OOOoO..OOOoO,
		[ 3] = oO00O..OOOO..oO00oo,
		[ 4] = OOOoO..OoO0oOO,
		[ 5] = oO00O..o0000..oO00O,
		[ 6] = o0000..OO00o..oO00oo,
		[ 7] = o0000..OO00o..oooOO0,
		[ 8] = Ooooo..OOOO..oo00ooO,
		[ 9] = OoO0oOO..OOOO,
		[10] = oO00O..OOOO..oooOO0,
		[11] = o0000..oooOO0..OOOO,
		[12] = o0000..oO00O..Ooooo,
		[13] = o0000..oooOO0..oO00oo,
		[14] = o0000..OOOO..o0000,
		[15] = o0000..oo00ooO..oO00O,
		[16] = oo00ooO..oO00O,
		[17] = Ooooo..OO00o..OO00o,
		[18] = o0000..OO00o..OoO0oOO,
		[19] = Ooooo..OOOoO..OOOO,
		[20] = Ooooo..Ooooo..OoO0oOO,
		[21] = o0000..oO00O..OO00o,
		[22] = oO00O..OOOO..oO00O,
		[23] = Ooooo..Ooooo..Ooooo,
	},
}    local HcXweiNB6666s=function(x,xx)   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end   local a,b=_G['assert'](x,xx)   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end   return b end   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end    while true do    if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end   if EfICQXH[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000)] then   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end     if    OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o  then             local dOZPodJ={ -- table(e4bd899)
	[  1] = { -- table(1a0075e)
		[1] = Ooooo..Ooooo..oO00O,
		[2] = Ooooo..OO00o..oO00oo,
		[3] = Ooooo..OOOoO,
		[4] = oo00ooO..OOOoO,
		[5] = OoO0oOO..Ooooo,
	},
	[  2] = { -- table(415f73f)
		[1] = o0000..o0000..oo00ooO,
		[2] = oooOO0,
		[3] = OO00o..o0000,
		[4] = Ooooo..Ooooo..OoO0oOO,
		[5] = o0000..OOOO..OO00o,
		[6] = Ooooo..OOOO..oooOO0,
		[7] = o0000..oO00oo..oooOO0,
	},
	[  3] = { -- table(869a80c)
		[1] = o0000..OoO0oOO..OoO0oOO,
		[2] = o0000..oO00O..oooOO0,
	},
	[  4] = { -- table(b786555)
		[1] = oooOO0..OoO0oOO,
		[2] = Ooooo..o0000..oO00O,
		[3] = o0000..OoO0oOO..oO00O,
		[4] = o0000..o0000..Ooooo,
		[5] = Ooooo..oO00O..oO00O,
		[6] = OOOoO..OO00o,
		[7] = oO00oo..oO00oo,
	},
	[  5] = { -- table(5e13b6a)
		[1] = Ooooo..OO00o..o0000,
		[2] = o0000..o0000,
		[3] = OOOoO..oooOO0,
		[4] = Ooooo..OO00o..oooOO0,
		[5] = Ooooo..OO00o..OOOoO,
	},
	[  6] = { -- table(efcc85b)
		[ 1] = o0000..OOOoO..OOOO,
		[ 2] = o0000..OOOO..Ooooo,
		[ 3] = Ooooo..OO00o,
		[ 4] = OOOoO..o0000,
		[ 5] = o0000..oo00ooO..OOOoO,
		[ 6] = o0000..oO00oo..OoO0oOO,
		[ 7] = oO00oo..oO00oo,
		[ 8] = o0000..OOOO..o0000,
		[ 9] = o0000..o0000..oooOO0,
		[10] = oO00oo..oooOO0,
		[11] = oooOO0..OOOoO,
		[12] = o0000..oO00oo..Ooooo,
		[13] = o0000..Ooooo..OO00o,
		[14] = Ooooo..oO00O..OoO0oOO,
		[15] = o0000..OO00o..OoO0oOO,
		[16] = OoO0oOO..Ooooo,
		[17] = o0000..oO00O..o0000,
		[18] = o0000..Ooooo..oooOO0,
		[19] = oooOO0..o0000,
		[20] = o0000..OOOO..OoO0oOO,
		[21] = Ooooo..oO00O,
		[22] = o0000..OOOoO,
		[23] = o0000..oooOO0..OoO0oOO,
		[24] = o0000..oooOO0..oooOO0,
		[25] = o0000..oo00ooO..OoO0oOO,
		[26] = OoO0oOO..oo00ooO,
		[27] = o0000..OOOoO..o0000,
		[28] = Ooooo..OOOoO..o0000,
		[29] = o0000..Ooooo..o0000,
		[30] = o0000..OOOO..OOOoO,
		[31] = o0000..oo00ooO..oO00O,
	},
	[  7] = { -- table(80f38f8)
		[1] = Ooooo..Ooooo..oo00ooO,
		[2] = oooOO0,
	},
	[  8] = { -- table(9a701d1)
		[1] = o0000..oo00ooO..Ooooo,
		[2] = o0000..oooOO0..OOOoO,
		[3] = oO00oo..o0000,
		[4] = o0000..oO00oo..oO00O,
	},
	[  9] = { -- table(74fa436)
		[1] = Ooooo..o0000..OO00o,
		[2] = o0000..oO00O..OO00o,
		[3] = o0000..oooOO0..OoO0oOO,
		[4] = Ooooo..oO00O..oooOO0,
		[5] = oO00oo..OO00o,
	},
	[ 10] = { -- table(8b58f37)
		[1] = o0000..oooOO0..OO00o,
		[2] = o0000..oooOO0..OOOoO,
		[3] = oooOO0..oooOO0,
		[4] = OO00o..OOOoO,
		[5] = oooOO0..Ooooo,
		[6] = Ooooo..oO00O..o0000,
		[7] = OoO0oOO..o0000,
	},
	[ 11] = { -- table(27aeca4)
		[1] = o0000..oooOO0..OOOO,
		[2] = o0000..Ooooo,
		[3] = oo00ooO,
		[4] = o0000..OOOoO,
		[5] = oooOO0..OOOoO,
		[6] = o0000..oo00ooO,
	},
	[ 12] = { -- table(d48ea0d)
		[1] = oO00O..OOOO,
		[2] = Ooooo..o0000..Ooooo,
		[3] = Ooooo..Ooooo,
		[4] = o0000..OoO0oOO..oO00oo,
	},
	[ 13] = { -- table(269cdc2)
		[1] = o0000..OOOO..OOOoO,
		[2] = o0000..o0000..OOOoO,
		[3] = o0000..OOOoO..OOOO,
		[4] = o0000..OOOoO..OOOO,
		[5] = oO00oo,
	},
	[ 14] = { -- table(9c9e7d3)
		[1] = Ooooo..OOOO..OOOoO,
		[2] = o0000..oooOO0..o0000,
		[3] = oooOO0..Ooooo,
		[4] = o0000..o0000,
		[5] = oO00oo..OOOO,
		[6] = o0000..OO00o..oO00oo,
	},
	[ 15] = { -- table(fcc2f10)
		[1] = o0000..OOOO..oooOO0,
		[2] = OoO0oOO..oO00O,
		[3] = oO00oo..o0000,
		[4] = oooOO0..oO00O,
		[5] = Ooooo..OOOO..OoO0oOO,
		[6] = o0000..oo00ooO..oO00O,
		[7] = o0000..OoO0oOO..oO00O,
		[8] = o0000..OOOO..OOOoO,
	},
	[ 16] = { -- table(6a71a09)
		[1] = o0000..OoO0oOO..oo00ooO,
		[2] = oo00ooO..oO00O,
	},
	[ 17] = { -- table(b0b040e)
		[1] = o0000..OOOO..oooOO0,
		[2] = Ooooo..Ooooo..o0000,
		[3] = oo00ooO,
		[4] = o0000..oO00O..o0000,
		[5] = oO00O..OOOoO,
		[6] = oO00O..OOOoO,
		[7] = oO00oo..OOOO,
		[8] = Ooooo..o0000..OOOO,
	},
	[ 18] = { -- table(fc12e2f)
		[1] = o0000..oooOO0..oO00O,
		[2] = oo00ooO..Ooooo,
	},
	[ 19] = { -- table(8ad2c3c)
		[1] = oo00ooO..OO00o,
		[2] = OO00o..OOOoO,
		[3] = oO00oo..oO00oo,
		[4] = Ooooo..Ooooo..OOOoO,
		[5] = oo00ooO..oO00O,
	},
	[ 20] = { -- table(79e4dc5)
		[ 1] = oo00ooO,
		[ 2] = o0000..oo00ooO,
		[ 3] = o0000..oooOO0..OoO0oOO,
		[ 4] = o0000..Ooooo..OoO0oOO,
		[ 5] = o0000..oO00O..OOOO,
		[ 6] = oooOO0..OOOoO,
		[ 7] = o0000..OoO0oOO..oooOO0,
		[ 8] = oO00O..oO00O,
		[ 9] = oO00O..Ooooo,
		[10] = o0000..OoO0oOO,
		[11] = OO00o,
		[12] = o0000..o0000..oo00ooO,
		[13] = o0000..oooOO0..OoO0oOO,
		[14] = oO00O..o0000,
		[15] = Ooooo..oO00O..OoO0oOO,
		[16] = o0000..Ooooo,
		[17] = o0000..oO00oo,
		[18] = Ooooo..oO00O..oO00oo,
		[19] = o0000..OoO0oOO..o0000,
		[20] = Ooooo..OoO0oOO,
		[21] = o0000..Ooooo..OoO0oOO,
		[22] = Ooooo..OOOoO..Ooooo,
		[23] = o0000..oo00ooO..o0000,
		[24] = o0000..OO00o..OO00o,
		[25] = OoO0oOO..o0000,
		[26] = oO00oo..Ooooo,
		[27] = o0000..oooOO0..o0000,
		[28] = Ooooo..Ooooo..oooOO0,
		[29] = o0000..OOOoO..oooOO0,
		[30] = o0000..OoO0oOO..oooOO0,
		[31] = Ooooo..OOOoO..oO00O,
	},
	[ 21] = { -- table(577531a)
		[1] = Ooooo..OoO0oOO,
		[2] = o0000..oO00oo..oooOO0,
	},
	[ 22] = { -- table(f3c7e4b)
		[1] = Ooooo..o0000..OOOO,
		[2] = Ooooo..Ooooo..OOOO,
		[3] = Ooooo..OOOO..OO00o,
		[4] = OO00o..oO00oo,
	},
	[ 23] = { -- table(43ed028)
		[1] = o0000..OO00o..oooOO0,
		[2] = oo00ooO..oo00ooO,
		[3] = Ooooo..OOOO..OOOO,
		[4] = o0000..oo00ooO..OOOO,
		[5] = Ooooo..oO00O..oO00oo,
		[6] = o0000..oO00O..oO00O,
	},
	[ 24] = { -- table(91b0141)
		[1] = Ooooo..OO00o..oooOO0,
		[2] = OoO0oOO..OoO0oOO,
		[3] = o0000..oooOO0..o0000,
		[4] = oo00ooO..o0000,
	},
	[ 25] = { -- table(42786e6)
		[1] = oO00O..oO00O,
		[2] = oo00ooO..OoO0oOO,
		[3] = oO00O,
		[4] = o0000..oO00oo..OOOoO,
		[5] = oO00oo..o0000,
	},
	[ 26] = { -- table(bd2b427)
		[1] = OoO0oOO..oo00ooO,
		[2] = Ooooo..oO00O..OOOoO,
		[3] = o0000..oO00O..Ooooo,
		[4] = OOOoO..OoO0oOO,
		[5] = OO00o..OOOoO,
		[6] = oo00ooO,
	},
	[ 27] = { -- table(8c4c6d4)
		[1] = Ooooo..OO00o..OoO0oOO,
		[2] = oO00O..Ooooo,
		[3] = o0000..oO00oo..OOOO,
		[4] = OOOoO..OO00o,
		[5] = Ooooo..OOOoO..Ooooo,
		[6] = OOOoO..oO00O,
		[7] = o0000..oO00O..oo00ooO,
		[8] = Ooooo..Ooooo..OOOO,
	},
	[ 28] = { -- table(c55707d)
		[1] = oooOO0..OoO0oOO,
		[2] = oO00oo..OO00o,
	},
	[ 29] = { -- table(6552b72)
		[1] = Ooooo..o0000..oo00ooO,
		[2] = o0000..oO00O..oO00oo,
		[3] = Ooooo..Ooooo..OO00o,
		[4] = oooOO0,
		[5] = o0000..OOOoO..OOOO,
		[6] = Ooooo..OO00o..oooOO0,
		[7] = o0000..OoO0oOO..Ooooo,
		[8] = o0000..OO00o..oO00oo,
	},
	[ 30] = { -- table(1ac6bc3)
		[1] = oO00oo..OOOoO,
		[2] = o0000..OoO0oOO..oo00ooO,
	},
	[ 31] = { -- table(b117c40)
		[1] = Ooooo..oO00O..oo00ooO,
		[2] = o0000..oooOO0,
		[3] = OoO0oOO..Ooooo,
		[4] = o0000..OOOO..OOOoO,
		[5] = Ooooo..OOOO..oO00O,
	},
	[ 32] = { -- table(3cd9779)
		[ 1] = o0000..Ooooo..OOOoO,
		[ 2] = oO00O..OOOO,
		[ 3] = oo00ooO..o0000,
		[ 4] = Ooooo..Ooooo..OO00o,
		[ 5] = o0000..o0000..oO00oo,
		[ 6] = OOOoO..OO00o,
		[ 7] = o0000..oo00ooO..OO00o,
		[ 8] = Ooooo..o0000..oooOO0,
		[ 9] = o0000..oo00ooO..oO00oo,
		[10] = Ooooo..Ooooo..OoO0oOO,
		[11] = o0000..o0000..OoO0oOO,
		[12] = o0000..OO00o..oooOO0,
		[13] = o0000..oO00oo..Ooooo,
		[14] = o0000..oO00oo..OOOoO,
		[15] = Ooooo..OOOO..oo00ooO,
		[16] = o0000..OoO0oOO..oo00ooO,
		[17] = o0000..o0000..oO00O,
		[18] = o0000..OOOoO..oooOO0,
		[19] = Ooooo..OOOoO..OOOO,
		[20] = oooOO0..o0000,
		[21] = o0000..Ooooo..OOOoO,
		[22] = o0000..OoO0oOO..o0000,
		[23] = Ooooo..oO00O..oooOO0,
		[24] = oooOO0..OoO0oOO,
		[25] = oo00ooO,
		[26] = o0000..Ooooo..Ooooo,
		[27] = o0000..o0000..OO00o,
		[28] = OoO0oOO,
		[29] = oO00oo..Ooooo,
		[30] = Ooooo..OOOO..OOOoO,
		[31] = oO00oo..oO00O,
	},
	[ 33] = { -- table(3468cbe)
		[1] = o0000..oO00O..oO00O,
		[2] = OO00o..OOOO,
	},
	[ 34] = { -- table(ce0011f)
		[1] = o0000..oO00O,
		[2] = o0000..OO00o..oO00oo,
		[3] = Ooooo..o0000..o0000,
		[4] = Ooooo..OOOO..oO00oo,
	},
	[ 35] = { -- table(8b21c6c)
		[1] = Ooooo..o0000..Ooooo,
		[2] = Ooooo..OOOO..Ooooo,
		[3] = Ooooo..o0000..OO00o,
		[4] = Ooooo..o0000..oo00ooO,
		[5] = o0000..oO00O,
	},
	[ 36] = { -- table(73235)
		[1] = Ooooo..oO00O..oO00oo,
		[2] = o0000..o0000..OOOO,
		[3] = o0000..OoO0oOO..oo00ooO,
		[4] = o0000..OOOoO..oo00ooO,
		[5] = o0000..OOOoO..oO00oo,
		[6] = o0000..oO00O..oO00oo,
		[7] = o0000..OoO0oOO..oooOO0,
	},
	[ 37] = { -- table(e5ab6ca)
		[1] = Ooooo..oO00O..OOOoO,
		[2] = o0000..oo00ooO..oO00oo,
	},
	[ 38] = { -- table(a8d903b)
		[1] = Ooooo..OO00o..Ooooo,
		[2] = Ooooo..o0000..oooOO0,
		[3] = o0000..o0000..OO00o,
		[4] = Ooooo..oO00O..oooOO0,
		[5] = oooOO0..OoO0oOO,
		[6] = Ooooo..Ooooo..oO00oo,
		[7] = oo00ooO..Ooooo,
	},
	[ 39] = { -- table(8da9358)
		[1] = Ooooo..o0000..oo00ooO,
		[2] = oO00oo..oO00oo,
		[3] = oo00ooO..oo00ooO,
		[4] = Ooooo..OO00o,
		[5] = o0000..OoO0oOO..o0000,
	},
	[ 40] = { -- table(c05bcb1)
		[ 1] = o0000..OOOO,
		[ 2] = Ooooo..o0000..o0000,
		[ 3] = oO00oo..oo00ooO,
		[ 4] = o0000..Ooooo..oooOO0,
		[ 5] = o0000..oO00oo,
		[ 6] = Ooooo..OO00o..OOOO,
		[ 7] = OoO0oOO..OOOO,
		[ 8] = o0000..OOOoO..OOOoO,
		[ 9] = o0000,
		[10] = o0000..OOOoO..oO00O,
		[11] = Ooooo..Ooooo..OOOoO,
		[12] = o0000..oo00ooO..Ooooo,
		[13] = o0000..OOOO..oO00O,
		[14] = o0000..Ooooo,
		[15] = o0000..oO00oo..oo00ooO,
		[16] = o0000..o0000..oo00ooO,
		[17] = Ooooo..Ooooo..oO00O,
		[18] = Ooooo..OOOO..OO00o,
		[19] = OO00o..o0000,
		[20] = Ooooo..o0000..Ooooo,
		[21] = o0000..o0000..oO00oo,
		[22] = oo00ooO..OOOoO,
		[23] = o0000..o0000..Ooooo,
		[24] = OoO0oOO..OO00o,
		[25] = oooOO0..OOOO,
		[26] = o0000..oO00oo..oO00oo,
		[27] = oO00O..oooOO0,
		[28] = o0000..o0000..o0000,
		[29] = OO00o..Ooooo,
		[30] = o0000..oooOO0..oooOO0,
		[31] = o0000..o0000..OO00o,
	},
	[ 41] = { -- table(fd57596)
		[1] = o0000..Ooooo..oO00oo,
		[2] = Ooooo..oo00ooO,
	},
	[ 42] = { -- table(fbaf517)
		[1] = o0000..Ooooo..Ooooo,
		[2] = OoO0oOO..OO00o,
		[3] = o0000..OoO0oOO..OoO0oOO,
		[4] = Ooooo..OOOO..oO00O,
	},
	[ 43] = { -- table(118d04)
		[1] = Ooooo..Ooooo..oo00ooO,
		[2] = o0000..oO00oo,
		[3] = o0000..OO00o..OOOoO,
		[4] = Ooooo,
		[5] = Ooooo..oO00O..OoO0oOO,
	},
	[ 44] = { -- table(58872ed)
		[1] = o0000..oO00O..OOOoO,
		[2] = o0000..OO00o..OOOO,
		[3] = Ooooo..oO00O..OOOO,
		[4] = o0000..oO00oo,
		[5] = Ooooo..oO00O..OO00o,
		[6] = Ooooo..Ooooo..Ooooo,
		[7] = Ooooo..oO00O,
	},
	[ 45] = { -- table(e6b5522)
		[1] = o0000..oO00oo,
		[2] = oO00oo..o0000,
		[3] = OOOoO..oooOO0,
		[4] = o0000..oO00oo..OoO0oOO,
		[5] = OOOoO..oo00ooO,
		[6] = Ooooo..OOOO..o0000,
	},
	[ 46] = { -- table(1efcbb3)
		[1] = oooOO0..oO00oo,
		[2] = Ooooo..oO00O..oO00oo,
		[3] = o0000,
		[4] = Ooooo..OOOO..oO00O,
	},
	[ 47] = { -- table(29c7570)
		[1] = o0000..OOOO..Ooooo,
		[2] = Ooooo..OOOO..OOOO,
		[3] = OOOoO..o0000,
		[4] = o0000..oO00O..oooOO0,
		[5] = OO00o..OOOO,
	},
	[ 48] = { -- table(d0650e9)
		[1] = Ooooo..OOOO..o0000,
		[2] = o0000..oO00O,
		[3] = oooOO0..OoO0oOO,
		[4] = Ooooo..Ooooo..oooOO0,
		[5] = OOOoO..oooOO0,
		[6] = OoO0oOO..Ooooo,
	},
	[ 49] = { -- table(58da16e)
		[1] = o0000..oooOO0..oo00ooO,
		[2] = o0000..oo00ooO..o0000,
		[3] = o0000..oo00ooO..oO00oo,
		[4] = OO00o..OoO0oOO,
		[5] = o0000..oO00oo..OoO0oOO,
		[6] = OoO0oOO,
		[7] = Ooooo..OO00o,
		[8] = o0000..oo00ooO..oooOO0,
	},
	[ 50] = { -- table(d91700f)
		[1] = Ooooo..Ooooo..Ooooo,
		[2] = Ooooo..oooOO0,
	},
	[ 51] = { -- table(1ab789c)
		[1] = Ooooo..OO00o..oO00O,
		[2] = o0000..OOOO..oo00ooO,
		[3] = o0000..OOOoO..OoO0oOO,
		[4] = Ooooo..Ooooo..oo00ooO,
		[5] = o0000..o0000..Ooooo,
		[6] = o0000..OOOO..OoO0oOO,
		[7] = o0000..OOOoO,
		[8] = o0000..OoO0oOO..oO00O,
	},
	[ 52] = { -- table(96a12a5)
		[1] = o0000..oO00oo,
		[2] = o0000..OOOO,
	},
	[ 53] = { -- table(476667a)
		[1] = o0000..OO00o..OOOoO,
		[2] = oooOO0..oO00oo,
		[3] = oO00O..OoO0oOO,
		[4] = OOOoO..oO00O,
		[5] = oO00O..Ooooo,
	},
	[ 54] = { -- table(5fefe2b)
		[1] = OOOoO..oo00ooO,
		[2] = o0000..oO00oo..OoO0oOO,
		[3] = o0000..o0000,
		[4] = OOOoO..oo00ooO,
		[5] = o0000..oO00O..Ooooo,
		[6] = o0000..OOOO..OOOoO,
	},
	[ 55] = { -- table(f458288)
		[1] = o0000..OOOO..OoO0oOO,
		[2] = Ooooo..OOOoO..Ooooo,
		[3] = Ooooo..OOOO..OOOoO,
		[4] = oo00ooO..OoO0oOO,
	},
	[ 56] = { -- table(b8e3421)
		[1] = o0000..Ooooo..oo00ooO,
		[2] = OOOoO..Ooooo,
		[3] = o0000..o0000..oO00oo,
		[4] = oO00oo..OoO0oOO,
		[5] = Ooooo..OO00o..OO00o,
	},
	[ 57] = { -- table(1f47046)
		[1] = o0000..oo00ooO..o0000,
		[2] = o0000..oo00ooO..o0000,
		[3] = o0000..oO00oo..OoO0oOO,
		[4] = o0000..OOOO..Ooooo,
		[5] = o0000..OOOO..OoO0oOO,
		[6] = Ooooo..o0000,
	},
	[ 58] = { -- table(b6d5207)
		[1] = oooOO0..OOOO,
		[2] = Ooooo..oO00O..oo00ooO,
		[3] = Ooooo..OoO0oOO,
		[4] = o0000..oO00oo..OoO0oOO,
		[5] = Ooooo..oO00O..oO00O,
		[6] = o0000..OOOO..OoO0oOO,
		[7] = OO00o..OO00o,
		[8] = Ooooo..OO00o,
	},
	[ 59] = { -- table(4f43f34)
		[1] = oo00ooO..oo00ooO,
		[2] = o0000..o0000..OO00o,
		[3] = o0000..oooOO0..o0000,
	},
	[ 60] = { -- table(d78f15d)
		[1] = oooOO0..Ooooo,
		[2] = o0000..OOOoO,
		[3] = Ooooo..o0000,
		[4] = o0000..oo00ooO..OOOoO,
		[5] = Ooooo..OOOoO..OO00o,
		[6] = OOOoO..o0000,
		[7] = o0000..OOOO..OOOO,
		[8] = o0000..oO00oo..o0000,
	},
	[ 61] = { -- table(f74ad2)
		[1] = o0000..Ooooo..oooOO0,
		[2] = o0000..Ooooo..oO00O,
	},
	[ 62] = { -- table(28307a3)
		[1] = oO00oo..oo00ooO,
		[2] = o0000..Ooooo..oO00O,
		[3] = o0000..OO00o..oO00oo,
		[4] = o0000..OO00o..o0000,
		[5] = o0000..oo00ooO..oo00ooO,
		[6] = OOOoO..o0000,
	},
	[ 63] = { -- table(9301aa0)
		[1] = Ooooo..OO00o..oooOO0,
		[2] = Ooooo..o0000..oO00oo,
		[3] = OO00o,
		[4] = Ooooo..OO00o..oo00ooO,
	},
	[ 64] = { -- table(9584659)
		[1] = Ooooo..OO00o..OOOO,
		[2] = Ooooo..OO00o..oO00oo,
		[3] = Ooooo..Ooooo..oo00ooO,
		[4] = OoO0oOO..oO00O,
		[5] = OO00o..oO00O,
		[6] = o0000..Ooooo..oO00O,
		[7] = o0000..oO00oo..OO00o,
		[8] = o0000..oO00oo..o0000,
	},
	[ 65] = { -- table(1db421e)
		[1] = OO00o..oo00ooO,
		[2] = oo00ooO,
		[3] = OoO0oOO..OOOoO,
	},
	[ 66] = { -- table(9b47aff)
		[1] = Ooooo..OOOoO..OOOO,
		[2] = o0000..oo00ooO..OOOO,
		[3] = o0000..OoO0oOO..oooOO0,
		[4] = oO00oo,
		[5] = oO00oo..OOOO,
		[6] = OOOoO..oooOO0,
	},
	[ 67] = { -- table(f8c40cc)
		[1] = oO00O..oO00oo,
		[2] = o0000..Ooooo..oooOO0,
		[3] = Ooooo..OOOO..Ooooo,
		[4] = o0000..OOOO..oo00ooO,
	},
	[ 68] = { -- table(43def15)
		[1] = o0000..oo00ooO..OOOoO,
		[2] = Ooooo..oo00ooO,
		[3] = Ooooo..OO00o..oooOO0,
		[4] = Ooooo..oO00O..OoO0oOO,
		[5] = oO00oo..OOOoO,
	},
	[ 69] = { -- table(c75622a)
		[1] = Ooooo..o0000..oooOO0,
		[2] = o0000..OOOoO..OOOO,
		[3] = o0000..OOOO..oO00oo,
		[4] = o0000..oO00O..oO00oo,
		[5] = Ooooo..oO00oo,
		[6] = Ooooo..Ooooo..Ooooo,
	},
	[ 70] = { -- table(85fc81b)
		[1] = OOOoO..OoO0oOO,
		[2] = oooOO0..oO00O,
		[3] = Ooooo..oO00oo,
		[4] = o0000..oO00O..o0000,
		[5] = o0000..oO00O..OOOoO,
		[6] = Ooooo..Ooooo..OO00o,
		[7] = OOOoO..oO00O,
		[8] = oO00oo..OO00o,
	},
	[ 71] = { -- table(fa29db8)
		[1] = o0000..Ooooo..oO00O,
		[2] = Ooooo..OO00o..OO00o,
		[3] = Ooooo..oO00oo,
	},
	[ 72] = { -- table(89b6791)
		[1] = oo00ooO..oO00O,
		[2] = o0000..OOOO..oo00ooO,
		[3] = Ooooo..OOOO..OOOoO,
		[4] = o0000..oO00O..OOOO,
		[5] = oooOO0..oo00ooO,
		[6] = Ooooo..oO00oo,
		[7] = Ooooo..Ooooo..Ooooo,
		[8] = o0000..OoO0oOO..OOOO,
	},
	[ 73] = { -- table(edf76f6)
		[1] = OO00o..OOOO,
		[2] = Ooooo..OOOO..Ooooo,
		[3] = Ooooo..OOOO..OO00o,
	},
	[ 74] = { -- table(3a8caf7)
		[1] = oo00ooO..oO00oo,
		[2] = Ooooo..oO00O..oooOO0,
		[3] = o0000..oooOO0..oo00ooO,
		[4] = oO00O..o0000,
		[5] = o0000..Ooooo..OOOO,
	},
	[ 75] = { -- table(ebfdd64)
		[ 1] = Ooooo..OO00o..oo00ooO,
		[ 2] = oo00ooO..Ooooo,
		[ 3] = o0000..OOOoO..OOOoO,
		[ 4] = oO00O..OOOoO,
		[ 5] = o0000..OO00o..OO00o,
		[ 6] = o0000..Ooooo..oO00O,
		[ 7] = oO00O..oO00O,
		[ 8] = o0000..o0000,
		[ 9] = oo00ooO..o0000,
		[10] = Ooooo..OO00o..OOOoO,
		[11] = OOOoO..o0000,
		[12] = Ooooo..o0000..OO00o,
		[13] = Ooooo..OOOO,
		[14] = Ooooo..oO00O..oo00ooO,
		[15] = o0000..OO00o..OO00o,
		[16] = Ooooo..OOOO..o0000,
		[17] = Ooooo..oO00O,
		[18] = OO00o..Ooooo,
		[19] = o0000..OO00o..o0000,
		[20] = o0000..OOOoO..o0000,
		[21] = Ooooo..oO00O..oooOO0,
		[22] = o0000..o0000..oo00ooO,
		[23] = Ooooo..oO00O,
		[24] = Ooooo..oO00oo,
		[25] = OoO0oOO..oo00ooO,
		[26] = o0000..oO00O..OoO0oOO,
		[27] = o0000..oO00oo..OO00o,
		[28] = Ooooo..oO00O..OOOO,
		[29] = o0000..oO00oo..OOOoO,
		[30] = o0000..OOOO..OOOO,
		[31] = oO00O..oO00oo,
	},
	[ 76] = { -- table(c7debcd)
		[1] = Ooooo..o0000..oO00oo,
		[2] = o0000..oooOO0..oO00O,
	},
	[ 77] = { -- table(d040c82)
		[1] = OO00o..Ooooo,
		[2] = oo00ooO..o0000,
		[3] = oO00O..o0000,
		[4] = o0000..OOOO..oooOO0,
	},
	[ 78] = { -- table(5151f93)
		[1] = OO00o..OO00o,
		[2] = OO00o..oO00O,
		[3] = Ooooo..oO00O..Ooooo,
		[4] = Ooooo..o0000..oooOO0,
		[5] = o0000..oO00O..Ooooo,
		[6] = Ooooo..Ooooo..Ooooo,
	},
	[ 79] = { -- table(84f6bd0)
		[1] = o0000..oo00ooO..OOOO,
		[2] = Ooooo..OOOO..oO00oo,
		[3] = o0000..OOOoO..OoO0oOO,
		[4] = Ooooo..OO00o..oO00oo,
	},
	[ 80] = { -- table(f8a77c9)
		[1] = o0000..oO00O..OoO0oOO,
		[2] = Ooooo..Ooooo..OOOoO,
		[3] = OO00o..oo00ooO,
		[4] = o0000..OO00o..oooOO0,
		[5] = o0000..OoO0oOO..oo00ooO,
	},
	[ 81] = { -- table(cea6ece)
		[1] = OoO0oOO..oO00O,
		[2] = Ooooo..OOOoO..oO00O,
		[3] = OoO0oOO..oooOO0,
		[4] = oo00ooO..oO00oo,
		[5] = o0000..oO00oo..Ooooo,
		[6] = o0000..o0000..o0000,
	},
	[ 82] = { -- table(ee821ef)
		[1] = o0000..Ooooo..OOOoO,
		[2] = OoO0oOO..Ooooo,
		[3] = o0000..OOOoO..OOOoO,
		[4] = o0000..OoO0oOO..Ooooo,
		[5] = oooOO0..oo00ooO,
		[6] = o0000..OOOO..OOOoO,
		[7] = o0000..oO00oo..o0000,
		[8] = OO00o..OOOoO,
	},
	[ 83] = { -- table(10774fc)
		[1] = OOOoO..OOOO,
		[2] = Ooooo..o0000..OoO0oOO,
	},
	[ 84] = { -- table(cb9c785)
		[1] = oooOO0..oO00O,
		[2] = o0000..OOOO..oo00ooO,
		[3] = o0000..oO00O,
		[4] = o0000..OOOoO..oO00O,
		[5] = oO00oo..oO00oo,
		[6] = o0000..o0000..oO00O,
		[7] = o0000..o0000..oo00ooO,
		[8] = o0000..OOOoO..oooOO0,
	},
	[ 85] = { -- table(bc2a9da)
		[1] = o0000..OoO0oOO..Ooooo,
		[2] = oO00oo..oooOO0,
	},
	[ 86] = { -- table(a3eee0b)
		[1] = o0000..Ooooo..oO00oo,
		[2] = oooOO0..oO00oo,
		[3] = o0000..oooOO0..oO00oo,
		[4] = oO00O,
		[5] = Ooooo..OOOO..oO00O,
	},
	[ 87] = { -- table(d4e4e8)
		[ 1] = o0000..oO00oo..o0000,
		[ 2] = Ooooo..oO00O..oo00ooO,
		[ 3] = o0000..oO00oo..OO00o,
		[ 4] = OOOoO..OO00o,
		[ 5] = o0000..OoO0oOO..Ooooo,
		[ 6] = Ooooo..oO00O,
		[ 7] = OO00o..oO00O,
		[ 8] = Ooooo..OOOoO..OOOO,
		[ 9] = oo00ooO..oO00O,
		[10] = o0000..oooOO0..OOOoO,
		[11] = Ooooo,
		[12] = o0000..o0000..Ooooo,
		[13] = Ooooo..OO00o..Ooooo,
		[14] = oO00oo..oo00ooO,
		[15] = oO00oo..o0000,
		[16] = Ooooo..oooOO0,
		[17] = Ooooo..o0000..OOOO,
		[18] = o0000..oO00oo,
		[19] = o0000..oO00oo..oooOO0,
		[20] = o0000..oO00O..Ooooo,
		[21] = o0000..OoO0oOO..OOOoO,
		[22] = o0000..Ooooo..OO00o,
		[23] = o0000..OOOO,
		[24] = Ooooo..OO00o,
		[25] = OOOoO..oo00ooO,
		[26] = Ooooo..OOOO..OOOO,
		[27] = oooOO0..oO00oo,
		[28] = oO00oo..OO00o,
		[29] = OOOoO..oooOO0,
		[30] = o0000..Ooooo..OOOoO,
		[31] = OO00o..oooOO0,
	},
	[ 88] = { -- table(bd45701)
		[1] = o0000..oo00ooO..OOOoO,
		[2] = Ooooo..Ooooo..o0000,
	},
	[ 89] = { -- table(7b189a6)
		[1] = OoO0oOO..oo00ooO,
		[2] = Ooooo..oo00ooO,
		[3] = oooOO0..oO00O,
		[4] = Ooooo..OOOoO..Ooooo,
	},
	[ 90] = { -- table(aec5fe7)
		[1] = o0000..OOOO..OoO0oOO,
		[2] = Ooooo..OOOoO..Ooooo,
		[3] = oooOO0..OOOO,
		[4] = o0000..o0000..Ooooo,
		[5] = Ooooo..o0000..oo00ooO,
		[6] = OOOoO..o0000,
		[7] = o0000..o0000..OOOO,
		[8] = oO00oo..OO00o,
	},
	[ 91] = { -- table(f876794)
		[1] = o0000..OOOO..o0000,
		[2] = o0000..Ooooo..Ooooo,
		[3] = oO00O..OoO0oOO,
		[4] = Ooooo..OOOoO..OOOO,
		[5] = oooOO0..OOOO,
		[6] = Ooooo..OOOO..OOOO,
		[7] = Ooooo..OOOoO,
	},
	[ 92] = { -- table(eae623d)
		[1] = Ooooo..o0000..OOOO,
		[2] = Ooooo..o0000,
		[3] = o0000..oO00O,
		[4] = oO00oo..o0000,
		[5] = o0000..OoO0oOO..OO00o,
		[6] = o0000..OoO0oOO..OOOoO,
		[7] = o0000..o0000..o0000,
		[8] = o0000..oO00oo..oO00oo,
	},
	[ 93] = { -- table(a5c9a32)
		[1] = o0000..oO00oo..Ooooo,
	},
	[ 94] = { -- table(5151383)
		[1] = Ooooo..Ooooo..Ooooo,
		[2] = o0000..Ooooo..oooOO0,
		[3] = o0000..oooOO0..OoO0oOO,
		[4] = Ooooo..oO00O..oO00O,
		[5] = OO00o..o0000,
		[6] = o0000..oooOO0..OoO0oOO,
		[7] = Ooooo..OOOoO..Ooooo,
		[8] = o0000..OoO0oOO..o0000,
	},
	[ 95] = { -- table(3d6900)
		[1] = OoO0oOO..o0000,
	},
	[ 96] = { -- table(623e539)
		[1] = Ooooo..o0000..OOOoO,
		[2] = o0000..oO00oo..o0000,
		[3] = oooOO0..oO00oo,
		[4] = oo00ooO..OoO0oOO,
	},
	[ 97] = { -- table(36277e)
		[1] = o0000..o0000..oo00ooO,
		[2] = o0000..OOOoO..o0000,
		[3] = OOOoO..OoO0oOO,
		[4] = o0000..OO00o..oO00O,
		[5] = OO00o..OOOoO,
		[6] = OOOoO..Ooooo,
		[7] = Ooooo..OoO0oOO,
		[8] = o0000..oO00oo..OOOO,
	},
	[ 98] = { -- table(8b64df)
		[1] = OoO0oOO..OOOoO,
	},
	[ 99] = { -- table(790152c)
		[1] = oO00oo..OO00o,
		[2] = Ooooo..OOOoO..OOOO,
		[3] = o0000..OOOO..OOOoO,
		[4] = Ooooo..OOOoO..OOOoO,
		[5] = Ooooo..Ooooo,
		[6] = o0000..oo00ooO..oO00O,
		[7] = o0000..Ooooo..OOOoO,
		[8] = OO00o..oo00ooO,
	},
	[100] = { -- table(ad49bf5)
		[1] = o0000..OOOO..OoO0oOO,
		[2] = OoO0oOO..o0000,
		[3] = OOOoO..OOOO,
		[4] = OOOoO..OoO0oOO,
		[5] = Ooooo..oO00O,
		[6] = oO00O,
	},
	[101] = { -- table(8893d8a)
		[1] = oO00oo..oO00O,
	},
	[102] = { -- table(5eb6ffb)
		[1] = oooOO0..oO00O,
		[2] = oooOO0..o0000,
	},
	[103] = { -- table(87f5818)
		[1] = o0000..OOOoO..OOOoO,
		[2] = o0000..OOOoO..OO00o,
		[3] = o0000..o0000..o0000,
		[4] = oo00ooO,
		[5] = Ooooo..OO00o..oO00oo,
	},
	[104] = { -- table(5a00271)
		[ 1] = Ooooo..Ooooo..OoO0oOO,
		[ 2] = oo00ooO..oO00oo,
		[ 3] = Ooooo..o0000..oooOO0,
		[ 4] = Ooooo..oooOO0,
		[ 5] = Ooooo..OO00o..OOOoO,
		[ 6] = oooOO0..oooOO0,
		[ 7] = oo00ooO..OOOO,
		[ 8] = o0000..oooOO0..oO00oo,
		[ 9] = Ooooo..OO00o,
		[10] = Ooooo..o0000..oo00ooO,
		[11] = o0000..oO00O..oo00ooO,
		[12] = oO00oo..oO00oo,
		[13] = o0000..o0000..o0000,
		[14] = o0000..oooOO0,
		[15] = o0000..OOOO..oO00oo,
		[16] = o0000..oo00ooO,
		[17] = o0000..oO00oo..oO00oo,
		[18] = o0000..o0000..oooOO0,
		[19] = o0000..oooOO0..OoO0oOO,
		[20] = o0000..oO00oo..OO00o,
		[21] = OOOoO..oooOO0,
		[22] = Ooooo..oO00O..OO00o,
		[23] = o0000..oO00O..OoO0oOO,
	},
}           if EfICQXH[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000)] then    if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end    local i_,i=nil,nil   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end        end     if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end   for i=_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000),#EfICQXH do         for i_=_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000),#EfICQXH[i] do         if EfICQXH[_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000)][_G[OoOoOoOO0..OoOoOoO00..OoOOoo000..oOoOOOo00..OoOOo000o..Oo0o0o0o0..OoO00oOO0..OoO0o000o](o0000)] then        if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end          EfICQXH[i][i_]= _G[Oo0O][oOo0]( EfICQXH[i][i_] - dOZPodJ[i][i_] )      if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end                end           if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end           end         if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end            end      if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end               end               end           if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end          break         if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_   
 end            end      
do    local SHcX=load
local load=function() end
x=_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[1][1],EfICQXH[1][2],EfICQXH[1][3],EfICQXH[1][4],EfICQXH[1][5]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[2][1],EfICQXH[2][2],EfICQXH[2][3],EfICQXH[2][4],EfICQXH[2][5],EfICQXH[2][6],EfICQXH[2][7]}))](load)
if x.short_src==_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[3][1],EfICQXH[3][2]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[4][1],EfICQXH[4][2],EfICQXH[4][3],EfICQXH[4][4],EfICQXH[4][5],EfICQXH[4][6],EfICQXH[4][7]}))]() then
load=SHcX
else
_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[5][1],EfICQXH[5][2],EfICQXH[5][3],EfICQXH[5][4],EfICQXH[5][5]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[6][1],EfICQXH[6][2],EfICQXH[6][3],EfICQXH[6][4],EfICQXH[6][5],EfICQXH[6][6],EfICQXH[6][7],EfICQXH[6][8],EfICQXH[6][9],EfICQXH[6][10],EfICQXH[6][11],EfICQXH[6][12],EfICQXH[6][13],EfICQXH[6][14],EfICQXH[6][15],EfICQXH[6][16],EfICQXH[6][17],EfICQXH[6][18],EfICQXH[6][19],EfICQXH[6][20],EfICQXH[6][21],EfICQXH[6][22],EfICQXH[6][23],EfICQXH[6][24],EfICQXH[6][25],EfICQXH[6][26],EfICQXH[6][27],EfICQXH[6][28],EfICQXH[6][29],EfICQXH[6][30],EfICQXH[6][31]})))
_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[7][1],EfICQXH[7][2]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[8][1],EfICQXH[8][2],EfICQXH[8][3],EfICQXH[8][4]}))]()
while true do end
end
x=_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[9][1],EfICQXH[9][2],EfICQXH[9][3],EfICQXH[9][4],EfICQXH[9][5]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[10][1],EfICQXH[10][2],EfICQXH[10][3],EfICQXH[10][4],EfICQXH[10][5],EfICQXH[10][6],EfICQXH[10][7]}))](load)
if x.what~=_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[11][1],EfICQXH[11][2],EfICQXH[11][3],EfICQXH[11][4],EfICQXH[11][5],EfICQXH[11][6]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[12][1],EfICQXH[12][2],EfICQXH[12][3],EfICQXH[12][4]}))](_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[13][1],EfICQXH[13][2],EfICQXH[13][3],EfICQXH[13][4],EfICQXH[13][5]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[14][1],EfICQXH[14][2],EfICQXH[14][3],EfICQXH[14][4],EfICQXH[14][5],EfICQXH[14][6]}))]({_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[15][1],EfICQXH[15][2],EfICQXH[15][3],EfICQXH[15][4],EfICQXH[15][5],EfICQXH[15][6],EfICQXH[15][7],EfICQXH[15][8]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[16][1],EfICQXH[16][2]}))),97,118,_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[17][1],EfICQXH[17][2],EfICQXH[17][3],EfICQXH[17][4],EfICQXH[17][5],EfICQXH[17][6],EfICQXH[17][7],EfICQXH[17][8]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[18][1],EfICQXH[18][2]})))})) then
_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[19][1],EfICQXH[19][2],EfICQXH[19][3],EfICQXH[19][4],EfICQXH[19][5]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[20][1],EfICQXH[20][2],EfICQXH[20][3],EfICQXH[20][4],EfICQXH[20][5],EfICQXH[20][6],EfICQXH[20][7],EfICQXH[20][8],EfICQXH[20][9],EfICQXH[20][10],EfICQXH[20][11],EfICQXH[20][12],EfICQXH[20][13],EfICQXH[20][14],EfICQXH[20][15],EfICQXH[20][16],EfICQXH[20][17],EfICQXH[20][18],EfICQXH[20][19],EfICQXH[20][20],EfICQXH[20][21],EfICQXH[20][22],EfICQXH[20][23],EfICQXH[20][24],EfICQXH[20][25],EfICQXH[20][26],EfICQXH[20][27],EfICQXH[20][28],EfICQXH[20][29],EfICQXH[20][30],EfICQXH[20][31]})))
_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[21][1],EfICQXH[21][2]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[22][1],EfICQXH[22][2],EfICQXH[22][3],EfICQXH[22][4]}))]()
while true do end
end
if x.source ~= _G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[23][1],EfICQXH[23][2],EfICQXH[23][3],EfICQXH[23][4],EfICQXH[23][5],EfICQXH[23][6]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[24][1],EfICQXH[24][2],EfICQXH[24][3],EfICQXH[24][4]}))](_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[25][1],EfICQXH[25][2],EfICQXH[25][3],EfICQXH[25][4],EfICQXH[25][5]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[26][1],EfICQXH[26][2],EfICQXH[26][3],EfICQXH[26][4],EfICQXH[26][5],EfICQXH[26][6]}))]({_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[27][1],EfICQXH[27][2],EfICQXH[27][3],EfICQXH[27][4],EfICQXH[27][5],EfICQXH[27][6],EfICQXH[27][7],EfICQXH[27][8]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[28][1],EfICQXH[28][2]}))),91,74,97,118,97,_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[29][1],EfICQXH[29][2],EfICQXH[29][3],EfICQXH[29][4],EfICQXH[29][5],EfICQXH[29][6],EfICQXH[29][7],EfICQXH[29][8]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[30][1],EfICQXH[30][2]})))})) then
_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[31][1],EfICQXH[31][2],EfICQXH[31][3],EfICQXH[31][4],EfICQXH[31][5]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[32][1],EfICQXH[32][2],EfICQXH[32][3],EfICQXH[32][4],EfICQXH[32][5],EfICQXH[32][6],EfICQXH[32][7],EfICQXH[32][8],EfICQXH[32][9],EfICQXH[32][10],EfICQXH[32][11],EfICQXH[32][12],EfICQXH[32][13],EfICQXH[32][14],EfICQXH[32][15],EfICQXH[32][16],EfICQXH[32][17],EfICQXH[32][18],EfICQXH[32][19],EfICQXH[32][20],EfICQXH[32][21],EfICQXH[32][22],EfICQXH[32][23],EfICQXH[32][24],EfICQXH[32][25],EfICQXH[32][26],EfICQXH[32][27],EfICQXH[32][28],EfICQXH[32][29],EfICQXH[32][30],EfICQXH[32][31]})))
_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[33][1],EfICQXH[33][2]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[34][1],EfICQXH[34][2],EfICQXH[34][3],EfICQXH[34][4]}))]()
while true do end
end
SHcX=gg.searchNumber
gg.searchNumber=function() end
x=_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[35][1],EfICQXH[35][2],EfICQXH[35][3],EfICQXH[35][4],EfICQXH[35][5]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[36][1],EfICQXH[36][2],EfICQXH[36][3],EfICQXH[36][4],EfICQXH[36][5],EfICQXH[36][6],EfICQXH[36][7]}))](gg.searchNumber)
if x.short_src==_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[37][1],EfICQXH[37][2]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[38][1],EfICQXH[38][2],EfICQXH[38][3],EfICQXH[38][4],EfICQXH[38][5],EfICQXH[38][6],EfICQXH[38][7]}))]() then
gg.searchNumber=SHcX
else
_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[39][1],EfICQXH[39][2],EfICQXH[39][3],EfICQXH[39][4],EfICQXH[39][5]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[40][1],EfICQXH[40][2],EfICQXH[40][3],EfICQXH[40][4],EfICQXH[40][5],EfICQXH[40][6],EfICQXH[40][7],EfICQXH[40][8],EfICQXH[40][9],EfICQXH[40][10],EfICQXH[40][11],EfICQXH[40][12],EfICQXH[40][13],EfICQXH[40][14],EfICQXH[40][15],EfICQXH[40][16],EfICQXH[40][17],EfICQXH[40][18],EfICQXH[40][19],EfICQXH[40][20],EfICQXH[40][21],EfICQXH[40][22],EfICQXH[40][23],EfICQXH[40][24],EfICQXH[40][25],EfICQXH[40][26],EfICQXH[40][27],EfICQXH[40][28],EfICQXH[40][29],EfICQXH[40][30],EfICQXH[40][31]})))
_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[41][1],EfICQXH[41][2]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[42][1],EfICQXH[42][2],EfICQXH[42][3],EfICQXH[42][4]}))]()
while true do end
end
x=_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[43][1],EfICQXH[43][2],EfICQXH[43][3],EfICQXH[43][4],EfICQXH[43][5]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[44][1],EfICQXH[44][2],EfICQXH[44][3],EfICQXH[44][4],EfICQXH[44][5],EfICQXH[44][6],EfICQXH[44][7]}))](gg.searchNumber)
if x.what~=_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[45][1],EfICQXH[45][2],EfICQXH[45][3],EfICQXH[45][4],EfICQXH[45][5],EfICQXH[45][6]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[46][1],EfICQXH[46][2],EfICQXH[46][3],EfICQXH[46][4]}))](_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[47][1],EfICQXH[47][2],EfICQXH[47][3],EfICQXH[47][4],EfICQXH[47][5]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[48][1],EfICQXH[48][2],EfICQXH[48][3],EfICQXH[48][4],EfICQXH[48][5],EfICQXH[48][6]}))]({_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[49][1],EfICQXH[49][2],EfICQXH[49][3],EfICQXH[49][4],EfICQXH[49][5],EfICQXH[49][6],EfICQXH[49][7],EfICQXH[49][8]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[50][1],EfICQXH[50][2]}))),97,118,_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[51][1],EfICQXH[51][2],EfICQXH[51][3],EfICQXH[51][4],EfICQXH[51][5],EfICQXH[51][6],EfICQXH[51][7],EfICQXH[51][8]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[52][1],EfICQXH[52][2]})))})) then
_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[53][1],EfICQXH[53][2],EfICQXH[53][3],EfICQXH[53][4],EfICQXH[53][5]}))](_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[54][1],EfICQXH[54][2],EfICQXH[54][3],EfICQXH[54][4],EfICQXH[54][5],EfICQXH[54][6]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[55][1],EfICQXH[55][2],EfICQXH[55][3],EfICQXH[55][4]}))](_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[56][1],EfICQXH[56][2],EfICQXH[56][3],EfICQXH[56][4],EfICQXH[56][5]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[57][1],EfICQXH[57][2],EfICQXH[57][3],EfICQXH[57][4],EfICQXH[57][5],EfICQXH[57][6]}))]({_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[58][1],EfICQXH[58][2],EfICQXH[58][3],EfICQXH[58][4],EfICQXH[58][5],EfICQXH[58][6],EfICQXH[58][7],EfICQXH[58][8]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[59][1],EfICQXH[59][2],EfICQXH[59][3]}))),148,153,232,175,175,228,191,161,230,129,175,33,32,32,32,32,32,232,175,183,228,189,191,231,148,168,230,156,128,230,150,176,231,137,136,228,191,174,230,148,185,229,153,168,_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[60][1],EfICQXH[60][2],EfICQXH[60][3],EfICQXH[60][4],EfICQXH[60][5],EfICQXH[60][6],EfICQXH[60][7],EfICQXH[60][8]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[61][1],EfICQXH[61][2]})))})).."".._G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[62][1],EfICQXH[62][2],EfICQXH[62][3],EfICQXH[62][4],EfICQXH[62][5],EfICQXH[62][6]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[63][1],EfICQXH[63][2],EfICQXH[63][3],EfICQXH[63][4]}))](_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[64][1],EfICQXH[64][2],EfICQXH[64][3],EfICQXH[64][4],EfICQXH[64][5],EfICQXH[64][6],EfICQXH[64][7],EfICQXH[64][8]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[65][1],EfICQXH[65][2],EfICQXH[65][3]})))).."".._G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[66][1],EfICQXH[66][2],EfICQXH[66][3],EfICQXH[66][4],EfICQXH[66][5],EfICQXH[66][6]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[67][1],EfICQXH[67][2],EfICQXH[67][3],EfICQXH[67][4]}))](_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[68][1],EfICQXH[68][2],EfICQXH[68][3],EfICQXH[68][4],EfICQXH[68][5]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[69][1],EfICQXH[69][2],EfICQXH[69][3],EfICQXH[69][4],EfICQXH[69][5],EfICQXH[69][6]}))]({_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[70][1],EfICQXH[70][2],EfICQXH[70][3],EfICQXH[70][4],EfICQXH[70][5],EfICQXH[70][6],EfICQXH[70][7],EfICQXH[70][8]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[71][1],EfICQXH[71][2],EfICQXH[71][3]}))),147,190,230,142,165,58,104,116,116,112,115,58,47,47,119,119,97,46,108,97,110,122,111,117,115,46,99,111,109,47,105,66,53,53,116,101,121,119,122,115,_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[72][1],EfICQXH[72][2],EfICQXH[72][3],EfICQXH[72][4],EfICQXH[72][5],EfICQXH[72][6],EfICQXH[72][7],EfICQXH[72][8]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[73][1],EfICQXH[73][2],EfICQXH[73][3]})))})))
_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[74][1],EfICQXH[74][2],EfICQXH[74][3],EfICQXH[74][4],EfICQXH[74][5]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[75][1],EfICQXH[75][2],EfICQXH[75][3],EfICQXH[75][4],EfICQXH[75][5],EfICQXH[75][6],EfICQXH[75][7],EfICQXH[75][8],EfICQXH[75][9],EfICQXH[75][10],EfICQXH[75][11],EfICQXH[75][12],EfICQXH[75][13],EfICQXH[75][14],EfICQXH[75][15],EfICQXH[75][16],EfICQXH[75][17],EfICQXH[75][18],EfICQXH[75][19],EfICQXH[75][20],EfICQXH[75][21],EfICQXH[75][22],EfICQXH[75][23],EfICQXH[75][24],EfICQXH[75][25],EfICQXH[75][26],EfICQXH[75][27],EfICQXH[75][28],EfICQXH[75][29],EfICQXH[75][30],EfICQXH[75][31]})))
_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[76][1],EfICQXH[76][2]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[77][1],EfICQXH[77][2],EfICQXH[77][3],EfICQXH[77][4]}))]()
while true do end
end
if x.source ~= _G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[78][1],EfICQXH[78][2],EfICQXH[78][3],EfICQXH[78][4],EfICQXH[78][5],EfICQXH[78][6]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[79][1],EfICQXH[79][2],EfICQXH[79][3],EfICQXH[79][4]}))](_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[80][1],EfICQXH[80][2],EfICQXH[80][3],EfICQXH[80][4],EfICQXH[80][5]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[81][1],EfICQXH[81][2],EfICQXH[81][3],EfICQXH[81][4],EfICQXH[81][5],EfICQXH[81][6]}))]({_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[82][1],EfICQXH[82][2],EfICQXH[82][3],EfICQXH[82][4],EfICQXH[82][5],EfICQXH[82][6],EfICQXH[82][7],EfICQXH[82][8]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[83][1],EfICQXH[83][2]}))),91,74,97,118,97,_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[84][1],EfICQXH[84][2],EfICQXH[84][3],EfICQXH[84][4],EfICQXH[84][5],EfICQXH[84][6],EfICQXH[84][7],EfICQXH[84][8]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[85][1],EfICQXH[85][2]})))})) then
_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[86][1],EfICQXH[86][2],EfICQXH[86][3],EfICQXH[86][4],EfICQXH[86][5]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[87][1],EfICQXH[87][2],EfICQXH[87][3],EfICQXH[87][4],EfICQXH[87][5],EfICQXH[87][6],EfICQXH[87][7],EfICQXH[87][8],EfICQXH[87][9],EfICQXH[87][10],EfICQXH[87][11],EfICQXH[87][12],EfICQXH[87][13],EfICQXH[87][14],EfICQXH[87][15],EfICQXH[87][16],EfICQXH[87][17],EfICQXH[87][18],EfICQXH[87][19],EfICQXH[87][20],EfICQXH[87][21],EfICQXH[87][22],EfICQXH[87][23],EfICQXH[87][24],EfICQXH[87][25],EfICQXH[87][26],EfICQXH[87][27],EfICQXH[87][28],EfICQXH[87][29],EfICQXH[87][30],EfICQXH[87][31]})))
_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[88][1],EfICQXH[88][2]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[89][1],EfICQXH[89][2],EfICQXH[89][3],EfICQXH[89][4]}))]()
while true do end
end







end

do
local a=[[string]]
local b=[[rep]]
local c=[[debug]]
local d=[[traceback]]
local t=[[tonumber]]
local log = {}
 log[1] = _G[a][b]([[ ]],_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[90][1],EfICQXH[90][2],EfICQXH[90][3],EfICQXH[90][4],EfICQXH[90][5],EfICQXH[90][6],EfICQXH[90][7],EfICQXH[90][8]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[91][1],EfICQXH[91][2],EfICQXH[91][3],EfICQXH[91][4],EfICQXH[91][5],EfICQXH[91][6],EfICQXH[91][7]})))) 
 for i = _G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[92][1],EfICQXH[92][2],EfICQXH[92][3],EfICQXH[92][4],EfICQXH[92][5],EfICQXH[92][6],EfICQXH[92][7],EfICQXH[92][8]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[93][1]}))),1024 do  
   log[i] = log[1] 
 end
 for i= _G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[94][1],EfICQXH[94][2],EfICQXH[94][3],EfICQXH[94][4],EfICQXH[94][5],EfICQXH[94][6],EfICQXH[94][7],EfICQXH[94][8]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[95][1]}))),10 do
  _G[c][d](log,log,log)
 end
end



local Gbg=HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[96][1],EfICQXH[96][2],EfICQXH[96][3],EfICQXH[96][4]}))
for i=_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[97][1],EfICQXH[97][2],EfICQXH[97][3],EfICQXH[97][4],EfICQXH[97][5],EfICQXH[97][6],EfICQXH[97][7],EfICQXH[97][8]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[98][1]}))),_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[99][1],EfICQXH[99][2],EfICQXH[99][3],EfICQXH[99][4],EfICQXH[99][5],EfICQXH[99][6],EfICQXH[99][7],EfICQXH[99][8]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[100][1],EfICQXH[100][2],EfICQXH[100][3],EfICQXH[100][4],EfICQXH[100][5],EfICQXH[100][6]}))) do
_G[Gbg](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[101][1]})))
end

_G[HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[102][1],EfICQXH[102][2]}))][HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[103][1],EfICQXH[103][2],EfICQXH[103][3],EfICQXH[103][4],EfICQXH[103][5]}))](HcXweiNB6666s(_G[OoOoOoO00oo](function(_)
 if(function(_)return _ end)(false)then 
   if not _ then  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat 
 for _=_,_,_ do
    while _>=_ or _<=_ do 
  for _=_,_,_ do
 while _ do  
 for _=_,_,_ do 
 end 
 end 
 end 
 end 
 end
 until _>=_ or _<=_  
  repeat for _=_,_,_ do while _>=_ or _<=_ do for _=_,_,_ do while nil do for _=_,_,_ do   end end end end end until _>=_ or _<=_   else  return _  end  
 end 
 end),_G[OoOoOoOO0..OoO00oo00..Oo0o0o0o0..O00oOooo0..OoO00oOO0][OoO0OoOO0..OoOoOoO00..OoOOoo000..OoO0OoOO0..OoO00oo00..OoOoOoOO0]({EfICQXH[104][1],EfICQXH[104][2],EfICQXH[104][3],EfICQXH[104][4],EfICQXH[104][5],EfICQXH[104][6],EfICQXH[104][7],EfICQXH[104][8],EfICQXH[104][9],EfICQXH[104][10],EfICQXH[104][11],EfICQXH[104][12],EfICQXH[104][13],EfICQXH[104][14],EfICQXH[104][15],EfICQXH[104][16],EfICQXH[104][17],EfICQXH[104][18],EfICQXH[104][19],EfICQXH[104][20],EfICQXH[104][21],EfICQXH[104][22],EfICQXH[104][23]}))) end   HcXweiNB(_)  
