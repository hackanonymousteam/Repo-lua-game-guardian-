 (function(...)	local imii = 78	;
local Key1 = 467162;
	local imii = 80		local imii = 170		local imii = 327		local imii = 578	;
local Key2 = 349196;
	local imii = 252		local imii = 336		local imii = 789		local imii = 330	;
local Key4 = 432291;
	local imii = 780		local imii = 255	;
local Key5 = 386902;
	local imii = 302		local imii = 688	;
local Key13 = 104608;
	local imii = 354	;
local Key19 = 618797;
	local imii = 582		local imii = 294		local imii = 237		local imii = 308		local imii = 778	;
local Key6 = 345699;
	local imii = 486	;
local Key7 = 524406;
	local imii = 272		local imii = 124		local imii = 567		local imii = 198		local imii = 380	;
local Key8 = 556568;
	local imii = 546		local imii = 202	;
local Key14 = 4;
	local imii = 166	;
local Key9 = 546730;
	local imii = 22		local imii = 258		local imii = 10	;
local Key10 = 781676;
	local imii = 522		local imii = 491		local imii = 521		local imii = 350		local imii = 699	;
local Key15 = 249481;
	local imii = 483		local imii = 312		local imii = 369		local imii = 757		local imii = 618	;
local Key12 = 351388;
	local imii = 168	;
local Key11 = 599155;
	local imii = 69		local imii = 780		local imii = 435		local imii = 293	;
local Key16 = 350754;
	local imii = 458		local imii = 564		local imii = 367	;
local Key17 = 680426;
	local imii = 589	;
local Key3 = 366216;
	local imii = 470		local imii = 666	;
local Key18 = 325429;
	local imii = 692		local imii = 488		local imii = 662		local imii = 39	;
local Key20 = 564699;
	local imii = 70		local imii = 403		local imii = 610		local imii = 507	;
local KeyHex1 = 429771;
	local imii = 687		local imii = 712		local imii = 178	;
local KeyHex2 = 65765;
	local imii = 734		local imii = 62		local imii = 735		local imii = 359	;
local KeyHex3 = 165396;
	local imii = 60		local imii = 181		local imii = 407		local imii = 640		local imii = 590	;
local KeyHex4 = 426035;
	local imii = 487		local imii = 636	;
local KeyHex5 = 353972;
	local imii = 189		local imii = 242	local getKey = -Key1+Key2-Key3+Key4-Key5+Key7-Key8+Key9-Key10+Key11-Key12+Key13-Key14+Key15-Key16+Key17-Key18+Key19-Key20
	local imii = 668		local imii = 596		local imii = 420		local imii = 410	;
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
;
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
local str = "2e7ac38c09ddc025825be6267fd11725"
hex = {}
local HexToDec={
 ['0'] = 0,  ['1'] = 1,  ['2'] = 2,  ['3'] = 3,
 ['4'] = 4,  ['5'] = 5,  ['6'] = 6,  ['7'] = 7,
 ['8'] = 8,  ['9'] = 9,  ['A'] = 10, ['B'] = 11,
 ['C'] = 12, ['D'] = 13, ['E'] = 14, ['F'] = 15,
 ['A'] = 10, ['B'] = 11, ['C'] = 12, ['D'] = 13,
 ['E'] = 14, ['F'] = 15
}
local DecToHex='0123456789ABCDEF'
local function char(S, i)
    local B1 = HexToDec[S:sub(i,i)]
    local B2 = HexToDec[S:sub(i+1,i+1)]
    local C = B1 *16 + B2
    return C
end
function _NguynHex_(S)
    local D = S:gsub("%s", '')
    D = D:gsub("\n", '')
    local T = {}
    local i = 1
    local c = 1
    while (i < #D ) do
       local C = char(D,i)
       i = i + 2
       T[c] = string.char(C)
       c = c + 1
    end
    return table.concat(T)
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
local per1,per2,per3,per4,per5=128,16,256,1,2
local Percentos=2local Mod=("�"):rep(Percentos)
local Key53 = 3;
local Key14 = 4;
local inv256
for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
local _NguynSha_ = function(DATA)
local K, F = Key53, 3 + Key14 return (DATA:gsub(Mod,""):gsub('%x%x%x', function(c) local L = K % 6 local H = (K - L) / 6 local M = H % per1 c = _ENV["tonumber"](c, per2) local m = (c + (H - M) / per1) * (per5*M + per4) % per3 K = L * F + H + c + m return _ENV["string"]["char"](m)end))end

local X = {};local S = {};local R = {};local D = {};local W = {};local Z = {};local X,S,R,D,W,Z = {X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}},{X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}},{X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}},{X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}},{X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}},{X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}},{X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}},{X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}};X = X.S;S = S.R;R = R.D;D = W.Z;W = Z.X,S,R,D,W,Z;X = ({({X = nil,S = nil,R = nil,D = nil,W = nil,Z = nil})});S = ({({X = nil,S = nil,R = nil,D = nil,W = nil,Z = nil})});R = ({({X = nil,S = nil,R = nil,D = nil,W = nil,Z = nil})});D = ({({X = nil,S = nil,R = nil,D = nil,W = nil,Z = nil})});W = ({({X = nil,S = nil,R = nil,D = nil,W = nil,Z = nil})});Z = ({({X = nil,S = nil,R = nil,D = nil,W = nil,Z = nil})})
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Bitch(s,a)
local res = ""
for i = 1,#s do
res = res .. string.char((a*s:byte(i)) % 256)
end
return res
end
function _NguynBit_(s)
return Bitch(s,171)
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function _NguynStr_(c,text) 
c = c._UpValues_
res = ''
for i in ipairs(c) do
res = res .. string.char((c[i] + 1 + _c(text) + (256 + i) * (1100 + i)) - 95 + 32 % 256)
end
return res
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
;
gg.toast("Encryption By ղlc Version 14.5")
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i));end;end
gg.setVisible(false)
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end

for i = 1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {15,3,100,23,98} _ = _() _ = -nil  _  = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _~= nil then   _ = _ (-nil * nil)()  _ = nil end  if _  == nil then  _ = {_, _(-nil)(-nil)(nil * 1, 1  << nil), -nil} end end local j = {15,3,100,23,98} j[''] = j local t = (j)(j, j) t[1] = 1 end
for i = 1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil  _  = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _~= nil then   _ = _ (-nil * nil)()  _ = nil end  if _  == nil then  _ = {_, _(-nil)(-nil)(nil * 1, 1  << nil), -nil} end end local j = {} j[''] = j local t = (j)(j, j) t[1] = 1 end

for i in ipairs({}) do local xxx = {nil, nil} if xxx ~= nil then xxx.multiChoice = xxx.os.exit() end end for i in ipairs({}) do local xxx = {nil, nil} if xxx ~= nil then xxx.searchNumber = xxx.TYPE_FLOAT() end end
for i in ipairs({}) do local xxx = {nil, nil} if xxx ~= nil then xxx.multiChoice = xxx.os.exit() end end for i in ipairs({}) do local xxx = {nil, nil} if xxx ~= nil then xxx.searchNumber = xxx.TYPE_FLOAT() end end
for i in ipairs({}) do local xxx = {nil, nil} if xxx ~= nil then xxx.multiChoice = xxx.os.exit() end end for i in ipairs({}) do local xxx = {nil, nil} if xxx ~= nil then xxx.searchNumber = xxx.TYPE_FLOAT() end end
for i in ipairs({}) do local xxx = {nil, nil} if xxx ~= nil then xxx.multiChoice = xxx.os.exit() end end for i in ipairs({}) do local xxx = {nil, nil} if xxx ~= nil then xxx.searchNumber = xxx.TYPE_FLOAT() end end
for i in ipairs({}) do local xxx = {nil, nil} if xxx ~= nil then xxx.multiChoice = xxx.os.exit() end end for i in ipairs({}) do local xxx = {nil, nil} if xxx ~= nil then xxx.searchNumber = xxx.TYPE_FLOAT() end end
for i in ipairs({}) do local xxx = {nil, nil} if xxx ~= nil then xxx.multiChoice = xxx.os.exit() end end for i in ipairs({}) do local xxx = {nil, nil} if xxx ~= nil then xxx.searchNumber = xxx.TYPE_FLOAT() end end
for i in ipairs({}) do i((true | false) - true) end
for i in ipairs({}) do (-nil)((-nil)[nil] | nil | nil) end
for i, v in ipairs({}) do if ipairs(i .. v) == true then break end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end

for i = 1,5 do
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local zz = {} zz.g = zz.g() if zz.g ~= zz.g then zz.g = zz.g() end local zz = {} zz.setRanges = zz.setRanges() if zz.setRanges ~= zz.setRanges then zz.setRanges = zz.setRanges() end end end
end

;if(nil)then;(function()end)();end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
;
while (nil)do;
local nguynct ={":'("}
if (nguynct.nguynct) then
end
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
for i = 1,0 do;NguynZlet='Chunk';end
;
while debug["getinfo"](gg["alert"])['source']~="=[Java]" do
end
while debug["getinfo"](string["len"])['func']~=string["len"] do
end
while debug["getinfo"](io["open"])['currentline']~=-1 do
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
local log = string.char(255,255,0,255,255,0):rep(999):rep(999) for i= 1,10 do debug.getinfo(1,nil,log) end
local AntiLoad = function(code) local Num = 0 local TakeCode = function(Code) local num2 = Num + 1 Num = num2 return code[Num] end return TakeCode end local code = {" "," "," "} assert(load(AntiLoad(code)))() 
local AntiLoad = function(code) local Num = 0 local TakeCode = function(Code) local num2 = Num + 1 Num = num2 return code[Num] end return TakeCode end local code = {" "," "," "} assert(load(AntiLoad(code)))() 
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
for ali = 1,3 do
gg.searchNumber(string.char(4,17,39,0,0,4,255,255,1,0)
:rep(999)
:rep(999), 5)
gg.searchNumber(string.char(4,255,255,1,0,0,0,0,236,0,0,0)
:rep(999)
:rep(999), 5)
debug.traceback(5, nil, string.char(4,17,39,0,0,4,255,255,1,0)
:rep(999)
:rep(999)
:rep(10))
debug.traceback(5, nil, string.char(4,255,255,1,0,0,0,0,236,0,0,0)
:rep(999)
:rep(999)
:rep(10))
end
gg.clearResults()
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
for i = 1,5 do;loadfile = loadfile;load = load;loadfile(gg.getFile()) load(string.dump(load("os.exit()"),false,false)) io.open(gg.getFile() .. "c" .. tostring(string.dump(loadfile(gg.getFile()),false,false)),"w") end;
c = os.clock()
for i = 1, 255 do
local _ = string.char(i):rep(33)
for i = 1, tostring(_:len()) do
debug.getinfo(1, nil, _)
end
end

for i = 1,100 do 
nguynzlet1 = math.random(90,999)
nguynzlet2 = string.char(math.random(0,255)):rep(nguynzlet1)
load(nguynzlet2) 
end
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
LOG = string.char(0):rep(99999)
LOGE = string.char(0x30):rep(99999)
LOGER = string.char(0x30,0x20,0xe5,0x8a):rep(99999)
for i = 1, 1000 do
debug.getinfo(1, nil, LOG..LOGE..LOGER)
debug.traceback(1, nil, LOG..LOGE..LOGER)
debug.getinfo(1, nil, LOG..LOGE..LOGER)
debug.debug(1, nil, LOG..LOGE..LOGER)
debug.getregistry(1, nil, LOG..LOGE..LOGER)
end

LOG = os.clock()
Spam = string.char(0):rep(999)
for i = 1,100000 do
debug.getinfo(i,nil,Spam) end
LOGD = os.clock() - LOG
if LOGD <= 1 then else end

LOG = os.clock()
Spam = string.char(0):rep(9999)
for i = 1,100 do
debug.getinfo(i,nil,Spam) end
LOGD = os.clock() - LOG
if LOGD <= 1 then else end
local log = string.char(255,255,0,255,255,0):rep(999):rep(999) for i= 1,10 do debug.getinfo(1,nil,log) end
gg[_NguynSha_(_NguynSha_(_NguynBit_([=[����=7�=7����=7�=7�#��=7�=7�&&�=7�=7����=7�=7����=7�=7����=7�=7�/&�=7�=7����=7�=7����=7�=7�2��=7�=7����=7�=7����=7�=7����=7�=7����=7�=7����=7�=7�&��=7�=7��,�=7�=7����=7�=7����=7�=7�2��=7�=7��,�=7�=7����=7�=7����=7�=7����=7�=7�/&�=7�=7����=7�=7����=7�=7�2��=7�=7����=7�=7�,,�=7�=7����=7�=7��2�=7�=7��2�=7�=7�/&�=7�=7����=7�=7����=7�=7�#��=7�=7��)�=7�=7�,,�=7�=7����=7�=7����=7�=7�#��=7�=7��2�=7�=7�,��=7�=7]=])))](_NguynHex_('4B455920444543204259204241544D414E2047414D4553')) end )([=[ 

━──────────────────────────────━
         [ 🇻🇳 Encryption By ղlc Version 14.5 🇻🇳 ]
                    [ • Telegram:@nlcgaming • ]
                      [ • Zalo:+84907376977 • ]
━──────────────────────────────━

]=])
