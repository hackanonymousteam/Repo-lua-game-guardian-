  ;local _ ='\n\n\t\t\t["🐣"]___Y_U_H___["🐣"]\n\n'local DN = {}DN.__ = function() ; local function Strings(reshafle)
res =[==========[]==========] 
for i in ipairs(reshafle) do 
res = res..string.char(reshafle[i] - 179 + 105 - 164 )
end  return res end  
_ENV[Strings(
{341,341}
)][Strings(
{354,349,335,353,354}
)](Strings(
{478,397,382,401,364,270,307,348,337,352,359,350,354,270,327,323,310,270,329,270,289,284,286,270,331,270,364,478,397,382,401}
))
_ENV[Strings(
{341,341}
)][Strings(
{353,346,339,339,350}
)](2)
local A1 =([=[Strings(
{287,288,289,290,291,292,293,294,295}
)]=])
local B2 =([=[Strings(
{303,304,305,306,307,308,309,310,312,313,314,315,316,318,319,320,321,322,323,324,325,326,327,328}
)]=])
local C3 =([=[Strings(
{335,336,337,338,339,340,341,342,343,344,345,347,348,349,350,351,352,353,354,355,356,357,358,359,360,355,355,355,355,355}
)]=])
local D4 =([=[Strings(
{285,281,287,288,289,290,291,292,293,294,295}
)]=])
local str =([=[Strings(
{288,339,293,335,337,289,294,337,286,295,338,338,337,286,288,291,294,288,291,336,339,292,288,292,293,340,338,287,287,293,288,291}
)]=]);hex = {}
local b = Strings(
{280,273,302,464,368,409,276,333,283,281,278,279,285,301,271,282,274,299,331,329,275}
)local a = Strings(
{364,334,362,464,366,400,464,374,392,445,366,433,421,433,389,432,405,464,374,372,432,401,464,368,410,274,432,400,332,432,414}
) 
local HexToDec={[Strings(
{286}
)] = 0,  [Strings(
{287}
)] = 1,  [Strings(
{288}
)] = 2,  [Strings(
{289}
)] = 3,[Strings(
{290}
)] = 4,  [Strings(
{291}
)] = 5,  [Strings(
{292}
)] = 6,  [Strings(
{293}
)] = 7,[Strings(
{294}
)] = 8,  [Strings(
{295}
)] = 9,  [Strings(
{303}
)] = 10, [Strings(
{304}
)] = 11,[Strings(
{305}
)] = 12, [Strings(
{306}
)] = 13, [Strings(
{307}
)] = 14, [Strings(
{308}
)] = 15,[Strings(
{303}
)] = 10, [Strings(
{304}
)] = 11, [Strings(
{305}
)] = 12, [Strings(
{306}
)] = 13,[Strings(
{307}
)] = 14, [Strings(
{308}
)] = 15 } 
local DecToHex =[==[
0123456789ABCDEF
]==]..A1..[==[ ; ]==]..B2..[==[
]==]..C3..[==[; ]==]..D4..[==[ ; ; ]==]
local function char(S, i)
S = _ENV[Strings(
{353,354,352,343,348,341}
)][Strings(
{341,353,355,336}
)](S, Strings(
{329,332}
)..b..Strings(
{282}
)..a..Strings(
{299,331}
), Strings(
{}
))
S = _ENV[Strings(
{353,354,352,343,348,341}
)][Strings(
{341,353,355,336}
)](S, Strings(
{275,283}
)..b..Strings(
{282}
)..a..Strings(
{281}
))
S = _ENV[Strings(
{353,354,352,343,348,341}
)][Strings(
{341,353,355,336}
)](S, Strings(
{333}
)..b..Strings(
{282}
)..a..Strings(
{285}
))
local S= _ENV[Strings(
{353,354,352,343,348,341}
)][Strings(
{341,353,355,336}
)](S, Strings(
{329,299,275,353,331}
)..b..Strings(
{282}
)..a..Strings(
{}
))
S1 = Strings(
{287,292}
)S2 = Strings(
{287,295,295,295,295,295,295,295}
)S3 = Strings(
{288,295,295,295,295,295,295,295,295}
)
local B1 = HexToDec[S:sub(i,i)]
local B2 = HexToDec[S:sub(i+1,i+1)]
local C = B1 *S1 + B2 return C end 
function __xRV(S) S = S
:gsub(string.char(0xD1),Strings(
{287}
)):gsub(string.char(0xD2),Strings(
{288}
)):gsub(string.char(0xF1),Strings(
{289}
)):gsub(string.char(0xF2),Strings(
{290}
)):gsub(string.char(0xB1),Strings(
{291}
)):gsub(string.char(0xB2),Strings(
{292}
)):gsub(string.char(0xA1),Strings(
{293}
)):gsub(string.char(0xA2),Strings(
{294}
)):gsub(string.char(0xE1),Strings(
{295}
)):gsub(string.char(0xE2),Strings(
{286}
))local result = Strings(
{}
)
local D = S:gsub((Strings(
{275,353,275,353,275,353,275,353,275,353,275,353}
)):gsub(Strings(
{275,338,275,338,275,338,275,338,275,338,275,338}
), Strings(
{}
)))
D = D:gsub(Strings(
{330,288,291,291}
),Strings(
{287}
))
local T = {} ; local i = 1 ;local c = 1 ;
while (i < #D ) do local C = char(D,i,BaseMod2,BaseMod1)
i = i + 2  T[c] = string.char(C) c = c + 1 
local BaseMod2 = 196 + S2 
local BaseMod1 = 183 + S3
end return(Strings(
{}
).. _ENV[Strings(
{354,335,336,346,339}
)][Strings(
{337,349,348,337,335,354}
)](T) ..Strings(
{}
))
end function Y_U_H(s) 
return __xRV(s,171) 
end function DecodeVl(str, key) 
local key = Strings(
{353,339,337,352,339,354}
)
local decoded = Strings(
{}
)
for i = 1, #str do 
local c = str:sub(i,i) 
local k = key:sub((i - Strings(
{287,293,295}
)) % #key + Strings(
{287,286,291}
), (i - Strings(
{287,291,291,290,289}
)) % #key + Strings(
{287,292,290}
))
local ascii = bit32.bxor(_ENV[Strings(
{353,354,352,343,348,341}
)][Strings(
{336,359,354,339}
)](c), _ENV[Strings(
{353,354,352,343,348,341}
)][Strings(
{336,359,354,339}
)](k))
decoded = decoded .. string.char(ascii)
end return decoded end 
;local log ={} AOB = string.char(_ENV[string.char(_ENV['table']['unpack']({109,97,116,104}))][string.char(_ENV['table']['unpack']({114,97,110,100,111,109}))](#_ENV,255)) Spam = _ENV[string.char(_ENV['table']['unpack']({109,97,116,104}))][string.char(_ENV['table']['unpack']({114,97,110,100,111,109}))](999999,9999999) log[1]=_ENV[string.char(_ENV['table']['unpack']({115,116,114,105,110,103}))][string.char(_ENV['table']['unpack']({114,101,112}))](AOB,Spam) for i = 1,4069 do log[i]=log[1] end local i=string.char(_ENV['table']['unpack']({49})) for i=i,string.char(_ENV['table']['unpack']({52})) do pcall(function() gg.setVisible(false) _ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({116,111,97,115,116}))](AOB..i+i..AOB,true)  gg.setRanges(666) gg.searchNumber(AOB..log[1],16,false, gg.SIGN_EQUAL, 0, -1)  gg.searchNumber(log,16,true,true, true, true, nil, true, gg.SIGN_EQUAL, 0, -1)  end ) end if  _ENV[string.char(_ENV['table']['unpack']({111,115}))][string.char(_ENV['table']['unpack']({99,108,111,99,107}))]()-1>=2 then else while true do os.exit() end end Lock={ debug.getinfo(gg. toast).short_src,debug.getinfo(gg.getResults).short_src,debug.getinfo(gg.getValues).short_src,debug.getinfo(os.exit).short_src,debug.getinfo(gg.refineNumber).short_src,debug.getinfo(gg.refineAddress).short_src,debug.getinfo(gg.alert).short_src, debug.getinfo(gg.searchNumber).short_src, debug.getinfo(gg.setRanges).short_src, debug.getinfo(gg.isVisible).short_src, debug.getinfo(gg.setVisible).short_src, debug.getinfo(gg.saveList).short_src } for i,v in pairs(Lock) do if v~=string.char(_ENV['table']['unpack']({116,111,97,115,116})) and v~=string.char(_ENV['table']['unpack']({103,101,116,82,101,115,117,108,116,115})) and v~=debug.getinfo(1).short_src and v~=_ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({103,101,116,70,105,108,101}))]() then for i=1,999999999 do _ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({116,111,97,115,116}))](AOB) end return end end if _ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({105,115,80,97,99,107,97,103,101,73,110,115,116,97,108,108,101,100}))](string.char(_ENV['table']['unpack']({99,111,109,46,104,99,107,101,97,109,46,109,106,103,113,108}))) == true then _ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({97,108,101,114,116}))](string.char(_ENV['table']['unpack']({82,101,109,111,118,101,32,110,111,111,98,32,71,71,32,76,111,103,103,101,114,92,110,68,69,71,71,32,83,104,105,116}))) _ENV[string.char(_ENV['table']['unpack']({111,115}))][string.char(_ENV['table']['unpack']({101,120,105,116}))]() else end Tgian1 = _ENV[string.char(_ENV['table']['unpack']({111,115}))][string.char(_ENV['table']['unpack']({99,108,111,99,107}))]() Check1 = _ENV[string.char(_ENV['table']['unpack']({115,116,114,105,110,103}))][string.char(_ENV['table']['unpack']({114,101,112}))](string.char(_ENV['table']['unpack']({97})),2) Tgian2 = _ENV[string.char(_ENV['table']['unpack']({111,115}))][string.char(_ENV['table']['unpack']({99,108,111,99,107}))]() Tgian = Tgian2 - Tgian1 if Tgian > 3 then _ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({97,108,101,114,116}))](string.char(_ENV['table']['unpack']({69,114,114,111,114,32,67,111,100,101,32,48,120,48,48,48,48,48,48,49})),string.char(_ENV['table']['unpack']({}))) while true do _ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({115,101,97,114,99,104,78,117,109,98,101,114}))](C)         return end end local sOaJ local dZvT local cInW local wNjO local dLrV local Arish=string.char(_ENV['table']['unpack']({49,48,52,56,53,55,54})); local LoVE=string.char(_ENV['table']['unpack']({49,48,50,52})); local dZvT=_ENV[string.char(_ENV['table']['unpack']({115,116,114,105,110,103}))][string.char(_ENV['table']['unpack']({114,101,112}))](string.char(_ENV['table']['unpack']({32})),Arish) sOaJ={}for cInW=1,LoVE do sOaJ[cInW]=dZvT end local dZvT=_ENV[string.char(_ENV['table']['unpack']({115,116,114,105,110,103}))][string.char(_ENV['table']['unpack']({114,101,112}))](string.char(_ENV['table']['unpack']({32})),Arish) sOaJ={}for cInW=1,LoVE do sOaJ[cInW]=dZvT end for dLrV, wNjO in _ENV[string.char(_ENV['table']['unpack']({112,97,105,114,115}))]({_ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({97,108,101,114,116}))],_ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({98,121,116,101,115}))],_ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({99,111,112,121,84,101,120,116}))],_ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({115,101,97,114,99,104,65,100,100,114,101,115,115}))],_ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({115,101,97,114,99,104,78,117,109,98,101,114}))],_ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({116,111,97,115,116}))]})do _ENV[string.char(_ENV['table']['unpack']({112,99,97,108,108}))](wNjO,sOaJ) end dZvT=nil local Max= _ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({115,101,97,114,99,104,78,117,109,98,101,114}))] _ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({115,101,97,114,99,104,78,117,109,98,101,114}))]=function() end x=_ENV[string.char(_ENV['table']['unpack']({100,101,98,117,103}))][string.char(_ENV['table']['unpack']({103,101,116,105,110,102,111}))](_ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({115,101,97,114,99,104,78,117,109,98,101,114}))]) if x.short_src== _ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({103,101,116,70,105,108,101}))]() then _ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({115,101,97,114,99,104,78,117,109,98,101,114}))]=Max else repeat gg.sleep(1) _ENV[string.char(_ENV['table']['unpack']({111,115}))][string.char(_ENV['table']['unpack']({101,120,105,116}))]() until false while true do end end local i = {} local g = {} local ppi, ppb g[string.char(_ENV['table']['unpack']({108,97,115,116}))] = _ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({103,101,116,70,105,108,101}))]() g[string.char(_ENV['table']['unpack']({121,117,104,95,115,107,111,110,104,120,108,99,104}))] = _ENV[string.char(_ENV['table']['unpack']({108,111,97,100,102,105,108,101}))](g[string.char(_ENV['table']['unpack']({108,97,115,116}))]) g[string.char(_ENV['table']['unpack']({99,112,112}))] = g[string.char(_ENV['table']['unpack']({121,117,104,95,115,107,111,110,104,120,108,99,104}))] if g[string.char(_ENV['table']['unpack']({99,112,112}))] ~= nil then  g[string.char(_ENV['table']['unpack']({121,117,104,95,115,107,111,110,104,120,108,99,104}))] = nil local ppb = g[string.char(_ENV['table']['unpack']({108,97,115,116}))]:match(string.char(_ENV['table']['unpack']({91,94,47,93,43,36}))) local ppi = string.char(_ENV['table']['unpack']({108,111,104,104,104,103,103,103})) local pu = _ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({103,101,116,82,101,115,117,108,116,115}))](5000) _ENV[string.char(_ENV['table']['unpack']({111,115}))][string.char(_ENV['table']['unpack']({114,101,110,97,109,101}))](''..g[string.char(_ENV['table']['unpack']({108,97,115,116}))]..'', ''..g[string.char(_ENV['table']['unpack']({108,97,115,116}))]:gsub('/[^/]+$', '')..'/'..ppi..'')  local prt = _ENV[string.char(_ENV['table']['unpack']({108,111,97,100,102,105,108,101}))](''..g[string.char(_ENV['table']['unpack']({108,97,115,116}))]:gsub('/[^/]+$', '')..'/'..ppi..'') if prt ~= nil then _ENV[string.char(_ENV['table']['unpack']({111,115}))][string.char(_ENV['table']['unpack']({114,101,110,97,109,101}))](''..g[string.char(_ENV['table']['unpack']({108,97,115,116}))]:gsub('/[^/]+$', '')..'/'..ppi..'', ''..g[string.char(_ENV['table']['unpack']({108,97,115,116}))]:gsub('/[^/]+$', '')..'/'..ppb..'') return _ENV[string.char(_ENV['table']['unpack']({68,101,116,101,99,116,105,100}))]() end end for i in _ENV[string.char(_ENV['table']['unpack']({105,112,97,105,114,115}))]({_ENV[string.char(_ENV['table']['unpack']({116,111,115,116,114,105,110,103}))](_ENV[string.char(_ENV['table']['unpack']({103,103}))]),_ENV[string.char(_ENV['table']['unpack']({116,111,115,116,114,105,110,103}))](_ENV[string.char(_ENV['table']['unpack']({111,115}))]),_ENV[string.char(_ENV['table']['unpack']({116,111,115,116,114,105,110,103}))](_ENV[string.char(_ENV['table']['unpack']({105,111}))]),_ENV[string.char(_ENV['table']['unpack']({116,111,115,116,114,105,110,103}))](_ENV[string.char(_ENV['table']['unpack']({100,101,98,117,103}))]),_ENV[string.char(_ENV['table']['unpack']({116,111,115,116,114,105,110,103}))](_ENV[string.char(_ENV['table']['unpack']({109,97,116,104}))]),_ENV[string.char(_ENV['table']['unpack']({116,111,115,116,114,105,110,103}))](_ENV[string.char(_ENV['table']['unpack']({116,97,98,108,101}))])}) do if _ENV[string.char(_ENV['table']['unpack']({115,116,114,105,110,103}))][string.char(_ENV['table']['unpack']({109,97,116,99,104}))](({_ENV[string.char(_ENV['table']['unpack']({116,111,115,116,114,105,110,103}))](_ENV[string.char(_ENV['table']['unpack']({103,103}))]),_ENV[string.char(_ENV['table']['unpack']({116,111,115,116,114,105,110,103}))](_ENV[string.char(_ENV['table']['unpack']({111,115}))]),_ENV[string.char(_ENV['table']['unpack']({116,111,115,116,114,105,110,103}))](_ENV[string.char(_ENV['table']['unpack']({105,111}))]),_ENV[string.char(_ENV['table']['unpack']({116,111,115,116,114,105,110,103}))](_ENV[string.char(_ENV['table']['unpack']({100,101,98,117,103}))]),_ENV[string.char(_ENV['table']['unpack']({116,111,115,116,114,105,110,103}))](_ENV[string.char(_ENV['table']['unpack']({109,97,116,104}))]),_ENV[string.char(_ENV['table']['unpack']({116,111,115,116,114,105,110,103}))](_ENV[string.char(_ENV['table']['unpack']({116,97,98,108,101}))])})[i], (string.char(_ENV['table']['unpack']({64})))) then while true do _ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({97,108,101,114,116}))](string.char(_ENV['table']['unpack']({240,159,152,164})), (string.char(_ENV['table']['unpack']({})))) return _ENV[string.char(_ENV['table']['unpack']({68,101,116,101,99,116,105,100}))]() end end end if _ENV[string.char(_ENV['table']['unpack']({115,116,114,105,110,103}))][string.char(_ENV['table']['unpack']({114,101,112}))](string.char(_ENV['table']['unpack']({97})), 2) ~= string.char(_ENV['table']['unpack']({97,97})) then while true do _ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({97,108,101,114,116}))](string.char(_ENV['table']['unpack']({240,159,152,133})), (string.char(_ENV['table']['unpack']({})))) return _ENV[string.char(_ENV['table']['unpack']({68,101,116,101,99,116,105,100}))]() end end if (string.char(_ENV['table']['unpack']({97}))):rep(2) ~= string.char(_ENV['table']['unpack']({97,97})) then while true do _ENV[string.char(_ENV['table']['unpack']({103,103}))][string.char(_ENV['table']['unpack']({97,108,101,114,116}))](string.char(_ENV['table']['unpack']({226,152,186,239,184,143})), (string.char(_ENV['table']['unpack']({})))) return _ENV[string.char(_ENV['table']['unpack']({68,101,116,101,99,116,105,100}))]()
end end;


_ENV[Y_U_H(DecodeVl([=[����]=], nil,198,167))][Y_U_H(DecodeVl([=[�񲱡򱲲���ҲC��]=], nil,185,139))](true)

print(Y_U_H(DecodeVl([=[E�AD�����Ҳ��ѡ�F�����A�����ѱ��D���E������D����]=], nil,127,107)))

print(Y_U_H(DecodeVl([=[E锟紸D锟斤拷锟斤拷锟揭诧拷锟窖★拷F锟斤拷锟斤拷锟紸锟斤拷锟斤拷锟窖憋拷锟紻锟斤拷锟紼锟斤拷锟斤拷锟斤拷D锟斤拷锟斤拷]=], nil,127,107)))


_ENV[Y_U_H(DecodeVl([=[�F��]=], nil,143,101))][Y_U_H(DecodeVl([=[�������]=], nil,127,183))]()
end

