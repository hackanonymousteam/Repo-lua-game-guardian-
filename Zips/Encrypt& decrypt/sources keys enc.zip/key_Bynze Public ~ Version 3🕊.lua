local _ = "🍏Bynze Public ~ Version 3🕊️"
;(function(...)
;while(nil) do; _ = { }; while _.__ ~= lil[nil] do; _ = _.__(); local k, v = {}; _ = _(_); _ = _(_)_ = _[_]; _ = _(_)_ = _[_]; local b, y, n, z, e = { }, { }, { }; _ = _(_)_ = _[_]; _ = _(_)_ = _[_]; local __ = {}; _ = _(_)_ = _[_]; _ = _(_)_ = _[_]; local ___ = { }; _ = _(_)_ = _[_]; _ = _(_)_ = _[_]; if _.byte <= lil[nil] then _._=_[_._](-nil)(-true)*(_[__]) end; _ = _(_)_ = _[_]; _ = _(_)_ = _[_]; if _() and _.byte(-nil) ~= byte.byte(b._[__]) then _.__[__._] = nil, nil else byte._() end; _ = _(_)_ = _[_]; _ = _(_)_ = _[_]; if byte.__(_[byte.__]) == (nil) and byte.__() * byte.__() >= b.byte.__() / byte.__() then end; _ = _(_)_ = _[_]; _ = _(_)_ = _[_]; for i=0,(nil) do _(__) end _(); break end; break end;;;
local Bynze = (...) 
local i = 1
local lll = {{},{}};
local LOADK = "DecodeMe"
local KeySize = 5440742109440326804;
local AdditionalA = 414022705;
local AdditionalB = 440;
local AdditionalC = 8691;
local AdditionalD = 394;
local AdditionalE = 21;
local AdditionalF = 3;
local AdditionalG = 3418600;
local AdditionalH = 4742;
local Tables = ({AdditionalA, AdditionalB, AdditionalC, AdditionalD, AdditionalE, AdditionalF, AdditionalG, AdditionalH});
local Char1 = { -- table(ea195c0)
	[1] = { -- table(8ed72f9)
		[ 1] = 521126,
		[ 2] = 3,
		[ 3] = 46,
		[ 4] = 4172546,
		[ 5] = 1339,
		[ 6] = 1651073,
		[ 7] = 302264,
		[ 8] = 4,
		[ 9] = 3448,
		[10] = 5095,
	},
	[2] = { -- table(bb8023e)
		[ 1] = 223,
		[ 2] = 2,
		[ 3] = 2,
		[ 4] = 469,
		[ 5] = 123,
		[ 6] = 20,
		[ 7] = 3299,
		[ 8] = 1763,
		[ 9] = 495,
		[10] = 36344,
	},
	[3] = { -- table(7fc089f)
		[ 1] = 480665,
		[ 2] = 3343625,
		[ 3] = 5157,
		[ 4] = 25,
		[ 5] = 2,
		[ 6] = 538526,
		[ 7] = 54,
		[ 8] = 2,
		[ 9] = 5316,
		[10] = 472693,
	},
	[4] = { -- table(aea4dec)
		[ 1] = 22,
		[ 2] = 1,
		[ 3] = 674889,
		[ 4] = 24,
		[ 5] = 16152,
		[ 6] = 3828,
		[ 7] = 291,
		[ 8] = 16,
		[ 9] = 5176,
		[10] = 184,
	},
	[5] = { -- table(a0945b5)
		[ 1] = 499052,
		[ 2] = 5,
		[ 3] = 4269415,
		[ 4] = 20559,
		[ 5] = 1767882,
		[ 6] = 1429360,
		[ 7] = 231040,
		[ 8] = 881543,
		[ 9] = 2,
		[10] = 317162,
	},
};
local Char2  = { -- table(82e044a)
	[1] = 5,
	[2] = 14,
	[3] = 1,
	[4] = 12,
	[5] = 6,
	[6] = 11,
	[7] = 12,
	[8] = 2,
	[9] = 5,
};

repeat
lll[1][i] = tonumber(string.char(i)) or string.char(i)
i = i + 1
until (i > 255)
local function _l(c)
return c
end


local function __YN(...) ;;while(nil)do;for _ = 1, _.byte do local byte, _ = {}, {} if(byte._)then _._ = byte._(y) end for byte = _._, byte._ do local __ = {} if(__._) then __._ = __._() end for res = byte.__ , __.__ do local __ = {} if (__._) then __.byte = byte.__(y) end for Bynze = _.byte, byte.__, _.__ do local chars = {} if (chars.byte) then __._ = chars.byte(__) end local ____ = {} if (____.chars)then ____.chars =(byte|___|__|_)(_, byte._) end end local __ = {} if (byte._) then __._ = (true|__|_|_)(_) end end local __ = {} if (__._) then __._ = (true|false|__|_)(_) end end local _ = {} if (_._) then _._ = (true|nil|false|nil|_|nil|false|true|nil)(_) end return (true|false|nil) end return end;;;

local strings = "";
local arg = {...};
strings = lll[2][arg[#arg]]
if not strings then
strings = string.char()
local num = arg[#arg][#arg[#arg]]
table.remove(arg[#arg], #arg[#arg])
for k, v in next, {arg[1]:byte(1,-1)}, nil do
if not arg[#arg][k] then
;;while(nil)do;for _ = 1, _.byte do local byte, _ = {}, {} if(byte._)then _._ = byte._(y) end for byte = _._, byte._ do local __ = {} if(__._) then __._ = __._() end for res = byte.__ , __.__ do local __ = {} if (__._) then __.byte = byte.__(y) end for Bynze = _.byte, byte.__, _.__ do local chars = {} if (chars.byte) then __._ = chars.byte(__) end local ____ = {} if (____.chars)then ____.chars =(byte|___|__|_)(_, byte._) end end local __ = {} if (byte._) then __._ = (true|__|_|_)(_) end end local __ = {} if (__._) then __._ = (true|false|__|_)(_) end end local _ = {} if (_._) then _._ = (true|nil|false|nil|_|nil|false|true|nil)(_) end return (true|false|nil) end return end;;;
v = lll[1][(v - (Tables[3] / AdditionalC) + (k + arg[#arg][4]) * (arg[#arg - 1] + Char2[num]))  % 256]
strings = strings .. v
else
;;while(nil)do;for _ = 1, _.byte do local byte, _ = {}, {} if(byte._)then _._ = byte._(y) end for byte = _._, byte._ do local __ = {} if(__._) then __._ = __._() end for res = byte.__ , __.__ do local __ = {} if (__._) then __.byte = byte.__(y) end for Bynze = _.byte, byte.__, _.__ do local chars = {} if (chars.byte) then __._ = chars.byte(__) end local ____ = {} if (____.chars)then ____.chars =(byte|___|__|_)(_, byte._) end end local __ = {} if (byte._) then __._ = (true|__|_|_)(_) end end local __ = {} if (__._) then __._ = (true|false|__|_)(_) end end local _ = {} if (_._) then _._ = (true|nil|false|nil|_|nil|false|true|nil)(_) end return (true|false|nil) end return end;;;
v = lll[1][(v - (arg[#arg][k] + Char2[2]) + (AdditionalA + string.sub(KeySize, 1, 5)) * (arg[#arg - 1] + Char2[num]))  % 256]
strings = strings .. v
end
lll[2][arg[#arg]] = res
end
end
return strings
end ;while(nil) do; _ = { }; while _.__ ~= lil[nil] do; _ = _.__(); local k, v = {}; _ = _(_); _ = _(_)_ = _[_]; _ = _(_)_ = _[_]; local b, y, n, z, e = { }, { }, { }; _ = _(_)_ = _[_]; _ = _(_)_ = _[_]; local __ = {}; _ = _(_)_ = _[_]; _ = _(_)_ = _[_]; local ___ = { }; _ = _(_)_ = _[_]; _ = _(_)_ = _[_]; if _.byte <= lil[nil] then _._=_[_._](-nil)(-true)*(_[__]) end; _ = _(_)_ = _[_]; _ = _(_)_ = _[_]; if _() and _.byte(-nil) ~= byte.byte(b._[__]) then _.__[__._] = nil, nil else byte._() end; _ = _(_)_ = _[_]; _ = _(_)_ = _[_]; if byte.__(_[byte.__]) == (nil) and byte.__() * byte.__() >= b.byte.__() / byte.__() then end; _ = _(_)_ = _[_]; _ = _(_)_ = _[_]; for i=0,(nil) do _(__) end _(); break end; break end;;;
local LOADK = "DecodeMe"
local LOADK = "DecodeMe"
;









gg[(__YN(_l("\220\108\154\132\58\13\99\101\229\196\221\119"), 1376, {3,138,191,173,82,69,136,124,250,226, 1}))]()

;;while(nil)do;for _ = 1, _.byte do local byte, _ = {}, {} if(byte._)then _._ = byte._(y) end for byte = _._, byte._ do local __ = {} if(__._) then __._ = __._() end for res = byte.__ , __.__ do local __ = {} if (__._) then __.byte = byte.__(y) end for Bynze = _.byte, byte.__, _.__ do local chars = {} if (chars.byte) then __._ = chars.byte(__) end local ____ = {} if (____.chars)then ____.chars =(byte|___|__|_)(_, byte._) end end local __ = {} if (byte._) then __._ = (true|__|_|_)(_) end end local __ = {} if (__._) then __._ = (true|false|__|_)(_) end end local _ = {} if (_._) then _._ = (true|nil|false|nil|_|nil|false|true|nil)(_) end return (true|false|nil) end return end;;;
;end)(Bynze)

