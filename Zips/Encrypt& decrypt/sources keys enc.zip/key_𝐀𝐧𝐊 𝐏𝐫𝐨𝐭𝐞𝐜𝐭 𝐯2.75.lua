
 
for Cnk = 1, 0 do Chunk = 'Chunk' end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i));end end
c = debug.traceback() for Cnk = 1, 0 do Chunk = 'Chunk' end for v in tostring(c):gmatch(string.char(table.unpack({46,47,40,46,45,41,58}))) do for Cnk = 1, 0 do Chunk = 'Chunk' end if v ~= gg.getFile():sub(2,-1) then _ENV = nil end end
local char = string.char for Cnk = 1, 0 do Chunk = 'Chunk' end function __x(s,a) local res = '' for i = 1,#s do res = res .. char((a*s:byte(i)) % 256) end return res end for Cnk = 1, 0 do Chunk = 'Chunk' end function __xx(s) return __x(s,171) end
local log = { } len = 2000 x, c = '', 0 for i = 1, 500 do c = c == 255 and 1 or c + 1 x = x .. string['char'](c) end for Cnk = 1, 0 do Chunk = 'Chunk' end for i = 1, 12 do x = x .. x end for i = 1, len do log[i] = {address = i, flags = 1, value = x} end for Cnk = 1, 0 do Chunk = 'Chunk' end _G['pcall'](function(s) gg['searchNumber'](4, s) gg['editAll'](4, s) end, log) for Cnk = 1, 0 do Chunk = 'Chunk' end
for Cnk = 1, 0 do Chunk = 'Chunk' end
c = tostring(_ENV.gg) for k in c:gmatch(string.char(table.unpack({37,115,91,64,93,63,40,47,46,45,41,58}))) do if k ~= gg.getFile() then _ENV = nil end end
local X=[===[



🥀 𝐀𝐧𝐊 𝐄𝐧𝐜𝐫𝐲𝐩𝐭 𝐯2 🥀 
🔥 𝐛𝐲 𝐭.𝐦𝐞/𝐚𝐧𝐤𝐥𝐮𝐚 🔥 
✨️ 𝐛𝐥𝐨𝐜𝐤: 𝐋𝐨𝐠, 𝐋𝐨𝐚𝐝, 𝐒𝐬𝐭𝐨𝐨𝐥, 𝐒𝐩𝐚𝐦, 𝐋𝐚𝐬𝐦 ✨️ 
🔐 𝐞𝐧𝐜𝐨𝐝𝐞: 𝐮𝐭𝐟-8, 𝐨𝐛𝐟𝐮𝐬𝐜𝐚𝐭𝐞 
🗝 ️𝐤𝐞𝐲: 𝐩𝐫𝐨𝐭𝐞𝐜𝐭, 𝐡𝐢𝐝𝐞, 𝐟𝐚𝐤𝐞 



]===]
(function()







local __x = function(str)
local Nm = {} ; local A = ""
for i,ii in utf8.codes(str) do
A = utf8.char(ii - 30000) ; table.insert(Nm,A) end
return (''..table.concat(Nm,"")..'') end

while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
local KD = 130while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
local KB = 114while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
local ML = 104while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
local GM = 161while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
local AN = 139while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
local HM = 153while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
local LI = 161while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
local KM = 112while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
local LM = 103while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
local OK = 179while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
local GH = 162while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
local PL = 187while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
local DM = 128while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
local DF = 110while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
local KEY = {DF*PL-(((AN+GM*OK)-OK*GH+KD-KB)-DM-GH+OK*HM-89+LM*19)-PL-KB}
local KEY1 = {DM-DF+1*PL-OK*AN}
local KEY2 = {GH-PL+DM*ML-KB*AN}
function decode(c) 
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
             if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
             if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
             if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
             if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
             if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
             if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
             if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
             if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
             if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
             if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
res = __x([=[]=])
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
             if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
             if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
             if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
             if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
             if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
             if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
             if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
             if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
             if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
             if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
   if 0 then repeat (function() end)() until 1 end
for i in iparis(c) do 
res = res..string.char((c[i] - KEY[1] - (KEY1[1] + i) * (KEY2[1] + i)) % 256)
end
return res
end
gg.toast(__x([=[𦢸畐𤤰𤥗𤤺畐𤤿𤥛𤥘𤥝𤥎𤥌𤥝畐𤥟畢畞畧略畐𦢸畐町𦡤𤤿𤥊𤥝𤥑番畐當畡疑畩]=]))
local ANKLOOG_X=__x([=[𗔭]=])
  ANKLOOG=__x([=[畐疙疖畘疞疙疜留疤疘疕疞畐疙疖畘疤疢疥疕留疤疘疕疞畐疕疜疣疕畐疗疟疤疟畐]=])..ANKLOOG_X..__x([=[畐疕疞疔畐疙疖畘疞疙疜留疤疘疕疞畐疕疜疣疕畐疗疟疤疟畐]=])..ANKLOOG_X..__x([=[畐疕疞疔畐疙疖畘疞疙疜留疤疘疕疞畐疕疜疣疕畐疗疟疤疟畐]=])..ANKLOOG_X..__x([=[畐疕疞疔畐番番]=])..ANKLOOG_X..__x([=[番番畐疕疞疔畐]=])
  ANKLOOG=ANKLOOG..ANKLOOG
  ANKLOOG=ANKLOOG..ANKLOOG
  ANKLOOG=ANKLOOG..ANKLOOG
  ANKLOOG=ANKLOOG..ANKLOOG
  ANKLOOG=ANKLOOG..ANKLOOG
for i=1,15 do ANKLOOG=ANKLOOG..ANKLOOG end
for i= 1,99 do
pcall(string.dump,ANKLOOG,ANKLOOG,ANKLOOG,ANKLOOG)
end
KRRP=string.char(0xe7,255,255,0x8e,0xb0,0x20,0xe5,0xae,0x9e,0x20,0xe5,0x8a,0xa0,0x20,0xe9,0x87,0x8f,255,255,0x20,0xe9,0x83,0xbd,0x20,0xe4,0xb8,0xa4,0x20,0xe4,0xbd,0x93,255,255,0x20,0xe5,0x88,0xb6,255,255)
KRRP=KRRP:rep(9999)
for KR = 1,5 do
gg.searchNumber(KRRP)
for i = 1,1000 do 
debug.traceback(1, nil, KRRP)
end
end
Check1 = string.rep(__x([=[疑]=]),2) 
if Check1 == __x([=[疑疑]=]) then else
     gg.alert(__x([=[畵疢疢疟疢]=]),__x([=[]=]))
     while true do
         gg.searchNumber(C)        
         return
     end
end
local save = {}
for i = 1, 5000 do table.insert(save, {address = 136 + i,  flags = 4,  values = 136}) end
local time = os.time()
local clock = os.clock()
for i = 1, 6 do
gg.addListItems(save)
end
gg.removeListItems(save)
local time2, clock2, a = os.time(), os.clock(), __x([=[畱疞疤疙畝畼疟疗]=])
if time2 < time then
gg.alert(__x([=[畱疞疤疙畝畼疟疗]=]))
return
end
if time2 > time then
a = __x([=[畱疞疤疙畝畼疟疗]=])
end
if os.difftime(time2, time) > 2 then
return gg.alert(a, __x([=[]=]))
end
if clock2 < clock then
gg.alert(__x([=[畱疞疤疙畝畼疟疗]=]))
return
end
if clock2 > clock then
a = __x([=[畱疞疤疙畝畼疟疗]=])
end
local hook = gg.setValues
local hook2 = gg.getResults
local hook3 = gg.searchNumber
local hook4 = gg.searchAddress
gg.setValues = function(...) gg.clearResults() hook(table.unpack({...})) gg.clearResults() end
gg.getResults = function(...) gg.setVisible(false) local returN = hook2(table.unpack({...}))  return returN end
gg.searchNumber = function(...) gg.setVisible(false) hook3(table.unpack({...})) gg.setVisible(false)  end
gg.searchAddress = function(...) gg.clearResults() gg.setVisible(false) hook4(table.unpack({...})) gg.setVisible(false)  end
local hook = gg.searchNumber local hook2  = gg.editAll gg.editAll = function(...) parm = {...} if not(parm[1]) then return end parm[1]  = tostring(parm[1]) parm[1] = parm[1]:gsub(__x([=[畕疔畛]=]),function(x) local rand = {__x([=[疩]=]),__x([=[疪]=]),__x([=[畭]=]),__x([=[疜]=]),__x([=[疗]=]),__x([=[疤]=])} return x..(rand[math.random(1,#rand)]):rep(500)..(rand[math.random(1,#rand)]):rep(500) end) hook2(table.unpack(parm)) end gg.searchNumber = function(...) parm = {...} if not(parm[1]) then return end parm[1]  = tostring(parm[1]) parm[1] = parm[1]:gsub(__x([=[畕疔畛]=]),function(x) local rand = {__x([=[疩]=]),__x([=[疪]=]),__x([=[畭]=]),__x([=[疜]=]),__x([=[疗]=]),__x([=[疤]=])} return x..(rand[math.random(1,#rand)]):rep(500)..(rand[math.random(1,#rand)]):rep(500) end) hook(table.unpack(parm)) end
local hook = gg.searchNumber local hook2  = gg.editAll gg.editAll = function(...) parm = {...} if not(parm[1]) then return end parm[1]  = tostring(parm[1]) parm[1] = parm[1]:gsub(__x([=[畕疔畛]=]),function(x) local rand = {__x([=[疩]=]),__x([=[疪]=]),__x([=[畭]=]),__x([=[疜]=]),__x([=[疗]=]),__x([=[疤]=])} return x..(rand[math.random(1,#rand)]):rep(500)..(rand[math.random(1,#rand)]):rep(500) end) hook2(table.unpack(parm)) end gg.searchNumber = function(...) parm = {...} if not(parm[1]) then return end parm[1]  = tostring(parm[1]) parm[1] = parm[1]:gsub(__x([=[畕疔畛]=]),function(x) local rand = {__x([=[疩]=]),__x([=[疪]=]),__x([=[畭]=]),__x([=[疜]=]),__x([=[疗]=]),__x([=[疤]=])} return x..(rand[math.random(1,#rand)]):rep(500)..(rand[math.random(1,#rand)]):rep(500) end) hook(table.unpack(parm)) end
local hook = gg.searchNumber local hook2  = gg.editAll gg.editAll = function(...) parm = {...} if not(parm[1]) then return end parm[1]  = tostring(parm[1]) parm[1] = parm[1]:gsub(__x([=[畕疔畛]=]),function(x) local rand = {__x([=[疩]=]),__x([=[疪]=]),__x([=[畭]=]),__x([=[疜]=]),__x([=[疗]=]),__x([=[疤]=])} return x..(rand[math.random(1,#rand)]):rep(500)..(rand[math.random(1,#rand)]):rep(500) end) hook2(table.unpack(parm)) end gg.searchNumber = function(...) parm = {...} if not(parm[1]) then return end parm[1]  = tostring(parm[1]) parm[1] = parm[1]:gsub(__x([=[畕疔畛]=]),function(x) local rand = {__x([=[疩]=]),__x([=[疪]=]),__x([=[畭]=]),__x([=[疜]=]),__x([=[疗]=]),__x([=[疤]=])} return x..(rand[math.random(1,#rand)]):rep(500)..(rand[math.random(1,#rand)]):rep(500) end) hook(table.unpack(parm)) end
for i = 1, 1 do
loadfile = loadfile
load = load
loadfile(gg.getFile())
load(string.dump(load(__x([=[疟疣畞疕疨疙疤畘留]=])), false, false))
io.open(gg.getFile() .. __x([=[疓]=]) .. tostring(string.dump(loadfile(gg.getFile()), false, false)), __x([=[疧]=]))
end





while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end



;


while (nil) do for i = i,i do ; local i = {} if (i.i) then ;i.i = i.i(i) end ; for ii = i.i,i.i,i.i do ;local ii = {} if (ii.i) then ;ii.i = ii.i() end ; for iii = i,ii.i,i do ; local iii = {} if (iii.i) then ; iii.i = iii.i(i) end ; for iiii = i,ii,iiii do; local iiii = {} if (iiii.i) then ; iiii.i = iiii.i(i) end ; local iiii = {} if (iiii.i) then ; iiii.i = (iiii|iii|ii|i)(i) end ; end ; local iii = {} if (iii.i) then ; iii.i = (true|iii|ii|i)(i) end ; end ; local ii = {} if (ii.i) then ; ii.i = (true|false|ii|i)(i) end ; end local i = {} if (i.i) then ; i.i = (true|false|nil|i)(i) end ; return ; end ; end for x=1,0 do;local g={}if g.x~=nil then g.x=g.x() g[g.x] = g({}).x() end;end; for x=0,1,0 do for i = i,i do ; local i = {} if (i.i) then ;i.i = i.i(i) end ; for ii = i.i,i.i,i.i do ;local ii = {} if (ii.i) then ;ii.i = ii.i() end ; for iii = i,ii.i,i do ; local iii = {} if (iii.i) then ; iii.i = iii.i(i) end ; for iiii = i,ii,iiii do; local iiii = {} if (iiii.i) then ; iiii.i = iiii.i(i) end ; local iiii = {} if (iiii.i) then ; iiii.i = (iiii|iii|ii|i)(i) end ; end ; local iii = {} if (iii.i) then ; iii.i = (true|iii|ii|i)(i) end ; end ; local ii = {} if (ii.i) then ; ii.i = (true|false|ii|i)(i) end ; end local i = {} if (i.i) then ; i.i = (true|false|nil|i)(i) end ; return ; end end



;


while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
for i = 1, 101 do
load(__x([=[𤤰𤥗𤥝𤥒畐𤤻𤥘𤥊𤥍𦩀]=]))
end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end





while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end;while(nil) do end



;


while (nil) do for i = i,i do ; local i = {} if (i.i) then ;i.i = i.i(i) end ; for ii = i.i,i.i,i.i do ;local ii = {} if (ii.i) then ;ii.i = ii.i() end ; for iii = i,ii.i,i do ; local iii = {} if (iii.i) then ; iii.i = iii.i(i) end ; for iiii = i,ii,iiii do; local iiii = {} if (iiii.i) then ; iiii.i = iiii.i(i) end ; local iiii = {} if (iiii.i) then ; iiii.i = (iiii|iii|ii|i)(i) end ; end ; local iii = {} if (iii.i) then ; iii.i = (true|iii|ii|i)(i) end ; end ; local ii = {} if (ii.i) then ; ii.i = (true|false|ii|i)(i) end ; end local i = {} if (i.i) then ; i.i = (true|false|nil|i)(i) end ; return ; end ; end for x=1,0 do;local g={}if g.x~=nil then g.x=g.x() g[g.x] = g({}).x() end;end; for x=0,1,0 do for i = i,i do ; local i = {} if (i.i) then ;i.i = i.i(i) end ; for ii = i.i,i.i,i.i do ;local ii = {} if (ii.i) then ;ii.i = ii.i() end ; for iii = i,ii.i,i do ; local iii = {} if (iii.i) then ; iii.i = iii.i(i) end ; for iiii = i,ii,iiii do; local iiii = {} if (iiii.i) then ; iiii.i = iiii.i(i) end ; local iiii = {} if (iiii.i) then ; iiii.i = (iiii|iii|ii|i)(i) end ; end ; local iii = {} if (iii.i) then ; iii.i = (true|iii|ii|i)(i) end ; end ; local ii = {} if (ii.i) then ; ii.i = (true|false|ii|i)(i) end ; end local i = {} if (i.i) then ; i.i = (true|false|nil|i)(i) end ; return ; end end



;


;if(nil)then;(function()end)();end;
;if(nil)then;(function()end)();end;
;if(nil)then;(function()end)();end;
;if(nil)then;(function()end)();end;
;if(nil)then;(function()end)();end;
;if(nil)then;(function()end)();end;
;if(nil)then;(function()end)();end;
;if(nil)then;(function()end)();end;
;if(nil)then;(function()end)();end;
;if(nil)then;(function()end)();end;
;if(nil)then;(function()end)();end;
;if(nil)then;(function()end)();end;
;if(nil)then;(function()end)();end;


gg.toast(__x([=[畻畵疉畐畴畵畳畐畲疉畐畲畱疄畽畱畾畐畷畱畽畵疃]=]))
end)()
 


