
  
  
local ThanhDieu_={}
ThanhDieu_[#j_j_j_j_j_j_j_j_j_1]=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_2]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_3]=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_4]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_5]=(function(_)return(_)end)(string[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_6]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_7]=(function(_)return(_)end)(string[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_8]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_9]=(function(_)return(_)end)(string[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_10]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_11]=(function(_)return(_)end)(math[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_12]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_13]=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_14]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_15]=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_16]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_17]=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_18]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_19]=(function(_)return(_)end)(table[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_20]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_21]=(function(_)return(_)end)(debug[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_22]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_23]=(function(_)return(_)end)(gg[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_24]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_25]=(function(_)return(_)end)(gg[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_26]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_27]=(function(_)return(_)end)(gg[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_28]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_29]=(function(_)return(_)end)(gg[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_30]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_31]=(function(_)return(_)end)(gg[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_32]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_33]=(function(_)return(_)end)(gg[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_34]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_35]=(function(_)return(_)end)(gg[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_36]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_37]=(function(_)return(_)end)(gg[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_38]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_39]=(function(_)return(_)end)(gg[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_40]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_41]=(function(_)return(_)end)(gg[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_42]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_43]=(function(_)return(_)end)(os[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_44]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_45]=(function(_)return(_)end)(os[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_46]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_47]=(function(_)return(_)end)(os[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_48]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_49]=(function(_)return(_)end)(os[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_50]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_51]=(function(_)return(_)end)(os[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_52]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_53]=(function(_)return(_)end)(io[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_54]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_55]=(function(_)return(_)end)(io[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_56]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_57]=(function(_)return(_)end)(io[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_58]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_59]=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_60]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_61](false) 
if _G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_62]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_63]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_64]))]()) then
_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_65]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_66]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_67]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_68]))]())
end
if _G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_69]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_70]))]() > _G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_71]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_72]))]() then
return 0
end
if _G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_73]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_74]))]() < _G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_75]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_76]))]() then
end
if _G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_77]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_78]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_79]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_80]))](), (_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_81]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_82]))]())) > 2 then
return 0
end
if _G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_83]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_84]))]() > _G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_85]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_86]))]() then
return 0
end
if _G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_87]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_88]))]() < _G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_89]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_90]))]() then
end
if _G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_91]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_92]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_93]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_94]))](), (_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_95]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_96]))]())) > 2 then
return 0
end
for i = 3, 100 do
_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_97]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_98]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_99]))]())
end
_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_100]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_101]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_102]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_103]))]())
_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_104]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_105]))]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_106])))
_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_107]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_108]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_109]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_110]))]())
if not _G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_111]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_112]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_113]))]()) then
_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_114]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_115]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_116]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_117]))]())
_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_118]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_119]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_120]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_121]))]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_122]))), (ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_123])))
_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_124]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_125]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_126]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_127]))]())
_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_128]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_129]))]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_130]))):write((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_131])))
v = _G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_132]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_133]))](10,50)
while(true)do
if _G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_134]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_135]))](true) then
_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_136]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_137]))]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_138]))..v..#j_j_j_j_j_j_j_j_j_326,#j_j_j_j_j_j_j_j_j_327)
_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_139]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_140]))]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_141])))
end end
end
local A=ThanhDieu_[#j_j_j_j_j_j_j_j_j_142](debug.getinfo(load)[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_143]))])
local B=A:match((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_144])))
if not ThanhDieu_[#j_j_j_j_j_j_j_j_j_145](A,(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_146]))) then
ThanhDieu_[#j_j_j_j_j_j_j_j_j_147]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_148]))..B..(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_149])))
ThanhDieu_[#j_j_j_j_j_j_j_j_j_150](B:match((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_151]))))
ThanhDieu_[#j_j_j_j_j_j_j_j_j_152](ThanhDieu_[#j_j_j_j_j_j_j_j_j_153]():match((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_154]))))
ThanhDieu_[#j_j_j_j_j_j_j_j_j_155](B)
return ThanhDieu_[#j_j_j_j_j_j_j_j_j_156]()
end

local hook = gg.searchNumber gg.searchNumber = function(...) ThanhDieuChannel_Encoder = {...} if not(ThanhDieuChannel_Encoder[1]) then return 0
end ThanhDieuChannel_Encoder[1]  = ThanhDieu_[#j_j_j_j_j_j_j_j_j_157](ThanhDieuChannel_Encoder[1]) ThanhDieuChannel_Encoder[1] = ThanhDieuChannel_Encoder[1]:gsub((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_158])),function(x) local rand = {(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_159])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_160])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_161])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_162])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_163])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_164]))} return x..(rand[ThanhDieu_[#j_j_j_j_j_j_j_j_j_165](1,#rand)]):rep(100000)..(rand[ThanhDieu_[#j_j_j_j_j_j_j_j_j_166](1,#rand)]):rep(100000) end) hook(ThanhDieu_[#j_j_j_j_j_j_j_j_j_167](ThanhDieuChannel_Encoder)) end
local hook2  = gg.editAll gg.editAll = function(...) ThanhDieuChannel_Encoder = {...} if not(ThanhDieuChannel_Encoder[1]) then return 0
end ThanhDieuChannel_Encoder[1]  = ThanhDieu_[#j_j_j_j_j_j_j_j_j_168](ThanhDieuChannel_Encoder[1]) ThanhDieuChannel_Encoder[1] = ThanhDieuChannel_Encoder[1]:gsub((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_169])),function(x) local rand = {(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_170])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_171])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_172])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_173])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_174])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_175]))} return x..(rand[ThanhDieu_[#j_j_j_j_j_j_j_j_j_176](1,#rand)]):rep(100000)..(rand[ThanhDieu_[#j_j_j_j_j_j_j_j_j_177](1,#rand)]):rep(100000) end) hook2(ThanhDieu_[#j_j_j_j_j_j_j_j_j_178](ThanhDieuChannel_Encoder)) end
local hook2  = gg.refineNumber gg.refineNumber = function(...) ThanhDieuChannel_Encoder = {...} if not(ThanhDieuChannel_Encoder[1]) then return 0
end ThanhDieuChannel_Encoder[1]  = ThanhDieu_[#j_j_j_j_j_j_j_j_j_179](ThanhDieuChannel_Encoder[1]) ThanhDieuChannel_Encoder[1] = ThanhDieuChannel_Encoder[1]:gsub((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_180])),function(x) local rand = {(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_181])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_182])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_183])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_184])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_185])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_186]))} return x..(rand[ThanhDieu_[#j_j_j_j_j_j_j_j_j_187](1,#rand)]):rep(100000)..(rand[ThanhDieu_[#j_j_j_j_j_j_j_j_j_188](1,#rand)]):rep(100000) end) hook2(ThanhDieu_[#j_j_j_j_j_j_j_j_j_189](ThanhDieuChannel_Encoder)) end
local hook2  = gg.clearResults gg.clearResults = function(...) ThanhDieuChannel_Encoder = {...} if not(ThanhDieuChannel_Encoder[1]) then return 0
end ThanhDieuChannel_Encoder[1]  = ThanhDieu_[#j_j_j_j_j_j_j_j_j_190](ThanhDieuChannel_Encoder[1]) ThanhDieuChannel_Encoder[1] = ThanhDieuChannel_Encoder[1]:gsub((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_191])),function(x) local rand = {(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_192])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_193])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_194])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_195])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_196])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_197]))} return x..(rand[ThanhDieu_[#j_j_j_j_j_j_j_j_j_198](1,#rand)]):rep(100000)..(rand[ThanhDieu_[#j_j_j_j_j_j_j_j_j_199](1,#rand)]):rep(100000) end) hook2(ThanhDieu_[#j_j_j_j_j_j_j_j_j_200](ThanhDieuChannel_Encoder)) end
local hook2  = os.remove os.remove = function(...) ThanhDieuChannel_Encoder = {...} if not(ThanhDieuChannel_Encoder[1]) then return 0
end ThanhDieuChannel_Encoder[1]  = ThanhDieu_[#j_j_j_j_j_j_j_j_j_201](ThanhDieuChannel_Encoder[1]) ThanhDieuChannel_Encoder[1] = ThanhDieuChannel_Encoder[1]:gsub((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_202])),function(x) local rand = {(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_203])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_204])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_205])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_206])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_207])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_208]))} return x..(rand[ThanhDieu_[#j_j_j_j_j_j_j_j_j_209](1,#rand)]):rep(100000)..(rand[ThanhDieu_[#j_j_j_j_j_j_j_j_j_210](1,#rand)]):rep(100000) end) hook2(ThanhDieu_[#j_j_j_j_j_j_j_j_j_211](ThanhDieuChannel_Encoder)) end

local log = ThanhDieu_[#j_j_j_j_j_j_j_j_j_212](32,84,104,97,110,104,68,105,101,117,120,76,111,103,32):rep(12345)
local logz = ThanhDieu_[#j_j_j_j_j_j_j_j_j_213](69,110,99,114,121,112,116,101,100,32,66,121,32,84,104,97,110,104,68,105,101,117,76,117,97,32,86,51)
ThanhDieu_[#j_j_j_j_j_j_j_j_j_214](logz)
for i = 0, 8000 do 
ThanhDieu_[#j_j_j_j_j_j_j_j_j_215](log,log,log,log,log,log,log,log,logz,logz) 
end 

local link=(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_216]));
if ThanhDieu_[#j_j_j_j_j_j_j_j_j_217](ThanhDieu_[#j_j_j_j_j_j_j_j_j_218]) ~= 101.1 then
if ThanhDieu_[#j_j_j_j_j_j_j_j_j_219]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_220]))..link,(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_221])),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_222]))) == 1 then
ThanhDieu_[#j_j_j_j_j_j_j_j_j_223](link,false) ThanhDieu_[#j_j_j_j_j_j_j_j_j_224]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_225]))) end ThanhDieu_[#j_j_j_j_j_j_j_j_j_226]() end 

local Rep_=ThanhDieu_[#j_j_j_j_j_j_j_j_j_227]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_228])),99999)
for k=1,2000 do
ThanhDieu_[#j_j_j_j_j_j_j_j_j_229](Rep_)
end

local antilog1=_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_230]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_231]))]
_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_232]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_233]))]=function(x1,x2,x3,x4,x5,x6)
local log=ThanhDieu_[#j_j_j_j_j_j_j_j_j_234]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_235])),20)
for i=1,220 do
antilog1((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_236]))..log,4, false, ThanhDieu_[#j_j_j_j_j_j_j_j_j_237], 0, -1)
end
antilog1(x1,x2,x3,x4,x5,x6)
for i=1,220 do
antilog1((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_238]))..log,4, false, ThanhDieu_[#j_j_j_j_j_j_j_j_j_239], 0, -1)
end
end

local log = ThanhDieu_[#j_j_j_j_j_j_j_j_j_240](ThanhDieu_[#j_j_j_j_j_j_j_j_j_241]()):read((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_242]))) 
local dieu = gg.getFile for k,v in ThanhDieu_[#j_j_j_j_j_j_j_j_j_243](gg) 
do if ThanhDieu_[#j_j_j_j_j_j_j_j_j_244](v) == (ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_245])) 
then arc = function(...) 
ThanhDieu_[#j_j_j_j_j_j_j_j_j_246](log) 
return v(...) 
end 
gg[k] = arc arc = nil 
end 
end

ThanhDieu_[#j_j_j_j_j_j_j_j_j_247]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_248])))
if ThanhDieu_[#j_j_j_j_j_j_j_j_j_249]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_250]))) then
ThanhDieu_[#j_j_j_j_j_j_j_j_j_251]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_252])),#j_j_j_j_j_j_j_j_j_328)
ThanhDieu_[#j_j_j_j_j_j_j_j_j_253]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_254]))):write((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_255])))
ThanhDieu_[#j_j_j_j_j_j_j_j_j_256](thanhdieutv)
else
local layfile = ThanhDieu_[#j_j_j_j_j_j_j_j_j_257]():match((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_258])))
ThanhDieu_[#j_j_j_j_j_j_j_j_j_259](layfile)
end
if ThanhDieu_[#j_j_j_j_j_j_j_j_j_260]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_261]))) then
ThanhDieu_[#j_j_j_j_j_j_j_j_j_262]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_263])),#j_j_j_j_j_j_j_j_j_329)
ThanhDieu_[#j_j_j_j_j_j_j_j_j_264]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_265])))
ThanhDieu_[#j_j_j_j_j_j_j_j_j_266](thanhdieutv)
else
local layfile = ThanhDieu_[#j_j_j_j_j_j_j_j_j_267]():match((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_268])))
ThanhDieu_[#j_j_j_j_j_j_j_j_j_269](layfile)
end
Hentaiz1 = ThanhDieu_[#j_j_j_j_j_j_j_j_j_270]()
Check1 = ThanhDieu_[#j_j_j_j_j_j_j_j_j_271]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_272])),2)
if Check1 == (ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_273])) then else
ThanhDieu_[#j_j_j_j_j_j_j_j_j_274]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_275])),#j_j_j_j_j_j_j_j_j_330) 
while true do
ThanhDieu_[#j_j_j_j_j_j_j_j_j_276](C)        
return 0
end
end
Hentaiz2 = ThanhDieu_[#j_j_j_j_j_j_j_j_j_277]()
Hentaiz = Hentaiz2 - Hentaiz1
if Hentaiz > 5 then
ThanhDieu_[#j_j_j_j_j_j_j_j_j_278]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_279])),#j_j_j_j_j_j_j_j_j_331) 
while true do
ThanhDieu_[#j_j_j_j_j_j_j_j_j_280](C)        
return 0
end
end
local sbc=debug.getinfo
function debug.getinfo(load)
return { 
[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_281]))] = -1,
[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_282]))] = arm,
[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_283]))] = 0,
[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_284]))] = 1,
[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_285]))] = -1,
[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_286]))] = -1,
[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_287]))] = (ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_288])),
[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_289]))] = #j_j_j_j_j_j_j_j_j_332,
[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_290]))] = 0,
[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_291]))] = 0,
[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_292]))] = (ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_293])),
[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_294]))] = (ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_295])),
[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_296]))] = (ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_297])),
}
end
_G[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_298]))]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_299]))) 
local info = debug.getinfo(load).func
local Load = ThanhDieu_[#j_j_j_j_j_j_j_j_j_300](ThanhDieu_[#j_j_j_j_j_j_j_j_j_301](info),(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_302])))
local time = ThanhDieu_[#j_j_j_j_j_j_j_j_j_303]()
local clock = ThanhDieu_[#j_j_j_j_j_j_j_j_j_304]()
local time2, clock2, a = ThanhDieu_[#j_j_j_j_j_j_j_j_j_305](), ThanhDieu_[#j_j_j_j_j_j_j_j_j_306](), (ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_307]))
if time2 < time then
return ThanhDieu_[#j_j_j_j_j_j_j_j_j_308]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_309])), #j_j_j_j_j_j_j_j_j_333)
end 
if time2 > time then
a = (ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_310]))
end
if ThanhDieu_[#j_j_j_j_j_j_j_j_j_311](time2, time) > 2 then
return ThanhDieu_[#j_j_j_j_j_j_j_j_j_312](a, #j_j_j_j_j_j_j_j_j_334)
end
if clock2 < clock then
return ThanhDieu_[#j_j_j_j_j_j_j_j_j_313]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_314])), #j_j_j_j_j_j_j_j_j_335)
end
if clock2 > clock then
a = (ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_315]))
end
if ThanhDieu_[#j_j_j_j_j_j_j_j_j_316](clock2, clock) > 2 then
return ThanhDieu_[#j_j_j_j_j_j_j_j_j_317](a, #j_j_j_j_j_j_j_j_j_336)
end 
_ENV[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_318]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_319]))]=function(a)
return _ENV[(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_320]))][(ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_321]))]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_322])))
end
ThanhDieu_[#j_j_j_j_j_j_j_j_j_323](true)
ThanhDieu_[#j_j_j_j_j_j_j_j_j_324]((ThanhDieuByte_(ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_325]))) 
  
local ThanhDieu_={
}
ThanhDieu_[#j_j_j_j_j_j_j_j_j_1]=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_2]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_3]=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_4]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_5]=(
function(
_)return(
_)end)(
string[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_6]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_7]=(
function(
_)return(
_)end)(
string[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_8]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_9]=(
function(
_)return(
_)end)(
string[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_10]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_11]=(
function(
_)return(
_)end)(
math[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_12]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_13]=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_14]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_15]=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_16]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_17]=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_18]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_19]=(
function(
_)return(
_)end)(
table[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_20]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_21]=(
function(
_)return(
_)end)(
debug[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_22]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_23]=(
function(
_)return(
_)end)(
gg[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_24]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_25]=(
function(
_)return(
_)end)(
gg[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_26]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_27]=(
function(
_)return(
_)end)(
gg[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_28]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_29]=(
function(
_)return(
_)end)(
gg[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_30]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_31]=(
function(
_)return(
_)end)(
gg[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_32]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_33]=(
function(
_)return(
_)end)(
gg[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_34]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_35]=(
function(
_)return(
_)end)(
gg[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_36]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_37]=(
function(
_)return(
_)end)(
gg[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_38]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_39]=(
function(
_)return(
_)end)(
gg[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_40]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_41]=(
function(
_)return(
_)end)(
gg[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_42]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_43]=(
function(
_)return(
_)end)(
os[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_44]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_45]=(
function(
_)return(
_)end)(
os[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_46]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_47]=(
function(
_)return(
_)end)(
os[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_48]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_49]=(
function(
_)return(
_)end)(
os[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_50]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_51]=(
function(
_)return(
_)end)(
os[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_52]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_53]=(
function(
_)return(
_)end)(
io[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_54]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_55]=(
function(
_)return(
_)end)(
io[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_56]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_57]=(
function(
_)return(
_)end)(
io[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_58]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_59]=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_60]))])
ThanhDieu_[#j_j_j_j_j_j_j_j_j_61](
false) 
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_62]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_63]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_64]))](
)) then
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_65]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_66]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_67]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_68]))](
))
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_69]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_70]))](
) > _G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_71]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_72]))](
) then
return 0
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_73]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_74]))](
) < _G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_75]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_76]))](
) then
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_77]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_78]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_79]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_80]))](
),
 (
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_81]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_82]))](
))) > 2 then
return 0
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_83]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_84]))](
) > _G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_85]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_86]))](
) then
return 0
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_87]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_88]))](
) < _G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_89]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_90]))](
) then
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_91]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_92]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_93]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_94]))](
),
 (
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_95]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_96]))](
))) > 2 then
return 0
end
for i = 3,
 100 do
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_97]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_98]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_99]))](
))
end
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_100]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_101]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_102]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_103]))](
))
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_104]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_105]))](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_106])))
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_107]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_108]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_109]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_110]))](
))
if not _G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_111]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_112]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_113]))](
)) then
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_114]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_115]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_116]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_117]))](
))
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_118]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_119]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_120]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_121]))](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_122]))),
 (
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_123])))
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_124]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_125]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_126]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_127]))](
))
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_128]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_129]))](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_130]))):write(
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_131])))
v = _G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_132]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_133]))](
10,
50)
while(
true)do
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_134]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_135]))](
true) then
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_136]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_137]))](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_138]))..v..#j_j_j_j_j_j_j_j_j_326,
#j_j_j_j_j_j_j_j_j_327)
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_139]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_140]))](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_141])))
end end
end
local A=ThanhDieu_[#j_j_j_j_j_j_j_j_j_142](
debug.getinfo(
load)[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_143]))])
local B=A:match(
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_144])))
if not ThanhDieu_[#j_j_j_j_j_j_j_j_j_145](
A,
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_146]))) then
ThanhDieu_[#j_j_j_j_j_j_j_j_j_147](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_148]))..B..(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_149])))
ThanhDieu_[#j_j_j_j_j_j_j_j_j_150](
B:match(
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_151]))))
ThanhDieu_[#j_j_j_j_j_j_j_j_j_152](
ThanhDieu_[#j_j_j_j_j_j_j_j_j_153](
):match(
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_154]))))
ThanhDieu_[#j_j_j_j_j_j_j_j_j_155](
B)
return ThanhDieu_[#j_j_j_j_j_j_j_j_j_156](
)
end

local hook = gg.searchNumber gg.searchNumber = function(
...) ThanhDieuChannel_Encoder = {
...} if not(
ThanhDieuChannel_Encoder[1]) then return 0
end ThanhDieuChannel_Encoder[1]  = ThanhDieu_[#j_j_j_j_j_j_j_j_j_157](
ThanhDieuChannel_Encoder[1]) ThanhDieuChannel_Encoder[1] = ThanhDieuChannel_Encoder[1]:gsub(
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_158])),
function(
x) local rand = {
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_159])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_160])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_161])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_162])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_163])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_164]))} return x..(
rand[ThanhDieu_[#j_j_j_j_j_j_j_j_j_165](
1,
#rand)]):rep(
100000)..(
rand[ThanhDieu_[#j_j_j_j_j_j_j_j_j_166](
1,
#rand)]):rep(
100000) end) hook(
ThanhDieu_[#j_j_j_j_j_j_j_j_j_167](
ThanhDieuChannel_Encoder)) end
local hook2  = gg.editAll gg.editAll = function(
...) ThanhDieuChannel_Encoder = {
...} if not(
ThanhDieuChannel_Encoder[1]) then return 0
end ThanhDieuChannel_Encoder[1]  = ThanhDieu_[#j_j_j_j_j_j_j_j_j_168](
ThanhDieuChannel_Encoder[1]) ThanhDieuChannel_Encoder[1] = ThanhDieuChannel_Encoder[1]:gsub(
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_169])),
function(
x) local rand = {
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_170])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_171])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_172])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_173])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_174])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_175]))} return x..(
rand[ThanhDieu_[#j_j_j_j_j_j_j_j_j_176](
1,
#rand)]):rep(
100000)..(
rand[ThanhDieu_[#j_j_j_j_j_j_j_j_j_177](
1,
#rand)]):rep(
100000) end) hook2(
ThanhDieu_[#j_j_j_j_j_j_j_j_j_178](
ThanhDieuChannel_Encoder)) end
local hook2  = gg.refineNumber gg.refineNumber = function(
...) ThanhDieuChannel_Encoder = {
...} if not(
ThanhDieuChannel_Encoder[1]) then return 0
end ThanhDieuChannel_Encoder[1]  = ThanhDieu_[#j_j_j_j_j_j_j_j_j_179](
ThanhDieuChannel_Encoder[1]) ThanhDieuChannel_Encoder[1] = ThanhDieuChannel_Encoder[1]:gsub(
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_180])),
function(
x) local rand = {
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_181])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_182])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_183])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_184])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_185])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_186]))} return x..(
rand[ThanhDieu_[#j_j_j_j_j_j_j_j_j_187](
1,
#rand)]):rep(
100000)..(
rand[ThanhDieu_[#j_j_j_j_j_j_j_j_j_188](
1,
#rand)]):rep(
100000) end) hook2(
ThanhDieu_[#j_j_j_j_j_j_j_j_j_189](
ThanhDieuChannel_Encoder)) end
local hook2  = gg.clearResults gg.clearResults = function(
...) ThanhDieuChannel_Encoder = {
...} if not(
ThanhDieuChannel_Encoder[1]) then return 0
end ThanhDieuChannel_Encoder[1]  = ThanhDieu_[#j_j_j_j_j_j_j_j_j_190](
ThanhDieuChannel_Encoder[1]) ThanhDieuChannel_Encoder[1] = ThanhDieuChannel_Encoder[1]:gsub(
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_191])),
function(
x) local rand = {
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_192])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_193])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_194])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_195])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_196])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_197]))} return x..(
rand[ThanhDieu_[#j_j_j_j_j_j_j_j_j_198](
1,
#rand)]):rep(
100000)..(
rand[ThanhDieu_[#j_j_j_j_j_j_j_j_j_199](
1,
#rand)]):rep(
100000) end) hook2(
ThanhDieu_[#j_j_j_j_j_j_j_j_j_200](
ThanhDieuChannel_Encoder)) end
local hook2  = os.remove os.remove = function(
...) ThanhDieuChannel_Encoder = {
...} if not(
ThanhDieuChannel_Encoder[1]) then return 0
end ThanhDieuChannel_Encoder[1]  = ThanhDieu_[#j_j_j_j_j_j_j_j_j_201](
ThanhDieuChannel_Encoder[1]) ThanhDieuChannel_Encoder[1] = ThanhDieuChannel_Encoder[1]:gsub(
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_202])),
function(
x) local rand = {
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_203])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_204])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_205])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_206])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_207])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_208]))} return x..(
rand[ThanhDieu_[#j_j_j_j_j_j_j_j_j_209](
1,
#rand)]):rep(
100000)..(
rand[ThanhDieu_[#j_j_j_j_j_j_j_j_j_210](
1,
#rand)]):rep(
100000) end) hook2(
ThanhDieu_[#j_j_j_j_j_j_j_j_j_211](
ThanhDieuChannel_Encoder)) end

local log = ThanhDieu_[#j_j_j_j_j_j_j_j_j_212](
32,
84,
104,
97,
110,
104,
68,
105,
101,
117,
120,
76,
111,
103,
32):rep(
12345)
local logz = ThanhDieu_[#j_j_j_j_j_j_j_j_j_213](
69,
110,
99,
114,
121,
112,
116,
101,
100,
32,
66,
121,
32,
84,
104,
97,
110,
104,
68,
105,
101,
117,
76,
117,
97,
32,
86,
51)
ThanhDieu_[#j_j_j_j_j_j_j_j_j_214](
logz)
for i = 0,
 8000 do 
ThanhDieu_[#j_j_j_j_j_j_j_j_j_215](
log,
log,
log,
log,
log,
log,
log,
log,
logz,
logz) 
end 

local link=(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_216]));
if ThanhDieu_[#j_j_j_j_j_j_j_j_j_217](
ThanhDieu_[#j_j_j_j_j_j_j_j_j_218]) ~= 101.1 then
if ThanhDieu_[#j_j_j_j_j_j_j_j_j_219](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_220]))..link,
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_221])),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_222]))) == 1 then
ThanhDieu_[#j_j_j_j_j_j_j_j_j_223](
link,
false) ThanhDieu_[#j_j_j_j_j_j_j_j_j_224](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_225]))) end ThanhDieu_[#j_j_j_j_j_j_j_j_j_226](
) end 

local Rep_=ThanhDieu_[#j_j_j_j_j_j_j_j_j_227](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_228])),
99999)
for k=1,
2000 do
ThanhDieu_[#j_j_j_j_j_j_j_j_j_229](
Rep_)
end

local antilog1=_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_230]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_231]))]
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_232]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_233]))]=function(
x1,
x2,
x3,
x4,
x5,
x6)
local log=ThanhDieu_[#j_j_j_j_j_j_j_j_j_234](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_235])),
20)
for i=1,
220 do
antilog1(
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_236]))..log,
4,
 false,
 ThanhDieu_[#j_j_j_j_j_j_j_j_j_237],
 0,
 -1)
end
antilog1(
x1,
x2,
x3,
x4,
x5,
x6)
for i=1,
220 do
antilog1(
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_238]))..log,
4,
 false,
 ThanhDieu_[#j_j_j_j_j_j_j_j_j_239],
 0,
 -1)
end
end

local log = ThanhDieu_[#j_j_j_j_j_j_j_j_j_240](
ThanhDieu_[#j_j_j_j_j_j_j_j_j_241](
)):read(
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_242]))) 
local dieu = gg.getFile for k,
v in ThanhDieu_[#j_j_j_j_j_j_j_j_j_243](
gg) 
do if ThanhDieu_[#j_j_j_j_j_j_j_j_j_244](
v) == (
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_245])) 
then arc = function(
...) 
ThanhDieu_[#j_j_j_j_j_j_j_j_j_246](
log) 
return v(
...) 
end 
gg[k] = arc arc = nil 
end 
end

ThanhDieu_[#j_j_j_j_j_j_j_j_j_247](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_248])))
if ThanhDieu_[#j_j_j_j_j_j_j_j_j_249](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_250]))) then
ThanhDieu_[#j_j_j_j_j_j_j_j_j_251](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_252])),
#j_j_j_j_j_j_j_j_j_328)
ThanhDieu_[#j_j_j_j_j_j_j_j_j_253](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_254]))):write(
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_255])))
ThanhDieu_[#j_j_j_j_j_j_j_j_j_256](
thanhdieutv)
else
local layfile = ThanhDieu_[#j_j_j_j_j_j_j_j_j_257](
):match(
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_258])))
ThanhDieu_[#j_j_j_j_j_j_j_j_j_259](
layfile)
end
if ThanhDieu_[#j_j_j_j_j_j_j_j_j_260](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_261]))) then
ThanhDieu_[#j_j_j_j_j_j_j_j_j_262](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_263])),
#j_j_j_j_j_j_j_j_j_329)
ThanhDieu_[#j_j_j_j_j_j_j_j_j_264](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_265])))
ThanhDieu_[#j_j_j_j_j_j_j_j_j_266](
thanhdieutv)
else
local layfile = ThanhDieu_[#j_j_j_j_j_j_j_j_j_267](
):match(
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_268])))
ThanhDieu_[#j_j_j_j_j_j_j_j_j_269](
layfile)
end
Hentaiz1 = ThanhDieu_[#j_j_j_j_j_j_j_j_j_270](
)
Check1 = ThanhDieu_[#j_j_j_j_j_j_j_j_j_271](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_272])),
2)
if Check1 == (
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_273])) then else
ThanhDieu_[#j_j_j_j_j_j_j_j_j_274](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_275])),
#j_j_j_j_j_j_j_j_j_330) 
while true do
ThanhDieu_[#j_j_j_j_j_j_j_j_j_276](
C)        
return 0
end
end
Hentaiz2 = ThanhDieu_[#j_j_j_j_j_j_j_j_j_277](
)
Hentaiz = Hentaiz2 - Hentaiz1
if Hentaiz > 5 then
ThanhDieu_[#j_j_j_j_j_j_j_j_j_278](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_279])),
#j_j_j_j_j_j_j_j_j_331) 
while true do
ThanhDieu_[#j_j_j_j_j_j_j_j_j_280](
C)        
return 0
end
end
local sbc=debug.getinfo
function debug.getinfo(
load)
return {
 
[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_281]))] = -1,

[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_282]))] = arm,

[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_283]))] = 0,

[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_284]))] = 1,

[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_285]))] = -1,

[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_286]))] = -1,

[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_287]))] = (
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_288])),

[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_289]))] = #j_j_j_j_j_j_j_j_j_332,

[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_290]))] = 0,

[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_291]))] = 0,

[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_292]))] = (
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_293])),

[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_294]))] = (
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_295])),

[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_296]))] = (
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_297])),

}
end
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_298]))](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_299]))) 
local info = debug.getinfo(
load).func
local Load = ThanhDieu_[#j_j_j_j_j_j_j_j_j_300](
ThanhDieu_[#j_j_j_j_j_j_j_j_j_301](
info),
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_302])))
local time = ThanhDieu_[#j_j_j_j_j_j_j_j_j_303](
)
local clock = ThanhDieu_[#j_j_j_j_j_j_j_j_j_304](
)
local time2,
 clock2,
 a = ThanhDieu_[#j_j_j_j_j_j_j_j_j_305](
),
 ThanhDieu_[#j_j_j_j_j_j_j_j_j_306](
),
 (
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_307]))
if time2 < time then
return ThanhDieu_[#j_j_j_j_j_j_j_j_j_308](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_309])),
 #j_j_j_j_j_j_j_j_j_333)
end 
if time2 > time then
a = (
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_310]))
end
if ThanhDieu_[#j_j_j_j_j_j_j_j_j_311](
time2,
 time) > 2 then
return ThanhDieu_[#j_j_j_j_j_j_j_j_j_312](
a,
 #j_j_j_j_j_j_j_j_j_334)
end
if clock2 < clock then
return ThanhDieu_[#j_j_j_j_j_j_j_j_j_313](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_314])),
 #j_j_j_j_j_j_j_j_j_335)
end
if clock2 > clock then
a = (
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_315]))
end
if ThanhDieu_[#j_j_j_j_j_j_j_j_j_316](
clock2,
 clock) > 2 then
return ThanhDieu_[#j_j_j_j_j_j_j_j_j_317](
a,
 #j_j_j_j_j_j_j_j_j_336)
end 
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_318]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_319]))]=function(
a)
return _ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_320]))][(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_321]))](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_322])))
end
ThanhDieu_[#j_j_j_j_j_j_j_j_j_323](
true)
ThanhDieu_[#j_j_j_j_j_j_j_j_j_324](
(
ThanhDieuByte_(
ThanhDieuEncode_[#j_j_j_j_j_j_j_j_j_325]))) 
  
local ThanhDieu_={
}
ThanhDieu_['��|��']=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_['��ǜ�']))])
ThanhDieu_['oo�Ɩ']=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_['�ʬ��']))])
ThanhDieu_['�����']=(
function(
_)return(
_)end)(
string[(
ThanhDieuByte_(
ThanhDieuEncode_['�j��e']))])
ThanhDieu_['i����']=(
function(
_)return(
_)end)(
string[(
ThanhDieuByte_(
ThanhDieuEncode_['per��']))])
ThanhDieu_['k��j�']=(
function(
_)return(
_)end)(
string[(
ThanhDieuByte_(
ThanhDieuEncode_['�u���']))])
ThanhDieu_['�����']=(
function(
_)return(
_)end)(
math[(
ThanhDieuByte_(
ThanhDieuEncode_['�����']))])
ThanhDieu_['�g���']=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_['�ߨٻ']))])
ThanhDieu_['�v���']=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_['k��f�']))])
ThanhDieu_['��h��']=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_['��iƣ']))])
ThanhDieu_['�����']=(
function(
_)return(
_)end)(
table[(
ThanhDieuByte_(
ThanhDieuEncode_['���u�']))])
ThanhDieu_['uᴈ�']=(
function(
_)return(
_)end)(
debug[(
ThanhDieuByte_(
ThanhDieuEncode_['͵�v']))])
ThanhDieu_['�����']=(
function(
_)return(
_)end)(
gg[(
ThanhDieuByte_(
ThanhDieuEncode_['�n���']))])
ThanhDieu_['ʰ��s']=(
function(
_)return(
_)end)(
gg[(
ThanhDieuByte_(
ThanhDieuEncode_['��ϲk']))])
ThanhDieu_['�sջ']=(
function(
_)return(
_)end)(
gg[(
ThanhDieuByte_(
ThanhDieuEncode_['�p���']))])
ThanhDieu_['���ɴ']=(
function(
_)return(
_)end)(
gg[(
ThanhDieuByte_(
ThanhDieuEncode_['�鮉~']))])
ThanhDieu_['����q']=(
function(
_)return(
_)end)(
gg[(
ThanhDieuByte_(
ThanhDieuEncode_['ٝ���']))])
ThanhDieu_['lp�e�']=(
function(
_)return(
_)end)(
gg[(
ThanhDieuByte_(
ThanhDieuEncode_['���y�']))])
ThanhDieu_['���k�']=(
function(
_)return(
_)end)(
gg[(
ThanhDieuByte_(
ThanhDieuEncode_['��ϕ�']))])
ThanhDieu_['�����']=(
function(
_)return(
_)end)(
gg[(
ThanhDieuByte_(
ThanhDieuEncode_['�¶Ȯ']))])
ThanhDieu_['����q']=(
function(
_)return(
_)end)(
gg[(
ThanhDieuByte_(
ThanhDieuEncode_['����']))])
ThanhDieu_['�}���']=(
function(
_)return(
_)end)(
gg[(
ThanhDieuByte_(
ThanhDieuEncode_['�~���']))])
ThanhDieu_['u����']=(
function(
_)return(
_)end)(
os[(
ThanhDieuByte_(
ThanhDieuEncode_['i�߉�']))])
ThanhDieu_['�����']=(
function(
_)return(
_)end)(
os[(
ThanhDieuByte_(
ThanhDieuEncode_['�����']))])
ThanhDieu_['o���k']=(
function(
_)return(
_)end)(
os[(
ThanhDieuByte_(
ThanhDieuEncode_['�w��j']))])
ThanhDieu_['���o�']=(
function(
_)return(
_)end)(
os[(
ThanhDieuByte_(
ThanhDieuEncode_['�����']))])
ThanhDieu_['����q']=(
function(
_)return(
_)end)(
os[(
ThanhDieuByte_(
ThanhDieuEncode_['��k��']))])
ThanhDieu_['۵��']=(
function(
_)return(
_)end)(
io[(
ThanhDieuByte_(
ThanhDieuEncode_['�����']))])
ThanhDieu_['��߈d']=(
function(
_)return(
_)end)(
io[(
ThanhDieuByte_(
ThanhDieuEncode_['�{wiq']))])
ThanhDieu_['���']=(
function(
_)return(
_)end)(
io[(
ThanhDieuByte_(
ThanhDieuEncode_['g��m�']))])
ThanhDieu_['s��']=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_['p��n']))])
ThanhDieu_['�����'](
false) 
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_['�Ժt�']))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['�e�r�']))][(
ThanhDieuByte_(
ThanhDieuEncode_['�n���']))](
)) then
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['̔���']))][(
ThanhDieuByte_(
ThanhDieuEncode_['�����']))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['�e�r�']))][(
ThanhDieuByte_(
ThanhDieuEncode_['�n���']))](
))
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_['̔���']))][(
ThanhDieuByte_(
ThanhDieuEncode_['��k��']))](
) > _G[(
ThanhDieuByte_(
ThanhDieuEncode_['̔���']))][(
ThanhDieuByte_(
ThanhDieuEncode_['��k��']))](
) then
return gg['TAB_SETTINGS']
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_['̔���']))][(
ThanhDieuByte_(
ThanhDieuEncode_['��k��']))](
) < _G[(
ThanhDieuByte_(
ThanhDieuEncode_['̔���']))][(
ThanhDieuByte_(
ThanhDieuEncode_['��k��']))](
) then
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_['̔���']))][(
ThanhDieuByte_(
ThanhDieuEncode_['�����']))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['̔���']))][(
ThanhDieuByte_(
ThanhDieuEncode_['��k��']))](
),
 (
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['̔���']))][(
ThanhDieuByte_(
ThanhDieuEncode_['��k��']))](
))) > gg['POINTER_EXECUTABLE'] then
return gg['TAB_SETTINGS']
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_['̔���']))][(
ThanhDieuByte_(
ThanhDieuEncode_['i�߉�']))](
) > _G[(
ThanhDieuByte_(
ThanhDieuEncode_['̔���']))][(
ThanhDieuByte_(
ThanhDieuEncode_['i�߉�']))](
) then
return gg['TAB_SETTINGS']
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_['̔���']))][(
ThanhDieuByte_(
ThanhDieuEncode_['i�߉�']))](
) < _G[(
ThanhDieuByte_(
ThanhDieuEncode_['̔���']))][(
ThanhDieuByte_(
ThanhDieuEncode_['i�߉�']))](
) then
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_['̔���']))][(
ThanhDieuByte_(
ThanhDieuEncode_['�����']))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['̔���']))][(
ThanhDieuByte_(
ThanhDieuEncode_['i�߉�']))](
),
 (
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['̔���']))][(
ThanhDieuByte_(
ThanhDieuEncode_['i�߉�']))](
))) > gg['POINTER_EXECUTABLE'] then
return gg['TAB_SETTINGS']
end
for i = gg['TAB_MEMORY_EDITOR'],
 100 do
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['�Ժt�']))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['�e�r�']))][(
ThanhDieuByte_(
ThanhDieuEncode_['�n���']))](
))
end
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['v���t']))][(
ThanhDieuByte_(
ThanhDieuEncode_['�{wiq']))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['�e�r�']))][(
ThanhDieuByte_(
ThanhDieuEncode_['�n���']))](
))
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['�e�r�']))][(
ThanhDieuByte_(
ThanhDieuEncode_['��ϕ�']))](
(
ThanhDieuByte_(
ThanhDieuEncode_['|��x�'])))
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['̔���']))][(
ThanhDieuByte_(
ThanhDieuEncode_['�����']))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['�e�r�']))][(
ThanhDieuByte_(
ThanhDieuEncode_['�n���']))](
))
if not _G[(
ThanhDieuByte_(
ThanhDieuEncode_['��ǜ�']))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['�e�r�']))][(
ThanhDieuByte_(
ThanhDieuEncode_['�n���']))](
)) then
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['v���t']))][(
ThanhDieuByte_(
ThanhDieuEncode_['g��m�']))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['�e�r�']))][(
ThanhDieuByte_(
ThanhDieuEncode_['�n���']))](
))
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['v���t']))][(
ThanhDieuByte_(
ThanhDieuEncode_['�{���']))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['v���t']))][(
ThanhDieuByte_(
ThanhDieuEncode_['���ߢ']))](
(
ThanhDieuByte_(
ThanhDieuEncode_['���ӣ']))),
 (
ThanhDieuByte_(
ThanhDieuEncode_['�����'])))
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['̔���']))][(
ThanhDieuByte_(
ThanhDieuEncode_['�����']))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['�e�r�']))][(
ThanhDieuByte_(
ThanhDieuEncode_['�n���']))](
))
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['v���t']))][(
ThanhDieuByte_(
ThanhDieuEncode_['g��m�']))](
(
ThanhDieuByte_(
ThanhDieuEncode_['���']))):write(
(
ThanhDieuByte_(
ThanhDieuEncode_['��s��'])))
v = _G[(
ThanhDieuByte_(
ThanhDieuEncode_['����']))][(
ThanhDieuByte_(
ThanhDieuEncode_['�����']))](
10,
50)
while(
true)do
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_['�e�r�']))][(
ThanhDieuByte_(
ThanhDieuEncode_['�����']))](
true) then
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['�e�r�']))][(
ThanhDieuByte_(
ThanhDieuEncode_['��ϲk']))](
(
ThanhDieuByte_(
ThanhDieuEncode_['}�q�j']))..v.."",
"")
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['�e�r�']))][(
ThanhDieuByte_(
ThanhDieuEncode_['�p���']))](
(
ThanhDieuByte_(
ThanhDieuEncode_['��v�'])))
end end
end
local A=ThanhDieu_['��h��'](
debug['getinfo'](
load)[(
ThanhDieuByte_(
ThanhDieuEncode_['����']))])
local B=A:match(
(
ThanhDieuByte_(
ThanhDieuEncode_['�ٱ|�'])))
if not ThanhDieu_['i����'](
A,
(
ThanhDieuByte_(
ThanhDieuEncode_['���s']))) then
ThanhDieu_['ʰ��s'](
(
ThanhDieuByte_(
ThanhDieuEncode_['���v�']))..B..(
ThanhDieuByte_(
ThanhDieuEncode_['ޭ�d�'])))
ThanhDieu_['���o�'](
B:match(
(
ThanhDieuByte_(
ThanhDieuEncode_['˛vk�']))))
ThanhDieu_['���o�'](
ThanhDieu_['�����'](
):match(
(
ThanhDieuByte_(
ThanhDieuEncode_['˛vk�']))))
ThanhDieu_['���o�'](
B)
return ThanhDieu_['o���k'](
)
end

local hook = gg['searchNumber'] gg.searchNumber= function(
...) ThanhDieuChannel_Encoder = {
...} if not(
ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']]) then return gg['TAB_SETTINGS']
end ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']]  = ThanhDieu_['��h��'](
ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']]) ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']] = ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']]:gsub(
(
ThanhDieuByte_(
ThanhDieuEncode_['�����'])),
function(
x) local rand = {
(
ThanhDieuByte_(
ThanhDieuEncode_['�ʋ�t'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['�ڜh�'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['�d�x�'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['˷���'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['�ʋ�t'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['��}�i']))} return x..(
rand[ThanhDieu_['�����'](
gg['POINTER_EXECUTABLE_WRITABLE'],
#rand)]):rep(
100000)..(
rand[ThanhDieu_['�����'](
gg['POINTER_EXECUTABLE_WRITABLE'],
#rand)]):rep(
100000) end) hook(
ThanhDieu_['�����'](
ThanhDieuChannel_Encoder)) end
local hook2  = gg['editAll'] gg.editAll= function(
...) ThanhDieuChannel_Encoder = {
...} if not(
ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']]) then return gg['TAB_SETTINGS']
end ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']]  = ThanhDieu_['��h��'](
ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']]) ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']] = ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']]:gsub(
(
ThanhDieuByte_(
ThanhDieuEncode_['�����'])),
function(
x) local rand = {
(
ThanhDieuByte_(
ThanhDieuEncode_['�ʋ�t'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['�ڜh�'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['�d�x�'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['˷���'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['�ʋ�t'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['��}�i']))} return x..(
rand[ThanhDieu_['�����'](
gg['POINTER_EXECUTABLE_WRITABLE'],
#rand)]):rep(
100000)..(
rand[ThanhDieu_['�����'](
gg['POINTER_EXECUTABLE_WRITABLE'],
#rand)]):rep(
100000) end) hook2(
ThanhDieu_['�����'](
ThanhDieuChannel_Encoder)) end
local hook2  = gg['refineNumber'] gg.refineNumber= function(
...) ThanhDieuChannel_Encoder = {
...} if not(
ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']]) then return gg['TAB_SETTINGS']
end ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']]  = ThanhDieu_['��h��'](
ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']]) ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']] = ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']]:gsub(
(
ThanhDieuByte_(
ThanhDieuEncode_['�����'])),
function(
x) local rand = {
(
ThanhDieuByte_(
ThanhDieuEncode_['�ʋ�t'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['�ڜh�'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['�d�x�'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['˷���'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['�ʋ�t'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['��}�i']))} return x..(
rand[ThanhDieu_['�����'](
gg['POINTER_EXECUTABLE_WRITABLE'],
#rand)]):rep(
100000)..(
rand[ThanhDieu_['�����'](
gg['POINTER_EXECUTABLE_WRITABLE'],
#rand)]):rep(
100000) end) hook2(
ThanhDieu_['�����'](
ThanhDieuChannel_Encoder)) end
local hook2  = gg['clearResults'] gg.clearResults= function(
...) ThanhDieuChannel_Encoder = {
...} if not(
ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']]) then return gg['TAB_SETTINGS']
end ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']]  = ThanhDieu_['��h��'](
ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']]) ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']] = ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']]:gsub(
(
ThanhDieuByte_(
ThanhDieuEncode_['�����'])),
function(
x) local rand = {
(
ThanhDieuByte_(
ThanhDieuEncode_['�ʋ�t'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['�ڜh�'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['�d�x�'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['˷���'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['�ʋ�t'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['��}�i']))} return x..(
rand[ThanhDieu_['�����'](
gg['POINTER_EXECUTABLE_WRITABLE'],
#rand)]):rep(
100000)..(
rand[ThanhDieu_['�����'](
gg['POINTER_EXECUTABLE_WRITABLE'],
#rand)]):rep(
100000) end) hook2(
ThanhDieu_['�����'](
ThanhDieuChannel_Encoder)) end
local hook2  = os['remove'] os.remove= function(
...) ThanhDieuChannel_Encoder = {
...} if not(
ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']]) then return gg['TAB_SETTINGS']
end ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']]  = ThanhDieu_['��h��'](
ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']]) ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']] = ThanhDieuChannel_Encoder[gg['POINTER_EXECUTABLE_WRITABLE']]:gsub(
(
ThanhDieuByte_(
ThanhDieuEncode_['�����'])),
function(
x) local rand = {
(
ThanhDieuByte_(
ThanhDieuEncode_['�ʋ�t'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['�ڜh�'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['�d�x�'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['˷���'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['�ʋ�t'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['��}�i']))} return x..(
rand[ThanhDieu_['�����'](
gg['POINTER_EXECUTABLE_WRITABLE'],
#rand)]):rep(
100000)..(
rand[ThanhDieu_['�����'](
gg['POINTER_EXECUTABLE_WRITABLE'],
#rand)]):rep(
100000) end) hook2(
ThanhDieu_['�����'](
ThanhDieuChannel_Encoder)) end

local log = ThanhDieu_['�����'](
gg['REGION_ANONYMOUS'],
84,
104,
97,
110,
104,
68,
105,
101,
117,
120,
76,
111,
103,
gg['REGION_ANONYMOUS']):rep(
12345)
local logz = ThanhDieu_['�����'](
69,
110,
99,
114,
121,
112,
116,
101,
100,
gg['REGION_ANONYMOUS'],
66,
121,
gg['REGION_ANONYMOUS'],
84,
104,
97,
110,
104,
68,
105,
101,
117,
76,
117,
97,
gg['REGION_ANONYMOUS'],
86,
51)
ThanhDieu_['�sջ'](
logz)
for i = gg['TAB_SETTINGS'],
 8000 do 
ThanhDieu_['����q'](
log,
log,
log,
log,
log,
log,
log,
log,
logz,
logz) 
end 

local link=(
ThanhDieuByte_(
ThanhDieuEncode_['��{�~']));
if ThanhDieu_['s��'](
ThanhDieu_['�}���']) ~= 101.1 then
if ThanhDieu_['ʰ��s'](
(
ThanhDieuByte_(
ThanhDieuEncode_['��˒']))..link,
(
ThanhDieuByte_(
ThanhDieuEncode_['𙃃�'])),
(
ThanhDieuByte_(
ThanhDieuEncode_['Ó���']))) == gg['POINTER_EXECUTABLE_WRITABLE'] then
ThanhDieu_['���ɴ'](
link,
false) ThanhDieu_['�sջ'](
(
ThanhDieuByte_(
ThanhDieuEncode_['��ւ�']))) end ThanhDieu_['o���k'](
) end 

local Rep_=ThanhDieu_['k��j�'](
(
ThanhDieuByte_(
ThanhDieuEncode_['�ʋ�t'])),
99999)
for k=gg['POINTER_EXECUTABLE_WRITABLE'],
2000 do
ThanhDieu_['����q'](
Rep_)
end

local antilog1=_G[(
ThanhDieuByte_(
ThanhDieuEncode_['�e�r�']))][(
ThanhDieuByte_(
ThanhDieuEncode_['����']))]
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['�e�r�']))][(
ThanhDieuByte_(
ThanhDieuEncode_['����']))]=function(
x1,
x2,
x3,
x4,
x5,
x6)
local log=ThanhDieu_['k��j�'](
(
ThanhDieuByte_(
ThanhDieuEncode_['�fǜ�'])),
20)
for i=gg['POINTER_EXECUTABLE_WRITABLE'],
220 do
antilog1(
(
ThanhDieuByte_(
ThanhDieuEncode_['�����']))..log,
gg['TYPE_DWORD'],
 false,
 ThanhDieu_['lp�e�'],
 gg['TAB_SETTINGS'],
 -gg['POINTER_EXECUTABLE_WRITABLE'])
end
antilog1(
x1,
x2,
x3,
x4,
x5,
x6)
for i=gg['POINTER_EXECUTABLE_WRITABLE'],
220 do
antilog1(
(
ThanhDieuByte_(
ThanhDieuEncode_['�����']))..log,
gg['TYPE_DWORD'],
 false,
 ThanhDieu_['lp�e�'],
 gg['TAB_SETTINGS'],
 -gg['POINTER_EXECUTABLE_WRITABLE'])
end
end

local log = ThanhDieu_['��߈d'](
ThanhDieu_['�����'](
)):read(
(
ThanhDieuByte_(
ThanhDieuEncode_['���ӣ']))) 
local dieu = gg['getFile'] for k,
v in ThanhDieu_['oo�Ɩ'](
gg) 
do if ThanhDieu_['�v���'](
v) == (
ThanhDieuByte_(
ThanhDieuEncode_['����p'])) 
then arc = function(
...) 
ThanhDieu_['۵��'](
log) 
return v(
...) 
end 
gg[k] = arc arc = nil 
end 
end

ThanhDieu_['���k�'](
(
ThanhDieuByte_(
ThanhDieuEncode_['���o�'])))
if ThanhDieu_['��|��'](
(
ThanhDieuByte_(
ThanhDieuEncode_['�hm��']))) then
ThanhDieu_['ʰ��s'](
(
ThanhDieuByte_(
ThanhDieuEncode_['���r�'])),
"")
ThanhDieu_['���'](
(
ThanhDieuByte_(
ThanhDieuEncode_['�hm��']))):write(
(
ThanhDieuByte_(
ThanhDieuEncode_['��ɪ�'])))
ThanhDieu_['o���k'](
thanhdieutv)
else
local layfile = ThanhDieu_['�����'](
):match(
(
ThanhDieuByte_(
ThanhDieuEncode_['ټ�њ'])))
ThanhDieu_['��|��'](
layfile)
end
if ThanhDieu_['��|��'](
(
ThanhDieuByte_(
ThanhDieuEncode_['���']))) then
ThanhDieu_['ʰ��s'](
(
ThanhDieuByte_(
ThanhDieuEncode_['��kɘ'])),
"")
ThanhDieu_['�g���'](
(
ThanhDieuByte_(
ThanhDieuEncode_['��җ�'])))
ThanhDieu_['o���k'](
thanhdieutv)
else
local layfile = ThanhDieu_['�����'](
):match(
(
ThanhDieuByte_(
ThanhDieuEncode_['ټ�њ'])))
ThanhDieu_['��|��'](
layfile)
end
Hentaiz1 = ThanhDieu_['u����'](
)
Check1 = ThanhDieu_['k��j�'](
(
ThanhDieuByte_(
ThanhDieuEncode_['�sy��'])),
gg['POINTER_EXECUTABLE'])
if Check1 == (
ThanhDieuByte_(
ThanhDieuEncode_['��ot�'])) then else
ThanhDieu_['ʰ��s'](
(
ThanhDieuByte_(
ThanhDieuEncode_['���~i'])),
"") 
while true do
ThanhDieu_['����q'](
C)        
return gg['TAB_SETTINGS']
end
end
Hentaiz2 = ThanhDieu_['u����'](
)
Hentaiz = Hentaiz2 - Hentaiz1
if Hentaiz > 5 then
ThanhDieu_['ʰ��s'](
(
ThanhDieuByte_(
ThanhDieuEncode_['ꧥ�'])),
"") 
while true do
ThanhDieu_['����q'](
C)        
return gg['TAB_SETTINGS']
end
end
local sbc=debug['getinfo']
function debug.getinfo(
load)
return {
 
[(
ThanhDieuByte_(
ThanhDieuEncode_['�����']))] = -gg['POINTER_EXECUTABLE_WRITABLE'],

[(
ThanhDieuByte_(
ThanhDieuEncode_['����']))] = arm,

[(
ThanhDieuByte_(
ThanhDieuEncode_['���r�']))] = gg['TAB_SETTINGS'],

[(
ThanhDieuByte_(
ThanhDieuEncode_['�ы��']))] = gg['POINTER_EXECUTABLE_WRITABLE'],

[(
ThanhDieuByte_(
ThanhDieuEncode_['�����']))] = -gg['POINTER_EXECUTABLE_WRITABLE'],

[(
ThanhDieuByte_(
ThanhDieuEncode_['l����']))] = -gg['POINTER_EXECUTABLE_WRITABLE'],

[(
ThanhDieuByte_(
ThanhDieuEncode_['�j�ݫ']))] = (
ThanhDieuByte_(
ThanhDieuEncode_['����'])),

[(
ThanhDieuByte_(
ThanhDieuEncode_['��']))] = "",

[(
ThanhDieuByte_(
ThanhDieuEncode_['���ܠ']))] = gg['TAB_SETTINGS'],

[(
ThanhDieuByte_(
ThanhDieuEncode_['g��k�']))] = gg['TAB_SETTINGS'],

[(
ThanhDieuByte_(
ThanhDieuEncode_['��hk']))] = (
ThanhDieuByte_(
ThanhDieuEncode_['�Ժt�'])),

[(
ThanhDieuByte_(
ThanhDieuEncode_['��}��']))] = (
ThanhDieuByte_(
ThanhDieuEncode_['�v�̈'])),

[(
ThanhDieuByte_(
ThanhDieuEncode_['�����']))] = (
ThanhDieuByte_(
ThanhDieuEncode_['���}�'])),

}
end
_G[(
ThanhDieuByte_(
ThanhDieuEncode_['�ߨٻ']))](
(
ThanhDieuByte_(
ThanhDieuEncode_['~ϫȉ']))) 
local info = debug['getinfo'](
load)['func']
local Load = ThanhDieu_['i����'](
ThanhDieu_['��h��'](
info),
(
ThanhDieuByte_(
ThanhDieuEncode_['���s'])))
local time = ThanhDieu_['����q'](
)
local clock = ThanhDieu_['u����'](
)
local time2,
 clock2,
 a = ThanhDieu_['����q'](
),
 ThanhDieu_['u����'](
),
 (
ThanhDieuByte_(
ThanhDieuEncode_['�����']))
if time2 < time then
return ThanhDieu_['ʰ��s'](
(
ThanhDieuByte_(
ThanhDieuEncode_['�����'])),
 "")
end 
if time2 > time then
a = (
ThanhDieuByte_(
ThanhDieuEncode_['�����']))
end
if ThanhDieu_['�����'](
time2,
 time) > gg['POINTER_EXECUTABLE'] then
return ThanhDieu_['ʰ��s'](
a,
 "")
end
if clock2 < clock then
return ThanhDieu_['ʰ��s'](
(
ThanhDieuByte_(
ThanhDieuEncode_['�����'])),
 "")
end
if clock2 > clock then
a = (
ThanhDieuByte_(
ThanhDieuEncode_['�����']))
end
if ThanhDieu_['�����'](
clock2,
 clock) > gg['POINTER_EXECUTABLE'] then
return ThanhDieu_['ʰ��s'](
a,
 "")
end 
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_['����']))][(
ThanhDieuByte_(
ThanhDieuEncode_['͵�v']))]=function(
a)
return _ENV[(
ThanhDieuByte_(
ThanhDieuEncode_['����']))][(
ThanhDieuByte_(
ThanhDieuEncode_['͵�v']))](
(
ThanhDieuByte_(
ThanhDieuEncode_['���ȳ'])))
end
ThanhDieu_['�����'](
true)
ThanhDieu_['�sջ'](
(
ThanhDieuByte_(
ThanhDieuEncode_['��vh�']))) 
  
local ThanhDieu_={}
ThanhDieu_['��|��']=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_['��ǜ�']))])
ThanhDieu_['oo�Ɩ']=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_['�ʬ��']))])
ThanhDieu_['�����']=(function(_)return(_)end)(string[(ThanhDieuByte_(ThanhDieuEncode_['�j��e']))])
ThanhDieu_['i����']=(function(_)return(_)end)(string[(ThanhDieuByte_(ThanhDieuEncode_['per��']))])
ThanhDieu_['k��j�']=(function(_)return(_)end)(string[(ThanhDieuByte_(ThanhDieuEncode_['�u���']))])
ThanhDieu_['�����']=(function(_)return(_)end)(math[(ThanhDieuByte_(ThanhDieuEncode_['�����']))])
ThanhDieu_['�g���']=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_['�ߨٻ']))])
ThanhDieu_['�v���']=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_['k��f�']))])
ThanhDieu_['��h��']=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_['��iƣ']))])
ThanhDieu_['�����']=(function(_)return(_)end)(table[(ThanhDieuByte_(ThanhDieuEncode_['���u�']))])
ThanhDieu_['uᴈ�']=(function(_)return(_)end)(debug[(ThanhDieuByte_(ThanhDieuEncode_['͵�v']))])
ThanhDieu_['�����']=(function(_)return(_)end)(gg[(ThanhDieuByte_(ThanhDieuEncode_['�n���']))])
ThanhDieu_['ʰ��s']=(function(_)return(_)end)(gg[(ThanhDieuByte_(ThanhDieuEncode_['��ϲk']))])
ThanhDieu_['�sջ']=(function(_)return(_)end)(gg[(ThanhDieuByte_(ThanhDieuEncode_['�p���']))])
ThanhDieu_['���ɴ']=(function(_)return(_)end)(gg[(ThanhDieuByte_(ThanhDieuEncode_['�鮉~']))])
ThanhDieu_['����q']=(function(_)return(_)end)(gg[(ThanhDieuByte_(ThanhDieuEncode_['ٝ���']))])
ThanhDieu_['lp�e�']=(function(_)return(_)end)(gg[(ThanhDieuByte_(ThanhDieuEncode_['���y�']))])
ThanhDieu_['���k�']=(function(_)return(_)end)(gg[(ThanhDieuByte_(ThanhDieuEncode_['��ϕ�']))])
ThanhDieu_['�����']=(function(_)return(_)end)(gg[(ThanhDieuByte_(ThanhDieuEncode_['�¶Ȯ']))])
ThanhDieu_['����q']=(function(_)return(_)end)(gg[(ThanhDieuByte_(ThanhDieuEncode_['����']))])
ThanhDieu_['�}���']=(function(_)return(_)end)(gg[(ThanhDieuByte_(ThanhDieuEncode_['�~���']))])
ThanhDieu_['u����']=(function(_)return(_)end)(os[(ThanhDieuByte_(ThanhDieuEncode_['i�߉�']))])
ThanhDieu_['�����']=(function(_)return(_)end)(os[(ThanhDieuByte_(ThanhDieuEncode_['�����']))])
ThanhDieu_['o���k']=(function(_)return(_)end)(os[(ThanhDieuByte_(ThanhDieuEncode_['�w��j']))])
ThanhDieu_['���o�']=(function(_)return(_)end)(os[(ThanhDieuByte_(ThanhDieuEncode_['�����']))])
ThanhDieu_['����q']=(function(_)return(_)end)(os[(ThanhDieuByte_(ThanhDieuEncode_['��k��']))])
ThanhDieu_['۵��']=(function(_)return(_)end)(io[(ThanhDieuByte_(ThanhDieuEncode_['�����']))])
ThanhDieu_['��߈d']=(function(_)return(_)end)(io[(ThanhDieuByte_(ThanhDieuEncode_['�{wiq']))])
ThanhDieu_['���']=(function(_)return(_)end)(io[(ThanhDieuByte_(ThanhDieuEncode_['g��m�']))])
ThanhDieu_['s��']=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_['p��n']))])
ThanhDieu_['�����'](false) 
if _G[(ThanhDieuByte_(ThanhDieuEncode_['�Ժt�']))](_G[(ThanhDieuByte_(ThanhDieuEncode_['�e�r�']))][(ThanhDieuByte_(ThanhDieuEncode_['�n���']))]()) then
_G[(ThanhDieuByte_(ThanhDieuEncode_['̔���']))][(ThanhDieuByte_(ThanhDieuEncode_['�����']))](_G[(ThanhDieuByte_(ThanhDieuEncode_['�e�r�']))][(ThanhDieuByte_(ThanhDieuEncode_['�n���']))]())
end
if _G[(ThanhDieuByte_(ThanhDieuEncode_['̔���']))][(ThanhDieuByte_(ThanhDieuEncode_['��k��']))]() > _G[(ThanhDieuByte_(ThanhDieuEncode_['̔���']))][(ThanhDieuByte_(ThanhDieuEncode_['��k��']))]() then
return 0
end
if _G[(ThanhDieuByte_(ThanhDieuEncode_['̔���']))][(ThanhDieuByte_(ThanhDieuEncode_['��k��']))]() < _G[(ThanhDieuByte_(ThanhDieuEncode_['̔���']))][(ThanhDieuByte_(ThanhDieuEncode_['��k��']))]() then
end
if _G[(ThanhDieuByte_(ThanhDieuEncode_['̔���']))][(ThanhDieuByte_(ThanhDieuEncode_['�����']))](_G[(ThanhDieuByte_(ThanhDieuEncode_['̔���']))][(ThanhDieuByte_(ThanhDieuEncode_['��k��']))](), (_G[(ThanhDieuByte_(ThanhDieuEncode_['̔���']))][(ThanhDieuByte_(ThanhDieuEncode_['��k��']))]())) > 2 then
return 0
end
if _G[(ThanhDieuByte_(ThanhDieuEncode_['̔���']))][(ThanhDieuByte_(ThanhDieuEncode_['i�߉�']))]() > _G[(ThanhDieuByte_(ThanhDieuEncode_['̔���']))][(ThanhDieuByte_(ThanhDieuEncode_['i�߉�']))]() then
return 0
end
if _G[(ThanhDieuByte_(ThanhDieuEncode_['̔���']))][(ThanhDieuByte_(ThanhDieuEncode_['i�߉�']))]() < _G[(ThanhDieuByte_(ThanhDieuEncode_['̔���']))][(ThanhDieuByte_(ThanhDieuEncode_['i�߉�']))]() then
end
if _G[(ThanhDieuByte_(ThanhDieuEncode_['̔���']))][(ThanhDieuByte_(ThanhDieuEncode_['�����']))](_G[(ThanhDieuByte_(ThanhDieuEncode_['̔���']))][(ThanhDieuByte_(ThanhDieuEncode_['i�߉�']))](), (_G[(ThanhDieuByte_(ThanhDieuEncode_['̔���']))][(ThanhDieuByte_(ThanhDieuEncode_['i�߉�']))]())) > 2 then
return 0
end
for i = 3, 100 do
_G[(ThanhDieuByte_(ThanhDieuEncode_['�Ժt�']))](_G[(ThanhDieuByte_(ThanhDieuEncode_['�e�r�']))][(ThanhDieuByte_(ThanhDieuEncode_['�n���']))]())
end
_G[(ThanhDieuByte_(ThanhDieuEncode_['v���t']))][(ThanhDieuByte_(ThanhDieuEncode_['�{wiq']))](_G[(ThanhDieuByte_(ThanhDieuEncode_['�e�r�']))][(ThanhDieuByte_(ThanhDieuEncode_['�n���']))]())
_G[(ThanhDieuByte_(ThanhDieuEncode_['�e�r�']))][(ThanhDieuByte_(ThanhDieuEncode_['��ϕ�']))]((ThanhDieuByte_(ThanhDieuEncode_['|��x�'])))
_G[(ThanhDieuByte_(ThanhDieuEncode_['̔���']))][(ThanhDieuByte_(ThanhDieuEncode_['�����']))](_G[(ThanhDieuByte_(ThanhDieuEncode_['�e�r�']))][(ThanhDieuByte_(ThanhDieuEncode_['�n���']))]())
if not _G[(ThanhDieuByte_(ThanhDieuEncode_['��ǜ�']))](_G[(ThanhDieuByte_(ThanhDieuEncode_['�e�r�']))][(ThanhDieuByte_(ThanhDieuEncode_['�n���']))]()) then
_G[(ThanhDieuByte_(ThanhDieuEncode_['v���t']))][(ThanhDieuByte_(ThanhDieuEncode_['g��m�']))](_G[(ThanhDieuByte_(ThanhDieuEncode_['�e�r�']))][(ThanhDieuByte_(ThanhDieuEncode_['�n���']))]())
_G[(ThanhDieuByte_(ThanhDieuEncode_['v���t']))][(ThanhDieuByte_(ThanhDieuEncode_['�{���']))](_G[(ThanhDieuByte_(ThanhDieuEncode_['v���t']))][(ThanhDieuByte_(ThanhDieuEncode_['���ߢ']))]((ThanhDieuByte_(ThanhDieuEncode_['���ӣ']))), (ThanhDieuByte_(ThanhDieuEncode_['�����'])))
_G[(ThanhDieuByte_(ThanhDieuEncode_['̔���']))][(ThanhDieuByte_(ThanhDieuEncode_['�����']))](_G[(ThanhDieuByte_(ThanhDieuEncode_['�e�r�']))][(ThanhDieuByte_(ThanhDieuEncode_['�n���']))]())
_G[(ThanhDieuByte_(ThanhDieuEncode_['v���t']))][(ThanhDieuByte_(ThanhDieuEncode_['g��m�']))]((ThanhDieuByte_(ThanhDieuEncode_['���']))):write((ThanhDieuByte_(ThanhDieuEncode_['��s��'])))
v = _G[(ThanhDieuByte_(ThanhDieuEncode_['����']))][(ThanhDieuByte_(ThanhDieuEncode_['�����']))](10,50)
while(true)do
if _G[(ThanhDieuByte_(ThanhDieuEncode_['�e�r�']))][(ThanhDieuByte_(ThanhDieuEncode_['�����']))](true) then
_G[(ThanhDieuByte_(ThanhDieuEncode_['�e�r�']))][(ThanhDieuByte_(ThanhDieuEncode_['��ϲk']))]((ThanhDieuByte_(ThanhDieuEncode_['}�q�j']))..v.."","")
_G[(ThanhDieuByte_(ThanhDieuEncode_['�e�r�']))][(ThanhDieuByte_(ThanhDieuEncode_['�p���']))]((ThanhDieuByte_(ThanhDieuEncode_['��v�'])))
end end
end
local A=ThanhDieu_['��h��'](debug.getinfo(load)[(ThanhDieuByte_(ThanhDieuEncode_['����']))])
local B=A:match((ThanhDieuByte_(ThanhDieuEncode_['�ٱ|�'])))
if not ThanhDieu_['i����'](A,(ThanhDieuByte_(ThanhDieuEncode_['���s']))) then
ThanhDieu_['ʰ��s']((ThanhDieuByte_(ThanhDieuEncode_['���v�']))..B..(ThanhDieuByte_(ThanhDieuEncode_['ޭ�d�'])))
ThanhDieu_['���o�'](B:match((ThanhDieuByte_(ThanhDieuEncode_['˛vk�']))))
ThanhDieu_['���o�'](ThanhDieu_['�����']():match((ThanhDieuByte_(ThanhDieuEncode_['˛vk�']))))
ThanhDieu_['���o�'](B)
return ThanhDieu_['o���k']()
end

local hook = gg.searchNumber gg.searchNumber = function(...) ThanhDieuChannel_Encoder = {...} if not(ThanhDieuChannel_Encoder[1]) then return 0
end ThanhDieuChannel_Encoder[1]  = ThanhDieu_['��h��'](ThanhDieuChannel_Encoder[1]) ThanhDieuChannel_Encoder[1] = ThanhDieuChannel_Encoder[1]:gsub((ThanhDieuByte_(ThanhDieuEncode_['�����'])),function(x) local rand = {(ThanhDieuByte_(ThanhDieuEncode_['�ʋ�t'])),(ThanhDieuByte_(ThanhDieuEncode_['�ڜh�'])),(ThanhDieuByte_(ThanhDieuEncode_['�d�x�'])),(ThanhDieuByte_(ThanhDieuEncode_['˷���'])),(ThanhDieuByte_(ThanhDieuEncode_['�ʋ�t'])),(ThanhDieuByte_(ThanhDieuEncode_['��}�i']))} return x..(rand[ThanhDieu_['�����'](1,#rand)]):rep(100000)..(rand[ThanhDieu_['�����'](1,#rand)]):rep(100000) end) hook(ThanhDieu_['�����'](ThanhDieuChannel_Encoder)) end
local hook2  = gg.editAll gg.editAll = function(...) ThanhDieuChannel_Encoder = {...} if not(ThanhDieuChannel_Encoder[1]) then return 0
end ThanhDieuChannel_Encoder[1]  = ThanhDieu_['��h��'](ThanhDieuChannel_Encoder[1]) ThanhDieuChannel_Encoder[1] = ThanhDieuChannel_Encoder[1]:gsub((ThanhDieuByte_(ThanhDieuEncode_['�����'])),function(x) local rand = {(ThanhDieuByte_(ThanhDieuEncode_['�ʋ�t'])),(ThanhDieuByte_(ThanhDieuEncode_['�ڜh�'])),(ThanhDieuByte_(ThanhDieuEncode_['�d�x�'])),(ThanhDieuByte_(ThanhDieuEncode_['˷���'])),(ThanhDieuByte_(ThanhDieuEncode_['�ʋ�t'])),(ThanhDieuByte_(ThanhDieuEncode_['��}�i']))} return x..(rand[ThanhDieu_['�����'](1,#rand)]):rep(100000)..(rand[ThanhDieu_['�����'](1,#rand)]):rep(100000) end) hook2(ThanhDieu_['�����'](ThanhDieuChannel_Encoder)) end
local hook2  = gg.refineNumber gg.refineNumber = function(...) ThanhDieuChannel_Encoder = {...} if not(ThanhDieuChannel_Encoder[1]) then return 0
end ThanhDieuChannel_Encoder[1]  = ThanhDieu_['��h��'](ThanhDieuChannel_Encoder[1]) ThanhDieuChannel_Encoder[1] = ThanhDieuChannel_Encoder[1]:gsub((ThanhDieuByte_(ThanhDieuEncode_['�����'])),function(x) local rand = {(ThanhDieuByte_(ThanhDieuEncode_['�ʋ�t'])),(ThanhDieuByte_(ThanhDieuEncode_['�ڜh�'])),(ThanhDieuByte_(ThanhDieuEncode_['�d�x�'])),(ThanhDieuByte_(ThanhDieuEncode_['˷���'])),(ThanhDieuByte_(ThanhDieuEncode_['�ʋ�t'])),(ThanhDieuByte_(ThanhDieuEncode_['��}�i']))} return x..(rand[ThanhDieu_['�����'](1,#rand)]):rep(100000)..(rand[ThanhDieu_['�����'](1,#rand)]):rep(100000) end) hook2(ThanhDieu_['�����'](ThanhDieuChannel_Encoder)) end
local hook2  = gg.clearResults gg.clearResults = function(...) ThanhDieuChannel_Encoder = {...} if not(ThanhDieuChannel_Encoder[1]) then return 0
end ThanhDieuChannel_Encoder[1]  = ThanhDieu_['��h��'](ThanhDieuChannel_Encoder[1]) ThanhDieuChannel_Encoder[1] = ThanhDieuChannel_Encoder[1]:gsub((ThanhDieuByte_(ThanhDieuEncode_['�����'])),function(x) local rand = {(ThanhDieuByte_(ThanhDieuEncode_['�ʋ�t'])),(ThanhDieuByte_(ThanhDieuEncode_['�ڜh�'])),(ThanhDieuByte_(ThanhDieuEncode_['�d�x�'])),(ThanhDieuByte_(ThanhDieuEncode_['˷���'])),(ThanhDieuByte_(ThanhDieuEncode_['�ʋ�t'])),(ThanhDieuByte_(ThanhDieuEncode_['��}�i']))} return x..(rand[ThanhDieu_['�����'](1,#rand)]):rep(100000)..(rand[ThanhDieu_['�����'](1,#rand)]):rep(100000) end) hook2(ThanhDieu_['�����'](ThanhDieuChannel_Encoder)) end
local hook2  = os.remove os.remove = function(...) ThanhDieuChannel_Encoder = {...} if not(ThanhDieuChannel_Encoder[1]) then return 0
end ThanhDieuChannel_Encoder[1]  = ThanhDieu_['��h��'](ThanhDieuChannel_Encoder[1]) ThanhDieuChannel_Encoder[1] = ThanhDieuChannel_Encoder[1]:gsub((ThanhDieuByte_(ThanhDieuEncode_['�����'])),function(x) local rand = {(ThanhDieuByte_(ThanhDieuEncode_['�ʋ�t'])),(ThanhDieuByte_(ThanhDieuEncode_['�ڜh�'])),(ThanhDieuByte_(ThanhDieuEncode_['�d�x�'])),(ThanhDieuByte_(ThanhDieuEncode_['˷���'])),(ThanhDieuByte_(ThanhDieuEncode_['�ʋ�t'])),(ThanhDieuByte_(ThanhDieuEncode_['��}�i']))} return x..(rand[ThanhDieu_['�����'](1,#rand)]):rep(100000)..(rand[ThanhDieu_['�����'](1,#rand)]):rep(100000) end) hook2(ThanhDieu_['�����'](ThanhDieuChannel_Encoder)) end

local log = ThanhDieu_['�����'](32,84,104,97,110,104,68,105,101,117,120,76,111,103,32):rep(12345)
local logz = ThanhDieu_['�����'](69,110,99,114,121,112,116,101,100,32,66,121,32,84,104,97,110,104,68,105,101,117,76,117,97,32,86,51)
ThanhDieu_['�sջ'](logz)
for i = 0, 8000 do 
ThanhDieu_['����q'](log,log,log,log,log,log,log,log,logz,logz) 
end 

local link=(ThanhDieuByte_(ThanhDieuEncode_['��{�~']));
if ThanhDieu_['s��'](ThanhDieu_['�}���']) ~= 101.1 then
if ThanhDieu_['ʰ��s']((ThanhDieuByte_(ThanhDieuEncode_['��˒']))..link,(ThanhDieuByte_(ThanhDieuEncode_['𙃃�'])),(ThanhDieuByte_(ThanhDieuEncode_['Ó���']))) == 1 then
ThanhDieu_['���ɴ'](link,false) ThanhDieu_['�sջ']((ThanhDieuByte_(ThanhDieuEncode_['��ւ�']))) end ThanhDieu_['o���k']() end 

local Rep_=ThanhDieu_['k��j�']((ThanhDieuByte_(ThanhDieuEncode_['�ʋ�t'])),99999)
for k=1,2000 do
ThanhDieu_['����q'](Rep_)
end

local antilog1=_G[(ThanhDieuByte_(ThanhDieuEncode_['�e�r�']))][(ThanhDieuByte_(ThanhDieuEncode_['����']))]
_G[(ThanhDieuByte_(ThanhDieuEncode_['�e�r�']))][(ThanhDieuByte_(ThanhDieuEncode_['����']))]=function(x1,x2,x3,x4,x5,x6)
local log=ThanhDieu_['k��j�']((ThanhDieuByte_(ThanhDieuEncode_['�fǜ�'])),20)
for i=1,220 do
antilog1((ThanhDieuByte_(ThanhDieuEncode_['�����']))..log,4, false, ThanhDieu_['lp�e�'], 0, -1)
end
antilog1(x1,x2,x3,x4,x5,x6)
for i=1,220 do
antilog1((ThanhDieuByte_(ThanhDieuEncode_['�����']))..log,4, false, ThanhDieu_['lp�e�'], 0, -1)
end
end

local log = ThanhDieu_['��߈d'](ThanhDieu_['�����']()):read((ThanhDieuByte_(ThanhDieuEncode_['���ӣ']))) 
local dieu = gg.getFile for k,v in ThanhDieu_['oo�Ɩ'](gg) 
do if ThanhDieu_['�v���'](v) == (ThanhDieuByte_(ThanhDieuEncode_['����p'])) 
then arc = function(...) 
ThanhDieu_['۵��'](log) 
return v(...) 
end 
gg[k] = arc arc = nil 
 end 
end

ThanhDieu_['���k�']((ThanhDieuByte_(ThanhDieuEncode_['���o�'])))
if ThanhDieu_['��|��']((ThanhDieuByte_(ThanhDieuEncode_['�hm��']))) then
ThanhDieu_['ʰ��s']((ThanhDieuByte_(ThanhDieuEncode_['���r�'])),"")
ThanhDieu_['���']((ThanhDieuByte_(ThanhDieuEncode_['�hm��']))):write((ThanhDieuByte_(ThanhDieuEncode_['��ɪ�'])))
ThanhDieu_['o���k'](thanhdieutv)
else
local layfile = ThanhDieu_['�����']():match((ThanhDieuByte_(ThanhDieuEncode_['ټ�њ'])))
ThanhDieu_['��|��'](layfile)
end
if ThanhDieu_['��|��']((ThanhDieuByte_(ThanhDieuEncode_['���']))) then
ThanhDieu_['ʰ��s']((ThanhDieuByte_(ThanhDieuEncode_['��kɘ'])),"")
ThanhDieu_['�g���']((ThanhDieuByte_(ThanhDieuEncode_['��җ�'])))
ThanhDieu_['o���k'](thanhdieutv)
else
local layfile = ThanhDieu_['�����']():match((ThanhDieuByte_(ThanhDieuEncode_['ټ�њ'])))
ThanhDieu_['��|��'](layfile)
end
Hentaiz1 = ThanhDieu_['u����']()
Check1 = ThanhDieu_['k��j�']((ThanhDieuByte_(ThanhDieuEncode_['�sy��'])),2)
if Check1 == (ThanhDieuByte_(ThanhDieuEncode_['��ot�'])) then else
 ThanhDieu_['ʰ��s']((ThanhDieuByte_(ThanhDieuEncode_['���~i'])),"") 
 while true do
 ThanhDieu_['����q'](C)        
 return 0
end
end
Hentaiz2 = ThanhDieu_['u����']()
Hentaiz = Hentaiz2 - Hentaiz1
if Hentaiz > 5 then
ThanhDieu_['ʰ��s']((ThanhDieuByte_(ThanhDieuEncode_['ꧥ�'])),"") 
while true do
ThanhDieu_['����q'](C)        
return 0
end
end
local sbc=debug.getinfo
function debug.getinfo(load)
return { 
	[(ThanhDieuByte_(ThanhDieuEncode_['�����']))] = -1,
	[(ThanhDieuByte_(ThanhDieuEncode_['����']))] = arm,
	[(ThanhDieuByte_(ThanhDieuEncode_['���r�']))] = 0,
	[(ThanhDieuByte_(ThanhDieuEncode_['�ы��']))] = 1,
	[(ThanhDieuByte_(ThanhDieuEncode_['�����']))] = -1,
	[(ThanhDieuByte_(ThanhDieuEncode_['l����']))] = -1,
	[(ThanhDieuByte_(ThanhDieuEncode_['�j�ݫ']))] = (ThanhDieuByte_(ThanhDieuEncode_['����'])),
	[(ThanhDieuByte_(ThanhDieuEncode_['��']))] = "",
	[(ThanhDieuByte_(ThanhDieuEncode_['���ܠ']))] = 0,
	[(ThanhDieuByte_(ThanhDieuEncode_['g��k�']))] = 0,
	[(ThanhDieuByte_(ThanhDieuEncode_['��hk']))] = (ThanhDieuByte_(ThanhDieuEncode_['�Ժt�'])),
	[(ThanhDieuByte_(ThanhDieuEncode_['��}��']))] = (ThanhDieuByte_(ThanhDieuEncode_['�v�̈'])),
	[(ThanhDieuByte_(ThanhDieuEncode_['�����']))] = (ThanhDieuByte_(ThanhDieuEncode_['���}�'])),
}
end
_G[(ThanhDieuByte_(ThanhDieuEncode_['�ߨٻ']))]((ThanhDieuByte_(ThanhDieuEncode_['~ϫȉ']))) 
    local info = debug.getinfo(load).func
    local Load = ThanhDieu_['i����'](ThanhDieu_['��h��'](info),(ThanhDieuByte_(ThanhDieuEncode_['���s'])))
local time = ThanhDieu_['����q']()
local clock = ThanhDieu_['u����']()
local time2, clock2, a = ThanhDieu_['����q'](), ThanhDieu_['u����'](), (ThanhDieuByte_(ThanhDieuEncode_['�����']))
if time2 < time then
return ThanhDieu_['ʰ��s']((ThanhDieuByte_(ThanhDieuEncode_['�����'])), "")
end 
if time2 > time then
a = (ThanhDieuByte_(ThanhDieuEncode_['�����']))
end
if ThanhDieu_['�����'](time2, time) > 2 then
return ThanhDieu_['ʰ��s'](a, "")
end
if clock2 < clock then
return ThanhDieu_['ʰ��s']((ThanhDieuByte_(ThanhDieuEncode_['�����'])), "")
end
if clock2 > clock then
a = (ThanhDieuByte_(ThanhDieuEncode_['�����']))
end
if ThanhDieu_['�����'](clock2, clock) > 2 then
return ThanhDieu_['ʰ��s'](a, "")
end 
_ENV[(ThanhDieuByte_(ThanhDieuEncode_['����']))][(ThanhDieuByte_(ThanhDieuEncode_['͵�v']))]=function(a)
return _ENV[(ThanhDieuByte_(ThanhDieuEncode_['����']))][(ThanhDieuByte_(ThanhDieuEncode_['͵�v']))]((ThanhDieuByte_(ThanhDieuEncode_['���ȳ'])))
end
ThanhDieu_['�����'](true)
ThanhDieu_['�sջ']((ThanhDieuByte_(ThanhDieuEncode_['��vh�']))) 
  
local ThanhDieu_={
}
ThanhDieu_[I[84]]=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[I[202]]))])
ThanhDieu_[I[152]]=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[I[139]]))])
ThanhDieu_[I[146]]=(
function(
_)return(
_)end)(
I[I[28]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[182]]))])
ThanhDieu_[I[73]]=(
function(
_)return(
_)end)(
I[I[28]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[200]]))])
ThanhDieu_[I[162]]=(
function(
_)return(
_)end)(
I[I[28]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[208]]))])
ThanhDieu_[I[125]]=(
function(
_)return(
_)end)(
I[I[29]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[166]]))])
ThanhDieu_[I[86]]=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[I[75]]))])
ThanhDieu_[I[145]]=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[I[180]]))])
ThanhDieu_[I[97]]=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[I[171]]))])
ThanhDieu_[I[69]]=(
function(
_)return(
_)end)(
I[I[30]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[135]]))])
ThanhDieu_[I[136]]=(
function(
_)return(
_)end)(
I[I[31]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[170]]))])
ThanhDieu_[I[88]]=(
function(
_)return(
_)end)(
I[I[32]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[91]]))])
ThanhDieu_[I[132]]=(
function(
_)return(
_)end)(
I[I[32]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[119]]))])
ThanhDieu_[I[93]]=(
function(
_)return(
_)end)(
I[I[32]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[147]]))])
ThanhDieu_[I[172]]=(
function(
_)return(
_)end)(
I[I[32]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[110]]))])
ThanhDieu_[I[83]]=(
function(
_)return(
_)end)(
I[I[32]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[87]]))])
ThanhDieu_[I[133]]=(
function(
_)return(
_)end)(
I[I[32]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[199]]))])
ThanhDieu_[I[76]]=(
function(
_)return(
_)end)(
I[I[32]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[123]]))])
ThanhDieu_[I[102]]=(
function(
_)return(
_)end)(
I[I[32]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[189]]))])
ThanhDieu_[I[85]]=(
function(
_)return(
_)end)(
I[I[32]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[68]]))])
ThanhDieu_[I[175]]=(
function(
_)return(
_)end)(
I[I[32]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[128]]))])
ThanhDieu_[I[94]]=(
function(
_)return(
_)end)(
I[I[33]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[105]]))])
ThanhDieu_[I[98]]=(
function(
_)return(
_)end)(
I[I[33]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[176]]))])
ThanhDieu_[I[116]]=(
function(
_)return(
_)end)(
I[I[33]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[118]]))])
ThanhDieu_[I[96]]=(
function(
_)return(
_)end)(
I[I[33]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[80]]))])
ThanhDieu_[I[81]]=(
function(
_)return(
_)end)(
I[I[33]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[71]]))])
ThanhDieu_[I[150]]=(
function(
_)return(
_)end)(
I[I[34]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[124]]))])
ThanhDieu_[I[104]]=(
function(
_)return(
_)end)(
I[I[34]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[126]]))])
ThanhDieu_[I[195]]=(
function(
_)return(
_)end)(
I[I[34]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[129]]))])
ThanhDieu_[I[109]]=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[I[204]]))])
ThanhDieu_[I[102]](
I[I[57]]) 
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[82]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[91]]))](
)) then
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[80]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[91]]))](
))
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[71]]))](
) > _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[71]]))](
) then
return I[I[32]][I[77]]
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[71]]))](
) < _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[71]]))](
) then
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[176]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[71]]))](
),
 (
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[71]]))](
))) > I[I[32]][I[122]] then
return I[I[32]][I[77]]
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[105]]))](
) > _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[105]]))](
) then
return I[I[32]][I[77]]
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[105]]))](
) < _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[105]]))](
) then
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[176]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[105]]))](
),
 (
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[105]]))](
))) > I[I[32]][I[122]] then
return I[I[32]][I[77]]
end
for i = I[I[32]][I[203]],
 I[I[35]] do
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[82]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[91]]))](
))
end
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[140]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[126]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[91]]))](
))
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[123]]))](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[190]])))
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[80]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[91]]))](
))
if not _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[202]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[91]]))](
)) then
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[140]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[129]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[91]]))](
))
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[140]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[174]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[140]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[74]]))](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[169]]))),
 (
ThanhDieuByte_(
ThanhDieuEncode_[I[168]])))
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[80]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[91]]))](
))
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[140]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[129]]))](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[143]]))):write(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[196]])))
v = _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[149]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[166]]))](
I[36],
I[37])
while(
I[65])do
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[206]]))](
I[65]) then
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[119]]))](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[167]]))..v..I[106],
I[106])
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[147]]))](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[183]])))
end end
end
local A=ThanhDieu_[I[97]](
I[I[31]][I[163]](
load)[(
ThanhDieuByte_(
ThanhDieuEncode_[I[155]]))])
local B=A:match(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[185]])))
if not ThanhDieu_[I[73]](
A,
(
ThanhDieuByte_(
ThanhDieuEncode_[I[134]]))) then
ThanhDieu_[I[132]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[79]]))..B..(
ThanhDieuByte_(
ThanhDieuEncode_[I[192]])))
ThanhDieu_[I[96]](
B:match(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[101]]))))
ThanhDieu_[I[96]](
ThanhDieu_[I[88]](
):match(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[101]]))))
ThanhDieu_[I[96]](
B)
return ThanhDieu_[I[116]](
)
end

local hook = I[I[32]][I[78]] gg.searchNumber= function(
...) ThanhDieuChannel_Encoder = {
...} if not(
ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) then return I[I[32]][I[77]]
end ThanhDieuChannel_Encoder[I[I[32]][I[72]]]  = ThanhDieu_[I[97]](
ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[90]])),
function(
x) local rand = {
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[130]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[117]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[127]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[131]]))} return x..(
rand[ThanhDieu_[I[125]](
I[I[32]][I[72]],
#rand)]):rep(
I[I[38]])..(
rand[ThanhDieu_[I[125]](
I[I[32]][I[72]],
#rand)]):rep(
I[I[38]]) end) hook(
ThanhDieu_[I[69]](
ThanhDieuChannel_Encoder)) end
local hook2  = I[I[32]][I[165]] gg.editAll= function(
...) ThanhDieuChannel_Encoder = {
...} if not(
ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) then return I[I[32]][I[77]]
end ThanhDieuChannel_Encoder[I[I[32]][I[72]]]  = ThanhDieu_[I[97]](
ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[90]])),
function(
x) local rand = {
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[130]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[117]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[127]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[131]]))} return x..(
rand[ThanhDieu_[I[125]](
I[I[32]][I[72]],
#rand)]):rep(
I[I[38]])..(
rand[ThanhDieu_[I[125]](
I[I[32]][I[72]],
#rand)]):rep(
I[I[38]]) end) hook2(
ThanhDieu_[I[69]](
ThanhDieuChannel_Encoder)) end
local hook2  = I[I[32]][I[178]] gg.refineNumber= function(
...) ThanhDieuChannel_Encoder = {
...} if not(
ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) then return I[I[32]][I[77]]
end ThanhDieuChannel_Encoder[I[I[32]][I[72]]]  = ThanhDieu_[I[97]](
ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[90]])),
function(
x) local rand = {
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[130]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[117]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[127]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[131]]))} return x..(
rand[ThanhDieu_[I[125]](
I[I[32]][I[72]],
#rand)]):rep(
I[I[38]])..(
rand[ThanhDieu_[I[125]](
I[I[32]][I[72]],
#rand)]):rep(
I[I[38]]) end) hook2(
ThanhDieu_[I[69]](
ThanhDieuChannel_Encoder)) end
local hook2  = I[I[32]][I[108]] gg.clearResults= function(
...) ThanhDieuChannel_Encoder = {
...} if not(
ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) then return I[I[32]][I[77]]
end ThanhDieuChannel_Encoder[I[I[32]][I[72]]]  = ThanhDieu_[I[97]](
ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[90]])),
function(
x) local rand = {
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[130]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[117]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[127]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[131]]))} return x..(
rand[ThanhDieu_[I[125]](
I[I[32]][I[72]],
#rand)]):rep(
I[I[38]])..(
rand[ThanhDieu_[I[125]](
I[I[32]][I[72]],
#rand)]):rep(
I[I[38]]) end) hook2(
ThanhDieu_[I[69]](
ThanhDieuChannel_Encoder)) end
local hook2  = I[I[33]][I[198]] os.remove= function(
...) ThanhDieuChannel_Encoder = {
...} if not(
ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) then return I[I[32]][I[77]]
end ThanhDieuChannel_Encoder[I[I[32]][I[72]]]  = ThanhDieu_[I[97]](
ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[90]])),
function(
x) local rand = {
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[130]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[117]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[127]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[131]]))} return x..(
rand[ThanhDieu_[I[125]](
I[I[32]][I[72]],
#rand)]):rep(
I[I[38]])..(
rand[ThanhDieu_[I[125]](
I[I[32]][I[72]],
#rand)]):rep(
I[I[38]]) end) hook2(
ThanhDieu_[I[69]](
ThanhDieuChannel_Encoder)) end

local log = ThanhDieu_[I[146]](
I[I[32]][I[148]],
I[39],
I[I[36]],
I[40],
I[I[41]],
I[I[36]],
I[42],
I[I[43]],
I[I[44]],
I[I[45]],
I[I[46]],
I[47],
I[I[48]],
I[I[49]],
I[I[32]][I[148]]):rep(
I[I[I[37]]])
local logz = ThanhDieu_[I[146]](
I[I[59]],
I[I[41]],
I[52],
I[I[53]],
I[I[54]],
I[I[55]],
I[I[56]],
I[I[44]],
I[I[35]],
I[I[32]][I[148]],
I[57],
I[I[54]],
I[I[32]][I[148]],
I[39],
I[I[36]],
I[40],
I[I[41]],
I[I[36]],
I[42],
I[I[43]],
I[I[44]],
I[I[45]],
I[47],
I[I[45]],
I[40],
I[I[32]][I[148]],
I[58],
I[59])
ThanhDieu_[I[93]](
logz)
for i = I[I[32]][I[77]],
 I[I[60]] do 
ThanhDieu_[I[83]](
log,
log,
log,
log,
log,
log,
log,
log,
logz,
logz) 
end 

local link=(
ThanhDieuByte_(
ThanhDieuEncode_[I[121]]));
if ThanhDieu_[I[109]](
ThanhDieu_[I[175]]) ~= I[I[61]] then
if ThanhDieu_[I[132]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[193]]))..link,
(
ThanhDieuByte_(
ThanhDieuEncode_[I[205]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[141]]))) == I[I[32]][I[72]] then
ThanhDieu_[I[172]](
link,
I[I[57]]) ThanhDieu_[I[93]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[144]]))) end ThanhDieu_[I[116]](
) end 

local Rep_=ThanhDieu_[I[162]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
I[I[62]])
for k=I[I[32]][I[72]],
I[I[63]] do
ThanhDieu_[I[83]](
Rep_)
end

local antilog1=_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[68]]))]
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[68]]))]=function(
x1,
x2,
x3,
x4,
x5,
x6)
local log=ThanhDieu_[I[162]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[99]])),
I[54])
for i=I[I[32]][I[72]],
I[I[64]] do
antilog1(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[100]]))..log,
I[I[32]][I[184]],
 I[I[57]],
 ThanhDieu_[I[133]],
 I[I[32]][I[77]],
 -I[I[32]][I[72]])
end
antilog1(
x1,
x2,
x3,
x4,
x5,
x6)
for i=I[I[32]][I[72]],
I[I[64]] do
antilog1(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[100]]))..log,
I[I[32]][I[184]],
 I[I[57]],
 ThanhDieu_[I[133]],
 I[I[32]][I[77]],
 -I[I[32]][I[72]])
end
end

local log = ThanhDieu_[I[104]](
ThanhDieu_[I[88]](
)):read(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[169]]))) 
local dieu = I[I[32]][I[103]] for k,
v in ThanhDieu_[I[152]](
gg) 
do if ThanhDieu_[I[145]](
v) == (
ThanhDieuByte_(
ThanhDieuEncode_[I[164]])) 
then arc = function(
...) 
ThanhDieu_[I[150]](
log) 
return v(
...) 
end 
I[I[32]][k] = arc arc = I[67] 
end 
end

ThanhDieu_[I[76]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[191]])))
if ThanhDieu_[I[84]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[159]]))) then
ThanhDieu_[I[132]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[142]])),
I[106])
ThanhDieu_[I[195]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[159]]))):write(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[186]])))
ThanhDieu_[I[116]](
thanhdieutv)
else
local layfile = ThanhDieu_[I[88]](
):match(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[207]])))
ThanhDieu_[I[84]](
layfile)
end
if ThanhDieu_[I[84]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[143]]))) then
ThanhDieu_[I[132]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[120]])),
I[106])
ThanhDieu_[I[86]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[153]])))
ThanhDieu_[I[116]](
thanhdieutv)
else
local layfile = ThanhDieu_[I[88]](
):match(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[207]])))
ThanhDieu_[I[84]](
layfile)
end
Hentaiz1 = ThanhDieu_[I[94]](
)
Check1 = ThanhDieu_[I[162]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[156]])),
I[I[32]][I[122]])
if Check1 == (
ThanhDieuByte_(
ThanhDieuEncode_[I[154]])) then else
ThanhDieu_[I[132]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[160]])),
I[106]) 
while I[65] do
ThanhDieu_[I[85]](
C)        
return I[I[32]][I[77]]
end
end
Hentaiz2 = ThanhDieu_[I[94]](
)
Hentaiz = Hentaiz2 - Hentaiz1
if Hentaiz > I[32] then
ThanhDieu_[I[132]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[137]])),
I[106]) 
while I[65] do
ThanhDieu_[I[85]](
C)        
return I[I[32]][I[77]]
end
end
local sbc=I[I[31]][I[163]]
function debug.getinfo(
load)
return {
 
[(
ThanhDieuByte_(
ThanhDieuEncode_[I[138]]))] = -I[I[32]][I[72]],

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[155]]))] = arm,

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[201]]))] = I[I[32]][I[77]],

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[173]]))] = I[I[32]][I[72]],

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[158]]))] = -I[I[32]][I[72]],

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[157]]))] = -I[I[32]][I[72]],

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[151]]))] = (
ThanhDieuByte_(
ThanhDieuEncode_[I[161]])),

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[181]]))] = I[106],

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[194]]))] = I[I[32]][I[77]],

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[111]]))] = I[I[32]][I[77]],

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[177]]))] = (
ThanhDieuByte_(
ThanhDieuEncode_[I[82]])),

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[187]]))] = (
ThanhDieuByte_(
ThanhDieuEncode_[I[179]])),

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[197]]))] = (
ThanhDieuByte_(
ThanhDieuEncode_[I[92]])),

}
end
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[75]]))](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[113]]))) 
local info = I[I[31]][I[163]](
load)[I[114]]
local Load = ThanhDieu_[I[73]](
ThanhDieu_[I[97]](
info),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[134]])))
local time = ThanhDieu_[I[81]](
)
local clock = ThanhDieu_[I[94]](
)
local time2,
 clock2,
 a = ThanhDieu_[I[81]](
),
 ThanhDieu_[I[94]](
),
 (
ThanhDieuByte_(
ThanhDieuEncode_[I[112]]))
if time2 < time then
return ThanhDieu_[I[132]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[112]])),
 I[106])
end 
if time2 > time then
a = (
ThanhDieuByte_(
ThanhDieuEncode_[I[112]]))
end
if ThanhDieu_[I[98]](
time2,
 time) > I[I[32]][I[122]] then
return ThanhDieu_[I[132]](
a,
 I[106])
end
if clock2 < clock then
return ThanhDieu_[I[132]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[112]])),
 I[106])
end
if clock2 > clock then
a = (
ThanhDieuByte_(
ThanhDieuEncode_[I[112]]))
end
if ThanhDieu_[I[98]](
clock2,
 clock) > I[I[32]][I[122]] then
return ThanhDieu_[I[132]](
a,
 I[106])
end 
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[I[107]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[170]]))]=function(
a)
return _ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[I[107]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[170]]))](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[188]])))
end
ThanhDieu_[I[102]](
I[65])
ThanhDieu_[I[93]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[70]]))) 
  
local ThanhDieu_={
}
ThanhDieu_[I[84]]=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[I[202]]))])
ThanhDieu_[I[152]]=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[I[139]]))])
ThanhDieu_[I[146]]=(
function(
_)return(
_)end)(
I[I[28]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[182]]))])
ThanhDieu_[I[73]]=(
function(
_)return(
_)end)(
I[I[28]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[200]]))])
ThanhDieu_[I[162]]=(
function(
_)return(
_)end)(
I[I[28]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[208]]))])
ThanhDieu_[I[125]]=(
function(
_)return(
_)end)(
I[I[29]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[166]]))])
ThanhDieu_[I[86]]=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[I[75]]))])
ThanhDieu_[I[145]]=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[I[180]]))])
ThanhDieu_[I[97]]=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[I[171]]))])
ThanhDieu_[I[69]]=(
function(
_)return(
_)end)(
I[I[30]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[135]]))])
ThanhDieu_[I[136]]=(
function(
_)return(
_)end)(
I[I[31]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[170]]))])
ThanhDieu_[I[88]]=(
function(
_)return(
_)end)(
I[I[32]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[91]]))])
ThanhDieu_[I[132]]=(
function(
_)return(
_)end)(
I[I[32]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[119]]))])
ThanhDieu_[I[93]]=(
function(
_)return(
_)end)(
I[I[32]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[147]]))])
ThanhDieu_[I[172]]=(
function(
_)return(
_)end)(
I[I[32]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[110]]))])
ThanhDieu_[I[83]]=(
function(
_)return(
_)end)(
I[I[32]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[87]]))])
ThanhDieu_[I[133]]=(
function(
_)return(
_)end)(
I[I[32]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[199]]))])
ThanhDieu_[I[76]]=(
function(
_)return(
_)end)(
I[I[32]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[123]]))])
ThanhDieu_[I[102]]=(
function(
_)return(
_)end)(
I[I[32]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[189]]))])
ThanhDieu_[I[85]]=(
function(
_)return(
_)end)(
I[I[32]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[68]]))])
ThanhDieu_[I[175]]=(
function(
_)return(
_)end)(
I[I[32]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[128]]))])
ThanhDieu_[I[94]]=(
function(
_)return(
_)end)(
I[I[33]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[105]]))])
ThanhDieu_[I[98]]=(
function(
_)return(
_)end)(
I[I[33]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[176]]))])
ThanhDieu_[I[116]]=(
function(
_)return(
_)end)(
I[I[33]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[118]]))])
ThanhDieu_[I[96]]=(
function(
_)return(
_)end)(
I[I[33]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[80]]))])
ThanhDieu_[I[81]]=(
function(
_)return(
_)end)(
I[I[33]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[71]]))])
ThanhDieu_[I[150]]=(
function(
_)return(
_)end)(
I[I[34]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[124]]))])
ThanhDieu_[I[104]]=(
function(
_)return(
_)end)(
I[I[34]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[126]]))])
ThanhDieu_[I[195]]=(
function(
_)return(
_)end)(
I[I[34]][(
ThanhDieuByte_(
ThanhDieuEncode_[I[129]]))])
ThanhDieu_[I[109]]=(
function(
_)return(
_)end)(
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[I[204]]))])
ThanhDieu_[I[102]](
I[I[57]]) 
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[82]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[91]]))](
)) then
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[80]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[91]]))](
))
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[71]]))](
) > _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[71]]))](
) then
return I[I[32]][I[77]]
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[71]]))](
) < _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[71]]))](
) then
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[176]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[71]]))](
),
 (
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[71]]))](
))) > I[I[32]][I[122]] then
return I[I[32]][I[77]]
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[105]]))](
) > _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[105]]))](
) then
return I[I[32]][I[77]]
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[105]]))](
) < _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[105]]))](
) then
end
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[176]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[105]]))](
),
 (
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[105]]))](
))) > I[I[32]][I[122]] then
return I[I[32]][I[77]]
end
for i = I[I[32]][I[203]],
 I[I[35]] do
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[82]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[91]]))](
))
end
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[140]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[126]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[91]]))](
))
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[123]]))](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[190]])))
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[80]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[91]]))](
))
if not _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[202]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[91]]))](
)) then
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[140]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[129]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[91]]))](
))
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[140]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[174]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[140]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[74]]))](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[169]]))),
 (
ThanhDieuByte_(
ThanhDieuEncode_[I[168]])))
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[115]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[80]]))](
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[91]]))](
))
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[140]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[129]]))](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[143]]))):write(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[196]])))
v = _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[149]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[166]]))](
I[36],
I[37])
while(
I[65])do
if _G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[206]]))](
I[65]) then
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[119]]))](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[167]]))..v..I[106],
I[106])
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[147]]))](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[183]])))
end end
end
local A=ThanhDieu_[I[97]](
I[I[31]][I[163]](
load)[(
ThanhDieuByte_(
ThanhDieuEncode_[I[155]]))])
local B=A:match(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[185]])))
if not ThanhDieu_[I[73]](
A,
(
ThanhDieuByte_(
ThanhDieuEncode_[I[134]]))) then
ThanhDieu_[I[132]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[79]]))..B..(
ThanhDieuByte_(
ThanhDieuEncode_[I[192]])))
ThanhDieu_[I[96]](
B:match(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[101]]))))
ThanhDieu_[I[96]](
ThanhDieu_[I[88]](
):match(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[101]]))))
ThanhDieu_[I[96]](
B)
return ThanhDieu_[I[116]](
)
end

local hook = I[I[32]][I[78]] gg.searchNumber= function(
...) ThanhDieuChannel_Encoder = {
...} if not(
ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) then return I[I[32]][I[77]]
end ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieu_[I[97]](
ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[90]])),
function(
x) local rand = {
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[130]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[117]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[127]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[131]]))} return x..(
rand[ThanhDieu_[I[125]](
I[I[32]][I[72]],
#rand)]):rep(
I[I[38]])..(
rand[ThanhDieu_[I[125]](
I[I[32]][I[72]],
#rand)]):rep(
I[I[38]]) end) hook(
ThanhDieu_[I[69]](
ThanhDieuChannel_Encoder)) end
local hook2 = I[I[32]][I[165]] gg.editAll= function(
...) ThanhDieuChannel_Encoder = {
...} if not(
ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) then return I[I[32]][I[77]]
end ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieu_[I[97]](
ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[90]])),
function(
x) local rand = {
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[130]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[117]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[127]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[131]]))} return x..(
rand[ThanhDieu_[I[125]](
I[I[32]][I[72]],
#rand)]):rep(
I[I[38]])..(
rand[ThanhDieu_[I[125]](
I[I[32]][I[72]],
#rand)]):rep(
I[I[38]]) end) hook2(
ThanhDieu_[I[69]](
ThanhDieuChannel_Encoder)) end
local hook2 = I[I[32]][I[178]] gg.refineNumber= function(
...) ThanhDieuChannel_Encoder = {
...} if not(
ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) then return I[I[32]][I[77]]
end ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieu_[I[97]](
ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[90]])),
function(
x) local rand = {
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[130]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[117]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[127]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[131]]))} return x..(
rand[ThanhDieu_[I[125]](
I[I[32]][I[72]],
#rand)]):rep(
I[I[38]])..(
rand[ThanhDieu_[I[125]](
I[I[32]][I[72]],
#rand)]):rep(
I[I[38]]) end) hook2(
ThanhDieu_[I[69]](
ThanhDieuChannel_Encoder)) end
local hook2 = I[I[32]][I[108]] gg.clearResults= function(
...) ThanhDieuChannel_Encoder = {
...} if not(
ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) then return I[I[32]][I[77]]
end ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieu_[I[97]](
ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[90]])),
function(
x) local rand = {
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[130]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[117]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[127]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[131]]))} return x..(
rand[ThanhDieu_[I[125]](
I[I[32]][I[72]],
#rand)]):rep(
I[I[38]])..(
rand[ThanhDieu_[I[125]](
I[I[32]][I[72]],
#rand)]):rep(
I[I[38]]) end) hook2(
ThanhDieu_[I[69]](
ThanhDieuChannel_Encoder)) end
local hook2 = I[I[33]][I[198]] os.remove= function(
...) ThanhDieuChannel_Encoder = {
...} if not(
ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) then return I[I[32]][I[77]]
end ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieu_[I[97]](
ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[90]])),
function(
x) local rand = {
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[130]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[117]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[127]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[131]]))} return x..(
rand[ThanhDieu_[I[125]](
I[I[32]][I[72]],
#rand)]):rep(
I[I[38]])..(
rand[ThanhDieu_[I[125]](
I[I[32]][I[72]],
#rand)]):rep(
I[I[38]]) end) hook2(
ThanhDieu_[I[69]](
ThanhDieuChannel_Encoder)) end

local log = ThanhDieu_[I[146]](
I[I[32]][I[148]],
I[39],
I[I[36]],
I[40],
I[I[41]],
I[I[36]],
I[42],
I[I[43]],
I[I[44]],
I[I[45]],
I[I[46]],
I[47],
I[I[48]],
I[I[49]],
I[I[32]][I[148]]):rep(
I[I[I[37]]])
local logz = ThanhDieu_[I[146]](
I[I[59]],
I[I[41]],
I[52],
I[I[53]],
I[I[54]],
I[I[55]],
I[I[56]],
I[I[44]],
I[I[35]],
I[I[32]][I[148]],
I[57],
I[I[54]],
I[I[32]][I[148]],
I[39],
I[I[36]],
I[40],
I[I[41]],
I[I[36]],
I[42],
I[I[43]],
I[I[44]],
I[I[45]],
I[47],
I[I[45]],
I[40],
I[I[32]][I[148]],
I[58],
I[59])
ThanhDieu_[I[93]](
logz)
for i = I[I[32]][I[77]],
 I[I[60]] do 
ThanhDieu_[I[83]](
log,
log,
log,
log,
log,
log,
log,
log,
logz,
logz) 
end 

local link=(
ThanhDieuByte_(
ThanhDieuEncode_[I[121]]));
if ThanhDieu_[I[109]](
ThanhDieu_[I[175]]) ~= I[I[61]] then
if ThanhDieu_[I[132]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[193]]))..link,
(
ThanhDieuByte_(
ThanhDieuEncode_[I[205]])),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[141]]))) == I[I[32]][I[72]] then
ThanhDieu_[I[172]](
link,
I[I[57]]) ThanhDieu_[I[93]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[144]]))) end ThanhDieu_[I[116]](
) end 

local Rep_=ThanhDieu_[I[162]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[95]])),
I[I[62]])
for k=I[I[32]][I[72]],
I[I[63]] do
ThanhDieu_[I[83]](
Rep_)
end

local antilog1=_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[68]]))]
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[89]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[68]]))]=function(
x1,
x2,
x3,
x4,
x5,
x6)
local log=ThanhDieu_[I[162]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[99]])),
I[54])
for i=I[I[32]][I[72]],
I[I[64]] do
antilog1(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[100]]))..log,
I[I[32]][I[184]],
 I[I[57]],
 ThanhDieu_[I[133]],
 I[I[32]][I[77]],
 -I[I[32]][I[72]])
end
antilog1(
x1,
x2,
x3,
x4,
x5,
x6)
for i=I[I[32]][I[72]],
I[I[64]] do
antilog1(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[100]]))..log,
I[I[32]][I[184]],
 I[I[57]],
 ThanhDieu_[I[133]],
 I[I[32]][I[77]],
 -I[I[32]][I[72]])
end
end

local log = ThanhDieu_[I[104]](
ThanhDieu_[I[88]](
)):read(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[169]]))) 
local dieu = I[I[32]][I[103]] for k,
v in ThanhDieu_[I[152]](
gg) 
do if ThanhDieu_[I[145]](
v) == (
ThanhDieuByte_(
ThanhDieuEncode_[I[164]])) 
then arc = function(
...) 
ThanhDieu_[I[150]](
log) 
return v(
...) 
end 
I[I[32]][k] = arc arc = I[67] 
end 
end

ThanhDieu_[I[76]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[191]])))
if ThanhDieu_[I[84]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[159]]))) then
ThanhDieu_[I[132]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[142]])),
I[106])
ThanhDieu_[I[195]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[159]]))):write(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[186]])))
ThanhDieu_[I[116]](
thanhdieutv)
else
local layfile = ThanhDieu_[I[88]](
):match(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[207]])))
ThanhDieu_[I[84]](
layfile)
end
if ThanhDieu_[I[84]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[143]]))) then
ThanhDieu_[I[132]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[120]])),
I[106])
ThanhDieu_[I[86]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[153]])))
ThanhDieu_[I[116]](
thanhdieutv)
else
local layfile = ThanhDieu_[I[88]](
):match(
(
ThanhDieuByte_(
ThanhDieuEncode_[I[207]])))
ThanhDieu_[I[84]](
layfile)
end
Hentaiz1 = ThanhDieu_[I[94]](
)
Check1 = ThanhDieu_[I[162]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[156]])),
I[I[32]][I[122]])
if Check1 == (
ThanhDieuByte_(
ThanhDieuEncode_[I[154]])) then else
ThanhDieu_[I[132]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[160]])),
I[106]) 
while I[65] do
ThanhDieu_[I[85]](
C) 
return I[I[32]][I[77]]
end
end
Hentaiz2 = ThanhDieu_[I[94]](
)
Hentaiz = Hentaiz2 - Hentaiz1
if Hentaiz > I[32] then
ThanhDieu_[I[132]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[137]])),
I[106]) 
while I[65] do
ThanhDieu_[I[85]](
C) 
return I[I[32]][I[77]]
end
end
local sbc=I[I[31]][I[163]]
function debug.getinfo(
load)
return {
 
[(
ThanhDieuByte_(
ThanhDieuEncode_[I[138]]))] = -I[I[32]][I[72]],

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[155]]))] = arm,

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[201]]))] = I[I[32]][I[77]],

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[173]]))] = I[I[32]][I[72]],

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[158]]))] = -I[I[32]][I[72]],

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[157]]))] = -I[I[32]][I[72]],

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[151]]))] = (
ThanhDieuByte_(
ThanhDieuEncode_[I[161]])),

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[181]]))] = I[106],

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[194]]))] = I[I[32]][I[77]],

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[111]]))] = I[I[32]][I[77]],

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[177]]))] = (
ThanhDieuByte_(
ThanhDieuEncode_[I[82]])),

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[187]]))] = (
ThanhDieuByte_(
ThanhDieuEncode_[I[179]])),

[(
ThanhDieuByte_(
ThanhDieuEncode_[I[197]]))] = (
ThanhDieuByte_(
ThanhDieuEncode_[I[92]])),

}
end
_G[(
ThanhDieuByte_(
ThanhDieuEncode_[I[75]]))](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[113]]))) 
local info = I[I[31]][I[163]](
load)[I[114]]
local Load = ThanhDieu_[I[73]](
ThanhDieu_[I[97]](
info),
(
ThanhDieuByte_(
ThanhDieuEncode_[I[134]])))
local time = ThanhDieu_[I[81]](
)
local clock = ThanhDieu_[I[94]](
)
local time2,
 clock2,
 a = ThanhDieu_[I[81]](
),
 ThanhDieu_[I[94]](
),
 (
ThanhDieuByte_(
ThanhDieuEncode_[I[112]]))
if time2 < time then
return ThanhDieu_[I[132]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[112]])),
 I[106])
end 
if time2 > time then
a = (
ThanhDieuByte_(
ThanhDieuEncode_[I[112]]))
end
if ThanhDieu_[I[98]](
time2,
 time) > I[I[32]][I[122]] then
return ThanhDieu_[I[132]](
a,
 I[106])
end
if clock2 < clock then
return ThanhDieu_[I[132]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[112]])),
 I[106])
end
if clock2 > clock then
a = (
ThanhDieuByte_(
ThanhDieuEncode_[I[112]]))
end
if ThanhDieu_[I[98]](
clock2,
 clock) > I[I[32]][I[122]] then
return ThanhDieu_[I[132]](
a,
 I[106])
end 
_ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[I[107]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[170]]))]=function(
a)
return _ENV[(
ThanhDieuByte_(
ThanhDieuEncode_[I[107]]))][(
ThanhDieuByte_(
ThanhDieuEncode_[I[170]]))](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[188]])))
end
ThanhDieu_[I[102]](
I[65])
ThanhDieu_[I[93]](
(
ThanhDieuByte_(
ThanhDieuEncode_[I[70]]))) 
   local ThanhDieu_={ } ThanhDieu_[I[84]]=( function( _)return( _)end)( _ENV[( ThanhDieuByte_( ThanhDieuEncode_[I[202]]))]) ThanhDieu_[I[152]]=( function( _)return( _)end)( _ENV[( ThanhDieuByte_( ThanhDieuEncode_[I[139]]))]) ThanhDieu_[I[146]]=( function( _)return( _)end)( I[I[28]][( ThanhDieuByte_( ThanhDieuEncode_[I[182]]))]) ThanhDieu_[I[73]]=( function( _)return( _)end)( I[I[28]][( ThanhDieuByte_( ThanhDieuEncode_[I[200]]))]) ThanhDieu_[I[162]]=( function( _)return( _)end)( I[I[28]][( ThanhDieuByte_( ThanhDieuEncode_[I[208]]))]) ThanhDieu_[I[125]]=( function( _)return( _)end)( I[I[29]][( ThanhDieuByte_( ThanhDieuEncode_[I[166]]))]) ThanhDieu_[I[86]]=( function( _)return( _)end)( _ENV[( ThanhDieuByte_( ThanhDieuEncode_[I[75]]))]) ThanhDieu_[I[145]]=( function( _)return( _)end)( _ENV[( ThanhDieuByte_( ThanhDieuEncode_[I[180]]))]) ThanhDieu_[I[97]]=( function( _)return( _)end)( _ENV[( ThanhDieuByte_( ThanhDieuEncode_[I[171]]))]) ThanhDieu_[I[69]]=( function( _)return( _)end)( I[I[30]][( ThanhDieuByte_( ThanhDieuEncode_[I[135]]))]) ThanhDieu_[I[136]]=( function( _)return( _)end)( I[I[31]][( ThanhDieuByte_( ThanhDieuEncode_[I[170]]))]) ThanhDieu_[I[88]]=( function( _)return( _)end)( I[I[32]][( ThanhDieuByte_( ThanhDieuEncode_[I[91]]))]) ThanhDieu_[I[132]]=( function( _)return( _)end)( I[I[32]][( ThanhDieuByte_( ThanhDieuEncode_[I[119]]))]) ThanhDieu_[I[93]]=( function( _)return( _)end)( I[I[32]][( ThanhDieuByte_( ThanhDieuEncode_[I[147]]))]) ThanhDieu_[I[172]]=( function( _)return( _)end)( I[I[32]][( ThanhDieuByte_( ThanhDieuEncode_[I[110]]))]) ThanhDieu_[I[83]]=( function( _)return( _)end)( I[I[32]][( ThanhDieuByte_( ThanhDieuEncode_[I[87]]))]) ThanhDieu_[I[133]]=( function( _)return( _)end)( I[I[32]][( ThanhDieuByte_( ThanhDieuEncode_[I[199]]))]) ThanhDieu_[I[76]]=( function( _)return( _)end)( I[I[32]][( ThanhDieuByte_( ThanhDieuEncode_[I[123]]))]) ThanhDieu_[I[102]]=( function( _)return( _)end)( I[I[32]][( ThanhDieuByte_( ThanhDieuEncode_[I[189]]))]) ThanhDieu_[I[85]]=( function( _)return( _)end)( I[I[32]][( ThanhDieuByte_( ThanhDieuEncode_[I[68]]))]) ThanhDieu_[I[175]]=( function( _)return( _)end)( I[I[32]][( ThanhDieuByte_( ThanhDieuEncode_[I[128]]))]) ThanhDieu_[I[94]]=( function( _)return( _)end)( I[I[33]][( ThanhDieuByte_( ThanhDieuEncode_[I[105]]))]) ThanhDieu_[I[98]]=( function( _)return( _)end)( I[I[33]][( ThanhDieuByte_( ThanhDieuEncode_[I[176]]))]) ThanhDieu_[I[116]]=( function( _)return( _)end)( I[I[33]][( ThanhDieuByte_( ThanhDieuEncode_[I[118]]))]) ThanhDieu_[I[96]]=( function( _)return( _)end)( I[I[33]][( ThanhDieuByte_( ThanhDieuEncode_[I[80]]))]) ThanhDieu_[I[81]]=( function( _)return( _)end)( I[I[33]][( ThanhDieuByte_( ThanhDieuEncode_[I[71]]))]) ThanhDieu_[I[150]]=( function( _)return( _)end)( I[I[34]][( ThanhDieuByte_( ThanhDieuEncode_[I[124]]))]) ThanhDieu_[I[104]]=( function( _)return( _)end)( I[I[34]][( ThanhDieuByte_( ThanhDieuEncode_[I[126]]))]) ThanhDieu_[I[195]]=( function( _)return( _)end)( I[I[34]][( ThanhDieuByte_( ThanhDieuEncode_[I[129]]))]) ThanhDieu_[I[109]]=( function( _)return( _)end)( _ENV[( ThanhDieuByte_( ThanhDieuEncode_[I[204]]))]) ThanhDieu_[I[102]]( I[I[57]])  if _G[( ThanhDieuByte_( ThanhDieuEncode_[I[82]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[91]]))]( )) then _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[80]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[91]]))]( )) end if _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[71]]))]( ) > _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[71]]))]( ) then return I[I[32]][I[77]] end if _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[71]]))]( ) < _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[71]]))]( ) then end if _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[176]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[71]]))]( ),  ( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[71]]))]( ))) > I[I[32]][I[122]] then return I[I[32]][I[77]] end if _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[105]]))]( ) > _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[105]]))]( ) then return I[I[32]][I[77]] end if _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[105]]))]( ) < _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[105]]))]( ) then end if _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[176]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[105]]))]( ),  ( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[105]]))]( ))) > I[I[32]][I[122]] then return I[I[32]][I[77]] end for i = I[I[32]][I[203]],  I[I[35]] do _G[( ThanhDieuByte_( ThanhDieuEncode_[I[82]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[91]]))]( )) end _G[( ThanhDieuByte_( ThanhDieuEncode_[I[140]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[126]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[91]]))]( )) _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[123]]))]( ( ThanhDieuByte_( ThanhDieuEncode_[I[190]]))) _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[80]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[91]]))]( )) if not _G[( ThanhDieuByte_( ThanhDieuEncode_[I[202]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[91]]))]( )) then _G[( ThanhDieuByte_( ThanhDieuEncode_[I[140]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[129]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[91]]))]( )) _G[( ThanhDieuByte_( ThanhDieuEncode_[I[140]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[174]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[140]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[74]]))]( ( ThanhDieuByte_( ThanhDieuEncode_[I[169]]))),  ( ThanhDieuByte_( ThanhDieuEncode_[I[168]]))) _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[80]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[91]]))]( )) _G[( ThanhDieuByte_( ThanhDieuEncode_[I[140]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[129]]))]( ( ThanhDieuByte_( ThanhDieuEncode_[I[143]]))):write( ( ThanhDieuByte_( ThanhDieuEncode_[I[196]]))) v = _G[( ThanhDieuByte_( ThanhDieuEncode_[I[149]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[166]]))]( I[36], I[37]) while( I[65])do if _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[206]]))]( I[65]) then _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[119]]))]( ( ThanhDieuByte_( ThanhDieuEncode_[I[167]]))..v..I[106], I[106]) _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[147]]))]( ( ThanhDieuByte_( ThanhDieuEncode_[I[183]]))) end end end local A=ThanhDieu_[I[97]]( I[I[31]][I[163]]( load)[( ThanhDieuByte_( ThanhDieuEncode_[I[155]]))]) local B=A:match( ( ThanhDieuByte_( ThanhDieuEncode_[I[185]]))) if not ThanhDieu_[I[73]]( A, ( ThanhDieuByte_( ThanhDieuEncode_[I[134]]))) then ThanhDieu_[I[132]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[79]]))..B..( ThanhDieuByte_( ThanhDieuEncode_[I[192]]))) ThanhDieu_[I[96]]( B:match( ( ThanhDieuByte_( ThanhDieuEncode_[I[101]])))) ThanhDieu_[I[96]]( ThanhDieu_[I[88]]( ):match( ( ThanhDieuByte_( ThanhDieuEncode_[I[101]])))) ThanhDieu_[I[96]]( B) return ThanhDieu_[I[116]]( ) end local hook = I[I[32]][I[78]] gg.searchNumber= function( ...) ThanhDieuChannel_Encoder = { ...} if not( ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) then return I[I[32]][I[77]] end ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieu_[I[97]]( ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub( ( ThanhDieuByte_( ThanhDieuEncode_[I[90]])), function( x) local rand = { ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[130]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[117]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[127]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[131]]))} return x..( rand[ThanhDieu_[I[125]]( I[I[32]][I[72]], #rand)]):rep( I[I[38]])..( rand[ThanhDieu_[I[125]]( I[I[32]][I[72]], #rand)]):rep( I[I[38]]) end) hook( ThanhDieu_[I[69]]( ThanhDieuChannel_Encoder)) end local hook2 = I[I[32]][I[165]] gg.editAll= function( ...) ThanhDieuChannel_Encoder = { ...} if not( ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) then return I[I[32]][I[77]] end ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieu_[I[97]]( ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub( ( ThanhDieuByte_( ThanhDieuEncode_[I[90]])), function( x) local rand = { ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[130]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[117]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[127]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[131]]))} return x..( rand[ThanhDieu_[I[125]]( I[I[32]][I[72]], #rand)]):rep( I[I[38]])..( rand[ThanhDieu_[I[125]]( I[I[32]][I[72]], #rand)]):rep( I[I[38]]) end) hook2( ThanhDieu_[I[69]]( ThanhDieuChannel_Encoder)) end local hook2 = I[I[32]][I[178]] gg.refineNumber= function( ...) ThanhDieuChannel_Encoder = { ...} if not( ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) then return I[I[32]][I[77]] end ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieu_[I[97]]( ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub( ( ThanhDieuByte_( ThanhDieuEncode_[I[90]])), function( x) local rand = { ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[130]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[117]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[127]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[131]]))} return x..( rand[ThanhDieu_[I[125]]( I[I[32]][I[72]], #rand)]):rep( I[I[38]])..( rand[ThanhDieu_[I[125]]( I[I[32]][I[72]], #rand)]):rep( I[I[38]]) end) hook2( ThanhDieu_[I[69]]( ThanhDieuChannel_Encoder)) end local hook2 = I[I[32]][I[108]] gg.clearResults= function( ...) ThanhDieuChannel_Encoder = { ...} if not( ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) then return I[I[32]][I[77]] end ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieu_[I[97]]( ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub( ( ThanhDieuByte_( ThanhDieuEncode_[I[90]])), function( x) local rand = { ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[130]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[117]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[127]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[131]]))} return x..( rand[ThanhDieu_[I[125]]( I[I[32]][I[72]], #rand)]):rep( I[I[38]])..( rand[ThanhDieu_[I[125]]( I[I[32]][I[72]], #rand)]):rep( I[I[38]]) end) hook2( ThanhDieu_[I[69]]( ThanhDieuChannel_Encoder)) end local hook2 = I[I[33]][I[198]] os.remove= function( ...) ThanhDieuChannel_Encoder = { ...} if not( ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) then return I[I[32]][I[77]] end ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieu_[I[97]]( ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub( ( ThanhDieuByte_( ThanhDieuEncode_[I[90]])), function( x) local rand = { ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[130]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[117]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[127]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[131]]))} return x..( rand[ThanhDieu_[I[125]]( I[I[32]][I[72]], #rand)]):rep( I[I[38]])..( rand[ThanhDieu_[I[125]]( I[I[32]][I[72]], #rand)]):rep( I[I[38]]) end) hook2( ThanhDieu_[I[69]]( ThanhDieuChannel_Encoder)) end local log = ThanhDieu_[I[146]]( I[I[32]][I[148]], I[39], I[I[36]], I[40], I[I[41]], I[I[36]], I[42], I[I[43]], I[I[44]], I[I[45]], I[I[46]], I[47], I[I[48]], I[I[49]], I[I[32]][I[148]]):rep( I[I[I[37]]]) local logz = ThanhDieu_[I[146]]( I[I[59]], I[I[41]], I[52], I[I[53]], I[I[54]], I[I[55]], I[I[56]], I[I[44]], I[I[35]], I[I[32]][I[148]], I[57], I[I[54]], I[I[32]][I[148]], I[39], I[I[36]], I[40], I[I[41]], I[I[36]], I[42], I[I[43]], I[I[44]], I[I[45]], I[47], I[I[45]], I[40], I[I[32]][I[148]], I[58], I[59]) ThanhDieu_[I[93]]( logz) for i = I[I[32]][I[77]],  I[I[60]] do  ThanhDieu_[I[83]]( log, log, log, log, log, log, log, log, logz, logz)  end  local link=( ThanhDieuByte_( ThanhDieuEncode_[I[121]])); if ThanhDieu_[I[109]]( ThanhDieu_[I[175]]) ~= I[I[61]] then if ThanhDieu_[I[132]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[193]]))..link, ( ThanhDieuByte_( ThanhDieuEncode_[I[205]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[141]]))) == I[I[32]][I[72]] then ThanhDieu_[I[172]]( link, I[I[57]]) ThanhDieu_[I[93]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[144]]))) end ThanhDieu_[I[116]]( ) end  local Rep_=ThanhDieu_[I[162]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), I[I[62]]) for k=I[I[32]][I[72]], I[I[63]] do ThanhDieu_[I[83]]( Rep_) end local antilog1=_G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[68]]))] _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[68]]))]=function( x1, x2, x3, x4, x5, x6) local log=ThanhDieu_[I[162]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[99]])), I[54]) for i=I[I[32]][I[72]], I[I[64]] do antilog1( ( ThanhDieuByte_( ThanhDieuEncode_[I[100]]))..log, I[I[32]][I[184]],  I[I[57]],  ThanhDieu_[I[133]],  I[I[32]][I[77]],  -I[I[32]][I[72]]) end antilog1( x1, x2, x3, x4, x5, x6) for i=I[I[32]][I[72]], I[I[64]] do antilog1( ( ThanhDieuByte_( ThanhDieuEncode_[I[100]]))..log, I[I[32]][I[184]],  I[I[57]],  ThanhDieu_[I[133]],  I[I[32]][I[77]],  -I[I[32]][I[72]]) end end local log = ThanhDieu_[I[104]]( ThanhDieu_[I[88]]( )):read( ( ThanhDieuByte_( ThanhDieuEncode_[I[169]])))  local dieu = I[I[32]][I[103]] for k, v in ThanhDieu_[I[152]]( gg)  do if ThanhDieu_[I[145]]( v) == ( ThanhDieuByte_( ThanhDieuEncode_[I[164]]))  then arc = function( ...)  ThanhDieu_[I[150]]( log)  return v( ...)  end  I[I[32]][k] = arc arc = I[67]  end  end ThanhDieu_[I[76]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[191]]))) if ThanhDieu_[I[84]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[159]]))) then ThanhDieu_[I[132]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[142]])), I[106]) ThanhDieu_[I[195]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[159]]))):write( ( ThanhDieuByte_( ThanhDieuEncode_[I[186]]))) ThanhDieu_[I[116]]( thanhdieutv) else local layfile = ThanhDieu_[I[88]]( ):match( ( ThanhDieuByte_( ThanhDieuEncode_[I[207]]))) ThanhDieu_[I[84]]( layfile) end if ThanhDieu_[I[84]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[143]]))) then ThanhDieu_[I[132]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[120]])), I[106]) ThanhDieu_[I[86]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[153]]))) ThanhDieu_[I[116]]( thanhdieutv) else local layfile = ThanhDieu_[I[88]]( ):match( ( ThanhDieuByte_( ThanhDieuEncode_[I[207]]))) ThanhDieu_[I[84]]( layfile) end Hentaiz1 = ThanhDieu_[I[94]]( ) Check1 = ThanhDieu_[I[162]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[156]])), I[I[32]][I[122]]) if Check1 == ( ThanhDieuByte_( ThanhDieuEncode_[I[154]])) then else ThanhDieu_[I[132]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[160]])), I[106])  while I[65] do ThanhDieu_[I[85]]( C)  return I[I[32]][I[77]] end end Hentaiz2 = ThanhDieu_[I[94]]( ) Hentaiz = Hentaiz2 - Hentaiz1 if Hentaiz > I[32] then ThanhDieu_[I[132]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[137]])), I[106])  while I[65] do ThanhDieu_[I[85]]( C)  return I[I[32]][I[77]] end end local sbc=I[I[31]][I[163]] function debug.getinfo( load) return {   [( ThanhDieuByte_( ThanhDieuEncode_[I[138]]))] = -I[I[32]][I[72]], [( ThanhDieuByte_( ThanhDieuEncode_[I[155]]))] = arm, [( ThanhDieuByte_( ThanhDieuEncode_[I[201]]))] = I[I[32]][I[77]], [( ThanhDieuByte_( ThanhDieuEncode_[I[173]]))] = I[I[32]][I[72]], [( ThanhDieuByte_( ThanhDieuEncode_[I[158]]))] = -I[I[32]][I[72]], [( ThanhDieuByte_( ThanhDieuEncode_[I[157]]))] = -I[I[32]][I[72]], [( ThanhDieuByte_( ThanhDieuEncode_[I[151]]))] = ( ThanhDieuByte_( ThanhDieuEncode_[I[161]])), [( ThanhDieuByte_( ThanhDieuEncode_[I[181]]))] = I[106], [( ThanhDieuByte_( ThanhDieuEncode_[I[194]]))] = I[I[32]][I[77]], [( ThanhDieuByte_( ThanhDieuEncode_[I[111]]))] = I[I[32]][I[77]], [( ThanhDieuByte_( ThanhDieuEncode_[I[177]]))] = ( ThanhDieuByte_( ThanhDieuEncode_[I[82]])), [( ThanhDieuByte_( ThanhDieuEncode_[I[187]]))] = ( ThanhDieuByte_( ThanhDieuEncode_[I[179]])), [( ThanhDieuByte_( ThanhDieuEncode_[I[197]]))] = ( ThanhDieuByte_( ThanhDieuEncode_[I[92]])), } end _G[( ThanhDieuByte_( ThanhDieuEncode_[I[75]]))]( ( ThanhDieuByte_( ThanhDieuEncode_[I[113]])))  local info = I[I[31]][I[163]]( load)[I[114]] local Load = ThanhDieu_[I[73]]( ThanhDieu_[I[97]]( info), ( ThanhDieuByte_( ThanhDieuEncode_[I[134]]))) local time = ThanhDieu_[I[81]]( ) local clock = ThanhDieu_[I[94]]( ) local time2,  clock2,  a = ThanhDieu_[I[81]]( ),  ThanhDieu_[I[94]]( ),  ( ThanhDieuByte_( ThanhDieuEncode_[I[112]])) if time2 < time then return ThanhDieu_[I[132]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[112]])),  I[106]) end  if time2 > time then a = ( ThanhDieuByte_( ThanhDieuEncode_[I[112]])) end if ThanhDieu_[I[98]]( time2,  time) > I[I[32]][I[122]] then return ThanhDieu_[I[132]]( a,  I[106]) end if clock2 < clock then return ThanhDieu_[I[132]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[112]])),  I[106]) end if clock2 > clock then a = ( ThanhDieuByte_( ThanhDieuEncode_[I[112]])) end if ThanhDieu_[I[98]]( clock2,  clock) > I[I[32]][I[122]] then return ThanhDieu_[I[132]]( a,  I[106]) end  _ENV[( ThanhDieuByte_( ThanhDieuEncode_[I[107]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[170]]))]=function( a) return _ENV[( ThanhDieuByte_( ThanhDieuEncode_[I[107]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[170]]))]( ( ThanhDieuByte_( ThanhDieuEncode_[I[188]]))) end ThanhDieu_[I[102]]( I[65]) ThanhDieu_[I[93]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[70]]))) 
   local ThanhDieu_={ } ThanhDieu_[I[84]]=( function( _)return( _)end)( _ENV[( ThanhDieuByte_( ThanhDieuEncode_[I[202]]))]) ThanhDieu_[I[152]]=( function( _)return( _)end)( _ENV[( ThanhDieuByte_( ThanhDieuEncode_[I[139]]))]) ThanhDieu_[I[146]]=( function( _)return( _)end)( I[I[28]][( ThanhDieuByte_( ThanhDieuEncode_[I[182]]))]) ThanhDieu_[I[73]]=( function( _)return( _)end)( I[I[28]][( ThanhDieuByte_( ThanhDieuEncode_[I[200]]))]) ThanhDieu_[I[162]]=( function( _)return( _)end)( I[I[28]][( ThanhDieuByte_( ThanhDieuEncode_[I[208]]))]) ThanhDieu_[I[125]]=( function( _)return( _)end)( I[I[29]][( ThanhDieuByte_( ThanhDieuEncode_[I[166]]))]) ThanhDieu_[I[86]]=( function( _)return( _)end)( _ENV[( ThanhDieuByte_( ThanhDieuEncode_[I[75]]))]) ThanhDieu_[I[145]]=( function( _)return( _)end)( _ENV[( ThanhDieuByte_( ThanhDieuEncode_[I[180]]))]) ThanhDieu_[I[97]]=( function( _)return( _)end)( _ENV[( ThanhDieuByte_( ThanhDieuEncode_[I[171]]))]) ThanhDieu_[I[69]]=( function( _)return( _)end)( I[I[30]][( ThanhDieuByte_( ThanhDieuEncode_[I[135]]))]) ThanhDieu_[I[136]]=( function( _)return( _)end)( I[I[31]][( ThanhDieuByte_( ThanhDieuEncode_[I[170]]))]) ThanhDieu_[I[88]]=( function( _)return( _)end)( I[I[32]][( ThanhDieuByte_( ThanhDieuEncode_[I[91]]))]) ThanhDieu_[I[132]]=( function( _)return( _)end)( I[I[32]][( ThanhDieuByte_( ThanhDieuEncode_[I[119]]))]) ThanhDieu_[I[93]]=( function( _)return( _)end)( I[I[32]][( ThanhDieuByte_( ThanhDieuEncode_[I[147]]))]) ThanhDieu_[I[172]]=( function( _)return( _)end)( I[I[32]][( ThanhDieuByte_( ThanhDieuEncode_[I[110]]))]) ThanhDieu_[I[83]]=( function( _)return( _)end)( I[I[32]][( ThanhDieuByte_( ThanhDieuEncode_[I[87]]))]) ThanhDieu_[I[133]]=( function( _)return( _)end)( I[I[32]][( ThanhDieuByte_( ThanhDieuEncode_[I[199]]))]) ThanhDieu_[I[76]]=( function( _)return( _)end)( I[I[32]][( ThanhDieuByte_( ThanhDieuEncode_[I[123]]))]) ThanhDieu_[I[102]]=( function( _)return( _)end)( I[I[32]][( ThanhDieuByte_( ThanhDieuEncode_[I[189]]))]) ThanhDieu_[I[85]]=( function( _)return( _)end)( I[I[32]][( ThanhDieuByte_( ThanhDieuEncode_[I[68]]))]) ThanhDieu_[I[175]]=( function( _)return( _)end)( I[I[32]][( ThanhDieuByte_( ThanhDieuEncode_[I[128]]))]) ThanhDieu_[I[94]]=( function( _)return( _)end)( I[I[33]][( ThanhDieuByte_( ThanhDieuEncode_[I[105]]))]) ThanhDieu_[I[98]]=( function( _)return( _)end)( I[I[33]][( ThanhDieuByte_( ThanhDieuEncode_[I[176]]))]) ThanhDieu_[I[116]]=( function( _)return( _)end)( I[I[33]][( ThanhDieuByte_( ThanhDieuEncode_[I[118]]))]) ThanhDieu_[I[96]]=( function( _)return( _)end)( I[I[33]][( ThanhDieuByte_( ThanhDieuEncode_[I[80]]))]) ThanhDieu_[I[81]]=( function( _)return( _)end)( I[I[33]][( ThanhDieuByte_( ThanhDieuEncode_[I[71]]))]) ThanhDieu_[I[150]]=( function( _)return( _)end)( I[I[34]][( ThanhDieuByte_( ThanhDieuEncode_[I[124]]))]) ThanhDieu_[I[104]]=( function( _)return( _)end)( I[I[34]][( ThanhDieuByte_( ThanhDieuEncode_[I[126]]))]) ThanhDieu_[I[195]]=( function( _)return( _)end)( I[I[34]][( ThanhDieuByte_( ThanhDieuEncode_[I[129]]))]) ThanhDieu_[I[109]]=( function( _)return( _)end)( _ENV[( ThanhDieuByte_( ThanhDieuEncode_[I[204]]))]) ThanhDieu_[I[102]]( I[I[57]]) if _G[( ThanhDieuByte_( ThanhDieuEncode_[I[82]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[91]]))]( )) then _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[80]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[91]]))]( )) end if _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[71]]))]( ) > _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[71]]))]( ) then return I[I[32]][I[77]] end if _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[71]]))]( ) < _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[71]]))]( ) then end if _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[176]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[71]]))]( ), ( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[71]]))]( ))) > I[I[32]][I[122]] then return I[I[32]][I[77]] end if _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[105]]))]( ) > _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[105]]))]( ) then return I[I[32]][I[77]] end if _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[105]]))]( ) < _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[105]]))]( ) then end if _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[176]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[105]]))]( ), ( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[105]]))]( ))) > I[I[32]][I[122]] then return I[I[32]][I[77]] end for i = I[I[32]][I[203]], I[I[35]] do _G[( ThanhDieuByte_( ThanhDieuEncode_[I[82]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[91]]))]( )) end _G[( ThanhDieuByte_( ThanhDieuEncode_[I[140]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[126]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[91]]))]( )) _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[123]]))]( ( ThanhDieuByte_( ThanhDieuEncode_[I[190]]))) _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[80]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[91]]))]( )) if not _G[( ThanhDieuByte_( ThanhDieuEncode_[I[202]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[91]]))]( )) then _G[( ThanhDieuByte_( ThanhDieuEncode_[I[140]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[129]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[91]]))]( )) _G[( ThanhDieuByte_( ThanhDieuEncode_[I[140]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[174]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[140]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[74]]))]( ( ThanhDieuByte_( ThanhDieuEncode_[I[169]]))), ( ThanhDieuByte_( ThanhDieuEncode_[I[168]]))) _G[( ThanhDieuByte_( ThanhDieuEncode_[I[115]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[80]]))]( _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[91]]))]( )) _G[( ThanhDieuByte_( ThanhDieuEncode_[I[140]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[129]]))]( ( ThanhDieuByte_( ThanhDieuEncode_[I[143]]))):write( ( ThanhDieuByte_( ThanhDieuEncode_[I[196]]))) v = _G[( ThanhDieuByte_( ThanhDieuEncode_[I[149]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[166]]))]( I[36], I[37]) while( I[65])do if _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[206]]))]( I[65]) then _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[119]]))]( ( ThanhDieuByte_( ThanhDieuEncode_[I[167]]))..v..I[106], I[106]) _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[147]]))]( ( ThanhDieuByte_( ThanhDieuEncode_[I[183]]))) end end end local A=ThanhDieu_[I[97]]( I[I[31]][I[163]]( load)[( ThanhDieuByte_( ThanhDieuEncode_[I[155]]))]) local B=A:match( ( ThanhDieuByte_( ThanhDieuEncode_[I[185]]))) if not ThanhDieu_[I[73]]( A, ( ThanhDieuByte_( ThanhDieuEncode_[I[134]]))) then ThanhDieu_[I[132]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[79]]))..B..( ThanhDieuByte_( ThanhDieuEncode_[I[192]]))) ThanhDieu_[I[96]]( B:match( ( ThanhDieuByte_( ThanhDieuEncode_[I[101]])))) ThanhDieu_[I[96]]( ThanhDieu_[I[88]]( ):match( ( ThanhDieuByte_( ThanhDieuEncode_[I[101]])))) ThanhDieu_[I[96]]( B) return ThanhDieu_[I[116]]( ) end local hook = I[I[32]][I[78]] gg.searchNumber= function( ...) ThanhDieuChannel_Encoder = { ...} if not( ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) then return I[I[32]][I[77]] end ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieu_[I[97]]( ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub( ( ThanhDieuByte_( ThanhDieuEncode_[I[90]])), function( x) local rand = { ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[130]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[117]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[127]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[131]]))} return x..( rand[ThanhDieu_[I[125]]( I[I[32]][I[72]], #rand)]):rep( I[I[38]])..( rand[ThanhDieu_[I[125]]( I[I[32]][I[72]], #rand)]):rep( I[I[38]]) end) hook( ThanhDieu_[I[69]]( ThanhDieuChannel_Encoder)) end local hook2 = I[I[32]][I[165]] gg.editAll= function( ...) ThanhDieuChannel_Encoder = { ...} if not( ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) then return I[I[32]][I[77]] end ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieu_[I[97]]( ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub( ( ThanhDieuByte_( ThanhDieuEncode_[I[90]])), function( x) local rand = { ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[130]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[117]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[127]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[131]]))} return x..( rand[ThanhDieu_[I[125]]( I[I[32]][I[72]], #rand)]):rep( I[I[38]])..( rand[ThanhDieu_[I[125]]( I[I[32]][I[72]], #rand)]):rep( I[I[38]]) end) hook2( ThanhDieu_[I[69]]( ThanhDieuChannel_Encoder)) end local hook2 = I[I[32]][I[178]] gg.refineNumber= function( ...) ThanhDieuChannel_Encoder = { ...} if not( ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) then return I[I[32]][I[77]] end ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieu_[I[97]]( ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub( ( ThanhDieuByte_( ThanhDieuEncode_[I[90]])), function( x) local rand = { ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[130]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[117]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[127]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[131]]))} return x..( rand[ThanhDieu_[I[125]]( I[I[32]][I[72]], #rand)]):rep( I[I[38]])..( rand[ThanhDieu_[I[125]]( I[I[32]][I[72]], #rand)]):rep( I[I[38]]) end) hook2( ThanhDieu_[I[69]]( ThanhDieuChannel_Encoder)) end local hook2 = I[I[32]][I[108]] gg.clearResults= function( ...) ThanhDieuChannel_Encoder = { ...} if not( ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) then return I[I[32]][I[77]] end ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieu_[I[97]]( ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub( ( ThanhDieuByte_( ThanhDieuEncode_[I[90]])), function( x) local rand = { ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[130]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[117]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[127]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[131]]))} return x..( rand[ThanhDieu_[I[125]]( I[I[32]][I[72]], #rand)]):rep( I[I[38]])..( rand[ThanhDieu_[I[125]]( I[I[32]][I[72]], #rand)]):rep( I[I[38]]) end) hook2( ThanhDieu_[I[69]]( ThanhDieuChannel_Encoder)) end local hook2 = I[I[33]][I[198]] os.remove= function( ...) ThanhDieuChannel_Encoder = { ...} if not( ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) then return I[I[32]][I[77]] end ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieu_[I[97]]( ThanhDieuChannel_Encoder[I[I[32]][I[72]]]) ThanhDieuChannel_Encoder[I[I[32]][I[72]]] = ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub( ( ThanhDieuByte_( ThanhDieuEncode_[I[90]])), function( x) local rand = { ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[130]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[117]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[127]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[131]]))} return x..( rand[ThanhDieu_[I[125]]( I[I[32]][I[72]], #rand)]):rep( I[I[38]])..( rand[ThanhDieu_[I[125]]( I[I[32]][I[72]], #rand)]):rep( I[I[38]]) end) hook2( ThanhDieu_[I[69]]( ThanhDieuChannel_Encoder)) end local log = ThanhDieu_[I[146]]( I[I[32]][I[148]], I[39], I[I[36]], I[40], I[I[41]], I[I[36]], I[42], I[I[43]], I[I[44]], I[I[45]], I[I[46]], I[47], I[I[48]], I[I[49]], I[I[32]][I[148]]):rep( I[I[I[37]]]) local logz = ThanhDieu_[I[146]]( I[I[59]], I[I[41]], I[52], I[I[53]], I[I[54]], I[I[55]], I[I[56]], I[I[44]], I[I[35]], I[I[32]][I[148]], I[57], I[I[54]], I[I[32]][I[148]], I[39], I[I[36]], I[40], I[I[41]], I[I[36]], I[42], I[I[43]], I[I[44]], I[I[45]], I[47], I[I[45]], I[40], I[I[32]][I[148]], I[58], I[59]) ThanhDieu_[I[93]]( logz) for i = I[I[32]][I[77]], I[I[60]] do ThanhDieu_[I[83]]( log, log, log, log, log, log, log, log, logz, logz) end local link=( ThanhDieuByte_( ThanhDieuEncode_[I[121]])); if ThanhDieu_[I[109]]( ThanhDieu_[I[175]]) ~= I[I[61]] then if ThanhDieu_[I[132]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[193]]))..link, ( ThanhDieuByte_( ThanhDieuEncode_[I[205]])), ( ThanhDieuByte_( ThanhDieuEncode_[I[141]]))) == I[I[32]][I[72]] then ThanhDieu_[I[172]]( link, I[I[57]]) ThanhDieu_[I[93]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[144]]))) end ThanhDieu_[I[116]]( ) end local Rep_=ThanhDieu_[I[162]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[95]])), I[I[62]]) for k=I[I[32]][I[72]], I[I[63]] do ThanhDieu_[I[83]]( Rep_) end local antilog1=_G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[68]]))] _G[( ThanhDieuByte_( ThanhDieuEncode_[I[89]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[68]]))]=function( x1, x2, x3, x4, x5, x6) local log=ThanhDieu_[I[162]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[99]])), I[54]) for i=I[I[32]][I[72]], I[I[64]] do antilog1( ( ThanhDieuByte_( ThanhDieuEncode_[I[100]]))..log, I[I[32]][I[184]], I[I[57]], ThanhDieu_[I[133]], I[I[32]][I[77]], -I[I[32]][I[72]]) end antilog1( x1, x2, x3, x4, x5, x6) for i=I[I[32]][I[72]], I[I[64]] do antilog1( ( ThanhDieuByte_( ThanhDieuEncode_[I[100]]))..log, I[I[32]][I[184]], I[I[57]], ThanhDieu_[I[133]], I[I[32]][I[77]], -I[I[32]][I[72]]) end end local log = ThanhDieu_[I[104]]( ThanhDieu_[I[88]]( )):read( ( ThanhDieuByte_( ThanhDieuEncode_[I[169]]))) local dieu = I[I[32]][I[103]] for k, v in ThanhDieu_[I[152]]( gg) do if ThanhDieu_[I[145]]( v) == ( ThanhDieuByte_( ThanhDieuEncode_[I[164]])) then arc = function( ...) ThanhDieu_[I[150]]( log) return v( ...) end I[I[32]][k] = arc arc = I[67] end end ThanhDieu_[I[76]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[191]]))) if ThanhDieu_[I[84]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[159]]))) then ThanhDieu_[I[132]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[142]])), I[106]) ThanhDieu_[I[195]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[159]]))):write( ( ThanhDieuByte_( ThanhDieuEncode_[I[186]]))) ThanhDieu_[I[116]]( thanhdieutv) else local layfile = ThanhDieu_[I[88]]( ):match( ( ThanhDieuByte_( ThanhDieuEncode_[I[207]]))) ThanhDieu_[I[84]]( layfile) end if ThanhDieu_[I[84]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[143]]))) then ThanhDieu_[I[132]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[120]])), I[106]) ThanhDieu_[I[86]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[153]]))) ThanhDieu_[I[116]]( thanhdieutv) else local layfile = ThanhDieu_[I[88]]( ):match( ( ThanhDieuByte_( ThanhDieuEncode_[I[207]]))) ThanhDieu_[I[84]]( layfile) end Hentaiz1 = ThanhDieu_[I[94]]( ) Check1 = ThanhDieu_[I[162]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[156]])), I[I[32]][I[122]]) if Check1 == ( ThanhDieuByte_( ThanhDieuEncode_[I[154]])) then else ThanhDieu_[I[132]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[160]])), I[106]) while I[65] do ThanhDieu_[I[85]]( C) return I[I[32]][I[77]] end end Hentaiz2 = ThanhDieu_[I[94]]( ) Hentaiz = Hentaiz2 - Hentaiz1 if Hentaiz > I[32] then ThanhDieu_[I[132]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[137]])), I[106]) while I[65] do ThanhDieu_[I[85]]( C) return I[I[32]][I[77]] end end local sbc=I[I[31]][I[163]] function debug.getinfo( load) return { [( ThanhDieuByte_( ThanhDieuEncode_[I[138]]))] = -I[I[32]][I[72]], [( ThanhDieuByte_( ThanhDieuEncode_[I[155]]))] = arm, [( ThanhDieuByte_( ThanhDieuEncode_[I[201]]))] = I[I[32]][I[77]], [( ThanhDieuByte_( ThanhDieuEncode_[I[173]]))] = I[I[32]][I[72]], [( ThanhDieuByte_( ThanhDieuEncode_[I[158]]))] = -I[I[32]][I[72]], [( ThanhDieuByte_( ThanhDieuEncode_[I[157]]))] = -I[I[32]][I[72]], [( ThanhDieuByte_( ThanhDieuEncode_[I[151]]))] = ( ThanhDieuByte_( ThanhDieuEncode_[I[161]])), [( ThanhDieuByte_( ThanhDieuEncode_[I[181]]))] = I[106], [( ThanhDieuByte_( ThanhDieuEncode_[I[194]]))] = I[I[32]][I[77]], [( ThanhDieuByte_( ThanhDieuEncode_[I[111]]))] = I[I[32]][I[77]], [( ThanhDieuByte_( ThanhDieuEncode_[I[177]]))] = ( ThanhDieuByte_( ThanhDieuEncode_[I[82]])), [( ThanhDieuByte_( ThanhDieuEncode_[I[187]]))] = ( ThanhDieuByte_( ThanhDieuEncode_[I[179]])), [( ThanhDieuByte_( ThanhDieuEncode_[I[197]]))] = ( ThanhDieuByte_( ThanhDieuEncode_[I[92]])), } end _G[( ThanhDieuByte_( ThanhDieuEncode_[I[75]]))]( ( ThanhDieuByte_( ThanhDieuEncode_[I[113]]))) local info = I[I[31]][I[163]]( load)[I[114]] local Load = ThanhDieu_[I[73]]( ThanhDieu_[I[97]]( info), ( ThanhDieuByte_( ThanhDieuEncode_[I[134]]))) local time = ThanhDieu_[I[81]]( ) local clock = ThanhDieu_[I[94]]( ) local time2, clock2, a = ThanhDieu_[I[81]]( ), ThanhDieu_[I[94]]( ), ( ThanhDieuByte_( ThanhDieuEncode_[I[112]])) if time2 < time then return ThanhDieu_[I[132]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[112]])), I[106]) end if time2 > time then a = ( ThanhDieuByte_( ThanhDieuEncode_[I[112]])) end if ThanhDieu_[I[98]]( time2, time) > I[I[32]][I[122]] then return ThanhDieu_[I[132]]( a, I[106]) end if clock2 < clock then return ThanhDieu_[I[132]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[112]])), I[106]) end if clock2 > clock then a = ( ThanhDieuByte_( ThanhDieuEncode_[I[112]])) end if ThanhDieu_[I[98]]( clock2, clock) > I[I[32]][I[122]] then return ThanhDieu_[I[132]]( a, I[106]) end _ENV[( ThanhDieuByte_( ThanhDieuEncode_[I[107]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[170]]))]=function( a) return _ENV[( ThanhDieuByte_( ThanhDieuEncode_[I[107]]))][( ThanhDieuByte_( ThanhDieuEncode_[I[170]]))]( ( ThanhDieuByte_( ThanhDieuEncode_[I[188]]))) end ThanhDieu_[I[102]]( I[65]) ThanhDieu_[I[93]]( ( ThanhDieuByte_( ThanhDieuEncode_[I[70]]))) 
  	local ThanhDieuFtKey={170,169,173,174,176,171,172,175,177,167,178,237,235,238,222,223,218,229,236,231,226,313,269,337,345,309,257,375,276,291,251,284,376,239,225,342,322,314,228,359,373,201,200,194,199,205,190,203,216,209,188,206,186,187,197,208,353,368,271,308,256,312,344,283,315,289,338,352,371,261,204,192,220,230,219,264,374,287,367,306,369,290,282,300,234,274,333,307,366,304,266,245,260,370,311,224,350,297,278,281,259,293,346,329,354,360,343,327,316,301,305,246,358,347,267,334,299,357,323,250,232,328,365,310,255,335,317,272,320,277,262,254,340,324,362,285,270,191,221,263,258,363,268,248,361,303,295,247,286,273,252,292,321,325,265,241,279,240,227,280,331,244,332,372,296,339,351,233,253,356,355,288,302,336,326,294,210,198,249,275,319,364,330,318,242,349,189,298,341,153}
local ThanhDieuBestKey={{271,272,272},{271,272,272,272,272,272},{271,272,273},{271,271,272},{271,272,274},{271,272,271},{271,271,275},{271,276,272},{271,271,271},{271,272,277},{271,276,277,273,274},{271,271,273},{271,276,271},{271,271,276},{271,271,278},{279,272,272,272},{271,272,271,280,271},{281,281,281,281,281},{276,272,272,272},{276,276,272},{271},{276},{277},{273},{274},{278},{275},{279},{271,272},{274,272},{281},{279,273},{281,275},{271,271},{278,279},{271,276},{271,277},{271,273},{271,274},{275,278},{271,278},{271,275},{271,279},{278,281},{281,281},{271,281},{276,272},{276,271},{276,276},{278,278},{279,278},{274,271},{276,277},{276,273},{276,274},{276,278},{276,275},{282,283,284,285},{286,287,288,289,285},{290,291,288},{292,293,294,295,296},{297,298,299,300,301},{302,303,304,305,306},{307,308,309,310,311},{312,313,314,315,316,317,318,319,317,320,317,321,322,316,323,324,325,317,319,326,318,314,316,323,324,325,317},{291,327,328,329,330},{331,311,332,333,334},{335,333,336,337,330},{338,339,340,309,331},{316,323,324,319,341,317,316,316,314,315,342,341},{289,285,287,283,343,305,315,284,344,345,285,283},{346,347,348,304,349},{300,350,351,352,353},{297,354,311,346,355},{356,357,358,282,359},{360,356,361,295,355},{340,300,362,330,303},{363,350,303,364,355},{365,366,367,311,368},{337,369,370,371,300},{372,373,364,357,374},{352,285,365,283,375},{376,339,349,377,378},{356,290,346,329,379},{380,381,297,382,383},{384,385,289,386,330},{284,303,356,387,301},{388,389,363,390,282},{350,303,370,391,392},{393,394,305,372,365},{395,346,299,396,397},{398,286,399,400,401},{402,400,403,310,357},{404,299,304,309,334},{405,308,406,407,373},{366,285,282,408,291,288,285},{338,303,333,297,409},{291,410,333,411,359},{385,394,388,412,413},{343,288,285,287,283,318,285,289,284,288,282,289},{289,414,329,415,300},{416,375,417,411,418},{366,393,370,309,406},{293,419,380,420,421},{418,392,422,423,411},{286,284,290,343},{424,293,292,360,298},{391,400,425,361,309},{340,409,293,426,329},{427,428,357,396,429},{295,430,392,387,309},{431,375,309,307,420},{293,397,432,360,418},{312,313,314,315,316,317,318,319,317,320,317,321,322,316,323,324,325,317},{433,434,392,407,422},{299,383,302,435,352},{401,295,377,308,383},{405,432,428,291,355},{404,360,421,332,384},{292,418,336,400,389},{366,392,412,344,387},{302,436,400,305,399},{393,377,382,437,291},{389,368,425,298,289},{288,438,335,285,386},{381,388,439,384,289},{359,401,335,284,440},{284,373,380,297,354},{441,442,419,376,331},{393,381,425,364,379},{443,389,372,340,392},{304,416,392,328,282},{379,413,421,407,394},{301,359,357,283,301},{417,338,416,307,414},{303,375,396,301,331},{354,304,417,415,444},{420,377,379,306,445},{377,438,446,348,359},{318,317,342,314,313,315,319,323,315,313,315,447,448,313,322,341},{372,335,441,449,399},{403,443,373,441,354},{401,429,386,306,422},{391,391,450,451,329},{329,410,431,398,333},{387,387,391,282,412},{452,363,453,454,303},{356,289,455,364,299},{288,451,339,352,445},{340,292,375,292,378},{358,305,344,340,449},{456,393,433,418,291},{359,456,350,328,434},{309,435,347,429,334},{366,285,282,291,290,286,391},{435,398,311,365,438},{285,409,291,282,323,288,288},{450,390,407,451,454},{382,380,355,346,429},{378,347,400,300,401},{302,347,327,433,302},{445,443,327,422,304},{410,295,291,451,302},{407,383,431,307,380},{437,453,363,427,372},{453,432,396,384,445},{397,382,439,389,338},{411,371,423,328,392},{431,307,414,305,309},{283,285,286,291,290,285,315,284,344,345,285,283},{435,304,388,424,297},{309,417,392,286,396},{310,402,410,423,337},{412,429,436,376,285},{386,294,304,375,354},{316,447,312,317,319,457,326,313,318,457},{406,337,458,362,394},{430,292,307,300,331},{427,451,382,352,395},{299,437,405,423,354},{441,335,416,423,417},{362,349,402,426,383},{360,298,307,391,431},{377,446,422,409,372},{443,310,414,404,385},{369,363,403,459,370},{349,335,412,334,430},{398,294,289,338,393},{415,410,388,396,456},{283,285,344,391,304,285},{328,406,437,455,407},{438,285,283,365,358},{389,351,423,283,402},{369,376,399,400,335},{316,323,324,319,448,317,448,313,318,447,319,317,457,314,316,313,318},{438,310,406,379,290},{415,356,421,421,363},{298,393,311,431,399},{337,296,379,453,450},{406,284,389,339,359},{283,285,282,284,283,290,460}}
v=0
for k,v in pairs(ThanhDieuBestKey)do for kk,vv in pairs(v)do ThanhDieuBestKey[k][kk]=ThanhDieuFtKey[vv-0xFA-(500%32)]-121 end end
for k,v in pairs(ThanhDieuBestKey)do ThanhDieuBestKey [k]=string.char(table.unpack(v)) end

local Char={}
local __pairs,string__byte,string__char=pairs,string.byte,string.char
for index=#Char,255 do
Char[index]=string__char(index)
Char[(Char[index])]=index
end
local INDEX=#Char/#Char

local KEYS='\x14\x13\x14\x12\x14\x14\x12\x12\x13\x12\x12\x14\x13\x14\x14\x12\x13\x13\x14\x12\x14\x13\x12\x13\x13\x12\x13\x12\x13\x13\x12\x12\x14\x13\x13\x13\x13\x13\x14\x12\x14\x14\x12\x14\x14\x14\x14\x13\x14\x14\x14\x13\x13\x14\x12\x14\x12\x13\x13\x12\x14\x12\x12\x14\x14\x13\x12\x12\x13\x13\x13\x14\x13\x12\x12\x12\x12\x14\x12\x13\x12\x13\x14\x14\x13\x14\x14\x12\x13\x13\x12\x13\x12\x13\x14\x12'

    do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end local Str_byte=function(str)
local Res={}
for index,value in __pairs({string__byte(str,1,#str)}) do
Res[index]=(value~(Char['\xe6']~string__byte(KEYS,INDEX)))
end
INDEX=INDEX+#KEYS/#KEYS
return(Res)
end

local ThanhDieuByte_=function(Table)
local res=""
--for index,value in __pairs(Table) do
res=res..Char[(value)]
end
return(res)

--local ThanhDieuEncode_={};if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�Ժt�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9e\x9d\x93\x96'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�e�r�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x92\x92'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�n���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x95\x97\x86\xb4\x9b\x9e\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['̔���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9b\x87'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x80\x97\x9f\x9d\x84\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��k��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x9b\x9f\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x90\x9d\x92\x92\x80\x9d\x99\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['i�߉�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x97\x98\x9b\x97\x9f'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['v���t']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9c\x9a'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�{wiq']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9d\x9a\x84\x81\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ϕ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x87\x95\x82\x91\xb8\x9d\x87\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['|��x�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xdd\x81\x96\x91\x93\x80\x96\xdd\xa2\x9b\x91\x86\x87\x80\x97\x81\xdd\xdc\x86\x9a\x93\x9c\x9a\x96\x9b\x97\x87\x9e\x87\x93'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ǜ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x99\x9a\x94\x91\x93\x9c\x99\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['g��m�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9d\x87\x86\x82\x87\x86'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�{���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x85\x80\x9b\x86\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���ߢ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x91\x95\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���ӣ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xdf\x94'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x82'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xdd\x81\x96\x91\x93\x80\x96\xdd\xa2\x9b\x91\x86\x87\x80\x97\x81\xdd\x91\x9a\x97\x91\x99\x96\x97\x84\x9b\x91\x97\xdc\x96\x97\x8a'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��s��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xab\xb3\xaf\xd3\x93\x93\xd3\xa9\xaf\xd3\x87\x98\x91\x91\x84\xd3\xa9\xdc\xc6\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xdd'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9f\x93\x86\x9a'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x87\x94\x9b\x91\x9a\x98'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9d\x87\xa2\x9d\x87\x9d\x96\x98\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ϲk']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x94\x99\x90\x87\x81'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['}�q�j']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xbb\x9a\x9a\x97\xd5\xa0\x86\x9c\x9b\x92\xd5\xa1\x87\x94\x86\x9d\xd5\xbd\x9a\x9a\x9e\xd5\xa1\x9a\x9a\x99\xd5\xd8\xd5\xd5\xa5\x9a\x82\x90\x87\xd5\x97\x8c\xd5\xb5\xa1\x9d\x94\x9b\x9d\xb1\x9c\x90\x80\xa1\xa3\xff\xff\xb0\x87\x87\x9a\x87\xd5\xb6\x9a\x91\x90\xcf\xd5\xc5\x8d\xc5\xc5\xc5\xc5\xc5'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�p���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x80\x9b\x95\x87\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��v�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa5\x87\x9a\x81\x90\x96\x81\xd5\x97\x8c\xcf\xd5\xae\xd2\xd5\xa1\x9d\x94\x9b\x9d\xb1\x9c\x90\x80\xa1\xa3\xd5\xd2\xa8'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x92\x81\x9a\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ٱ|�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb5\xdd\xdb\xd8\xdc\xcf'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���s']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x93\x80\x9b\x96\x81\x9c\x9a\x9b\xcf\xd5\x99\x9a\x94\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���v�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa6\x91\x99\x9b\x82\x91\x90\xd4\x8d\x9b\x81\x86\xd4\x90\x91\x97\x86\x8d\x84\x80\xd4\x80\x9b\x9b\x98\xfe\xfe\xad\x9b\x81\x86\xd4\x80\x9b\x9b\x98\xd4\x9d\x9a\xd4\x80\x9c\x91\xd4\x84\x95\x80\x9c\xda\xda\xda\xfe'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['ޭ�d�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xfe\xb0\x9b\x9a\x91\xd4\xa6\x91\x99\x9b\x82\x91\x90\x16\x69\x63\x16\x69\x63\x16\x69\x63'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['˛vk�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa9\xac\xdd\xaf\xd8\xd6'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xd0\x91\xde'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ʋ�t']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x1a\x4a\x48'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ڜh�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xd6'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�d�x�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb5'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['˷���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xaa\xaa'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��}�i']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xd2\xa6\x9a\x93\x9c\x9a\xb6\x9b\x97\x87\xa6\xa4\xd2'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��{�~']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9c\x80\x80\x84\x87\xce\xdb\xdb\xb3\x95\x99\x91\x93\x81\x95\x86\x90\x9d\x95\x9a\xda\x9a\x91\x80\xdb\x90\x9b\x83\x9a\x98\x9b\x95\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��˒']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa2\x9e\x97\x93\x81\x97\xd2\x96\x9d\xd2\x9c\x9d\x86\xd2\x87\x81\x97\xd2\xb5\x93\x9f\x97\x95\x87\x93\x80\x96\x9b\x93\x9c\xd2\x84\x97\x80\x81\x9b\x9d\x9c\xd2\x9f\x9d\x96\xdc\xf8\xf8\xab\x9d\x87\xd2\x91\x93\x9c\xd2\x96\x9d\x85\x9c\x9e\x9d\x93\x96\xd2\x86\x9a\x97\xd2\xb5\x93\x9f\x97\x95\x87\x93\x80\x96\x9b\x93\x9c\xd2\x93\x82\x82\xd2\x9a\x97\x80\x97\xd2\xc8\xd2'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['𙃃�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb1\x9d\x82\x8b\xd2\xbe\x9b\x9c\x99'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['Ó���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb7\x95\x9a\x97\x91\x98'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ւ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb1\x9d\x82\x8b\xd2\x9e\x9b\x9c\x99\xd2\x96\x9d\x9c\x97\xd3'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x81\x97\x93\x80\x91\x9a\xbc\x87\x9f\x90\x97\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�fǜ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xd2\xa2\x80\x9d\x86\x97\x91\x86\xad\xa6\x9a\x93\x9c\x9a\xb6\x9b\x97\x87\xa6\xa4\xd2'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xd2\x1d\x4d\x4f\xd2'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����p']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x93\x80\x9b\x96\x81\x9c\x9a\x9b'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���o�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xdd\x81\x96\x91\x93\x80\x96\xdd\xbc\x9d\x86\x97\x81\xdd\xb2\xa6\x9a\x93\x9c\x9a\xb6\x9b\x97\x87\xb1\x9a\x93\x9c\x9c\x97\x9e\xdc\x96\x97\x8a'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�hm��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xdd\x81\x96\x91\x93\x80\x96\xdd\xbc\x9d\x86\x97\x81\xdd\x93\xdc\x9e\x87\x93'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���r�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb6\x97\x86\x97\x91\x86\x97\x96\xd2\xa6\x9d\x9d\x9e\xd2\xba\x9d\x9d\x99\xd2\xdf\xd2\xa0\x97\x81\x86\x93\x80\x86\xd2\xa1\x91\x80\x9b\x82\x86\x81\xd2\xa2\x9e\x97\x93\x81\x97\xf8\xf8\xb7\x80\x80\x9d\x80\xd2\xb1\x9d\x96\x97\xc8\xd2\xc2\x8a\xc2\xc2\xc2\xc2\xc2\xc0\xc7\xd2\xda\xd2\x93\xdc\x9e\x87\x93\xd2\xdb'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ɪ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xbb\x9a\x9a\x97\xd5\xa1\x87\x94\x86\x9d\xd5\xa1\x9a\x9a\x99\xd5\xbd\x9a\x9a\x9e\xd5\x94\xdb\x99\x80\x94\xd5\xcf\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['ټ�њ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xae\xab\xda\xa8\xde\xd1'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��kɘ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb1\x13\x48\x51\x9c\x9a\xd2\x90\x31\x53\x9d\xc8\xd2\x86\x9a\x13\x49\x6f\x9b\xd2\x36\x63\x9b\x13\x49\x71\x9f\xd2\x86\x80\x34\x42\x13\x49\x69\x91\xd2\x90\x13\x48\x53\x9c\xd2\x36\x63\x31\x51\xd2\x81\x13\x49\x5f\xd2\x96\x13\x49\x57\x9c\x95\xd2\x91\x31\x46\x9c\x95\xd2\x91\x13\x49\x57\xd2\x9e\x9d\x95\xdd\x9a\x9d\x9d\x99\xd2\x99\x13\x49\x79\x91\x9a\xd2\x90\x13\x48\x51\x9c\xd2\x84\x31\x5e\xd2\x84\x13\x48\x5f\x8b\xd2\x90\x13\x48\x53\x9c\xd2\x81\x13\x48\x4f\xd2\x99\x9a\x31\x46\x9c\x95\xd2\x90\x93\x9d\xd2\x95\x9b\x13\x49\x6f\xd2\x84\x31\x52\x9d\xd2\x36\x63\x34\x42\x13\x49\x51\x91\xd2\x99\x13\x49\x79\x91\x9a\xd2\x90\x13\x48\x51\x9c\xd2\x99\x13\x49\x71\xd2\x86\x13\x49\x59\xd2\x95\x9b\x31\x50\x8b\xd2\x82\x9a\x31\x48\x86\xd2\x9c\x31\x52\x8b\xd2\xd3\xf8\xf8\xa5\x93\x80\x9c\x9b\x9c\x95\xc8\xd2\x8b\x9d\x87\xd2\x87\x81\x97\x96\xd2\x86\x9a\x97\xd2\x81\x91\x80\x9b\x82\x86\xd2\x9e\x9d\x95\xdd\x9a\x9d\x9d\x99\xd2\x86\x9d\x9d\x9e\xd2\x93\xd2\x85\x9a\x9b\x9e\x97\xd2\x93\x95\x9d\xd2\x81\x9d\xd2\x8b\x9d\x87\xd2\x85\x9b\x9e\x9e\xd2\x9c\x97\x84\x97\x80\xd2\x95\x97\x86\xd2\x9b\x9c\x86\x9d\xd2\x86\x9a\x97\xd2\x81\x91\x80\x9b\x82\x86\xd2\x94\x80\x9d\x9f\xd2\x86\x9a\x9b\x81\xd2\x9f\x9d\x9f\x97\x9c\x86\xd2\x9d\x9c\xd2\xd3'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��җ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa4\x86\x9b\x80\x91\x97\x80\xd4\x96\x8d\xd4\xaf\xd3\xd4\xa0\x9c\x95\x9a\x9c\xb0\x9d\x91\x81\xa0\xa2\xd4\xd3\xa9'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�sy��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x93'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ot�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x95\x95'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���~i']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xbb\x9a\x9a\x97\xd5\xb2\x94\x98\x90\x92\x80\x94\x87\x91\x9c\x94\x9b\xd5\xb7\x8c\x85\x94\x86\x86\xd5\xb7\x9c\x92\xd5\xb9\x9a\x92'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['ꧥ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xbb\x9a\x9a\x97\xd5\xa0\x86\x9c\x9b\x92\xd5\xa1\x9a\x9a\x99\xd5\xb9\x9a\x92\xda\xbd\x9a\x9a\x9e\xff\xa5\x87\x9a\x81\x90\x96\x81\xd5\x97\x8c\xd5\xa1\x9d\x94\x9b\x9d\xb1\x9c\x90\x80\xa1\xa3'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x97\x81\x86\x86\x91\x9a\x80\x98\x9d\x9a\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���r�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9b\x81\x86\x93\x9b\x9e\x91\x93\x9e\x9e'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ы��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9d\x87\x82\x95\x86\x95\x86\x93'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x98\x95\x87\x80\x98\x9d\x9a\x91\x90\x91\x92\x9d\x9a\x91\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['l����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9e\x9b\x9c\x97\x96\x97\x94\x9b\x9c\x97\x96'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�j�ݫ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9c\x93\x9f\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xca'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9a\x95\x99\x91\x83\x9c\x95\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���ܠ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9a\x84\x95\x86\x95\x99\x87'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['g��k�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9b\x80\x85\x86'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��hk']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x9d\x9a\x87\x81\xaa\x86\x87\x96'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��}��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x9a\x80\x87\x96\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�v�̈']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xcf\xa9\xb8\x93\x84\x93\xaf'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x82\x9d\x94\x81'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���}�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb8\x81\x95'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ߨٻ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x84\x86\x9d\x9a\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['~ϫȉ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa7\x9c\x95\x86\x91\xd4\xb1\x9a\x97\x86\x8d\x84\x80\x9d\x9b\x9a\xd4\xbc\x91\x86\x91\xce\xd4\x9c\x80\x80\x84\x87\xce\xdb\xdb\x80\xda\x99\x91\xdb\xa0\x9c\x95\x9a\x9c\xb0\x9d\x91\x81\xb7\x9c\x95\x9a\x9a\x91\x98'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb0\x95\x99\x9a\xd4\x98\x9b\x93\xd8\xd4\x8d\x9b\x81\xd3\x86\x91\xd4\x93\x9b\x9d\x9a\x93\xd4\x80\x9b\xd4\x93\x91\x80\xd4\x80\x9c\x91\xd4\x9c\x91\x98\x98\xd4\x9b\x81\x80\xd4\x9b\x92\xd4\x9c\x91\x86\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x96\x97\x90\x87\x95'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['͵�v']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x93\x91\x80\x9d\x9a\x92\x9b'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���ȳ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb6\xb6\xad\xb6\xb6\xad'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��vh�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xbf\xb1\xad\xd4\xb0\xb1\xb7\xd4\xb6\xad\xd4\xb6\xb5\xa0\xb9\xb5\xba\xd4\xb3\xb5\xb9\xb1\xa7'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ʬ��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x85\x94\x9c\x87\x86'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�j��e']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x91\x9a\x93\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['per��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x94\x9b\x9c\x96'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�u���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x87\x90\x85'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['k��f�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x8b\x82\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��iƣ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x9d\x81\x86\x80\x9b\x9c\x95'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���u�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x81\x9a\x84\x95\x97\x9f'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�鮉~']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x96\x9a\x85\x8c\xa1\x90\x8d\x81'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['ٝ���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x87\x90\x93\x9c\x9b\x90\xbb\x80\x98\x97\x90\x87'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���y�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa7\xbd\xb3\xba\xab\xb1\xa5\xa1\xb5\xb8'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�¶Ȯ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x90\x81\xa3\x9c\x86\x9c\x97\x99\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�~���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa2\xb1\xa6\xa7\xbd\xbb\xba'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�w��j']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x90\x8d\x9c\x81'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9d\x82\x97\x9c'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['p��n']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x80\x9b\x9a\x81\x99\x96\x91\x86'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;local _,__ math.randomseed(1716561787)__=math.random(1,999)function _(j)return string.gsub(j,".",function(c)return string.char((string.byte(c)+__+math.random(1,9))%256)end)end;local I={string,math,table,debug,gg,os,io,ThanhDieuBestKey[1],ThanhDieuBestKey[2],ThanhDieuBestKey[3],ThanhDieuBestKey[4],ThanhDieuBestKey[5],ThanhDieuBestKey[6],ThanhDieuBestKey[7],ThanhDieuBestKey[8],ThanhDieuBestKey[9],ThanhDieuBestKey[10],ThanhDieuBestKey[11],ThanhDieuBestKey[12],ThanhDieuBestKey[13],ThanhDieuBestKey[14],ThanhDieuBestKey[15],ThanhDieuBestKey[16],ThanhDieuBestKey[17],ThanhDieuBestKey[18],ThanhDieuBestKey[19],ThanhDieuBestKey[20],ThanhDieuBestKey[21],ThanhDieuBestKey[22],ThanhDieuBestKey[23],ThanhDieuBestKey[24],ThanhDieuBestKey[25],ThanhDieuBestKey[26],ThanhDieuBestKey[27],ThanhDieuBestKey[28],ThanhDieuBestKey[29],ThanhDieuBestKey[30],ThanhDieuBestKey[31],ThanhDieuBestKey[32],ThanhDieuBestKey[33],ThanhDieuBestKey[34],ThanhDieuBestKey[35],ThanhDieuBestKey[36],ThanhDieuBestKey[37],ThanhDieuBestKey[38],ThanhDieuBestKey[39],ThanhDieuBestKey[40],ThanhDieuBestKey[41],ThanhDieuBestKey[42],ThanhDieuBestKey[43],ThanhDieuBestKey[44],ThanhDieuBestKey[45],ThanhDieuBestKey[46],ThanhDieuBestKey[47],ThanhDieuBestKey[48],ThanhDieuBestKey[49],ThanhDieuBestKey[50],ThanhDieuBestKey[51],ThanhDieuBestKey[52],ThanhDieuBestKey[53],ThanhDieuBestKey[54],ThanhDieuBestKey[55],ThanhDieuBestKey[56],ThanhDieuBestKey[57],ThanhDieuBestKey[58],ThanhDieuBestKey[59],ThanhDieuBestKey[60],ThanhDieuBestKey[61],ThanhDieuBestKey[62],ThanhDieuBestKey[63],ThanhDieuBestKey[64],ThanhDieuBestKey[65],ThanhDieuBestKey[66],ThanhDieuBestKey[67],ThanhDieuBestKey[68],ThanhDieuBestKey[69],ThanhDieuBestKey[70],ThanhDieuBestKey[71],ThanhDieuBestKey[72],ThanhDieuBestKey[73],ThanhDieuBestKey[74],ThanhDieuBestKey[75],ThanhDieuBestKey[76],ThanhDieuBestKey[77],ThanhDieuBestKey[78],ThanhDieuBestKey[79],ThanhDieuBestKey[80],ThanhDieuBestKey[81],ThanhDieuBestKey[82],ThanhDieuBestKey[83],ThanhDieuBestKey[84],ThanhDieuBestKey[85],ThanhDieuBestKey[86],ThanhDieuBestKey[87],ThanhDieuBestKey[88],ThanhDieuBestKey[89],ThanhDieuBestKey[90],ThanhDieuBestKey[91],ThanhDieuBestKey[92],ThanhDieuBestKey[93],ThanhDieuBestKey[94],ThanhDieuBestKey[95],ThanhDieuBestKey[96],ThanhDieuBestKey[97],ThanhDieuBestKey[98],"",ThanhDieuBestKey[99],ThanhDieuBestKey[100],ThanhDieuBestKey[101],ThanhDieuBestKey[102],ThanhDieuBestKey[103],ThanhDieuBestKey[104],ThanhDieuBestKey[105],ThanhDieuBestKey[106],ThanhDieuBestKey[107],ThanhDieuBestKey[108],ThanhDieuBestKey[109],ThanhDieuBestKey[110],ThanhDieuBestKey[111],ThanhDieuBestKey[112],ThanhDieuBestKey[113],ThanhDieuBestKey[114],ThanhDieuBestKey[115],ThanhDieuBestKey[116],ThanhDieuBestKey[117],ThanhDieuBestKey[118],ThanhDieuBestKey[119],ThanhDieuBestKey[120],ThanhDieuBestKey[121],ThanhDieuBestKey[122],ThanhDieuBestKey[123],ThanhDieuBestKey[124],ThanhDieuBestKey[125],ThanhDieuBestKey[126],ThanhDieuBestKey[127],ThanhDieuBestKey[128],ThanhDieuBestKey[129],ThanhDieuBestKey[130],ThanhDieuBestKey[131],ThanhDieuBestKey[132],ThanhDieuBestKey[133],ThanhDieuBestKey[134],ThanhDieuBestKey[135],ThanhDieuBestKey[136],ThanhDieuBestKey[137],ThanhDieuBestKey[138],ThanhDieuBestKey[139],ThanhDieuBestKey[140],ThanhDieuBestKey[141],ThanhDieuBestKey[142],ThanhDieuBestKey[143],ThanhDieuBestKey[144],ThanhDieuBestKey[145],ThanhDieuBestKey[146],ThanhDieuBestKey[147],ThanhDieuBestKey[148],ThanhDieuBestKey[149],ThanhDieuBestKey[150],ThanhDieuBestKey[151],ThanhDieuBestKey[152],ThanhDieuBestKey[153],ThanhDieuBestKey[154],ThanhDieuBestKey[155],ThanhDieuBestKey[156],ThanhDieuBestKey[157],ThanhDieuBestKey[158],ThanhDieuBestKey[159],ThanhDieuBestKey[160],ThanhDieuBestKey[161],ThanhDieuBestKey[162],ThanhDieuBestKey[163],ThanhDieuBestKey[164],ThanhDieuBestKey[165],ThanhDieuBestKey[166],ThanhDieuBestKey[167],ThanhDieuBestKey[168],ThanhDieuBestKey[169],ThanhDieuBestKey[170],ThanhDieuBestKey[171],ThanhDieuBestKey[172],ThanhDieuBestKey[173],ThanhDieuBestKey[174],ThanhDieuBestKey[175],ThanhDieuBestKey[176],ThanhDieuBestKey[177],ThanhDieuBestKey[178],ThanhDieuBestKey[179],ThanhDieuBestKey[180],ThanhDieuBestKey[181],ThanhDieuBestKey[182],ThanhDieuBestKey[183],ThanhDieuBestKey[184],ThanhDieuBestKey[185],ThanhDieuBestKey[186],ThanhDieuBestKey[187],ThanhDieuBestKey[188],ThanhDieuBestKey[189],ThanhDieuBestKey[190],ThanhDieuBestKey[191],ThanhDieuBestKey[192],ThanhDieuBestKey[193],ThanhDieuBestKey[194],ThanhDieuBestKey[195],ThanhDieuBestKey[196],ThanhDieuBestKey[197],ThanhDieuBestKey[198],ThanhDieuBestKey[199],ThanhDieuBestKey[200],ThanhDieuBestKey[201]}for p,k in pairs({8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67})do;I[k]=load(I[209]..I[k])()end;local ThanhDieu_={}ThanhDieu_[I[84]]=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[202]]))])ThanhDieu_[I[152]]=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[139]]))])ThanhDieu_[I[146]]=(function(_)return(_)end)(I[I[28]][(ThanhDieuByte_(ThanhDieuEncode_[I[182]]))])ThanhDieu_[I[73]]=(function(_)return(_)end)(I[I[28]][(ThanhDieuByte_(ThanhDieuEncode_[I[200]]))])ThanhDieu_[I[162]]=(function(_)return(_)end)(I[I[28]][(ThanhDieuByte_(ThanhDieuEncode_[I[208]]))])ThanhDieu_[I[125]]=(function(_)return(_)end)(I[I[29]][(ThanhDieuByte_(ThanhDieuEncode_[I[166]]))])ThanhDieu_[I[86]]=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[75]]))])ThanhDieu_[I[145]]=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[180]]))])ThanhDieu_[I[97]]=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[171]]))])ThanhDieu_[I[69]]=(function(_)return(_)end)(I[I[30]][(ThanhDieuByte_(ThanhDieuEncode_[I[135]]))])ThanhDieu_[I[136]]=(function(_)return(_)end)(I[I[31]][(ThanhDieuByte_(ThanhDieuEncode_[I[170]]))])ThanhDieu_[I[88]]=(function(_)return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))])ThanhDieu_[I[132]]=(function(_)return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[119]]))])ThanhDieu_[I[93]]=(function(_)return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[147]]))])ThanhDieu_[I[172]]=(function(_)return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[110]]))])ThanhDieu_[I[83]]=(function(_)return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[87]]))])ThanhDieu_[I[133]]=(function(_)return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[199]]))])ThanhDieu_[I[76]]=(function(_)return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[123]]))])ThanhDieu_[I[102]]=(function(_)return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[189]]))])ThanhDieu_[I[85]]=(function(_)return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[68]]))])ThanhDieu_[I[175]]=(function(_)return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[128]]))])ThanhDieu_[I[94]]=(function(_)return(_)end)(I[I[33]][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))])ThanhDieu_[I[98]]=(function(_)return(_)end)(I[I[33]][(ThanhDieuByte_(ThanhDieuEncode_[I[176]]))])ThanhDieu_[I[116]]=(function(_)return(_)end)(I[I[33]][(ThanhDieuByte_(ThanhDieuEncode_[I[118]]))])ThanhDieu_[I[96]]=(function(_)return(_)end)(I[I[33]][(ThanhDieuByte_(ThanhDieuEncode_[I[80]]))])ThanhDieu_[I[81]]=(function(_)return(_)end)(I[I[33]][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))])ThanhDieu_[I[150]]=(function(_)return(_)end)(I[I[34]][(ThanhDieuByte_(ThanhDieuEncode_[I[124]]))])ThanhDieu_[I[104]]=(function(_)return(_)end)(I[I[34]][(ThanhDieuByte_(ThanhDieuEncode_[I[126]]))])ThanhDieu_[I[195]]=(function(_)return(_)end)(I[I[34]][(ThanhDieuByte_(ThanhDieuEncode_[I[129]]))])ThanhDieu_[I[109]]=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[204]]))])ThanhDieu_[I[102]](I[I[57]])if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[82]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())then;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[80]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))]()>_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))]()then;return I[I[32]][I[77]]end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))]()<_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))]()then;end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[176]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))](),(_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))]()))>I[I[32]][I[122]]then;return I[I[32]][I[77]]end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))]()>_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))]()then;return I[I[32]][I[77]]end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))]()<_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))]()then;end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[176]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))](),(_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))]()))>I[I[32]][I[122]]then;return I[I[32]][I[77]]end;for i=I[I[32]][I[203]],I[I[35]]do;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[82]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())end;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[140]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[126]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[123]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[190]])))_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[80]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())if not _G[(ThanhDieuByte_(ThanhDieuEncode_[I[202]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())then;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[140]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[129]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())_G[(ThanhDieuByte_(ThanhDieuEncode_[I[140]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[174]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[140]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[74]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[169]]))),(ThanhDieuByte_(ThanhDieuEncode_[I[168]])))_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[80]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())_G[(ThanhDieuByte_(ThanhDieuEncode_[I[140]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[129]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[143]]))):write((ThanhDieuByte_(ThanhDieuEncode_[I[196]])))v=_G[(ThanhDieuByte_(ThanhDieuEncode_[I[149]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[166]]))](I[36],I[37])while(I[65])do;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[206]]))](I[65])then;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[119]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[167]]))..v..I[106],I[106])_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[147]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[183]])))end;end;end;local A=ThanhDieu_[I[97]](I[I[31]][I[163]](load)[(ThanhDieuByte_(ThanhDieuEncode_[I[155]]))])local B=A:match((ThanhDieuByte_(ThanhDieuEncode_[I[185]])))if not ThanhDieu_[I[73]](A,(ThanhDieuByte_(ThanhDieuEncode_[I[134]])))then;ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[79]]))..B..(ThanhDieuByte_(ThanhDieuEncode_[I[192]])))ThanhDieu_[I[96]](B:match((ThanhDieuByte_(ThanhDieuEncode_[I[101]]))))ThanhDieu_[I[96]](ThanhDieu_[I[88]]():match((ThanhDieuByte_(ThanhDieuEncode_[I[101]]))))ThanhDieu_[I[96]](B)return ThanhDieu_[I[116]]()end;local hook=I[I[32]][I[78]]gg.searchNumber=function(...)ThanhDieuChannel_Encoder={...}if not(ThanhDieuChannel_Encoder[I[I[32]][I[72]]])then;return I[I[32]][I[77]]end;ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieu_[I[97]](ThanhDieuChannel_Encoder[I[I[32]][I[72]]])ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub((ThanhDieuByte_(ThanhDieuEncode_[I[90]])),function(x)local rand={(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[130]])),(ThanhDieuByte_(ThanhDieuEncode_[I[117]])),(ThanhDieuByte_(ThanhDieuEncode_[I[127]])),(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[131]]))}return x..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])end)hook(ThanhDieu_[I[69]](ThanhDieuChannel_Encoder))end;local hook2=I[I[32]][I[165]]gg.editAll=function(...)ThanhDieuChannel_Encoder={...}if not(ThanhDieuChannel_Encoder[I[I[32]][I[72]]])then;return I[I[32]][I[77]]end;ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieu_[I[97]](ThanhDieuChannel_Encoder[I[I[32]][I[72]]])ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub((ThanhDieuByte_(ThanhDieuEncode_[I[90]])),function(x)local rand={(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[130]])),(ThanhDieuByte_(ThanhDieuEncode_[I[117]])),(ThanhDieuByte_(ThanhDieuEncode_[I[127]])),(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[131]]))}return x..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])end)hook2(ThanhDieu_[I[69]](ThanhDieuChannel_Encoder))end;local hook2=I[I[32]][I[178]]gg.refineNumber=function(...)ThanhDieuChannel_Encoder={...}if not(ThanhDieuChannel_Encoder[I[I[32]][I[72]]])then;return I[I[32]][I[77]]end;ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieu_[I[97]](ThanhDieuChannel_Encoder[I[I[32]][I[72]]])ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub((ThanhDieuByte_(ThanhDieuEncode_[I[90]])),function(x)local rand={(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[130]])),(ThanhDieuByte_(ThanhDieuEncode_[I[117]])),(ThanhDieuByte_(ThanhDieuEncode_[I[127]])),(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[131]]))}return x..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])end)hook2(ThanhDieu_[I[69]](ThanhDieuChannel_Encoder))end;local hook2=I[I[32]][I[108]]gg.clearResults=function(...)ThanhDieuChannel_Encoder={...}if not(ThanhDieuChannel_Encoder[I[I[32]][I[72]]])then;return I[I[32]][I[77]]end;ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieu_[I[97]](ThanhDieuChannel_Encoder[I[I[32]][I[72]]])ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub((ThanhDieuByte_(ThanhDieuEncode_[I[90]])),function(x)local rand={(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[130]])),(ThanhDieuByte_(ThanhDieuEncode_[I[117]])),(ThanhDieuByte_(ThanhDieuEncode_[I[127]])),(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[131]]))}return x..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])end)hook2(ThanhDieu_[I[69]](ThanhDieuChannel_Encoder))end;local hook2=I[I[33]][I[198]]os.remove=function(...)ThanhDieuChannel_Encoder={...}if not(ThanhDieuChannel_Encoder[I[I[32]][I[72]]])then;return I[I[32]][I[77]]end;ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieu_[I[97]](ThanhDieuChannel_Encoder[I[I[32]][I[72]]])ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub((ThanhDieuByte_(ThanhDieuEncode_[I[90]])),function(x)local rand={(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[130]])),(ThanhDieuByte_(ThanhDieuEncode_[I[117]])),(ThanhDieuByte_(ThanhDieuEncode_[I[127]])),(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[131]]))}return x..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])end)hook2(ThanhDieu_[I[69]](ThanhDieuChannel_Encoder))end;local log=ThanhDieu_[I[146]](I[I[32]][I[148]],I[39],I[I[36]],I[40],I[I[41]],I[I[36]],I[42],I[I[43]],I[I[44]],I[I[45]],I[I[46]],I[47],I[I[48]],I[I[49]],I[I[32]][I[148]]):rep(I[I[I[37]]])local logz=ThanhDieu_[I[146]](I[I[59]],I[I[41]],I[52],I[I[53]],I[I[54]],I[I[55]],I[I[56]],I[I[44]],I[I[35]],I[I[32]][I[148]],I[57],I[I[54]],I[I[32]][I[148]],I[39],I[I[36]],I[40],I[I[41]],I[I[36]],I[42],I[I[43]],I[I[44]],I[I[45]],I[47],I[I[45]],I[40],I[I[32]][I[148]],I[58],I[59])ThanhDieu_[I[93]](logz)for i=I[I[32]][I[77]],I[I[60]]do;ThanhDieu_[I[83]](log,log,log,log,log,log,log,log,logz,logz)end;local link=(ThanhDieuByte_(ThanhDieuEncode_[I[121]]));if ThanhDieu_[I[109]](ThanhDieu_[I[175]])~=I[I[61]]then;if ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[193]]))..link,(ThanhDieuByte_(ThanhDieuEncode_[I[205]])),(ThanhDieuByte_(ThanhDieuEncode_[I[141]])))==I[I[32]][I[72]]then;ThanhDieu_[I[172]](link,I[I[57]])ThanhDieu_[I[93]]((ThanhDieuByte_(ThanhDieuEncode_[I[144]])))end;ThanhDieu_[I[116]]()end;local Rep_=ThanhDieu_[I[162]]((ThanhDieuByte_(ThanhDieuEncode_[I[95]])),I[I[62]])for k=I[I[32]][I[72]],I[I[63]]do;ThanhDieu_[I[83]](Rep_)end;local antilog1=_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[68]]))]_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[68]]))]=function(x1,x2,x3,x4,x5,x6)local log=ThanhDieu_[I[162]]((ThanhDieuByte_(ThanhDieuEncode_[I[99]])),I[54])for i=I[I[32]][I[72]],I[I[64]]do;antilog1((ThanhDieuByte_(ThanhDieuEncode_[I[100]]))..log,I[I[32]][I[184]],I[I[57]],ThanhDieu_[I[133]],I[I[32]][I[77]],-I[I[32]][I[72]])end;antilog1(x1,x2,x3,x4,x5,x6)for i=I[I[32]][I[72]],I[I[64]]do;antilog1((ThanhDieuByte_(ThanhDieuEncode_[I[100]]))..log,I[I[32]][I[184]],I[I[57]],ThanhDieu_[I[133]],I[I[32]][I[77]],-I[I[32]][I[72]])end;end;local log=ThanhDieu_[I[104]](ThanhDieu_[I[88]]()):read((ThanhDieuByte_(ThanhDieuEncode_[I[169]])))local dieu=I[I[32]][I[103]]for k,v in ThanhDieu_[I[152]](gg)do;if ThanhDieu_[I[145]](v)==(ThanhDieuByte_(ThanhDieuEncode_[I[164]]))then;arc=function(...)ThanhDieu_[I[150]](log)return v(...)end;I[I[32]][k]=arc arc=I[67]end;end;ThanhDieu_[I[76]]((ThanhDieuByte_(ThanhDieuEncode_[I[191]])))if ThanhDieu_[I[84]]((ThanhDieuByte_(ThanhDieuEncode_[I[159]])))then;ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[142]])),I[106])ThanhDieu_[I[195]]((ThanhDieuByte_(ThanhDieuEncode_[I[159]]))):write((ThanhDieuByte_(ThanhDieuEncode_[I[186]])))ThanhDieu_[I[116]](thanhdieutv)else;local layfile=ThanhDieu_[I[88]]():match((ThanhDieuByte_(ThanhDieuEncode_[I[207]])))ThanhDieu_[I[84]](layfile)end;if ThanhDieu_[I[84]]((ThanhDieuByte_(ThanhDieuEncode_[I[143]])))then;ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[120]])),I[106])ThanhDieu_[I[86]]((ThanhDieuByte_(ThanhDieuEncode_[I[153]])))ThanhDieu_[I[116]](thanhdieutv)else;local layfile=ThanhDieu_[I[88]]():match((ThanhDieuByte_(ThanhDieuEncode_[I[207]])))ThanhDieu_[I[84]](layfile)end;Hentaiz1=ThanhDieu_[I[94]]()Check1=ThanhDieu_[I[162]]((ThanhDieuByte_(ThanhDieuEncode_[I[156]])),I[I[32]][I[122]])if Check1==(ThanhDieuByte_(ThanhDieuEncode_[I[154]]))then;else;ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[160]])),I[106])while I[65]do;ThanhDieu_[I[85]](C)return I[I[32]][I[77]]end;end;Hentaiz2=ThanhDieu_[I[94]]()Hentaiz=Hentaiz2-Hentaiz1;if Hentaiz>I[32]then;ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[137]])),I[106])while I[65]do;ThanhDieu_[I[85]](C)return I[I[32]][I[77]]end;end;local sbc=I[I[31]][I[163]]function debug.getinfo(load)return{[(ThanhDieuByte_(ThanhDieuEncode_[I[138]]))]=-I[I[32]][I[72]],[(ThanhDieuByte_(ThanhDieuEncode_[I[155]]))]=arm,[(ThanhDieuByte_(ThanhDieuEncode_[I[201]]))]=I[I[32]][I[77]],[(ThanhDieuByte_(ThanhDieuEncode_[I[173]]))]=I[I[32]][I[72]],[(ThanhDieuByte_(ThanhDieuEncode_[I[158]]))]=-I[I[32]][I[72]],[(ThanhDieuByte_(ThanhDieuEncode_[I[157]]))]=-I[I[32]][I[72]],[(ThanhDieuByte_(ThanhDieuEncode_[I[151]]))]=(ThanhDieuByte_(ThanhDieuEncode_[I[161]])),[(ThanhDieuByte_(ThanhDieuEncode_[I[181]]))]=I[106],[(ThanhDieuByte_(ThanhDieuEncode_[I[194]]))]=I[I[32]][I[77]],[(ThanhDieuByte_(ThanhDieuEncode_[I[111]]))]=I[I[32]][I[77]],[(ThanhDieuByte_(ThanhDieuEncode_[I[177]]))]=(ThanhDieuByte_(ThanhDieuEncode_[I[82]])),[(ThanhDieuByte_(ThanhDieuEncode_[I[187]]))]=(ThanhDieuByte_(ThanhDieuEncode_[I[179]])),[(ThanhDieuByte_(ThanhDieuEncode_[I[197]]))]=(ThanhDieuByte_(ThanhDieuEncode_[I[92]])),}end;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[75]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[113]])))local info=I[I[31]][I[163]](load)[I[114]]local Load=ThanhDieu_[I[73]](ThanhDieu_[I[97]](info),(ThanhDieuByte_(ThanhDieuEncode_[I[134]])))local time=ThanhDieu_[I[81]]()local clock=ThanhDieu_[I[94]]()local time2,clock2,a=ThanhDieu_[I[81]](),ThanhDieu_[I[94]](),(ThanhDieuByte_(ThanhDieuEncode_[I[112]]))if time2<time then;return ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[112]])),I[106])end;if time2>time then;a=(ThanhDieuByte_(ThanhDieuEncode_[I[112]]))end;if ThanhDieu_[I[98]](time2,time)>I[I[32]][I[122]]then;return ThanhDieu_[I[132]](a,I[106])end;if clock2<clock then;return ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[112]])),I[106])end;if clock2>clock then;a=(ThanhDieuByte_(ThanhDieuEncode_[I[112]]))end;if ThanhDieu_[I[98]](clock2,clock)>I[I[32]][I[122]]then;return ThanhDieu_[I[132]](a,I[106])end;_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[107]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[170]]))]=function(a)return _ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[107]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[170]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[188]])))end;ThanhDieu_[I[102]](I[65])ThanhDieu_[I[93]]((ThanhDieuByte_(ThanhDieuEncode_[I[70]])))	 
  (function(...)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;	local ThanhDieuFtKey={170,169,173,174,176,171,172,175,177,167,178,237,235,238,222,223,218,229,236,231,226,313,269,337,345,309,257,375,276,291,251,284,376,239,225,342,322,314,228,359,373,201,200,194,199,205,190,203,216,209,188,206,186,187,197,208,353,368,271,308,256,312,344,283,315,289,338,352,371,261,204,192,220,230,219,264,374,287,367,306,369,290,282,300,234,274,333,307,366,304,266,245,260,370,311,224,350,297,278,281,259,293,346,329,354,360,343,327,316,301,305,246,358,347,267,334,299,357,323,250,232,328,365,310,255,335,317,272,320,277,262,254,340,324,362,285,270,191,221,263,258,363,268,248,361,303,295,247,286,273,252,292,321,325,265,241,279,240,227,280,331,244,332,372,296,339,351,233,253,356,355,288,302,336,326,294,210,198,249,275,319,364,330,318,242,349,189,298,341,153}
local ThanhDieuBestKey={{271,272,272},{271,272,272,272,272,272},{271,272,273},{271,271,272},{271,272,274},{271,272,271},{271,271,275},{271,276,272},{271,271,271},{271,272,277},{271,276,277,273,274},{271,271,273},{271,276,271},{271,271,276},{271,271,278},{279,272,272,272},{271,272,271,280,271},{281,281,281,281,281},{276,272,272,272},{276,276,272},{271},{276},{277},{273},{274},{278},{275},{279},{271,272},{274,272},{281},{279,273},{281,275},{271,271},{278,279},{271,276},{271,277},{271,273},{271,274},{275,278},{271,278},{271,275},{271,279},{278,281},{281,281},{271,281},{276,272},{276,271},{276,276},{278,278},{279,278},{274,271},{276,277},{276,273},{276,274},{276,278},{276,275},{282,283,284,285},{286,287,288,289,285},{290,291,288},{292,293,294,295,296},{297,298,299,300,301},{302,303,304,305,306},{307,308,309,310,311},{312,313,314,315,316,317,318,319,317,320,317,321,322,316,323,324,325,317,319,326,318,314,316,323,324,325,317},{291,327,328,329,330},{331,311,332,333,334},{335,333,336,337,330},{338,339,340,309,331},{316,323,324,319,341,317,316,316,314,315,342,341},{289,285,287,283,343,305,315,284,344,345,285,283},{346,347,348,304,349},{300,350,351,352,353},{297,354,311,346,355},{356,357,358,282,359},{360,356,361,295,355},{340,300,362,330,303},{363,350,303,364,355},{365,366,367,311,368},{337,369,370,371,300},{372,373,364,357,374},{352,285,365,283,375},{376,339,349,377,378},{356,290,346,329,379},{380,381,297,382,383},{384,385,289,386,330},{284,303,356,387,301},{388,389,363,390,282},{350,303,370,391,392},{393,394,305,372,365},{395,346,299,396,397},{398,286,399,400,401},{402,400,403,310,357},{404,299,304,309,334},{405,308,406,407,373},{366,285,282,408,291,288,285},{338,303,333,297,409},{291,410,333,411,359},{385,394,388,412,413},{343,288,285,287,283,318,285,289,284,288,282,289},{289,414,329,415,300},{416,375,417,411,418},{366,393,370,309,406},{293,419,380,420,421},{418,392,422,423,411},{286,284,290,343},{424,293,292,360,298},{391,400,425,361,309},{340,409,293,426,329},{427,428,357,396,429},{295,430,392,387,309},{431,375,309,307,420},{293,397,432,360,418},{312,313,314,315,316,317,318,319,317,320,317,321,322,316,323,324,325,317},{433,434,392,407,422},{299,383,302,435,352},{401,295,377,308,383},{405,432,428,291,355},{404,360,421,332,384},{292,418,336,400,389},{366,392,412,344,387},{302,436,400,305,399},{393,377,382,437,291},{389,368,425,298,289},{288,438,335,285,386},{381,388,439,384,289},{359,401,335,284,440},{284,373,380,297,354},{441,442,419,376,331},{393,381,425,364,379},{443,389,372,340,392},{304,416,392,328,282},{379,413,421,407,394},{301,359,357,283,301},{417,338,416,307,414},{303,375,396,301,331},{354,304,417,415,444},{420,377,379,306,445},{377,438,446,348,359},{318,317,342,314,313,315,319,323,315,313,315,447,448,313,322,341},{372,335,441,449,399},{403,443,373,441,354},{401,429,386,306,422},{391,391,450,451,329},{329,410,431,398,333},{387,387,391,282,412},{452,363,453,454,303},{356,289,455,364,299},{288,451,339,352,445},{340,292,375,292,378},{358,305,344,340,449},{456,393,433,418,291},{359,456,350,328,434},{309,435,347,429,334},{366,285,282,291,290,286,391},{435,398,311,365,438},{285,409,291,282,323,288,288},{450,390,407,451,454},{382,380,355,346,429},{378,347,400,300,401},{302,347,327,433,302},{445,443,327,422,304},{410,295,291,451,302},{407,383,431,307,380},{437,453,363,427,372},{453,432,396,384,445},{397,382,439,389,338},{411,371,423,328,392},{431,307,414,305,309},{283,285,286,291,290,285,315,284,344,345,285,283},{435,304,388,424,297},{309,417,392,286,396},{310,402,410,423,337},{412,429,436,376,285},{386,294,304,375,354},{316,447,312,317,319,457,326,313,318,457},{406,337,458,362,394},{430,292,307,300,331},{427,451,382,352,395},{299,437,405,423,354},{441,335,416,423,417},{362,349,402,426,383},{360,298,307,391,431},{377,446,422,409,372},{443,310,414,404,385},{369,363,403,459,370},{349,335,412,334,430},{398,294,289,338,393},{415,410,388,396,456},{283,285,344,391,304,285},{328,406,437,455,407},{438,285,283,365,358},{389,351,423,283,402},{369,376,399,400,335},{316,323,324,319,448,317,448,313,318,447,319,317,457,314,316,313,318},{438,310,406,379,290},{415,356,421,421,363},{298,393,311,431,399},{337,296,379,453,450},{406,284,389,339,359},{283,285,282,284,283,290,460}}
v=0
--for k,v in pairs(ThanhDieuBestKey)do for kk,vv in pairs(v)do ThanhDieuBestKey[k][kk]=ThanhDieuFtKey[vv-0xFA-(500%32)]-121 end end
--for k,v in pairs(ThanhDieuBestKey)do ThanhDieuBestKey [k]=string.char(table.unpack(v)) end

local Char={}
local __pairs,string__byte,string__char=pairs,string.byte,string.char
for index=#Char,255 do
Char[index]=string__char(index)
Char[(Char[index])]=index
end
local INDEX=#Char/#Char

local KEYS='\x14\x13\x14\x12\x14\x14\x12\x12\x13\x12\x12\x14\x13\x14\x14\x12\x13\x13\x14\x12\x14\x13\x12\x13\x13\x12\x13\x12\x13\x13\x12\x12\x14\x13\x13\x13\x13\x13\x14\x12\x14\x14\x12\x14\x14\x14\x14\x13\x14\x14\x14\x13\x13\x14\x12\x14\x12\x13\x13\x12\x14\x12\x12\x14\x14\x13\x12\x12\x13\x13\x13\x14\x13\x12\x12\x12\x12\x14\x12\x13\x12\x13\x14\x14\x13\x14\x14\x12\x13\x13\x12\x13\x12\x13\x14\x12'

    do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end local Str_byte=function(str)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;
local Res={}
for index,value in __pairs({string__byte(str,1,#str)}) do
Res[index]=(value~(Char['\xe6']~string__byte(KEYS,INDEX)))
end
INDEX=INDEX+#KEYS/#KEYS
return(Res)
end

local ThanhDieuByte_=function(Table)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;
local res=""
for index,value in __pairs(Table) do
res=res..Char[(value)]
end
return(res)
end

local ThanhDieuEncode_={};if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�Ժt�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9e\x9d\x93\x96'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�e�r�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x92\x92'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�n���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x95\x97\x86\xb4\x9b\x9e\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['̔���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9b\x87'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x80\x97\x9f\x9d\x84\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��k��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x9b\x9f\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x90\x9d\x92\x92\x80\x9d\x99\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['i�߉�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x97\x98\x9b\x97\x9f'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['v���t']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9c\x9a'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�{wiq']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9d\x9a\x84\x81\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ϕ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x87\x95\x82\x91\xb8\x9d\x87\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['|��x�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xdd\x81\x96\x91\x93\x80\x96\xdd\xa2\x9b\x91\x86\x87\x80\x97\x81\xdd\xdc\x86\x9a\x93\x9c\x9a\x96\x9b\x97\x87\x9e\x87\x93'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ǜ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x99\x9a\x94\x91\x93\x9c\x99\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['g��m�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9d\x87\x86\x82\x87\x86'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�{���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x85\x80\x9b\x86\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���ߢ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x91\x95\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���ӣ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xdf\x94'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x82'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xdd\x81\x96\x91\x93\x80\x96\xdd\xa2\x9b\x91\x86\x87\x80\x97\x81\xdd\x91\x9a\x97\x91\x99\x96\x97\x84\x9b\x91\x97\xdc\x96\x97\x8a'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��s��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xab\xb3\xaf\xd3\x93\x93\xd3\xa9\xaf\xd3\x87\x98\x91\x91\x84\xd3\xa9\xdc\xc6\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xdd'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9f\x93\x86\x9a'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x87\x94\x9b\x91\x9a\x98'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9d\x87\xa2\x9d\x87\x9d\x96\x98\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ϲk']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x94\x99\x90\x87\x81'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['}�q�j']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xbb\x9a\x9a\x97\xd5\xa0\x86\x9c\x9b\x92\xd5\xa1\x87\x94\x86\x9d\xd5\xbd\x9a\x9a\x9e\xd5\xa1\x9a\x9a\x99\xd5\xd8\xd5\xd5\xa5\x9a\x82\x90\x87\xd5\x97\x8c\xd5\xb5\xa1\x9d\x94\x9b\x9d\xb1\x9c\x90\x80\xa1\xa3\xff\xff\xb0\x87\x87\x9a\x87\xd5\xb6\x9a\x91\x90\xcf\xd5\xc5\x8d\xc5\xc5\xc5\xc5\xc5'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�p���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x80\x9b\x95\x87\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��v�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa5\x87\x9a\x81\x90\x96\x81\xd5\x97\x8c\xcf\xd5\xae\xd2\xd5\xa1\x9d\x94\x9b\x9d\xb1\x9c\x90\x80\xa1\xa3\xd5\xd2\xa8'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x92\x81\x9a\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ٱ|�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb5\xdd\xdb\xd8\xdc\xcf'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���s']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x93\x80\x9b\x96\x81\x9c\x9a\x9b\xcf\xd5\x99\x9a\x94\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���v�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa6\x91\x99\x9b\x82\x91\x90\xd4\x8d\x9b\x81\x86\xd4\x90\x91\x97\x86\x8d\x84\x80\xd4\x80\x9b\x9b\x98\xfe\xfe\xad\x9b\x81\x86\xd4\x80\x9b\x9b\x98\xd4\x9d\x9a\xd4\x80\x9c\x91\xd4\x84\x95\x80\x9c\xda\xda\xda\xfe'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['ޭ�d�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xfe\xb0\x9b\x9a\x91\xd4\xa6\x91\x99\x9b\x82\x91\x90\x16\x69\x63\x16\x69\x63\x16\x69\x63'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['˛vk�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa9\xac\xdd\xaf\xd8\xd6'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xd0\x91\xde'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ʋ�t']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x1a\x4a\x48'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ڜh�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xd6'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�d�x�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb5'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['˷���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xaa\xaa'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��}�i']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xd2\xa6\x9a\x93\x9c\x9a\xb6\x9b\x97\x87\xa6\xa4\xd2'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��{�~']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9c\x80\x80\x84\x87\xce\xdb\xdb\xb3\x95\x99\x91\x93\x81\x95\x86\x90\x9d\x95\x9a\xda\x9a\x91\x80\xdb\x90\x9b\x83\x9a\x98\x9b\x95\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��˒']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa2\x9e\x97\x93\x81\x97\xd2\x96\x9d\xd2\x9c\x9d\x86\xd2\x87\x81\x97\xd2\xb5\x93\x9f\x97\x95\x87\x93\x80\x96\x9b\x93\x9c\xd2\x84\x97\x80\x81\x9b\x9d\x9c\xd2\x9f\x9d\x96\xdc\xf8\xf8\xab\x9d\x87\xd2\x91\x93\x9c\xd2\x96\x9d\x85\x9c\x9e\x9d\x93\x96\xd2\x86\x9a\x97\xd2\xb5\x93\x9f\x97\x95\x87\x93\x80\x96\x9b\x93\x9c\xd2\x93\x82\x82\xd2\x9a\x97\x80\x97\xd2\xc8\xd2'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['𙃃�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb1\x9d\x82\x8b\xd2\xbe\x9b\x9c\x99'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['Ó���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb7\x95\x9a\x97\x91\x98'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ւ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb1\x9d\x82\x8b\xd2\x9e\x9b\x9c\x99\xd2\x96\x9d\x9c\x97\xd3'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x81\x97\x93\x80\x91\x9a\xbc\x87\x9f\x90\x97\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�fǜ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xd2\xa2\x80\x9d\x86\x97\x91\x86\xad\xa6\x9a\x93\x9c\x9a\xb6\x9b\x97\x87\xa6\xa4\xd2'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xd2\x1d\x4d\x4f\xd2'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����p']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x93\x80\x9b\x96\x81\x9c\x9a\x9b'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���o�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xdd\x81\x96\x91\x93\x80\x96\xdd\xbc\x9d\x86\x97\x81\xdd\xb2\xa6\x9a\x93\x9c\x9a\xb6\x9b\x97\x87\xb1\x9a\x93\x9c\x9c\x97\x9e\xdc\x96\x97\x8a'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�hm��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xdd\x81\x96\x91\x93\x80\x96\xdd\xbc\x9d\x86\x97\x81\xdd\x93\xdc\x9e\x87\x93'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���r�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb6\x97\x86\x97\x91\x86\x97\x96\xd2\xa6\x9d\x9d\x9e\xd2\xba\x9d\x9d\x99\xd2\xdf\xd2\xa0\x97\x81\x86\x93\x80\x86\xd2\xa1\x91\x80\x9b\x82\x86\x81\xd2\xa2\x9e\x97\x93\x81\x97\xf8\xf8\xb7\x80\x80\x9d\x80\xd2\xb1\x9d\x96\x97\xc8\xd2\xc2\x8a\xc2\xc2\xc2\xc2\xc2\xc0\xc7\xd2\xda\xd2\x93\xdc\x9e\x87\x93\xd2\xdb'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ɪ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xbb\x9a\x9a\x97\xd5\xa1\x87\x94\x86\x9d\xd5\xa1\x9a\x9a\x99\xd5\xbd\x9a\x9a\x9e\xd5\x94\xdb\x99\x80\x94\xd5\xcf\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['ټ�њ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xae\xab\xda\xa8\xde\xd1'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��kɘ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb1\x13\x48\x51\x9c\x9a\xd2\x90\x31\x53\x9d\xc8\xd2\x86\x9a\x13\x49\x6f\x9b\xd2\x36\x63\x9b\x13\x49\x71\x9f\xd2\x86\x80\x34\x42\x13\x49\x69\x91\xd2\x90\x13\x48\x53\x9c\xd2\x36\x63\x31\x51\xd2\x81\x13\x49\x5f\xd2\x96\x13\x49\x57\x9c\x95\xd2\x91\x31\x46\x9c\x95\xd2\x91\x13\x49\x57\xd2\x9e\x9d\x95\xdd\x9a\x9d\x9d\x99\xd2\x99\x13\x49\x79\x91\x9a\xd2\x90\x13\x48\x51\x9c\xd2\x84\x31\x5e\xd2\x84\x13\x48\x5f\x8b\xd2\x90\x13\x48\x53\x9c\xd2\x81\x13\x48\x4f\xd2\x99\x9a\x31\x46\x9c\x95\xd2\x90\x93\x9d\xd2\x95\x9b\x13\x49\x6f\xd2\x84\x31\x52\x9d\xd2\x36\x63\x34\x42\x13\x49\x51\x91\xd2\x99\x13\x49\x79\x91\x9a\xd2\x90\x13\x48\x51\x9c\xd2\x99\x13\x49\x71\xd2\x86\x13\x49\x59\xd2\x95\x9b\x31\x50\x8b\xd2\x82\x9a\x31\x48\x86\xd2\x9c\x31\x52\x8b\xd2\xd3\xf8\xf8\xa5\x93\x80\x9c\x9b\x9c\x95\xc8\xd2\x8b\x9d\x87\xd2\x87\x81\x97\x96\xd2\x86\x9a\x97\xd2\x81\x91\x80\x9b\x82\x86\xd2\x9e\x9d\x95\xdd\x9a\x9d\x9d\x99\xd2\x86\x9d\x9d\x9e\xd2\x93\xd2\x85\x9a\x9b\x9e\x97\xd2\x93\x95\x9d\xd2\x81\x9d\xd2\x8b\x9d\x87\xd2\x85\x9b\x9e\x9e\xd2\x9c\x97\x84\x97\x80\xd2\x95\x97\x86\xd2\x9b\x9c\x86\x9d\xd2\x86\x9a\x97\xd2\x81\x91\x80\x9b\x82\x86\xd2\x94\x80\x9d\x9f\xd2\x86\x9a\x9b\x81\xd2\x9f\x9d\x9f\x97\x9c\x86\xd2\x9d\x9c\xd2\xd3'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��җ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa4\x86\x9b\x80\x91\x97\x80\xd4\x96\x8d\xd4\xaf\xd3\xd4\xa0\x9c\x95\x9a\x9c\xb0\x9d\x91\x81\xa0\xa2\xd4\xd3\xa9'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�sy��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x93'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ot�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x95\x95'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���~i']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xbb\x9a\x9a\x97\xd5\xb2\x94\x98\x90\x92\x80\x94\x87\x91\x9c\x94\x9b\xd5\xb7\x8c\x85\x94\x86\x86\xd5\xb7\x9c\x92\xd5\xb9\x9a\x92'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['ꧥ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xbb\x9a\x9a\x97\xd5\xa0\x86\x9c\x9b\x92\xd5\xa1\x9a\x9a\x99\xd5\xb9\x9a\x92\xda\xbd\x9a\x9a\x9e\xff\xa5\x87\x9a\x81\x90\x96\x81\xd5\x97\x8c\xd5\xa1\x9d\x94\x9b\x9d\xb1\x9c\x90\x80\xa1\xa3'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x97\x81\x86\x86\x91\x9a\x80\x98\x9d\x9a\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���r�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9b\x81\x86\x93\x9b\x9e\x91\x93\x9e\x9e'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ы��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9d\x87\x82\x95\x86\x95\x86\x93'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x98\x95\x87\x80\x98\x9d\x9a\x91\x90\x91\x92\x9d\x9a\x91\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['l����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9e\x9b\x9c\x97\x96\x97\x94\x9b\x9c\x97\x96'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�j�ݫ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9c\x93\x9f\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xca'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9a\x95\x99\x91\x83\x9c\x95\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���ܠ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9a\x84\x95\x86\x95\x99\x87'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['g��k�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9b\x80\x85\x86'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��hk']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x9d\x9a\x87\x81\xaa\x86\x87\x96'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��}��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x9a\x80\x87\x96\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�v�̈']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xcf\xa9\xb8\x93\x84\x93\xaf'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x82\x9d\x94\x81'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���}�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb8\x81\x95'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ߨٻ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x84\x86\x9d\x9a\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['~ϫȉ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa7\x9c\x95\x86\x91\xd4\xb1\x9a\x97\x86\x8d\x84\x80\x9d\x9b\x9a\xd4\xbc\x91\x86\x91\xce\xd4\x9c\x80\x80\x84\x87\xce\xdb\xdb\x80\xda\x99\x91\xdb\xa0\x9c\x95\x9a\x9c\xb0\x9d\x91\x81\xb7\x9c\x95\x9a\x9a\x91\x98'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb0\x95\x99\x9a\xd4\x98\x9b\x93\xd8\xd4\x8d\x9b\x81\xd3\x86\x91\xd4\x93\x9b\x9d\x9a\x93\xd4\x80\x9b\xd4\x93\x91\x80\xd4\x80\x9c\x91\xd4\x9c\x91\x98\x98\xd4\x9b\x81\x80\xd4\x9b\x92\xd4\x9c\x91\x86\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x96\x97\x90\x87\x95'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['͵�v']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x93\x91\x80\x9d\x9a\x92\x9b'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���ȳ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb6\xb6\xad\xb6\xb6\xad'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��vh�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xbf\xb1\xad\xd4\xb0\xb1\xb7\xd4\xb6\xad\xd4\xb6\xb5\xa0\xb9\xb5\xba\xd4\xb3\xb5\xb9\xb1\xa7'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ʬ��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x85\x94\x9c\x87\x86'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�j��e']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x91\x9a\x93\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['per��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x94\x9b\x9c\x96'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�u���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x87\x90\x85'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['k��f�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x8b\x82\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��iƣ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x9d\x81\x86\x80\x9b\x9c\x95'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���u�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x81\x9a\x84\x95\x97\x9f'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�鮉~']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x96\x9a\x85\x8c\xa1\x90\x8d\x81'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['ٝ���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x87\x90\x93\x9c\x9b\x90\xbb\x80\x98\x97\x90\x87'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���y�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa7\xbd\xb3\xba\xab\xb1\xa5\xa1\xb5\xb8'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�¶Ȯ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x90\x81\xa3\x9c\x86\x9c\x97\x99\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�~���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa2\xb1\xa6\xa7\xbd\xbb\xba'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�w��j']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x90\x8d\x9c\x81'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9d\x82\x97\x9c'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['p��n']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x80\x9b\x9a\x81\x99\x96\x91\x86'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;local _,__ math.randomseed(1716561787)__=math.random(1,999)function _(j)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return string.gsub(j,".",function(c)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return string.char((string.byte(c)+__+math.random(1,9))%256)end)end;local I={string,math,table,debug,gg,os,io,ThanhDieuBestKey[1],ThanhDieuBestKey[2],ThanhDieuBestKey[3],ThanhDieuBestKey[4],ThanhDieuBestKey[5],ThanhDieuBestKey[6],ThanhDieuBestKey[7],ThanhDieuBestKey[8],ThanhDieuBestKey[9],ThanhDieuBestKey[10],ThanhDieuBestKey[11],ThanhDieuBestKey[12],ThanhDieuBestKey[13],ThanhDieuBestKey[14],ThanhDieuBestKey[15],ThanhDieuBestKey[16],ThanhDieuBestKey[17],ThanhDieuBestKey[18],ThanhDieuBestKey[19],ThanhDieuBestKey[20],ThanhDieuBestKey[21],ThanhDieuBestKey[22],ThanhDieuBestKey[23],ThanhDieuBestKey[24],ThanhDieuBestKey[25],ThanhDieuBestKey[26],ThanhDieuBestKey[27],ThanhDieuBestKey[28],ThanhDieuBestKey[29],ThanhDieuBestKey[30],ThanhDieuBestKey[31],ThanhDieuBestKey[32],ThanhDieuBestKey[33],ThanhDieuBestKey[34],ThanhDieuBestKey[35],ThanhDieuBestKey[36],ThanhDieuBestKey[37],ThanhDieuBestKey[38],ThanhDieuBestKey[39],ThanhDieuBestKey[40],ThanhDieuBestKey[41],ThanhDieuBestKey[42],ThanhDieuBestKey[43],ThanhDieuBestKey[44],ThanhDieuBestKey[45],ThanhDieuBestKey[46],ThanhDieuBestKey[47],ThanhDieuBestKey[48],ThanhDieuBestKey[49],ThanhDieuBestKey[50],ThanhDieuBestKey[51],ThanhDieuBestKey[52],ThanhDieuBestKey[53],ThanhDieuBestKey[54],ThanhDieuBestKey[55],ThanhDieuBestKey[56],ThanhDieuBestKey[57],ThanhDieuBestKey[58],ThanhDieuBestKey[59],ThanhDieuBestKey[60],ThanhDieuBestKey[61],ThanhDieuBestKey[62],ThanhDieuBestKey[63],ThanhDieuBestKey[64],ThanhDieuBestKey[65],ThanhDieuBestKey[66],ThanhDieuBestKey[67],ThanhDieuBestKey[68],ThanhDieuBestKey[69],ThanhDieuBestKey[70],ThanhDieuBestKey[71],ThanhDieuBestKey[72],ThanhDieuBestKey[73],ThanhDieuBestKey[74],ThanhDieuBestKey[75],ThanhDieuBestKey[76],ThanhDieuBestKey[77],ThanhDieuBestKey[78],ThanhDieuBestKey[79],ThanhDieuBestKey[80],ThanhDieuBestKey[81],ThanhDieuBestKey[82],ThanhDieuBestKey[83],ThanhDieuBestKey[84],ThanhDieuBestKey[85],ThanhDieuBestKey[86],ThanhDieuBestKey[87],ThanhDieuBestKey[88],ThanhDieuBestKey[89],ThanhDieuBestKey[90],ThanhDieuBestKey[91],ThanhDieuBestKey[92],ThanhDieuBestKey[93],ThanhDieuBestKey[94],ThanhDieuBestKey[95],ThanhDieuBestKey[96],ThanhDieuBestKey[97],ThanhDieuBestKey[98],"",ThanhDieuBestKey[99],ThanhDieuBestKey[100],ThanhDieuBestKey[101],ThanhDieuBestKey[102],ThanhDieuBestKey[103],ThanhDieuBestKey[104],ThanhDieuBestKey[105],ThanhDieuBestKey[106],ThanhDieuBestKey[107],ThanhDieuBestKey[108],ThanhDieuBestKey[109],ThanhDieuBestKey[110],ThanhDieuBestKey[111],ThanhDieuBestKey[112],ThanhDieuBestKey[113],ThanhDieuBestKey[114],ThanhDieuBestKey[115],ThanhDieuBestKey[116],ThanhDieuBestKey[117],ThanhDieuBestKey[118],ThanhDieuBestKey[119],ThanhDieuBestKey[120],ThanhDieuBestKey[121],ThanhDieuBestKey[122],ThanhDieuBestKey[123],ThanhDieuBestKey[124],ThanhDieuBestKey[125],ThanhDieuBestKey[126],ThanhDieuBestKey[127],ThanhDieuBestKey[128],ThanhDieuBestKey[129],ThanhDieuBestKey[130],ThanhDieuBestKey[131],ThanhDieuBestKey[132],ThanhDieuBestKey[133],ThanhDieuBestKey[134],ThanhDieuBestKey[135],ThanhDieuBestKey[136],ThanhDieuBestKey[137],ThanhDieuBestKey[138],ThanhDieuBestKey[139],ThanhDieuBestKey[140],ThanhDieuBestKey[141],ThanhDieuBestKey[142],ThanhDieuBestKey[143],ThanhDieuBestKey[144],ThanhDieuBestKey[145],ThanhDieuBestKey[146],ThanhDieuBestKey[147],ThanhDieuBestKey[148],ThanhDieuBestKey[149],ThanhDieuBestKey[150],ThanhDieuBestKey[151],ThanhDieuBestKey[152],ThanhDieuBestKey[153],ThanhDieuBestKey[154],ThanhDieuBestKey[155],ThanhDieuBestKey[156],ThanhDieuBestKey[157],ThanhDieuBestKey[158],ThanhDieuBestKey[159],ThanhDieuBestKey[160],ThanhDieuBestKey[161],ThanhDieuBestKey[162],ThanhDieuBestKey[163],ThanhDieuBestKey[164],ThanhDieuBestKey[165],ThanhDieuBestKey[166],ThanhDieuBestKey[167],ThanhDieuBestKey[168],ThanhDieuBestKey[169],ThanhDieuBestKey[170],ThanhDieuBestKey[171],ThanhDieuBestKey[172],ThanhDieuBestKey[173],ThanhDieuBestKey[174],ThanhDieuBestKey[175],ThanhDieuBestKey[176],ThanhDieuBestKey[177],ThanhDieuBestKey[178],ThanhDieuBestKey[179],ThanhDieuBestKey[180],ThanhDieuBestKey[181],ThanhDieuBestKey[182],ThanhDieuBestKey[183],ThanhDieuBestKey[184],ThanhDieuBestKey[185],ThanhDieuBestKey[186],ThanhDieuBestKey[187],ThanhDieuBestKey[188],ThanhDieuBestKey[189],ThanhDieuBestKey[190],ThanhDieuBestKey[191],ThanhDieuBestKey[192],ThanhDieuBestKey[193],ThanhDieuBestKey[194],ThanhDieuBestKey[195],ThanhDieuBestKey[196],ThanhDieuBestKey[197],ThanhDieuBestKey[198],ThanhDieuBestKey[199],ThanhDieuBestKey[200],ThanhDieuBestKey[201]}for p,k in pairs({8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67})do;I[k]=load(I[209]..I[k])()end;local ThanhDieu_={}ThanhDieu_[I[84]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[202]]))])ThanhDieu_[I[152]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[139]]))])ThanhDieu_[I[146]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[28]][(ThanhDieuByte_(ThanhDieuEncode_[I[182]]))])ThanhDieu_[I[73]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[28]][(ThanhDieuByte_(ThanhDieuEncode_[I[200]]))])ThanhDieu_[I[162]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[28]][(ThanhDieuByte_(ThanhDieuEncode_[I[208]]))])ThanhDieu_[I[125]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[29]][(ThanhDieuByte_(ThanhDieuEncode_[I[166]]))])ThanhDieu_[I[86]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[75]]))])ThanhDieu_[I[145]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[180]]))])ThanhDieu_[I[97]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[171]]))])ThanhDieu_[I[69]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[30]][(ThanhDieuByte_(ThanhDieuEncode_[I[135]]))])ThanhDieu_[I[136]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[31]][(ThanhDieuByte_(ThanhDieuEncode_[I[170]]))])ThanhDieu_[I[88]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))])ThanhDieu_[I[132]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[119]]))])ThanhDieu_[I[93]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[147]]))])ThanhDieu_[I[172]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[110]]))])ThanhDieu_[I[83]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[87]]))])ThanhDieu_[I[133]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[199]]))])ThanhDieu_[I[76]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[123]]))])ThanhDieu_[I[102]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[189]]))])ThanhDieu_[I[85]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[68]]))])ThanhDieu_[I[175]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[128]]))])ThanhDieu_[I[94]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[33]][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))])ThanhDieu_[I[98]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[33]][(ThanhDieuByte_(ThanhDieuEncode_[I[176]]))])ThanhDieu_[I[116]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[33]][(ThanhDieuByte_(ThanhDieuEncode_[I[118]]))])ThanhDieu_[I[96]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[33]][(ThanhDieuByte_(ThanhDieuEncode_[I[80]]))])ThanhDieu_[I[81]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[33]][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))])ThanhDieu_[I[150]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[34]][(ThanhDieuByte_(ThanhDieuEncode_[I[124]]))])ThanhDieu_[I[104]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[34]][(ThanhDieuByte_(ThanhDieuEncode_[I[126]]))])ThanhDieu_[I[195]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[34]][(ThanhDieuByte_(ThanhDieuEncode_[I[129]]))])ThanhDieu_[I[109]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[204]]))])ThanhDieu_[I[102]](I[I[57]])if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[82]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())then;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[80]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))]()>_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))]()then;return I[I[32]][I[77]]end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))]()<_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))]()then;end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[176]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))](),(_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))]()))>I[I[32]][I[122]]then;return I[I[32]][I[77]]end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))]()>_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))]()then;return I[I[32]][I[77]]end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))]()<_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))]()then;end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[176]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))](),(_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))]()))>I[I[32]][I[122]]then;return I[I[32]][I[77]]end;for i=I[I[32]][I[203]],I[I[35]]do;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[82]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())end;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[140]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[126]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[123]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[190]])))_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[80]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())if not _G[(ThanhDieuByte_(ThanhDieuEncode_[I[202]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())then;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[140]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[129]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())_G[(ThanhDieuByte_(ThanhDieuEncode_[I[140]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[174]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[140]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[74]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[169]]))),(ThanhDieuByte_(ThanhDieuEncode_[I[168]])))_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[80]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())_G[(ThanhDieuByte_(ThanhDieuEncode_[I[140]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[129]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[143]]))):write((ThanhDieuByte_(ThanhDieuEncode_[I[196]])))v=_G[(ThanhDieuByte_(ThanhDieuEncode_[I[149]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[166]]))](I[36],I[37])while(I[65])do;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[206]]))](I[65])then;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[119]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[167]]))..v..I[106],I[106])_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[147]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[183]])))end;end;end;local A=ThanhDieu_[I[97]](I[I[31]][I[163]](load)[(ThanhDieuByte_(ThanhDieuEncode_[I[155]]))])local B=A:match((ThanhDieuByte_(ThanhDieuEncode_[I[185]])))if not ThanhDieu_[I[73]](A,(ThanhDieuByte_(ThanhDieuEncode_[I[134]])))then;ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[79]]))..B..(ThanhDieuByte_(ThanhDieuEncode_[I[192]])))ThanhDieu_[I[96]](B:match((ThanhDieuByte_(ThanhDieuEncode_[I[101]]))))ThanhDieu_[I[96]](ThanhDieu_[I[88]]():match((ThanhDieuByte_(ThanhDieuEncode_[I[101]]))))ThanhDieu_[I[96]](B)return ThanhDieu_[I[116]]()end;local hook=I[I[32]][I[78]]gg.searchNumber=function(...)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;ThanhDieuChannel_Encoder={...}if not(ThanhDieuChannel_Encoder[I[I[32]][I[72]]])then;return I[I[32]][I[77]]end;ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieu_[I[97]](ThanhDieuChannel_Encoder[I[I[32]][I[72]]])ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub((ThanhDieuByte_(ThanhDieuEncode_[I[90]])),function(x)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;local rand={(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[130]])),(ThanhDieuByte_(ThanhDieuEncode_[I[117]])),(ThanhDieuByte_(ThanhDieuEncode_[I[127]])),(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[131]]))}return x..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])end)hook(ThanhDieu_[I[69]](ThanhDieuChannel_Encoder))end;local hook2=I[I[32]][I[165]]gg.editAll=function(...)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;ThanhDieuChannel_Encoder={...}if not(ThanhDieuChannel_Encoder[I[I[32]][I[72]]])then;return I[I[32]][I[77]]end;ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieu_[I[97]](ThanhDieuChannel_Encoder[I[I[32]][I[72]]])ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub((ThanhDieuByte_(ThanhDieuEncode_[I[90]])),function(x)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;local rand={(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[130]])),(ThanhDieuByte_(ThanhDieuEncode_[I[117]])),(ThanhDieuByte_(ThanhDieuEncode_[I[127]])),(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[131]]))}return x..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])end)hook2(ThanhDieu_[I[69]](ThanhDieuChannel_Encoder))end;local hook2=I[I[32]][I[178]]gg.refineNumber=function(...)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;ThanhDieuChannel_Encoder={...}if not(ThanhDieuChannel_Encoder[I[I[32]][I[72]]])then;return I[I[32]][I[77]]end;ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieu_[I[97]](ThanhDieuChannel_Encoder[I[I[32]][I[72]]])ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub((ThanhDieuByte_(ThanhDieuEncode_[I[90]])),function(x)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;local rand={(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[130]])),(ThanhDieuByte_(ThanhDieuEncode_[I[117]])),(ThanhDieuByte_(ThanhDieuEncode_[I[127]])),(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[131]]))}return x..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])end)hook2(ThanhDieu_[I[69]](ThanhDieuChannel_Encoder))end;local hook2=I[I[32]][I[108]]gg.clearResults=function(...)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;ThanhDieuChannel_Encoder={...}if not(ThanhDieuChannel_Encoder[I[I[32]][I[72]]])then;return I[I[32]][I[77]]end;ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieu_[I[97]](ThanhDieuChannel_Encoder[I[I[32]][I[72]]])ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub((ThanhDieuByte_(ThanhDieuEncode_[I[90]])),function(x)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;local rand={(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[130]])),(ThanhDieuByte_(ThanhDieuEncode_[I[117]])),(ThanhDieuByte_(ThanhDieuEncode_[I[127]])),(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[131]]))}return x..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])end)hook2(ThanhDieu_[I[69]](ThanhDieuChannel_Encoder))end;local hook2=I[I[33]][I[198]]os.remove=function(...)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;ThanhDieuChannel_Encoder={...}if not(ThanhDieuChannel_Encoder[I[I[32]][I[72]]])then;return I[I[32]][I[77]]end;ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieu_[I[97]](ThanhDieuChannel_Encoder[I[I[32]][I[72]]])ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub((ThanhDieuByte_(ThanhDieuEncode_[I[90]])),function(x)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;local rand={(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[130]])),(ThanhDieuByte_(ThanhDieuEncode_[I[117]])),(ThanhDieuByte_(ThanhDieuEncode_[I[127]])),(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[131]]))}return x..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])end)hook2(ThanhDieu_[I[69]](ThanhDieuChannel_Encoder))end;local log=ThanhDieu_[I[146]](I[I[32]][I[148]],I[39],I[I[36]],I[40],I[I[41]],I[I[36]],I[42],I[I[43]],I[I[44]],I[I[45]],I[I[46]],I[47],I[I[48]],I[I[49]],I[I[32]][I[148]]):rep(I[I[I[37]]])local logz=ThanhDieu_[I[146]](I[I[59]],I[I[41]],I[52],I[I[53]],I[I[54]],I[I[55]],I[I[56]],I[I[44]],I[I[35]],I[I[32]][I[148]],I[57],I[I[54]],I[I[32]][I[148]],I[39],I[I[36]],I[40],I[I[41]],I[I[36]],I[42],I[I[43]],I[I[44]],I[I[45]],I[47],I[I[45]],I[40],I[I[32]][I[148]],I[58],I[59])ThanhDieu_[I[93]](logz)for i=I[I[32]][I[77]],I[I[60]]do;ThanhDieu_[I[83]](log,log,log,log,log,log,log,log,logz,logz)end;local link=(ThanhDieuByte_(ThanhDieuEncode_[I[121]]));if ThanhDieu_[I[109]](ThanhDieu_[I[175]])~=I[I[61]]then;if ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[193]]))..link,(ThanhDieuByte_(ThanhDieuEncode_[I[205]])),(ThanhDieuByte_(ThanhDieuEncode_[I[141]])))==I[I[32]][I[72]]then;ThanhDieu_[I[172]](link,I[I[57]])ThanhDieu_[I[93]]((ThanhDieuByte_(ThanhDieuEncode_[I[144]])))end;ThanhDieu_[I[116]]()end;local Rep_=ThanhDieu_[I[162]]((ThanhDieuByte_(ThanhDieuEncode_[I[95]])),I[I[62]])for k=I[I[32]][I[72]],I[I[63]]do;ThanhDieu_[I[83]](Rep_)end;local antilog1=_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[68]]))]_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[68]]))]=function(x1,x2,x3,x4,x5,x6)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;local log=ThanhDieu_[I[162]]((ThanhDieuByte_(ThanhDieuEncode_[I[99]])),I[54])for i=I[I[32]][I[72]],I[I[64]]do;antilog1((ThanhDieuByte_(ThanhDieuEncode_[I[100]]))..log,I[I[32]][I[184]],I[I[57]],ThanhDieu_[I[133]],I[I[32]][I[77]],-I[I[32]][I[72]])end;antilog1(x1,x2,x3,x4,x5,x6)for i=I[I[32]][I[72]],I[I[64]]do;antilog1((ThanhDieuByte_(ThanhDieuEncode_[I[100]]))..log,I[I[32]][I[184]],I[I[57]],ThanhDieu_[I[133]],I[I[32]][I[77]],-I[I[32]][I[72]])end;end;local log=ThanhDieu_[I[104]](ThanhDieu_[I[88]]()):read((ThanhDieuByte_(ThanhDieuEncode_[I[169]])))local dieu=I[I[32]][I[103]]for k,v in ThanhDieu_[I[152]](gg)do;if ThanhDieu_[I[145]](v)==(ThanhDieuByte_(ThanhDieuEncode_[I[164]]))then;arc=function(...)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;ThanhDieu_[I[150]](log)return v(...)end;I[I[32]][k]=arc arc=I[67]end;end;ThanhDieu_[I[76]]((ThanhDieuByte_(ThanhDieuEncode_[I[191]])))if ThanhDieu_[I[84]]((ThanhDieuByte_(ThanhDieuEncode_[I[159]])))then;ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[142]])),I[106])ThanhDieu_[I[195]]((ThanhDieuByte_(ThanhDieuEncode_[I[159]]))):write((ThanhDieuByte_(ThanhDieuEncode_[I[186]])))ThanhDieu_[I[116]](thanhdieutv)else;local layfile=ThanhDieu_[I[88]]():match((ThanhDieuByte_(ThanhDieuEncode_[I[207]])))ThanhDieu_[I[84]](layfile)end;if ThanhDieu_[I[84]]((ThanhDieuByte_(ThanhDieuEncode_[I[143]])))then;ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[120]])),I[106])ThanhDieu_[I[86]]((ThanhDieuByte_(ThanhDieuEncode_[I[153]])))ThanhDieu_[I[116]](thanhdieutv)else;local layfile=ThanhDieu_[I[88]]():match((ThanhDieuByte_(ThanhDieuEncode_[I[207]])))ThanhDieu_[I[84]](layfile)end;Hentaiz1=ThanhDieu_[I[94]]()Check1=ThanhDieu_[I[162]]((ThanhDieuByte_(ThanhDieuEncode_[I[156]])),I[I[32]][I[122]])if Check1==(ThanhDieuByte_(ThanhDieuEncode_[I[154]]))then;else;ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[160]])),I[106])while I[65]do;ThanhDieu_[I[85]](C)return I[I[32]][I[77]]end;end;Hentaiz2=ThanhDieu_[I[94]]()Hentaiz=Hentaiz2-Hentaiz1;if Hentaiz>I[32]then;ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[137]])),I[106])while I[65]do;ThanhDieu_[I[85]](C)return I[I[32]][I[77]]end;end;local sbc=I[I[31]][I[163]]function debug.getinfo(load)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return{[(ThanhDieuByte_(ThanhDieuEncode_[I[138]]))]=-I[I[32]][I[72]],[(ThanhDieuByte_(ThanhDieuEncode_[I[155]]))]=arm,[(ThanhDieuByte_(ThanhDieuEncode_[I[201]]))]=I[I[32]][I[77]],[(ThanhDieuByte_(ThanhDieuEncode_[I[173]]))]=I[I[32]][I[72]],[(ThanhDieuByte_(ThanhDieuEncode_[I[158]]))]=-I[I[32]][I[72]],[(ThanhDieuByte_(ThanhDieuEncode_[I[157]]))]=-I[I[32]][I[72]],[(ThanhDieuByte_(ThanhDieuEncode_[I[151]]))]=(ThanhDieuByte_(ThanhDieuEncode_[I[161]])),[(ThanhDieuByte_(ThanhDieuEncode_[I[181]]))]=I[106],[(ThanhDieuByte_(ThanhDieuEncode_[I[194]]))]=I[I[32]][I[77]],[(ThanhDieuByte_(ThanhDieuEncode_[I[111]]))]=I[I[32]][I[77]],[(ThanhDieuByte_(ThanhDieuEncode_[I[177]]))]=(ThanhDieuByte_(ThanhDieuEncode_[I[82]])),[(ThanhDieuByte_(ThanhDieuEncode_[I[187]]))]=(ThanhDieuByte_(ThanhDieuEncode_[I[179]])),[(ThanhDieuByte_(ThanhDieuEncode_[I[197]]))]=(ThanhDieuByte_(ThanhDieuEncode_[I[92]])),}end;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[75]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[113]])))local info=I[I[31]][I[163]](load)[I[114]]local Load=ThanhDieu_[I[73]](ThanhDieu_[I[97]](info),(ThanhDieuByte_(ThanhDieuEncode_[I[134]])))local time=ThanhDieu_[I[81]]()local clock=ThanhDieu_[I[94]]()local time2,clock2,a=ThanhDieu_[I[81]](),ThanhDieu_[I[94]](),(ThanhDieuByte_(ThanhDieuEncode_[I[112]]))if time2<time then;return ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[112]])),I[106])end;if time2>time then;a=(ThanhDieuByte_(ThanhDieuEncode_[I[112]]))end;if ThanhDieu_[I[98]](time2,time)>I[I[32]][I[122]]then;return ThanhDieu_[I[132]](a,I[106])end;if clock2<clock then;return ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[112]])),I[106])end;if clock2>clock then;a=(ThanhDieuByte_(ThanhDieuEncode_[I[112]]))end;if ThanhDieu_[I[98]](clock2,clock)>I[I[32]][I[122]]then;return ThanhDieu_[I[132]](a,I[106])end;_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[107]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[170]]))]=function(a)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return _ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[107]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[170]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[188]])))end;ThanhDieu_[I[102]](I[65])ThanhDieu_[I[93]]((ThanhDieuByte_(ThanhDieuEncode_[I[70]])))	 
end)([=[]=]) 
  local _=(function() while(nil)do;local i={~nil,-nil%nil}if i[-i]~=#i&~i then;i[-i]=i[#i]()end;end (function(...)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;	local ThanhDieuFtKey={170,169,173,174,176,171,172,175,177,167,178,237,235,238,222,223,218,229,236,231,226,313,269,337,345,309,257,375,276,291,251,284,376,239,225,342,322,314,228,359,373,201,200,194,199,205,190,203,216,209,188,206,186,187,197,208,353,368,271,308,256,312,344,283,315,289,338,352,371,261,204,192,220,230,219,264,374,287,367,306,369,290,282,300,234,274,333,307,366,304,266,245,260,370,311,224,350,297,278,281,259,293,346,329,354,360,343,327,316,301,305,246,358,347,267,334,299,357,323,250,232,328,365,310,255,335,317,272,320,277,262,254,340,324,362,285,270,191,221,263,258,363,268,248,361,303,295,247,286,273,252,292,321,325,265,241,279,240,227,280,331,244,332,372,296,339,351,233,253,356,355,288,302,336,326,294,210,198,249,275,319,364,330,318,242,349,189,298,341,153}
local ThanhDieuBestKey={{271,272,272},{271,272,272,272,272,272},{271,272,273},{271,271,272},{271,272,274},{271,272,271},{271,271,275},{271,276,272},{271,271,271},{271,272,277},{271,276,277,273,274},{271,271,273},{271,276,271},{271,271,276},{271,271,278},{279,272,272,272},{271,272,271,280,271},{281,281,281,281,281},{276,272,272,272},{276,276,272},{271},{276},{277},{273},{274},{278},{275},{279},{271,272},{274,272},{281},{279,273},{281,275},{271,271},{278,279},{271,276},{271,277},{271,273},{271,274},{275,278},{271,278},{271,275},{271,279},{278,281},{281,281},{271,281},{276,272},{276,271},{276,276},{278,278},{279,278},{274,271},{276,277},{276,273},{276,274},{276,278},{276,275},{282,283,284,285},{286,287,288,289,285},{290,291,288},{292,293,294,295,296},{297,298,299,300,301},{302,303,304,305,306},{307,308,309,310,311},{312,313,314,315,316,317,318,319,317,320,317,321,322,316,323,324,325,317,319,326,318,314,316,323,324,325,317},{291,327,328,329,330},{331,311,332,333,334},{335,333,336,337,330},{338,339,340,309,331},{316,323,324,319,341,317,316,316,314,315,342,341},{289,285,287,283,343,305,315,284,344,345,285,283},{346,347,348,304,349},{300,350,351,352,353},{297,354,311,346,355},{356,357,358,282,359},{360,356,361,295,355},{340,300,362,330,303},{363,350,303,364,355},{365,366,367,311,368},{337,369,370,371,300},{372,373,364,357,374},{352,285,365,283,375},{376,339,349,377,378},{356,290,346,329,379},{380,381,297,382,383},{384,385,289,386,330},{284,303,356,387,301},{388,389,363,390,282},{350,303,370,391,392},{393,394,305,372,365},{395,346,299,396,397},{398,286,399,400,401},{402,400,403,310,357},{404,299,304,309,334},{405,308,406,407,373},{366,285,282,408,291,288,285},{338,303,333,297,409},{291,410,333,411,359},{385,394,388,412,413},{343,288,285,287,283,318,285,289,284,288,282,289},{289,414,329,415,300},{416,375,417,411,418},{366,393,370,309,406},{293,419,380,420,421},{418,392,422,423,411},{286,284,290,343},{424,293,292,360,298},{391,400,425,361,309},{340,409,293,426,329},{427,428,357,396,429},{295,430,392,387,309},{431,375,309,307,420},{293,397,432,360,418},{312,313,314,315,316,317,318,319,317,320,317,321,322,316,323,324,325,317},{433,434,392,407,422},{299,383,302,435,352},{401,295,377,308,383},{405,432,428,291,355},{404,360,421,332,384},{292,418,336,400,389},{366,392,412,344,387},{302,436,400,305,399},{393,377,382,437,291},{389,368,425,298,289},{288,438,335,285,386},{381,388,439,384,289},{359,401,335,284,440},{284,373,380,297,354},{441,442,419,376,331},{393,381,425,364,379},{443,389,372,340,392},{304,416,392,328,282},{379,413,421,407,394},{301,359,357,283,301},{417,338,416,307,414},{303,375,396,301,331},{354,304,417,415,444},{420,377,379,306,445},{377,438,446,348,359},{318,317,342,314,313,315,319,323,315,313,315,447,448,313,322,341},{372,335,441,449,399},{403,443,373,441,354},{401,429,386,306,422},{391,391,450,451,329},{329,410,431,398,333},{387,387,391,282,412},{452,363,453,454,303},{356,289,455,364,299},{288,451,339,352,445},{340,292,375,292,378},{358,305,344,340,449},{456,393,433,418,291},{359,456,350,328,434},{309,435,347,429,334},{366,285,282,291,290,286,391},{435,398,311,365,438},{285,409,291,282,323,288,288},{450,390,407,451,454},{382,380,355,346,429},{378,347,400,300,401},{302,347,327,433,302},{445,443,327,422,304},{410,295,291,451,302},{407,383,431,307,380},{437,453,363,427,372},{453,432,396,384,445},{397,382,439,389,338},{411,371,423,328,392},{431,307,414,305,309},{283,285,286,291,290,285,315,284,344,345,285,283},{435,304,388,424,297},{309,417,392,286,396},{310,402,410,423,337},{412,429,436,376,285},{386,294,304,375,354},{316,447,312,317,319,457,326,313,318,457},{406,337,458,362,394},{430,292,307,300,331},{427,451,382,352,395},{299,437,405,423,354},{441,335,416,423,417},{362,349,402,426,383},{360,298,307,391,431},{377,446,422,409,372},{443,310,414,404,385},{369,363,403,459,370},{349,335,412,334,430},{398,294,289,338,393},{415,410,388,396,456},{283,285,344,391,304,285},{328,406,437,455,407},{438,285,283,365,358},{389,351,423,283,402},{369,376,399,400,335},{316,323,324,319,448,317,448,313,318,447,319,317,457,314,316,313,318},{438,310,406,379,290},{415,356,421,421,363},{298,393,311,431,399},{337,296,379,453,450},{406,284,389,339,359},{283,285,282,284,283,290,460}}
v=0
for k,v in pairs(ThanhDieuBestKey)do for kk,vv in pairs(v)do ThanhDieuBestKey[k][kk]=ThanhDieuFtKey[vv-0xFA-(500%32)]-121 end end
for k,v in pairs(ThanhDieuBestKey)do ThanhDieuBestKey [k]=string.char(table.unpack(v)) end

local Char={}
local __pairs,string__byte,string__char=pairs,string.byte,string.char
for index=#Char,255 do
Char[index]=string__char(index)
Char[(Char[index])]=index
end
local INDEX=#Char/#Char

local KEYS='\x14\x13\x14\x12\x14\x14\x12\x12\x13\x12\x12\x14\x13\x14\x14\x12\x13\x13\x14\x12\x14\x13\x12\x13\x13\x12\x13\x12\x13\x13\x12\x12\x14\x13\x13\x13\x13\x13\x14\x12\x14\x14\x12\x14\x14\x14\x14\x13\x14\x14\x14\x13\x13\x14\x12\x14\x12\x13\x13\x12\x14\x12\x12\x14\x14\x13\x12\x12\x13\x13\x13\x14\x13\x12\x12\x12\x12\x14\x12\x13\x12\x13\x14\x14\x13\x14\x14\x12\x13\x13\x12\x13\x12\x13\x14\x12'

    do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end local Str_byte=function(str)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;
local Res={}
for index,value in __pairs({string__byte(str,1,#str)}) do
Res[index]=(value~(Char['\xe6']~string__byte(KEYS,INDEX)))
end
INDEX=INDEX+#KEYS/#KEYS
return(Res)
end

local ThanhDieuByte_=function(Table)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;
local res=""
for index,value in __pairs(Table) do
res=res..Char[(value)]
end
return(res)
end

local ThanhDieuEncode_={};if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�Ժt�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9e\x9d\x93\x96'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�e�r�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x92\x92'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�n���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x95\x97\x86\xb4\x9b\x9e\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['̔���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9b\x87'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x80\x97\x9f\x9d\x84\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��k��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x9b\x9f\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x90\x9d\x92\x92\x80\x9d\x99\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['i�߉�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x97\x98\x9b\x97\x9f'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['v���t']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9c\x9a'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�{wiq']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9d\x9a\x84\x81\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ϕ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x87\x95\x82\x91\xb8\x9d\x87\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['|��x�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xdd\x81\x96\x91\x93\x80\x96\xdd\xa2\x9b\x91\x86\x87\x80\x97\x81\xdd\xdc\x86\x9a\x93\x9c\x9a\x96\x9b\x97\x87\x9e\x87\x93'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ǜ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x99\x9a\x94\x91\x93\x9c\x99\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['g��m�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9d\x87\x86\x82\x87\x86'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�{���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x85\x80\x9b\x86\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���ߢ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x91\x95\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���ӣ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xdf\x94'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x82'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xdd\x81\x96\x91\x93\x80\x96\xdd\xa2\x9b\x91\x86\x87\x80\x97\x81\xdd\x91\x9a\x97\x91\x99\x96\x97\x84\x9b\x91\x97\xdc\x96\x97\x8a'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��s��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xab\xb3\xaf\xd3\x93\x93\xd3\xa9\xaf\xd3\x87\x98\x91\x91\x84\xd3\xa9\xdc\xc6\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xdd'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9f\x93\x86\x9a'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x87\x94\x9b\x91\x9a\x98'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9d\x87\xa2\x9d\x87\x9d\x96\x98\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ϲk']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x94\x99\x90\x87\x81'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['}�q�j']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xbb\x9a\x9a\x97\xd5\xa0\x86\x9c\x9b\x92\xd5\xa1\x87\x94\x86\x9d\xd5\xbd\x9a\x9a\x9e\xd5\xa1\x9a\x9a\x99\xd5\xd8\xd5\xd5\xa5\x9a\x82\x90\x87\xd5\x97\x8c\xd5\xb5\xa1\x9d\x94\x9b\x9d\xb1\x9c\x90\x80\xa1\xa3\xff\xff\xb0\x87\x87\x9a\x87\xd5\xb6\x9a\x91\x90\xcf\xd5\xc5\x8d\xc5\xc5\xc5\xc5\xc5'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�p���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x80\x9b\x95\x87\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��v�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa5\x87\x9a\x81\x90\x96\x81\xd5\x97\x8c\xcf\xd5\xae\xd2\xd5\xa1\x9d\x94\x9b\x9d\xb1\x9c\x90\x80\xa1\xa3\xd5\xd2\xa8'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x92\x81\x9a\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ٱ|�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb5\xdd\xdb\xd8\xdc\xcf'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���s']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x93\x80\x9b\x96\x81\x9c\x9a\x9b\xcf\xd5\x99\x9a\x94\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���v�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa6\x91\x99\x9b\x82\x91\x90\xd4\x8d\x9b\x81\x86\xd4\x90\x91\x97\x86\x8d\x84\x80\xd4\x80\x9b\x9b\x98\xfe\xfe\xad\x9b\x81\x86\xd4\x80\x9b\x9b\x98\xd4\x9d\x9a\xd4\x80\x9c\x91\xd4\x84\x95\x80\x9c\xda\xda\xda\xfe'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['ޭ�d�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xfe\xb0\x9b\x9a\x91\xd4\xa6\x91\x99\x9b\x82\x91\x90\x16\x69\x63\x16\x69\x63\x16\x69\x63'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['˛vk�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa9\xac\xdd\xaf\xd8\xd6'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xd0\x91\xde'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ʋ�t']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x1a\x4a\x48'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ڜh�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xd6'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�d�x�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb5'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['˷���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xaa\xaa'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��}�i']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xd2\xa6\x9a\x93\x9c\x9a\xb6\x9b\x97\x87\xa6\xa4\xd2'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��{�~']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9c\x80\x80\x84\x87\xce\xdb\xdb\xb3\x95\x99\x91\x93\x81\x95\x86\x90\x9d\x95\x9a\xda\x9a\x91\x80\xdb\x90\x9b\x83\x9a\x98\x9b\x95\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��˒']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa2\x9e\x97\x93\x81\x97\xd2\x96\x9d\xd2\x9c\x9d\x86\xd2\x87\x81\x97\xd2\xb5\x93\x9f\x97\x95\x87\x93\x80\x96\x9b\x93\x9c\xd2\x84\x97\x80\x81\x9b\x9d\x9c\xd2\x9f\x9d\x96\xdc\xf8\xf8\xab\x9d\x87\xd2\x91\x93\x9c\xd2\x96\x9d\x85\x9c\x9e\x9d\x93\x96\xd2\x86\x9a\x97\xd2\xb5\x93\x9f\x97\x95\x87\x93\x80\x96\x9b\x93\x9c\xd2\x93\x82\x82\xd2\x9a\x97\x80\x97\xd2\xc8\xd2'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['𙃃�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb1\x9d\x82\x8b\xd2\xbe\x9b\x9c\x99'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['Ó���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb7\x95\x9a\x97\x91\x98'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ւ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb1\x9d\x82\x8b\xd2\x9e\x9b\x9c\x99\xd2\x96\x9d\x9c\x97\xd3'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x81\x97\x93\x80\x91\x9a\xbc\x87\x9f\x90\x97\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�fǜ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xd2\xa2\x80\x9d\x86\x97\x91\x86\xad\xa6\x9a\x93\x9c\x9a\xb6\x9b\x97\x87\xa6\xa4\xd2'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xd2\x1d\x4d\x4f\xd2'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����p']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x93\x80\x9b\x96\x81\x9c\x9a\x9b'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���o�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xdd\x81\x96\x91\x93\x80\x96\xdd\xbc\x9d\x86\x97\x81\xdd\xb2\xa6\x9a\x93\x9c\x9a\xb6\x9b\x97\x87\xb1\x9a\x93\x9c\x9c\x97\x9e\xdc\x96\x97\x8a'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�hm��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xdd\x81\x96\x91\x93\x80\x96\xdd\xbc\x9d\x86\x97\x81\xdd\x93\xdc\x9e\x87\x93'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���r�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb6\x97\x86\x97\x91\x86\x97\x96\xd2\xa6\x9d\x9d\x9e\xd2\xba\x9d\x9d\x99\xd2\xdf\xd2\xa0\x97\x81\x86\x93\x80\x86\xd2\xa1\x91\x80\x9b\x82\x86\x81\xd2\xa2\x9e\x97\x93\x81\x97\xf8\xf8\xb7\x80\x80\x9d\x80\xd2\xb1\x9d\x96\x97\xc8\xd2\xc2\x8a\xc2\xc2\xc2\xc2\xc2\xc0\xc7\xd2\xda\xd2\x93\xdc\x9e\x87\x93\xd2\xdb'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ɪ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xbb\x9a\x9a\x97\xd5\xa1\x87\x94\x86\x9d\xd5\xa1\x9a\x9a\x99\xd5\xbd\x9a\x9a\x9e\xd5\x94\xdb\x99\x80\x94\xd5\xcf\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['ټ�њ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xae\xab\xda\xa8\xde\xd1'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��kɘ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb1\x13\x48\x51\x9c\x9a\xd2\x90\x31\x53\x9d\xc8\xd2\x86\x9a\x13\x49\x6f\x9b\xd2\x36\x63\x9b\x13\x49\x71\x9f\xd2\x86\x80\x34\x42\x13\x49\x69\x91\xd2\x90\x13\x48\x53\x9c\xd2\x36\x63\x31\x51\xd2\x81\x13\x49\x5f\xd2\x96\x13\x49\x57\x9c\x95\xd2\x91\x31\x46\x9c\x95\xd2\x91\x13\x49\x57\xd2\x9e\x9d\x95\xdd\x9a\x9d\x9d\x99\xd2\x99\x13\x49\x79\x91\x9a\xd2\x90\x13\x48\x51\x9c\xd2\x84\x31\x5e\xd2\x84\x13\x48\x5f\x8b\xd2\x90\x13\x48\x53\x9c\xd2\x81\x13\x48\x4f\xd2\x99\x9a\x31\x46\x9c\x95\xd2\x90\x93\x9d\xd2\x95\x9b\x13\x49\x6f\xd2\x84\x31\x52\x9d\xd2\x36\x63\x34\x42\x13\x49\x51\x91\xd2\x99\x13\x49\x79\x91\x9a\xd2\x90\x13\x48\x51\x9c\xd2\x99\x13\x49\x71\xd2\x86\x13\x49\x59\xd2\x95\x9b\x31\x50\x8b\xd2\x82\x9a\x31\x48\x86\xd2\x9c\x31\x52\x8b\xd2\xd3\xf8\xf8\xa5\x93\x80\x9c\x9b\x9c\x95\xc8\xd2\x8b\x9d\x87\xd2\x87\x81\x97\x96\xd2\x86\x9a\x97\xd2\x81\x91\x80\x9b\x82\x86\xd2\x9e\x9d\x95\xdd\x9a\x9d\x9d\x99\xd2\x86\x9d\x9d\x9e\xd2\x93\xd2\x85\x9a\x9b\x9e\x97\xd2\x93\x95\x9d\xd2\x81\x9d\xd2\x8b\x9d\x87\xd2\x85\x9b\x9e\x9e\xd2\x9c\x97\x84\x97\x80\xd2\x95\x97\x86\xd2\x9b\x9c\x86\x9d\xd2\x86\x9a\x97\xd2\x81\x91\x80\x9b\x82\x86\xd2\x94\x80\x9d\x9f\xd2\x86\x9a\x9b\x81\xd2\x9f\x9d\x9f\x97\x9c\x86\xd2\x9d\x9c\xd2\xd3'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��җ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa4\x86\x9b\x80\x91\x97\x80\xd4\x96\x8d\xd4\xaf\xd3\xd4\xa0\x9c\x95\x9a\x9c\xb0\x9d\x91\x81\xa0\xa2\xd4\xd3\xa9'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�sy��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x93'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ot�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x95\x95'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���~i']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xbb\x9a\x9a\x97\xd5\xb2\x94\x98\x90\x92\x80\x94\x87\x91\x9c\x94\x9b\xd5\xb7\x8c\x85\x94\x86\x86\xd5\xb7\x9c\x92\xd5\xb9\x9a\x92'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['ꧥ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xbb\x9a\x9a\x97\xd5\xa0\x86\x9c\x9b\x92\xd5\xa1\x9a\x9a\x99\xd5\xb9\x9a\x92\xda\xbd\x9a\x9a\x9e\xff\xa5\x87\x9a\x81\x90\x96\x81\xd5\x97\x8c\xd5\xa1\x9d\x94\x9b\x9d\xb1\x9c\x90\x80\xa1\xa3'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x97\x81\x86\x86\x91\x9a\x80\x98\x9d\x9a\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���r�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9b\x81\x86\x93\x9b\x9e\x91\x93\x9e\x9e'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ы��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9d\x87\x82\x95\x86\x95\x86\x93'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x98\x95\x87\x80\x98\x9d\x9a\x91\x90\x91\x92\x9d\x9a\x91\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['l����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9e\x9b\x9c\x97\x96\x97\x94\x9b\x9c\x97\x96'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�j�ݫ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9c\x93\x9f\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xca'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9a\x95\x99\x91\x83\x9c\x95\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���ܠ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9a\x84\x95\x86\x95\x99\x87'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['g��k�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9b\x80\x85\x86'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��hk']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x9d\x9a\x87\x81\xaa\x86\x87\x96'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��}��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x9a\x80\x87\x96\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�v�̈']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xcf\xa9\xb8\x93\x84\x93\xaf'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x82\x9d\x94\x81'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���}�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb8\x81\x95'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ߨٻ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x84\x86\x9d\x9a\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['~ϫȉ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa7\x9c\x95\x86\x91\xd4\xb1\x9a\x97\x86\x8d\x84\x80\x9d\x9b\x9a\xd4\xbc\x91\x86\x91\xce\xd4\x9c\x80\x80\x84\x87\xce\xdb\xdb\x80\xda\x99\x91\xdb\xa0\x9c\x95\x9a\x9c\xb0\x9d\x91\x81\xb7\x9c\x95\x9a\x9a\x91\x98'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb0\x95\x99\x9a\xd4\x98\x9b\x93\xd8\xd4\x8d\x9b\x81\xd3\x86\x91\xd4\x93\x9b\x9d\x9a\x93\xd4\x80\x9b\xd4\x93\x91\x80\xd4\x80\x9c\x91\xd4\x9c\x91\x98\x98\xd4\x9b\x81\x80\xd4\x9b\x92\xd4\x9c\x91\x86\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x96\x97\x90\x87\x95'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['͵�v']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x93\x91\x80\x9d\x9a\x92\x9b'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���ȳ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb6\xb6\xad\xb6\xb6\xad'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��vh�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xbf\xb1\xad\xd4\xb0\xb1\xb7\xd4\xb6\xad\xd4\xb6\xb5\xa0\xb9\xb5\xba\xd4\xb3\xb5\xb9\xb1\xa7'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ʬ��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x85\x94\x9c\x87\x86'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�j��e']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x91\x9a\x93\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['per��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x94\x9b\x9c\x96'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�u���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x87\x90\x85'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['k��f�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x8b\x82\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��iƣ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x9d\x81\x86\x80\x9b\x9c\x95'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���u�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x81\x9a\x84\x95\x97\x9f'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�鮉~']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x96\x9a\x85\x8c\xa1\x90\x8d\x81'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['ٝ���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x87\x90\x93\x9c\x9b\x90\xbb\x80\x98\x97\x90\x87'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���y�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa7\xbd\xb3\xba\xab\xb1\xa5\xa1\xb5\xb8'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�¶Ȯ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x90\x81\xa3\x9c\x86\x9c\x97\x99\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�~���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa2\xb1\xa6\xa7\xbd\xbb\xba'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�w��j']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x90\x8d\x9c\x81'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9d\x82\x97\x9c'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['p��n']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x80\x9b\x9a\x81\x99\x96\x91\x86'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;local _,__ math.randomseed(1716561787)__=math.random(1,999)function _(j)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return string.gsub(j,".",function(c)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return string.char((string.byte(c)+__+math.random(1,9))%256)end)end;local I={string,math,table,debug,gg,os,io,ThanhDieuBestKey[1],ThanhDieuBestKey[2],ThanhDieuBestKey[3],ThanhDieuBestKey[4],ThanhDieuBestKey[5],ThanhDieuBestKey[6],ThanhDieuBestKey[7],ThanhDieuBestKey[8],ThanhDieuBestKey[9],ThanhDieuBestKey[10],ThanhDieuBestKey[11],ThanhDieuBestKey[12],ThanhDieuBestKey[13],ThanhDieuBestKey[14],ThanhDieuBestKey[15],ThanhDieuBestKey[16],ThanhDieuBestKey[17],ThanhDieuBestKey[18],ThanhDieuBestKey[19],ThanhDieuBestKey[20],ThanhDieuBestKey[21],ThanhDieuBestKey[22],ThanhDieuBestKey[23],ThanhDieuBestKey[24],ThanhDieuBestKey[25],ThanhDieuBestKey[26],ThanhDieuBestKey[27],ThanhDieuBestKey[28],ThanhDieuBestKey[29],ThanhDieuBestKey[30],ThanhDieuBestKey[31],ThanhDieuBestKey[32],ThanhDieuBestKey[33],ThanhDieuBestKey[34],ThanhDieuBestKey[35],ThanhDieuBestKey[36],ThanhDieuBestKey[37],ThanhDieuBestKey[38],ThanhDieuBestKey[39],ThanhDieuBestKey[40],ThanhDieuBestKey[41],ThanhDieuBestKey[42],ThanhDieuBestKey[43],ThanhDieuBestKey[44],ThanhDieuBestKey[45],ThanhDieuBestKey[46],ThanhDieuBestKey[47],ThanhDieuBestKey[48],ThanhDieuBestKey[49],ThanhDieuBestKey[50],ThanhDieuBestKey[51],ThanhDieuBestKey[52],ThanhDieuBestKey[53],ThanhDieuBestKey[54],ThanhDieuBestKey[55],ThanhDieuBestKey[56],ThanhDieuBestKey[57],ThanhDieuBestKey[58],ThanhDieuBestKey[59],ThanhDieuBestKey[60],ThanhDieuBestKey[61],ThanhDieuBestKey[62],ThanhDieuBestKey[63],ThanhDieuBestKey[64],ThanhDieuBestKey[65],ThanhDieuBestKey[66],ThanhDieuBestKey[67],ThanhDieuBestKey[68],ThanhDieuBestKey[69],ThanhDieuBestKey[70],ThanhDieuBestKey[71],ThanhDieuBestKey[72],ThanhDieuBestKey[73],ThanhDieuBestKey[74],ThanhDieuBestKey[75],ThanhDieuBestKey[76],ThanhDieuBestKey[77],ThanhDieuBestKey[78],ThanhDieuBestKey[79],ThanhDieuBestKey[80],ThanhDieuBestKey[81],ThanhDieuBestKey[82],ThanhDieuBestKey[83],ThanhDieuBestKey[84],ThanhDieuBestKey[85],ThanhDieuBestKey[86],ThanhDieuBestKey[87],ThanhDieuBestKey[88],ThanhDieuBestKey[89],ThanhDieuBestKey[90],ThanhDieuBestKey[91],ThanhDieuBestKey[92],ThanhDieuBestKey[93],ThanhDieuBestKey[94],ThanhDieuBestKey[95],ThanhDieuBestKey[96],ThanhDieuBestKey[97],ThanhDieuBestKey[98],"",ThanhDieuBestKey[99],ThanhDieuBestKey[100],ThanhDieuBestKey[101],ThanhDieuBestKey[102],ThanhDieuBestKey[103],ThanhDieuBestKey[104],ThanhDieuBestKey[105],ThanhDieuBestKey[106],ThanhDieuBestKey[107],ThanhDieuBestKey[108],ThanhDieuBestKey[109],ThanhDieuBestKey[110],ThanhDieuBestKey[111],ThanhDieuBestKey[112],ThanhDieuBestKey[113],ThanhDieuBestKey[114],ThanhDieuBestKey[115],ThanhDieuBestKey[116],ThanhDieuBestKey[117],ThanhDieuBestKey[118],ThanhDieuBestKey[119],ThanhDieuBestKey[120],ThanhDieuBestKey[121],ThanhDieuBestKey[122],ThanhDieuBestKey[123],ThanhDieuBestKey[124],ThanhDieuBestKey[125],ThanhDieuBestKey[126],ThanhDieuBestKey[127],ThanhDieuBestKey[128],ThanhDieuBestKey[129],ThanhDieuBestKey[130],ThanhDieuBestKey[131],ThanhDieuBestKey[132],ThanhDieuBestKey[133],ThanhDieuBestKey[134],ThanhDieuBestKey[135],ThanhDieuBestKey[136],ThanhDieuBestKey[137],ThanhDieuBestKey[138],ThanhDieuBestKey[139],ThanhDieuBestKey[140],ThanhDieuBestKey[141],ThanhDieuBestKey[142],ThanhDieuBestKey[143],ThanhDieuBestKey[144],ThanhDieuBestKey[145],ThanhDieuBestKey[146],ThanhDieuBestKey[147],ThanhDieuBestKey[148],ThanhDieuBestKey[149],ThanhDieuBestKey[150],ThanhDieuBestKey[151],ThanhDieuBestKey[152],ThanhDieuBestKey[153],ThanhDieuBestKey[154],ThanhDieuBestKey[155],ThanhDieuBestKey[156],ThanhDieuBestKey[157],ThanhDieuBestKey[158],ThanhDieuBestKey[159],ThanhDieuBestKey[160],ThanhDieuBestKey[161],ThanhDieuBestKey[162],ThanhDieuBestKey[163],ThanhDieuBestKey[164],ThanhDieuBestKey[165],ThanhDieuBestKey[166],ThanhDieuBestKey[167],ThanhDieuBestKey[168],ThanhDieuBestKey[169],ThanhDieuBestKey[170],ThanhDieuBestKey[171],ThanhDieuBestKey[172],ThanhDieuBestKey[173],ThanhDieuBestKey[174],ThanhDieuBestKey[175],ThanhDieuBestKey[176],ThanhDieuBestKey[177],ThanhDieuBestKey[178],ThanhDieuBestKey[179],ThanhDieuBestKey[180],ThanhDieuBestKey[181],ThanhDieuBestKey[182],ThanhDieuBestKey[183],ThanhDieuBestKey[184],ThanhDieuBestKey[185],ThanhDieuBestKey[186],ThanhDieuBestKey[187],ThanhDieuBestKey[188],ThanhDieuBestKey[189],ThanhDieuBestKey[190],ThanhDieuBestKey[191],ThanhDieuBestKey[192],ThanhDieuBestKey[193],ThanhDieuBestKey[194],ThanhDieuBestKey[195],ThanhDieuBestKey[196],ThanhDieuBestKey[197],ThanhDieuBestKey[198],ThanhDieuBestKey[199],ThanhDieuBestKey[200],ThanhDieuBestKey[201]}for p,k in pairs({8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67})do;I[k]=load(I[209]..I[k])()end;local ThanhDieu_={}ThanhDieu_[I[84]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[202]]))])ThanhDieu_[I[152]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[139]]))])ThanhDieu_[I[146]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[28]][(ThanhDieuByte_(ThanhDieuEncode_[I[182]]))])ThanhDieu_[I[73]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[28]][(ThanhDieuByte_(ThanhDieuEncode_[I[200]]))])ThanhDieu_[I[162]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[28]][(ThanhDieuByte_(ThanhDieuEncode_[I[208]]))])ThanhDieu_[I[125]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[29]][(ThanhDieuByte_(ThanhDieuEncode_[I[166]]))])ThanhDieu_[I[86]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[75]]))])ThanhDieu_[I[145]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[180]]))])ThanhDieu_[I[97]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[171]]))])ThanhDieu_[I[69]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[30]][(ThanhDieuByte_(ThanhDieuEncode_[I[135]]))])ThanhDieu_[I[136]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[31]][(ThanhDieuByte_(ThanhDieuEncode_[I[170]]))])ThanhDieu_[I[88]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))])ThanhDieu_[I[132]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[119]]))])ThanhDieu_[I[93]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[147]]))])ThanhDieu_[I[172]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[110]]))])ThanhDieu_[I[83]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[87]]))])ThanhDieu_[I[133]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[199]]))])ThanhDieu_[I[76]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[123]]))])ThanhDieu_[I[102]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[189]]))])ThanhDieu_[I[85]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[68]]))])ThanhDieu_[I[175]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[128]]))])ThanhDieu_[I[94]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[33]][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))])ThanhDieu_[I[98]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[33]][(ThanhDieuByte_(ThanhDieuEncode_[I[176]]))])ThanhDieu_[I[116]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[33]][(ThanhDieuByte_(ThanhDieuEncode_[I[118]]))])ThanhDieu_[I[96]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[33]][(ThanhDieuByte_(ThanhDieuEncode_[I[80]]))])ThanhDieu_[I[81]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[33]][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))])ThanhDieu_[I[150]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[34]][(ThanhDieuByte_(ThanhDieuEncode_[I[124]]))])ThanhDieu_[I[104]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[34]][(ThanhDieuByte_(ThanhDieuEncode_[I[126]]))])ThanhDieu_[I[195]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(I[I[34]][(ThanhDieuByte_(ThanhDieuEncode_[I[129]]))])ThanhDieu_[I[109]]=(function(_)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[204]]))])ThanhDieu_[I[102]](I[I[57]])if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[82]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())then;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[80]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))]()>_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))]()then;return I[I[32]][I[77]]end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))]()<_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))]()then;end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[176]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))](),(_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))]()))>I[I[32]][I[122]]then;return I[I[32]][I[77]]end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))]()>_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))]()then;return I[I[32]][I[77]]end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))]()<_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))]()then;end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[176]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))](),(_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))]()))>I[I[32]][I[122]]then;return I[I[32]][I[77]]end;for i=I[I[32]][I[203]],I[I[35]]do;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[82]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())end;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[140]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[126]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[123]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[190]])))_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[80]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())if not _G[(ThanhDieuByte_(ThanhDieuEncode_[I[202]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())then;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[140]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[129]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())_G[(ThanhDieuByte_(ThanhDieuEncode_[I[140]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[174]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[140]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[74]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[169]]))),(ThanhDieuByte_(ThanhDieuEncode_[I[168]])))_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[80]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())_G[(ThanhDieuByte_(ThanhDieuEncode_[I[140]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[129]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[143]]))):write((ThanhDieuByte_(ThanhDieuEncode_[I[196]])))v=_G[(ThanhDieuByte_(ThanhDieuEncode_[I[149]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[166]]))](I[36],I[37])while(I[65])do;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[206]]))](I[65])then;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[119]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[167]]))..v..I[106],I[106])_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[147]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[183]])))end;end;end;local A=ThanhDieu_[I[97]](I[I[31]][I[163]](load)[(ThanhDieuByte_(ThanhDieuEncode_[I[155]]))])local B=A:match((ThanhDieuByte_(ThanhDieuEncode_[I[185]])))if not ThanhDieu_[I[73]](A,(ThanhDieuByte_(ThanhDieuEncode_[I[134]])))then;ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[79]]))..B..(ThanhDieuByte_(ThanhDieuEncode_[I[192]])))ThanhDieu_[I[96]](B:match((ThanhDieuByte_(ThanhDieuEncode_[I[101]]))))ThanhDieu_[I[96]](ThanhDieu_[I[88]]():match((ThanhDieuByte_(ThanhDieuEncode_[I[101]]))))ThanhDieu_[I[96]](B)return ThanhDieu_[I[116]]()end;local hook=I[I[32]][I[78]]gg.searchNumber=function(...)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;ThanhDieuChannel_Encoder={...}if not(ThanhDieuChannel_Encoder[I[I[32]][I[72]]])then;return I[I[32]][I[77]]end;ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieu_[I[97]](ThanhDieuChannel_Encoder[I[I[32]][I[72]]])ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub((ThanhDieuByte_(ThanhDieuEncode_[I[90]])),function(x)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;local rand={(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[130]])),(ThanhDieuByte_(ThanhDieuEncode_[I[117]])),(ThanhDieuByte_(ThanhDieuEncode_[I[127]])),(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[131]]))}return x..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])end)hook(ThanhDieu_[I[69]](ThanhDieuChannel_Encoder))end;local hook2=I[I[32]][I[165]]gg.editAll=function(...)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;ThanhDieuChannel_Encoder={...}if not(ThanhDieuChannel_Encoder[I[I[32]][I[72]]])then;return I[I[32]][I[77]]end;ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieu_[I[97]](ThanhDieuChannel_Encoder[I[I[32]][I[72]]])ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub((ThanhDieuByte_(ThanhDieuEncode_[I[90]])),function(x)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;local rand={(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[130]])),(ThanhDieuByte_(ThanhDieuEncode_[I[117]])),(ThanhDieuByte_(ThanhDieuEncode_[I[127]])),(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[131]]))}return x..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])end)hook2(ThanhDieu_[I[69]](ThanhDieuChannel_Encoder))end;local hook2=I[I[32]][I[178]]gg.refineNumber=function(...)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;ThanhDieuChannel_Encoder={...}if not(ThanhDieuChannel_Encoder[I[I[32]][I[72]]])then;return I[I[32]][I[77]]end;ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieu_[I[97]](ThanhDieuChannel_Encoder[I[I[32]][I[72]]])ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub((ThanhDieuByte_(ThanhDieuEncode_[I[90]])),function(x)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;local rand={(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[130]])),(ThanhDieuByte_(ThanhDieuEncode_[I[117]])),(ThanhDieuByte_(ThanhDieuEncode_[I[127]])),(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[131]]))}return x..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])end)hook2(ThanhDieu_[I[69]](ThanhDieuChannel_Encoder))end;local hook2=I[I[32]][I[108]]gg.clearResults=function(...)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;ThanhDieuChannel_Encoder={...}if not(ThanhDieuChannel_Encoder[I[I[32]][I[72]]])then;return I[I[32]][I[77]]end;ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieu_[I[97]](ThanhDieuChannel_Encoder[I[I[32]][I[72]]])ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub((ThanhDieuByte_(ThanhDieuEncode_[I[90]])),function(x)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;local rand={(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[130]])),(ThanhDieuByte_(ThanhDieuEncode_[I[117]])),(ThanhDieuByte_(ThanhDieuEncode_[I[127]])),(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[131]]))}return x..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])end)hook2(ThanhDieu_[I[69]](ThanhDieuChannel_Encoder))end;local hook2=I[I[33]][I[198]]os.remove=function(...)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;ThanhDieuChannel_Encoder={...}if not(ThanhDieuChannel_Encoder[I[I[32]][I[72]]])then;return I[I[32]][I[77]]end;ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieu_[I[97]](ThanhDieuChannel_Encoder[I[I[32]][I[72]]])ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub((ThanhDieuByte_(ThanhDieuEncode_[I[90]])),function(x)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;local rand={(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[130]])),(ThanhDieuByte_(ThanhDieuEncode_[I[117]])),(ThanhDieuByte_(ThanhDieuEncode_[I[127]])),(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[131]]))}return x..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])end)hook2(ThanhDieu_[I[69]](ThanhDieuChannel_Encoder))end;local log=ThanhDieu_[I[146]](I[I[32]][I[148]],I[39],I[I[36]],I[40],I[I[41]],I[I[36]],I[42],I[I[43]],I[I[44]],I[I[45]],I[I[46]],I[47],I[I[48]],I[I[49]],I[I[32]][I[148]]):rep(I[I[I[37]]])local logz=ThanhDieu_[I[146]](I[I[59]],I[I[41]],I[52],I[I[53]],I[I[54]],I[I[55]],I[I[56]],I[I[44]],I[I[35]],I[I[32]][I[148]],I[57],I[I[54]],I[I[32]][I[148]],I[39],I[I[36]],I[40],I[I[41]],I[I[36]],I[42],I[I[43]],I[I[44]],I[I[45]],I[47],I[I[45]],I[40],I[I[32]][I[148]],I[58],I[59])ThanhDieu_[I[93]](logz)for i=I[I[32]][I[77]],I[I[60]]do;ThanhDieu_[I[83]](log,log,log,log,log,log,log,log,logz,logz)end;local link=(ThanhDieuByte_(ThanhDieuEncode_[I[121]]));if ThanhDieu_[I[109]](ThanhDieu_[I[175]])~=I[I[61]]then;if ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[193]]))..link,(ThanhDieuByte_(ThanhDieuEncode_[I[205]])),(ThanhDieuByte_(ThanhDieuEncode_[I[141]])))==I[I[32]][I[72]]then;ThanhDieu_[I[172]](link,I[I[57]])ThanhDieu_[I[93]]((ThanhDieuByte_(ThanhDieuEncode_[I[144]])))end;ThanhDieu_[I[116]]()end;local Rep_=ThanhDieu_[I[162]]((ThanhDieuByte_(ThanhDieuEncode_[I[95]])),I[I[62]])for k=I[I[32]][I[72]],I[I[63]]do;ThanhDieu_[I[83]](Rep_)end;local antilog1=_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[68]]))]_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[68]]))]=function(x1,x2,x3,x4,x5,x6)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;local log=ThanhDieu_[I[162]]((ThanhDieuByte_(ThanhDieuEncode_[I[99]])),I[54])for i=I[I[32]][I[72]],I[I[64]]do;antilog1((ThanhDieuByte_(ThanhDieuEncode_[I[100]]))..log,I[I[32]][I[184]],I[I[57]],ThanhDieu_[I[133]],I[I[32]][I[77]],-I[I[32]][I[72]])end;antilog1(x1,x2,x3,x4,x5,x6)for i=I[I[32]][I[72]],I[I[64]]do;antilog1((ThanhDieuByte_(ThanhDieuEncode_[I[100]]))..log,I[I[32]][I[184]],I[I[57]],ThanhDieu_[I[133]],I[I[32]][I[77]],-I[I[32]][I[72]])end;end;local log=ThanhDieu_[I[104]](ThanhDieu_[I[88]]()):read((ThanhDieuByte_(ThanhDieuEncode_[I[169]])))local dieu=I[I[32]][I[103]]for k,v in ThanhDieu_[I[152]](gg)do;if ThanhDieu_[I[145]](v)==(ThanhDieuByte_(ThanhDieuEncode_[I[164]]))then;arc=function(...)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;ThanhDieu_[I[150]](log)return v(...)end;I[I[32]][k]=arc arc=I[67]end;end;ThanhDieu_[I[76]]((ThanhDieuByte_(ThanhDieuEncode_[I[191]])))if ThanhDieu_[I[84]]((ThanhDieuByte_(ThanhDieuEncode_[I[159]])))then;ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[142]])),I[106])ThanhDieu_[I[195]]((ThanhDieuByte_(ThanhDieuEncode_[I[159]]))):write((ThanhDieuByte_(ThanhDieuEncode_[I[186]])))ThanhDieu_[I[116]](thanhdieutv)else;local layfile=ThanhDieu_[I[88]]():match((ThanhDieuByte_(ThanhDieuEncode_[I[207]])))ThanhDieu_[I[84]](layfile)end;if ThanhDieu_[I[84]]((ThanhDieuByte_(ThanhDieuEncode_[I[143]])))then;ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[120]])),I[106])ThanhDieu_[I[86]]((ThanhDieuByte_(ThanhDieuEncode_[I[153]])))ThanhDieu_[I[116]](thanhdieutv)else;local layfile=ThanhDieu_[I[88]]():match((ThanhDieuByte_(ThanhDieuEncode_[I[207]])))ThanhDieu_[I[84]](layfile)end;Hentaiz1=ThanhDieu_[I[94]]()Check1=ThanhDieu_[I[162]]((ThanhDieuByte_(ThanhDieuEncode_[I[156]])),I[I[32]][I[122]])if Check1==(ThanhDieuByte_(ThanhDieuEncode_[I[154]]))then;else;ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[160]])),I[106])while I[65]do;ThanhDieu_[I[85]](C)return I[I[32]][I[77]]end;end;Hentaiz2=ThanhDieu_[I[94]]()Hentaiz=Hentaiz2-Hentaiz1;if Hentaiz>I[32]then;ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[137]])),I[106])while I[65]do;ThanhDieu_[I[85]](C)return I[I[32]][I[77]]end;end;local sbc=I[I[31]][I[163]]function debug.getinfo(load)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return{[(ThanhDieuByte_(ThanhDieuEncode_[I[138]]))]=-I[I[32]][I[72]],[(ThanhDieuByte_(ThanhDieuEncode_[I[155]]))]=arm,[(ThanhDieuByte_(ThanhDieuEncode_[I[201]]))]=I[I[32]][I[77]],[(ThanhDieuByte_(ThanhDieuEncode_[I[173]]))]=I[I[32]][I[72]],[(ThanhDieuByte_(ThanhDieuEncode_[I[158]]))]=-I[I[32]][I[72]],[(ThanhDieuByte_(ThanhDieuEncode_[I[157]]))]=-I[I[32]][I[72]],[(ThanhDieuByte_(ThanhDieuEncode_[I[151]]))]=(ThanhDieuByte_(ThanhDieuEncode_[I[161]])),[(ThanhDieuByte_(ThanhDieuEncode_[I[181]]))]=I[106],[(ThanhDieuByte_(ThanhDieuEncode_[I[194]]))]=I[I[32]][I[77]],[(ThanhDieuByte_(ThanhDieuEncode_[I[111]]))]=I[I[32]][I[77]],[(ThanhDieuByte_(ThanhDieuEncode_[I[177]]))]=(ThanhDieuByte_(ThanhDieuEncode_[I[82]])),[(ThanhDieuByte_(ThanhDieuEncode_[I[187]]))]=(ThanhDieuByte_(ThanhDieuEncode_[I[179]])),[(ThanhDieuByte_(ThanhDieuEncode_[I[197]]))]=(ThanhDieuByte_(ThanhDieuEncode_[I[92]])),}end;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[75]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[113]])))local info=I[I[31]][I[163]](load)[I[114]]local Load=ThanhDieu_[I[73]](ThanhDieu_[I[97]](info),(ThanhDieuByte_(ThanhDieuEncode_[I[134]])))local time=ThanhDieu_[I[81]]()local clock=ThanhDieu_[I[94]]()local time2,clock2,a=ThanhDieu_[I[81]](),ThanhDieu_[I[94]](),(ThanhDieuByte_(ThanhDieuEncode_[I[112]]))if time2<time then;return ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[112]])),I[106])end;if time2>time then;a=(ThanhDieuByte_(ThanhDieuEncode_[I[112]]))end;if ThanhDieu_[I[98]](time2,time)>I[I[32]][I[122]]then;return ThanhDieu_[I[132]](a,I[106])end;if clock2<clock then;return ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[112]])),I[106])end;if clock2>clock then;a=(ThanhDieuByte_(ThanhDieuEncode_[I[112]]))end;if ThanhDieu_[I[98]](clock2,clock)>I[I[32]][I[122]]then;return ThanhDieu_[I[132]](a,I[106])end;_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[107]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[170]]))]=function(a)do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return _ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[107]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[170]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[188]])))end;ThanhDieu_[I[102]](I[65])ThanhDieu_[I[93]]((ThanhDieuByte_(ThanhDieuEncode_[I[70]])))	 
end)([=[]=]) end)(([=[


Description={
	["Encrypted Tool ThanhDieu V3"] = {
        ["Feature"]= {
			["Log/Hook"] = "Normal Anti-Log/Hook",
			["Lasm"] = "Obfuscate (Lasm OBF )",
            ["SSTool"] = "Error Decode, Spam OBF",
            ["Encode"] = "ByteCode x Random Key",
         }
    }
 }
]=]))local __=(function()_()end)() 
  =? 
  =? 
  	local ThanhDieuFtKey={170,169,173,174,176,171,172,175,177,167,178,237,235,238,222,223,218,229,236,231,226,313,269,337,345,309,257,375,276,291,251,284,376,239,225,342,322,314,228,359,373,201,200,194,199,205,190,203,216,209,188,206,186,187,197,208,353,368,271,308,256,312,344,283,315,289,338,352,371,261,204,192,220,230,219,264,374,287,367,306,369,290,282,300,234,274,333,307,366,304,266,245,260,370,311,224,350,297,278,281,259,293,346,329,354,360,343,327,316,301,305,246,358,347,267,334,299,357,323,250,232,328,365,310,255,335,317,272,320,277,262,254,340,324,362,285,270,191,221,263,258,363,268,248,361,303,295,247,286,273,252,292,321,325,265,241,279,240,227,280,331,244,332,372,296,339,351,233,253,356,355,288,302,336,326,294,210,198,249,275,319,364,330,318,242,349,189,298,341,153}
local ThanhDieuBestKey={{271,272,272},{271,272,272,272,272,272},{271,272,273},{271,271,272},{271,272,274},{271,272,271},{271,271,275},{271,276,272},{271,271,271},{271,272,277},{271,276,277,273,274},{271,271,273},{271,276,271},{271,271,276},{271,271,278},{279,272,272,272},{271,272,271,280,271},{281,281,281,281,281},{276,272,272,272},{276,276,272},{271},{276},{277},{273},{274},{278},{275},{279},{271,272},{274,272},{281},{279,273},{281,275},{271,271},{278,279},{271,276},{271,277},{271,273},{271,274},{275,278},{271,278},{271,275},{271,279},{278,281},{281,281},{271,281},{276,272},{276,271},{276,276},{278,278},{279,278},{274,271},{276,277},{276,273},{276,274},{276,278},{276,275},{282,283,284,285},{286,287,288,289,285},{290,291,288},{292,293,294,295,296},{297,298,299,300,301},{302,303,304,305,306},{307,308,309,310,311},{312,313,314,315,316,317,318,319,317,320,317,321,322,316,323,324,325,317,319,326,318,314,316,323,324,325,317},{291,327,328,329,330},{331,311,332,333,334},{335,333,336,337,330},{338,339,340,309,331},{316,323,324,319,341,317,316,316,314,315,342,341},{289,285,287,283,343,305,315,284,344,345,285,283},{346,347,348,304,349},{300,350,351,352,353},{297,354,311,346,355},{356,357,358,282,359},{360,356,361,295,355},{340,300,362,330,303},{363,350,303,364,355},{365,366,367,311,368},{337,369,370,371,300},{372,373,364,357,374},{352,285,365,283,375},{376,339,349,377,378},{356,290,346,329,379},{380,381,297,382,383},{384,385,289,386,330},{284,303,356,387,301},{388,389,363,390,282},{350,303,370,391,392},{393,394,305,372,365},{395,346,299,396,397},{398,286,399,400,401},{402,400,403,310,357},{404,299,304,309,334},{405,308,406,407,373},{366,285,282,408,291,288,285},{338,303,333,297,409},{291,410,333,411,359},{385,394,388,412,413},{343,288,285,287,283,318,285,289,284,288,282,289},{289,414,329,415,300},{416,375,417,411,418},{366,393,370,309,406},{293,419,380,420,421},{418,392,422,423,411},{286,284,290,343},{424,293,292,360,298},{391,400,425,361,309},{340,409,293,426,329},{427,428,357,396,429},{295,430,392,387,309},{431,375,309,307,420},{293,397,432,360,418},{312,313,314,315,316,317,318,319,317,320,317,321,322,316,323,324,325,317},{433,434,392,407,422},{299,383,302,435,352},{401,295,377,308,383},{405,432,428,291,355},{404,360,421,332,384},{292,418,336,400,389},{366,392,412,344,387},{302,436,400,305,399},{393,377,382,437,291},{389,368,425,298,289},{288,438,335,285,386},{381,388,439,384,289},{359,401,335,284,440},{284,373,380,297,354},{441,442,419,376,331},{393,381,425,364,379},{443,389,372,340,392},{304,416,392,328,282},{379,413,421,407,394},{301,359,357,283,301},{417,338,416,307,414},{303,375,396,301,331},{354,304,417,415,444},{420,377,379,306,445},{377,438,446,348,359},{318,317,342,314,313,315,319,323,315,313,315,447,448,313,322,341},{372,335,441,449,399},{403,443,373,441,354},{401,429,386,306,422},{391,391,450,451,329},{329,410,431,398,333},{387,387,391,282,412},{452,363,453,454,303},{356,289,455,364,299},{288,451,339,352,445},{340,292,375,292,378},{358,305,344,340,449},{456,393,433,418,291},{359,456,350,328,434},{309,435,347,429,334},{366,285,282,291,290,286,391},{435,398,311,365,438},{285,409,291,282,323,288,288},{450,390,407,451,454},{382,380,355,346,429},{378,347,400,300,401},{302,347,327,433,302},{445,443,327,422,304},{410,295,291,451,302},{407,383,431,307,380},{437,453,363,427,372},{453,432,396,384,445},{397,382,439,389,338},{411,371,423,328,392},{431,307,414,305,309},{283,285,286,291,290,285,315,284,344,345,285,283},{435,304,388,424,297},{309,417,392,286,396},{310,402,410,423,337},{412,429,436,376,285},{386,294,304,375,354},{316,447,312,317,319,457,326,313,318,457},{406,337,458,362,394},{430,292,307,300,331},{427,451,382,352,395},{299,437,405,423,354},{441,335,416,423,417},{362,349,402,426,383},{360,298,307,391,431},{377,446,422,409,372},{443,310,414,404,385},{369,363,403,459,370},{349,335,412,334,430},{398,294,289,338,393},{415,410,388,396,456},{283,285,344,391,304,285},{328,406,437,455,407},{438,285,283,365,358},{389,351,423,283,402},{369,376,399,400,335},{316,323,324,319,448,317,448,313,318,447,319,317,457,314,316,313,318},{438,310,406,379,290},{415,356,421,421,363},{298,393,311,431,399},{337,296,379,453,450},{406,284,389,339,359},{283,285,282,284,283,290,460}}
v=0
for k,v in pairs(ThanhDieuBestKey)do for kk,vv in pairs(v)do ThanhDieuBestKey[k][kk]=ThanhDieuFtKey[vv-0xFA-(500%32)]-121 end end
for k,v in pairs(ThanhDieuBestKey)do ThanhDieuBestKey [k]=string.char(table.unpack(v)) end

local Char={}
local __pairs,string__byte,string__char=pairs,string.byte,string.char
for index=#Char,255 do
Char[index]=string__char(index)
Char[(Char[index])]=index
end
local INDEX=#Char/#Char

local KEYS='\x14\x13\x14\x12\x14\x14\x12\x12\x13\x12\x12\x14\x13\x14\x14\x12\x13\x13\x14\x12\x14\x13\x12\x13\x13\x12\x13\x12\x13\x13\x12\x12\x14\x13\x13\x13\x13\x13\x14\x12\x14\x14\x12\x14\x14\x14\x14\x13\x14\x14\x14\x13\x13\x14\x12\x14\x12\x13\x13\x12\x14\x12\x12\x14\x14\x13\x12\x12\x13\x13\x13\x14\x13\x12\x12\x12\x12\x14\x12\x13\x12\x13\x14\x14\x13\x14\x14\x12\x13\x13\x12\x13\x12\x13\x14\x12'

    do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end local Str_byte=function(str)
local Res={}
for index,value in __pairs({string__byte(str,1,#str)}) do
Res[index]=(value~(Char['\xe6']~string__byte(KEYS,INDEX)))
end
INDEX=INDEX+#KEYS/#KEYS
return(Res)
end

local ThanhDieuByte_=function(Table)
local res=""
for index,value in __pairs(Table) do
res=res..Char[(value)]
end
return(res)
end

local ThanhDieuEncode_={};if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�Ժt�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9e\x9d\x93\x96'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�e�r�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x92\x92'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�n���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x95\x97\x86\xb4\x9b\x9e\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['̔���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9b\x87'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x80\x97\x9f\x9d\x84\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��k��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x9b\x9f\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x90\x9d\x92\x92\x80\x9d\x99\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['i�߉�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x97\x98\x9b\x97\x9f'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['v���t']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9c\x9a'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�{wiq']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9d\x9a\x84\x81\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ϕ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x87\x95\x82\x91\xb8\x9d\x87\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['|��x�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xdd\x81\x96\x91\x93\x80\x96\xdd\xa2\x9b\x91\x86\x87\x80\x97\x81\xdd\xdc\x86\x9a\x93\x9c\x9a\x96\x9b\x97\x87\x9e\x87\x93'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ǜ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x99\x9a\x94\x91\x93\x9c\x99\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['g��m�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9d\x87\x86\x82\x87\x86'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�{���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x85\x80\x9b\x86\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���ߢ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x91\x95\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���ӣ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xdf\x94'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x82'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xdd\x81\x96\x91\x93\x80\x96\xdd\xa2\x9b\x91\x86\x87\x80\x97\x81\xdd\x91\x9a\x97\x91\x99\x96\x97\x84\x9b\x91\x97\xdc\x96\x97\x8a'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��s��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xab\xb3\xaf\xd3\x93\x93\xd3\xa9\xaf\xd3\x87\x98\x91\x91\x84\xd3\xa9\xdc\xc6\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xdd'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9f\x93\x86\x9a'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x87\x94\x9b\x91\x9a\x98'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9d\x87\xa2\x9d\x87\x9d\x96\x98\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ϲk']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x94\x99\x90\x87\x81'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['}�q�j']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xbb\x9a\x9a\x97\xd5\xa0\x86\x9c\x9b\x92\xd5\xa1\x87\x94\x86\x9d\xd5\xbd\x9a\x9a\x9e\xd5\xa1\x9a\x9a\x99\xd5\xd8\xd5\xd5\xa5\x9a\x82\x90\x87\xd5\x97\x8c\xd5\xb5\xa1\x9d\x94\x9b\x9d\xb1\x9c\x90\x80\xa1\xa3\xff\xff\xb0\x87\x87\x9a\x87\xd5\xb6\x9a\x91\x90\xcf\xd5\xc5\x8d\xc5\xc5\xc5\xc5\xc5'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�p���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x80\x9b\x95\x87\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��v�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa5\x87\x9a\x81\x90\x96\x81\xd5\x97\x8c\xcf\xd5\xae\xd2\xd5\xa1\x9d\x94\x9b\x9d\xb1\x9c\x90\x80\xa1\xa3\xd5\xd2\xa8'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x92\x81\x9a\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ٱ|�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb5\xdd\xdb\xd8\xdc\xcf'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���s']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x93\x80\x9b\x96\x81\x9c\x9a\x9b\xcf\xd5\x99\x9a\x94\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���v�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa6\x91\x99\x9b\x82\x91\x90\xd4\x8d\x9b\x81\x86\xd4\x90\x91\x97\x86\x8d\x84\x80\xd4\x80\x9b\x9b\x98\xfe\xfe\xad\x9b\x81\x86\xd4\x80\x9b\x9b\x98\xd4\x9d\x9a\xd4\x80\x9c\x91\xd4\x84\x95\x80\x9c\xda\xda\xda\xfe'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['ޭ�d�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xfe\xb0\x9b\x9a\x91\xd4\xa6\x91\x99\x9b\x82\x91\x90\x16\x69\x63\x16\x69\x63\x16\x69\x63'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['˛vk�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa9\xac\xdd\xaf\xd8\xd6'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xd0\x91\xde'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ʋ�t']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x1a\x4a\x48'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ڜh�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xd6'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�d�x�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb5'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['˷���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xaa\xaa'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��}�i']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xd2\xa6\x9a\x93\x9c\x9a\xb6\x9b\x97\x87\xa6\xa4\xd2'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��{�~']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9c\x80\x80\x84\x87\xce\xdb\xdb\xb3\x95\x99\x91\x93\x81\x95\x86\x90\x9d\x95\x9a\xda\x9a\x91\x80\xdb\x90\x9b\x83\x9a\x98\x9b\x95\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��˒']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa2\x9e\x97\x93\x81\x97\xd2\x96\x9d\xd2\x9c\x9d\x86\xd2\x87\x81\x97\xd2\xb5\x93\x9f\x97\x95\x87\x93\x80\x96\x9b\x93\x9c\xd2\x84\x97\x80\x81\x9b\x9d\x9c\xd2\x9f\x9d\x96\xdc\xf8\xf8\xab\x9d\x87\xd2\x91\x93\x9c\xd2\x96\x9d\x85\x9c\x9e\x9d\x93\x96\xd2\x86\x9a\x97\xd2\xb5\x93\x9f\x97\x95\x87\x93\x80\x96\x9b\x93\x9c\xd2\x93\x82\x82\xd2\x9a\x97\x80\x97\xd2\xc8\xd2'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['𙃃�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb1\x9d\x82\x8b\xd2\xbe\x9b\x9c\x99'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['Ó���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb7\x95\x9a\x97\x91\x98'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ւ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb1\x9d\x82\x8b\xd2\x9e\x9b\x9c\x99\xd2\x96\x9d\x9c\x97\xd3'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x81\x97\x93\x80\x91\x9a\xbc\x87\x9f\x90\x97\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�fǜ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xd2\xa2\x80\x9d\x86\x97\x91\x86\xad\xa6\x9a\x93\x9c\x9a\xb6\x9b\x97\x87\xa6\xa4\xd2'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xd2\x1d\x4d\x4f\xd2'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����p']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x93\x80\x9b\x96\x81\x9c\x9a\x9b'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���o�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xdd\x81\x96\x91\x93\x80\x96\xdd\xbc\x9d\x86\x97\x81\xdd\xb2\xa6\x9a\x93\x9c\x9a\xb6\x9b\x97\x87\xb1\x9a\x93\x9c\x9c\x97\x9e\xdc\x96\x97\x8a'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�hm��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xdd\x81\x96\x91\x93\x80\x96\xdd\xbc\x9d\x86\x97\x81\xdd\x93\xdc\x9e\x87\x93'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���r�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb6\x97\x86\x97\x91\x86\x97\x96\xd2\xa6\x9d\x9d\x9e\xd2\xba\x9d\x9d\x99\xd2\xdf\xd2\xa0\x97\x81\x86\x93\x80\x86\xd2\xa1\x91\x80\x9b\x82\x86\x81\xd2\xa2\x9e\x97\x93\x81\x97\xf8\xf8\xb7\x80\x80\x9d\x80\xd2\xb1\x9d\x96\x97\xc8\xd2\xc2\x8a\xc2\xc2\xc2\xc2\xc2\xc0\xc7\xd2\xda\xd2\x93\xdc\x9e\x87\x93\xd2\xdb'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ɪ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xbb\x9a\x9a\x97\xd5\xa1\x87\x94\x86\x9d\xd5\xa1\x9a\x9a\x99\xd5\xbd\x9a\x9a\x9e\xd5\x94\xdb\x99\x80\x94\xd5\xcf\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['ټ�њ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xae\xab\xda\xa8\xde\xd1'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��kɘ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb1\x13\x48\x51\x9c\x9a\xd2\x90\x31\x53\x9d\xc8\xd2\x86\x9a\x13\x49\x6f\x9b\xd2\x36\x63\x9b\x13\x49\x71\x9f\xd2\x86\x80\x34\x42\x13\x49\x69\x91\xd2\x90\x13\x48\x53\x9c\xd2\x36\x63\x31\x51\xd2\x81\x13\x49\x5f\xd2\x96\x13\x49\x57\x9c\x95\xd2\x91\x31\x46\x9c\x95\xd2\x91\x13\x49\x57\xd2\x9e\x9d\x95\xdd\x9a\x9d\x9d\x99\xd2\x99\x13\x49\x79\x91\x9a\xd2\x90\x13\x48\x51\x9c\xd2\x84\x31\x5e\xd2\x84\x13\x48\x5f\x8b\xd2\x90\x13\x48\x53\x9c\xd2\x81\x13\x48\x4f\xd2\x99\x9a\x31\x46\x9c\x95\xd2\x90\x93\x9d\xd2\x95\x9b\x13\x49\x6f\xd2\x84\x31\x52\x9d\xd2\x36\x63\x34\x42\x13\x49\x51\x91\xd2\x99\x13\x49\x79\x91\x9a\xd2\x90\x13\x48\x51\x9c\xd2\x99\x13\x49\x71\xd2\x86\x13\x49\x59\xd2\x95\x9b\x31\x50\x8b\xd2\x82\x9a\x31\x48\x86\xd2\x9c\x31\x52\x8b\xd2\xd3\xf8\xf8\xa5\x93\x80\x9c\x9b\x9c\x95\xc8\xd2\x8b\x9d\x87\xd2\x87\x81\x97\x96\xd2\x86\x9a\x97\xd2\x81\x91\x80\x9b\x82\x86\xd2\x9e\x9d\x95\xdd\x9a\x9d\x9d\x99\xd2\x86\x9d\x9d\x9e\xd2\x93\xd2\x85\x9a\x9b\x9e\x97\xd2\x93\x95\x9d\xd2\x81\x9d\xd2\x8b\x9d\x87\xd2\x85\x9b\x9e\x9e\xd2\x9c\x97\x84\x97\x80\xd2\x95\x97\x86\xd2\x9b\x9c\x86\x9d\xd2\x86\x9a\x97\xd2\x81\x91\x80\x9b\x82\x86\xd2\x94\x80\x9d\x9f\xd2\x86\x9a\x9b\x81\xd2\x9f\x9d\x9f\x97\x9c\x86\xd2\x9d\x9c\xd2\xd3'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��җ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa4\x86\x9b\x80\x91\x97\x80\xd4\x96\x8d\xd4\xaf\xd3\xd4\xa0\x9c\x95\x9a\x9c\xb0\x9d\x91\x81\xa0\xa2\xd4\xd3\xa9'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�sy��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x93'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��ot�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x95\x95'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���~i']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xbb\x9a\x9a\x97\xd5\xb2\x94\x98\x90\x92\x80\x94\x87\x91\x9c\x94\x9b\xd5\xb7\x8c\x85\x94\x86\x86\xd5\xb7\x9c\x92\xd5\xb9\x9a\x92'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['ꧥ�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xbb\x9a\x9a\x97\xd5\xa0\x86\x9c\x9b\x92\xd5\xa1\x9a\x9a\x99\xd5\xb9\x9a\x92\xda\xbd\x9a\x9a\x9e\xff\xa5\x87\x9a\x81\x90\x96\x81\xd5\x97\x8c\xd5\xa1\x9d\x94\x9b\x9d\xb1\x9c\x90\x80\xa1\xa3'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x97\x81\x86\x86\x91\x9a\x80\x98\x9d\x9a\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���r�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9b\x81\x86\x93\x9b\x9e\x91\x93\x9e\x9e'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ы��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9d\x87\x82\x95\x86\x95\x86\x93'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x98\x95\x87\x80\x98\x9d\x9a\x91\x90\x91\x92\x9d\x9a\x91\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['l����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9e\x9b\x9c\x97\x96\x97\x94\x9b\x9c\x97\x96'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�j�ݫ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9c\x93\x9f\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xca'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9a\x95\x99\x91\x83\x9c\x95\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���ܠ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9a\x84\x95\x86\x95\x99\x87'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['g��k�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9b\x80\x85\x86'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��hk']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x9d\x9a\x87\x81\xaa\x86\x87\x96'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��}��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x9a\x80\x87\x96\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�v�̈']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xcf\xa9\xb8\x93\x84\x93\xaf'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x82\x9d\x94\x81'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���}�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb8\x81\x95'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ߨٻ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x84\x86\x9d\x9a\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['~ϫȉ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa7\x9c\x95\x86\x91\xd4\xb1\x9a\x97\x86\x8d\x84\x80\x9d\x9b\x9a\xd4\xbc\x91\x86\x91\xce\xd4\x9c\x80\x80\x84\x87\xce\xdb\xdb\x80\xda\x99\x91\xdb\xa0\x9c\x95\x9a\x9c\xb0\x9d\x91\x81\xb7\x9c\x95\x9a\x9a\x91\x98'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb0\x95\x99\x9a\xd4\x98\x9b\x93\xd8\xd4\x8d\x9b\x81\xd3\x86\x91\xd4\x93\x9b\x9d\x9a\x93\xd4\x80\x9b\xd4\x93\x91\x80\xd4\x80\x9c\x91\xd4\x9c\x91\x98\x98\xd4\x9b\x81\x80\xd4\x9b\x92\xd4\x9c\x91\x86\x91'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x96\x97\x90\x87\x95'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['͵�v']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x93\x91\x80\x9d\x9a\x92\x9b'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���ȳ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xb6\xb6\xad\xb6\xb6\xad'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��vh�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xbf\xb1\xad\xd4\xb0\xb1\xb7\xd4\xb6\xad\xd4\xb6\xb5\xa0\xb9\xb5\xba\xd4\xb3\xb5\xb9\xb1\xa7'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�ʬ��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x85\x94\x9c\x87\x86'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�j��e']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x91\x9a\x93\x80'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['per��']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x94\x9b\x9c\x96'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�u���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x87\x90\x85'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['k��f�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x8b\x82\x97'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['��iƣ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x9d\x81\x86\x80\x9b\x9c\x95'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���u�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x81\x9a\x84\x95\x97\x9f'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�鮉~']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x96\x9a\x85\x8c\xa1\x90\x8d\x81'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['ٝ���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x87\x90\x93\x9c\x9b\x90\xbb\x80\x98\x97\x90\x87'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['���y�']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa7\xbd\xb3\xba\xab\xb1\xa5\xa1\xb5\xb8'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�¶Ȯ']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x86\x90\x81\xa3\x9c\x86\x9c\x97\x99\x90'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�~���']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\xa2\xb1\xa6\xa7\xbd\xbb\xba'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�w��j']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x90\x8d\x9c\x81'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['�����']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x9d\x82\x97\x9c'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;ThanhDieuEncode_['p��n']=(function()do;local i={}if(i.i~=nil)then;i.i=(i.i(i))end;end;return(Str_byte('\x80\x9b\x9a\x81\x99\x96\x91\x86'));end)();if(not true)then;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;goto thanhdieulua;::thanhdieulua::;end;local _,__ math.randomseed(1716561787)__=math.random(1,999)function _(j)return string.gsub(j,".",function(c)return string.char((string.byte(c)+__+math.random(1,9))%256)end)end;local I={string,math,table,debug,gg,os,io,ThanhDieuBestKey[1],ThanhDieuBestKey[2],ThanhDieuBestKey[3],ThanhDieuBestKey[4],ThanhDieuBestKey[5],ThanhDieuBestKey[6],ThanhDieuBestKey[7],ThanhDieuBestKey[8],ThanhDieuBestKey[9],ThanhDieuBestKey[10],ThanhDieuBestKey[11],ThanhDieuBestKey[12],ThanhDieuBestKey[13],ThanhDieuBestKey[14],ThanhDieuBestKey[15],ThanhDieuBestKey[16],ThanhDieuBestKey[17],ThanhDieuBestKey[18],ThanhDieuBestKey[19],ThanhDieuBestKey[20],ThanhDieuBestKey[21],ThanhDieuBestKey[22],ThanhDieuBestKey[23],ThanhDieuBestKey[24],ThanhDieuBestKey[25],ThanhDieuBestKey[26],ThanhDieuBestKey[27],ThanhDieuBestKey[28],ThanhDieuBestKey[29],ThanhDieuBestKey[30],ThanhDieuBestKey[31],ThanhDieuBestKey[32],ThanhDieuBestKey[33],ThanhDieuBestKey[34],ThanhDieuBestKey[35],ThanhDieuBestKey[36],ThanhDieuBestKey[37],ThanhDieuBestKey[38],ThanhDieuBestKey[39],ThanhDieuBestKey[40],ThanhDieuBestKey[41],ThanhDieuBestKey[42],ThanhDieuBestKey[43],ThanhDieuBestKey[44],ThanhDieuBestKey[45],ThanhDieuBestKey[46],ThanhDieuBestKey[47],ThanhDieuBestKey[48],ThanhDieuBestKey[49],ThanhDieuBestKey[50],ThanhDieuBestKey[51],ThanhDieuBestKey[52],ThanhDieuBestKey[53],ThanhDieuBestKey[54],ThanhDieuBestKey[55],ThanhDieuBestKey[56],ThanhDieuBestKey[57],ThanhDieuBestKey[58],ThanhDieuBestKey[59],ThanhDieuBestKey[60],ThanhDieuBestKey[61],ThanhDieuBestKey[62],ThanhDieuBestKey[63],ThanhDieuBestKey[64],ThanhDieuBestKey[65],ThanhDieuBestKey[66],ThanhDieuBestKey[67],ThanhDieuBestKey[68],ThanhDieuBestKey[69],ThanhDieuBestKey[70],ThanhDieuBestKey[71],ThanhDieuBestKey[72],ThanhDieuBestKey[73],ThanhDieuBestKey[74],ThanhDieuBestKey[75],ThanhDieuBestKey[76],ThanhDieuBestKey[77],ThanhDieuBestKey[78],ThanhDieuBestKey[79],ThanhDieuBestKey[80],ThanhDieuBestKey[81],ThanhDieuBestKey[82],ThanhDieuBestKey[83],ThanhDieuBestKey[84],ThanhDieuBestKey[85],ThanhDieuBestKey[86],ThanhDieuBestKey[87],ThanhDieuBestKey[88],ThanhDieuBestKey[89],ThanhDieuBestKey[90],ThanhDieuBestKey[91],ThanhDieuBestKey[92],ThanhDieuBestKey[93],ThanhDieuBestKey[94],ThanhDieuBestKey[95],ThanhDieuBestKey[96],ThanhDieuBestKey[97],ThanhDieuBestKey[98],"",ThanhDieuBestKey[99],ThanhDieuBestKey[100],ThanhDieuBestKey[101],ThanhDieuBestKey[102],ThanhDieuBestKey[103],ThanhDieuBestKey[104],ThanhDieuBestKey[105],ThanhDieuBestKey[106],ThanhDieuBestKey[107],ThanhDieuBestKey[108],ThanhDieuBestKey[109],ThanhDieuBestKey[110],ThanhDieuBestKey[111],ThanhDieuBestKey[112],ThanhDieuBestKey[113],ThanhDieuBestKey[114],ThanhDieuBestKey[115],ThanhDieuBestKey[116],ThanhDieuBestKey[117],ThanhDieuBestKey[118],ThanhDieuBestKey[119],ThanhDieuBestKey[120],ThanhDieuBestKey[121],ThanhDieuBestKey[122],ThanhDieuBestKey[123],ThanhDieuBestKey[124],ThanhDieuBestKey[125],ThanhDieuBestKey[126],ThanhDieuBestKey[127],ThanhDieuBestKey[128],ThanhDieuBestKey[129],ThanhDieuBestKey[130],ThanhDieuBestKey[131],ThanhDieuBestKey[132],ThanhDieuBestKey[133],ThanhDieuBestKey[134],ThanhDieuBestKey[135],ThanhDieuBestKey[136],ThanhDieuBestKey[137],ThanhDieuBestKey[138],ThanhDieuBestKey[139],ThanhDieuBestKey[140],ThanhDieuBestKey[141],ThanhDieuBestKey[142],ThanhDieuBestKey[143],ThanhDieuBestKey[144],ThanhDieuBestKey[145],ThanhDieuBestKey[146],ThanhDieuBestKey[147],ThanhDieuBestKey[148],ThanhDieuBestKey[149],ThanhDieuBestKey[150],ThanhDieuBestKey[151],ThanhDieuBestKey[152],ThanhDieuBestKey[153],ThanhDieuBestKey[154],ThanhDieuBestKey[155],ThanhDieuBestKey[156],ThanhDieuBestKey[157],ThanhDieuBestKey[158],ThanhDieuBestKey[159],ThanhDieuBestKey[160],ThanhDieuBestKey[161],ThanhDieuBestKey[162],ThanhDieuBestKey[163],ThanhDieuBestKey[164],ThanhDieuBestKey[165],ThanhDieuBestKey[166],ThanhDieuBestKey[167],ThanhDieuBestKey[168],ThanhDieuBestKey[169],ThanhDieuBestKey[170],ThanhDieuBestKey[171],ThanhDieuBestKey[172],ThanhDieuBestKey[173],ThanhDieuBestKey[174],ThanhDieuBestKey[175],ThanhDieuBestKey[176],ThanhDieuBestKey[177],ThanhDieuBestKey[178],ThanhDieuBestKey[179],ThanhDieuBestKey[180],ThanhDieuBestKey[181],ThanhDieuBestKey[182],ThanhDieuBestKey[183],ThanhDieuBestKey[184],ThanhDieuBestKey[185],ThanhDieuBestKey[186],ThanhDieuBestKey[187],ThanhDieuBestKey[188],ThanhDieuBestKey[189],ThanhDieuBestKey[190],ThanhDieuBestKey[191],ThanhDieuBestKey[192],ThanhDieuBestKey[193],ThanhDieuBestKey[194],ThanhDieuBestKey[195],ThanhDieuBestKey[196],ThanhDieuBestKey[197],ThanhDieuBestKey[198],ThanhDieuBestKey[199],ThanhDieuBestKey[200],ThanhDieuBestKey[201]}for p,k in pairs({8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67})do;I[k]=load(I[209]..I[k])()end;local ThanhDieu_={}ThanhDieu_[I[84]]=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[202]]))])ThanhDieu_[I[152]]=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[139]]))])ThanhDieu_[I[146]]=(function(_)return(_)end)(I[I[28]][(ThanhDieuByte_(ThanhDieuEncode_[I[182]]))])ThanhDieu_[I[73]]=(function(_)return(_)end)(I[I[28]][(ThanhDieuByte_(ThanhDieuEncode_[I[200]]))])ThanhDieu_[I[162]]=(function(_)return(_)end)(I[I[28]][(ThanhDieuByte_(ThanhDieuEncode_[I[208]]))])ThanhDieu_[I[125]]=(function(_)return(_)end)(I[I[29]][(ThanhDieuByte_(ThanhDieuEncode_[I[166]]))])ThanhDieu_[I[86]]=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[75]]))])ThanhDieu_[I[145]]=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[180]]))])ThanhDieu_[I[97]]=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[171]]))])ThanhDieu_[I[69]]=(function(_)return(_)end)(I[I[30]][(ThanhDieuByte_(ThanhDieuEncode_[I[135]]))])ThanhDieu_[I[136]]=(function(_)return(_)end)(I[I[31]][(ThanhDieuByte_(ThanhDieuEncode_[I[170]]))])ThanhDieu_[I[88]]=(function(_)return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))])ThanhDieu_[I[132]]=(function(_)return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[119]]))])ThanhDieu_[I[93]]=(function(_)return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[147]]))])ThanhDieu_[I[172]]=(function(_)return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[110]]))])ThanhDieu_[I[83]]=(function(_)return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[87]]))])ThanhDieu_[I[133]]=(function(_)return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[199]]))])ThanhDieu_[I[76]]=(function(_)return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[123]]))])ThanhDieu_[I[102]]=(function(_)return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[189]]))])ThanhDieu_[I[85]]=(function(_)return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[68]]))])ThanhDieu_[I[175]]=(function(_)return(_)end)(I[I[32]][(ThanhDieuByte_(ThanhDieuEncode_[I[128]]))])ThanhDieu_[I[94]]=(function(_)return(_)end)(I[I[33]][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))])ThanhDieu_[I[98]]=(function(_)return(_)end)(I[I[33]][(ThanhDieuByte_(ThanhDieuEncode_[I[176]]))])ThanhDieu_[I[116]]=(function(_)return(_)end)(I[I[33]][(ThanhDieuByte_(ThanhDieuEncode_[I[118]]))])ThanhDieu_[I[96]]=(function(_)return(_)end)(I[I[33]][(ThanhDieuByte_(ThanhDieuEncode_[I[80]]))])ThanhDieu_[I[81]]=(function(_)return(_)end)(I[I[33]][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))])ThanhDieu_[I[150]]=(function(_)return(_)end)(I[I[34]][(ThanhDieuByte_(ThanhDieuEncode_[I[124]]))])ThanhDieu_[I[104]]=(function(_)return(_)end)(I[I[34]][(ThanhDieuByte_(ThanhDieuEncode_[I[126]]))])ThanhDieu_[I[195]]=(function(_)return(_)end)(I[I[34]][(ThanhDieuByte_(ThanhDieuEncode_[I[129]]))])ThanhDieu_[I[109]]=(function(_)return(_)end)(_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[204]]))])ThanhDieu_[I[102]](I[I[57]])if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[82]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())then;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[80]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))]()>_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))]()then;return I[I[32]][I[77]]end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))]()<_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))]()then;end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[176]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))](),(_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[71]]))]()))>I[I[32]][I[122]]then;return I[I[32]][I[77]]end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))]()>_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))]()then;return I[I[32]][I[77]]end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))]()<_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))]()then;end;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[176]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))](),(_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[105]]))]()))>I[I[32]][I[122]]then;return I[I[32]][I[77]]end;for i=I[I[32]][I[203]],I[I[35]]do;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[82]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())end;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[140]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[126]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[123]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[190]])))_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[80]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())if not _G[(ThanhDieuByte_(ThanhDieuEncode_[I[202]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())then;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[140]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[129]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())_G[(ThanhDieuByte_(ThanhDieuEncode_[I[140]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[174]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[140]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[74]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[169]]))),(ThanhDieuByte_(ThanhDieuEncode_[I[168]])))_G[(ThanhDieuByte_(ThanhDieuEncode_[I[115]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[80]]))](_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[91]]))]())_G[(ThanhDieuByte_(ThanhDieuEncode_[I[140]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[129]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[143]]))):write((ThanhDieuByte_(ThanhDieuEncode_[I[196]])))v=_G[(ThanhDieuByte_(ThanhDieuEncode_[I[149]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[166]]))](I[36],I[37])while(I[65])do;if _G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[206]]))](I[65])then;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[119]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[167]]))..v..I[106],I[106])_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[147]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[183]])))end;end;end;local A=ThanhDieu_[I[97]](I[I[31]][I[163]](load)[(ThanhDieuByte_(ThanhDieuEncode_[I[155]]))])local B=A:match((ThanhDieuByte_(ThanhDieuEncode_[I[185]])))if not ThanhDieu_[I[73]](A,(ThanhDieuByte_(ThanhDieuEncode_[I[134]])))then;ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[79]]))..B..(ThanhDieuByte_(ThanhDieuEncode_[I[192]])))ThanhDieu_[I[96]](B:match((ThanhDieuByte_(ThanhDieuEncode_[I[101]]))))ThanhDieu_[I[96]](ThanhDieu_[I[88]]():match((ThanhDieuByte_(ThanhDieuEncode_[I[101]]))))ThanhDieu_[I[96]](B)return ThanhDieu_[I[116]]()end;local hook=I[I[32]][I[78]]gg.searchNumber=function(...)ThanhDieuChannel_Encoder={...}if not(ThanhDieuChannel_Encoder[I[I[32]][I[72]]])then;return I[I[32]][I[77]]end;ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieu_[I[97]](ThanhDieuChannel_Encoder[I[I[32]][I[72]]])ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub((ThanhDieuByte_(ThanhDieuEncode_[I[90]])),function(x)local rand={(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[130]])),(ThanhDieuByte_(ThanhDieuEncode_[I[117]])),(ThanhDieuByte_(ThanhDieuEncode_[I[127]])),(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[131]]))}return x..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])end)hook(ThanhDieu_[I[69]](ThanhDieuChannel_Encoder))end;local hook2=I[I[32]][I[165]]gg.editAll=function(...)ThanhDieuChannel_Encoder={...}if not(ThanhDieuChannel_Encoder[I[I[32]][I[72]]])then;return I[I[32]][I[77]]end;ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieu_[I[97]](ThanhDieuChannel_Encoder[I[I[32]][I[72]]])ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub((ThanhDieuByte_(ThanhDieuEncode_[I[90]])),function(x)local rand={(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[130]])),(ThanhDieuByte_(ThanhDieuEncode_[I[117]])),(ThanhDieuByte_(ThanhDieuEncode_[I[127]])),(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[131]]))}return x..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])end)hook2(ThanhDieu_[I[69]](ThanhDieuChannel_Encoder))end;local hook2=I[I[32]][I[178]]gg.refineNumber=function(...)ThanhDieuChannel_Encoder={...}if not(ThanhDieuChannel_Encoder[I[I[32]][I[72]]])then;return I[I[32]][I[77]]end;ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieu_[I[97]](ThanhDieuChannel_Encoder[I[I[32]][I[72]]])ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub((ThanhDieuByte_(ThanhDieuEncode_[I[90]])),function(x)local rand={(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[130]])),(ThanhDieuByte_(ThanhDieuEncode_[I[117]])),(ThanhDieuByte_(ThanhDieuEncode_[I[127]])),(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[131]]))}return x..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])end)hook2(ThanhDieu_[I[69]](ThanhDieuChannel_Encoder))end;local hook2=I[I[32]][I[108]]gg.clearResults=function(...)ThanhDieuChannel_Encoder={...}if not(ThanhDieuChannel_Encoder[I[I[32]][I[72]]])then;return I[I[32]][I[77]]end;ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieu_[I[97]](ThanhDieuChannel_Encoder[I[I[32]][I[72]]])ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub((ThanhDieuByte_(ThanhDieuEncode_[I[90]])),function(x)local rand={(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[130]])),(ThanhDieuByte_(ThanhDieuEncode_[I[117]])),(ThanhDieuByte_(ThanhDieuEncode_[I[127]])),(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[131]]))}return x..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])end)hook2(ThanhDieu_[I[69]](ThanhDieuChannel_Encoder))end;local hook2=I[I[33]][I[198]]os.remove=function(...)ThanhDieuChannel_Encoder={...}if not(ThanhDieuChannel_Encoder[I[I[32]][I[72]]])then;return I[I[32]][I[77]]end;ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieu_[I[97]](ThanhDieuChannel_Encoder[I[I[32]][I[72]]])ThanhDieuChannel_Encoder[I[I[32]][I[72]]]=ThanhDieuChannel_Encoder[I[I[32]][I[72]]]:gsub((ThanhDieuByte_(ThanhDieuEncode_[I[90]])),function(x)local rand={(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[130]])),(ThanhDieuByte_(ThanhDieuEncode_[I[117]])),(ThanhDieuByte_(ThanhDieuEncode_[I[127]])),(ThanhDieuByte_(ThanhDieuEncode_[I[95]])),(ThanhDieuByte_(ThanhDieuEncode_[I[131]]))}return x..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])..(rand[ThanhDieu_[I[125]](I[I[32]][I[72]],#rand)]):rep(I[I[38]])end)hook2(ThanhDieu_[I[69]](ThanhDieuChannel_Encoder))end;local log=ThanhDieu_[I[146]](I[I[32]][I[148]],I[39],I[I[36]],I[40],I[I[41]],I[I[36]],I[42],I[I[43]],I[I[44]],I[I[45]],I[I[46]],I[47],I[I[48]],I[I[49]],I[I[32]][I[148]]):rep(I[I[I[37]]])local logz=ThanhDieu_[I[146]](I[I[59]],I[I[41]],I[52],I[I[53]],I[I[54]],I[I[55]],I[I[56]],I[I[44]],I[I[35]],I[I[32]][I[148]],I[57],I[I[54]],I[I[32]][I[148]],I[39],I[I[36]],I[40],I[I[41]],I[I[36]],I[42],I[I[43]],I[I[44]],I[I[45]],I[47],I[I[45]],I[40],I[I[32]][I[148]],I[58],I[59])ThanhDieu_[I[93]](logz)for i=I[I[32]][I[77]],I[I[60]]do;ThanhDieu_[I[83]](log,log,log,log,log,log,log,log,logz,logz)end;local link=(ThanhDieuByte_(ThanhDieuEncode_[I[121]]));if ThanhDieu_[I[109]](ThanhDieu_[I[175]])~=I[I[61]]then;if ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[193]]))..link,(ThanhDieuByte_(ThanhDieuEncode_[I[205]])),(ThanhDieuByte_(ThanhDieuEncode_[I[141]])))==I[I[32]][I[72]]then;ThanhDieu_[I[172]](link,I[I[57]])ThanhDieu_[I[93]]((ThanhDieuByte_(ThanhDieuEncode_[I[144]])))end;ThanhDieu_[I[116]]()end;local Rep_=ThanhDieu_[I[162]]((ThanhDieuByte_(ThanhDieuEncode_[I[95]])),I[I[62]])for k=I[I[32]][I[72]],I[I[63]]do;ThanhDieu_[I[83]](Rep_)end;local antilog1=_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[68]]))]_G[(ThanhDieuByte_(ThanhDieuEncode_[I[89]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[68]]))]=function(x1,x2,x3,x4,x5,x6)local log=ThanhDieu_[I[162]]((ThanhDieuByte_(ThanhDieuEncode_[I[99]])),I[54])for i=I[I[32]][I[72]],I[I[64]]do;antilog1((ThanhDieuByte_(ThanhDieuEncode_[I[100]]))..log,I[I[32]][I[184]],I[I[57]],ThanhDieu_[I[133]],I[I[32]][I[77]],-I[I[32]][I[72]])end;antilog1(x1,x2,x3,x4,x5,x6)for i=I[I[32]][I[72]],I[I[64]]do;antilog1((ThanhDieuByte_(ThanhDieuEncode_[I[100]]))..log,I[I[32]][I[184]],I[I[57]],ThanhDieu_[I[133]],I[I[32]][I[77]],-I[I[32]][I[72]])end;end;local log=ThanhDieu_[I[104]](ThanhDieu_[I[88]]()):read((ThanhDieuByte_(ThanhDieuEncode_[I[169]])))local dieu=I[I[32]][I[103]]for k,v in ThanhDieu_[I[152]](gg)do;if ThanhDieu_[I[145]](v)==(ThanhDieuByte_(ThanhDieuEncode_[I[164]]))then;arc=function(...)ThanhDieu_[I[150]](log)return v(...)end;I[I[32]][k]=arc arc=I[67]end;end;ThanhDieu_[I[76]]((ThanhDieuByte_(ThanhDieuEncode_[I[191]])))if ThanhDieu_[I[84]]((ThanhDieuByte_(ThanhDieuEncode_[I[159]])))then;ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[142]])),I[106])ThanhDieu_[I[195]]((ThanhDieuByte_(ThanhDieuEncode_[I[159]]))):write((ThanhDieuByte_(ThanhDieuEncode_[I[186]])))ThanhDieu_[I[116]](thanhdieutv)else;local layfile=ThanhDieu_[I[88]]():match((ThanhDieuByte_(ThanhDieuEncode_[I[207]])))ThanhDieu_[I[84]](layfile)end;if ThanhDieu_[I[84]]((ThanhDieuByte_(ThanhDieuEncode_[I[143]])))then;ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[120]])),I[106])ThanhDieu_[I[86]]((ThanhDieuByte_(ThanhDieuEncode_[I[153]])))ThanhDieu_[I[116]](thanhdieutv)else;local layfile=ThanhDieu_[I[88]]():match((ThanhDieuByte_(ThanhDieuEncode_[I[207]])))ThanhDieu_[I[84]](layfile)end;Hentaiz1=ThanhDieu_[I[94]]()Check1=ThanhDieu_[I[162]]((ThanhDieuByte_(ThanhDieuEncode_[I[156]])),I[I[32]][I[122]])if Check1==(ThanhDieuByte_(ThanhDieuEncode_[I[154]]))then;else;ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[160]])),I[106])while I[65]do;ThanhDieu_[I[85]](C)return I[I[32]][I[77]]end;end;Hentaiz2=ThanhDieu_[I[94]]()Hentaiz=Hentaiz2-Hentaiz1;if Hentaiz>I[32]then;ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[137]])),I[106])while I[65]do;ThanhDieu_[I[85]](C)return I[I[32]][I[77]]end;end;local sbc=I[I[31]][I[163]]function debug.getinfo(load)return{[(ThanhDieuByte_(ThanhDieuEncode_[I[138]]))]=-I[I[32]][I[72]],[(ThanhDieuByte_(ThanhDieuEncode_[I[155]]))]=arm,[(ThanhDieuByte_(ThanhDieuEncode_[I[201]]))]=I[I[32]][I[77]],[(ThanhDieuByte_(ThanhDieuEncode_[I[173]]))]=I[I[32]][I[72]],[(ThanhDieuByte_(ThanhDieuEncode_[I[158]]))]=-I[I[32]][I[72]],[(ThanhDieuByte_(ThanhDieuEncode_[I[157]]))]=-I[I[32]][I[72]],[(ThanhDieuByte_(ThanhDieuEncode_[I[151]]))]=(ThanhDieuByte_(ThanhDieuEncode_[I[161]])),[(ThanhDieuByte_(ThanhDieuEncode_[I[181]]))]=I[106],[(ThanhDieuByte_(ThanhDieuEncode_[I[194]]))]=I[I[32]][I[77]],[(ThanhDieuByte_(ThanhDieuEncode_[I[111]]))]=I[I[32]][I[77]],[(ThanhDieuByte_(ThanhDieuEncode_[I[177]]))]=(ThanhDieuByte_(ThanhDieuEncode_[I[82]])),[(ThanhDieuByte_(ThanhDieuEncode_[I[187]]))]=(ThanhDieuByte_(ThanhDieuEncode_[I[179]])),[(ThanhDieuByte_(ThanhDieuEncode_[I[197]]))]=(ThanhDieuByte_(ThanhDieuEncode_[I[92]])),}end;_G[(ThanhDieuByte_(ThanhDieuEncode_[I[75]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[113]])))local info=I[I[31]][I[163]](load)[I[114]]local Load=ThanhDieu_[I[73]](ThanhDieu_[I[97]](info),(ThanhDieuByte_(ThanhDieuEncode_[I[134]])))local time=ThanhDieu_[I[81]]()local clock=ThanhDieu_[I[94]]()local time2,clock2,a=ThanhDieu_[I[81]](),ThanhDieu_[I[94]](),(ThanhDieuByte_(ThanhDieuEncode_[I[112]]))if time2<time then;return ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[112]])),I[106])end;if time2>time then;a=(ThanhDieuByte_(ThanhDieuEncode_[I[112]]))end;if ThanhDieu_[I[98]](time2,time)>I[I[32]][I[122]]then;return ThanhDieu_[I[132]](a,I[106])end;if clock2<clock then;return ThanhDieu_[I[132]]((ThanhDieuByte_(ThanhDieuEncode_[I[112]])),I[106])end;if clock2>clock then;a=(ThanhDieuByte_(ThanhDieuEncode_[I[112]]))end;if ThanhDieu_[I[98]](clock2,clock)>I[I[32]][I[122]]then;return ThanhDieu_[I[132]](a,I[106])end;_ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[107]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[170]]))]=function(a)return _ENV[(ThanhDieuByte_(ThanhDieuEncode_[I[107]]))][(ThanhDieuByte_(ThanhDieuEncode_[I[170]]))]((ThanhDieuByte_(ThanhDieuEncode_[I[188]])))end;ThanhDieu_[I[102]](I[65])ThanhDieu_[I[93]]((ThanhDieuByte_(ThanhDieuEncode_[I[70]])))	 
