(function(...)
(function(...)
local _ = ("\n\n\n\n\n\n\n\n qw-NaN 1-0 \n\n\n\n¥Blocked¥\n\n\n\n")



NaN = { function(...)end }

local AntiLoad = function(code) local Num = 0 local TakeCode = function(Code) local num2 = Num + 1 Num = num2 return code[Num] end return TakeCode end local code = {" "," "," "} assert(load(AntiLoad(code)))()
NaN = { function(_ENV)end }






NaN = { function(...)end }






NaN = { function(...)end }
local b = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/' 
function __b58(DATA)
    DATA = string.gsub(DATA, '[^'..b..'=]', '')
    return (DATA:gsub('.', function(x)
        if (x == '=') then return '' end
        local r,f='',(b:find(x)-1)
        for i=6,1,-1 do r=r..(f%2^i-f%2^(i-1)>0 and '1' or '0') end
        return r;
    end):gsub('%d%d%d?%d?%d?%d?%d?%d?', function(x)
        if (#x ~= 8) then return '' end
        local c=0
        for i=1,8 do c=c+(x:sub(i,i)=='1' and 2^(8-i) or 0) end
            return string.char(c)
    end))
end
NaN = { function(...)end }
function __x(s)
local res = ""
for i = 1,#s do
res = res .. string.char((171*s:byte(i)) % 256)
end
return res
end
NaN = { function(...)end }


gg.toast(__b58(__b58(__x(__x("�JR��v��*���d��[ٹv���������R�̚���%")))))end)(...)

end)()
