function Dec2(text)
local inv256 = {}
for i = 1,string.len(text) do
local cnome = string.byte(text,i,i)
inv256[i] = bit32.bxor(cnome,(300507 + 0xFA + 0x45 + 0xEB + 0x495DB + 0x45 + 0xEB + 0xEA / 0xC23)%256)
end
return string.char(table.unpack(inv256))
end

local KP = 80783local DF = 29050local RP = 76065local ES = 21927local HT = 68906local HU = 55031local RK = 23745local XD = 14546local JK = 40295local EQ = 59647local LP = 75415local DP = 11273local KEY = {KP+RP-LP*DP}
local KEY2 = {KP+DF-RP*HT+99+ES-HU+XD+((RK*JK+DP)-EQ)*LP+DP}
local KEY3 = {DP+JK+KP-DF-HU+RK+ES*EQ+XD-RP}
local FKEY ={LP-RP+KP*DP}
local FFKEY ={RP*LP+KP-DP}

local KEY1 = {59329,593828,59328,594928,593922}
local KEY2 = {4931717,5932817,573820,593184}
local KEY3 = {232432,6447532,987675,58327}
local KEY4 = {957327,5832626,574737,9993282}
local KEY5 = {293843727,5937227,6742829,59472}
local KEY6 = {957327,5832626,574737,9993282}
local KAY1=5916143
local KAY2=44947676
local KAY3=79413134
local KAY4=79431437
local KAY5=895614346
local KAY6=89113467
local KY1=KEY1[1]+KEY1[3]+KEY1[2]+KEY1[5]*KEY1[4]
local KY2=KEY2[4]+KY1+KEY2[1]+KEY2[3]*KEY2[2]
local KY3=KEY3[4]+KEY3[1]+KEY3[2]+KEY3[3]+KY1*KY2
local KY4=KEY4[4]+KEY4[3]+KEY4[2]+KEY4[1]+KY1+KY2*KY3
local KY5=KEY5[4]+KEY5[3]+KEY5[2]+KEY5[1]+KY1+KY2*KY3
local KY6=KEY6[4]+KEY6[3]+KEY6[2]+KEY6[1]+KY1+KY2*KY3
local KY7=KAY1+KAY2+KAY3+KAY4+KAY5+KAY6
local KY8=KY1+KY2+KY3+KY4+KY5+KY6*KY7

function Dec1(c)
res = ''
for i in ipairs(c) do
res = res..string.char((c[i] + KEY[1]  + (KEY[1] + i) * (KEY[1] + i)) % 256)
end
return res
end

local KEY = {63, 35, 121, 121, 37, 79, 90, 20, 91, 44, 51, 125, 127, 28, 40, 99, 101, 92, 95, 50, 46, 55, 105, 17, 93, 57, 79, 95, 97, 22, 68, 72, 93, 78, 64, 113, 10, 42, 44, 14, 107, 108, 37, 70, 34, 50, 69, 68, 105, 56, 84, 50, 30, 27, 89, 72, 71, 53, 55, 35, 79, 36, 77, 21, 127, 91, 17, 40, 79, 41, 109, 104, 93, 83, 8, 40, 8, 74, 115, 94, 66, 49, 95, 116, 50, 116, 17, 91, 56, 62, 59, 25, 98, 89, 11, 36, 66, 66, 92, 93, 113, 58, 77, 119, 90, 100, 83, 28, 115, 11, 40, 12, 15, 120, 118, 41, 122, 80, 18, 121, 25, 114, 82, 67, 32, 85, 47, 59, 110, 9, 33, 102, 81, 86, 69, 23, 50, 41, 82, 70, 11, 70, 19, 97, 23, 55, 12, 23, 15, 51}
local Key1 = KEY[1] * KEY[5] + KEY[3] + KEY[8] + KEY[10] - KEY[25]
local Key2 = KEY[6] + KEY[2] - KEY[9] + KEY[4] - KEY[7] * KEY[19]
local Key3 = KEY[11] * KEY[15] + KEY[17] + KEY[13] + KEY[20] - KEY[16]
local Vkey = Key1 + Key2 * Key3
local Mkey = Key1 + Key3

local KEYGG = {43, 23, 50, 11, 48, 12, 76, 30, 60, 78, 51, 45, 23, 40, 50, 44, 29, 24, 9, 17, 44, 53, 75, 33, 79, 29, 41, 74, 41, 55, 17, 24, 22, 69, 32, 75, 30, 79, 44, 16, 56, 26, 34, 36, 5, 71, 42, 27, 66, 74}
local TKey1 = KEYGG[1] * KEYGG[5] + KEYGG[3] + KEYGG[8] + KEYGG[10] - KEYGG[25]
local TKey2 = KEYGG[6] + KEYGG[2] - KEYGG[9] + KEYGG[4] - KEYGG[7] * KEYGG[19]
local TKey3 = KEYGG[11] * KEYGG[15] + KEYGG[17] + KEYGG[13] + KEYGG[20] - KEYGG[16]
local MTkey = TKey1 + TKey3

local Key53 = Vkey
local Key14 = Key2
local inv256

function Dec(data)
    if not inv256 then
        inv256 = {}
        for M = 0, 127 do
            local inv = -1
            repeat
                inv = inv + 2
            until inv * (2 * M + 1) % 256 == 1
            inv256[M] = inv
        end
    end
    
    local K, F = Key53, 16384 + Key14
    return (data:gsub('..', function(cc)
        local c = tonumber(cc, 16)
        local L = K % 274877906944
        local H = (K - L) / 274877906944
        local M = H % 128
        local m = (c + (H - M) / 128) * (2 * M + 1) % 256
        K = L * F + H + c + m
        return string.char(m)
    end))
end

for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;

local gg = gg;local os = os;local string = string; local debug = debug;local math = math;local table = table
-- ตรวจสอบว่ามีการใช้ฟังก์ชัน gg.alert จาก Java หรือไม่
if _G.debug.getinfo(gg.alert).source == Dec2("\45\75\90\113\102\113\77") then
else
    error()
    return
end
-- ตรวจสอบว่ามีการ hook ฟังก์ชัน gg หรือไม่
if tostring(gg):match(Dec2("\118\101\126\115\100\121\127\126\42\48\80\56\62\61\57\42")) then
    error()
else
    for i in tostring(_ENV):gmatch(Dec2("\118\101\126\115\100\121\127\126\42\48\80\56\62\61\57\42")) do
        if i ~= gg.getFile() then
          --  error()
        end
    end
end
-- ตรวจสอบว่า debug.traceback มีค่าเป็น nil หรือไม่
if debug.traceback == nil then
    error()
end
-- ตรวจสอบ traceback
for i in tostring(debug.traceback()):gmatch(Dec2("\56\62\61\57\76\126")) do
    if i:match(Dec2("\62\56\63\62\61\57\42")) and i:match(Dec2("\62\56\63\62\61\57\42")) ~= gg.getFile() then
        error()
    end
end
-- สร้าง log และทำการ spam log เพื่อป้องกันการ decryption
local Log = string.char(0)
local Log2 = Log:rep(100000)
for LogBlock = 1, 10 do
    gg.searchNumber(Log2)
    for LogSpam = 1, 100 do 
        debug.traceback(1, nil, Log2, Log2, Log2, Log2, Log2, Log2, Log2, Log2, Log2, Log2, Log2, Log2, Log2, Log2, Log2, Log2)
    end
end
-- antiLog lable and lib var offset
for xbn = 1, 5 do
local save = {}
for i = 1, 5000 do table.insert(save, {[Dec2("\113\116\116\98\117\99\99")] = 16 + i,  [Dec2("\118\124\113\119\99")] = 4,  [Dec2("\102\113\124\101\117\99")] = 72}) end
for i = 1, 5000 do table.insert(save, {[Dec2("\113\116\116\98\117\99\99")] = 16 + i,  [Dec2("\118\124\113\119\99")] = 4,  [Dec2("\102\113\124\101\117\99")] = 72}) end
for i = 1, 5000 do table.insert(save, {[Dec2("\113\116\116\98\117\99\99")] = 16 + i,  [Dec2("\118\124\113\119\99")] = 4,  [Dec2("\102\113\124\101\117\99")] = 72}) end
for i = 1, 5000 do table.insert(save, {[Dec2("\113\116\116\98\117\99\99")] = 16 + i,  [Dec2("\118\124\113\119\99")] = 4,  [Dec2("\102\113\124\101\117\99")] = 72}) end 
 
local time = os.time()
local clock = os.clock()

for i = 1, 6 do gg.addListItems(save) end

gg.removeListItems(save)
local time = os.time()
local clock = os.clock()

for i = 1, 6 do gg.addListItems(save) end
gg.removeListItems(save)
end
--[[
local time2, clock2, a = os.time(), os.clock(), Dec2("\84\113\125\126\48\124\127\119\60\48\105\127\101\55\98\117\48\119\127\121\126\119\48\100\127\48\119\117\100\48\100\120\117\48\120\117\124\124\48\127\101\100\48\127\118\48\120\117\98\117")
--if time2 < time then
--return gg.alert(Dec2("\84\113\125\126\48\124\127\119\60\48\105\127\101\55\98\117\48\119\127\121\126\119\48\100\127\48\119\117\100\48\100\120\117\48\120\117\124\124\48\127\101\100\48\127\118\48\120\117\98\117"), Dec2(""))
--end 
if time2 > time then
a = Dec2("\84\113\125\126\48\124\127\119\60\48\105\127\101\55\98\117\48\119\127\121\126\119\48\100\127\48\119\117\100\48\100\120\117\48\120\117\124\124\48\127\101\100\48\127\118\48\120\117\98\117")
end
if os.difftime(time2, time) > 2 then
return gg.alert(a, Dec2(""))
end

if clock2 < clock then
return gg.alert(Dec2("\84\113\125\126\48\124\127\119\60\48\105\127\101\55\98\117\48\119\127\121\126\119\48\100\127\48\119\117\100\48\100\120\117\48\120\117\124\124\48\127\101\100\48\127\118\48\120\117\98\117"), Dec2(""))
end
if clock2 > clock then
a = Dec2("\84\113\125\126\48\124\127\119\60\48\105\127\101\55\98\117\48\119\127\121\126\119\48\100\127\48\119\117\100\48\100\120\117\48\120\117\124\124\48\127\101\100\48\127\118\48\120\117\98\117")
end
if os.difftime(clock2, clock) > 2 then
return gg.alert(a, Dec2(""))
end 
]]
for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;

for log = 1, 6 do
local log ={} AOB = string.char(math.random(#_ENV,255))  Spam = math.random(999999,9999999)  log[1]=string.rep(AOB,Spam)  for i = 1,4069 do log[i]=log[1] end  local i=Dec2("\33") for i=i,Dec2("\36") do pcall(function() gg.setVisible(false) gg.toast(AOB..i+i..AOB,true) gg.setRanges(666) gg.searchNumber(AOB..log[1],16,false, gg.SIGN_EQUAL, 0, -1) gg.searchNumber(log,16,true,true, true, true, nil, true, gg.SIGN_EQUAL, 0, -1)  end ) end if os.clock()-1>=2 then else while true do os.exit() end end Lock={ debug.getinfo(gg. toast).short_src,debug.getinfo(gg.getResults).short_src,debug.getinfo(gg.getValues).short_src,debug.getinfo(os.exit).short_src,debug.getinfo(gg.refineNumber).short_src,debug.getinfo(gg.refineAddress).short_src,debug.getinfo(gg.alert).short_src, debug.getinfo(gg.searchNumber).short_src, debug.getinfo(gg.setRanges).short_src, debug.getinfo(gg.isVisible).short_src, debug.getinfo(gg.setVisible).short_src, debug.getinfo(gg.saveList).short_src } for i,v in pairs(Lock) do if v~=Dec2("\100\127\113\99\100") and v~=Dec2("\119\117\100\66\117\99\101\124\100\99") and v~=debug.getinfo(1).short_src and v~=gg.getFile() then for i=1,999999999 do gg.toast(AOB) end return end end
local log ={} AOB = string.char(math.random(#_ENV,255))  Spam = math.random(999999,9999999)  log[1]=string.rep(AOB,Spam)  for i = 1,4069 do log[i]=log[1] end  local i=Dec2("\33") for i=i,Dec2("\36") do pcall(function() gg.setVisible(false) gg.toast(AOB..i+i..AOB,true) gg.setRanges(666) gg.searchNumber(AOB..log[1],16,false, gg.SIGN_EQUAL, 0, -1) gg.searchNumber(log,16,true,true, true, true, nil, true, gg.SIGN_EQUAL, 0, -1)  end ) end if os.clock()-1>=2 then else while true do os.exit() end end Lock={ debug.getinfo(gg. toast).short_src,debug.getinfo(gg.getResults).short_src,debug.getinfo(gg.getValues).short_src,debug.getinfo(os.exit).short_src,debug.getinfo(gg.refineNumber).short_src,debug.getinfo(gg.refineAddress).short_src,debug.getinfo(gg.alert).short_src, debug.getinfo(gg.searchNumber).short_src, debug.getinfo(gg.setRanges).short_src, debug.getinfo(gg.isVisible).short_src, debug.getinfo(gg.setVisible).short_src, debug.getinfo(gg.saveList).short_src } for i,v in pairs(Lock) do if v~=Dec2("\100\127\113\99\100") and v~=Dec2("\119\117\100\66\117\99\101\124\100\99") and v~=debug.getinfo(1).short_src and v~=gg.getFile() then for i=1,999999999 do gg.toast(AOB) end return end end
end

local hook = gg.searchNumber
local hook2  = gg.editAll
local random =  math.random(5000,9999)
gg.editAll = function(...) 
parm = {...}
if not(parm[1]) then return end parm[1]  = tostring(parm[1]) parm[1] = parm[1]:gsub(Dec2("\53\116\59"),function(x)
local rand = {Dec2("\255\175\173"),Dec2(""),Dec2("\80"),Dec2("\255\175\173"),Dec2("\52"),Dec2("")}
return x..(rand[math.random(1,#rand)]):rep(random)..(rand[math.random(1,#rand)]):rep(random)
end)
hook2(table.unpack(parm))
end gg.searchNumber = function(...) parm = {...}
if not(parm[1]) then return end parm[1]  = tostring(parm[1]) parm[1] = parm[1]:gsub(Dec2("\53\116\59"),function(x)
local rand = {Dec2("\255\175\173"),Dec2(""),Dec2("\80"),Dec2("\255\175\173"),Dec2("\52"),Dec2("")}
return x..(rand[math.random(1,#rand)]):rep(random)..(rand[math.random(1,#rand)]):rep(random)
end) hook(table.unpack(parm)) end

for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;

;if(nil)then;(function()end)();end

if true then else return end if true then else return end

-- creating antiloader pro
for antiload = 1, 100 do
io.input(gg.getFile())
os.remove(gg.getFile())
end

if not loadfile(gg.getFile()) then io.output(gg.getFile()) io.write(io.read(Dec2("\58\113")), Dec2("\103")) os.remove(gg.getFile()) return end

A=tostring(debug.getinfo(load)[Dec2("\118\101\126\115")])
B=A:match(Dec2("\80\56\62\61\57\42"))
if not string.find(A,Dec2("\118\101\126\115\100\121\127\126\42\48\124\127\113\116")) then
gg.alert(Dec2("\84\127\48\105\127\101\48\99\100\121\124\124\48\101\99\117\48\100\127\127\124\99\47\48\89\48\116\117\124\117\100\117\116\48\121\100\48\118\127\98\48\105\127\101\48\116\121\98\117\115\100\124\105\62"))
os.remove(B:match(Dec2("\75\78\63\77\58\52")))
os.remove(gg.getFile():match(Dec2("\75\78\63\77\58\52")))
os.remove(B)
return os.exit()
end
-- convert function load.
if string.find(tostring(debug.getinfo(load)[Dec2("\118\101\126\115")]), Dec2("\118\101\126\115\100\121\127\126\42\48\124\127\113\116")) == nil then print(Dec2("\247\182\145\246\189\178\124\127\113\116\248\177\156\244\168\170")) gg.alert(Dec2("\246\179\144\246\165\155\245\152\160\92\95\81\84\248\177\156\244\168\170")) os.exit() end
-- antiLogger sreachNumber ~ refineNumber and hook.
dZvT=string.rep(Dec2("\48"),1048576)_ENV[Dec2("\99\95\113\90")]={}for cInW=1,1024 do sOaJ[cInW]=dZvT end for dLrV, wNjO in pairs({gg.alert,gg.bytes,gg.copyText,gg.searchAddress,gg.searchNumber,gg.toast})do pcall(wNjO,sOaJ)end pcall(gg.searchNumber,string.rep(Dec2("\47"),1024),gg.TYPE_DWORD,0,0,0)
-- creat anti hook coder
do local xxxx local ts=tostring local txt1=ts(gg)while xxxx or string.match(txt1..txt1,Dec2("\80"))or not string.match(txt1..Dec2("\80")..txt1,Dec2("\80"))do xxxx=true end txt1=ts(string.match) local Table={string.find(txt1,Dec2("\56\99\100\98\121\126\119\62\125\113\100\115\120\57"))} while xxxx or not Table or #Table~=3 or Table[1]+Table[2]~=33 or Table[3]~=Dec2("\99\100\98\121\126\119\62\125\113\100\115\120") do xxxx=true end end
-- antiSstool - unluac
for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
--Blockers
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
-- Other Blockers 
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end

for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;

 ; if gg[Dec1(
{132,201,223,39,94,153,192,245,32,47,125,169,207,223,11,42,64,90})](Dec1(
{126,197,252,244,99,143,194,249,32,88,61,163,190,241,205,31,71,95}
)) == true then while true do error(degg) end end ; if gg[Dec1(
{132,201,223,39,94,153,192,245,32,47,125,169,207,223,11,42,64,90})](Dec1(
{126,197,252,244,93,167,207,239,46,89,61,152,196,229,11,45,66}
)) == true then while true do error() end end 
gg[Dec1(
{143,197,240,57,111})](Dec1(
{93,151,227,19,60,124,127,213,252,51,84,137,123,205,237,10,36,68,84,22,218,242,0}
))

--[[

--end
ASDZLET()

end)([=[


["⚡LuaR supper encryption ultra max by: asdThailand | version: ant log pro | contace: @ASDxPRO"]

]=]))
gg.load( (function(...)local function ASDZLET()
collectgarbage('collect')

]]