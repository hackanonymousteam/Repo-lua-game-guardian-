local XU__ = string.char
;(function(...)
end)(...) 
return (function(...)
    local lll = {};
    local _l_ = {};  
    
assert(not (_ENV[XU__(103,103)][XU__(115,101,116,86,105,115,105,98,108,101)]((false))))
if_time_not_matched = true
if if_time_not_matched then
    current_time = tostring(_ENV[XU__(111,115)][XU__(116,105,109,101)]())
    time_match = _ENV[XU__(115,116,114,105,110,103)][XU__(109,97,116,99,104)](XU__(47) .. current_time, XU__(47,40,91,94,47,93,43,41,36))
    if time_match ~= current_time then
        while_loop = true
        while while_loop do
            error_alert = true
            if error_alert then
                _ENV[XU__(103,103)][XU__(97,108,101,114,116)](XU__(69,114,114,111,114,44,32,116,105,109,101,32,105,115,32,110,111,116,32,97,99,99,101,112,95,116,97,98,108,101,46))
                return _ENV[XU__(111,115)][XU__(101,120,105,116)]()
            end
            if not false_condition then
                return _ENV[XU__(111,115)][XU__(101,120,105,116)]()
            end
        end
    end
end


local script_name_regex, script_data = _ENV[XU__(103,103)][XU__(103,101,116,70,105,108,101)]():gsub(XU__(37,112), function(...)
return XU__(37) .. (...)
end), (_ENV[XU__(105,111)][XU__(105,110,112,117,116)](_ENV[XU__(103,103)][XU__(103,101,116,70,105,108,101)]()):read(XU__(42,97)))

if pcall(_ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)], (1)) and pcall(_ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)], (2)) and pcall(_ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)], (3)) and _ENV[XU__(115,116,114,105,110,103)][XU__(109,97,116,99,104)](_ENV[XU__(100,101,98,117,103)][XU__(116,114,97,99,101,98,97,99,107)](), script_name_regex) then
	if not _ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)]((1)).func == _ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)] and not _ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)]((1)).what == XU__(74,97,118,97) and not _ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)]((1)).source == XU__(61,91,74,97,118,97,93) and not _ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)]((1)).short_src == XU__(91,74,97,118,97,93) then
		while true do
			if true then
				_ENV[XU__(103,103)][XU__(97,108,101,114,116)](XU__(69,114,114,111,114,44,32,106,97,118,97,32,105,110,102,111,32,105,115,32,110,111,116,32,115,97,109,101,46))
				_ENV[XU__(111,115)][XU__(101,120,105,116)]()

				if false then
					if true then
					end
				end
			end
		end
	end

	if not _ENV[XU__(115,116,114,105,110,103)][XU__(109,97,116,99,104)](tostring(_ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)]((2)).func), script_name_regex) and not _ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)]((2)).what == XU__(76,117,97) and not _ENV[XU__(115,116,114,105,110,103)][XU__(109,97,116,99,104)](_ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)]((2)).source, script_name_regex) and not _ENV[XU__(115,116,114,105,110,103)][XU__(109,97,116,99,104)](_ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)]((2)).short_src, script_name_regex) then
		while true do
			if true then
				_ENV[XU__(103,103)][XU__(97,108,101,114,116)](XU__(69,114,114,111,114,44,32,115,101,108,102,105,110,102,111,32,105,115,32,110,111,116,32,115,97,109,101,46))
				_ENV[XU__(111,115)][XU__(101,120,105,116)]()
				if false then
					if true then
					end
				end
			end
		end
	end
    if _ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)]((3)) ~= nil then
		if not _ENV[XU__(115,116,114,105,110,103)][XU__(109,97,116,99,104)](tostring(_ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)]((3)).func), script_name_regex) and not _ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)]((3)).what == XU__(109,97,105,110) and not _ENV[XU__(115,116,114,105,110,103)][XU__(109,97,116,99,104)](_ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)]((3)).source, script_name_regex) and not _ENV[XU__(115,116,114,105,110,103)][XU__(109,97,116,99,104)](_ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)]((3)).short_src, script_name_regex) then
			while true do
				if true then
					_ENV[XU__(103,103)][XU__(97,108,101,114,116)](XU__(69,114,114,111,114,44,32,115,101,108,102,115,101,99,111,110,100,105,110,102,111,32,105,115,32,110,111,116,32,115,97,109,101,46))   
					if false then
						if true then
						end
					end
				end
			end
		end
	end
end



local temporary_c = {{}, {}}

for n = (1), (10000) do
	temporary_c[(1)][#temporary_c[(1)] + 1], temporary_c[(2)][#temporary_c[(2)] + 1] = utf8.char(_ENV[XU__(109,97,116,104)][XU__(114,97,110,100,111,109)]((10000), (16000))), {
		[XU__(102,108,97,103,115)] = (4),
		[XU__(97,100,100,114,101,115,115)] = (110) + n,
	}
end

temporary_c[(1)] = (_ENV[XU__(115,116,114,105,110,103)][XU__(114,101,112)](_ENV[XU__(115,116,114,105,110,103)][XU__(114,101,112)]((_ENV[XU__(116,97,98,108,101)][XU__(99,111,110,99,97,116)](temporary_c[(1)])), (999)), (2)))

path__table = {}
for k, v in pairs(gg) do
    if type(v) == XU__(102,117,110,99,116,105,111,110) then
        success, result = pcall(_ENV[XU__(103,103)][XU__(105,110,116,101,114,110,97,108,50)], v)
        for path in _ENV[XU__(115,116,114,105,110,103)][XU__(103,109,97,116,99,104)](result, XU__(47,40,46,45,41,58)) do
            path__table[#path__table + 1] = XU__(47) .. path
        end

        for path in _ENV[XU__(115,116,114,105,110,103)][XU__(103,109,97,116,99,104)](result, XU__(37,91,74,97,118,97,37,93,37,58,37,45,49)) do
            path__table[#path__table + 1] = path
        end
    end
end

for k, path in pairs(path__table) do
    while not path or _ENV[XU__(115,116,114,105,110,103)][XU__(102,105,110,100)](path, XU__(37,91,74,97,118,97,37,93,37,58,37,45,49)) or path ~= _ENV[XU__(103,103)][XU__(103,101,116,70,105,108,101)]() do
        _ENV[XU__(111,115)][XU__(101,120,105,116)]()
    end
end


local _table = {}
local value1 = 2000
local value2 = XU__(49)
local value3, value4 = XU__(), 1
local value5 = XU__(89,110,120,95,95)
local start_time = _ENV[XU__(111,115)][XU__(116,105,109,101)]()
for i = 1, 500 do
    value4 = value4 == 255 and 1 or value4 + 1
    value3 = value3 .. _ENV[XU__(115,116,114,105,110,103)][XU__(99,104,97,114)](value4)
end
for i = 1, 12 do
    value3 = value3 .. value3
end
for i = 1, value1 do
    _table[i] = {address = i, flags = 1, value3c = value3}
end
for i = 1, 15 do
    value2 = value2 .. value2
    value5 = value5 .. value5
end
for y = 1, 15 do
    _table[y] = value5
end

pcall(function(i)
        _ENV[XU__(103,103)][XU__(115,101,97,114,99,104,78,117,109,98,101,114)](i)
    end, _table)

xpcall(function(i)
        _ENV[XU__(103,103)][XU__(101,100,105,116,65,108,108)](i, 4)
    end, function()
        traceback = _ENV[XU__(100,101,98,117,103)][XU__(116,114,97,99,101,98,97,99,107)]()
    end, _table)

local end_time = _ENV[XU__(111,115)][XU__(116,105,109,101)]()
if _ENV[XU__(111,115)][XU__(100,105,102,102,116,105,109,101)](end_time, start_time) > 2 then
    _ENV[XU__(111,115)][XU__(101,120,105,116)]()
end

value1 = nil
value2 = nil
value3 = nil
value4 = nil
if ((tostring(_ENV[XU__(103,103)][XU__(115,101,116,82,97,110,103,101,115)])):match(XU__(47,37,119,43,47,37,120,43,37,83,43,37,112,43,37,97,43))) ~= nil then
    return _ENV[XU__(111,115)][XU__(101,120,105,116)]()
end

local get__table_spam = {}
local b, to_string, get_spam_name = 0, tostring
local temp_string = XU__()
local b = 0
while (b < (10 ^ 2)) do
    temp_string = temp_string .. tostring(b * b)
    b = b + 1
end

local get_spam_name = XU__()
for i = 1, 10 do
    get_spam_name = XU__(240,159,140,168,239,184,143) .. get_spam_name .. XU__(226,152,131,239,184,143) .. get_spam_name .. XU__(226,157,132,239,184,143)
end
get_spam_name = get_spam_name:rep(100)

local tmp = (function()
    return temp_string
end)()

local spam = XU__(76,117,97,32,53,46,50)
local random_number = _ENV[XU__(109,97,116,104)][XU__(114,97,110,100,111,109)](1, 255)
local c, b_value = XU__(39) .. random_number .. XU__(39), _ENV[XU__(109,97,116,104)][XU__(114,97,110,100,111,109)](100, 300)

if tostring(XU__(64)) == XU__() then
    return _ENV[XU__(111,115)][XU__(101,120,105,116)]()
end


local spam_2 = XU__(105,115,32,116,111,112)
local get_table_spam = {}
for i = 1, #tmp do
    get_table_spam[i] = {
        [XU__(97,100,100,114,101,115,115)] = get_spam_name,
        [XU__(102,108,97,103,115)] = get_spam_name,
        [XU__(118,97,108,117,101)] = get_spam_name,
        [XU__(102,114,101,101,122,101)] = get_spam_name,
        [XU__(110,97,109,101)] = get_spam_name,
        get_table_spam[i - 1]
    }
    _ENV[XU__(103,103)][XU__(114,101,102,105,110,101,78,117,109,98,101,114)](get_table_spam)
    _ENV[XU__(103,103)][XU__(114,101,102,105,110,101,65,100,100,114,101,115,115)](get_table_spam)
end



-- Check for any variables that contain the XU__(64) character and exit the program if found.
for i, var in ipairs({tostring(gg), tostring(os), tostring(io), tostring(debug), tostring(math), tostring(table)}) do
    if _ENV[XU__(115,116,114,105,110,103)][XU__(109,97,116,99,104)](var, XU__(64)) then
        _ENV[XU__(111,115)][XU__(101,120,105,116)]()
        _ENV[XU__(103,103)][XU__(112,114,111,99,101,115,115,75,105,108,108)]()
        return
    end
end

-- Check if the program is being executed from a valid source, and if not, loop indefinitely.
if pcall(_ENV[XU__(111,115)][XU__(101,120,105,116)]) or _ENV[XU__(115,116,114,105,110,103)][XU__(114,101,112)](XU__(39), XU__(50)) ~= XU__(39,39) or not _ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)](tostring).isvararg or _ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)](_ENV[XU__(103,103)][XU__(115,101,97,114,99,104,78,117,109,98,101,114)]).what == XU__(76,117,97) then
    while true do
        local x = 0
        repeat
            x = x + 1
            _ENV[XU__(103,103)][XU__(115,101,116,86,105,115,105,98,108,101)](false)
            _ENV[XU__(103,103)][XU__(115,108,101,101,112)](0)
            _ENV[XU__(103,103)][XU__(115,101,116,86,105,115,105,98,108,101)](true)
            _ENV[XU__(103,103)][XU__(115,108,101,101,112)](2000)
            _ENV[XU__(103,103)][XU__(115,101,116,86,105,115,105,98,108,101)](false)
            _ENV[XU__(103,103)][XU__(115,108,101,101,112)](0)
            _ENV[XU__(103,103)][XU__(115,101,116,86,105,115,105,98,108,101)](true)
        until x == 20000
        _ENV[XU__(103,103)][XU__(115,108,101,101,112)](0)
        _ENV[XU__(111,115)][XU__(101,120,105,116)]()
    end
end

-- Check if the current file being executed is _ENV[XU__(103,103)][XU__(114,101,102,105,110,101,78,117,109,98,101,114)], and if it is not, loop indefinitely.
local current_file = _ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)](_ENV[XU__(103,103)][XU__(114,101,102,105,110,101,78,117,109,98,101,114)]).short_src
if current_file ~= _ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)](1).short_src and current_file ~= _ENV[XU__(103,103)][XU__(103,101,116,70,105,108,101)]() then
    while true do
        local x = 0
        repeat
            x = x + 1
            _ENV[XU__(103,103)][XU__(115,101,116,86,105,115,105,98,108,101)](false)
            _ENV[XU__(103,103)][XU__(115,108,101,101,112)](0)
            _ENV[XU__(103,103)][XU__(115,101,116,86,105,115,105,98,108,101)](true)
            _ENV[XU__(103,103)][XU__(115,108,101,101,112)](2000)
            _ENV[XU__(103,103)][XU__(115,101,116,86,105,115,105,98,108,101)](false)
            _ENV[XU__(103,103)][XU__(115,108,101,101,112)](0)
            _ENV[XU__(103,103)][XU__(115,101,116,86,105,115,105,98,108,101)](true)
        until x == 20000
        _ENV[XU__(103,103)][XU__(115,108,101,101,112)](0)
        _ENV[XU__(111,115)][XU__(101,120,105,116)]()
    end
end

-- Check for any variables that contain the XU__(64) character again and loop indefinitely if found.
for i, var in ipairs({tostring(gg), tostring(os), tostring(io), tostring(debug), tostring(math), tostring(table)}) do
    if _ENV[XU__(115,116,114,105,110,103)][XU__(109,97,116,99,104)](var, XU__(64)) then
        while true do
            local x = 0
            repeat
                x = x + 1
                _ENV[XU__(103,103)][XU__(115,101,116,86,105,115,105,98,108,101)](false)
                _ENV[XU__(103,103)][XU__(115,108,101,101,112)](0)
                _ENV[XU__(103,103)][XU__(115,101,116,86,105,115,105,98,108,101)](true)
                _ENV[XU__(103,103)][XU__(115,108,101,101,112)](2000)
                _ENV[XU__(103,103)][XU__(115,101,116,86,105,115,105,98,108,101)](false)
                _ENV[XU__(103,103)][XU__(115,108,101,101,112)](0)
                _ENV[XU__(103,103)][XU__(115,101,116,86,105,115,105,98,108,101)](true)
            until x == 20000
            _ENV[XU__(103,103)][XU__(115,108,101,101,112)](0)
            _ENV[XU__(111,115)][XU__(101,120,105,116)]()
        end
    end
end

-- Check if the function _ENV[XU__(103,103)][XU__(115,101,97,114,99,104,78,117,109,98,101,114)] is being called from Java and exit if it is not.
local info = _ENV[XU__(100,101,98,117,103)][XU__(103,101,116,105,110,102,111)](_ENV[XU__(103,103)][XU__(115,101,97,114,99,104,78,117,109,98,101,114)])
if info.what ~= XU__(74,97,118,97) then
    _ENV[XU__(111,115)][XU__(101,120,105,116)]()
    while true do
    end
end


local indexTable = {}
local globalTable = {}
local packagePathIndex, packagePathBase
globalTable[XU__(108,97,115,116,70,105,108,101,80,97,116,104)] = _ENV[XU__(103,103)][XU__(103,101,116,70,105,108,101)]()
globalTable[XU__(108,117,97,70,105,108,101)] = _ENV[XU__(108,111,97,100,102,105,108,101)](globalTable[XU__(108,97,115,116,70,105,108,101,80,97,116,104)])
globalTable[XU__(99,112,112,70,105,108,101)] = globalTable[XU__(108,117,97,70,105,108,101)]
if globalTable[XU__(99,112,112,70,105,108,101)] ~= nil then
    globalTable[XU__(108,117,97,70,105,108,101)] = nil
    packagePathBase = globalTable[XU__(108,97,115,116,70,105,108,101,80,97,116,104)]:match(XU__(91,94,47,93,43,36))
    packagePathIndex = XU__(108,111,104,104,104,103,103,103)
    local output = _ENV[XU__(103,103)][XU__(103,101,116,82,101,115,117,108,116,115)](5000)
    _ENV[XU__(111,115)][XU__(114,101,110,97,109,101)](XU__() .. globalTable[XU__(108,97,115,116,70,105,108,101,80,97,116,104)] .. XU__(), XU__() .. globalTable[XU__(108,97,115,116,70,105,108,101,80,97,116,104)]:gsub(XU__(47,91,94,47,93,43,36), XU__()) .. XU__(47) .. packagePathIndex .. XU__())
    local printFunc = _ENV[XU__(108,111,97,100,102,105,108,101)](XU__() .. globalTable[XU__(108,97,115,116,70,105,108,101,80,97,116,104)]:gsub(XU__(47,91,94,47,93,43,36), XU__()) .. XU__(47) .. packagePathIndex .. XU__())
    if printFunc ~= nil then
        _ENV[XU__(111,115)][XU__(114,101,110,97,109,101)](
            XU__() .. globalTable[XU__(108,97,115,116,70,105,108,101,80,97,116,104)]:gsub(XU__(47,91,94,47,93,43,36), XU__()) .. XU__(47) .. packagePathIndex .. XU__(),
            XU__() .. globalTable[XU__(108,97,115,116,70,105,108,101,80,97,116,104)]:gsub(XU__(47,91,94,47,93,43,36), XU__()) .. XU__(47) .. packagePathBase .. XU__()
        )
        repeat
            x = 0
            repeat
                x = x + 1
                _ENV[XU__(103,103)][XU__(115,101,116,86,105,115,105,98,108,101)](false)
                _ENV[XU__(103,103)][XU__(115,108,101,101,112)](0)
                _ENV[XU__(103,103)][XU__(115,101,116,86,105,115,105,98,108,101)](true)
                _ENV[XU__(103,103)][XU__(115,108,101,101,112)](2000)
                _ENV[XU__(103,103)][XU__(115,101,116,86,105,115,105,98,108,101)](false)
                _ENV[XU__(103,103)][XU__(115,108,101,101,112)](0)
                _ENV[XU__(103,103)][XU__(115,101,116,86,105,115,105,98,108,101)](true)
            until x == 20000
            gg[XU__(115,108,101,101,112)](0)
            _ENV[XU__(111,115)][XU__(101,120,105,116)]()
        until false
    end
end
for i in _ENV[XU__(105,112,97,105,114,115)](
    {
        _ENV[XU__(116,111,115,116,114,105,110,103)](_ENV[XU__(103,103)]),
        _ENV[XU__(116,111,115,116,114,105,110,103)](_ENV[XU__(111,115)]),
        _ENV[XU__(116,111,115,116,114,105,110,103)](_ENV[XU__(105,111)]),
        _ENV[XU__(116,111,115,116,114,105,110,103)](_ENV[XU__(100,101,98,117,103)]),
        _ENV[XU__(116,111,115,116,114,105,110,103)](_ENV[XU__(109,97,116,104)]),
        _ENV[XU__(116,111,115,116,114,105,110,103)](_ENV[XU__(116,97,98,108,101)])
    }
) do
    if
        _ENV[XU__(115,116,114,105,110,103)][XU__(109,97,116,99,104)](
            ({
                _ENV[XU__(116,111,115,116,114,105,110,103)](_ENV[XU__(103,103)]),
                _ENV[XU__(116,111,115,116,114,105,110,103)](_ENV[XU__(111,115)]),
                _ENV[XU__(116,111,115,116,114,105,110,103)](_ENV[XU__(105,111)]),
                _ENV[XU__(116,111,115,116,114,105,110,103)](_ENV[XU__(100,101,98,117,103)]),
                _ENV[XU__(116,111,115,116,114,105,110,103)](_ENV[XU__(109,97,116,104)]),
                _ENV[XU__(116,111,115,116,114,105,110,103)](_ENV[XU__(116,97,98,108,101)])
            })[i],
            (XU__(64))
        )
     then
        repeat
            x = 0
            repeat
                x = x + 1
                _ENV[XU__(103,103)][XU__(115,101,116,86,105,115,105,98,108,101)](false)
                _ENV[XU__(103,103)][XU__(115,108,101,101,112)](0)
                _ENV[XU__(103,103)][XU__(115,101,116,86,105,115,105,98,108,101)](true)
                _ENV[XU__(103,103)][XU__(115,108,101,101,112)](2000)
                _ENV[XU__(103,103)][XU__(115,101,116,86,105,115,105,98,108,101)](false)
                _ENV[XU__(103,103)][XU__(115,108,101,101,112)](0)
                _ENV[XU__(103,103)][XU__(115,101,116,86,105,115,105,98,108,101)](true)
            until x == 20000
            gg[XU__(115,108,101,101,112)](0)
            _ENV[XU__(111,115)][XU__(101,120,105,116)]()
        until false
    end
end



-- Check if the pcall function is available
if _ENV[XU__(112,99,97,108,108)] == nil then
    return _ENV[XU__(111,115)][XU__(101,120,105,116)]()
end


-- Check if the _ENV[XU__(100,101,98,117,103)][XU__(116,114,97,99,101,98,97,99,107)] function is available
if _ENV[XU__(100,101,98,117,103)][XU__(116,114,97,99,101,98,97,99,107)] == nil then
    return _ENV[XU__(111,115)][XU__(101,120,105,116)]()
end

-- Check if the _ENV[XU__(115,116,114,105,110,103)][XU__(114,101,112)] function works as expected
if _ENV[XU__(115,116,114,105,110,103)][XU__(114,101,112)](XU__(97), 2) ~= XU__(97,97) then
    while true do
        _ENV[XU__(103,103)][XU__(97,108,101,114,116)](XU__(69,114,114,111,114,58,32,115,116,114,105,110,103,46,114,101,112,32,102,117,110,99,116,105,111,110,32,110,111,116,32,119,111,114,107,105,110,103,32,97,115,32,101,120,112,101,99,116,101,100,46))
        return _ENV[XU__(111,115)][XU__(101,120,105,116)]()
    end
end

-- Create a long string of repeated characters
local longString = _ENV[XU__(115,116,114,105,110,103)][XU__(99,104,97,114)](255):rep(6):rep(4):rep(999)

-- Refine numbers in the long string using the GameGuardian API
for i = 1, 3340 do
    _ENV[XU__(103,103)][XU__(114,101,102,105,110,101,78,117,109,98,101,114)](XU__(48), longString, longString, longString, longString, longString, longString, longString)
end

-- Check if certain values in the gg table contain specific strings
local ggValues = {_ENV[XU__(103,103)].CACHE_DIR, _ENV[XU__(103,103)].EXT_FILES_DIR, _ENV[XU__(103,103)].EXT_CACHE_DIR, _ENV[XU__(103,103)].FILES_DIR, _ENV[XU__(103,103)].PACKAGE}
local ggKeywords = {XU__(97,114,116), XU__(65,82,84), XU__(65,114,116), XU__(100,101,99), XU__(68,101,99), XU__(68,69,67), XU__(104,111,111,107), XU__(72,111,111,107), XU__(72,111,111,75), XU__(72,79,79,75), XU__(108,111,103), XU__(76,111,103), XU__(76,79,71)}
for i, v in pairs(ggKeywords) do
    if _ENV[XU__(115,116,114,105,110,103)][XU__(102,105,110,100)](tostring(ggValues), v) or (not _ENV[XU__(115,116,114,105,110,103)][XU__(102,105,110,100)](tostring(ggValues), XU__(99,111,109))) then
        while true do
            return _ENV[XU__(111,115)][XU__(101,120,105,116)]()
        end
    end
end

-- Check for specific package, version, and build of GameGuardian
while _ENV[XU__(103,103)][XU__(80,65,67,75,65,71,69)] == XU__(99,97,116,99,104,46,65,114,116,46,84,111,111,108,46,115,101,97,116,99,104) do
    while true do
        return _ENV[XU__(111,115)][XU__(101,120,105,116)]()
    end
end

while _ENV[XU__(103,103)][XU__(86,69,82,83,73,79,78)] ~= XU__(49,48,49,46,49) do
    while true do
        return _ENV[XU__(111,115)][XU__(101,120,105,116)]()
    end
end

while _ENV[XU__(115,116,114,105,110,103)][XU__(102,105,110,100)](_ENV[XU__(103,103)][XU__(69,88,84,95,67,65,67,72,69,95,68,73,82)], XU__(99,111,109,46,65,114,116,46,84,111,111,108)) do
    while true do
        return _ENV[XU__(111,115)][XU__(101,120,105,116)]()
    end
end

while _ENV[XU__(115,116,114,105,110,103)][XU__(102,105,110,100)](_ENV[XU__(103,103)][XU__(69,88,84,95,67,65,67,72,69,95,68,73,82)], XU__(99,97,116,99,104,95,46,109,101,95,46,105,102,95,46,121,111,117,95,46,99,97,110,95,57,51)) do
    while true do
        _ENV[XU__(111,115)][XU__(101,120,105,116)]()
    end
end


-- Check each line of the traceback string for a filename that doesnXU__(116,32,109,97,116,99,104,32,116,104,101,32,99,117,114,114,101,110,116,32,115,99,114,105,112,116)s filename
for line in _ENV[XU__(115,116,114,105,110,103)][XU__(103,109,97,116,99,104)](tostring(_ENV[XU__(100,101,98,117,103)][XU__(116,114,97,99,101,98,97,99,107)]()), XU__(40,46,45,41,10)) do
    if _ENV[XU__(115,116,114,105,110,103)][XU__(109,97,116,99,104)](line, XU__(46,40,47,46,45,41,58)) and _ENV[XU__(115,116,114,105,110,103)][XU__(109,97,116,99,104)](line, XU__(46,40,47,46,45,41,58)) ~= _ENV[XU__(103,103)][XU__(103,101,116,70,105,108,101)]() then
        _ENV[XU__(111,115)][XU__(101,120,105,116)]()
        print(XU__(69,114,114,111,114,58,32,105,110,99,111,114,114,101,99,116,32,102,105,108,101,110,97,109,101,32,100,101,116,101,99,116,101,100,46))
        return
    end
end

local function checkDebugger()
    local mt = _ENV[XU__(100,101,98,117,103)][XU__(103,101,116,109,101,116,97,116,97,98,108,101)](_G)
    if mt ~= nil then
        _ENV[XU__(103,103)][XU__(97,108,101,114,116)](XU__(68,101,98,117,103,103,101,114,32,100,101,116,101,99,116,101,100,33))
        return _ENV[XU__(111,115)][XU__(101,120,105,116)]()
    end
end

checkDebugger()
;
    gg.toast(decode({'\1\77\71\91\34\70', {215}},{'\4\70\83\37\76\70', {31}},{'\3\36\70\69\88\81', {143}},{'\2\72\70\35\69\92', {55}},{'\5\83\75\89', {23}}));
end)(...)


