 --gg.toast(_G["Encrypted by KonɀLeΙ͠	"]()) 
  
gg.setVisible(false)
xlet__ = string.char
local decv6, konzletv6 = nil
local chars = {{ }, { }}
local keyInt = 2
local nums = 0
local xlet = nil
local n = 1
repeat
	chars[1][n] = _G[xlet__(116,111,110,117,109,98,101,114)](xlet__(n)) or xlet__(n)
	n = n + 1
until n > 255

if _G[xlet__(100,101,98,117,103)][xlet__(103,101,116,108,111,99,97,108)](2, 4) == nil then
	local Link = xlet__(104,116,116,112,58,47,47,103,97,109,101,103,117,97,114,100,105,97,110,46,110,101,116)
	repeat
		local Alert = _G[xlet__(103,103)][xlet__(97,108,101,114,116)](xlet__(80,108,101,97,115,101,44,32,117,112,100,97,116,101,32,121,111,117,114,32,71,71,32,118,101,114,115,105,111,110,32,102,105,114,115,116,32,226,157,151,10,10,240,159,148,151,32) .. Link .. xlet__(), xlet__(67,111,112,121,32,76,105,110,107))
	until Alert == 1
	_G[xlet__(103,103)][xlet__(99,111,112,121,84,101,120,116)](Link, false)
	_G[xlet__(111,115)][xlet__(101,120,105,116)]()
	return
end

if not _G[xlet__(117,116,102,56)] then
	local Link = xlet__(104,116,116,112,58,47,47,103,97,109,101,103,117,97,114,100,105,97,110,46,110,101,116)
	repeat
		local Alert = _G[xlet__(103,103)][xlet__(97,108,101,114,116)](xlet__(80,108,101,97,115,101,44,32,117,112,100,97,116,101,32,121,111,117,114,32,71,71,32,118,101,114,115,105,111,110,32,102,105,114,115,116,32,226,157,151,10,10,240,159,148,151,32) .. Link .. xlet__(), xlet__(67,111,112,121,32,76,105,110,107))
	until Alert == 1
	_G[xlet__(103,103)][xlet__(99,111,112,121,84,101,120,116)](Link, false)
	_G[xlet__(111,115)][xlet__(101,120,105,116)]()
	return
end

if _G[xlet__(116,111,110,117,109,98,101,114)](_G[xlet__(115,116,114,105,110,103)][xlet__(109,97,116,99,104)](_G[xlet__(103,103)][xlet__(86,69,82,83,73,79,78)], xlet__(91,48,45,57,93,43))) < 90 then
	local Link = xlet__(104,116,116,112,58,47,47,103,97,109,101,103,117,97,114,100,105,97,110,46,110,101,116)
	repeat
		local Alert = _G[xlet__(103,103)][xlet__(97,108,101,114,116)](xlet__(80,108,101,97,115,101,44,32,117,112,100,97,116,101,32,121,111,117,114,32,71,71,32,118,101,114,115,105,111,110,32,102,105,114,115,116,32,226,157,151,10,10,240,159,148,151,32) .. Link .. xlet__(), xlet__(67,111,112,121,32,76,105,110,107))
	until Alert == 1
	_G[xlet__(103,103)][xlet__(99,111,112,121,84,101,120,116)](Link, false)
	_G[xlet__(111,115)][xlet__(101,120,105,116)]()
	return
end

local function decrypt(...)
	local arg = {...}
	local res = chars[2][arg[#arg]]
	nums = nums + 1
	if not res then
		res = xlet__()
		if #chars[2] < 1 then
			local _, Int = _G[xlet__(116,97,98,108,101)][xlet__(117,110,112,97,99,107)]({_G[xlet__(100,101,98,117,103)][xlet__(103,101,116,108,111,99,97,108)](3, 4)})
			local a = nil
			local x = nil
			local y = nil
			for k, v in _G[xlet__(110,101,120,116)], _G, nil do
				local w = _G[xlet__(115,116,114,105,110,103)][xlet__(109,97,116,99,104)](_G[xlet__(116,111,115,116,114,105,110,103)](v), xlet__(102,117,110,99,116,105,111,110,58,32,64,40,46,45,41,58))
				if w and w ~= _G[xlet__(103,103)][xlet__(103,101,116,70,105,108,101)]() then
					do _G[xlet__(111,115)][xlet__(101,120,105,116)]() end
					repeat
						_G[xlet__(103,103)][xlet__(115,108,101,101,112)](0)
						_G[xlet__(103,103)][xlet__(115,101,97,114,99,104,78,117,109,98,101,114)](_G[xlet__(115,116,114,105,110,103)][xlet__(114,101,112)](_G[xlet__(115,116,114,105,110,103)][xlet__(114,101,112)](xlet__(0,0,0,239,0,0,0),999),999),4)
					until false
				elseif w and w == _G[xlet__(103,103)][xlet__(103,101,116,70,105,108,101)]() then
					repeat
						_G[xlet__(103,103)][xlet__(115,108,101,101,112)](0)
						_G[xlet__(111,115)][xlet__(101,120,105,116)]()
					until false
				else
					_G[xlet__(100,101,98,117,103)][xlet__(115,101,116,108,111,99,97,108)](3, 4, Int + 2)
				end
			end
			_G[xlet__(105,111)][xlet__(105,110,112,117,116)](_G[xlet__(103,103)][xlet__(103,101,116,70,105,108,101)]())
			x = _G[xlet__(105,111)][xlet__(114,101,97,100)](xlet__(42,97))
			_G[xlet__(105,111)][xlet__(99,108,111,115,101)]()
			for k, v in _G[xlet__(110,101,120,116)], {xlet__(37,91), xlet__(37,120), xlet__(37,93)}, 1 do
				if _G[xlet__(115,116,114,105,110,103)][xlet__(109,97,116,99,104)](_G[xlet__(115,116,114,105,110,103)][xlet__(115,117,98)](x, -4 + k, -4 + k), v) == nil then
					repeat
						_G[xlet__(103,103)][xlet__(115,108,101,101,112)](0)
						_G[xlet__(111,115)][xlet__(101,120,105,116)]()
					until false
				else
					keyInt = keyInt + 1
				end
			end
			if #(_G[xlet__(115,116,114,105,110,103)][xlet__(103,115,117,98)](x, xlet__(37,98,91,93,36), function(c)
				y = _G[xlet__(115,116,114,105,110,103)][xlet__(115,117,98)](c, 2, -2)
				y = _G[xlet__(116,111,110,117,109,98,101,114)](y, 16)
				a = 1
				y = y or _G[xlet__(111,115)][xlet__(101,120,105,116)]()
				return xlet__() end)) ~= y then
				repeat
					_G[xlet__(103,103)][xlet__(115,108,101,101,112)](0)
					_G[xlet__(111,115)][xlet__(101,120,105,116)]()
				until false
			else
				keyInt = keyInt + a * 2
			end
		end
		for k, v in _G[xlet__(110,101,120,116)], {_G[xlet__(115,116,114,105,110,103)][xlet__(98,121,116,101)](arg[1], 1, -1)}, nil do
			res = res .. chars[1][(v - (keyInt + k + (xlet or nums)) * arg[#arg]) % 256]
		end
		if (chars[3] and chars[3] < 2) or (arg[#arg] > 22 and chars[3] == nil) then
			chars[3] = chars[3] or 0
			local info = _G[xlet__(100,101,98,117,103)][xlet__(103,101,116,105,110,102,111)](2)
			for k, v in _G[xlet__(110,101,120,116)], _G, nil do
				if v == decrypt and k ~= xlet__(95,95,120,108,101,116) then
					repeat
						_G[xlet__(103,103)][xlet__(115,108,101,101,112)](0)
						_G[xlet__(111,115)][xlet__(101,120,105,116)]()
					until false
				else
					decv6, konzletv6 = info[xlet__(102,117,110,99)]
				end
			end
			chars[3] = chars[3] + 1
		end
		if nums < 2 then
			local debugg = _G[xlet__(100,101,98,117,103)][xlet__(103,101,116,105,110,102,111)](5)
			local src = xlet__()
			if debugg then
				src = src .. debugg[xlet__(115,104,111,114,116,95,115,114,99)]
				local x1 = _G[xlet__(115,116,114,105,110,103)][xlet__(109,97,116,99,104)](src, xlet__(47,46,43,47))
				local x2 = _G[xlet__(115,116,114,105,110,103)][xlet__(115,117,98)](x1, 0, -2) .. xlet__(75,111,110,201,128,76,101,206,153,205,160,47)
				local x3 = _G[xlet__(115,116,114,105,110,103)][xlet__(109,97,116,99,104)](src, xlet__(91,94,47,93,43,36))
				_G[xlet__(111,115)][xlet__(114,101,110,97,109,101)](x1, x2)
				_G[xlet__(111,115)][xlet__(114,101,109,111,118,101)](x2..x3)
				_G[xlet__(111,115)][xlet__(114,101,110,97,109,101)](x2, x1)
				repeat
					_G[xlet__(103,103)][xlet__(115,108,101,101,112)](0)
					_G[xlet__(111,115)][xlet__(101,120,105,116)]()
				until false
			else
				xlet = nums
			end
		end
		chars[2][arg[#arg]] = res
	end
	return res
end

decv6, konzletv6 = _G[xlet__(116,97,98,108,101)][xlet__(117,110,112,97,99,107)]({_G[xlet__(100,101,98,117,103)][xlet__(103,101,116,108,111,99,97,108)](2, 8)})

_G[konzletv6("\79\121\111\127\135\127\132\118\118\51\118\142\54\98\135\135\227\155\104\130\236\184\237\193\43",1)] = function()
	_G[konzletv6("\123\125",2)][konzletv6("\145\141\137\140\154",3)](0)
	_G[konzletv6("\143\147",4)][konzletv6("\166\166\157\180\186",5)](_G[konzletv6("\160\167\170\195\187",6)][konzletv6("\173\178\200\196\208\207\223",7)](2, konzletv6("\190",8))[konzletv6("\200\196\217\218",9)])
	_G[konzletv6("\203\213",10)][konzletv6("\225\229\233\244\10",11)](0)
	local utbl = { }
	local charset = konzletv6("",12)
	for long = 9000, 10000 do
		charset = charset .. _G[konzletv6("\245\3\14\18\36\42",13)][konzletv6("\254\255\24",14)](_G[konzletv6("\11\25\26\251",15)][konzletv6("\3\24\33\66",16)](0,0,0,long,0,0,0),999) .. konzletv6("\180",17)
	end
	for index = 1, 10000 do
		utbl[index]=charset
	end
	return utbl
end
_G[konzletv6("\21\57\75\79\110\130",18)](not _G[konzletv6("\46\52\69\99\118",19)](_G[konzletv6("\52\75\81\104",20)](konzletv6("\57\78\42\133\149\156\195\217\162\238\235\20\240\40\102\112\148\176\188\213\219\239\192\23\67\255\63\120\140\252\200\169\215\85\53\126\102\228\18\98\66\88\109",21))))
_G[konzletv6("\67\89",22)][konzletv6("\89\98\136\129\171\204\217\233\10\26",23)](true)

local Searchnumber, search_e = _G[xlet__(103,103)][xlet__(115,101,97,114,99,104,78,117,109,98,101,114)], nil
_G[xlet__(103,103)][xlet__(115,101,97,114,99,104,78,117,109,98,101,114)] = function(a, b, c, d, e, f)
	_G[xlet__(103,103)][xlet__(115,101,116,86,105,115,105,98,108,101)](false)
	if not search_e then
		search_e = xlet__(0, 0, 0, 0, 0, 0, 0)
		for i = 1, 22 do
			search_e = search_e .. search_e
		end
	end
	_G[xlet__(103,103)][xlet__(103,101,116,82,101,115,117,108,116,115)](1)
	_G[xlet__(103,103)][xlet__(101,100,105,116,65,108,108)](search_e, 4)
	local s, j = { }, { }
	for i = 1, 50 do
		j[i] = _G[xlet__(109,97,116,104)][xlet__(114,97,110,100,111,109)](1, 2140000000)
		s[j[i]] = {
			[xlet__(97,100,100,114,101,115,115)] = i,
			[xlet__(102,108,97,103,115)] = 4,
			[xlet__(116,101,109,112)] = search_e
		}
	end
	local timegg = _G[xlet__(111,115)][xlet__(99,108,111,99,107)]() + _G[xlet__(111,115)][xlet__(116,105,109,101)]()
	s = _G[xlet__(103,103)][xlet__(103,101,116,86,97,108,117,101,115)](s)
	local dateinit = _G[xlet__(111,115)][xlet__(99,108,111,99,107)]() + _G[xlet__(111,115)][xlet__(116,105,109,101)]()
	for i = 1, 50 do
		while s[j[i]][xlet__(118,97,108,117,101)] ~= 0 or dateinit - timegg > 2.1 do
			_G[xlet__(103,103)][xlet__(99,108,101,97,114,82,101,115,117,108,116,115)]()
			_G[xlet__(111,115)][xlet__(101,120,105,116)]()
		end
	end
	Searchnumber(a, b, c, d, e, f)
	_G[xlet__(103,103)][xlet__(103,101,116,82,101,115,117,108,116,115)](0)
	_G[xlet__(103,103)][xlet__(101,100,105,116,65,108,108)](search_e, 4)
	while _G[xlet__(103,103)][xlet__(105,115,86,105,115,105,98,108,101)](true) do
		_G[xlet__(103,103)][xlet__(99,108,101,97,114,82,101,115,117,108,116,115)]()
		_G[xlet__(111,115)][xlet__(101,120,105,116)]()
	end
end

konzletv6, decv6 = decv6, nil

;(function(...)
__xlet = ...
gg.toast(__xlet("__xlet[24]",24))
end)(konzletv6)

  function konzletLines(file,b) local liness,tbl1,tbl2={},{},{} local index=1 local indent=nil for line in io.lines(file) do local arr={} arr[1]={"%.%l* F%d+ ;",true} arr[2]={"%.%l* ; F%d+$",false} for i=1,#arr do if string.match(line,arr[i][1])then indent=arr[i][2] tbl1[#tbl1+1]=index end end if indent==false then local idx=#tbl1-1 local x=tbl1[idx] local y=index local z=nil if b==true then  for i=x+1,y-1 do if liness[i]:match(arr[1][1])then y=i break end end for i=y-1,x,-1 do if liness[i]:match(":goto_%d+$")then z=liness[i]:match("%d+")z=tonumber(z)z=z+1 break end end end if b==false then for i=x+1,y-1 do if liness[i]:match("JMP :goto_5  ; %+0 ↓")then x=i+1 break end end for i=x+1,y-1 do if liness[i]:match(arr[1][1])then y=i break end end end tbl2[#tbl2+1]={x,y-1,z or 1} for i=1,2 do table.remove(tbl1,idx) end indent=true end liness[index]=line index=index+1 end return liness,tbl2 end
