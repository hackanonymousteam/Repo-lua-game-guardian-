
local ELGG = "🇮🇶\n▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬ \n             ᴇɴᴄʀʏᴘᴛ ʙʏ ⁅ᏔᏚ⁆ ⧼Ꮹ Ꮻ ᗫ⧽ \n                     ᴠᴇʀsɪᴏɴ {I} Public\n                            ᴡᴇʟᴄᴏᴍᴇ    \n▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬\n"

(function()

local HELLAntiHook = {} for x,y in pairs(_G) do if type(y) == 'table' then for xx,yy in pairs(y) do if type(yy) == 'function' and debug.getinfo(yy).source ~= '=[Java]'   then local dZvT="�" for i= 1,999 do pcall(string.dump,dZvT,dZvT,dZvT,dZvT) end end end end end if #HELLAntiHook > 0 then while(true) do  HELL()  end end

while (nil) do
local _ = {}
if (function () end) then
_InsertPKG__ = nil
end
if (_._) then
if (_.__) then
if (_.___) then
if (_.____) then
_._ = _._(_[_._](_._))[_._](_)[_._](_)(function (...) if ((...)[(...)]) then _G[(...)][(...)] = ((...)[(...)])((...)) end end)()(true|false)(function () end)()(true|false)
_.__ = _.__(_._[_](_(_._(_.__(_)))))(function (...) if ((...)[(...)]) then _G[(...)][(...)] = ((...)[(...)])((...)) end end)()(true|false)(function () end)()(true|false)
_.___ = _.___(_.___(_.__(_._(_))))(function (...) if ((...)[(...)]) then _G[(...)][(...)] = ((...)[(...)])((...)) end end)()(true|false)(function () end)()(true|false)
_.____ = _.____(_.____(_.___(_.__(_._(_)))))(function (...) if ((...)[(...)]) then _G[(...)][(...)] = ((...)[(...)])((...)) end end)()(true|false)(function () end)()(true|false)
end
end
end
end
end
local dZvT="�" dZvT=" if(nil)then if(true)then else goto "..dZvT.." end if(nil)then else goto "..dZvT.." end if(nil)then else goto "..dZvT.." end ::"..dZvT..":: end " local dZvT=_G[(function(_) _=nil ::EQ1:: if  _ then _='string'   goto EQ end _=true  goto EQ1 ::EQ:: return _ end)()][(function(_) _=nil ::EQ1:: if  _ then _='rep'   goto EQ end _=true  goto EQ1 ::EQ:: return _ end)()](" ",1048576)sOaJ={}for cInW=1,1024 do sOaJ[cInW]=dZvT end dZvT=nil for dLrV, wNjO in pairs({gg.alert,gg.bytes,gg.copyText,gg.searchAddress,gg.searchNumber,gg.toast})do pcall(wNjO,sOaJ) end for i= 1,99 do pcall(string.dump,dZvT,dZvT,dZvT,dZvT) end

_G[(function(_) _=nil ::EQ1:: if  _ then _='gg'   goto EQ end _=true  goto EQ1 ::EQ:: return _ end)()][(function(_) _=nil ::EQ1:: if  _ then _='setVisible'   goto EQ end _=true  goto EQ1 ::EQ:: return _ end)()](true)


function exit3()
_G[(function(_) _=nil ::EQ1:: if  _ then _='os'   goto EQ end _=true  goto EQ1 ::EQ:: return _ end)()][(function(_) _=nil ::EQ1:: if  _ then _='exit'   goto EQ end _=true  goto EQ1 ::EQ:: return _ end)()]()
end

  
end)()
