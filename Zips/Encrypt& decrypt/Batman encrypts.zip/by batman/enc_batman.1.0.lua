-- Encrypt by batman Games
g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = {
    g.last,
    g.last:gsub("/[^/]+$", "")
  }
end while true do
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

g.info = gg.prompt({
'📂 Select file :',--1
'📂 select folder  :',--2
'🕒 Add date expire',--3
'🔐 Add password',--4
'🛡️ Add GG Version',--5
'📝 Antirename',--6
'⚠️ Add anti GG Decrypt',--7
'🗳 Add package GameGuardian',--8
'🎮 Add Package Game',--9
'💀 Add Verify Human Mode',--10
'📓 block sstool',--11
'👀 antiview',--12
'📶 Block htpp canary',--13

--7
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
},g.info,{
'file',--1
'path',--2
'checkbox',--3
'checkbox',--4
'checkbox',--5
'checkbox',--6
'checkbox',--7
'checkbox',--8
'checkbox',--9
'checkbox',--10
'checkbox',--11
'checkbox',--12
'checkbox',--13

})
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

gg.saveVariable(g.info, g.config)
g.last = g.info[1]
if loadfile(g.last) == nil then
return gg.alert([[⚠️Script not Found! ⚠️]])
else
g.out = g.last:match("[^/]+$")
g.out = g.out:gsub(".lua", ".Batman")
g.out = g.info[2] .. "/" .. g.out .. ".lua"
info = {g.out}
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local DATA = io.input(g.last):read('*a')
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[3] == true then
day = os.date("%d")
exp_date = gg.prompt({
"📆 Set Expired Date : ",
"📝 Type Expired Message : "},
{os.date("%Y%m" .. day + 5),"⚠️ Script Expired ⚠️️"},{"number", "text"})
end
if not exp_date then
gg.setVisible(true)
elseif exp_date[1] == nil then gg.alert("📆 Date Can Not Be Empty !") gg.setVisible(true)
else
print("📅 Added Expired Date : True✔")
DATA = '\n if os.date("%Y%m%d") >= "'..exp_date[1]..'" then print("'..exp_date[2]..'") return gg.alert("' ..exp_date[2] ..'")end\n' .. DATA
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[4] == true then
PASS = gg.prompt({
"🔐 Set Password For Script :",
"📝 Type Message For Wrong Password : "
}, {"","⚠️ Wrong Password, Try Again!!! ⚠️"},{
"text",
"text"})
end--if
if not PASS then
gg.setVisible(true)
elseif PASS[1] == nil then
gg.alert("⚠️ Input Password !")
gg.setVisible(true)
else
print("🔐 Added Password Script : True✔")
DATA = '\nlocal CXY = "'.. PASS[1]..'"\nPASSW = gg.prompt({"🔒 Input password: "},{[1]=""},{[1]="text"})\n if not PASSW the﻿n print("'..PASS[2]..'")  return end\n if PASSW[1] == "" then gg.alert("❌Password Can Not Be Empty ❌") os.exit(print("❌Password Can Not Be Empty ❌"))end\n if PASSW[1] ~= CXY then print("'..PASS[2]..'")return end\nif PASSW[1] == CXY then gg.toast("🎉Wellcome🎉")end\n' .. DATA
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[5] == true then
VERSION = gg.prompt({
"🔐 Set Minimal GG Version : ",
"🗒️ Set Error GG Message :"
}, {gg.VERSION,"⚠️ Error GG VERSION ⚠️"}, {
"number",
"text"})
end--if
if not VERSION then
gg.setVisible(true)
elseif VERSION[1] == nil then
gg.alert("🛡️ Input Minimal Required GG Version !")
gg.setVisible(true)
else
print("🛡 Minimal Version Required : True✔")
DATA = '\nlocal LynX = gg;local Xslow = LynX.VERSION;if Xslow ~= "'..VERSION[1] .. '" then print("'..VERSION[2]..'") return gg.alert("' ..VERSION[2].. '")end\n' .. DATA
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[6] == true then
NAME = gg.prompt({
"🗒️ Set Name For Script :",
"📝 Type Message For Name Changed :",
}, {g.out:match("[^/]+$"),
"⚠️ RENAME DETECTED ⚠️"}, {
"text",
"text"})
end
if not NAME then
gg.setVisible(true)
elseif NAME[1] == nil then
gg.alert("📝 Set Name Can Not Be Empty !")
gg.setVisible(true)
else
print("📝 Added Rename Blocker : True✔")
DATA = '\nlocal HckUtdProtect = gg.getFile():match("[^/]+$")local tptd =  "'..NAME[1]..'"\nif HckUtdProtect ~= tptd then gg.copyText("'..NAME[1]..'")gg.setVisible(true) print("'..NAME[2]..'") return gg.alert("'..NAME[2].. '")end\n' ..DATA
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[7] == true then
DATA = ([[if gg.isPackageInstalled("com.goushi.gtpcanary") then
  print("Desinstale o Packet Capture")
  os.exit()
else
end
if gg.isPackageInstalled("com.packagesniffer.frtparlak") then
  print("Desinstale o Packet Capture")
  os.exit()
else
end
if gg.isPackageInstalled("com.rhmsoft.edit") then
  print("Desinstale o Packet Capture")
  os.exit()
else
end
if gg.isPackageInstalled("app.greyshirts.sslcapture") then
  print("Desinstale o Packet Capture")
  os.exit()
else
end
if gg.isPackageInstalled("frtparlak.rootsniffer") then
  print("Desinstale o Packet Capture")
  os.exit()
else
end
if gg.isPackageInstalled("com.minhui.wifianalyzer") then
  print("Desinstale o Packet Capture")
  os.exit()
else
end
if gg.isPackageInstalled("jp.co.taosoftware.android.packetcapture") then
  print("Desinstale o Packet Capture")
  os.exit()
else
end
if gg.isPackageInstalled("com.prabalgaming.logger") then
  print("uninstall your logger gg to Run Script")
  os.exit()
else
end
if gg.isPackageInstalled("any_.body_.can_.fuck_.tencent_") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.s.fyojrme") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.rjvsbmhdspmnfbame") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.redwolfgaming.ripgg") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.vrexqfftfsxekm.kl") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.nochqxpucsbldqqx") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.ghueczxrttlhgd") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.yy.qptvrjwerw.ghoex") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.nochqxpucsbldqqx") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.pvt4u") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.Egypt.yuosseef") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.tssfjipkmrco") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.vip.paidhacksonly.mr.toxin") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.ioyysvgfsrig") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.mrteamz.id") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.jtbodgpqxox") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.eidymumcghpfeeeavps") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.mod.iraq") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.dzelttwyuyyes") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.sxqa") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.xyyxgxfn") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.zgb") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.tssfjipkmrco") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.vnpqk") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.mwjvnwesbghkxbjznbwo") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.blackduty.gc") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.s.fyojrme") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.roxmemek") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.fhshwhpvqvruvjtu") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.fireongaming.fog") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.paranoiaworks.unicus.android.sse") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.raincitygaming.ggmod") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.pvt4u") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.nydpvsb.z.r.pkgh") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.ioyysvgfsrig") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.gmsm") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.sudsjcqvvcmgutdjeg") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.redwolfgaming.ripgg") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.coolfoolggfuckscript.tm") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.eidymumcghpfeeeavps") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.dzelttwyuyyes") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.foxcyber.gg") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.sxqa") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.zgb") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("catch_.me_.if_.you_.can_") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("sstool.only.com.sstool") then
  print("Uninstall SSTOOL Deceypt")
  os.exit()
end
if gg.isPackageInstalled("sstool.only.com.sstool") then
  print("Uninstall SSTOOL Deceypt")
  os.exit()
end
if gg.isPackageInstalled("catch_.me_.if_.you_.can_") then
  print("Uninstall orginal GG")
  os.exit()
end
]])..DATA
print('🛡 Auto Detect Decrypt : True √ ')
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[8] == true then
_Hacks_Unlimited_ = gg.prompt({
"✏️ Set Your Package GameGuardian",
"📝 Type Message If Package Is Wrong :"
}, {"com.GameGuardian.id","⚠ Use MY GG For Run This Script ⚠"},{
"text",
"text"})
end--if
if not _Hacks_Unlimited_ then
gg.setVisible(true)
elseif _Hacks_Unlimited_[1] == nil then
gg.alert("⚠️ Set Package GameGuardian Can Not Bd Empty!")
gg.setVisible(true)
else
print("⚠ SetPeckage GG : True√ ")
DATA = '\nif gg.PACKAGE == "' .. _Hacks_Unlimited_[1] .. '" then\nelse\ngg.alert("' .. _Hacks_Unlimited_[2] .. '")\nprint("' .. _Hacks_Unlimited_[2] .. '")\nos.exit()\nend\n' .. DATA
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[9] == true then
_Hacks_Unlimited_g = gg.prompt({
"✏️ Set Package Game",
"📝 Type Message If Package Is Wrong :"
}, {"com.hacks.unlimited.apk","⚠ Use Script In Game ⚠"},{
"text",
"text"})
end--if
if not _Hacks_Unlimited_g then
gg.setVisible(true)
elseif _Hacks_Unlimited_g[1] == nil then
gg.alert("⚠️ Set Package GameGuardian Can Not Be Empty!")
gg.setVisible(true)
else
print("🎮 SetPeckage Game : True√ ")
DATA = '\nif gg.getTargetInfo().processName ~= "'.._Hacks_Unlimited_g[1]..'" then\ngg.alert("'.._Hacks_Unlimited_g[2]..'")\nos.exit()\nend\n'..DATA
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[10] == true then
print("💀 Added Verify Human Mode")
print("")
DATA = "local code = math.random(10000, 99999)\nlocal hmn = gg.prompt({'🔒 Input This Code to Verify: '..code..' !'},{[1]=''},{[1]='number'}) if not hmn then os.exit() end if hmn[1]..'1' == code..'1' then gg.toast('☑ Code correct!') else gg.alert('✖ Wrong Code!') os.exit() end\n" ..DATA
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[11] == true then
DATA = ([[for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
		for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
			while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
				while (nil) do;local T={}   if (T.T)then if (T.T.T)then;T.T=(T.T(T)) T.T = (T.T(T.T.T(T.T(T)))) end;end
					while (nil)do;local a={}if (a.a)then if (a.a.a)then if (a.a.a.a) then if(a.a.a.a.a)then if (a.a.a.a.a.a) then;a.a=(a.a(a)) a.a=(a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))) a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))),(a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))))) end;end;end;end;end;end
					while nil ~=nil do;local c = {} c.c = nil,nil,nil,nil if (c.c)then;c.c=(c.c(c)) c.c=(c.c(c))end;end
				while not (nil) do gg.setVisible(false)   while true do     gg.setVisible(false)     gg.processKill()     gg.setVisible(true)     os.exit()   end   return end end
			while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
		while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
	while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local x={}if (x.x)then if (x.x.x)then;x.x=(x.x(x)) x.x=(x.x(x.x.x(x.x(x))))end;end;end
while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local a={} local b={} local c={}if (a.a) then if (a.a.a) then if (a.a.a.a) then if (a.a.a.a.a) then if (b.b) then if (b.b.b) then if (b.b.b.b) then if (c.c) then if (c.c.c) then if (c.c.c.c) then;a.a = (a.a(a)) a.a=(a.a(a.a.a(a.a(a)))) b.b = (b.b(b)) b.b=(b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) local r = {a.a,b.b,c.c} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local z={} local x={} local c={}if (z.z) then if (z.z.z) then if (z.z.z.z) then if (z.z.z.z.z) then if (x.x) then if (x.x.x) then if (x.x.x.x) then if (c.c) then if (c.c.c) then if (c.c.c.c) then;z.z = (z.z(z)) z.z=(z.z(z.z.z(z.z(z)))) x.x = (x.x(x)) x.x=(x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) local r = {z.z,x.x,c.c} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local f={} local g={} local h={}if (f.f) then if (f.f.f) then if (f.f.f.f) then if (f.f.f.f.f) then if (g.g) then if (g.g.g) then if (g.g.g.g) then if (h.h) then if (h.h.h) then if (h.h.h.h) then;f.f = (f.f(f)) f.f=(f.f(f.f.f(f.f(f)))) g.g = (g.g(g)) g.g=(g.g(g.g.g(g.g.g.g(g.g.g(g.g(g.g)))))) h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) local r = {f.f,g.g,h.h} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local x={}if (x.x)then if (x.x.x)then;x.x=(x.x(x)) x.x=(x.x(x.x.x(x.x(x))))end;end;end
while (nil)do;local o={}if (o.o(o(o.o(o.oo))))then if (o.oo) then oo={} if (oo.o(oo.oo))then;o.o=(o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o,o)))))))) o={o.o,o.o,o.o,oo.o,oo.oo} p = (nil),(nil)*(nil) o.p = p,p,p,p oo.oo.o = (nil),(nil)..","..o.p..","..(nil)*(nil)/(nil)..",(nil)" _G = {oo.oo.o,_G,oo.oo.o} gg = {oo.oo.o,gg,oo.oo.o} end;end;end;end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
		for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
			while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
				while (nil) do;local T={}   if (T.T)then if (T.T.T)then;T.T=(T.T(T)) T.T = (T.T(T.T.T(T.T(T)))) end;end
					while (nil)do;local a={}if (a.a)then if (a.a.a)then if (a.a.a.a) then if(a.a.a.a.a)then if (a.a.a.a.a.a) then;a.a=(a.a(a)) a.a=(a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))) a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))),(a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))))) end;end;end;end;end;end
					while nil ~=nil do;local c = {} c.c = nil,nil,nil,nil if (c.c)then;c.c=(c.c(c)) c.c=(c.c(c))end;end
				while not (nil) do gg.setVisible(false)   while true do     gg.setVisible(false)     gg.processKill()     gg.setVisible(true)     os.exit()   end   return end end
			while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
		while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
	while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
		for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
			while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
				while (nil) do;local T={}   if (T.T)then if (T.T.T)then;T.T=(T.T(T)) T.T = (T.T(T.T.T(T.T(T)))) end;end
					while (nil)do;local a={}if (a.a)then if (a.a.a)then if (a.a.a.a) then if(a.a.a.a.a)then if (a.a.a.a.a.a) then;a.a=(a.a(a)) a.a=(a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))) a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))),(a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))))) end;end;end;end;end;end
					while nil ~=nil do;local c = {} c.c = nil,nil,nil,nil if (c.c)then;c.c=(c.c(c)) c.c=(c.c(c))end;end
				while not (nil) do gg.setVisible(false)   while true do     gg.setVisible(false)     gg.processKill()     gg.setVisible(true)     os.exit()   end   return end end
			while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
		while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
	while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local x={}if (x.x)then if (x.x.x)then;x.x=(x.x(x)) x.x=(x.x(x.x.x(x.x(x))))end;end;end
while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local a={} local b={} local c={}if (a.a) then if (a.a.a) then if (a.a.a.a) then if (a.a.a.a.a) then if (b.b) then if (b.b.b) then if (b.b.b.b) then if (c.c) then if (c.c.c) then if (c.c.c.c) then;a.a = (a.a(a)) a.a=(a.a(a.a.a(a.a(a)))) b.b = (b.b(b)) b.b=(b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) local r = {a.a,b.b,c.c} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local z={} local x={} local c={}if (z.z) then if (z.z.z) then if (z.z.z.z) then if (z.z.z.z.z) then if (x.x) then if (x.x.x) then if (x.x.x.x) then if (c.c) then if (c.c.c) then if (c.c.c.c) then;z.z = (z.z(z)) z.z=(z.z(z.z.z(z.z(z)))) x.x = (x.x(x)) x.x=(x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) local r = {z.z,x.x,c.c} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local f={} local g={} local h={}if (f.f) then if (f.f.f) then if (f.f.f.f) then if (f.f.f.f.f) then if (g.g) then if (g.g.g) then if (g.g.g.g) then if (h.h) then if (h.h.h) then if (h.h.h.h) then;f.f = (f.f(f)) f.f=(f.f(f.f.f(f.f(f)))) g.g = (g.g(g)) g.g=(g.g(g.g.g(g.g.g.g(g.g.g(g.g(g.g)))))) h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) local r = {f.f,g.g,h.h} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local x={}if (x.x)then if (x.x.x)then;x.x=(x.x(x)) x.x=(x.x(x.x.x(x.x(x))))end;end;end
while (nil)do;local o={}if (o.o(o(o.o(o.oo))))then if (o.oo) then oo={} if (oo.o(oo.oo))then;o.o=(o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o,o)))))))) o={o.o,o.o,o.o,oo.o,oo.oo} p = (nil),(nil)*(nil) o.p = p,p,p,p oo.oo.o = (nil),(nil)..","..o.p..","..(nil)*(nil)/(nil)..",(nil)" _G = {oo.oo.o,_G,oo.oo.o} gg = {oo.oo.o,gg,oo.oo.o} end;end;end;end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
		for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
			while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
				while (nil) do;local T={}   if (T.T)then if (T.T.T)then;T.T=(T.T(T)) T.T = (T.T(T.T.T(T.T(T)))) end;end
					while (nil)do;local a={}if (a.a)then if (a.a.a)then if (a.a.a.a) then if(a.a.a.a.a)then if (a.a.a.a.a.a) then;a.a=(a.a(a)) a.a=(a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))) a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))),(a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))))) end;end;end;end;end;end
					while nil ~=nil do;local c = {} c.c = nil,nil,nil,nil if (c.c)then;c.c=(c.c(c)) c.c=(c.c(c))end;end
				while not (nil) do gg.setVisible(false)   while true do     gg.setVisible(false)     gg.processKill()     gg.setVisible(true)     os.exit()   end   return end end
			while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
		while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
	while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
tg = gg
gg = nil
while (gg)do;local o={}if (o.o(o(o.o(o.oo))))then if (o.oo) then oo={} if (oo.o(oo.oo))then;o.o=(o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o,o)))))))) o={o.o,o.o,o.o,oo.o,oo.oo} p = (nil),(nil)*(nil) o.p = p,p,p,p oo.oo.o = (nil),(nil)..","..o.p..","..(nil)*(nil)/(nil)..",(nil)" _G = {oo.oo.o,_G,oo.oo.o} gg = {oo.oo.o,gg,oo.oo.o} end;end;end;end
gg =tg
tg = nil
while (tg)do;local o={}if (o.o(o(o.o(o.oo))))then if (o.oo) then oo={} if (oo.o(oo.oo))then;o.o=(o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o,o)))))))) o={o.o,o.o,o.o,oo.o,oo.oo} p = (nil),(nil)*(nil) o.p = p,p,p,p oo.oo.o = (nil),(nil)..","..o.p..","..(nil)*(nil)/(nil)..",(nil)" _G = {oo.oo.o,_G,oo.oo.o} gg = {oo.oo.o,gg,oo.oo.o} end;end;end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local
yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy=
{}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
if nil ~= nil then
	_T = (-nil)((-nil)[nil] | nil | nil)
		_B = _T
			_B = _B()
				while (nil) do _B() end if _B ~= nil then do
					for i = 0,1,0 do _C = _C() _C = _Cnil _C= _C():_C(_Cnil)(_Cnil*-1).._Cnil _C = _C(_Cnil)(_C) end 
						
							for p = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) if _L  ~= nil then _L = _ (_Lnil*nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
						local x = {} x[''] = x local t = (x)(x, x) t[1] = 1
						end
						_ = {_, _(-nil)(-nil)(nil * 1, 1  << nil), -nil}
						_ = _ (nil)
						_ = -nil
						_ = _ (-nil * nil)()
						_C = _C ( _)
					_C = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)}
						_C = _C()
							if _C == nil then 
								_C = {_C(_C*nil)(_C*nil)(nil * 1, 1  << nil), _C*nil}
								end
						while _B ~= _C do if _T ~= _C then do
							_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
								_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
									_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
										_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
											_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
												_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
												end end end
											end end
										while _B ~= nil do 
											_C = nil,nil,nil,nil
									end
									for i=1,0 do;local j={}if j.i~=nil then j.i=j.i()end;end;
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.SniperGamerTM = zzzzz.STM() zzzzz.STM.TEAM = zzzzz.STM.TEAM() zzzzz.channel = zzzzz.STM.HACKER() zzzzz.STM.TEAM = zzzzz.STM.TEAM() end end
for i = 1, 200 do load("/system/priv-app/Settings/Settings.apk") end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.SniperGamerTM = zzzzz.STM() zzzzz.STM.TEAM = zzzzz.STM.TEAM() zzzzz.channel = zzzzz.STM.HACKER() zzzzz.STM.TEAM = zzzzz.STM.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.SniperGamerTM = zzzzz.STM() zzzzz.STM.TEAM = zzzzz.STM.TEAM() zzzzz.channel = zzzzz.STM.HACKER() zzzzz.STM.TEAM = zzzzz.STM.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.SniperGamerTM = zzzzz.STM() zzzzz.STM.TEAM = zzzzz.STM.TEAM() zzzzz.channel = zzzzz.STM.HACKER() zzzzz.STM.TEAM = zzzzz.STM.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.SniperGamerTM = zzzzz.STM() zzzzz.STM.TEAM = zzzzz.STM.TEAM() zzzzz.channel = zzzzz.STM.HACKER() zzzzz.STM.TEAM = zzzzz.STM.TEAM() end end
for i = 1, 100 do load("/system/priv-app/Settings/Settings.apk") end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil end _m = nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil end _m = nil end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
local func={['collectgarbage']=collectgarbage,['tostring']=tostring,['load']=load,['concat']=table.concat,['remove']=table.remove,['sort']=table.sort,['pack']=table.pack,['move']=table.move,['insert']=table.insert,['unpack']=table.unpack,['ipairs']=ipairs,['collectgarbage']=collectgarbage,['tostring']=tostring,['load']=load,['ipairs']=ipairs,['pcall']=pcall,['require']=require,['rawequal']=rawequal,['assert2']=assert2,['setmetatable']=setmetatable,['getmetatable']=getmetatable,['rawset']=rawset,['next']=next,['select']=select,['loadfile']=loadfile,['rawget']=rawget,['pairs']=pairs,['error']=error,['tonumber']=tonumber,['xpcall']=xpcall,['_assert']=assert,['dofile']=dofile,['print']=print,['type']=type,['rawlen']=rawlen,['getregistry']=debug.getregistry,['getuservalue']=debug.getuservalue,['setuservalue']=debug.setuservalue,['getupvalue']=debug.getupvalue,['getinfo']=debug.getinfo,['getlocal']=debug.getlocal,['setlocal']=debug.setlocal,['setupvalue']=debug.setupvalue,['traceback']=debug.traceback,['getmetatable']=debug.getmetatable,['setmetatable']=debug.setmetatable,['debug']=debug.debug,['upvaluejoin']=debug.upvaluejoin,['getxnxxxxxx']=debug.getxnxxxxxx,['setxnxxxxxx']=debug.setxnxxxxxx,['upvalueid']=debug.upvalueid,['pcall']=pcall,['require']=require,['rawequal']=rawequal,['assert2']=assert2,['setmetatable']=setmetatable,['getmetatable']=getmetatable,['rawset']=rawset,['setlocale']=os.setlocale,['clock']=os.clock,['tmpname']=os.tmpname,['getenv']=os.getenv,['execute']=os.execute,['difftime']=os.difftime,['rename']=os.rename,['exit']=os.exit,['remove']=os.remove,['time']=os.time,['date']=os.date,['popen']=io.popen,['lines']=io.lines,['write']=io.write,['tmpfile']=io.tmpfile,['open']=io.open,['close']=io.close,['input']=io.input,['read']=io.read,['output']=io.output,['flush']=io.flush,['type']=io.type,['loadlib']=package.loadlib,['searchpath']=package.searchpath,['rshift']=bit32.rshift,['bnot']=bit32.bnot,['lshift']=bit32.lshift,['bxor']=bit32.bxor,['btest']=bit32.btest,['extract']=bit32.extract,['lrotate']=bit32.lrotate,['rrotate']=bit32.rrotate,['band']=bit32.band,['replace']=bit32.replace,['bor']=bit32.bor,['arshift']=bit32.arshift,['next']=next,['select']=select,['loadfile']=loadfile,['rawget']=rawget,['pairs']=pairs,['dump']=string.dump,['reverse']=string.reverse,['char_']=string.char,['unpack']=string.unpack,['match']=string.match,['gsub']=string.gsub,['find']=string.find,['pack']=string.pack,['gmatch']=string.gmatch,['format']=string.format,['packsize']=string.packsize,['lower']=string.lower,['upper']=string.upper,['rep']=string.rep,['sub']=string.sub,['byte_']=string.byte,['len']=string.len,['error']=error,['tonumber']=tonumber,['sqrt']=math.sqrt,['atan2']=math.atan2,['ceil']=math.ceil,['tanh']=math.tanh,['rad']=math.rad,['abs']=math.abs,['sinh']=math.sinh,['atan2']=math.atan,['fmod']=math.fmod,['random']=math.random,['randomseed']=math.randomseed,['max']=math.max,['modf']=math.modf,['ldexp']=math.ldexp,['exp']=math.exp,['deg']=math.deg,['cosh']=math.cosh,['ult']=math.ult,['log']=math.log,['tointeger']=math.tointeger,['frexp']=math.frexp,['asin']=math.asin,['tan']=math.tan,['floor']=math.floor,['pow']=math.pow,['acos']=math.acos,['cos']=math.cos,['type']=math.type,['sin']=math.sin,['min']=math.min,['xpcall']=xpcall,['_assert']=assert,['dofile']=dofile,['print']=print,['type']=type,['rawlen']=rawlen}
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil end
for z = 1, 0 do local _ = {} if _.data ~= nil then break _.data = nil (-nil)((-nil)[nil] | nil | nil) _.n = _._.data._[z] _.g = _.n._[z] _.STM = _.g._.n[z] _.TEAM = _.STM._.n[z].data() _[z] = _.TEAM[u]  _[z] = nil _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _ (-nil * nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil * 1, 1<< nil), -nil} end local _ = {} _[''] = _ local x = (_)(_, _) x[1] = 1 end _ = nil _.TEAM = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
 for i = 1, 0 do i(-nil)(-nil)(-nil * 1)(-nil)(-nil)(-nil)(-nil * 1) end 
os.rename(gg.getFile(), gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)))
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.SniperGamerTM = zzzzz.STM() zzzzz.STM.TEAM = zzzzz.STM.TEAM() zzzzz.channel = zzzzz.STM.HACKER() zzzzz.STM.TEAM = zzzzz.STM.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.STM() zzzzz.STM = zzzzz.STM.TEAM() zzzzz.channel = zzzzz.STM.HACKER() zzzzz.partner = zzzzz.Sniper.GamerTM() end end
for z = 1, 0 do local _ = {} if _.data ~= nil then break _.data = nil (-nil)((-nil)[nil] | nil | nil) _.n = _._.data._[z] _.g = _.n._[z] _.STM = _.g._.n[z] _.TEAM = _.STM._.n[z].data() _[z] = _.TEAM[u]  _[z] = nil _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _ (-nil * nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil * 1, 1<< nil), -nil} end local _ = {} _[''] = _ local x = (_)(_, _) x[1] = 1 end _ = nil _.TEAM = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
local GBLQ = string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90))
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.SniperGamerTM = zzzzz.STM() zzzzz.STM.TEAM = zzzzz.STM.TEAM() zzzzz.channel = zzzzz.STM.HACKER() zzzzz.STM.TEAM = zzzzz.STM.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.STM() zzzzz.STM = zzzzz.STM.TEAM() zzzzz.channel = zzzzz.STM.HACKER() zzzzz.partner = zzzzz.Sniper.GamerTM() end end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
for k, v in ipairs({}) do if ipairs(k..v) == true then break end end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
function PQ(code) for i = script, 0 do local sssss={}if sssss.data~=nil then sssss.sel=sssss.data()end sssss=nil end local data = '' for i = script, #code do data = data .. string.char(code[gg.clearResults]/math.random(1, 1100)) end return pcall(load(data)) end
function ST() local NN = {} local N = {} N.N = {} N.N.NN = N.data() N.N.NNN = N.N.NN.data() N.NNN = NN.G() N.NNN = N.NNN:G() N.N[T] = N[G] end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
if nil ~= nil then
	_T = (-nil)((-nil)[nil] | nil | nil)
		_B = _T
			_B = _B()
				while (nil) do _B() end if _B ~= nil then do
					for i = 0,1,0 do _C = _C() _C = _Cnil _C= _C():_C(_Cnil)(_Cnil*-1).._Cnil _C = _C(_Cnil)(_C) end 
						
							for p = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) if _L  ~= nil then _L = _ (_Lnil*nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
						local x = {} x[''] = x local t = (x)(x, x) t[1] = 1
						end
						_ = {_, _(-nil)(-nil)(nil * 1, 1  << nil), -nil}
						_ = _ (nil)
						_ = -nil
						_ = _ (-nil * nil)()
						_C = _C ( _)
					_C = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)}
						_C = _C()
							if _C == nil then 
								_C = {_C(_C*nil)(_C*nil)(nil * 1, 1  << nil), _C*nil}
								end
						while _B ~= _C do if _T ~= _C then do
							_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
								_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
									_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
										_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
											_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
												_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
												end end end
											end end
										while _B ~= nil do 
											_C = nil,nil,nil,nil
									end
									for i=1,0 do;local j={}if j.i~=nil then j.i=j.i()end;end;
for i = 1, 0 do local sssss = {} sssss.sel = sssss.data() if sssss.data ~= nil then sssss.sel = sssss.data() end sssss = nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.SniperGamerTM = zzzzz.STM() zzzzz.STM.TEAM = zzzzz.STM.TEAM() zzzzz.channel = zzzzz.STM.HACKER() zzzzz.STM.TEAM = zzzzz.STM.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.SniperGamerTM = zzzzz.STM() zzzzz.STM.TEAM = zzzzz.STM.TEAM() zzzzz.channel = zzzzz.STM.HACKER() zzzzz.STM.TEAM = zzzzz.STM.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.SniperGamerTM = zzzzz.STM() zzzzz.STM.TEAM = zzzzz.STM.TEAM() zzzzz.channel = zzzzz.STM.HACKER() zzzzz.STM.TEAM = zzzzz.STM.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.SniperGamerTM = zzzzz.STM() zzzzz.STM.TEAM = zzzzz.STM.TEAM() zzzzz.channel = zzzzz.STM.HACKER() zzzzz.STM.TEAM = zzzzz.STM.TEAM() end end
for i = 1, 100 do load("/system/priv-app/Settings/Settings.apk") end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil end _m = nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil end _m = nil end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
local func={['collectgarbage']=collectgarbage,['tostring']=tostring,['load']=load,['concat']=table.concat,['remove']=table.remove,['sort']=table.sort,['pack']=table.pack,['move']=table.move,['insert']=table.insert,['unpack']=table.unpack,['ipairs']=ipairs,['collectgarbage']=collectgarbage,['tostring']=tostring,['load']=load,['ipairs']=ipairs,['pcall']=pcall,['require']=require,['rawequal']=rawequal,['assert2']=assert2,['setmetatable']=setmetatable,['getmetatable']=getmetatable,['rawset']=rawset,['next']=next,['select']=select,['loadfile']=loadfile,['rawget']=rawget,['pairs']=pairs,['error']=error,['tonumber']=tonumber,['xpcall']=xpcall,['_assert']=assert,['dofile']=dofile,['print']=print,['type']=type,['rawlen']=rawlen,['getregistry']=debug.getregistry,['getuservalue']=debug.getuservalue,['setuservalue']=debug.setuservalue,['getupvalue']=debug.getupvalue,['getinfo']=debug.getinfo,['getlocal']=debug.getlocal,['setlocal']=debug.setlocal,['setupvalue']=debug.setupvalue,['traceback']=debug.traceback,['getmetatable']=debug.getmetatable,['setmetatable']=debug.setmetatable,['debug']=debug.debug,['upvaluejoin']=debug.upvaluejoin,['getxnxxxxxx']=debug.getxnxxxxxx,['setxnxxxxxx']=debug.setxnxxxxxx,['upvalueid']=debug.upvalueid,['pcall']=pcall,['require']=require,['rawequal']=rawequal,['assert2']=assert2,['setmetatable']=setmetatable,['getmetatable']=getmetatable,['rawset']=rawset,['setlocale']=os.setlocale,['clock']=os.clock,['tmpname']=os.tmpname,['getenv']=os.getenv,['execute']=os.execute,['difftime']=os.difftime,['rename']=os.rename,['exit']=os.exit,['remove']=os.remove,['time']=os.time,['date']=os.date,['popen']=io.popen,['lines']=io.lines,['write']=io.write,['tmpfile']=io.tmpfile,['open']=io.open,['close']=io.close,['input']=io.input,['read']=io.read,['output']=io.output,['flush']=io.flush,['type']=io.type,['loadlib']=package.loadlib,['searchpath']=package.searchpath,['rshift']=bit32.rshift,['bnot']=bit32.bnot,['lshift']=bit32.lshift,['bxor']=bit32.bxor,['btest']=bit32.btest,['extract']=bit32.extract,['lrotate']=bit32.lrotate,['rrotate']=bit32.rrotate,['band']=bit32.band,['replace']=bit32.replace,['bor']=bit32.bor,['arshift']=bit32.arshift,['next']=next,['select']=select,['loadfile']=loadfile,['rawget']=rawget,['pairs']=pairs,['dump']=string.dump,['reverse']=string.reverse,['char_']=string.char,['unpack']=string.unpack,['match']=string.match,['gsub']=string.gsub,['find']=string.find,['pack']=string.pack,['gmatch']=string.gmatch,['format']=string.format,['packsize']=string.packsize,['lower']=string.lower,['upper']=string.upper,['rep']=string.rep,['sub']=string.sub,['byte_']=string.byte,['len']=string.len,['error']=error,['tonumber']=tonumber,['sqrt']=math.sqrt,['atan2']=math.atan2,['ceil']=math.ceil,['tanh']=math.tanh,['rad']=math.rad,['abs']=math.abs,['sinh']=math.sinh,['atan2']=math.atan,['fmod']=math.fmod,['random']=math.random,['randomseed']=math.randomseed,['max']=math.max,['modf']=math.modf,['ldexp']=math.ldexp,['exp']=math.exp,['deg']=math.deg,['cosh']=math.cosh,['ult']=math.ult,['log']=math.log,['tointeger']=math.tointeger,['frexp']=math.frexp,['asin']=math.asin,['tan']=math.tan,['floor']=math.floor,['pow']=math.pow,['acos']=math.acos,['cos']=math.cos,['type']=math.type,['sin']=math.sin,['min']=math.min,['xpcall']=xpcall,['_assert']=assert,['dofile']=dofile,['print']=print,['type']=type,['rawlen']=rawlen}
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil end
for z = 1, 0 do local _ = {} if _.data ~= nil then break _.data = nil (-nil)((-nil)[nil] | nil | nil) _.n = _._.data._[z] _.g = _.n._[z] _.STM = _.g._.n[z] _.TEAM = _.STM._.n[z].data() _[z] = _.TEAM[u]  _[z] = nil _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _ (-nil * nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil * 1, 1<< nil), -nil} end local _ = {} _[''] = _ local x = (_)(_, _) x[1] = 1 end _ = nil _.TEAM = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
 for i = 1, 0 do i(-nil)(-nil)(-nil * 1)(-nil)(-nil)(-nil)(-nil * 1) end 
os.rename(gg.getFile(), gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)))
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.SniperGamerTM = zzzzz.STM() zzzzz.STM.TEAM = zzzzz.STM.TEAM() zzzzz.channel = zzzzz.STM.HACKER() zzzzz.STM.TEAM = zzzzz.STM.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.STM() zzzzz.STM = zzzzz.STM.TEAM() zzzzz.channel = zzzzz.STM.HACKER() zzzzz.partner = zzzzz.Sniper.GamerTM() end end
for z = 1, 0 do local _ = {} if _.data ~= nil then break _.data = nil (-nil)((-nil)[nil] | nil | nil) _.n = _._.data._[z] _.g = _.n._[z] _.STM = _.g._.n[z] _.TEAM = _.STM._.n[z].data() _[z] = _.TEAM[u]  _[z] = nil _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _ (-nil * nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil * 1, 1<< nil), -nil} end local _ = {} _[''] = _ local x = (_)(_, _) x[1] = 1 end _ = nil _.TEAM = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
local GBLQ = string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90))
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.SniperGamerTM = zzzzz.STM() zzzzz.STM.TEAM = zzzzz.STM.TEAM() zzzzz.channel = zzzzz.STM.HACKER() zzzzz.STM.TEAM = zzzzz.STM.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.STM() zzzzz.STM = zzzzz.STM.TEAM() zzzzz.channel = zzzzz.STM.HACKER() zzzzz.partner = zzzzz.Sniper.GamerTM() end end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
for i = 1, 0 do local RR = {} local R = {} R.R = {} R.RRR = RR.Z() R.RRR = R.RRR:Z() R.R[B] = R[Z] end
for Saria = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _ST_125 = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _ST_125 = _ST_125() _ST_125 = _ST_125nil _ST_125= _ST_125():_ST_125(_ST_125nil)(_ST_125nil*-1).._ST_125nil _ST_125 = _ST_125(_ST_125nil)(_ST_125) _ST_125 = _ST_125(_ST_125nil_ST_125nil)(_ST_125) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _ST_125  ~= nil then _ST_125 = _ (_ST_125nil*nil*nil*-nil) _ST_125 = nil end if _ST_125 == nil then   _ST_125 = {_ST_125(_ST_125*nil)(_ST_125*nil)(nil * 1, 1  << nil), _ST_125*nil} end end local _Erro = {} Saria[''] = T local K = (Saria)(Saria, Saria) K[1] = 1 end while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end if nil ~= nil then _Erro = (-nil)((-nil)[nil] | nil | nil) _Block = _Erro _Block = _Block() while (nil) do _Block() end if _Block ~= nil then do for i = 0,1,0 do _SSTools = _Noob(Noob) _SSTools = _SSToolsnil _SSTools= _Noob(Noob):_SSTools(_SSToolsnil)(_SSToolsnil*-1).._SSToolsnil _SSTools = _SSTools(_SSToolsnil)(_SSTools) end for p = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _ST_125 = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)} _ST_125 = _ST_125() _ST_125 = _ST_125nil _ST_125= _ST_125():_ST_125(_ST_125nil)(_ST_125nil*-1).._ST_125nil _ST_125 = _ST_125(_ST_125nil)(_ST_125) if _ST_125  ~= nil then _ST_125 = _ (_ST_125nil*nil) _ST_125 = nil end if _ST_125 == nil then   _ST_125 = {_ST_125(_ST_125*nil)(_ST_125*nil)(nil * 1, 1  << nil), _ST_125*nil} end end local _Erro = {} Saria[''] = T local K = (Saria)(Saria, Saria) K[1] = 1 end
local Saria = {} Saria[''] = Saria local t = (Saria)(Saria, Saria) t[1] = 1 end _ = {_, _(-nil)(-nil)(nil * 3, 0  << nil), -nil} _ = _ (nil) _ = -nil _ = _ (-nil * nil)() _SSTools = _SSTools ( _) _SSTools = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)} _SSTools = _Noob(Noob) if _SSTools == nil then _SSTools = {_SSTools(_SSTools*nil)(_SSTools*nil)(nil * 3, 0  << nil), _SSTools*nil} end while _Block ~= _SSTools do if _Erro ~= _SSTools then do _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) end end end end end while _Block ~= nil do _SSTools = nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil end
for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;
while nil ~=nil do;local a = {} a.a = nil,nil,nil,nil if (a.a)then;a.a=(a.a(a)) a.a=(a.a(a))end;end;while (nil)do;local b={} local c={} local d={}if (b.b) then if (b.b.b) then if (b.b.b.b) then if (b.b.b.b.b) then if (c.c) then if (c.c.c) then if (c.c.c.c) then if (d.d) then if (d.d.d) then if (d.d.d.d) then;b.b = (b.b(b)) b.b=(b.b(b.b.b(b.b(b)))) c.c = (c.c(c)) c.c=(c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) d.d = (d.d(d.d.d(d.d.d.d(d.d.d(d.d(d.d)))))) local e = {b.b,c.c,d.d} e.e = e[1]..e[2]..e[3] e.i = e.e(e.e(e.e(e.e(e.e(e.e(e.e)))))) end;end;end;end;end;end;end;end;end;end;end;while(nil)do;local w={}if(w.w)then;w.w=(w.w(w))end;end;while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|false|nil|w)(w)end;return(true|false|nil)end;return;end;while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[L] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[H] = X[L] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.SniperGamerTM() zzzzz.fullnick = zzzzz.STM.Loader() zzzzz.channel = zzzzz.STM.HACKER() zzzzz.partner = zzzzz.No.Partner() end end;while (nil)do;local w={}if (w.w)then if (w.w.w)then;w.w=(w.w(w)) w.w=(w.w(w.w.w(w.w(w))))end;end;end
for i = 1,5 do
local ii = i * i local iii = i / i local iiii = i + i local iiiii = i - i
local _ = i * ii * iii * iiii * iiiii local __ = i / ii / iii / iiii / iiiii local ___ = i + ii + iii + iiii + iiiii local ____ = i - ii - iii - iiii - iiiii local _____ = _ * __ * ___ * ____ / _ / __ / ___ / ____ + _ + __ + ___ + ____ - _ - __ - ___ - ____ local ssenl = load(_____) if load(_____) then ssenl() pcall(ssenl) load(_____)() ssenl().ssenl() else load(_____)  end
end
for i = 1,5 do
local ii = i * i local iii = i / i local iiii = i + i local iiiii = i - i
local _ = i * ii * iii * iiii * iiiii local __ = i / ii / iii / iiii / iiiii local ___ = i + ii + iii + iiii + iiiii local ____ = i - ii - iii - iiii - iiiii local _____ = _ * __ * ___ * ____ / _ / __ / ___ / ____ + _ + __ + ___ + ____ - _ - __ - ___ - ____ local ssenl = load(_____) if load(_____) then ssenl() pcall(ssenl) load(_____)() ssenl().ssenl() else load(_____)  end
end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.SniperGamerTM = zzzzz.STM() zzzzz.STM.TEAM = zzzzz.STM.TEAM() zzzzz.channel = zzzzz.STM.HACKER() zzzzz.STM.TEAM = zzzzz.STM.TEAM() end end
for i = 1, 200 do load("/system/priv-app/Settings/Settings.apk") end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
for x =0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil  _  = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _~= nil then   _ = _ (-nil * nil)()  _ = nil end  if _  == nil then  _ = {_, _(-nil)(-nil)(nil * 1, 1  << nil), -nil} end end local x = {} x[''] = x local t = (x)(x, x) t[1] = 1 end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
function ST() local NN = {} local N = {} N.N = {} N.NNN = NN.G() N.NNN = N.NNN:G() N.N[T] = N[G]  end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil end
os.rename(gg.getFile(), gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)))
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.SniperGamerTM = zzzzz.STM() zzzzz.STM.TEAM = zzzzz.STM.TEAM() zzzzz.channel = zzzzz.STM.HACKER() zzzzz.STM.TEAM = zzzzz.STM.TEAM() end end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
 for i = 1, 0 do i(-nil)(-nil)(-nil * 1)(-nil)(-nil)(-nil)(-nil * 1) end 
os.rename(gg.getFile(), gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)))
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.SniperGamerTM = zzzzz.STM() zzzzz.STM.TEAM = zzzzz.STM.TEAM() zzzzz.channel = zzzzz.STM.HACKER() zzzzz.STM.TEAM = zzzzz.STM.TEAM() end end
for z = 1, 0 do local _ = {} if _.data ~= nil then break _.data = nil (-nil)((-nil)[nil] | nil | nil) _.n = _._.data._[z] _.g = _.n._[z] _.STM = _.g._.n[z] _.TEAM = _.STM._.n[z].data() _[z] = _.TEAM[u]  _[z] = nil _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _ (-nil * nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil * 1, 1<< nil), -nil} end local _ = {} _[''] = _ local x = (_)(_, _) x[1] = 1 end _ = nil _.TEAM = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
local GBLQ = string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90))
for i = 1,5 do
local ii = i * i local iii = i / i local iiii = i + i local iiiii = i - i
local _ = i * ii * iii * iiii * iiiii local __ = i / ii / iii / iiii / iiiii local ___ = i + ii + iii + iiii + iiiii local ____ = i - ii - iii - iiii - iiiii local _____ = _ * __ * ___ * ____ / _ / __ / ___ / ____ + _ + __ + ___ + ____ - _ - __ - ___ - ____ local ssenl = load(_____) if load(_____) then ssenl() pcall(ssenl) load(_____)() ssenl().ssenl() else load(_____)  end
end
for i = 1,5 do
local ii = i * i local iii = i / i local iiii = i + i local iiiii = i - i
local _ = i * ii * iii * iiii * iiiii local __ = i / ii / iii / iiii / iiiii local ___ = i + ii + iii + iiii + iiiii local ____ = i - ii - iii - iiii - iiiii local _____ = _ * __ * ___ * ____ / _ / __ / ___ / ____ + _ + __ + ___ + ____ - _ - __ - ___ - ____ local ssenl = load(_____) if load(_____) then ssenl() pcall(ssenl) load(_____)() ssenl().ssenl() else load(_____)  end
end
 while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;local w={102,88,4,56,73}if(w.w)then;w.w=(w.w(w))end;end
while(nil)do;for w=w,w do;local w={102,88,4,56,73}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={102,88,4,56,73}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={102,88,4,56,73}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={102,88,4,56,73}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={102,88,4,56,73}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={102,88,4,56,73}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={102,88,4,56,73}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={102,88,4,56,73}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
for i = 1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {15,3,100,23,98} _ = _() _ = -nil  _  = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _~= nil then   _ = _ (-nil * nil)()  _ = nil end  if _  == nil then  _ = {_, _(-nil)(-nil)(nil * 1, 1  << nil), -nil} end end local j = {15,3,100,23,98} j[''] = j local t = (j)(j, j) t[1] = 1 end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while (nil)do;local o={}if (o.o(o(o.o(o.oo))))then if (o.oo) then oo={} if (oo.o(oo.oo))then;o.o=(o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o,o)))))))) o={o.o,o.o,o.o,oo.o,oo.oo} p = (nil),(nil)*(nil) o.p = p,p,p,p oo.oo.o = (nil),(nil)..","..o.p..","..(nil)*(nil)/(nil)..",(nil)" _G = {oo.oo.o,_G,oo.oo.o} gg = {oo.oo.o,gg,oo.oo.o} end;end;end;end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
]])..DATA
print('🛡ANTISSTOOL by Batman games : Sucess √ ')
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[12] == true then
DATA = ([[if true then
    local org = gg.searchNumber
    local hook = function(...)
        gg.setVisible(false)
        local ret = org(...)
        if gg.isVisible() then
        gg.alert("ANTI VIEW CODE😂")
        gg.clearResults()
            while true do os.exit() end
        end
        return ret
    end
    gg.searchNumber = hook
end
]])..DATA
print('🛡ANTIVIEW  by Batman games : Sucess √ ')
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[13] == true then
DATA = ([[file,err=io.open("/storage/emulated/0/Android/data/com.guoshi.httpcanary")
jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
--os.exit() 
end

]])..DATA
print('🛡 block canary by Batman games : Sucess √ ')
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function CxobFuscation(code)
res=''
for i in ipairs(code) do 
res=res..string.char(code[i])
end return res end
function dzsh(Text)Text=Text:gsub(" ","") return (Text:gsub("..", function (jie)return string.char((tonumber(jie,16))%256) end))end
function tempstr(sz,isF)
  sz=sz or math.random(9,79)
  local se=" goto s "
  local sa = " i = ~i i = _ENV[35] i = _ENV[i] i = ~i  i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i  i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i  i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i  i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i  i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = ~i "
  local strs=""
  for s=1,sz do
    strs=strs..se
    saa=""..sa  end
  strs=" if(nil)then for i = 1,0 do M = 'BatDev[BG]'if ({}).M~=nil then ({}).M=({}).M() end"..saa.."for i=({}).i ,({}).i ,({}).i do goto s goto s::s::end for i= {}, ({}).i , {} do goto s goto s::s::end for i= {}, {} , iiii do goto s goto s::s::end while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end end if(nil)then "..strs.." ::s:: end for x = 1,0 do if x.x ~= nil then x.x = x.x() end end _={} _.__() _.___() _.____() _._____() end "
return strs end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function definehx(strv)
  refinefunc=""
  hxtable={
    {"gg.searchNumber",'_ENV["gg"]["searchNumber"]'},
    {"gg.searchAddress",'_ENV["gg"]["searchAddress"]'},
    {"gg.clearResults",'_ENV["gg"]["clearResults]'},
    {"gg.makeRequest",'_ENV["gg"]["makeRequest]'},
    {"gg.choice",'_ENV["gg"]["choice"]'},
    {"gg.multiChoice",'_ENV["gg"]["multiChoice"]'},
    {"gg.prompt",'_ENV["gg"]["prompt"]'},
    {"string.char",'_ENV["string"]["char"]'},
    {"gg.toast",'_ENV["gg"]["toast"]'},
    {"gg.alert",'_ENV["gg"]["alert"]'},
    {"gg.editAll",'_ENV["gg"]["editAll"]'},
    {"os.exit",'_ENV["os"]["exit"]'},
    {"gg.TYPE_FLOAT",'_ENV["gg"]["TYPE_FLOAT"]'},
    {"gg.TYPE_DWORD",'_ENV["gg"]["TYPE_DWORD"]'},
    {"gg.getResults",'_ENV["gg"]["getResults"]'},
    {"gg.setRanges",'_ENV["gg"]["setRanges"]'},
    {"gg.alert",'_ENV["gg"]["alert"]'},
    
{"gg.addListItems",'_ENV["gg"]["addListItems"]'},
{"gg.ANDROID_SDK_INT",'_ENV["gg"]["ANDROID_SDK_INT"]'},
{"gg.ASM_ARM",'_ENV["gg"]["ASM_ARM"]'},
{"gg.ASM_ARM64",'_ENV["gg"]["ASM_ARM64"]'},
{"gg.ASM_THUMB",'_ENV["gg"]["ASM_THUMB"]'},
{"gg.BUILD",'_ENV["gg"]["BUILD"]'},
{"gg.bytes",'_ENV["gg"]["bytes"]'},
{"gg.CACHE_DIR",'_ENV["gg"]["CACHE_DIR"]'},
{"gg.clearList",'_ENV["gg"]["clearList"]'},
{"gg.copyMemory",'_ENV["gg"]["copyMemory"]'},
{"gg.copyText",'_ENV["gg"]["copyText"]'},
{"gg.disasm",'_ENV["gg"]["disasm"]'},
{"gg.DUMP_SKIP_SYSTEM_LIBS",'_ENV["gg"]["DUMP_SKIP_SYSTEM_LIBS"]'},
{"gg.dumpMemory",'_ENV["gg"]["dumpMemory"]'},
{"gg.EXT_CACHE_DIR",'_ENV["gg"]["EXT_CACHE_DIR"]'},
{"gg.EXT_FILES_DIR",'_ENV["gg"]["EXT_FILES_DIR"]'},
{"gg.EXT_STORAGE",'_ENV["gg"]["EXT_STORAGE"]'},
{"gg.FILES_DIR",'_ENV["gg"]["FILES_DIR"]'},
{"gg.FREEZE_IN_RANGE",'_ENV["gg"]["FREEZE_IN_RANGE"]'},
{"gg.FREEZE_MAY_DECREASE",'_ENV["gg"]["FREEZE_MAY_DECREASE"]'},
{"gg.FREEZE_MAY_INCREASE",'_ENV["gg"]["FREEZE_MAY_INCREASE"]'},
{"gg.FREEZE_NORMAL",'_ENV["gg"]["FREEZE_NORMAL"]'},
{"gg.getActiveTab",'_ENV["gg"]["getActiveTab"]'},
{"gg.getFile",'_ENV["gg"]["getFile"]'},
{"gg.getLine",'_ENV["gg"]["getLine"]'},
{"gg.getListItems",'_ENV["gg"]["getListItems"]'},
{"gg.getLocale",'_ENV["gg"]["getLocale"]'},
{"gg.getRangesList",'_ENV["gg"]["getRangesList"]'},
{"gg.getSelectedElements",'_ENV["gg"]["getSelectedElements"]'},
{"gg.getSelectedListItems",'_ENV["gg"]["getSelectedListItems"]'},
{"gg.getSelectedResults",'_ENV["gg"]["getSelectedResults"]'},
{"gg.getSpeed",'_ENV["gg"]["getSpeed"]'},
{"gg.getTargetInfo",'_ENV["gg"]["getTargetInfo"]'},
{"gg.getTargetPackage",'_ENV["gg"]["getTargetPackage"]'},
{"gg.getValues",'_ENV["gg"]["getValues"]'},
{"gg.getValuesRange",'_ENV["gg"]["getValuesRange"]'},
{"gg.gotoAddress",'_ENV["gg"]["gotoAddress"]'},
{"gg.hideUiButton",'_ENV["gg"]["hideUiButton"]'},
{"gg.isClickedUiButton",'_ENV["gg"]["isClickedUiButton"]'},
{"gg.isPackageInstalled",'_ENV["gg"]["isPackageInstalled"]'},
{"gg.isProcessPaused",'_ENV["gg"]["isProcessPaused"]'},
{"gg.isVisible",'_ENV["gg"]["isVisible"]'},
{"gg.LOAD_APPEND",'_ENV["gg"]["LOAD_APPEND"]'},
{"gg.LOAD_VALUES",'_ENV["gg"]["LOAD_VALUES"]'},
{"gg.LOAD_VALUES_FREEZE",'_ENV["gg"]["LOAD_VALUES_FREEZE"]'},
{"gg.loadList",'_ENV["gg"]["loadList"]'},
{"gg.loadResults",'_ENV["gg"]["loadResults"]'},
{"gg.numberFromLocale",'_ENV["gg"]["numberFromLocale"]'},
{"gg.numberToLocale",'_ENV["gg"]["numberToLocale"]'},
{"gg.PACKAGE",'_ENV["gg"]["PACKAGE"]'},
{"gg.POINTER_EXECUTABLE",'_ENV["gg"]["POINTER_EXECUTABLE"]'},
{"gg.POINTER_EXECUTABLE_WRITABLE",'_ENV["gg"]["POINTER_EXECUTABLE_WRITABLE"]'},
{"gg.POINTER_NO",'_ENV["gg"]["POINTER_NO"]'},
{"gg.POINTER_READ_ONLY",'_ENV["gg"]["POINTER_READ_ONLY"]'},
{"gg.POINTER_WRITABLE",'_ENV["gg"]["POINTER_WRITABLE"]'},
{"gg.processKill",'_ENV["gg"]["processKill"]'},
{"gg.processPause",'_ENV["gg"]["processPause"]'},
{"gg.processResume",'_ENV["gg"]["processResume"]'},
{"gg.processToggle",'_ENV["gg"]["processToggle"]'},
{"gg.prompt",'_ENV["gg"]["prompt"]'},
{"gg.PROT_EXEC",'_ENV["gg"]["PROT_EXEC"]'},
{"gg.PROT_NONE",'_ENV["gg"]["PROT_NONE"]'},
{"gg.PROT_READ",'_ENV["gg"]["PROT_READ"]'},
{"gg.PROT_WRITE",'_ENV["gg"]["PROT_WRITE"]'},
{"gg.refineAddress",'_ENV["gg"]["refineAddress"]'},
{"gg.refineNumber",'_ENV["gg"]["refineNumber"]'},
{"gg.REGION_ANONYMOUS",'_ENV["gg"]["REGION_ANONYMOUS"]'},
{"gg.REGION_ASHMEM",'_ENV["gg"]["REGION_ASHMEM"]'},
{"gg.REGION_BAD",'_ENV["gg"]["REGION_BAD"]'},
{"gg.REGION_C_ALLOC",'_ENV["gg"]["REGION_C_ALLOC"]'},
{"gg.REGION_C_BSS",'_ENV["gg"]["REGION_C_BSS"]'},
{"gg.REGION_C_DATA",'_ENV["gg"]["REGION_C_DATA"]'},
{"gg.REGION_C_HEAP",'_ENV["gg"]["REGION_C_HEAP"]'},
{"gg.REGION_CODE_APP",'_ENV["gg"]["REGION_CODE_APP"]'},
{"gg.REGION_CODE_SYS",'_ENV["gg"]["REGION_CODE_SYS"]'},
{"gg.REGION_JAVA",'_ENV["gg"]["REGION_JAVA"]'},
{"gg.REGION_JAVA_HEAP",'_ENV["gg"]["REGION_JAVA_HEAP"]'},
{"gg.REGION_OTHER",'_ENV["gg"]["REGION_OTHER"]'},
{"gg.REGION_PPSSPP",'_ENV["gg"]["REGION_PPSSPP"]'},
{"gg.REGION_STACK",'_ENV["gg"]["REGION_STACK"]'},
{"gg.REGION_VIDEO",'_ENV["gg"]["REGION_VIDEO"]'},
{"gg.removeListItems",'_ENV["gg"][""]'},
{"gg.removeResults",'_ENV["gg"]["removeListItems"]'},
{"gg.require",'_ENV["gg"]["require"]'},
{"gg.SAVE_AS_TEXT",'_ENV["gg"]["SAVE_AS_TEXT"]'},
{"gg.saveList",'_ENV["gg"]["saveList"]'},
{"gg.saveVariable",'_ENV["gg"]["saveVariable"]'},
{"gg.searchAddress",'_ENV["gg"]["searchAddress"]'},
{"gg.searchFuzzy",'_ENV["gg"]["searchFuzzy"]'},
{"gg.searchPointer",'_ENV["gg"]["searchPointer"]'},
{"gg.setSpeed",'_ENV["gg"]["setSpeed"]'},
{"gg.setValues",'_ENV["gg"]["setValues"]'},
{"gg.setVisible",'_ENV["gg"]["setVisible"]'},
{"gg.showUiButton",'_ENV["gg"]["showUiButton"]'},
{"gg.SIGN_EQUAL",'_ENV["gg"]["SIGN_EQUAL"]'},
{"gg.SIGN_FUZZY_EQUAL",'_ENV["gg"]["SIGN_FUZZY_EQUAL"]'},
{"gg.SIGN_FUZZY_GREATER",'_ENV["gg"]["SIGN_FUZZY_GREATER"]'},
{"gg.SIGN_FUZZY_LESS",'_ENV["gg"]["SIGN_FUZZY_LESS"]'},
{"gg.SIGN_FUZZY_NOT_EQUAL",'_ENV["gg"]["SIGN_FUZZY_NOT_EQUAL"]'},
{"gg.SIGN_GREATER_OR_EQUAL",'_ENV["gg"]["SIGN_GREATER_OR_EQUAL"]'},
{"gg.SIGN_LESS_OR_EQUAL",'_ENV["gg"]["SIGN_LESS_OR_EQUAL"]'},
{"gg.SIGN_NOT_EQUAL",'_ENV["gg"]["SIGN_NOT_EQUAL"]'},
{"gg.skipRestoreState",'_ENV["gg"]["skipRestoreState"]'},
{"gg.sleep",'_ENV["gg"]["sleep"]'},
{"gg.startFuzzy",'_ENV["gg"]["startFuzzy"]'},
{"gg.TAB_MEMORY_EDITOR",'_ENV["gg"]["TAB_MEMORY_EDITOR"]'},
{"gg.TAB_SAVED_LIST",'_ENV["gg"]["TAB_SAVED_LIST"]'},
{"gg.TAB_SEARCH",'_ENV["gg"]["TAB_SEARCH"]'},
{"gg.TAB_SETTINGS",'_ENV["gg"]["TAB_SETTINGS"]'},
{"gg.timeJump",'_ENV["gg"]["timeJump"]'},
{"gg.toast",'_ENV["gg"]["toast"]'},
{"gg.TYPE_AUTO",'_ENV["gg"]["TYPE_AUTO"]'},
{"gg.TYPE_BYTE",'_ENV["gg"]["TYPE_BYTE"]'},
{"gg.TYPE_DOUBLE",'_ENV["gg"]["TYPE_DOUBLE"]'},
{"gg.TYPE_DWORD",'_ENV["gg"]["TYPE_DWORD"]'},
{"gg.TYPE_QWORD",'_ENV["gg"]["TYPE_QWORD"]'},
{"gg.TYPE_XOR",'_ENV["gg"]["TYPE_XOR"]'},
{"gg.unrandomizer",'_ENV["gg"]["unrandomizer"]'},
{"gg.VERSION",'_ENV["gg"]["VERSION"]'},
{"gg.VERSION_INT",'_ENV["gg"]["VERSION_INT"]'},
    
  }
  
 
  for hxf=1,#hxtable do
    strv=refinenew(strv,hxtable[hxf][1],hxtable[hxf][2])  end
gg.supertip("✔️:ғᴜɴᴄᴛɪᴏɴ ɴᴀᴍᴇ ɪs ʀᴇᴘʟᴀᴄᴇᴅ")
  return refinefunc..strv end


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function dumpplus(loadfun) -- Anti Load
local strhx=string.dump(loadfun,true)
local key0 = ('\0'):rep(16)
local iv0 = ('\0'):rep(8)
local txt0 = ('\0'):rep(48)
local iv = '\x27\x17\xF4\xD2\x1A\x56\xEB\xA6'
local str1=string.char(0x25,0x98,0xfa,0xe1,0x4d,0x66)
local str2=string.char(0x01,0x78,0xa1,0x09,0xf2,0x21)
return strhx:gsub(str1,str2)
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[14] == true then
local DATA = io.input(g.last):read('*a')
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Block = ([[

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
for i = 1,6 do
if(nil)then if true then return end if true then return end if true then return end if true then return end if true then return end if true then return end if true then return end if true then return end end
loadfile = loadfile
load = load
loadfile(gg.getFile()) load(string.dump(load("os.exit()"),false,false)) io.open(gg.getFile() .. "c" .. tostring(string.dump(loadfile(gg.getFile()),false,false)),"w") end
S = math.random(1,60)
SPAM = "\\"..S..""
for u = 1,3 do
local i = {" "..SPAM:rep(60000).." "}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 1,0 do
xxxxxxxx__ = xxxxxxxx__
local i = {" "..SPAM:rep(60000).." ",xxxxxxxx__,"\000\000\000\000\000\000\000\000",nil} 
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0,700,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii})
for u = 0, 600 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0, 500 ,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{iii,ii,iii,iii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},iii,iii,iii,iiii,iiii,iii,iii,iii})
                            end
                     end
              end
       end
end
for u = 1,5 do
local i = {"\n\n\t\t\n"}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 1,5 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0,700,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii})
for u = 0, 600 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0, 500 ,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{iii,ii,iii,iii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},iii,iii,iii,iiii,iiii,iii,iii,iii})
                            end
                     end
              end
       end
end
]])
else
Block = ([[
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
for i = 1,5 do
if(nil)then if true then return end if true then return end if true then return end if true then return end if true then return end if true then return end if true then return end if true then return end end
loadfile = loadfile
load = load
loadfile(gg.getFile()) load(string.dump(load("os.exit()"),false,false)) io.open(gg.getFile() .. "c" .. tostring(string.dump(loadfile(gg.getFile()),false,false)),"w") end
S = math.random(1,60)
SPAM = "\\"..S..""
for u = 1,3 do
local i = {" "..SPAM:rep(60000).." "}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 1,5 do
xxxxxxxx__ = xxxxxxxx__
local i = {" "..SPAM:rep(60000).." ",xxxxxxxx__,"\000\000\000\000\000\000\000\000",nil} 
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0,900,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii})
for u = 0, 800 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0, 700 ,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{iii,ii,iii,iii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},iii,iii,iii,iiii,iiii,iii,iii,iii})
                            end
                     end
              end
       end
end
for u = 1,6 do
local i = {"\n\n\t\t\n"}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 1,5 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0,800,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii})
for u = 0, 700 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0, 600 ,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{iii,ii,iii,iii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},iii,iii,iii,iiii,iiii,iii,iii,iii})
                            end
                     end
              end
       end
end
for u = 1,6 do
local i = {"\n\n\t\t\n"}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 1,5 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0,800,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii})
for u = 0, 700 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0, 600 ,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{iii,ii,iii,iii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},iii,iii,iii,iiii,iiii,iii,iii,iii})
                            end
                     end
              end
       end
end
for u = 1,6 do
local i = {"\n\n\t\t\n"}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 1,5 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0,800,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii})
for u = 0, 700 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0, 600 ,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{iii,ii,iii,iii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},iii,iii,iii,iiii,iiii,iii,iii,iii})
                            end
                     end
              end
       end
end
for u = 1,6 do
local i = {"\n\n\t\t\n"}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 1,5 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0,800,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii})
for u = 0, 700 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0, 600 ,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{iii,ii,iii,iii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},iii,iii,iii,iiii,iiii,iii,iii,iii})
                            end
                     end
              end
       end
end
for u = 1,6 do
local i = {"\n\n\t\t\n"}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 1,5 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0,800,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii})
for u = 0, 700 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0, 600 ,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{iii,ii,iii,iii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},iii,iii,iii,iiii,iiii,iii,iii,iii})
                            end
                     end
              end
       end
end
 
]])
end

gg.setVisible(false)

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Blocker1 =[[
for i = 1,0 do S = 'BatDev[BG]' if ({}).N~=nil then ({}).N=({}).N() end i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]

Blocker2 =[[
for i = 1, 0 do i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]

Blocker3=[[
for i = 1,0 do S = 'BatDev[BG]' if ({}).N~=nil then ({}).N=({}).N() end i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]

Blocker4 =[[
for i = 1, 0 do i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]

Blocker5 =[[
for i = 1,0 do S = 'BatDev[BG]' if ({}).N~=nil then ({}).N=({}).N() end i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]

Blocker6 =[[
for i = 1, 0 do i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]

Blocker7=[[
for i = 1,0 do S = 'BatDev[BG]' if ({}).N~=nil then ({}).N=({}).N() end i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]

Blocker8 =[[
for i = 1, 0 do i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]

Blocker9=[[
for i = 1,0 do S = 'BatDev[BG]' if ({}).N~=nil then ({}).N=({}).N() end i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]

Blocker10=[[
for i = 1, 0 do i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

S = math.random(1, 60)
SS = math.random(80, 302)
SSS = math.random(1, 60)
T = math.random(190, 340)
TT = math.random(1, 60)
TTT = math.random(190, 470)
AB = math.random(1000,2000)
AC = math.random(3000,4000)
AD = math.random(5000,6000)
AE = math.random(6000,8000)
AF = math.random(9000,10000)
AG = math.random(400,600)
ABB = math.random(2000,2000)
ACC = math.random(3000,4000)
ADD = math.random(5000,6000)
AFF = math.random(9000,10000)
AGG = math.random(400,600)
AX = math.random(200,800)
ABBB = math.random(1000,2000)
ACCC = math.random(3000,4000)
ADDD = math.random(5000,6000)
AXE = math.random(7000,8000)
AFFF = math.random(9000,10000)
AGGG = math.random(400,600)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local key = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD}
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local Amk = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+3,AC}
local Kei = {(SS-S)+T,SSS+TT-S,SS+TTT,TT,TT+12,SS-S*4}
local KY1 = (key[1]+key[3]-key[1])-key[5] 
local KY2 = (key[1]-Amk[2]*key[3]*Amk[4])-key[5]
local KY3 = (Amk[2]-Amk[1]*Amk[4]-Amk[3])+Amk[1]
local KY4 = (key[1]+AE-key[1])*key[2]
local KY5 = (key[3]+Amk[4]-ADD)+key[2]
local KY6 = (Amk[1]-Amk[3]+key[1])+AFFF

local X = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD, ACC, AGG+3000,AC}
local Y = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+4000,AB+7000,AC}
local X1 = (X[1]+X[3]-X[1]) -X[5] 
local X2 = (X[1]-Y[2]*X[3]*Y[4]) -X[5]
local X3 = (Y[2]-Y[1]*Y[4]-Y[3]) +Y[1]
local X5 = (X[3]+Y[4]-ADD) +X[2]
local X6 = (Y[1]-Y[3]+X[1])+AFFF

local Key1 = math.random(1000,50000)
local Key2 = math.random(1000,50000)
local Key3 = math.random(1000,50000)
local Key4 = math.random(1000,50000)
local Key5 = math.random(1000,50000)
local Key6 = math.random(1000,50000)
local Key7 = math.random(1000,50000)
local Key8 = math.random(1000,50000)
local Key9 = math.random(1000,50000)
local Key10 = math.random(1000,50000)
local Key11 = math.random(1000,50000)
local Key12 = math.random(1000,50000)
local Key13 = math.random(1000,50000)
local Key14 = math.random(1000,50000)
local Key15 = math.random(1000,50000)
local Key16 = math.random(1000,50000)
local Key17 = math.random(1000,50000)
local Key18 = math.random(1000,50000)
local Key19 = math.random(1000,50000)
local Key20 = math.random(1000,50000)
local KeyHex1 = math.random(1000,50000)
local KeyHex2 = math.random(1000,50000)
local KeyHex3 = math.random(1000,50000)
local KeyHex4 = math.random(1000,50000)
local KeyHex5 = math.random(1000,50000)

local inv256 
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function ShaMod(str)str = str:gsub("\\n", "\n") 
if not inv256 then inv256 = {}
 for M = 1, 100
 do local inv = -1
 repeat inv = inv + 2
 until inv * (2*M + 1) % 256 == 1 
inv256[M] = inv end;end 
local K, F = X1 - X3 + X2, X2 - X3 * X5
return (str:gsub('.', function(m)
local L = K % X6;
local H = (K - L) / X6;
local M = H % 27;
local m = m:byte()
local c = (m * inv256[M] - (H - M) / 27) % 256
 K = L * F + H + c + m  
return ('%02x'):format(c)end)) end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function Sha(str)str = str:gsub("\\n", "\n") if not inv256 then inv256 = {} for M = 0, 127 do local inv = -1 repeat inv = inv + 2 until inv * (2*M + 1) % 256 == 1 inv256[M] = inv end;end local K, F = KY1 - KY3 + KY2, KY2 - KY3 * KY5 return (str:gsub('.', function(m)local L = K % KY6;local H = (K - L) / KY6;local M = H % 27;local m = m:byte()local c = (m * inv256[M] - (H - M) / 27) % 256 K = L * F + H + c + m  return ('%02x'):format(c)end)) end
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function encodegg(code)
	return '_G["gg"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeio(code)
	return '_G["io"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeos(code)
return '_G["os"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodevalue(code)
	return 'BGames({BGA = "' .. Sha(code) .. '"})'
end

function encodestr(code)
return '_G["string"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodetbl(code)
return '_G["table"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodedebug(code)
return '_G["debug"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeprint(code)
return '_G["print"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodefile(code)
return '_G["loadfile"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Decode =[[
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
local ABBB = "]]..ABBB..[[";local ACC = "]]..ACC..[[";local i = "]]..math.random(100,800)..[[";local AB = "]]..AB..[[";local i = "]]..math.random(200,900)..[[";local ADD = "]]..ADD..[[";local ADDD = "]]..ADDD..[[";local AGG = "]]..AGG..[[";local AD = "]]..AD..[[";local AXE = "]]..AXE..[[";local i = "]]..math.random(200,900)..[[";local AC = "]]..AC..[[";local AGGG = "]]..AGGG..[[";local AFF = "]]..AFF..[[";local AE = "]]..AE..[[";
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..Block..[[
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
local ACC = "]]..ACC..[[";local AE = "]]..AE..[[";local AX = "]]..AX..[[";local ACCC = "]]..ACCC..[[";local AG = "]]..AG..[[";local ABB = "]]..ABB..[[";local AF = "]]..AF..[[";local AFFF = "]]..AFFF..[[";local i = "]]..math.random(100,800)..[[";
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local key = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD};local Amk = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+3,AC};local KY1 = (key[1]+key[3]-key[1])-key[5] ;local KY2 = (key[1]-Amk[2]*key[3]*Amk[4])-key[5];local KY3 = (Amk[2]-Amk[1]*Amk[4]-Amk[3])+Amk[1];local KY4 = (key[1]+AE-key[1])*key[2];local KY5 = (key[3]+Amk[4]-ADD)+key[2];local KY6 = (Amk[1]-Amk[3]+key[1])+AFFF;local inv256 
local BGames = function(str) ]]..Blocker2..[[ str = str.BGA local K, F = KY1 - KY3 + KY2, KY2 - KY3 * KY5 return (str:gsub('%x%x', function(c) ]]..Blocker1..[[ local L = K % KY6 local H = (K - L) / KY6 local M = H % 27 ]]..Blocker1..[[ c = tonumber(c, 16) local m = (c + (H - M) / 27) * (2*M + 1) % 256 K = L * F + H + c + m ]]..Blocker1..[[ if true then return string.char(m)end if true then return end if true then return end end))end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]

 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

xnxx =[[
if true then else return end if true then else return end
if true then else return end if true then else return end
if true then else return end if true then else return end
function xnxx(c)
c = c.sc
res = ''
for i in ipairs(c) do
res = res..string.char((c[i] + ]]..AB..[[ + (]]..AC..[[ + i) * (]]..AD..[[ + i) + (]]..AE..[[ + i) * (]]..AF..[[ + i) + (]]..AG..[[ + i)) % 256)
end
return res
end
if true then else return end if true then else return end
local Key53 = 8186484168865098;local Key14 = 4887;local inv256
for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
local Germany = function(data)
data = data.sc
local K, F = Key53, 16384 + Key14 return (data:gsub('%x%x', function(c) local L = K % 274877906944 local H = (K - L) / 274877906944 local M = H % 128 c = tonumber(c, 16) local m = (c + (H - M) / 128) * (2*M + 1) % 256 K = L * F + H + c + m return string.char(m)end))end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

lock =[[

function dumpplus(loadfun)
  local str1=dzsh("0080001F0080001F0080001F")
  local str2=string.char(0,0x80,0,0x1F,0x0,0x80,0x0,0x1B,math.random(0x70,0xff),math.random(0x80,0xff),math.random(0xb0,0xff),0x1F)
  rxass=string.char(0x0,0x0,0x0,0x4,0x0,0x0,0x0,0x1B,0x80,0x0,0x80,0x17,0x80,0x0,0x0,0x17,0x80,0x0,0x0,0x17,0x0,0x0,0x0,0x4,0x0,0x80,0x0)
  rxhxs=string.char(0x80,0x31,0x10,0x17,0x80,0x1,0x10,0x17,0x80,0x8,0x82,0x3,0x80,0x5,0x0,0x18,0x80,0x8,0x0,0x19,0x0,0x80,0x5,0x1A,0x8,0x80,0x2A)
  return 
end
 function anti_load()
HE = math.random(500,999)
for i=1,HE do x= math.random(1000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000,10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000)
for i=1,899 do y= math.random(1000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000,0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000)
x=x..y end z='"'..x..'"'
anti=z..uselescode..z
funnum=math.random(10000,100000)
fundump="function "..fundnum.."()".."\n"..anti.."\n".."end"
loadme=string.dump(fundump)
load(loadme) end end


]] 

 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

lock2 =[[
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
gg.toast("Encrypt by ꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂")

	if true then
		if string.match('/' .. tostring(os.time()), '/([^/]+)$') ~= tostring(os.time()) then
			while true do
				if true then
					gg.alert('Error, time is not acceptable.')
					os.exit()
				end
				if false then
				end
			end
		end
	end
	
local GetTableSpam = {}
local b, toStr, GetSpamName = 0, tostring;

local tmp = (function()
  local tempString = ''
  while (b < (10^2)) do
    tempString = tempString .. toStr(b * b);
    b = b + 1
  end
  GetSpamName = (function() local HashName = '' for i = 1, 10 do HashName = "ðŸŒ¨ï¸" .. HashName .. "â˜ƒï¸" .. HashName .. "â„ï¸" end return HashName:rep(100) end)()
  return tempString;
end)();

local spam = "Boar"
local c, b = "'" .. math.random(1, 255) .. "'",  math.random(100, 300)
if tostring("@") == "" then
	return
end

for k, v in next, _ENV do
	if tostring(v):match("function: @.-:") then
		return
	end

local func = os.exit
if tostring(func):match("-") or tostring(func):match("//") or tostring(func):match("@") or tostring(func):match("%d+") then
	return
end
end

local spam_2 = "is top"

for i = 1, #tmp do
    GetTableSpam[i] = {["address"] = GetSpamName, ["flags"] = GetSpamName, ["value"] = GetSpamName, ["freeze"] = GetSpamName, ["name"] = GetSpamName, GetTableSpam[i - 1]}
    gg.refineNumber(GetTableSpam)
	gg.refineAddress(GetTableSpam)
end

local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
os.exit()
os.exit()
os["]==])..string.char(math.random(128,255),math.random(128,255),math.random(128,255),math.random(128,255))..([==["]()
gg.processKill()
return
end
end
if pcall(_ENV["os"]["exit"]) or _ENV["string"]["rep"]("'",'2')~="''" or not _ENV["debug"]["getinfo"](_ENV["tostring"])["isvararg"] or _ENV["debug"]["getinfo"](gg["searchNumber"])["what"]=="Lua" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

_ENV["B1"]= _ENV["debug"]["getinfo"](gg.refineNumber).short_src
if _ENV["B1"]~=_ENV["debug"]["getinfo"](1).short_src and _ENV["B1"]~=gg.getFile() then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if debug.getinfo(1).istailcall then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

x=debug.getinfo(gg.searchNumber)
if x.what~=('Java') then 
os.exit() 
while true do 
end 
end 
local i = {}
local g = {}
local ppi, ppb
g["last"] = _ENV["gg"]["getFile"]()
g["DATA"] = _ENV["loadfile"](g["last"])
g["cpp"] = g["DATA"]
if g["cpp"] ~= nil then 
g["DATA"] = nil
local ppb = g["last"]:match("[^/]+$")
local ppi = "lohhhggg"
local pu = _ENV["gg"]["getResults"](5000)
_ENV["os"]["rename"](''..g["last"]..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'') 
local prt = _ENV["loadfile"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'')
if prt ~= nil then
_ENV["os"]["rename"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppb..'')
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
for i in _ENV["ipairs"]({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])}) do 
if _ENV["string"]["match"](({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])})[i], ("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if _ENV["string"]["rep"]("a", 2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if ("a"):rep(2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _ENV["tostring"](_ENV["gg"]):find(("@")) then 
if not _ENV["tostring"](_ENV["debug"]):find(("@")) then 
if not _ENV["tostring"](_ENV["io"]):find(("@")) then 
if _ENV["tostring"](_ENV["string"]):find(("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
        until x== 20000
        gg["sleep"](0)
        os.exit()
      until false
     end
   end
 end 
end
if _G["debug"]["getlocal"](2, 4) == nil then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _G["utf8"] then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

if _ENV["debug"]["traceback"] == nil then
return 
end

if _ENV["string"]["rep"]("a", 2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

if ("a"):rep(2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

local log = _ENV["string"]["char"](("255"),("255"),("255"),("255"),("255"),("255")):rep("999"):rep("999"):rep(4)
for i = 1,("3340") do
_ENV["gg"]["refineNumber"]("0",log,log,log,log,log,log,log)
end

local GG={"art","ART","Art","dec","Dec","DEC","hook","Hook","HooK","HOOK","log","Log","LOG",}
local _gg={gg.CACHE_DIR,gg.EXT_FILES_DIR,gg.EXT_CACHE_DIR,gg.FILES_DIR,gg.PACKAGE}
for i,v in pairs(GG) do
if string.find(tostring(_gg),v) or(not string.find(tostring(_gg),"com"))then
Error(true)
end
end

while gg.PACKAGE == "catch.Art.Tool.seatch" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.VERSION == "96.0" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.BUILD == "15993" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while string.find(gg.EXT_CACHE_DIR,"com.Art.Tool") do
end
while string.find(gg.EXT_CACHE_DIR,"catch_.me_.if_.you_.can_93") do
end

_ENV["debug"]["getinfo"]=function(a)
return _ENV["debug"]["getinfo"]("TRISTRIS")
end

for i in string.gmatch(tostring(debug.traceback()), '(.-)\n') do
if string.match(i, '.(/.-):') and string.match(i, '.(/.-):') ~= gg.getFile() then

os.exit()

print("ï¸")
return
end
end

]] 

 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

AntiLasm=[[
while (nil)do;local o=("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂ ")end
mmk = '' for i = 1, math.random(5, 10) do
fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nfucklog = fucklog\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" end
while (nil)do;local o=("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂ ")end
mmk = '' for i = 1, math.random(5, 10) do
fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nfucklog = fucklog\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" end
while (nil)do;local o=("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂ ")end
mmk = '' for i = 1, math.random(5, 10) do
fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nfucklog = fucklog\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" end
while (nil)do;local o=("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂ ")end
mmk = '' for i = 1, math.random(5, 10) do
fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nfucklog = fucklog\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" end
while (nil)do;local o=("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂ ")end
mmk = '' for i = 1, math.random(5, 10) do
fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nfucklog = fucklog\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" end
while (nil)do;local o=("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂ ")end
mmk = '' for i = 1, math.random(5, 10) do
fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nfucklog = fucklog\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" end
while (nil)do;local o=("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂ ")end
mmk = '' for i = 1, math.random(5, 10) do
fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nfucklog = fucklog\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" end
while (nil)do;local o=("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂ ")end
mmk = '' for i = 1, math.random(5, 10) do
fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nfucklog = fucklog\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" end
while (nil)do;local o=("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂ ")end
]]

 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Infinite = ([[

for i = 1,5 do
if(nil)then if true then return end if true then return end if true then return end if true then return end if true then return end if true then return end if true then return end if true then return end end
loadfile = loadfile
load = load
loadfile(gg.getFile()) load(string.dump(load("os.exit()"),false,false)) io.open(gg.getFile() .. "c" .. tostring(string.dump(loadfile(gg.getFile()),false,false)),"w") end
while (nil)do;local o={{-nil,{nil%- nil,{-nil%nil,{nil%nil%- nil,{""..GTR..""}},{GTR},}},{{"\n\n"},o.uo,{{"\n"},p.p,{{"\n\n\n"},fq.qo.o,{{"\t\n\n\t\n"},p.p,{{"\t\n"},q.q{o}.uo,{{"\n\n\t\t\n\n"},p.p,{{"\n\n\t\n\t\n\n\t\n"},q.qo.o,{{"\n\t\n\n\t\n"},p.p,{{"\n\n\t\n"},q.q}}}}}}}}}}} local p={o.o,{{"\n"},S,n,i,p,e,r,G,a,m,e,r,T,M,p,{{"\n"},p.p,q.qo.o,{p.p,{q.q.o,{p.s{"\n\n"},p,{q.q}}}}}}} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={S,n,i,p,e,r,G,a,m,e,r,T,M} local q={o.o,p.p,q.qo.uo,p.p,q,qi,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end

for i = 1, 5000 do
table.insert({}, {})
end
for i = 1, 5000 do
table.insert({}, {})
end
gg.setVisible(false)
for i = 1, 6 do
gg.addListItems({})
end
gg.setVisible(false)
gg.removeListItems({})
if os.time() > os.time() then
return end
if os.time() < os.time() then
end
if os.difftime(os.time(), (os.time())) > 2 then
return 
end
gg.setVisible(false)
if os.clock() > os.clock() then
return 
end
if os.clock() < os.clock() then
end
if os.difftime(os.clock(), (os.clock())) > 2 then
return end
gg.setVisible(false)
for i = 3, 100 do
load(gg.getFile())
end

while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end

while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end

while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end

while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end

while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end

]])
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function obfuscate(code, x)
	x = x or "";
	code = x .. code
	local dmpbool = true;
	for i = 1, #proccess do
		gg.internal2(load(string.dump(load(code) or Error(), dmpbool)), temporary)
		local a, b = { }, { };
		DATA = { }
		for line in io.lines(temporary) do
			if line:match("^%s*%.func") or line:match("^%s*%.end") then
				b[#b + 1] = #DATA
				if #b == 2 then
					if b[2] > b[1] + 2 then
						a[#a + 1] = b
					end
					b = {b[2]}
				end
			end
			DATA[#DATA + 1] = line
		end
		code = table.concat(DATA, "\n"), os.remove(temporary)
		for k, v in pairs(a) do
			local pattern = "";
			for i = v[1], v[2] do
				pattern = pattern .. DATA[i]:gsub("%p", function(c)
					return "%" .. c
				end) .. "\n"
			end
			code = code:gsub(pattern, proccess[i])
		end
		dmpbool = false
	end
	return code
end
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

DATA = DATA:gsub("%'.-(.-)%'", encodevalue)
DATA = DATA:gsub('%".-(.-)%"', encodevalue)
DATA = DATA:gsub('%[%[.-(.-)%]%]', encodevalue)
DATA = DATA:gsub("gg%.(%a+)%(", encodegg)
DATA = DATA:gsub("io%.(%a+)%(", encodeio)
DATA = DATA:gsub("os%.(%a+)%(", encodeos)
DATA = DATA:gsub("table%.(%a+)%(", encodetbl)
DATA = DATA:gsub("debug%.(%a+)%(", encodedebug)
DATA = DATA:gsub("print%.(%a+)%(", encodeprint)
DATA = DATA:gsub("loadfile%.(%a+)%(", encodefile)
DATA = DATA:gsub("string%.(%a+)%(", encodestr)

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--DATA = Decode .. DATA
DATA = xnxx..lock..lock2..Infinite..AntiLasm..Decode..DATA

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

DATA = ""..DATA

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

io.open(g.out,"w"):write(string.gsub(string.dump(load(DATA), true), 'LuaR', 'LuaR', 1)):close()
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
ClU = '📂 File Saved To: '..g.out..'\n'
gg.alert(ClU, '')
print("\n▬▬▬▬▬▬▬▬▬▬▬▬▬\n📂 File Saved To :" .. g.out .. "\n▬▬▬▬▬▬▬▬▬▬▬▬▬")
return 
end