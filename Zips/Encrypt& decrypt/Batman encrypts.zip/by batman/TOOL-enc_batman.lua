function EncryptionTools() 
enc = gg.choice({
"ᴇɴᴄʀʏᴘᴛ v1",
"ᴇɴᴄʀʏᴘᴛ ᴠ2",
"ᴇɴᴄʀʏᴘᴛ ᴠ3",
"ᴇɴᴄʀʏᴘᴛ v4",
"ᴇɴᴄʀʏᴘᴛ v5",
"ᴇɴᴄʀʏᴘᴛ v6",
"ᴇɴᴄʀʏᴘᴛ ᴠ7",
"ᴇɴᴄʀʏᴘᴛ ᴠ8",
"ᴇɴᴄʀʏᴘᴛ v9",
"ᴇɴᴄʀʏᴘᴛ v10",
"ʙᴀᴄᴋ",
},0,"")
if enc == 1 then encv1() end
if enc == 2 then encv2() end
if enc == 3 then encv3() end
if enc == 4 then encv4() end
if enc == 5 then encv5() end
if enc == 6 then encv6() end
if enc == 7 then encv7() end
if enc == 8 then encv8() end
if enc == 9 then encv9() end
if enc == 10 then encv10() end
if enc == 11 then os.exit() end

BATMAN = -1
end


function encv1() 
g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 gg.alert([[

📌 Features
 
Encrypy hash +
Encrypt base 64 +
Encrypt utf8 +
Encrypt chiper +
ofuscation +
sha+
new block Sstool+
antilog +
antiload 
Work gg 101.1✔️

by Batman Games🍿 
My telegram @batmangamesS 
]])
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

while true do
  g.info = gg.prompt({
    '📂 Select file :', -- 1
    '📂 Select folder  :',-- 2
    '🕒 Add date expire',--3
'🔐 Add password',--4
'🛡️ Add GG Version',--5
'📝 Antirename',--6
'⚠️ Add anti GG Decrypt',--7
'🗳 Add package GameGuardian',--8
'🎮 Add Package Game',--9
'💀 Add Verify Human Mode',--10
'👀 antiview',--12
'📶 Block htpp canary',--13
'🔐 required root to start script',--14
'🔐 Add alert with time and date',--15
  }, g.info, {
    'file', -- 1
    'path', -- 2
    'checkbox',--3
'checkbox',--4
'checkbox',--5
'checkbox',--6
'checkbox',--7
'checkbox',--8
'checkbox',--9
'checkbox',--10
'checkbox',--12
'checkbox',--13
'checkbox',--14
'checkbox',--15
  })
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  gg.saveVariable(g.info, g.config)
  g.last = g.info[1]
  if loadfile(g.last) == nil then
    gg.alert("⚠️ Script not Found! ⚠️")
    return
  else
    g.out = g.last:match("[^/]+$")
    g.out = g.out:gsub(".lua", ".Batman")
    g.out = g.info[2] .. "" .. g.out .. ".lua"
  end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  local file = io.open(g.last, "r")
  local DATA = file:read('*a')
  file:close()
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  function CriptografiaImpressionante(str)
      
      local chave_oculta = 42
      local hash = ''
      local tamanho_str = #str

      for i = 1, tamanho_str do
          local byte = str:byte(i) or 0
          local valor = byte + chave_oculta
          local hash_byte = valor % 256
          hash = hash .. string.format('%02x', hash_byte)
      end
      return hash
  end

  DATA = CriptografiaImpressionante(DATA)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  
  function Base64Encode(str)
      local b64chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
      local result = ''
      local len = #str
      local i = 1

      while i <= len do
          local char1 = str:byte(i)
          i = i + 1
          local char2 = i <= len and str:byte(i) or 0
          i = i + 1
          local char3 = i <= len and str:byte(i) or 0
          i = i + 1

          local bits = char1 * 65536 + char2 * 256 + char3

          local enc1 = b64chars:sub(bits / 262144 % 64 + 1, bits / 262144 % 64 + 1)
          local enc2 = b64chars:sub(bits / 4096 % 64 + 1, bits / 4096 % 64 + 1)
          local enc3 = b64chars:sub(bits / 64 % 64 + 1, bits / 64 % 64 + 1)
          local enc4 = b64chars:sub(bits % 64 + 1, bits % 64 + 1)

          if i > len + 2 then
              enc3 = '='
              enc4 = '='
          elseif i > len + 1 then
              enc4 = '='
          end

          result = result .. enc1 .. enc2 .. enc3 .. enc4
      end

      return result
  end

  
  DATA = Base64Encode(DATA)
  
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  function CriptografarUTF8(str)
    local result = {}
    for i = 1, #str do
        local byte = string.byte(str, i)
        local bytes = {}
        while byte > 0 do
            table.insert(bytes, 1, bit32.band(byte, 0xFF))
            byte = bit32.arshift(byte, 8)
        end
        for _, b in ipairs(bytes) do
            table.insert(result, string.char(b))
        end
    end
    return table.concat(result)
end

DATA = CriptografarUTF8(DATA)

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


function CriptografarCifraSubstituicao(texto)
    local chave = {
        a = "x",
        b = "y",
        c = "z",
        d = "a",
        e = "b",
        f = "c",
        g = "d",
        h = "e",
        i = "f",
        j = "g",
        k = "h",
        l = "i",
        m = "j",
        n = "k",
        o = "l",
        p = "m",
        q = "n",
        r = "o",
        s = "p",
        t = "q",
        u = "r",
        v = "s",
        w = "t",
        x = "u",
        y = "v",
        z = "w",
        [" "] = " "
    }
    
    local resultado = ""
    for i = 1, #texto do
        local caractere = texto:sub(i, i)
        local caractereCriptografado = chave[caractere]
        resultado = resultado .. (caractereCriptografado or caractere)
    end
    return resultado
end


DATA = CriptografarCifraSubstituicao(DATA)

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function CxobFuscation(str)
    local res = ''
    for i = 1, #str do
        res = res .. string.char(str:byte(i))
    end
    return res
end

DATA = CxobFuscation(DATA)

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  
  io.open(g.out,"w"):write(DATA):close()
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  
  local descript_code = [[
  
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    function DescriptografiaImpressionante(hash)
        local chave_oculta = 42
        local str = ''
        local tamanho_hash = #hash

        for i = 1, tamanho_hash, 2 do
            local hex_byte = string.sub(hash, i, i+1)
            local hash_byte = tonumber(hex_byte, 16)
            local valor = (hash_byte - chave_oculta) % 256
            str = str .. string.char(valor)
        end
        return str
    end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    
    function Base64Decode(str)
        local b64chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
        local result = ''
        local len = #str
        local i = 1

        while i <= len do
            local char1 = b64chars:find(str:sub(i, i)) - 1
            i = i + 1
            local char2 = b64chars:find(str:sub(i, i)) - 1
            i = i + 1
            local char3 = b64chars:find(str:sub(i, i)) - 1
            i = i + 1
            local char4 = b64chars:find(str:sub(i, i)) - 1
            i = i + 1

            local bits = char1 * 262144 + char2 * 4096 + char3 * 64 + char4

            local byte1 = math.floor(bits / 65536)
            
local byte2 = math.floor(bits / 256) % 256
            local byte3 = bits % 256

            if char3 ~= 64 then
                result = result .. string.char(byte1) .. string.char(byte2) .. string.char(byte3)
            elseif char2 ~= 64 then
                result = result .. string.char(byte1) .. string.char(byte2)
            else
                result = result .. string.char(byte1)
            end
        end

        return result
    end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function DescriptografarUTF8(str)
        local result = {}
        local byte
        local num_bytes = 0
        for i = 1, #str do
            byte = string.byte(str, i)
            if num_bytes == 0 then
                if byte < 0x80 then
                    table.insert(result, string.char(byte))
                elseif byte < 0xE0 then
                    num_bytes = 1
                    byte = bit32.band(byte, 0x1F)
                elseif byte < 0xF0 then
                    num_bytes = 2
                    byte = bit32.band(byte, 0x0F)
                else
                    num_bytes = 3
                    byte = bit32.band(byte, 0x07)
                end
            else
                byte = bit32.bor(bit32.lshift(bit32.band(byte, 0x3F), 6 * (num_bytes - 1)), byte)
                num_bytes = num_bytes - 1
                if num_bytes == 0 then
                    table.insert(result, string.char(byte))
                end
            end
        end
        return table.concat(result)
    end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


    function DescriptografarCifraSubstituicao(texto)
        local chave = {
            x = "a",
            y = "b",
            z = "c",
            a = "d",
            b = "e",
            c = "f",
            d = "g",
            e = "h",
            f = "i",
            g = "j",
            h = "k",
            i = "l",
            j = "m",
            k = "n",
            l = "o",
            m = "p",
            n = "q",
            o = "r",
            p = "s",
            q = "t",
            r = "u",
            s = "v",
            t = "w",
            u = "x",
            v = "y",
            w = "z",
            [" "] = " "
        }
        
        local resultado = ""
        for i = 1, #texto do
            local caractere = texto:sub(i, i)
            local caractereDescriptografado = chave[caractere]
            resultado = resultado .. (caractereDescriptografado or caractere)
        end
        return resultado
    end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function DesofuscarCodigo(str)
    local res = ''
    for i = 1, #str do
        res = res .. string.char(str:byte(i))
    end
    return res
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    
    local encrypted_code = "]] .. DATA .. [["
    local decrypted_code = DescriptografiaImpressionante(Base64Decode(DescriptografarUTF8(DescriptografarCifraSubstituicao(DesofuscarCodigo(encrypted_code)))))
    assert(load(decrypted_code))()
    
  ]]
  
 DATA = descript_code
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
io.open(g.out, "w"):write(DATA):close()


local arquivo_saida = io.open(g.out, "r")
local dados_saida = arquivo_saida:read("*a")
arquivo_saida:close()

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[3] == true then
day = os.date("%d")
exp_date = gg.prompt({
"📆 Set Expired Date : ",
"📝 Type Expired Message : "},
{os.date("%Y%m" .. day + 5),"⚠️ Script Expired ⚠️️"},{"number", "text"})
end
if not exp_date then
gg.setVisible(true)
elseif exp_date[1] == nil then gg.alert("📆 Date Can Not Be Empty !") gg.setVisible(true)
else
print("📅 Added Expired Date : True✔")
dados_saida = '\n if os.date("%Y%m%d") >= "'..exp_date[1]..'" then print("'..exp_date[2]..'") return gg.alert("' ..exp_date[2] ..'")end\n' .. dados_saida
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[4] == true then
PASS = gg.prompt({
"🔐 Set Password For Script :",
"📝 Type Message For Wrong Password : "
}, {"","⚠️ Wrong Password, Try Again!!! ⚠️"},{
"text",
"text"})
end--if
if not PASS then
gg.setVisible(true)
elseif PASS[1] == nil then
gg.alert("⚠️ Input Password !")
gg.setVisible(true)
else
print("🔐 Added Password Script : True✔")
dados_saida = '\nlocal CXY = "'.. PASS[1]..'"\nPASSW = gg.prompt({"🔒 Input password: "},{[1]=""},{[1]="text"})\n if not PASSW the﻿n print("'..PASS[2]..'")  return end\n if PASSW[1] == "" then gg.alert("❌Password Can Not Be Empty ❌") os.exit(print("❌Password Can Not Be Empty ❌"))end\n if PASSW[1] ~= CXY then print("'..PASS[2]..'")return end\nif PASSW[1] == CXY then gg.toast("🎉Wellcome🎉")end\n' .. dados_saida
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[5] == true then
VERSION = gg.prompt({
"🔐 Set Minimal GG Version : ",
"🗒️ Set Error GG Message :"
}, {gg.VERSION,"⚠️ Error GG VERSION ⚠️"}, {
"number",
"text"})
end--if
if not VERSION then
gg.setVisible(true)
elseif VERSION[1] == nil then
gg.alert("🛡️ Input Minimal Required GG Version !")
gg.setVisible(true)
else
print("🛡 Minimal Version Required : True✔")
dados_saida = '\nlocal LynX = gg;local Xslow = LynX.VERSION;if Xslow ~= "'..VERSION[1] .. '" then print("'..VERSION[2]..'") return gg.alert("' ..VERSION[2].. '")end\n' .. dados_saida
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[6] == true then
NAME = gg.prompt({
"🗒️ Set Name For Script :",
"📝 Type Message For Name Changed :",
}, {g.out:match("[^/]+$"),
"⚠️ RENAME DETECTED ⚠️"}, {
"text",
"text"})
end
if not NAME then
gg.setVisible(true)
elseif NAME[1] == nil then
gg.alert("📝 Set Name Can Not Be Empty !")
gg.setVisible(true)
else
print("📝 Added Rename Blocker : True✔")
dados_saida = '\nlocal HckUtdProtect = gg.getFile():match("[^/]+$")local tptd =  "'..NAME[1]..'"\nif HckUtdProtect ~= tptd then gg.copyText("'..NAME[1]..'")gg.setVisible(true) print("'..NAME[2]..'") return gg.alert("'..NAME[2].. '")end\n' ..dados_saida
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[7] == true then
dados_saida = ([[if gg.isPackageInstalled("com.goushi.gtpcanary") then
  print("uninstall o Packet Capture")
  os.exit()
else
end
if gg.isPackageInstalled("com.packagesniffer.frtparlak") then
  print("uninstall o Packet Capture")
  os.exit()
else
end

if gg.isPackageInstalled("app.greyshirts.sslcapture") then
  print("uninstall o Packet Capture")
  os.exit()
else
end
if gg.isPackageInstalled("frtparlak.rootsniffer") then
  print("uninstall o Packet Capture")
  os.exit()
else
end
if gg.isPackageInstalled("com.minhui.wifianalyzer") then
  print("uninstall o Packet Capture")
  os.exit()
else
end
if gg.isPackageInstalled("jp.co.taosoftware.android.packetcapture") then
  print("uninstall o Packet Capture")
  os.exit()
else
end
if gg.isPackageInstalled("com.prabalgaming.logger") then
  print("uninstall your logger gg to Run Script")
  os.exit()
else
end
if gg.isPackageInstalled("any_.body_.can_.fuck_.tencent_") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.s.fyojrme") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.rjvsbmhdspmnfbame") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.redwolfgaming.ripgg") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.vrexqfftfsxekm.kl") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.nochqxpucsbldqqx") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.ghueczxrttlhgd") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.yy.qptvrjwerw.ghoex") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.nochqxpucsbldqqx") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.pvt4u") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.Egypt.yuosseef") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.tssfjipkmrco") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.vip.paidhacksonly.mr.toxin") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.ioyysvgfsrig") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.mrteamz.id") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.jtbodgpqxox") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.eidymumcghpfeeeavps") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.mod.iraq") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.dzelttwyuyyes") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.sxqa") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.xyyxgxfn") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.zgb") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.tssfjipkmrco") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.vnpqk") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.mwjvnwesbghkxbjznbwo") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.blackduty.gc") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.s.fyojrme") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.roxmemek") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.fhshwhpvqvruvjtu") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.fireongaming.fog") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.paranoiaworks.unicus.android.sse") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.raincitygaming.ggmod") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.pvt4u") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.nydpvsb.z.r.pkgh") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.ioyysvgfsrig") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.gmsm") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.sudsjcqvvcmgutdjeg") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.redwolfgaming.ripgg") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.coolfoolggfuckscript.tm") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.eidymumcghpfeeeavps") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.dzelttwyuyyes") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.foxcyber.gg") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.sxqa") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.zgb") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("catch_.me_.if_.you_.can_") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("sstool.only.com.sstool") then
  print("Uninstall SSTOOL Deceypt")
  os.exit()
end
if gg.isPackageInstalled("sstool.only.com.sstool") then
  print("Uninstall SSTOOL Deceypt")
  os.exit()
end
if gg.isPackageInstalled("catch_.me_.if_.you_.can_") then
  print("Uninstall orginal GG")
  os.exit()
end
]])..dados_saida
print('🛡 Auto Detect Decrypt : True √ ')
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[8] == true then
_Hacks_Unlimited_ = gg.prompt({
"✏️ Set Your Package GameGuardian",
"📝 Type Message If Package Is Wrong :"
}, {"com.GameGuardian.id","⚠ Use MY GG For Run This Script ⚠"},{
"text",
"text"})
end--if
if not _Hacks_Unlimited_ then
gg.setVisible(true)
elseif _Hacks_Unlimited_[1] == nil then
gg.alert("⚠️ Set Package GameGuardian Can Not Bd Empty!")
gg.setVisible(true)
else
print("⚠ SetPeckage GG : True√ ")
dados_saida = '\nif gg.PACKAGE == "' .. _Hacks_Unlimited_[1] .. '" then\nelse\ngg.alert("' .. _Hacks_Unlimited_[2] .. '")\nprint("' .. _Hacks_Unlimited_[2] .. '")\nos.exit()\nend\n' .. dados_saida
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[9] == true then
_Hacks_Unlimited_g = gg.prompt({
"✏️ Set Package Game",
"📝 Type Message If Package Is Wrong :"
}, {"com.hacks.unlimited.apk","⚠ Use Script In Game ⚠"},{
"text",
"text"})
end--if
if not _Hacks_Unlimited_g then
gg.setVisible(true)
elseif _Hacks_Unlimited_g[1] == nil then
gg.alert("⚠️ Set Package GameGuardian Can Not Be Empty!")
gg.setVisible(true)
else
print("🎮 SetPeckage Game : True√ ")
dados_saida = '\nif gg.getTargetInfo().processName ~= "'.._Hacks_Unlimited_g[1]..'" then\ngg.alert("'.._Hacks_Unlimited_g[2]..'")\nos.exit()\nend\n'..dados_saida
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[10] == true then
print("💀 Added Verify Human Mode")
print("")
dados_saida = "local code = math.random(10000, 99999)\nlocal hmn = gg.prompt({'🔒 Input This Code to Verify: '..code..' !'},{[1]=''},{[1]='number'}) if not hmn then os.exit() end if hmn[1]..'1' == code..'1' then gg.toast('☑ Code correct!') else gg.alert('✖ Wrong Code!') os.exit() end\n" ..dados_saida
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[11] == true then
dados_saida = ([[if true then
    local org = gg.searchNumber
    local hook = function(...)
        gg.setVisible(false)
        local ret = org(...)
        if gg.isVisible() then
        gg.alert("ANTI VIEW CODE😂")
        gg.clearResults()
            while true do os.exit() end
        end
        return ret
    end
    gg.searchNumber = hook
end
]])..dados_saida
print('🛡ANTIVIEW  by Batman games : Sucess √ ')
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[12] == true then
dados_saida = ([[file,err=io.open("/storage/emulated/0/Android/data/com.guoshi.httpcanary")
jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
--os.exit() 
end

]])..dados_saida
print('🛡 block canary by Batman games : Sucess √ ')
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
if g.info[13] == true then
dados_saida = ([[file, err = io.open("/system/bin/su", "r")

if file then
    gg.alert("Rooted device! Starting the script...")
    file:close()
else
    gg.alert("Non-rooted device. This script requires a rooted device.")
    os.exit()
end

]])..dados_saida
print('🛡 required root to start script by Batman games : Sucess √ ')
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[14] == true then
    alert = gg.prompt({
        "🔐 Set your name for alert:"
    }, {
        "",
        "⚠️ Wrong name, Try Again!!! ⚠️"
    }, {
        "text"
    })
    
    if not alert then
        gg.setVisible(true)
    
    elseif alert[1] == "" then
        gg.alert("⚠️ Input alert !")
        gg.setVisible(true)
    else
        print("🔐 Added alert Script : True✔")
        dados_saida = '\n modbybatman = os.date ("%Y/%m/%d %H:%M:%S")\n' ..
                      'gg.alert("' .. alert[1] .. ' \n" .. modbybatman)' .. dados_saida
        gg.alert("🔐 Added alert Script : True✔")
    end
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

S = math.random(1, 60)
SS = math.random(80, 302)
SSS = math.random(1, 60)
T = math.random(190, 340)
TT = math.random(1, 60)
TTT = math.random(190, 470)
AB = math.random(1000,2000)
AC = math.random(3000,4000)
AD = math.random(5000,6000)
AE = math.random(6000,8000)
AF = math.random(9000,10000)
AG = math.random(400,600)
ABB = math.random(2000,2000)
ACC = math.random(3000,4000)
ADD = math.random(5000,6000)
AFF = math.random(9000,10000)
AGG = math.random(400,600)
AX = math.random(200,800)
ABBB = math.random(1000,2000)
ACCC = math.random(3000,4000)
ADDD = math.random(5000,6000)
AXE = math.random(7000,8000)
AFFF = math.random(9000,10000)
AGGG = math.random(400,600)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local key = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD}
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local Amk = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+3,AC}
local Kei = {(SS-S)+T,SSS+TT-S,SS+TTT,TT,TT+12,SS-S*4}
local KY1 = (key[1]+key[3]-key[1])-key[5] 
local KY2 = (key[1]-Amk[2]*key[3]*Amk[4])-key[5]
local KY3 = (Amk[2]-Amk[1]*Amk[4]-Amk[3])+Amk[1]
local KY4 = (key[1]+AE-key[1])*key[2]
local KY5 = (key[3]+Amk[4]-ADD)+key[2]
local KY6 = (Amk[1]-Amk[3]+key[1])+AFFF

local X = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD, ACC, AGG+3000,AC}
local Y = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+4000,AB+7000,AC}
local X1 = (X[1]+X[3]-X[1]) -X[5] 
local X2 = (X[1]-Y[2]*X[3]*Y[4]) -X[5]
local X3 = (Y[2]-Y[1]*Y[4]-Y[3]) +Y[1]
local X5 = (X[3]+Y[4]-ADD) +X[2]
local X6 = (Y[1]-Y[3]+X[1])+AFFF

local Key1 = math.random(1000,50000)
local Key2 = math.random(1000,50000)
local Key3 = math.random(1000,50000)
local Key4 = math.random(1000,50000)
local Key5 = math.random(1000,50000)
local Key6 = math.random(1000,50000)
local Key7 = math.random(1000,50000)
local Key8 = math.random(1000,50000)
local Key9 = math.random(1000,50000)
local Key10 = math.random(1000,50000)
local Key11 = math.random(1000,50000)
local Key12 = math.random(1000,50000)
local Key13 = math.random(1000,50000)
local Key14 = math.random(1000,50000)
local Key15 = math.random(1000,50000)
local Key16 = math.random(1000,50000)
local Key17 = math.random(1000,50000)
local Key18 = math.random(1000,50000)
local Key19 = math.random(1000,50000)
local Key20 = math.random(1000,50000)
local KeyHex1 = math.random(1000,50000)
local KeyHex2 = math.random(1000,50000)
local KeyHex3 = math.random(1000,50000)
local KeyHex4 = math.random(1000,50000)
local KeyHex5 = math.random(1000,50000)

local inv256 
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function ShaMod(str)str = str:gsub("\n", "\n") if not inv256 then inv256 = {} for M = 1, 100 do local inv = -1 repeat inv = inv + 2 until inv * (2*M + 1) % 256 == 1 inv256[M] = inv end;end local K, F = X1 - X3 + X2, X2 - X3 * X5 return (str:gsub('.', function(m) local L = K % X6; local H = (K - L) / X6; local M = H % 27; local m = m:byte() local c = (m * inv256[M] - (H - M) / 27) % 256 K = L * F + H + c + m
return ('%02x'):format(c)end)) end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function Sha(str)str = str:gsub("\\n", "\n") if not inv256 then inv256 = {} for M = 0, 127 do local inv = -1 repeat inv = inv + 2 until inv * (2*M + 1) % 256 == 1 inv256[M] = inv end;end local K, F = KY1 - KY3 + KY2, KY2 - KY3 * KY5 return (str:gsub('.', function(m)local L = K % KY6;local H = (K - L) / KY6;local M = H % 27;local m = m:byte()local c = (m * inv256[M] - (H - M) / 27) % 256 K = L * F + H + c + m  return ('%02x'):format(c)end)) end
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function SHA(str)
    str = str:gsub("\\n","\n"):gsub("\\t","\t")
    if not inv256 then 
        inv256 = {} 
        for M = 1, 100 do 
            local inv = -1 
            repeat  
                inv = inv + 2 
            until inv * (2*M + 1) % 256 == 1 
            inv256[M] = inv 
        end 
    end
    local K, F = X1 - X3 + X2, X2 - X3 * X5 
    return (str:gsub('.', function(m) 
        local L = K % X6 
        local H = (K - L) / X6 
        local M = H % 27 
        local m = m:byte() 
        local c = (m * inv256[M] - (H - M) / 27) % 256 
        K = L * F + H + c + m 
        return ('%02x'):format(c) 
    end)) 
end
 
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function encodegg(code)
	return '_G["gg"][BGames({BGA = "' .. SHA(code) .. '"})]('
end
function encodeio(code)
	return '_G["io"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeos(code)
return '_G["os"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodevalue(code)
	return 'BGames({BGA = "' .. Sha(code) .. '"})'
end

function encodestr(code)
return '_G["string"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodetbl(code)
return '_G["table"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodedebug(code)
return '_G["debug"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeprint(code)
return '_G["print"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodefile(code)
return '_G["loadfile"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Decode =[[
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
local ABBB = "]]..ABBB..[[";local ACC = "]]..ACC..[[";local i = "]]..math.random(100,800)..[[";local AB = "]]..AB..[[";local i = "]]..math.random(200,900)..[[";local ADD = "]]..ADD..[[";local ADDD = "]]..ADDD..[[";local AGG = "]]..AGG..[[";local AD = "]]..AD..[[";local AXE = "]]..AXE..[[";local i = "]]..math.random(200,900)..[[";local AC = "]]..AC..[[";local AGGG = "]]..AGGG..[[";local AFF = "]]..AFF..[[";local AE = "]]..AE..[[";
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
local ACC = "]]..ACC..[[";local AE = "]]..AE..[[";local AX = "]]..AX..[[";local ACCC = "]]..ACCC..[[";local AG = "]]..AG..[[";local ABB = "]]..ABB..[[";local AF = "]]..AF..[[";local AFFF = "]]..AFFF..[[";local i = "]]..math.random(100,800)..[[";
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end

local key = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD};local Amk = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+3,AC};local KY1 = (key[1]+key[3]-key[1])-key[5] ;local KY2 = (key[1]-Amk[2]*key[3]*Amk[4])-key[5];local KY3 = (Amk[2]-Amk[1]*Amk[4]-Amk[3])+Amk[1];local KY4 = (key[1]+AE-key[1])*key[2];local KY5 = (key[3]+Amk[4]-ADD)+key[2];local KY6 = (Amk[1]-Amk[3]+key[1])+AFFF;local inv256 
local BGames = function(str) str = str.BGA local K, F = KY1 - KY3 + KY2, KY2 - KY3 * KY5 return (str:gsub('%x%x', function(c) local L = K % KY6 local H = (K - L) / KY6 local M = H % 27 c = tonumber(c, 16) local m = (c + (H - M) / 27) * (2*M + 1) % 256 K = L * F + H + c + m 
 if true then return string.char(m)end if true then return end if true then return end end))end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

lock2 =[[
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
gg.toast("Encrypt by ꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂")

	if true then
		if string.match('/' .. tostring(os.time()), '/([^/]+)$') ~= tostring(os.time()) then
			while true do
				if true then
					gg.alert('Error, time is not acceptable.')
					os.exit()
				end
				if false then
				end
			end
		end
	end
	
local GetTableSpam = {}
local b, toStr, GetSpamName = 0, tostring;

local tmp = (function()
  local tempString = ''
  while (b < (10^2)) do
    tempString = tempString .. toStr(b * b);
    b = b + 1
  end
  GetSpamName = (function() local HashName = '' for i = 1, 10 do HashName = "ðŸŒ¨ï¸" .. HashName .. "â˜ƒï¸" .. HashName .. "â„ï¸" end return HashName:rep(100) end)()
  return tempString;
end)();

local spam = "Boar"
local c, b = "'" .. math.random(1, 255) .. "'",  math.random(100, 300)
if tostring("@") == "" then
	return
end

for k, v in next, _ENV do
	if tostring(v):match("function: @.-:") then
		return
	end

local func = os.exit
if tostring(func):match("-") or tostring(func):match("//") or tostring(func):match("@") or tostring(func):match("%d+") then
	return
end
end

local spam_2 = "is top"

for i = 1, #tmp do
    GetTableSpam[i] = {["address"] = GetSpamName, ["flags"] = GetSpamName, ["value"] = GetSpamName, ["freeze"] = GetSpamName, ["name"] = GetSpamName, GetTableSpam[i - 1]}
    gg.refineNumber(GetTableSpam)
	gg.refineAddress(GetTableSpam)
end

local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
os.exit()
os.exit()
os["]==])..string.char(math.random(128,255),math.random(128,255),math.random(128,255),math.random(128,255))..([==["]()
gg.processKill()
return
end
end
if pcall(_ENV["os"]["exit"]) or _ENV["string"]["rep"]("'",'2')~="''" or not _ENV["debug"]["getinfo"](_ENV["tostring"])["isvararg"] or _ENV["debug"]["getinfo"](gg["searchNumber"])["what"]=="Lua" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

_ENV["B1"]= _ENV["debug"]["getinfo"](gg.refineNumber).short_src
if _ENV["B1"]~=_ENV["debug"]["getinfo"](1).short_src and _ENV["B1"]~=gg.getFile() then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if debug.getinfo(1).istailcall then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

x=debug.getinfo(gg.searchNumber)
if x.what~=('Java') then 
os.exit() 
while true do 
end 
end 
local i = {}
local g = {}
local ppi, ppb
g["last"] = _ENV["gg"]["getFile"]()
g["dados_saida"] = _ENV["loadfile"](g["last"])
g["cpp"] = g["dados_saida"]
if g["cpp"] ~= nil then 
g["dados_saida"] = nil
local ppb = g["last"]:match("[^/]+$")
local ppi = "lohhhggg"
local pu = _ENV["gg"]["getResults"](5000)
_ENV["os"]["rename"](''..g["last"]..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'') 
local prt = _ENV["loadfile"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'')
if prt ~= nil then
_ENV["os"]["rename"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppb..'')
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
for i in _ENV["ipairs"]({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])}) do 
if _ENV["string"]["match"](({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])})[i], ("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if _ENV["string"]["rep"]("a", 2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if ("a"):rep(2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _ENV["tostring"](_ENV["gg"]):find(("@")) then 
if not _ENV["tostring"](_ENV["debug"]):find(("@")) then 
if not _ENV["tostring"](_ENV["io"]):find(("@")) then 
if _ENV["tostring"](_ENV["string"]):find(("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
        until x== 20000
        gg["sleep"](0)
        os.exit()
      until false
     end
   end
 end 
end
if _G["debug"]["getlocal"](2, 4) == nil then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _G["utf8"] then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

if _ENV["debug"]["traceback"] == nil then
return 
end

if _ENV["string"]["rep"]("a", 2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

if ("a"):rep(2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

local log = _ENV["string"]["char"](("255"),("255"),("255"),("255"),("255"),("255")):rep("999"):rep("999"):rep(4)
for i = 1,("3340") do
_ENV["gg"]["refineNumber"]("0",log,log,log,log,log,log,log)
end

local GG={"art","ART","Art","dec","Dec","DEC","hook","Hook","HooK","HOOK","log","Log","LOG",}
local _gg={gg.CACHE_DIR,gg.EXT_FILES_DIR,gg.EXT_CACHE_DIR,gg.FILES_DIR,gg.PACKAGE}
for i,v in pairs(GG) do
if string.find(tostring(_gg),v) or(not string.find(tostring(_gg),"com"))then
Error(true)
end
end

while gg.PACKAGE == "catch.Art.Tool.seatch" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.VERSION == "96.0" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.BUILD == "15993" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while string.find(gg.EXT_CACHE_DIR,"com.Art.Tool") do
end
while string.find(gg.EXT_CACHE_DIR,"catch_.me_.if_.you_.can_93") do
end

_ENV["debug"]["getinfo"]=function(a)
return _ENV["debug"]["getinfo"]("BATMANN")
end

for i in string.gmatch(tostring(debug.traceback()), '(.-)\n') do
if string.match(i, '.(/.-):') and string.match(i, '.(/.-):') ~= gg.getFile() then

os.exit()

print("ï¸")
return
end
end

]] 
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

AntiLasm=[[
mmk = ''
for i = 1, math.random(5, 10) do
    fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
    mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nif fucklog or debug.getinfo(2) ~= nil then\n\n   print('Tentativa de log ou disassembly detectada!')\n   -- Encerrar a execução ou tomar outra ação adequada\n   return\nend\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" 
end
]]

 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Infinite = [[

for i = 1,5 do
    if(nil) then 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
    end
    loadfile = loadfile
    load = load
    loadfile(gg.getFile()) 
    load(string.dump(load("os.exit()"),false,false)) 
    io.open(gg.getFile() .. "c" .. tostring(string.dump(loadfile(gg.getFile()),false,false)),"w") 
end

for i = 1, 5000 do
    table.insert({}, {})
end
for i = 1, 5000 do
    table.insert({}, {})
end

gg.setVisible(false)
for i = 1, 6 do
    gg.addListItems({})
end

gg.setVisible(false)
gg.removeListItems({})

if os.time() > os.time() then
    return 
end
if os.time() < os.time() then
end
if os.difftime(os.time(), (os.time())) > 2 then
    return 
end

gg.setVisible(false)
if os.clock() > os.clock() then
    return 
end
if os.clock() < os.clock() then
end
if os.difftime(os.clock(), (os.clock())) > 2 then
    return 
end

gg.setVisible(false)
for i = 3, 100 do
    load(gg.getFile())
end

while(nil)do
    local i={}
    if(i.i)then
        i.i=(i.i(i))
    end
end

while(nil)do
    for i=i,i do
        local i={}
        if(i.i)then
            i.i=(i.i(i))
        end
        for ii=i.i,i.i,i.i do
            local ii={}
            if(ii.i)then
                ii.i=ii.i()
            end
            for iii=i,ii.i,i do
                local iii={}
                if(iii.i)then
                    iii.i=iii.i(i)
                end
                for iiii=i,ii,iii.i do
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=iiii.i(i)
                    end
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=(iiii|iii|ii|i)(i)
                    end
                end
                local iii={}
                if(iii.i)then
                    iii.i=(true|iii|ii|i)(i)
                end
            end
            local ii={}
            if(ii.i)then
                ii.i=(true|false|ii|i)(i)
            end
        end
        local i={}
        if(i.i)then
            i.i=(true|false|nil|i)(i)
        end
        return(true|false|nil)
    end
    return
end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


Infinite2 = [[
function obfuscate(code, x)
    x = x or ""
    code = x .. code
    local dmpbool = true
    local proccess = {
        "%%%%%%",
        "@@@@@@",
        "&&&&&&",
        "******"
    } 
    local temporary = "temp.lua" 
    for i = 1, #proccess do
        local f = load(code) or function() error("Error") end
        local dumped_code = string.dump(f, dmpbool)
        local f2 = load(dumped_code) or function() error("Error") end
        gg.internal2(f2, temporary)
        local a, b = {}, {}
        local dados_saida = {}
        for line in io.lines(temporary) do
            if line:match("^%s*%.func") or line:match("^%s*%.end") then
                b[#b + 1] = #dados_saida
                if #b == 2 then
                    if b[2] > b[1] + 2 then
                        a[#a + 1] = b
                    end
                    b = {b[2]}
                end
            end
            dados_saida[#dados_saida + 1] = line
        end
        code = table.concat(dados_saida, "\n")
        os.remove(temporary)
        for k, v in pairs(a) do
            local pattern = ""
            for i = v[1], v[2] do
                pattern = pattern .. dados_saida[i]:gsub("%p", function(c)
                    return "%" .. c
                end) .. "\n"
            end
            code = code:gsub(pattern, proccess[i])
        end
        dmpbool = false
    end
    return code
end

]]

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

blocksstol = [[

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

dados_saida = dados_saida:gsub("%'.-(.-)%'", encodevalue)
dados_saida = dados_saida:gsub('%".-(.-)%"', encodevalue)
dados_saida = dados_saida:gsub('%[%[.-(.-)%]%]', encodevalue)
dados_saida = dados_saida:gsub("gg%.(%a+)%(", encodegg)
dados_saida = dados_saida:gsub("io%.(%a+)%(", encodeio)
dados_saida = dados_saida:gsub("os%.(%a+)%(", encodeos)
dados_saida = dados_saida:gsub("table%.(%a+)%(", encodetbl)
dados_saida = dados_saida:gsub("debug%.(%a+)%(", encodedebug)
dados_saida = dados_saida:gsub("print%.(%a+)%(", encodeprint)
dados_saida = dados_saida:gsub("loadfile%.(%a+)%(", encodefile)
dados_saida = dados_saida:gsub("string%.(%a+)%(", encodestr)

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--dados_saida = Decode .. dados_saida
dados_saida = blocksstol..lock2..Infinite..Infinite2..AntiLasm..Decode..dados_saida

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

dados_saida = ""..dados_saida

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

io.open(g.out,"w"):write(string.gsub(string.dump(load(dados_saida), true), 'LuaR', 'LuaR', 1)):close()
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
ClU = '📂 File Saved To: '..g.out..'\n'
gg.alert(ClU, '')
print("\n▬▬▬▬▬▬▬▬▬▬▬▬▬\n📂 File Saved To :" .. g.out .. "\n▬▬▬▬▬▬▬▬▬▬▬▬▬")
return 
end
 end


function encv2() 

g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 gg.alert([[

📌 Time for encrypt file 1 or 3 minutes
📌 escapeOpcode slow encode


📌 Features
 
Encrypy hash +
Encrypt utf16 +
Encrypt utf32 +
Encrypt chunk +
Encrypt escapeOpcode + 
sha+
new block Sstool+
antilog +
antiload 
Working gg 101.1✔️

by Batman Games🍿 
My telegram @batmangamesS 
]])
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

while true do
  g.info = gg.prompt({
    '📂 Select file :', -- 1
    '📂 Select folder  :' -- 2
  }, g.info, {
    'file', -- 1
    'path' -- 2
  })
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  gg.saveVariable(g.info, g.config)
  g.last = g.info[1]
  if loadfile(g.last) == nil then
    gg.alert("⚠️ Script not Found! ⚠️")
    return
  else
    g.out = g.last:match("[^/]+$")
    g.out = g.out:gsub(".lua", ".Batman")
    g.out = g.info[2] .. "/" .. g.out .. ".lua"
  end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  local file = io.open(g.last, "r")
  local DATA = file:read('*a')
  file:close()
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  function CriptografiaImpressionante(str)
      -- Chave oculta (pode ser modificada conforme desejado)
      local chave_oculta = 42
      local hash = ''
      local tamanho_str = #str

      for i = 1, tamanho_str do
          local byte = str:byte(i) or 0
          local valor = byte + chave_oculta
          local hash_byte = valor % 256
          hash = hash .. string.format('%02x', hash_byte)
      end
      return hash
  end

  DATA = CriptografiaImpressionante(DATA)
  
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function CriptografarUTF16(str)
    local result = {}
    for i = 1, #str do
        local byte = string.byte(str, i)
        -- Adicionar byte zero para o segundo byte de cada caractere
        table.insert(result, string.char(0))
        table.insert(result, string.char(byte))
    end
    return table.concat(result)
end
  
DATA = CriptografarUTF16(DATA)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function CriptografarUTF32(str)
    local result = {}
    for i = 1, #str do
        local byte = string.byte(str, i)
        -- Adicionar bytes zero adicionais para o segundo, terceiro e quarto byte de cada caractere
        for j = 1, 3 do
            table.insert(result, string.char(0))
        end
        table.insert(result, string.char(byte))
    end
    return table.concat(result)
end
  
DATA = CriptografarUTF32(DATA)

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function codifica(str)
    local chunk = {str:byte(1, #str)}
    if #chunk % 4 ~= 0 then
        local remaining_bytes = 4 - (#chunk % 4)
        for i = 1, remaining_bytes do
            table.insert(chunk, math.random(1, 255))
        end
    end
    local test = #chunk / 4

    
    local encoded_chunk = ''
    for i = 1, test do
        local byte1, byte2, byte3, byte4 = chunk[(i-1)*4+1], chunk[(i-1)*4+2], chunk[(i-1)*4+3], chunk[(i-1)*4+4]
        local encoded_byte = string.char(byte1, byte2, byte3, byte4)
        encoded_chunk = encoded_chunk .. encoded_byte
    end

    return encoded_chunk
end

DATA = codifica(DATA)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function escapeOpcode(str)
    local special_characters = {40, 41, 46, 37, 43, 45, 42, 63, 91, 93, 94, 36}
    local escaped_chars = {}
    local txt = ""

    for char in string.gmatch(str, ".") do
        local char_code = string.byte(char)
        local escaped_char = string.format("ã€%03dã€‘", char_code)
        escaped_chars[#escaped_chars + 1] = escaped_char
    end

    for i, escaped_char in ipairs(escaped_chars) do
        local is_special = false
        for _, special_code in ipairs(special_characters) do
            if escaped_char == string.format("ã€%03dã€‘", special_code) then
                is_special = true
                break
            end
        end
        txt = txt .. (is_special and "ã€37ã€‘" or "") .. escaped_char
    end

    txt = string.gsub(txt, "ã€(%d+)ã€‘", function(char_code)
        return string.char(tonumber(char_code))
    end)

    return txt
end

DATA = escapeOpcode(DATA)


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  
  io.open(g.out,"w"):write(DATA):close()
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  
  local descript_code = [[
 
    function DescriptografiaImpressionante(hash)
        local chave_oculta = 42
        local str = ''
        local tamanho_hash = #hash

        for i = 1, tamanho_hash, 2 do
            local hex_byte = string.sub(hash, i, i+1)
            local hash_byte = tonumber(hex_byte, 16)
            local valor = (hash_byte - chave_oculta) % 256
            str = str .. string.char(valor)
        end
        return str
    end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function DescriptografarUTF16(str)
    local result = {}
    local byte1, byte2
    for i = 1, #str, 2 do
        byte1 = string.byte(str, i)
        byte2 = string.byte(str, i+1)
        -- Ignorar o primeiro byte zero de cada caractere
        table.insert(result, string.char(byte2))
    end
    return table.concat(result)
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function DescriptografarUTF32(str)
    local result = {}
    for i = 1, #str, 4 do
        -- Ignorar os primeiros três bytes zero de cada caractere
        local byte = string.byte(str, i + 3)
        table.insert(result, string.char(byte))
    end
    return table.concat(result)
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function decodifica(str)
    local decoded_chunk = {}
    for i = 1, #str, 4 do
        local byte1, byte2, byte3, byte4 = str:byte(i, i+3)
        table.insert(decoded_chunk, byte1)
        table.insert(decoded_chunk, byte2)
        table.insert(decoded_chunk, byte3)
        table.insert(decoded_chunk, byte4)
    end

    
    local decoded_str = ''
    for _, byte in ipairs(decoded_chunk) do
        decoded_str = decoded_str .. string.char(byte)
    end

    return decoded_str
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function unescapeOpcode(str)
    local txt = str:gsub("ã€37ã€‘", "")
    txt = txt:gsub("ã€(%d+)ã€‘", function(char_code)
        return string.char(tonumber(char_code))
    end)
    return txt
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    
    local encrypted_code = "]] .. DATA .. [["
    local decrypted_code = DescriptografiaImpressionante(DescriptografarUTF16(DescriptografarUTF32(decodifica(unescapeOpcode(encrypted_code)))))
    assert(load(decrypted_code))()
  ]]
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  DATA = descript_code
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

io.open(g.out,"w"):write(DATA):close()


 
local arquivo_saida = io.open(g.out, "r")
local dados_saida = arquivo_saida:read("*a")
arquivo_saida:close()
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

S = math.random(1, 60)
SS = math.random(80, 302)
SSS = math.random(1, 60)
T = math.random(190, 340)
TT = math.random(1, 60)
TTT = math.random(190, 470)
AB = math.random(1000,2000)
AC = math.random(3000,4000)
AD = math.random(5000,6000)
AE = math.random(6000,8000)
AF = math.random(9000,10000)
AG = math.random(400,600)
ABB = math.random(2000,2000)
ACC = math.random(3000,4000)
ADD = math.random(5000,6000)
AFF = math.random(9000,10000)
AGG = math.random(400,600)
AX = math.random(200,800)
ABBB = math.random(1000,2000)
ACCC = math.random(3000,4000)
ADDD = math.random(5000,6000)
AXE = math.random(7000,8000)
AFFF = math.random(9000,10000)
AGGG = math.random(400,600)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local key = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD}
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local Amk = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+3,AC}
local Kei = {(SS-S)+T,SSS+TT-S,SS+TTT,TT,TT+12,SS-S*4}
local KY1 = (key[1]+key[3]-key[1])-key[5] 
local KY2 = (key[1]-Amk[2]*key[3]*Amk[4])-key[5]
local KY3 = (Amk[2]-Amk[1]*Amk[4]-Amk[3])+Amk[1]
local KY4 = (key[1]+AE-key[1])*key[2]
local KY5 = (key[3]+Amk[4]-ADD)+key[2]
local KY6 = (Amk[1]-Amk[3]+key[1])+AFFF

local X = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD, ACC, AGG+3000,AC}
local Y = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+4000,AB+7000,AC}
local X1 = (X[1]+X[3]-X[1]) -X[5] 
local X2 = (X[1]-Y[2]*X[3]*Y[4]) -X[5]
local X3 = (Y[2]-Y[1]*Y[4]-Y[3]) +Y[1]
local X5 = (X[3]+Y[4]-ADD) +X[2]
local X6 = (Y[1]-Y[3]+X[1])+AFFF

local Key1 = math.random(1000,50000)
local Key2 = math.random(1000,50000)
local Key3 = math.random(1000,50000)
local Key4 = math.random(1000,50000)
local Key5 = math.random(1000,50000)
local Key6 = math.random(1000,50000)
local Key7 = math.random(1000,50000)
local Key8 = math.random(1000,50000)
local Key9 = math.random(1000,50000)
local Key10 = math.random(1000,50000)
local Key11 = math.random(1000,50000)
local Key12 = math.random(1000,50000)
local Key13 = math.random(1000,50000)
local Key14 = math.random(1000,50000)
local Key15 = math.random(1000,50000)
local Key16 = math.random(1000,50000)
local Key17 = math.random(1000,50000)
local Key18 = math.random(1000,50000)
local Key19 = math.random(1000,50000)
local Key20 = math.random(1000,50000)
local KeyHex1 = math.random(1000,50000)
local KeyHex2 = math.random(1000,50000)
local KeyHex3 = math.random(1000,50000)
local KeyHex4 = math.random(1000,50000)
local KeyHex5 = math.random(1000,50000)

local inv256 
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function ShaMod(str)str = str:gsub("\n", "\n") if not inv256 then inv256 = {} for M = 1, 100 do local inv = -1 repeat inv = inv + 2 until inv * (2*M + 1) % 256 == 1 inv256[M] = inv end;end local K, F = X1 - X3 + X2, X2 - X3 * X5 return (str:gsub('.', function(m) local L = K % X6; local H = (K - L) / X6; local M = H % 27; local m = m:byte() local c = (m * inv256[M] - (H - M) / 27) % 256 K = L * F + H + c + m
return ('%02x'):format(c)end)) end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function Sha(str)str = str:gsub("\\n", "\n") if not inv256 then inv256 = {} for M = 0, 127 do local inv = -1 repeat inv = inv + 2 until inv * (2*M + 1) % 256 == 1 inv256[M] = inv end;end local K, F = KY1 - KY3 + KY2, KY2 - KY3 * KY5 return (str:gsub('.', function(m)local L = K % KY6;local H = (K - L) / KY6;local M = H % 27;local m = m:byte()local c = (m * inv256[M] - (H - M) / 27) % 256 K = L * F + H + c + m  return ('%02x'):format(c)end)) end
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function SHA(str)
    str = str:gsub("\\n","\n"):gsub("\\t","\t")
    if not inv256 then 
        inv256 = {} 
        for M = 1, 100 do 
            local inv = -1 
            repeat  
                inv = inv + 2 
            until inv * (2*M + 1) % 256 == 1 
            inv256[M] = inv 
        end 
    end
    local K, F = X1 - X3 + X2, X2 - X3 * X5 
    return (str:gsub('.', function(m) 
        local L = K % X6 
        local H = (K - L) / X6 
        local M = H % 27 
        local m = m:byte() 
        local c = (m * inv256[M] - (H - M) / 27) % 256 
        K = L * F + H + c + m 
        return ('%02x'):format(c) 
    end)) 
end
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function encodegg(code)
	return '_G["gg"][BGames({BGA = "' .. SHA(code) .. '"})]('
end
function encodeio(code)
	return '_G["io"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeos(code)
return '_G["os"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodevalue(code)
	return 'BGames({BGA = "' .. Sha(code) .. '"})'
end

function encodestr(code)
return '_G["string"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodetbl(code)
return '_G["table"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodedebug(code)
return '_G["debug"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeprint(code)
return '_G["print"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodefile(code)
return '_G["loadfile"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Decode =[[
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
local ABBB = "]]..ABBB..[[";local ACC = "]]..ACC..[[";local i = "]]..math.random(100,800)..[[";local AB = "]]..AB..[[";local i = "]]..math.random(200,900)..[[";local ADD = "]]..ADD..[[";local ADDD = "]]..ADDD..[[";local AGG = "]]..AGG..[[";local AD = "]]..AD..[[";local AXE = "]]..AXE..[[";local i = "]]..math.random(200,900)..[[";local AC = "]]..AC..[[";local AGGG = "]]..AGGG..[[";local AFF = "]]..AFF..[[";local AE = "]]..AE..[[";
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
local ACC = "]]..ACC..[[";local AE = "]]..AE..[[";local AX = "]]..AX..[[";local ACCC = "]]..ACCC..[[";local AG = "]]..AG..[[";local ABB = "]]..ABB..[[";local AF = "]]..AF..[[";local AFFF = "]]..AFFF..[[";local i = "]]..math.random(100,800)..[[";
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end

local key = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD};local Amk = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+3,AC};local KY1 = (key[1]+key[3]-key[1])-key[5] ;local KY2 = (key[1]-Amk[2]*key[3]*Amk[4])-key[5];local KY3 = (Amk[2]-Amk[1]*Amk[4]-Amk[3])+Amk[1];local KY4 = (key[1]+AE-key[1])*key[2];local KY5 = (key[3]+Amk[4]-ADD)+key[2];local KY6 = (Amk[1]-Amk[3]+key[1])+AFFF;local inv256 
local BGames = function(str) str = str.BGA local K, F = KY1 - KY3 + KY2, KY2 - KY3 * KY5 return (str:gsub('%x%x', function(c) local L = K % KY6 local H = (K - L) / KY6 local M = H % 27 c = tonumber(c, 16) local m = (c + (H - M) / 27) * (2*M + 1) % 256 K = L * F + H + c + m 
 if true then return string.char(m)end if true then return end if true then return end end))end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

lock2 =[[
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
gg.toast("Encrypt by ꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂")

	if true then
		if string.match('/' .. tostring(os.time()), '/([^/]+)$') ~= tostring(os.time()) then
			while true do
				if true then
					gg.alert('Error, time is not acceptable.')
					os.exit()
				end
				if false then
				end
			end
		end
	end
	
local GetTableSpam = {}
local b, toStr, GetSpamName = 0, tostring;

local tmp = (function()
  local tempString = ''
  while (b < (10^2)) do
    tempString = tempString .. toStr(b * b);
    b = b + 1
  end
  GetSpamName = (function() local HashName = '' for i = 1, 10 do HashName = "ðŸŒ¨ï¸" .. HashName .. "â˜ƒï¸" .. HashName .. "â„ï¸" end return HashName:rep(100) end)()
  return tempString;
end)();

local spam = "Boar"
local c, b = "'" .. math.random(1, 255) .. "'",  math.random(100, 300)
if tostring("@") == "" then
	return
end

for k, v in next, _ENV do
	if tostring(v):match("function: @.-:") then
		return
	end

local func = os.exit
if tostring(func):match("-") or tostring(func):match("//") or tostring(func):match("@") or tostring(func):match("%d+") then
	return
end
end

local spam_2 = "is top"

for i = 1, #tmp do
    GetTableSpam[i] = {["address"] = GetSpamName, ["flags"] = GetSpamName, ["value"] = GetSpamName, ["freeze"] = GetSpamName, ["name"] = GetSpamName, GetTableSpam[i - 1]}
    gg.refineNumber(GetTableSpam)
	gg.refineAddress(GetTableSpam)
end

local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
os.exit()
os.exit()
os["]==])..string.char(math.random(128,255),math.random(128,255),math.random(128,255),math.random(128,255))..([==["]()
gg.processKill()
return
end
end
if pcall(_ENV["os"]["exit"]) or _ENV["string"]["rep"]("'",'2')~="''" or not _ENV["debug"]["getinfo"](_ENV["tostring"])["isvararg"] or _ENV["debug"]["getinfo"](gg["searchNumber"])["what"]=="Lua" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

_ENV["B1"]= _ENV["debug"]["getinfo"](gg.refineNumber).short_src
if _ENV["B1"]~=_ENV["debug"]["getinfo"](1).short_src and _ENV["B1"]~=gg.getFile() then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if debug.getinfo(1).istailcall then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

x=debug.getinfo(gg.searchNumber)
if x.what~=('Java') then 
os.exit() 
while true do 
end 
end 
local i = {}
local g = {}
local ppi, ppb
g["last"] = _ENV["gg"]["getFile"]()
g["dados_saida"] = _ENV["loadfile"](g["last"])
g["cpp"] = g["dados_saida"]
if g["cpp"] ~= nil then 
g["dados_saida"] = nil
local ppb = g["last"]:match("[^/]+$")
local ppi = "lohhhggg"
local pu = _ENV["gg"]["getResults"](5000)
_ENV["os"]["rename"](''..g["last"]..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'') 
local prt = _ENV["loadfile"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'')
if prt ~= nil then
_ENV["os"]["rename"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppb..'')
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
for i in _ENV["ipairs"]({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])}) do 
if _ENV["string"]["match"](({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])})[i], ("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if _ENV["string"]["rep"]("a", 2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if ("a"):rep(2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _ENV["tostring"](_ENV["gg"]):find(("@")) then 
if not _ENV["tostring"](_ENV["debug"]):find(("@")) then 
if not _ENV["tostring"](_ENV["io"]):find(("@")) then 
if _ENV["tostring"](_ENV["string"]):find(("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
        until x== 20000
        gg["sleep"](0)
        os.exit()
      until false
     end
   end
 end 
end
if _G["debug"]["getlocal"](2, 4) == nil then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _G["utf8"] then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

if _ENV["debug"]["traceback"] == nil then
return 
end

if _ENV["string"]["rep"]("a", 2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

if ("a"):rep(2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

local log = _ENV["string"]["char"](("255"),("255"),("255"),("255"),("255"),("255")):rep("999"):rep("999"):rep(4)
for i = 1,("3340") do
_ENV["gg"]["refineNumber"]("0",log,log,log,log,log,log,log)
end

local GG={"art","ART","Art","dec","Dec","DEC","hook","Hook","HooK","HOOK","log","Log","LOG",}
local _gg={gg.CACHE_DIR,gg.EXT_FILES_DIR,gg.EXT_CACHE_DIR,gg.FILES_DIR,gg.PACKAGE}
for i,v in pairs(GG) do
if string.find(tostring(_gg),v) or(not string.find(tostring(_gg),"com"))then
Error(true)
end
end

while gg.PACKAGE == "catch.Art.Tool.seatch" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.VERSION == "96.0" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.BUILD == "15993" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while string.find(gg.EXT_CACHE_DIR,"com.Art.Tool") do
end
while string.find(gg.EXT_CACHE_DIR,"catch_.me_.if_.you_.can_93") do
end

_ENV["debug"]["getinfo"]=function(a)
return _ENV["debug"]["getinfo"]("BATMANN")
end

for i in string.gmatch(tostring(debug.traceback()), '(.-)\n') do
if string.match(i, '.(/.-):') and string.match(i, '.(/.-):') ~= gg.getFile() then

os.exit()

print("ï¸")
return
end
end

]] 
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

AntiLasm=[[
mmk = ''
for i = 1, math.random(5, 10) do
    fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
    mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nif fucklog or debug.getinfo(2) ~= nil then\n\n   print('Tentativa de log ou disassembly detectada!')\n   -- Encerrar a execução ou tomar outra ação adequada\n   return\nend\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" 
end
]]

 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Infinite = [[

for i = 1,5 do
    if(nil) then 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
    end
    loadfile = loadfile
    load = load
    loadfile(gg.getFile()) 
    load(string.dump(load("os.exit()"),false,false)) 
    io.open(gg.getFile() .. "c" .. tostring(string.dump(loadfile(gg.getFile()),false,false)),"w") 
end

for i = 1, 5000 do
    table.insert({}, {})
end
for i = 1, 5000 do
    table.insert({}, {})
end

gg.setVisible(false)
for i = 1, 6 do
    gg.addListItems({})
end

gg.setVisible(false)
gg.removeListItems({})

if os.time() > os.time() then
    return 
end
if os.time() < os.time() then
end
if os.difftime(os.time(), (os.time())) > 2 then
    return 
end

gg.setVisible(false)
if os.clock() > os.clock() then
    return 
end
if os.clock() < os.clock() then
end
if os.difftime(os.clock(), (os.clock())) > 2 then
    return 
end

gg.setVisible(false)
for i = 3, 100 do
    load(gg.getFile())
end

while(nil)do
    local i={}
    if(i.i)then
        i.i=(i.i(i))
    end
end

while(nil)do
    for i=i,i do
        local i={}
        if(i.i)then
            i.i=(i.i(i))
        end
        for ii=i.i,i.i,i.i do
            local ii={}
            if(ii.i)then
                ii.i=ii.i()
            end
            for iii=i,ii.i,i do
                local iii={}
                if(iii.i)then
                    iii.i=iii.i(i)
                end
                for iiii=i,ii,iii.i do
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=iiii.i(i)
                    end
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=(iiii|iii|ii|i)(i)
                    end
                end
                local iii={}
                if(iii.i)then
                    iii.i=(true|iii|ii|i)(i)
                end
            end
            local ii={}
            if(ii.i)then
                ii.i=(true|false|ii|i)(i)
            end
        end
        local i={}
        if(i.i)then
            i.i=(true|false|nil|i)(i)
        end
        return(true|false|nil)
    end
    return
end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Infinite2 = [[
function obfuscate(code, x)
    x = x or ""
    code = x .. code
    local dmpbool = true
    local proccess = {
        "%%%%%%",
        "@@@@@@",
        "&&&&&&",
        "******"
    } 
    local temporary = "temp.lua" 
    for i = 1, #proccess do
        local f = load(code) or function() error("Error") end
        local dumped_code = string.dump(f, dmpbool)
        local f2 = load(dumped_code) or function() error("Error") end
        gg.internal2(f2, temporary)
        local a, b = {}, {}
        local dados_saida = {}
        for line in io.lines(temporary) do
            if line:match("^%s*%.func") or line:match("^%s*%.end") then
                b[#b + 1] = #dados_saida
                if #b == 2 then
                    if b[2] > b[1] + 2 then
                        a[#a + 1] = b
                    end
                    b = {b[2]}
                end
            end
            dados_saida[#dados_saida + 1] = line
        end
        code = table.concat(dados_saida, "\n")
        os.remove(temporary)
        for k, v in pairs(a) do
            local pattern = ""
            for i = v[1], v[2] do
                pattern = pattern .. dados_saida[i]:gsub("%p", function(c)
                    return "%" .. c
                end) .. "\n"
            end
            code = code:gsub(pattern, proccess[i])
        end
        dmpbool = false
    end
    return code
end

]]

blocksstol = [[

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

dados_saida = dados_saida:gsub("%'.-(.-)%'", encodevalue)
dados_saida = dados_saida:gsub('%".-(.-)%"', encodevalue)
dados_saida = dados_saida:gsub('%[%[.-(.-)%]%]', encodevalue)
dados_saida = dados_saida:gsub("gg%.(%a+)%(", encodegg)
dados_saida = dados_saida:gsub("io%.(%a+)%(", encodeio)
dados_saida = dados_saida:gsub("os%.(%a+)%(", encodeos)
dados_saida = dados_saida:gsub("table%.(%a+)%(", encodetbl)
dados_saida = dados_saida:gsub("debug%.(%a+)%(", encodedebug)
dados_saida = dados_saida:gsub("print%.(%a+)%(", encodeprint)
dados_saida = dados_saida:gsub("loadfile%.(%a+)%(", encodefile)
dados_saida = dados_saida:gsub("string%.(%a+)%(", encodestr)

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--dados_saida = Decode .. dados_saida
dados_saida = blocksstol..lock2..Infinite..Infinite2..AntiLasm..Decode..dados_saida

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

dados_saida = ""..dados_saida

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

io.open(g.out,"w"):write(string.gsub(string.dump(load(dados_saida), true), 'LuaR', 'LuaR', 1)):close()
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
ClU = '📂 File Saved To: '..g.out..'\n'
gg.alert(ClU, '')
print("\n▬▬▬▬▬▬▬▬▬▬▬▬▬\n📂 File Saved To :" .. g.out .. "\n▬▬▬▬▬▬▬▬▬▬▬▬▬")
return 
end
 end

function encv3()

g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 gg.alert([[

📌 Features
 
Encrypy hash +
Encrypt escape_magic +
Encrypt escapeOpcode otimized + 
sha+
new block Sstool+
antilog +
antiload 
Working gg 101.1✔️

by Batman Games🍿 
My telegram @batmangamesS 
]])
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

while true do
  g.info = gg.prompt({
    '📂 Select file :', -- 1
    '📂 Select folder  :' -- 2
  }, g.info, {
    'file', -- 1
    'path' -- 2
  })
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  gg.saveVariable(g.info, g.config)
  g.last = g.info[1]
  if loadfile(g.last) == nil then
    gg.alert("⚠️ Script not Found! ⚠️")
    return
  else
    g.out = g.last:match("[^/]+$")
    g.out = g.out:gsub(".lua", ".Batman")
    g.out = g.info[2] .. "" .. g.out .. ".lua"
  end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  local file = io.open(g.last, "r")
  local DATA = file:read('*a')
  file:close()
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  function CriptografiaImpressionante(str)
      -- Chave oculta (pode ser modificada conforme desejado)
      local chave_oculta = 84
      local hash = ''
      local tamanho_str = #str

      for i = 1, tamanho_str do
          local byte = str:byte(i) or 0
          local valor = byte + chave_oculta
          local hash_byte = valor % 256
          hash = hash .. string.format('%02x', hash_byte)
      end
      return hash
  end

  DATA = CriptografiaImpressionante(DATA)
  
  ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function enc(str) 
    local x = {str:byte(1, -1)}
    for ii in pairs(x) do 
        for i = 1, 150 do 
            x[ii] = (x[ii] + i) % 256
        end
    end
    return string.char(table.unpack(x))
end

DATA = enc(DATA)
  
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function escape_magic(str)
  return (str:gsub("[%p]", "%%%1"))
end

DATA = escape_magic(DATA)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function escapeOpcode(str)
    local special_characters = {40, 41, 46, 37, 43, 45, 42, 63, 91, 93, 94, 36}
    local escaped_chars = {}

    for char in str:gmatch(".") do
        local char_code = char:byte()
        local escaped_char = string.format("ã€%03dã€‘", char_code)
        if special_characters[char_code] then
            escaped_char = "ã€37ã€‘" .. escaped_char
        end
        escaped_chars[#escaped_chars + 1] = escaped_char
    end

    return table.concat(escaped_chars)
end

DATA = escapeOpcode(DATA)

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  -- Escrever o conteúdo criptografado em um arquivo
  io.open(g.out,"w"):write(DATA):close()
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  -- Lógica para decodificar o conteúdo durante a execução do script
  local descript_code = [[
  
  while nil do
    local i = nil
    for i = i, i(), i() do
        local _, __, ___ = nil, nil, nil
        local __ = {}
        local ___ = {}
        ___[___] = ___
        ___[__()] = ___()
        ___[___()] = ___
        ___[___()] = _

        for _ = __, ___(), ___() do
            if _ == #__ then
                for _ = __, ___(), ___() do
                    if _ == #__ then
                    end
                end
                if _ == #__ then
                end
            end
        end
    end
end

 for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end

    function DescriptografiaImpressionante(hash)
        local chave_oculta = 84
        local str = ''
        local tamanho_hash = #hash

        for i = 1, tamanho_hash, 2 do
            local hex_byte = string.sub(hash, i, i+1)
            local hash_byte = tonumber(hex_byte, 16)
            local valor = (hash_byte - chave_oculta) % 256
            str = str .. string.char(valor)
        end
        return str
    end

for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end

function dec(str) 
    local x = {str:byte(1, -1)}
    for ii in pairs(x) do 
        for i = 1, 150 do 
            x[ii] = (x[ii] - i) % 256
        end
    end
    return string.char(table.unpack(x))
end

for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end

function unescape_magic(str)
    return str:gsub("%%(%x%x)", function(hex)
        return string.char(tonumber(hex, 16))
    end)
end

for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end

function unescapeOpcode(str)
    local txt = str:gsub("ã€37ã€‘", "")
    txt = txt:gsub("ã€(%d+)ã€‘", function(char_code)
        return string.char(tonumber(char_code))
    end)
    return txt
end

for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


while nil do
    local i = nil
    for i = i, i(), i() do
        local _, __, ___ = nil, nil, nil
        local __ = {}
        local ___ = {}
        ___[___] = ___
        ___[__()] = ___()
        ___[___()] = ___
        ___[___()] = _

        for _ = __, ___(), ___() do
            if _ == #__ then
                for _ = __, ___(), ___() do
                    if _ == #__ then
                    end
                end
                if _ == #__ then
                end
            end
        end
    end
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


    -- Recuperar o código original
    local encrypted_code = "]] .. DATA .. [["
    local decrypted_code = DescriptografiaImpressionante(dec(unescape_magic(unescapeOpcode(encrypted_code))))
    assert(load(decrypted_code))()
  ]]
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  DATA = descript_code
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

io.open(g.out,"w"):write(DATA):close()


 -- Lendo os dados do arquivo de saída "g.out"
local arquivo_saida = io.open(g.out, "r")
local dados_saida = arquivo_saida:read("*a")
arquivo_saida:close()
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

S = math.random(1, 60)
SS = math.random(80, 302)
SSS = math.random(1, 60)
T = math.random(190, 340)
TT = math.random(1, 60)
TTT = math.random(190, 470)
AB = math.random(1000,2000)
AC = math.random(3000,4000)
AD = math.random(5000,6000)
AE = math.random(6000,8000)
AF = math.random(9000,10000)
AG = math.random(400,600)
ABB = math.random(2000,2000)
ACC = math.random(3000,4000)
ADD = math.random(5000,6000)
AFF = math.random(9000,10000)
AGG = math.random(400,600)
AX = math.random(200,800)
ABBB = math.random(1000,2000)
ACCC = math.random(3000,4000)
ADDD = math.random(5000,6000)
AXE = math.random(7000,8000)
AFFF = math.random(9000,10000)
AGGG = math.random(400,600)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local key = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD}
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local Amk = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+3,AC}
local Kei = {(SS-S)+T,SSS+TT-S,SS+TTT,TT,TT+12,SS-S*4}
local KY1 = (key[1]+key[3]-key[1])-key[5] 
local KY2 = (key[1]-Amk[2]*key[3]*Amk[4])-key[5]
local KY3 = (Amk[2]-Amk[1]*Amk[4]-Amk[3])+Amk[1]
local KY4 = (key[1]+AE-key[1])*key[2]
local KY5 = (key[3]+Amk[4]-ADD)+key[2]
local KY6 = (Amk[1]-Amk[3]+key[1])+AFFF

local X = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD, ACC, AGG+3000,AC}
local Y = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+4000,AB+7000,AC}
local X1 = (X[1]+X[3]-X[1]) -X[5] 
local X2 = (X[1]-Y[2]*X[3]*Y[4]) -X[5]
local X3 = (Y[2]-Y[1]*Y[4]-Y[3]) +Y[1]
local X5 = (X[3]+Y[4]-ADD) +X[2]
local X6 = (Y[1]-Y[3]+X[1])+AFFF

local Key1 = math.random(1000,50000)
local Key2 = math.random(1000,50000)
local Key3 = math.random(1000,50000)
local Key4 = math.random(1000,50000)
local Key5 = math.random(1000,50000)
local Key6 = math.random(1000,50000)
local Key7 = math.random(1000,50000)
local Key8 = math.random(1000,50000)
local Key9 = math.random(1000,50000)
local Key10 = math.random(1000,50000)
local Key11 = math.random(1000,50000)
local Key12 = math.random(1000,50000)
local Key13 = math.random(1000,50000)
local Key14 = math.random(1000,50000)
local Key15 = math.random(1000,50000)
local Key16 = math.random(1000,50000)
local Key17 = math.random(1000,50000)
local Key18 = math.random(1000,50000)
local Key19 = math.random(1000,50000)
local Key20 = math.random(1000,50000)
local KeyHex1 = math.random(1000,50000)
local KeyHex2 = math.random(1000,50000)
local KeyHex3 = math.random(1000,50000)
local KeyHex4 = math.random(1000,50000)
local KeyHex5 = math.random(1000,50000)

local inv256 
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function ShaMod(str)str = str:gsub("\n", "\n") if not inv256 then inv256 = {} for M = 1, 100 do local inv = -1 repeat inv = inv + 2 until inv * (2*M + 1) % 256 == 1 inv256[M] = inv end;end local K, F = X1 - X3 + X2, X2 - X3 * X5 return (str:gsub('.', function(m) local L = K % X6; local H = (K - L) / X6; local M = H % 27; local m = m:byte() local c = (m * inv256[M] - (H - M) / 27) % 256 K = L * F + H + c + m
return ('%02x'):format(c)end)) end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function Sha(str)str = str:gsub("\\n", "\n") if not inv256 then inv256 = {} for M = 0, 127 do local inv = -1 repeat inv = inv + 2 until inv * (2*M + 1) % 256 == 1 inv256[M] = inv end;end local K, F = KY1 - KY3 + KY2, KY2 - KY3 * KY5 return (str:gsub('.', function(m)local L = K % KY6;local H = (K - L) / KY6;local M = H % 27;local m = m:byte()local c = (m * inv256[M] - (H - M) / 27) % 256 K = L * F + H + c + m  return ('%02x'):format(c)end)) end
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function SHA(str)
    str = str:gsub("\\n","\n"):gsub("\\t","\t")
    if not inv256 then 
        inv256 = {} 
        for M = 1, 100 do 
            local inv = -1 
            repeat  
                inv = inv + 2 
            until inv * (2*M + 1) % 256 == 1 
            inv256[M] = inv 
        end 
    end
    local K, F = X1 - X3 + X2, X2 - X3 * X5 
    return (str:gsub('.', function(m) 
        local L = K % X6 
        local H = (K - L) / X6 
        local M = H % 27 
        local m = m:byte() 
        local c = (m * inv256[M] - (H - M) / 27) % 256 
        K = L * F + H + c + m 
        return ('%02x'):format(c) 
    end)) 
end
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function encodegg(code)
	return '_G["gg"][BGames({BGA = "' .. SHA(code) .. '"})]('
end
function encodeio(code)
	return '_G["io"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeos(code)
return '_G["os"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodevalue(code)
	return 'BGames({BGA = "' .. Sha(code) .. '"})'
end

function encodestr(code)
return '_G["string"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodetbl(code)
return '_G["table"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodedebug(code)
return '_G["debug"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeprint(code)
return '_G["print"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodefile(code)
return '_G["loadfile"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Decode =[[
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
local ABBB = "]]..ABBB..[[";local ACC = "]]..ACC..[[";local i = "]]..math.random(100,800)..[[";local AB = "]]..AB..[[";local i = "]]..math.random(200,900)..[[";local ADD = "]]..ADD..[[";local ADDD = "]]..ADDD..[[";local AGG = "]]..AGG..[[";local AD = "]]..AD..[[";local AXE = "]]..AXE..[[";local i = "]]..math.random(200,900)..[[";local AC = "]]..AC..[[";local AGGG = "]]..AGGG..[[";local AFF = "]]..AFF..[[";local AE = "]]..AE..[[";
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
local ACC = "]]..ACC..[[";local AE = "]]..AE..[[";local AX = "]]..AX..[[";local ACCC = "]]..ACCC..[[";local AG = "]]..AG..[[";local ABB = "]]..ABB..[[";local AF = "]]..AF..[[";local AFFF = "]]..AFFF..[[";local i = "]]..math.random(100,800)..[[";
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end

local key = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD};local Amk = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+3,AC};local KY1 = (key[1]+key[3]-key[1])-key[5] ;local KY2 = (key[1]-Amk[2]*key[3]*Amk[4])-key[5];local KY3 = (Amk[2]-Amk[1]*Amk[4]-Amk[3])+Amk[1];local KY4 = (key[1]+AE-key[1])*key[2];local KY5 = (key[3]+Amk[4]-ADD)+key[2];local KY6 = (Amk[1]-Amk[3]+key[1])+AFFF;local inv256 
local BGames = function(str) str = str.BGA local K, F = KY1 - KY3 + KY2, KY2 - KY3 * KY5 return (str:gsub('%x%x', function(c) local L = K % KY6 local H = (K - L) / KY6 local M = H % 27 c = tonumber(c, 16) local m = (c + (H - M) / 27) * (2*M + 1) % 256 K = L * F + H + c + m 
 if true then return string.char(m)end if true then return end if true then return end end))end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

lock2 =[[
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
gg.toast("Encrypt by ꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂")

	if true then
		if string.match('/' .. tostring(os.time()), '/([^/]+)$') ~= tostring(os.time()) then
			while true do
				if true then
					gg.alert('Error, time is not acceptable.')
					os.exit()
				end
				if false then
				end
			end
		end
	end
	
local GetTableSpam = {}
local b, toStr, GetSpamName = 0, tostring;

local tmp = (function()
  local tempString = ''
  while (b < (10^2)) do
    tempString = tempString .. toStr(b * b);
    b = b + 1
  end
  GetSpamName = (function() local HashName = '' for i = 1, 10 do HashName = "ðŸŒ¨ï¸" .. HashName .. "â˜ƒï¸" .. HashName .. "â„ï¸" end return HashName:rep(100) end)()
  return tempString;
end)();

local spam = "Boar"
local c, b = "'" .. math.random(1, 255) .. "'",  math.random(100, 300)
if tostring("@") == "" then
	return
end

for k, v in next, _ENV do
	if tostring(v):match("function: @.-:") then
		return
	end

local func = os.exit
if tostring(func):match("-") or tostring(func):match("//") or tostring(func):match("@") or tostring(func):match("%d+") then
	return
end
end

local spam_2 = "is top"

for i = 1, #tmp do
    GetTableSpam[i] = {["address"] = GetSpamName, ["flags"] = GetSpamName, ["value"] = GetSpamName, ["freeze"] = GetSpamName, ["name"] = GetSpamName, GetTableSpam[i - 1]}
    gg.refineNumber(GetTableSpam)
	gg.refineAddress(GetTableSpam)
end

local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
os.exit()
os.exit()
os["]==])..string.char(math.random(128,255),math.random(128,255),math.random(128,255),math.random(128,255))..([==["]()
gg.processKill()
return
end
end
if pcall(_ENV["os"]["exit"]) or _ENV["string"]["rep"]("'",'2')~="''" or not _ENV["debug"]["getinfo"](_ENV["tostring"])["isvararg"] or _ENV["debug"]["getinfo"](gg["searchNumber"])["what"]=="Lua" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

_ENV["B1"]= _ENV["debug"]["getinfo"](gg.refineNumber).short_src
if _ENV["B1"]~=_ENV["debug"]["getinfo"](1).short_src and _ENV["B1"]~=gg.getFile() then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if debug.getinfo(1).istailcall then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

x=debug.getinfo(gg.searchNumber)
if x.what~=('Java') then 
os.exit() 
while true do 
end 
end 
local i = {}
local g = {}
local ppi, ppb
g["last"] = _ENV["gg"]["getFile"]()
g["dados_saida"] = _ENV["loadfile"](g["last"])
g["cpp"] = g["dados_saida"]
if g["cpp"] ~= nil then 
g["dados_saida"] = nil
local ppb = g["last"]:match("[^/]+$")
local ppi = "lohhhggg"
local pu = _ENV["gg"]["getResults"](5000)
_ENV["os"]["rename"](''..g["last"]..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'') 
local prt = _ENV["loadfile"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'')
if prt ~= nil then
_ENV["os"]["rename"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppb..'')
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
for i in _ENV["ipairs"]({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])}) do 
if _ENV["string"]["match"](({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])})[i], ("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if _ENV["string"]["rep"]("a", 2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if ("a"):rep(2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _ENV["tostring"](_ENV["gg"]):find(("@")) then 
if not _ENV["tostring"](_ENV["debug"]):find(("@")) then 
if not _ENV["tostring"](_ENV["io"]):find(("@")) then 
if _ENV["tostring"](_ENV["string"]):find(("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
        until x== 20000
        gg["sleep"](0)
        os.exit()
      until false
     end
   end
 end 
end
if _G["debug"]["getlocal"](2, 4) == nil then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _G["utf8"] then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

if _ENV["debug"]["traceback"] == nil then
return 
end

if _ENV["string"]["rep"]("a", 2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

if ("a"):rep(2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

local log = _ENV["string"]["char"](("255"),("255"),("255"),("255"),("255"),("255")):rep("999"):rep("999"):rep(4)
for i = 1,("3340") do
_ENV["gg"]["refineNumber"]("0",log,log,log,log,log,log,log)
end

local GG={"art","ART","Art","dec","Dec","DEC","hook","Hook","HooK","HOOK","log","Log","LOG",}
local _gg={gg.CACHE_DIR,gg.EXT_FILES_DIR,gg.EXT_CACHE_DIR,gg.FILES_DIR,gg.PACKAGE}
for i,v in pairs(GG) do
if string.find(tostring(_gg),v) or(not string.find(tostring(_gg),"com"))then
Error(true)
end
end

while gg.PACKAGE == "catch.Art.Tool.seatch" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.VERSION == "96.0" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.BUILD == "15993" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while string.find(gg.EXT_CACHE_DIR,"com.Art.Tool") do
end
while string.find(gg.EXT_CACHE_DIR,"catch_.me_.if_.you_.can_93") do
end

_ENV["debug"]["getinfo"]=function(a)
return _ENV["debug"]["getinfo"]("BATMANN")
end

for i in string.gmatch(tostring(debug.traceback()), '(.-)\n') do
if string.match(i, '.(/.-):') and string.match(i, '.(/.-):') ~= gg.getFile() then

os.exit()

print("ï¸")
return
end
end

]] 
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

AntiLasm=[[
mmk = ''
for i = 1, math.random(5, 10) do
    fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
    mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nif fucklog or debug.getinfo(2) ~= nil then\n\n   print('Tentativa de log ou disassembly detectada!')\n   -- Encerrar a execução ou tomar outra ação adequada\n   return\nend\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" 
end
]]

 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Infinite = [[

for i = 1,5 do
    if(nil) then 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
    end
    loadfile = loadfile
    load = load
    loadfile(gg.getFile()) 
    load(string.dump(load("os.exit()"),false,false)) 
    io.open(gg.getFile() .. "c" .. tostring(string.dump(loadfile(gg.getFile()),false,false)),"w") 
end

for i = 1, 5000 do
    table.insert({}, {})
end
for i = 1, 5000 do
    table.insert({}, {})
end

gg.setVisible(false)
for i = 1, 6 do
    gg.addListItems({})
end

gg.setVisible(false)
gg.removeListItems({})

if os.time() > os.time() then
    return 
end
if os.time() < os.time() then
end
if os.difftime(os.time(), (os.time())) > 2 then
    return 
end

gg.setVisible(false)
if os.clock() > os.clock() then
    return 
end
if os.clock() < os.clock() then
end
if os.difftime(os.clock(), (os.clock())) > 2 then
    return 
end

gg.setVisible(false)
for i = 3, 100 do
    load(gg.getFile())
end

while(nil)do
    local i={}
    if(i.i)then
        i.i=(i.i(i))
    end
end

while(nil)do
    for i=i,i do
        local i={}
        if(i.i)then
            i.i=(i.i(i))
        end
        for ii=i.i,i.i,i.i do
            local ii={}
            if(ii.i)then
                ii.i=ii.i()
            end
            for iii=i,ii.i,i do
                local iii={}
                if(iii.i)then
                    iii.i=iii.i(i)
                end
                for iiii=i,ii,iii.i do
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=iiii.i(i)
                    end
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=(iiii|iii|ii|i)(i)
                    end
                end
                local iii={}
                if(iii.i)then
                    iii.i=(true|iii|ii|i)(i)
                end
            end
            local ii={}
            if(ii.i)then
                ii.i=(true|false|ii|i)(i)
            end
        end
        local i={}
        if(i.i)then
            i.i=(true|false|nil|i)(i)
        end
        return(true|false|nil)
    end
    return
end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Infinite2 = [[
function obfuscate(code, x)
    x = x or ""
    code = x .. code
    local dmpbool = true
    local proccess = {
        "%%%%%%",
        "@@@@@@",
        "&&&&&&",
        "******"
    } 
    local temporary = "temp.lua" 
    for i = 1, #proccess do
        local f = load(code) or function() error("Error") end
        local dumped_code = string.dump(f, dmpbool)
        local f2 = load(dumped_code) or function() error("Error") end
        gg.internal2(f2, temporary)
        local a, b = {}, {}
        local dados_saida = {}
        for line in io.lines(temporary) do
            if line:match("^%s*%.func") or line:match("^%s*%.end") then
                b[#b + 1] = #dados_saida
                if #b == 2 then
                    if b[2] > b[1] + 2 then
                        a[#a + 1] = b
                    end
                    b = {b[2]}
                end
            end
            dados_saida[#dados_saida + 1] = line
        end
        code = table.concat(dados_saida, "\n")
        os.remove(temporary)
        for k, v in pairs(a) do
            local pattern = ""
            for i = v[1], v[2] do
                pattern = pattern .. dados_saida[i]:gsub("%p", function(c)
                    return "%" .. c
                end) .. "\n"
            end
            code = code:gsub(pattern, proccess[i])
        end
        dmpbool = false
    end
    return code
end

]]

blocksstol = [[

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

dados_saida = dados_saida:gsub("%'.-(.-)%'", encodevalue)
dados_saida = dados_saida:gsub('%".-(.-)%"', encodevalue)
dados_saida = dados_saida:gsub('%[%[.-(.-)%]%]', encodevalue)
dados_saida = dados_saida:gsub("gg%.(%a+)%(", encodegg)
dados_saida = dados_saida:gsub("io%.(%a+)%(", encodeio)
dados_saida = dados_saida:gsub("os%.(%a+)%(", encodeos)
dados_saida = dados_saida:gsub("table%.(%a+)%(", encodetbl)
dados_saida = dados_saida:gsub("debug%.(%a+)%(", encodedebug)
dados_saida = dados_saida:gsub("print%.(%a+)%(", encodeprint)
dados_saida = dados_saida:gsub("loadfile%.(%a+)%(", encodefile)
dados_saida = dados_saida:gsub("string%.(%a+)%(", encodestr)

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--dados_saida = Decode .. dados_saida
dados_saida = blocksstol..lock2..Infinite..Infinite2..AntiLasm..Decode..dados_saida

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

dados_saida = ""..dados_saida
 
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

io.open(g.out,"w"):write(string.gsub(string.dump(load(dados_saida), true), 'LuaR', 'LuaR', 1)):close()
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
ClU = '📂 File Saved To: '..g.out..'\n'
gg.alert(ClU, '')
print("\n▬▬▬▬▬▬▬▬▬▬▬▬▬\n📂 File Saved To :" .. g.out .. "\n▬▬▬▬▬▬▬▬▬▬▬▬▬")
return 
end
 end

function encv4() 
g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 gg.alert([[

📌 Features
 
Encrypy encode string +
Encrypt string to hex +
Encrypt code morse  + 
sha+
new block Sstool+
antilog +
antiload 
Working gg 101.1✔️

by Batman Games🍿 
My telegram @batmangamesS 
]])
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

while true do
  g.info = gg.prompt({
    '📂 Select file :', -- 1
    '📂 Select folder  :' -- 2
  }, g.info, {
    'file', -- 1
    'path' -- 2
  })
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  gg.saveVariable(g.info, g.config)
  g.last = g.info[1]
  if loadfile(g.last) == nil then
    gg.alert("⚠️ Script not Found! ⚠️")
    return
  else
    g.out = g.last:match("[^/]+$")
    g.out = g.out:gsub(".lua", ".Batman")
    g.out = g.info[2] .. "" .. g.out .. ".lua"
  end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  local file = io.open(g.last, "r")
  local DATA = file:read('*a')
  file:close()
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
function EncodeFunctionString1(str)
    local result = ""
    for i = 1, #str do
        local byteValue = string.byte(str:sub(i, i))
        local encodedByte = string.format('%02x', (byteValue - 42) % 256)  -- Modificando o valor de Keys para 42
        result = result .. encodedByte
    end
    return result:gsub("^$", "")  -- Remove o primeiro caractere "$" se estiver presente
end

DATA = EncodeFunctionString1(DATA)


local function str2hexa(str)
                local h = string.gsub(str, ".", function(c)
                        return string.format("%02x", string.byte(c))
                end)
                return h
        end

DATA = str2hexa(DATA)



local function Enc(str)
    str = str:upper()  -- Converter a string para letras maiúsculas
    
    local Nums = {".----","..---","...--","....-",".....","-....","--...","---..","----.","-----"} 
    local Words = {".-","-...","-.-.","-..",".","..-.","--.","....","..",".---","-.-",".-..","--","-.","---",".--.","--.-",".-.","...","-","..-","...-",".--","-..-","-.--","--.."} 
    local encodedStr = ""

    for i = 1, #str do
        local char = str:sub(i, i)
        if char:match("[%d]") then  -- Se o caractere for um dígito
            local num = tonumber(char)
            if num == 0 then num = 10 end
            encodedStr = encodedStr .. " " .. Nums[num]
        elseif char:match("[%u]") then  -- Se o caractere for uma letra maiúscula
            encodedStr = encodedStr .. " " .. Words[char:byte() - 64]
        end
    end
    
    return encodedStr:sub(2)  -- Remover o espaço inicial antes do primeiro caractere codificado
end


DATA = Enc(DATA)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  -- Lógica para decodificar o conteúdo durante a execução do script
  local descript_code = [[
 
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------



function DecodeFunctionString1(str)
    local result = ""
    for i = 1, #str, 2 do
        local hexByte = str:sub(i, i + 1)
        local byteValue = tonumber(hexByte, 16)
        local decodedByte = string.char((byteValue + 42) % 256)  -- Invertendo a operação de codificação
        result = result .. decodedByte
    end
    return result
end


local function hexa2str(hexStr)
    local str = hexStr:gsub("(%x%x)", function(hex)
        return string.char(tonumber(hex, 16))
    end)
    return str
end



local function Dec(str)
    local MorseToChar = {
        [".-"] = "A", ["-..."] = "B", ["-.-."] = "C", ["-.."] = "D", ["."] = "E",
        ["..-."] = "F", ["--."] = "G", ["...."] = "H", [".."] = "I", [".---"] = "J",
        ["-.-"] = "K", [".-.."] = "L", ["--"] = "M", ["-."] = "N", ["---"] = "O",
        [".--."] = "P", ["--.-"] = "Q", [".-."] = "R", ["..."] = "S", ["-"] = "T",
        ["..-"] = "U", ["...-"] = "V", [".--"] = "W", ["-..-"] = "X", ["-.--"] = "Y",
        ["--.."] = "Z", [".----"] = "1", ["..---"] = "2", ["...--"] = "3", ["....-"] = "4",
        ["....."] = "5", ["-...."] = "6", ["--..."] = "7", ["---.."] = "8", ["----."] = "9",
        ["-----"] = "0"
    }
    
    local decodedStr = ""
    for code in str:gmatch("%S+") do
        decodedStr = decodedStr .. (MorseToChar[code] or " ")
    end
    
    return decodedStr
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    -- Recuperar o código original
    local encrypted_code = "]] .. DATA .. [["
    local decrypted_code = DecodeFunctionString1(hexa2str(Dec(encrypted_code)))
    assert(load(decrypted_code))()
  ]]
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  DATA = descript_code
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

io.open(g.out,"w"):write(DATA):close()

-- Lendo os dados do arquivo de saída "g.out"
local arquivo_saida = io.open(g.out, "r")
local xxx = arquivo_saida:read("*a")
arquivo_saida:close()

S = math.random(1, 60)
SS = math.random(80, 302)
SSS = math.random(1, 60)
T = math.random(190, 340)
TT = math.random(1, 60)
TTT = math.random(190, 470)
AB = math.random(1000,2000)
AC = math.random(3000,4000)
AD = math.random(5000,6000)
AE = math.random(6000,8000)
AF = math.random(9000,10000)
AG = math.random(400,600)
ABB = math.random(2000,2000)
ACC = math.random(3000,4000)
ADD = math.random(5000,6000)
AFF = math.random(9000,10000)
AGG = math.random(400,600)
AX = math.random(200,800)
ABBB = math.random(1000,2000)
ACCC = math.random(3000,4000)
ADDD = math.random(5000,6000)
AXE = math.random(7000,8000)
AFFF = math.random(9000,10000)
AGGG = math.random(400,600)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local key = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD}
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local Amk = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+3,AC}
local Kei = {(SS-S)+T,SSS+TT-S,SS+TTT,TT,TT+12,SS-S*4}
local KY1 = (key[1]+key[3]-key[1])-key[5] 
local KY2 = (key[1]-Amk[2]*key[3]*Amk[4])-key[5]
local KY3 = (Amk[2]-Amk[1]*Amk[4]-Amk[3])+Amk[1]
local KY4 = (key[1]+AE-key[1])*key[2]
local KY5 = (key[3]+Amk[4]-ADD)+key[2]
local KY6 = (Amk[1]-Amk[3]+key[1])+AFFF

local X = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD, ACC, AGG+3000,AC}
local Y = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+4000,AB+7000,AC}
local X1 = (X[1]+X[3]-X[1]) -X[5] 
local X2 = (X[1]-Y[2]*X[3]*Y[4]) -X[5]
local X3 = (Y[2]-Y[1]*Y[4]-Y[3]) +Y[1]
local X5 = (X[3]+Y[4]-ADD) +X[2]
local X6 = (Y[1]-Y[3]+X[1])+AFFF

local Key1 = math.random(1000,50000)
local Key2 = math.random(1000,50000)
local Key3 = math.random(1000,50000)
local Key4 = math.random(1000,50000)
local Key5 = math.random(1000,50000)
local Key6 = math.random(1000,50000)
local Key7 = math.random(1000,50000)
local Key8 = math.random(1000,50000)
local Key9 = math.random(1000,50000)
local Key10 = math.random(1000,50000)
local Key11 = math.random(1000,50000)
local Key12 = math.random(1000,50000)
local Key13 = math.random(1000,50000)
local Key14 = math.random(1000,50000)
local Key15 = math.random(1000,50000)
local Key16 = math.random(1000,50000)
local Key17 = math.random(1000,50000)
local Key18 = math.random(1000,50000)
local Key19 = math.random(1000,50000)
local Key20 = math.random(1000,50000)
local KeyHex1 = math.random(1000,50000)
local KeyHex2 = math.random(1000,50000)
local KeyHex3 = math.random(1000,50000)
local KeyHex4 = math.random(1000,50000)
local KeyHex5 = math.random(1000,50000)

local inv256 
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function ShaMod(str)str = str:gsub("\n", "\n") if not inv256 then inv256 = {} for M = 1, 100 do local inv = -1 repeat inv = inv + 2 until inv * (2*M + 1) % 256 == 1 inv256[M] = inv end;end local K, F = X1 - X3 + X2, X2 - X3 * X5 return (str:gsub('.', function(m) local L = K % X6; local H = (K - L) / X6; local M = H % 27; local m = m:byte() local c = (m * inv256[M] - (H - M) / 27) % 256 K = L * F + H + c + m
return ('%02x'):format(c)end)) end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function Sha(str)str = str:gsub("\\n", "\n") if not inv256 then inv256 = {} for M = 0, 127 do local inv = -1 repeat inv = inv + 2 until inv * (2*M + 1) % 256 == 1 inv256[M] = inv end;end local K, F = KY1 - KY3 + KY2, KY2 - KY3 * KY5 return (str:gsub('.', function(m)local L = K % KY6;local H = (K - L) / KY6;local M = H % 27;local m = m:byte()local c = (m * inv256[M] - (H - M) / 27) % 256 K = L * F + H + c + m  return ('%02x'):format(c)end)) end
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function SHA(str)
    str = str:gsub("\\n","\n"):gsub("\\t","\t")
    if not inv256 then 
        inv256 = {} 
        for M = 1, 100 do 
            local inv = -1 
            repeat  
                inv = inv + 2 
            until inv * (2*M + 1) % 256 == 1 
            inv256[M] = inv 
        end 
    end
    local K, F = X1 - X3 + X2, X2 - X3 * X5 
    return (str:gsub('.', function(m) 
        local L = K % X6 
        local H = (K - L) / X6 
        local M = H % 27 
        local m = m:byte() 
        local c = (m * inv256[M] - (H - M) / 27) % 256 
        K = L * F + H + c + m 
        return ('%02x'):format(c) 
    end)) 
end
 
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function encodegg(code)
	return '_G["gg"][BGames({BGA = "' .. SHA(code) .. '"})]('
end
function encodeio(code)
	return '_G["io"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeos(code)
return '_G["os"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodevalue(code)
	return 'BGames({BGA = "' .. Sha(code) .. '"})'
end

function encodestr(code)
return '_G["string"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodetbl(code)
return '_G["table"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodedebug(code)
return '_G["debug"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeprint(code)
return '_G["print"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodefile(code)
return '_G["loadfile"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Decode =[[
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
local ABBB = "]]..ABBB..[[";local ACC = "]]..ACC..[[";local i = "]]..math.random(100,800)..[[";local AB = "]]..AB..[[";local i = "]]..math.random(200,900)..[[";local ADD = "]]..ADD..[[";local ADDD = "]]..ADDD..[[";local AGG = "]]..AGG..[[";local AD = "]]..AD..[[";local AXE = "]]..AXE..[[";local i = "]]..math.random(200,900)..[[";local AC = "]]..AC..[[";local AGGG = "]]..AGGG..[[";local AFF = "]]..AFF..[[";local AE = "]]..AE..[[";
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
local ACC = "]]..ACC..[[";local AE = "]]..AE..[[";local AX = "]]..AX..[[";local ACCC = "]]..ACCC..[[";local AG = "]]..AG..[[";local ABB = "]]..ABB..[[";local AF = "]]..AF..[[";local AFFF = "]]..AFFF..[[";local i = "]]..math.random(100,800)..[[";
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end

local key = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD};local Amk = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+3,AC};local KY1 = (key[1]+key[3]-key[1])-key[5] ;local KY2 = (key[1]-Amk[2]*key[3]*Amk[4])-key[5];local KY3 = (Amk[2]-Amk[1]*Amk[4]-Amk[3])+Amk[1];local KY4 = (key[1]+AE-key[1])*key[2];local KY5 = (key[3]+Amk[4]-ADD)+key[2];local KY6 = (Amk[1]-Amk[3]+key[1])+AFFF;local inv256 
local BGames = function(str) str = str.BGA local K, F = KY1 - KY3 + KY2, KY2 - KY3 * KY5 return (str:gsub('%x%x', function(c) local L = K % KY6 local H = (K - L) / KY6 local M = H % 27 c = tonumber(c, 16) local m = (c + (H - M) / 27) * (2*M + 1) % 256 K = L * F + H + c + m 
 if true then return string.char(m)end if true then return end if true then return end end))end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

lock2 =[[
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
gg.toast("Encrypt by ꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂")

	if true then
		if string.match('/' .. tostring(os.time()), '/([^/]+)$') ~= tostring(os.time()) then
			while true do
				if true then
					gg.alert('Error, time is not acceptable.')
					os.exit()
				end
				if false then
				end
			end
		end
	end
	
local GetTableSpam = {}
local b, toStr, GetSpamName = 0, tostring;

local tmp = (function()
  local tempString = ''
  while (b < (10^2)) do
    tempString = tempString .. toStr(b * b);
    b = b + 1
  end
  GetSpamName = (function() local HashName = '' for i = 1, 10 do HashName = "ðŸŒ¨ï¸" .. HashName .. "â˜ƒï¸" .. HashName .. "â„ï¸" end return HashName:rep(100) end)()
  return tempString;
end)();

local spam = "Boar"
local c, b = "'" .. math.random(1, 255) .. "'",  math.random(100, 300)
if tostring("@") == "" then
	return
end

for k, v in next, _ENV do
	if tostring(v):match("function: @.-:") then
		return
	end

local func = os.exit
if tostring(func):match("-") or tostring(func):match("//") or tostring(func):match("@") or tostring(func):match("%d+") then
	return
end
end

local spam_2 = "is top"

for i = 1, #tmp do
    GetTableSpam[i] = {["address"] = GetSpamName, ["flags"] = GetSpamName, ["value"] = GetSpamName, ["freeze"] = GetSpamName, ["name"] = GetSpamName, GetTableSpam[i - 1]}
    gg.refineNumber(GetTableSpam)
	gg.refineAddress(GetTableSpam)
end

local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
os.exit()
os.exit()
os["]==])..string.char(math.random(128,255),math.random(128,255),math.random(128,255),math.random(128,255))..([==["]()
gg.processKill()
return
end
end
if pcall(_ENV["os"]["exit"]) or _ENV["string"]["rep"]("'",'2')~="''" or not _ENV["debug"]["getinfo"](_ENV["tostring"])["isvararg"] or _ENV["debug"]["getinfo"](gg["searchNumber"])["what"]=="Lua" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

_ENV["B1"]= _ENV["debug"]["getinfo"](gg.refineNumber).short_src
if _ENV["B1"]~=_ENV["debug"]["getinfo"](1).short_src and _ENV["B1"]~=gg.getFile() then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if debug.getinfo(1).istailcall then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

x=debug.getinfo(gg.searchNumber)
if x.what~=('Java') then 
os.exit() 
while true do 
end 
end 
local i = {}
local g = {}
local ppi, ppb
g["last"] = _ENV["gg"]["getFile"]()
g["xxx"] = _ENV["loadfile"](g["last"])
g["cpp"] = g["xxx"]
if g["cpp"] ~= nil then 
g["xxx"] = nil
local ppb = g["last"]:match("[^/]+$")
local ppi = "lohhhggg"
local pu = _ENV["gg"]["getResults"](5000)
_ENV["os"]["rename"](''..g["last"]..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'') 
local prt = _ENV["loadfile"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'')
if prt ~= nil then
_ENV["os"]["rename"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppb..'')
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
for i in _ENV["ipairs"]({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])}) do 
if _ENV["string"]["match"](({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])})[i], ("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if _ENV["string"]["rep"]("a", 2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if ("a"):rep(2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _ENV["tostring"](_ENV["gg"]):find(("@")) then 
if not _ENV["tostring"](_ENV["debug"]):find(("@")) then 
if not _ENV["tostring"](_ENV["io"]):find(("@")) then 
if _ENV["tostring"](_ENV["string"]):find(("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
        until x== 20000
        gg["sleep"](0)
        os.exit()
      until false
     end
   end
 end 
end
if _G["debug"]["getlocal"](2, 4) == nil then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _G["utf8"] then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

if _ENV["debug"]["traceback"] == nil then
return 
end

if _ENV["string"]["rep"]("a", 2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

if ("a"):rep(2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

local log = _ENV["string"]["char"](("255"),("255"),("255"),("255"),("255"),("255")):rep("999"):rep("999"):rep(4)
for i = 1,("3340") do
_ENV["gg"]["refineNumber"]("0",log,log,log,log,log,log,log)
end

local GG={"art","ART","Art","dec","Dec","DEC","hook","Hook","HooK","HOOK","log","Log","LOG",}
local _gg={gg.CACHE_DIR,gg.EXT_FILES_DIR,gg.EXT_CACHE_DIR,gg.FILES_DIR,gg.PACKAGE}
for i,v in pairs(GG) do
if string.find(tostring(_gg),v) or(not string.find(tostring(_gg),"com"))then
Error(true)
end
end

while gg.PACKAGE == "catch.Art.Tool.seatch" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.VERSION == "96.0" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.BUILD == "15993" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while string.find(gg.EXT_CACHE_DIR,"com.Art.Tool") do
end
while string.find(gg.EXT_CACHE_DIR,"catch_.me_.if_.you_.can_93") do
end

_ENV["debug"]["getinfo"]=function(a)
return _ENV["debug"]["getinfo"]("BATMANN")
end

for i in string.gmatch(tostring(debug.traceback()), '(.-)\n') do
if string.match(i, '.(/.-):') and string.match(i, '.(/.-):') ~= gg.getFile() then

os.exit()

print("ï¸")
return
end
end

]] 
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

AntiLasm=[[
mmk = ''
for i = 1, math.random(5, 10) do
    fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
    mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nif fucklog or debug.getinfo(2) ~= nil then\n\n   print('Tentativa de log ou disassembly detectada!')\n   -- Encerrar a execução ou tomar outra ação adequada\n   return\nend\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" 
end
]]

 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Infinite = [[

for i = 1,5 do
    if(nil) then 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
    end
    loadfile = loadfile
    load = load
    loadfile(gg.getFile()) 
    load(string.dump(load("os.exit()"),false,false)) 
    io.open(gg.getFile() .. "c" .. tostring(string.dump(loadfile(gg.getFile()),false,false)),"w") 
end

for i = 1, 5000 do
    table.insert({}, {})
end
for i = 1, 5000 do
    table.insert({}, {})
end

gg.setVisible(false)
for i = 1, 6 do
    gg.addListItems({})
end

gg.setVisible(false)
gg.removeListItems({})

if os.time() > os.time() then
    return 
end
if os.time() < os.time() then
end
if os.difftime(os.time(), (os.time())) > 2 then
    return 
end

gg.setVisible(false)
if os.clock() > os.clock() then
    return 
end
if os.clock() < os.clock() then
end
if os.difftime(os.clock(), (os.clock())) > 2 then
    return 
end

gg.setVisible(false)
for i = 3, 100 do
    load(gg.getFile())
end

while(nil)do
    local i={}
    if(i.i)then
        i.i=(i.i(i))
    end
end

while(nil)do
    for i=i,i do
        local i={}
        if(i.i)then
            i.i=(i.i(i))
        end
        for ii=i.i,i.i,i.i do
            local ii={}
            if(ii.i)then
                ii.i=ii.i()
            end
            for iii=i,ii.i,i do
                local iii={}
                if(iii.i)then
                    iii.i=iii.i(i)
                end
                for iiii=i,ii,iii.i do
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=iiii.i(i)
                    end
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=(iiii|iii|ii|i)(i)
                    end
                end
                local iii={}
                if(iii.i)then
                    iii.i=(true|iii|ii|i)(i)
                end
            end
            local ii={}
            if(ii.i)then
                ii.i=(true|false|ii|i)(i)
            end
        end
        local i={}
        if(i.i)then
            i.i=(true|false|nil|i)(i)
        end
        return(true|false|nil)
    end
    return
end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


Infinite2 = [[
function obfuscate(code, x)
    x = x or ""
    code = x .. code
    local dmpbool = true
    local proccess = {
        "%%%%%%",
        "@@@@@@",
        "&&&&&&",
        "******"
    } 
    local temporary = "temp.lua" 
    for i = 1, #proccess do
        local f = load(code) or function() error("Error") end
        local dumped_code = string.dump(f, dmpbool)
        local f2 = load(dumped_code) or function() error("Error") end
        gg.internal2(f2, temporary)
        local a, b = {}, {}
        local xxx = {}
        for line in io.lines(temporary) do
            if line:match("^%s*%.func") or line:match("^%s*%.end") then
                b[#b + 1] = #xxx
                if #b == 2 then
                    if b[2] > b[1] + 2 then
                        a[#a + 1] = b
                    end
                    b = {b[2]}
                end
            end
            xxx[#xxx + 1] = line
        end
        code = table.concat(xxx, "\n")
        os.remove(temporary)
        for k, v in pairs(a) do
            local pattern = ""
            for i = v[1], v[2] do
                pattern = pattern .. xxx[i]:gsub("%p", function(c)
                    return "%" .. c
                end) .. "\n"
            end
            code = code:gsub(pattern, proccess[i])
        end
        dmpbool = false
    end
    return code
end

]]

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

blocksstol = [[

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

xxx = xxx:gsub("%'.-(.-)%'", encodevalue)
xxx = xxx:gsub('%".-(.-)%"', encodevalue)
xxx = xxx:gsub('%[%[.-(.-)%]%]', encodevalue)
xxx = xxx:gsub("gg%.(%a+)%(", encodegg)
xxx = xxx:gsub("io%.(%a+)%(", encodeio)
xxx = xxx:gsub("os%.(%a+)%(", encodeos)
xxx = xxx:gsub("table%.(%a+)%(", encodetbl)
xxx = xxx:gsub("debug%.(%a+)%(", encodedebug)
xxx = xxx:gsub("print%.(%a+)%(", encodeprint)
xxx = xxx:gsub("loadfile%.(%a+)%(", encodefile)
xxx = xxx:gsub("string%.(%a+)%(", encodestr)

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--xxx = Decode .. xxx
xxx = blocksstol..lock2..Infinite..Infinite2..AntiLasm..Decode..xxx

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

xxx = ""..xxx

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

io.open(g.out,"w"):write(string.gsub(string.dump(load(xxx), true), 'LuaR', 'LuaR', 1)):close()
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
ClU = '📂 File Saved To: '..g.out..'\n'
gg.alert(ClU, '')
print("\n▬▬▬▬▬▬▬▬▬▬▬▬▬\n📂 File Saved To :" .. g.out .. "\n▬▬▬▬▬▬▬▬▬▬▬▬▬")
return 
end
 end


function encv5()

g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 gg.alert([[

📌 Features
 
ofuscation +
Encrypt string +
sha+
new block Sstool+
antilog +
antiload 
Working gg 101.1✔️

by Batman Games🍿 
My telegram @batmangamesS 
]])
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

while true do
  g.info = gg.prompt({
    '📂 Select file :', -- 1
    '📂 Select folder  :' -- 2
  }, g.info, {
    'file', -- 1
    'path' -- 2
  })
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  gg.saveVariable(g.info, g.config)
  g.last = g.info[1]
  if loadfile(g.last) == nil then
    gg.alert("⚠️ Script not Found! ⚠️")
    return
  else
    g.out = g.last:match("[^/]+$")
    g.out = g.out:gsub(".lua", ".Batman")
    g.out = g.info[2] .. "" .. g.out .. ".lua"
  end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  local file = io.open(g.last, "r")
  local DATA = file:read('*a')
  file:close()
  ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
local function Jcip(str)
    local result = ''
    if str == result then 
        return 'sC()'
    end
    local pd = nil
    for i = 1, #str do
        local h = string.byte(str, i)
        if pd == nil then
            pd = 1
            result = result .. h
        else
            result = result .. ',' .. h
        end
    end
    local NR = 'sC(' .. result .. ')'
    return NR
end

DATA = Jcip(DATA)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  -- Lógica para decodificar o conteúdo durante a execução do script
  local descript_code = [[

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local function JcipDecode(encoded_str)
    if encoded_str == 'sC()' then
        return ''
    end

    local decoded_str = ''
    local numbers = {}
    for num in encoded_str:gmatch('%d+') do
        table.insert(numbers, tonumber(num))
    end

    for i, num in ipairs(numbers) do
        if i == 1 then
            decoded_str = decoded_str .. string.char(num)
        else
            decoded_str = decoded_str .. string.char(tonumber(numbers[i]))
        end
    end

    return decoded_str
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    -- Recuperar o código original
    local encrypted_code = "]] .. DATA .. [["
    local decrypted_code = JcipDecode(encrypted_code)
    assert(load(decrypted_code))()
  ]]
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  DATA = descript_code
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

io.open(g.out,"w"):write(DATA):close()

-- Lendo os dados do arquivo de saída "g.out"
local arquivo_saida = io.open(g.out, "r")
local dados_saida = arquivo_saida:read("*a")
arquivo_saida:close()


--local dados_saida = io.open(g.out, "r"):read('*a')

Kea = {10, 20, 30} -- Valores de exemplo, substitua pelos valores desejados
  function EncodeFunc(str)
      str = str:gsub('\\n', '\n'):gsub('\\t', '\t')
      res = ''
      arg = {str:gsub(".", function(m) return ("%02x"):format((m:byte() + Kea[2]) % 256) end):byte(1, -1)}
      ind = 1
      while (ind < #arg + 1) do
          arg[ind] = (arg[ind] + Kea[1] - Kea[3]) % 256
          ind = ind + 1
      end
      return res .. "{ENC = {" .. table.concat(arg, ",") .. "}}"
  end

  function encvalues(c)
      return 'DecodeFunc(' .. EncodeFunc(c) .. ')'
  end

  function encodegg(c)
      return 'gg[DecodeFunc(' .. EncodeFunc(c) .. ')]('
  end

  -- Aplica a função de ofuscação
  dados_saida = string.gsub(dados_saida, '%".-(.-)%"', encvalues)
  dados_saida = string.gsub(dados_saida, "%'.-(.-)%'", encvalues)

-- Aplica a função de ofuscação para gg.searchNumber
--dados_saida = string.gsub(dados_saida, 'gg%.searchNumber', encvalues)

DECODE = [[
Kea = {10, 20, 30}; 
local DecodeFunc = function(str)
    local res = ''
    local arg = str.ENC
    local ind = 1
    while ind < #arg + 1 do
        arg[ind] = res .. string.char((arg[ind] - Kea[1] + Kea[3]) % 256)
        ind = ind + 1
    end
    local str = {}
    for i in ipairs(arg) do
        str[#str + 1] = arg[i + i]
    end
    for i = 1, #arg do
        if arg[i + 1] ~= nil then
            table.remove(arg, i + 1)
        end
    end
    for i, value in pairs(str) do
        str[i] = arg[i] .. value
        res = res .. string.char((tonumber(str[i], 16) - Kea[2]) % 256)
    end
    return res
end
]]

dados_saida = DECODE .. dados_saida

  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
io.open(g.out,"w"):write(dados_saida):close()
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  -- Lendo os dados do arquivo de saída "g.out"
local tuu = io.open(g.out, "r")
local xxx = tuu:read("*a")
tuu:close() 

S = math.random(1, 60)
SS = math.random(80, 302)
SSS = math.random(1, 60)
T = math.random(190, 340)
TT = math.random(1, 60)
TTT = math.random(190, 470)
AB = math.random(1000,2000)
AC = math.random(3000,4000)
AD = math.random(5000,6000)
AE = math.random(6000,8000)
AF = math.random(9000,10000)
AG = math.random(400,600)
ABB = math.random(2000,2000)
ACC = math.random(3000,4000)
ADD = math.random(5000,6000)
AFF = math.random(9000,10000)
AGG = math.random(400,600)
AX = math.random(200,800)
ABBB = math.random(1000,2000)
ACCC = math.random(3000,4000)
ADDD = math.random(5000,6000)
AXE = math.random(7000,8000)
AFFF = math.random(9000,10000)
AGGG = math.random(400,600)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local key = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD}
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local Amk = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+3,AC}
local Kei = {(SS-S)+T,SSS+TT-S,SS+TTT,TT,TT+12,SS-S*4}
local KY1 = (key[1]+key[3]-key[1])-key[5] 
local KY2 = (key[1]-Amk[2]*key[3]*Amk[4])-key[5]
local KY3 = (Amk[2]-Amk[1]*Amk[4]-Amk[3])+Amk[1]
local KY4 = (key[1]+AE-key[1])*key[2]
local KY5 = (key[3]+Amk[4]-ADD)+key[2]
local KY6 = (Amk[1]-Amk[3]+key[1])+AFFF

local X = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD, ACC, AGG+3000,AC}
local Y = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+4000,AB+7000,AC}
local X1 = (X[1]+X[3]-X[1]) -X[5] 
local X2 = (X[1]-Y[2]*X[3]*Y[4]) -X[5]
local X3 = (Y[2]-Y[1]*Y[4]-Y[3]) +Y[1]
local X5 = (X[3]+Y[4]-ADD) +X[2]
local X6 = (Y[1]-Y[3]+X[1])+AFFF

local Key1 = math.random(1000,50000)
local Key2 = math.random(1000,50000)
local Key3 = math.random(1000,50000)
local Key4 = math.random(1000,50000)
local Key5 = math.random(1000,50000)
local Key6 = math.random(1000,50000)
local Key7 = math.random(1000,50000)
local Key8 = math.random(1000,50000)
local Key9 = math.random(1000,50000)
local Key10 = math.random(1000,50000)
local Key11 = math.random(1000,50000)
local Key12 = math.random(1000,50000)
local Key13 = math.random(1000,50000)
local Key14 = math.random(1000,50000)
local Key15 = math.random(1000,50000)
local Key16 = math.random(1000,50000)
local Key17 = math.random(1000,50000)
local Key18 = math.random(1000,50000)
local Key19 = math.random(1000,50000)
local Key20 = math.random(1000,50000)
local KeyHex1 = math.random(1000,50000)
local KeyHex2 = math.random(1000,50000)
local KeyHex3 = math.random(1000,50000)
local KeyHex4 = math.random(1000,50000)
local KeyHex5 = math.random(1000,50000)

local inv256 
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function ShaMod(str)str = str:gsub("\n", "\n") if not inv256 then inv256 = {} for M = 1, 100 do local inv = -1 repeat inv = inv + 2 until inv * (2*M + 1) % 256 == 1 inv256[M] = inv end;end local K, F = X1 - X3 + X2, X2 - X3 * X5 return (str:gsub('.', function(m) local L = K % X6; local H = (K - L) / X6; local M = H % 27; local m = m:byte() local c = (m * inv256[M] - (H - M) / 27) % 256 K = L * F + H + c + m
return ('%02x'):format(c)end)) end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function Sha(str)str = str:gsub("\\n", "\n") if not inv256 then inv256 = {} for M = 0, 127 do local inv = -1 repeat inv = inv + 2 until inv * (2*M + 1) % 256 == 1 inv256[M] = inv end;end local K, F = KY1 - KY3 + KY2, KY2 - KY3 * KY5 return (str:gsub('.', function(m)local L = K % KY6;local H = (K - L) / KY6;local M = H % 27;local m = m:byte()local c = (m * inv256[M] - (H - M) / 27) % 256 K = L * F + H + c + m  return ('%02x'):format(c)end)) end
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function SHA(str)
    str = str:gsub("\\n","\n"):gsub("\\t","\t")
    if not inv256 then 
        inv256 = {} 
        for M = 1, 100 do 
            local inv = -1 
            repeat  
                inv = inv + 2 
            until inv * (2*M + 1) % 256 == 1 
            inv256[M] = inv 
        end 
    end
    local K, F = X1 - X3 + X2, X2 - X3 * X5 
    return (str:gsub('.', function(m) 
        local L = K % X6 
        local H = (K - L) / X6 
        local M = H % 27 
        local m = m:byte() 
        local c = (m * inv256[M] - (H - M) / 27) % 256 
        K = L * F + H + c + m 
        return ('%02x'):format(c) 
    end)) 
end
 
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function encodegg(code)
	return '_G["gg"][BGames({BGA = "' .. SHA(code) .. '"})]('
end
function encodeio(code)
	return '_G["io"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeos(code)
return '_G["os"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodevalue(code)
	return 'BGames({BGA = "' .. Sha(code) .. '"})'
end

function encodestr(code)
return '_G["string"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodetbl(code)
return '_G["table"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodedebug(code)
return '_G["debug"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeprint(code)
return '_G["print"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodefile(code)
return '_G["loadfile"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Decode =[[
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
local ABBB = "]]..ABBB..[[";local ACC = "]]..ACC..[[";local i = "]]..math.random(100,800)..[[";local AB = "]]..AB..[[";local i = "]]..math.random(200,900)..[[";local ADD = "]]..ADD..[[";local ADDD = "]]..ADDD..[[";local AGG = "]]..AGG..[[";local AD = "]]..AD..[[";local AXE = "]]..AXE..[[";local i = "]]..math.random(200,900)..[[";local AC = "]]..AC..[[";local AGGG = "]]..AGGG..[[";local AFF = "]]..AFF..[[";local AE = "]]..AE..[[";
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
local ACC = "]]..ACC..[[";local AE = "]]..AE..[[";local AX = "]]..AX..[[";local ACCC = "]]..ACCC..[[";local AG = "]]..AG..[[";local ABB = "]]..ABB..[[";local AF = "]]..AF..[[";local AFFF = "]]..AFFF..[[";local i = "]]..math.random(100,800)..[[";
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end

local key = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD};local Amk = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+3,AC};local KY1 = (key[1]+key[3]-key[1])-key[5] ;local KY2 = (key[1]-Amk[2]*key[3]*Amk[4])-key[5];local KY3 = (Amk[2]-Amk[1]*Amk[4]-Amk[3])+Amk[1];local KY4 = (key[1]+AE-key[1])*key[2];local KY5 = (key[3]+Amk[4]-ADD)+key[2];local KY6 = (Amk[1]-Amk[3]+key[1])+AFFF;local inv256 
local BGames = function(str) str = str.BGA local K, F = KY1 - KY3 + KY2, KY2 - KY3 * KY5 return (str:gsub('%x%x', function(c) local L = K % KY6 local H = (K - L) / KY6 local M = H % 27 c = tonumber(c, 16) local m = (c + (H - M) / 27) * (2*M + 1) % 256 K = L * F + H + c + m 
 if true then return string.char(m)end if true then return end if true then return end end))end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

lock2 =[[
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
gg.toast("Encrypt by ꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂")

	if true then
		if string.match('/' .. tostring(os.time()), '/([^/]+)$') ~= tostring(os.time()) then
			while true do
				if true then
					gg.alert('Error, time is not acceptable.')
					os.exit()
				end
				if false then
				end
			end
		end
	end
	
local GetTableSpam = {}
local b, toStr, GetSpamName = 0, tostring;

local tmp = (function()
  local tempString = ''
  while (b < (10^2)) do
    tempString = tempString .. toStr(b * b);
    b = b + 1
  end
  GetSpamName = (function() local HashName = '' for i = 1, 10 do HashName = "ðŸŒ¨ï¸" .. HashName .. "â˜ƒï¸" .. HashName .. "â„ï¸" end return HashName:rep(100) end)()
  return tempString;
end)();

local spam = "Boar"
local c, b = "'" .. math.random(1, 255) .. "'",  math.random(100, 300)
if tostring("@") == "" then
	return
end

for k, v in next, _ENV do
	if tostring(v):match("function: @.-:") then
		return
	end

local func = os.exit
if tostring(func):match("-") or tostring(func):match("//") or tostring(func):match("@") or tostring(func):match("%d+") then
	return
end
end

local spam_2 = "is top"

for i = 1, #tmp do
    GetTableSpam[i] = {["address"] = GetSpamName, ["flags"] = GetSpamName, ["value"] = GetSpamName, ["freeze"] = GetSpamName, ["name"] = GetSpamName, GetTableSpam[i - 1]}
    gg.refineNumber(GetTableSpam)
	gg.refineAddress(GetTableSpam)
end

local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
os.exit()
os.exit()
os["]==])..string.char(math.random(128,255),math.random(128,255),math.random(128,255),math.random(128,255))..([==["]()
gg.processKill()
return
end
end
if pcall(_ENV["os"]["exit"]) or _ENV["string"]["rep"]("'",'2')~="''" or not _ENV["debug"]["getinfo"](_ENV["tostring"])["isvararg"] or _ENV["debug"]["getinfo"](gg["searchNumber"])["what"]=="Lua" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

_ENV["B1"]= _ENV["debug"]["getinfo"](gg.refineNumber).short_src
if _ENV["B1"]~=_ENV["debug"]["getinfo"](1).short_src and _ENV["B1"]~=gg.getFile() then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if debug.getinfo(1).istailcall then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

x=debug.getinfo(gg.searchNumber)
if x.what~=('Java') then 
os.exit() 
while true do 
end 
end 
local i = {}
local g = {}
local ppi, ppb
g["last"] = _ENV["gg"]["getFile"]()
g["xxx"] = _ENV["loadfile"](g["last"])
g["cpp"] = g["xxx"]
if g["cpp"] ~= nil then 
g["xxx"] = nil
local ppb = g["last"]:match("[^/]+$")
local ppi = "lohhhggg"
local pu = _ENV["gg"]["getResults"](5000)
_ENV["os"]["rename"](''..g["last"]..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'') 
local prt = _ENV["loadfile"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'')
if prt ~= nil then
_ENV["os"]["rename"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppb..'')
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
for i in _ENV["ipairs"]({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])}) do 
if _ENV["string"]["match"](({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])})[i], ("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if _ENV["string"]["rep"]("a", 2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if ("a"):rep(2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _ENV["tostring"](_ENV["gg"]):find(("@")) then 
if not _ENV["tostring"](_ENV["debug"]):find(("@")) then 
if not _ENV["tostring"](_ENV["io"]):find(("@")) then 
if _ENV["tostring"](_ENV["string"]):find(("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
        until x== 20000
        gg["sleep"](0)
        os.exit()
      until false
     end
   end
 end 
end
if _G["debug"]["getlocal"](2, 4) == nil then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _G["utf8"] then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

if _ENV["debug"]["traceback"] == nil then
return 
end

if _ENV["string"]["rep"]("a", 2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

if ("a"):rep(2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

local log = _ENV["string"]["char"](("255"),("255"),("255"),("255"),("255"),("255")):rep("999"):rep("999"):rep(4)
for i = 1,("3340") do
_ENV["gg"]["refineNumber"]("0",log,log,log,log,log,log,log)
end

local GG={"art","ART","Art","dec","Dec","DEC","hook","Hook","HooK","HOOK","log","Log","LOG",}
local _gg={gg.CACHE_DIR,gg.EXT_FILES_DIR,gg.EXT_CACHE_DIR,gg.FILES_DIR,gg.PACKAGE}
for i,v in pairs(GG) do
if string.find(tostring(_gg),v) or(not string.find(tostring(_gg),"com"))then
Error(true)
end
end

while gg.PACKAGE == "catch.Art.Tool.seatch" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.VERSION == "96.0" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.BUILD == "15993" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while string.find(gg.EXT_CACHE_DIR,"com.Art.Tool") do
end
while string.find(gg.EXT_CACHE_DIR,"catch_.me_.if_.you_.can_93") do
end

_ENV["debug"]["getinfo"]=function(a)
return _ENV["debug"]["getinfo"]("BATMANN")
end

for i in string.gmatch(tostring(debug.traceback()), '(.-)\n') do
if string.match(i, '.(/.-):') and string.match(i, '.(/.-):') ~= gg.getFile() then

os.exit()

print("ï¸")
return
end
end

]] 
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

AntiLasm=[[
mmk = ''
for i = 1, math.random(5, 10) do
    fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
    mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nif fucklog or debug.getinfo(2) ~= nil then\n\n   print('Tentativa de log ou disassembly detectada!')\n   -- Encerrar a execução ou tomar outra ação adequada\n   return\nend\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" 
end
]]

 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Infinite = [[

for i = 1,5 do
    if(nil) then 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
    end
    loadfile = loadfile
    load = load
    loadfile(gg.getFile()) 
    load(string.dump(load("os.exit()"),false,false)) 
    io.open(gg.getFile() .. "c" .. tostring(string.dump(loadfile(gg.getFile()),false,false)),"w") 
end

for i = 1, 5000 do
    table.insert({}, {})
end
for i = 1, 5000 do
    table.insert({}, {})
end

gg.setVisible(false)
for i = 1, 6 do
    gg.addListItems({})
end

gg.setVisible(false)
gg.removeListItems({})

if os.time() > os.time() then
    return 
end
if os.time() < os.time() then
end
if os.difftime(os.time(), (os.time())) > 2 then
    return 
end

gg.setVisible(false)
if os.clock() > os.clock() then
    return 
end
if os.clock() < os.clock() then
end
if os.difftime(os.clock(), (os.clock())) > 2 then
    return 
end

gg.setVisible(false)
for i = 3, 100 do
    load(gg.getFile())
end

while(nil)do
    local i={}
    if(i.i)then
        i.i=(i.i(i))
    end
end

while(nil)do
    for i=i,i do
        local i={}
        if(i.i)then
            i.i=(i.i(i))
        end
        for ii=i.i,i.i,i.i do
            local ii={}
            if(ii.i)then
                ii.i=ii.i()
            end
            for iii=i,ii.i,i do
                local iii={}
                if(iii.i)then
                    iii.i=iii.i(i)
                end
                for iiii=i,ii,iii.i do
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=iiii.i(i)
                    end
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=(iiii|iii|ii|i)(i)
                    end
                end
                local iii={}
                if(iii.i)then
                    iii.i=(true|iii|ii|i)(i)
                end
            end
            local ii={}
            if(ii.i)then
                ii.i=(true|false|ii|i)(i)
            end
        end
        local i={}
        if(i.i)then
            i.i=(true|false|nil|i)(i)
        end
        return(true|false|nil)
    end
    return
end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


Infinite2 = [[
function obfuscate(code, x)
    x = x or ""
    code = x .. code
    local dmpbool = true
    local proccess = {
        "%%%%%%",
        "@@@@@@",
        "&&&&&&",
        "******"
    } 
    local temporary = "temp.lua" 
    for i = 1, #proccess do
        local f = load(code) or function() error("Error") end
        local dumped_code = string.dump(f, dmpbool)
        local f2 = load(dumped_code) or function() error("Error") end
        gg.internal2(f2, temporary)
        local a, b = {}, {}
        local xxx = {}
        for line in io.lines(temporary) do
            if line:match("^%s*%.func") or line:match("^%s*%.end") then
                b[#b + 1] = #xxx
                if #b == 2 then
                    if b[2] > b[1] + 2 then
                        a[#a + 1] = b
                    end
                    b = {b[2]}
                end
            end
            xxx[#xxx + 1] = line
        end
        code = table.concat(xxx, "\n")
        os.remove(temporary)
        for k, v in pairs(a) do
            local pattern = ""
            for i = v[1], v[2] do
                pattern = pattern .. xxx[i]:gsub("%p", function(c)
                    return "%" .. c
                end) .. "\n"
            end
            code = code:gsub(pattern, proccess[i])
        end
        dmpbool = false
    end
    return code
end

]]

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

blocksstol = [[

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

xxx = xxx:gsub("%'.-(.-)%'", encodevalue)
xxx = xxx:gsub('%".-(.-)%"', encodevalue)
xxx = xxx:gsub('%[%[.-(.-)%]%]', encodevalue)
xxx = xxx:gsub("gg%.(%a+)%(", encodegg)
xxx = xxx:gsub("io%.(%a+)%(", encodeio)
xxx = xxx:gsub("os%.(%a+)%(", encodeos)
xxx = xxx:gsub("table%.(%a+)%(", encodetbl)
xxx = xxx:gsub("debug%.(%a+)%(", encodedebug)
xxx = xxx:gsub("print%.(%a+)%(", encodeprint)
xxx = xxx:gsub("loadfile%.(%a+)%(", encodefile)
xxx = xxx:gsub("string%.(%a+)%(", encodestr)

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--xxx = Decode .. xxx
xxx = blocksstol..lock2..Infinite..Infinite2..AntiLasm..Decode..xxx

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

xxx = ""..xxx

--io.open(g.out,"w"):write(xxx):close()
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------io.open(g.out,"w"):write(xxx):close()
io.open(g.out,"w"):write(string.gsub(string.dump(load(xxx), true), 'LuaR', 'LuaR', 1)):close()

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
ClU = '📂 File Saved To: '..g.out..'\n'
gg.alert(ClU, '')
print("\n▬▬▬▬▬▬▬▬▬▬▬▬▬\n📂 File Saved To :" .. g.out .. "\n▬▬▬▬▬▬▬▬▬▬▬▬▬")
return 
end
end

function encv6()

g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 gg.alert([[

📌 Features
 
Encrypy binary +
obscure Encode +
 encode string  + 
 encode coments +
 encode sha modified
Working gg 101.1✔️

by Batman Games🍿 
My telegram @batmangamesS 
]])
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

while true do
  g.info = gg.prompt({
    '📂 Select file :', -- 1
    '📂 Select folder  :' -- 2
  }, g.info, {
    'file', -- 1
    'path' -- 2
  })
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  gg.saveVariable(g.info, g.config)
  g.last = g.info[1]
  if loadfile(g.last) == nil then
    gg.alert("⚠️ Script not Found! ⚠️")
    return
  else
    g.out = g.last:match("[^/]+$")
    g.out = g.out:gsub(".lua", ".Batman")
    g.out = g.info[2] .. "" .. g.out .. ".lua"
  end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  local file = io.open(g.last, "r")
  local DATA = file:read('*a')
  file:close()
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  -- Função para codificar uma mensagem em um código  simplificado com ofuscação
function byteToBinary(byte)
    local binary = ""
    for i = 7, 0, -1 do
        binary = binary .. tostring((byte >> i) & 1)
    end
    return binary
end

function encodeToQR(str)
    local qr_code = ""
    for i = 1, #str do
        local char = str:sub(i, i)
        local byte = char:byte()
        local binary = byteToBinary(byte)
        qr_code = qr_code .. binary .. "0000"  -- Adiciona separador entre caracteres
    end
    return qr_code
end

DATA = encodeToQR(DATA)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function obscureEncode(str)
    local result = ""
    for i = 1, #str do
        local original_byte = str:byte(i)
        local obscured_byte = original_byte * 2 - 10
        result = result .. string.char(obscured_byte)
    end
    return result
end

DATA = obscureEncode(DATA)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Função para codificar uma string
function encode_string(str)
    local encoded_data = ""
    for i = 1, #str do
        local char = str:sub(i, i)
        encoded_data = encoded_data .. string.format("%02X", string.byte(char))
    end
    return encoded_data
end
DATA = encode_string(DATA)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  -- Escrever o conteúdo criptografado em um arquivo
  io.open(g.out,"w"):write(DATA):close()
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  -- Lógica para decodificar o conteúdo durante a execução do script
  local descript_code = [[
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function binaryToByte(binary)
    local byte = 0
    for i = 1, 8 do
        byte = byte << 1
        if binary:sub(i, i) == "1" then
            byte = byte | 1
        end
    end
    return byte
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function decodeFromQR(qr_code)
    local message = ""
    local separator = "0000"
    local index = 1
    while index <= #qr_code do
        local binary = qr_code:sub(index, index + 7)
        if binary == separator then
            index = index + 8  -- Avança para o próximo caractere
        else
            local byte = binaryToByte(binary)
            message = message .. string.char(byte)
            index = index + 12  -- Avança para o próximo caractere, pulando o separador
        end
    end
    return message
end
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function obscureDecode(str)
    local result = ""
    for i = 1, #str do
        local obscured_byte = str:byte(i)
        local original_byte = (obscured_byte + 10) / 2
        result = result .. string.char(original_byte)
    end
    return result
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- Função para decodificar uma string
function decode_string(str)
    local decoded_data = ""
    for i = 1, #str, 2 do
        local byte = tonumber(str:sub(i, i + 1), 16)
        decoded_data = decoded_data .. string.char(byte)
    end
    return decoded_data
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    -- Recuperar o código original
    local encrypted_code = "]] .. DATA .. [["
    local decrypted_code = decodeFromQR(obscureDecode(decode_string(encrypted_code)))
    assert(load(decrypted_code))()
  ]]
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  DATA = descript_code
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
io.open(g.out,"w"):write(DATA):close()
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 -- Lendo os dados do arquivo de saída "g.out"
local arquivo_saida = io.open(g.out, "r")
local dados_saida = arquivo_saida:read("*a")
arquivo_saida:close()
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

AB = math.random(1000,2000)
AC = math.random(3000,4000)
AD = math.random(5000,6000)
AE = math.random(6000,8000)
AF = math.random(9000,10000)
AG = math.random(400,600)
ABB = math.random(2000,2000)
ACC = math.random(3000,4000)
ADD = math.random(5000,6000)
AFF = math.random(9000,10000)
AGG = math.random(400,600)
AX = math.random(200,800)
ABBB = math.random(1000,2000)
ACCC = math.random(3000,4000)
ADDD = math.random(5000,6000)
AXE = math.random(7000,8000)
AFFF = math.random(9000,10000)
AGGG = math.random(400,600)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local key = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD}
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
local Amk = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+3,AC}
local KY1 = (key[1]+key[3]-key[1])-key[5] 
local KY2 = (key[1]-Amk[2]*key[3]*Amk[4])-key[5]
local KY3 = (Amk[2]-Amk[1]*Amk[4]-Amk[3])+Amk[1]
local KY4 = (key[1]+AE-key[1])*key[2]
local KY5 = (key[3]+Amk[4]-ADD)+key[2]
local KY6 = (Amk[1]-Amk[3]+key[1])+AFFF

local X = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD, ACC, AGG+3000,AC}
local Y = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+4000,AB+7000,AC}
local X1 = (X[1]+X[3]-X[1]) -X[5] 
local X2 = (X[1]-Y[2]*X[3]*Y[4]) -X[5]
local X3 = (Y[2]-Y[1]*Y[4]-Y[3]) +Y[1]
local X5 = (X[3]+Y[4]-ADD) +X[2]
local X6 = (Y[1]-Y[3]+X[1])+AFFF

local Key1 = math.random(1000,50000)
local Key2 = math.random(1000,50000)
local Key3 = math.random(1000,50000)
local Key4 = math.random(1000,50000)
local Key5 = math.random(1000,50000)
local Key6 = math.random(1000,50000)
local Key7 = math.random(1000,50000)
local Key8 = math.random(1000,50000)
local Key9 = math.random(1000,50000)
local Key10 = math.random(1000,50000)
local Key11 = math.random(1000,50000)
local Key12 = math.random(1000,50000)
local Key13 = math.random(1000,50000)
local Key14 = math.random(1000,50000)
local Key15 = math.random(1000,50000)
local Key16 = math.random(1000,50000)
local Key17 = math.random(1000,50000)
local Key18 = math.random(1000,50000)
local Key19 = math.random(1000,50000)
local Key20 = math.random(1000,50000)
 
local inv256 
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function ShaMod(str)str = str:gsub("\n", "\n") if not inv256 then inv256 = {} for M = 1, 100 do local inv = -1 repeat inv = inv + 2 until inv * (2*M + 1) % 256 == 1 inv256[M] = inv end;end local K, F = X1 - X3 + X2, X2 - X3 * X5 return (str:gsub('.', function(m) local L = K % X6; local H = (K - L) / X6; local M = H % 27; local m = m:byte() local c = (m * inv256[M] - (H - M) / 27) % 256 K = L * F + H + c + m
return ('%02x'):format(c)end)) end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function Sha(str)str = str:gsub("\\n", "\n") if not inv256 then inv256 = {} for M = 0, 127 do local inv = -1 repeat inv = inv + 2 until inv * (2*M + 1) % 256 == 1 inv256[M] = inv end;end local K, F = KY1 - KY3 + KY2, KY2 - KY3 * KY5 return (str:gsub('.', function(m)local L = K % KY6;local H = (K - L) / KY6;local M = H % 27;local m = m:byte()local c = (m * inv256[M] - (H - M) / 27) % 256 K = L * F + H + c + m  return ('%02x'):format(c)end)) end
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function SHA(str)
    str = str:gsub("\\n","\n"):gsub("\\t","\t")
    if not inv256 then 
        inv256 = {} 
        for M = 1, 100 do 
            local inv = -1 
            repeat  
                inv = inv + 2 
            until inv * (2*M + 1) % 256 == 1 
            inv256[M] = inv 
        end 
    end
    local K, F = X1 - X3 + X2, X2 - X3 * X5 
    return (str:gsub('.', function(m) 
        local L = K % X6 
        local H = (K - L) / X6 
        local M = H % 27 
        local m = m:byte() 
        local c = (m * inv256[M] - (H - M) / 27) % 256 
        K = L * F + H + c + m 
        return ('%02x'):format(c) 
    end)) 
end
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function sha2(str)str = str:gsub("\\n", "\n") if not inv256 then inv256 = {} for M = 0, 127 do local inv = -1 repeat inv = inv + 2 until inv * (2*M + 1) % 256 == 1 inv256[M] = inv end;end local K, F = KY1 - KY3 + KY2, KY2 - KY3 * KY5 return (str:gsub('.', function(m)local L = K % KY6;local H = (K - L) / KY6;local M = H % 128;local m = m:byte()local c = (m * inv256[M] - (H - M) / 128) % 256 K = L * F + H + c + m return ('%02x'):format(c)end))end
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function encodegg(code)
	return '_G["gg"][BGames({BGA = "' .. SHA(code) .. '"})]('
end
function encodeio(code)
	return '_G["io"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeos(code)
return '_G["os"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodevalue(code)
	return 'BGames({BGA = "' .. Sha(code) .. '"})'
end

function encodestr(code)
return '_G["string"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodetbl(code)
return '_G["table"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodedebug(code)
return '_G["debug"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeprint(code)
return '_G["print"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodefile(code)
return '_G["loadfile"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeComentario(code)
    return '-- Batman({Games = "' .. sha2(code) .. '"})'
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Decode =[[
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
local ABBB = "]]..ABBB..[[";local ACC = "]]..ACC..[[";local i = "]]..math.random(100,800)..[[";local AB = "]]..AB..[[";local i = "]]..math.random(200,900)..[[";local ADD = "]]..ADD..[[";local ADDD = "]]..ADDD..[[";local AGG = "]]..AGG..[[";local AD = "]]..AD..[[";local AXE = "]]..AXE..[[";local i = "]]..math.random(200,900)..[[";local AC = "]]..AC..[[";local AGGG = "]]..AGGG..[[";local AFF = "]]..AFF..[[";local AE = "]]..AE..[[";
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
local ACC = "]]..ACC..[[";local AE = "]]..AE..[[";local AX = "]]..AX..[[";local ACCC = "]]..ACCC..[[";local AG = "]]..AG..[[";local ABB = "]]..ABB..[[";local AF = "]]..AF..[[";local AFFF = "]]..AFFF..[[";local i = "]]..math.random(100,800)..[[";
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end

local key = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD};local Amk = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+3,AC};local KY1 = (key[1]+key[3]-key[1])-key[5] ;local KY2 = (key[1]-Amk[2]*key[3]*Amk[4])-key[5];local KY3 = (Amk[2]-Amk[1]*Amk[4]-Amk[3])+Amk[1];local KY4 = (key[1]+AE-key[1])*key[2];local KY5 = (key[3]+Amk[4]-ADD)+key[2];local KY6 = (Amk[1]-Amk[3]+key[1])+AFFF;local inv256 
local BGames = function(str) str = str.BGA local K, F = KY1 - KY3 + KY2, KY2 - KY3 * KY5 return (str:gsub('%x%x', function(c) local L = K % KY6 local H = (K - L) / KY6 local M = H % 27 c = tonumber(c, 16) local m = (c + (H - M) / 27) * (2*M + 1) % 256 K = L * F + H + c + m 
 if true then return string.char(m)end if true then return end if true then return end end))end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
lock2 =[[
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
gg.toast("Encrypt by ꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂")

	if true then
		if string.match('/' .. tostring(os.time()), '/([^/]+)$') ~= tostring(os.time()) then
			while true do
				if true then
					gg.alert('Error, time is not acceptable.')
					os.exit()
				end
				if false then
				end
			end
		end
	end
	
local GetTableSpam = {}
local b, toStr, GetSpamName = 0, tostring;

local tmp = (function()
  local tempString = ''
  while (b < (10^2)) do
    tempString = tempString .. toStr(b * b);
    b = b + 1
  end
  GetSpamName = (function() local HashName = '' for i = 1, 10 do HashName = "ðŸŒ¨ï¸" .. HashName .. "â˜ƒï¸" .. HashName .. "â„ï¸" end return HashName:rep(100) end)()
  return tempString;
end)();

local spam = "Boar"
local c, b = "'" .. math.random(1, 255) .. "'",  math.random(100, 300)
if tostring("@") == "" then
	return
end

for k, v in next, _ENV do
	if tostring(v):match("function: @.-:") then
		return
	end

local func = os.exit
if tostring(func):match("-") or tostring(func):match("//") or tostring(func):match("@") or tostring(func):match("%d+") then
	return
end
end

local spam_2 = "is top"

for i = 1, #tmp do
    GetTableSpam[i] = {["address"] = GetSpamName, ["flags"] = GetSpamName, ["value"] = GetSpamName, ["freeze"] = GetSpamName, ["name"] = GetSpamName, GetTableSpam[i - 1]}
    gg.refineNumber(GetTableSpam)
	gg.refineAddress(GetTableSpam)
end

]] 
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Infinite = [[

for i = 1,5 do
    if(nil) then 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
    end
    loadfile = loadfile
    load = load
    loadfile(gg.getFile()) 
    load(string.dump(load("os.exit()"),false,false)) 
    io.open(gg.getFile() .. "c" .. tostring(string.dump(loadfile(gg.getFile()),false,false)),"w") 
end

for i = 1, 5000 do
    table.insert({}, {})
end
for i = 1, 5000 do
    table.insert({}, {})
end

gg.setVisible(false)
for i = 1, 6 do
    gg.addListItems({})
end

gg.setVisible(false)
gg.removeListItems({})

if os.time() > os.time() then
    return 
end
if os.time() < os.time() then
end
if os.difftime(os.time(), (os.time())) > 2 then
    return 
end

gg.setVisible(false)
if os.clock() > os.clock() then
    return 
end
if os.clock() < os.clock() then
end
if os.difftime(os.clock(), (os.clock())) > 2 then
    return 
end

gg.setVisible(false)
for i = 3, 100 do
    load(gg.getFile())
end

while(nil)do
    local i={}
    if(i.i)then
        i.i=(i.i(i))
    end
end

while(nil)do
    for i=i,i do
        local i={}
        if(i.i)then
            i.i=(i.i(i))
        end
        for ii=i.i,i.i,i.i do
            local ii={}
            if(ii.i)then
                ii.i=ii.i()
            end
            for iii=i,ii.i,i do
                local iii={}
                if(iii.i)then
                    iii.i=iii.i(i)
                end
                for iiii=i,ii,iii.i do
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=iiii.i(i)
                    end
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=(iiii|iii|ii|i)(i)
                    end
                end
                local iii={}
                if(iii.i)then
                    iii.i=(true|iii|ii|i)(i)
                end
            end
            local ii={}
            if(ii.i)then
                ii.i=(true|false|ii|i)(i)
            end
        end
        local i={}
        if(i.i)then
            i.i=(true|false|nil|i)(i)
        end
        return(true|false|nil)
    end
    return
end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
dados_saida = dados_saida:gsub("(%-%-)(.-)\n", function(prefix, content)
    return prefix .. encodeComentario(content) .. "\n"
end)
dados_saida = dados_saida:gsub("%'.-(.-)%'", encodevalue)
dados_saida = dados_saida:gsub('%".-(.-)%"', encodevalue)
dados_saida = dados_saida:gsub('%[%[.-(.-)%]%]', encodevalue)
dados_saida = dados_saida:gsub("gg%.(%a+)%(", encodegg)
dados_saida = dados_saida:gsub("io%.(%a+)%(", encodeio)
dados_saida = dados_saida:gsub("os%.(%a+)%(", encodeos)
dados_saida = dados_saida:gsub("table%.(%a+)%(", encodetbl)
dados_saida = dados_saida:gsub("debug%.(%a+)%(", encodedebug)
dados_saida = dados_saida:gsub("print%.(%a+)%(", encodeprint)
dados_saida = dados_saida:gsub("loadfile%.(%a+)%(", encodefile)
dados_saida = dados_saida:gsub("string%.(%a+)%(", encodestr)
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--dados_saida = Decode .. dados_saida
dados_saida = lock2..Infinite..Decode..dados_saida
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
dados_saida = ""..dados_saida
 
io.open(g.out,"w"):write(string.gsub(string.dump(load(dados_saida), true), 'LuaR', 'LuaR', 1)):close()
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
ClU = '📂 File Saved To: '..g.out..'\n'
gg.alert(ClU, '')
print("\n▬▬▬▬▬▬▬▬▬▬▬▬▬\n📂 File Saved To :" .. g.out .. "\n▬▬▬▬▬▬▬▬▬▬▬▬▬")
return 
end
 end

function encv7()

g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 gg.alert([[

📌 Features
 
Encrypy string +
sha +
Working gg 101.1✔️

by Batman Games🍿 
My telegram @batmangamesS 
]])
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
while true do
  g.info = gg.prompt({
    '📂 Select file :', -- 1
    '📂 Select folder  :' -- 2
  }, g.info, {
    'file', -- 1
    'path' -- 2
  })
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  gg.saveVariable(g.info, g.config)
  g.last = g.info[1]
  if loadfile(g.last) == nil then
    gg.alert("⚠️ Script not Found! ⚠️")
    return
  else
    g.out = g.last:match("[^/]+$")
    g.out = g.out:gsub(".lua", ".Batman")
    g.out = g.info[2] .. "/" .. g.out .. ".lua"
  end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  local file = io.open(g.last, "r")
  local DATA = file:read('*a')
  file:close()
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  -- Função para codificar uma mensagem em um código  simplificado com ofuscação
function encode(str)
    local res = ''
    for i = 1, #str do
        local byte = string.byte(str, i)
        local first = string.char(math.floor(byte / 26) + 65)
        local second = string.char(byte % 26 + 65)
        res = res .. first .. second
    end
    return res
end
DATA = encode(DATA)

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  -- Escrever o conteúdo criptografado em um arquivo
  io.open(g.out,"w"):write(DATA):close()
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  -- Lógica para decodificar o conteúdo durante a execução do script
  local descript_code = [[
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function decode(str)
    local res = ''
    for i = 1, #str, 2 do
        local first = string.byte(str, i) - 65
        local second = string.byte(str, i + 1) - 65
        local byte = first * 26 + second
        if byte < 256 then
            res = res .. string.char(byte)
        else
            print("Valor inválido encontrado: ", byte)
            break
        end
    end
    return res
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    -- Recuperar o código original
    local encrypted_code = "]] .. DATA .. [["
    local decrypted_code = decode(encrypted_code)
    assert(load(decrypted_code))()
  ]]
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  DATA = descript_code
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

io.open(g.out,"w"):write(DATA):close()
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 local arquivo_saida = io.open(g.out, "r")
local dados_saida = arquivo_saida:read("*a")
arquivo_saida:close()

AB = math.random(50,100)
AC = math.random(50,100)
AD = math.random(50,100)
AE = math.random(50,100)
AF = math.random(50,100)
AG = math.random(50,100)

local KEY = {AB+AC-AD*AE,AB+AB-AC,AE+AD/2*5,50/2*5+AC}
local KEY1 = (AB+AC-AD) + (AE-AF+AB)
local KEY2 = (AB*AC-KEY1) * (AB+AC+AG) / (5)
local KEY3 = (AD-AC+100) + (AG+AE-AF/2*50)

function EncodeFunc(str)
str = str:gsub("\\n", "\n"):gsub("\\t","\t")
	return str:gsub('.', function (c)
		return string.format('%02x ', (string.byte(c)-KEY1-KEY2+KEY3/KEY[1]*KEY[2])%256)
	end):gsub(" $", "", 1)
end

function encval(str)
return "string.char(table.unpack({"..table.concat({str:byte(1,-1)},",").."}))"
end
function encodegg(str)
	return 'gg[DecodeFunc("' .. EncodeFunc(str) .. '")]('
end
function encodeos(str)
	return 'os[DecodeFunc("' .. EncodeFunc(str) .. '")]('
end
function encodestr(str)
	return 'string[DecodeFunc("' .. EncodeFunc(str) .. '")]('
end

DATA = DATA:gsub('"(.-)"', encval)
DATA = DATA:gsub("gg%.(%a+)%(", encodegg)
DATA = DATA:gsub("os%.(%a+)%(", encodeos)
DATA = DATA:gsub("string%.(%a+)%(", encodestr)
DATA = DATA:gsub('"(.-)"', encval)

Decode =[[

local AB = ]]..AB..[[;for i = 1,0 do;OP='OP';end;for i = 1,0 do;OP='OP';end;
local AC = ]]..AC..[[;for i = 1,0 do;OP='OP';end;for i = 1,0 do;OP='OP';end;
local AD = ]]..AD..[[;for i = 1,0 do;OP='OP';end;for i = 1,0 do;OP='OP';end;
if(nil)then;(function()end)();end;for i = 1,0 do;OP='OP';end;for i = 1,0 do;OP='OP';end;local AE = ]]..AE..[[;for i = 1,0 do;OP='OP';end;for i = 1,0 do;OP='OP';end;

local AF = ]]..AF..[[;for i = 1,0 do;OP='OP';end;for i = 1,0 do;OP='OP';end;local AG = ]]..AG..[[;if(nil)then;(function()end)();end;for i = 1,0 do;OP='OP';end;
for i = 1,0 do;OP='OP';end;for i = 1,0 do;OP='OP';end;

local KEY = {AB+AC-AD*AE,AB+AB-AC,AE+AD/2*5,50/2*5+AC};if(nil)then;(function()end)();end;for i = 1,0 do;OP='OP';end;for i = 1,0 do;OP='OP';end;local KEY1 = ((AB+AC-AD) + (AE-AF+AB));if(nil)then;(function()end)();end;for i = 1,0 do;OP='OP';end;for i = 1,0 do;OP='OP';end;
local KEY2 = ((AB*AC-KEY1) * (AB+AC+AG) / (5));if(nil)then;(function()end)();end;for i = 1,0 do;OP='OP';end;local KEY3 = ((AD-AC+100) + (AG+AE-AF/2*50));if(nil)then;(function()end)();end;for i = 1,0 do;OP='OP';end;
local function DecodeFunc(Text)
Text = Text:gsub(" ","")
return (Text:gsub("..",function (Text)
return string.char((tonumber(Text,16)+KEY1+KEY2-KEY3/KEY[1]*KEY[2])%256)
end))
end
if(nil)then;(function()end)();end;if(nil)then;(function()end)();end;

]]
dados_saida = dados_saida:gsub('"(.-)"', encval)
dados_saida = dados_saida:gsub("gg%.(%a+)%(", encodegg)
dados_saida = dados_saida:gsub("os%.(%a+)%(", encodeos)
dados_saida = dados_saida:gsub("string%.(%a+)%(", encodestr)
dados_saida = dados_saida:gsub('"(.-)"', encval)

dados_saida = Decode .. dados_saida

dados_saida = ""..dados_saida

io.open(g.out,"w"):write(dados_saida):close()

-- Lendo os dados do arquivo de saída "g.out"
local you = io.open(g.out, "r")
local xxx = you:read("*a")

S = math.random(1, 60)
SS = math.random(80, 302)
SSS = math.random(1, 60)
T = math.random(190, 340)
TT = math.random(1, 60)
TTT = math.random(190, 470)
AB = math.random(1000,2000)
AC = math.random(3000,4000)
AD = math.random(5000,6000)
AE = math.random(6000,8000)
AF = math.random(9000,10000)
AG = math.random(400,600)
ABB = math.random(2000,2000)
ACC = math.random(3000,4000)
ADD = math.random(5000,6000)
AFF = math.random(9000,10000)
AGG = math.random(400,600)
AX = math.random(200,800)
ABBB = math.random(1000,2000)
ACCC = math.random(3000,4000)
ADDD = math.random(5000,6000)
AXE = math.random(7000,8000)
AFFF = math.random(9000,10000)
AGGG = math.random(400,600)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local key = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD}
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local Amk = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+3,AC}
local Kei = {(SS-S)+T,SSS+TT-S,SS+TTT,TT,TT+12,SS-S*4}
local KY1 = (key[1]+key[3]-key[1])-key[5] 
local KY2 = (key[1]-Amk[2]*key[3]*Amk[4])-key[5]
local KY3 = (Amk[2]-Amk[1]*Amk[4]-Amk[3])+Amk[1]
local KY4 = (key[1]+AE-key[1])*key[2]
local KY5 = (key[3]+Amk[4]-ADD)+key[2]
local KY6 = (Amk[1]-Amk[3]+key[1])+AFFF

local X = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD, ACC, AGG+3000,AC}
local Y = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+4000,AB+7000,AC}
local X1 = (X[1]+X[3]-X[1]) -X[5] 
local X2 = (X[1]-Y[2]*X[3]*Y[4]) -X[5]
local X3 = (Y[2]-Y[1]*Y[4]-Y[3]) +Y[1]
local X5 = (X[3]+Y[4]-ADD) +X[2]
local X6 = (Y[1]-Y[3]+X[1])+AFFF

local Key1 = math.random(1000,50000)
local Key2 = math.random(1000,50000)
local Key3 = math.random(1000,50000)
local Key4 = math.random(1000,50000)
local Key5 = math.random(1000,50000)
local Key6 = math.random(1000,50000)
local Key7 = math.random(1000,50000)
local Key8 = math.random(1000,50000)
local Key9 = math.random(1000,50000)
local Key10 = math.random(1000,50000)
local Key11 = math.random(1000,50000)
local Key12 = math.random(1000,50000)
local Key13 = math.random(1000,50000)
local Key14 = math.random(1000,50000)
local Key15 = math.random(1000,50000)
local Key16 = math.random(1000,50000)
local Key17 = math.random(1000,50000)
local Key18 = math.random(1000,50000)
local Key19 = math.random(1000,50000)
local Key20 = math.random(1000,50000)
local KeyHex1 = math.random(1000,50000)
local KeyHex2 = math.random(1000,50000)
local KeyHex3 = math.random(1000,50000)
local KeyHex4 = math.random(1000,50000)
local KeyHex5 = math.random(1000,50000)

local inv256 
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function ShaMod(str)str = str:gsub("\n", "\n") if not inv256 then inv256 = {} for M = 1, 100 do local inv = -1 repeat inv = inv + 2 until inv * (2*M + 1) % 256 == 1 inv256[M] = inv end;end local K, F = X1 - X3 + X2, X2 - X3 * X5 return (str:gsub('.', function(m) local L = K % X6; local H = (K - L) / X6; local M = H % 27; local m = m:byte() local c = (m * inv256[M] - (H - M) / 27) % 256 K = L * F + H + c + m
return ('%02x'):format(c)end)) end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function Sha(str)str = str:gsub("\\n", "\n") if not inv256 then inv256 = {} for M = 0, 127 do local inv = -1 repeat inv = inv + 2 until inv * (2*M + 1) % 256 == 1 inv256[M] = inv end;end local K, F = KY1 - KY3 + KY2, KY2 - KY3 * KY5 return (str:gsub('.', function(m)local L = K % KY6;local H = (K - L) / KY6;local M = H % 27;local m = m:byte()local c = (m * inv256[M] - (H - M) / 27) % 256 K = L * F + H + c + m  return ('%02x'):format(c)end)) end
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function SHA(str)
    str = str:gsub("\\n","\n"):gsub("\\t","\t")
    if not inv256 then 
        inv256 = {} 
        for M = 1, 100 do 
            local inv = -1 
            repeat  
                inv = inv + 2 
            until inv * (2*M + 1) % 256 == 1 
            inv256[M] = inv 
        end 
    end
    local K, F = X1 - X3 + X2, X2 - X3 * X5 
    return (str:gsub('.', function(m) 
        local L = K % X6 
        local H = (K - L) / X6 
        local M = H % 27 
        local m = m:byte() 
        local c = (m * inv256[M] - (H - M) / 27) % 256 
        K = L * F + H + c + m 
        return ('%02x'):format(c) 
    end)) 
end
 
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function encodegg(code)
	return '_G["gg"][BGames({BGA = "' .. SHA(code) .. '"})]('
end
function encodeio(code)
	return '_G["io"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeos(code)
return '_G["os"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodevalue(code)
	return 'BGames({BGA = "' .. Sha(code) .. '"})'
end
function encodestr(code)
return '_G["string"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodetbl(code)
return '_G["table"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodedebug(code)
return '_G["debug"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeprint(code)
return '_G["print"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodefile(code)
return '_G["loadfile"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Decode =[[
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
local ABBB = "]]..ABBB..[[";local ACC = "]]..ACC..[[";local i = "]]..math.random(100,800)..[[";local AB = "]]..AB..[[";local i = "]]..math.random(200,900)..[[";local ADD = "]]..ADD..[[";local ADDD = "]]..ADDD..[[";local AGG = "]]..AGG..[[";local AD = "]]..AD..[[";local AXE = "]]..AXE..[[";local i = "]]..math.random(200,900)..[[";local AC = "]]..AC..[[";local AGGG = "]]..AGGG..[[";local AFF = "]]..AFF..[[";local AE = "]]..AE..[[";
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
local ACC = "]]..ACC..[[";local AE = "]]..AE..[[";local AX = "]]..AX..[[";local ACCC = "]]..ACCC..[[";local AG = "]]..AG..[[";local ABB = "]]..ABB..[[";local AF = "]]..AF..[[";local AFFF = "]]..AFFF..[[";local i = "]]..math.random(100,800)..[[";
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end

local key = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD};local Amk = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+3,AC};local KY1 = (key[1]+key[3]-key[1])-key[5] ;local KY2 = (key[1]-Amk[2]*key[3]*Amk[4])-key[5];local KY3 = (Amk[2]-Amk[1]*Amk[4]-Amk[3])+Amk[1];local KY4 = (key[1]+AE-key[1])*key[2];local KY5 = (key[3]+Amk[4]-ADD)+key[2];local KY6 = (Amk[1]-Amk[3]+key[1])+AFFF;local inv256 
local BGames = function(str) str = str.BGA local K, F = KY1 - KY3 + KY2, KY2 - KY3 * KY5 return (str:gsub('%x%x', function(c) local L = K % KY6 local H = (K - L) / KY6 local M = H % 27 c = tonumber(c, 16) local m = (c + (H - M) / 27) * (2*M + 1) % 256 K = L * F + H + c + m 
 if true then return string.char(m)end if true then return end if true then return end end))end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

lock2 =[[
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
gg.toast("Encrypt by ꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂")

	if true then
		if string.match('/' .. tostring(os.time()), '/([^/]+)$') ~= tostring(os.time()) then
			while true do
				if true then
					gg.alert('Error, time is not acceptable.')
					os.exit()
				end
				if false then
				end
			end
		end
	end
	
local GetTableSpam = {}
local b, toStr, GetSpamName = 0, tostring;

local tmp = (function()
  local tempString = ''
  while (b < (10^2)) do
    tempString = tempString .. toStr(b * b);
    b = b + 1
  end
  GetSpamName = (function() local HashName = '' for i = 1, 10 do HashName = "ðŸŒ¨ï¸" .. HashName .. "â˜ƒï¸" .. HashName .. "â„ï¸" end return HashName:rep(100) end)()
  return tempString;
end)();

local spam = "Boar"
local c, b = "'" .. math.random(1, 255) .. "'",  math.random(100, 300)
if tostring("@") == "" then
	return
end

for k, v in next, _ENV do
	if tostring(v):match("function: @.-:") then
		return
	end

local func = os.exit
if tostring(func):match("-") or tostring(func):match("//") or tostring(func):match("@") or tostring(func):match("%d+") then
	return
end
end

local spam_2 = "is top"

for i = 1, #tmp do
    GetTableSpam[i] = {["address"] = GetSpamName, ["flags"] = GetSpamName, ["value"] = GetSpamName, ["freeze"] = GetSpamName, ["name"] = GetSpamName, GetTableSpam[i - 1]}
    gg.refineNumber(GetTableSpam)
	gg.refineAddress(GetTableSpam)
end

local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
os.exit()
os.exit()
os["]==])..string.char(math.random(128,255),math.random(128,255),math.random(128,255),math.random(128,255))..([==["]()
gg.processKill()
return
end
end
if pcall(_ENV["os"]["exit"]) or _ENV["string"]["rep"]("'",'2')~="''" or not _ENV["debug"]["getinfo"](_ENV["tostring"])["isvararg"] or _ENV["debug"]["getinfo"](gg["searchNumber"])["what"]=="Lua" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

_ENV["B1"]= _ENV["debug"]["getinfo"](gg.refineNumber).short_src
if _ENV["B1"]~=_ENV["debug"]["getinfo"](1).short_src and _ENV["B1"]~=gg.getFile() then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if debug.getinfo(1).istailcall then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

x=debug.getinfo(gg.searchNumber)
if x.what~=('Java') then 
os.exit() 
while true do 
end 
end 
local i = {}
local g = {}
local ppi, ppb
g["last"] = _ENV["gg"]["getFile"]()
g["xxx"] = _ENV["loadfile"](g["last"])
g["cpp"] = g["xxx"]
if g["cpp"] ~= nil then 
g["xxx"] = nil
local ppb = g["last"]:match("[^/]+$")
local ppi = "lohhhggg"
local pu = _ENV["gg"]["getResults"](5000)
_ENV["os"]["rename"](''..g["last"]..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'') 
local prt = _ENV["loadfile"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'')
if prt ~= nil then
_ENV["os"]["rename"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppb..'')
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
for i in _ENV["ipairs"]({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])}) do 
if _ENV["string"]["match"](({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])})[i], ("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if _ENV["string"]["rep"]("a", 2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if ("a"):rep(2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _ENV["tostring"](_ENV["gg"]):find(("@")) then 
if not _ENV["tostring"](_ENV["debug"]):find(("@")) then 
if not _ENV["tostring"](_ENV["io"]):find(("@")) then 
if _ENV["tostring"](_ENV["string"]):find(("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
        until x== 20000
        gg["sleep"](0)
        os.exit()
      until false
     end
   end
 end 
end
if _G["debug"]["getlocal"](2, 4) == nil then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _G["utf8"] then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

if _ENV["debug"]["traceback"] == nil then
return 
end

if _ENV["string"]["rep"]("a", 2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

if ("a"):rep(2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

local log = _ENV["string"]["char"](("255"),("255"),("255"),("255"),("255"),("255")):rep("999"):rep("999"):rep(4)
for i = 1,("3340") do
_ENV["gg"]["refineNumber"]("0",log,log,log,log,log,log,log)
end

local GG={"art","ART","Art","dec","Dec","DEC","hook","Hook","HooK","HOOK","log","Log","LOG",}
local _gg={gg.CACHE_DIR,gg.EXT_FILES_DIR,gg.EXT_CACHE_DIR,gg.FILES_DIR,gg.PACKAGE}
for i,v in pairs(GG) do
if string.find(tostring(_gg),v) or(not string.find(tostring(_gg),"com"))then
Error(true)
end
end

while gg.PACKAGE == "catch.Art.Tool.seatch" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.VERSION == "96.0" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.BUILD == "15993" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while string.find(gg.EXT_CACHE_DIR,"com.Art.Tool") do
end
while string.find(gg.EXT_CACHE_DIR,"catch_.me_.if_.you_.can_93") do
end

_ENV["debug"]["getinfo"]=function(a)
return _ENV["debug"]["getinfo"]("BATMANN")
end

for i in string.gmatch(tostring(debug.traceback()), '(.-)\n') do
if string.match(i, '.(/.-):') and string.match(i, '.(/.-):') ~= gg.getFile() then

os.exit()

print("ï¸")
return
end
end

]] 
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

AntiLasm=[[
mmk = ''
for i = 1, math.random(5, 10) do
    fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
    mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nif fucklog or debug.getinfo(2) ~= nil then\n\n   print('Tentativa de log ou disassembly detectada!')\n   -- Encerrar a execução ou tomar outra ação adequada\n   return\nend\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" 
end
]]

 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Infinite = [[

for i = 1,5 do
    if(nil) then 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
    end
    loadfile = loadfile
    load = load
    loadfile(gg.getFile()) 
    load(string.dump(load("os.exit()"),false,false)) 
    io.open(gg.getFile() .. "c" .. tostring(string.dump(loadfile(gg.getFile()),false,false)),"w") 
end

for i = 1, 5000 do
    table.insert({}, {})
end
for i = 1, 5000 do
    table.insert({}, {})
end

gg.setVisible(false)
for i = 1, 6 do
    gg.addListItems({})
end

gg.setVisible(false)
gg.removeListItems({})

if os.time() > os.time() then
    return 
end
if os.time() < os.time() then
end
if os.difftime(os.time(), (os.time())) > 2 then
    return 
end

gg.setVisible(false)
if os.clock() > os.clock() then
    return 
end
if os.clock() < os.clock() then
end
if os.difftime(os.clock(), (os.clock())) > 2 then
    return 
end

gg.setVisible(false)
for i = 3, 100 do
    load(gg.getFile())
end

while(nil)do
    local i={}
    if(i.i)then
        i.i=(i.i(i))
    end
end

while(nil)do
    for i=i,i do
        local i={}
        if(i.i)then
            i.i=(i.i(i))
        end
        for ii=i.i,i.i,i.i do
            local ii={}
            if(ii.i)then
                ii.i=ii.i()
            end
            for iii=i,ii.i,i do
                local iii={}
                if(iii.i)then
                    iii.i=iii.i(i)
                end
                for iiii=i,ii,iii.i do
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=iiii.i(i)
                    end
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=(iiii|iii|ii|i)(i)
                    end
                end
                local iii={}
                if(iii.i)then
                    iii.i=(true|iii|ii|i)(i)
                end
            end
            local ii={}
            if(ii.i)then
                ii.i=(true|false|ii|i)(i)
            end
        end
        local i={}
        if(i.i)then
            i.i=(true|false|nil|i)(i)
        end
        return(true|false|nil)
    end
    return
end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Infinite2 = [[
function obfuscate(code, x)
    x = x or ""
    code = x .. code
    local dmpbool = true
    local proccess = {
        "%%%%%%",
        "@@@@@@",
        "&&&&&&",
        "******"
    } 
    local temporary = "temp.lua" 
    for i = 1, #proccess do
        local f = load(code) or function() error("Error") end
        local dumped_code = string.dump(f, dmpbool)
        local f2 = load(dumped_code) or function() error("Error") end
        gg.internal2(f2, temporary)
        local a, b = {}, {}
        local xxx = {}
        for line in io.lines(temporary) do
            if line:match("^%s*%.func") or line:match("^%s*%.end") then
                b[#b + 1] = #xxx
                if #b == 2 then
                    if b[2] > b[1] + 2 then
                        a[#a + 1] = b
                    end
                    b = {b[2]}
                end
            end
            xxx[#xxx + 1] = line
        end
        code = table.concat(xxx, "\n")
        os.remove(temporary)
        for k, v in pairs(a) do
            local pattern = ""
            for i = v[1], v[2] do
                pattern = pattern .. xxx[i]:gsub("%p", function(c)
                    return "%" .. c
                end) .. "\n"
            end
            code = code:gsub(pattern, proccess[i])
        end
        dmpbool = false
    end
    return code
end

]]
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

blocksstol = [[

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end

while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

xxx = xxx:gsub("%'.-(.-)%'", encodevalue)
xxx = xxx:gsub('%".-(.-)%"', encodevalue)
xxx = xxx:gsub('%[%[.-(.-)%]%]', encodevalue)
xxx = xxx:gsub("gg%.(%a+)%(", encodegg)
xxx = xxx:gsub("io%.(%a+)%(", encodeio)
xxx = xxx:gsub("os%.(%a+)%(", encodeos)
xxx = xxx:gsub("table%.(%a+)%(", encodetbl)
xxx = xxx:gsub("debug%.(%a+)%(", encodedebug)
xxx = xxx:gsub("print%.(%a+)%(", encodeprint)
xxx = xxx:gsub("loadfile%.(%a+)%(", encodefile)
xxx = xxx:gsub("string%.(%a+)%(", encodestr)

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--xxx = Decode .. xxx
xxx = blocksstol..lock2..Infinite..Infinite2..AntiLasm..Decode..xxx

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
xxx = ""..xxx

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
io.open(g.out,"w"):write(string.gsub(string.dump(load(xxx), true), 'LuaR', 'LuaR', 1)):close()
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
ClU = '📂 File Saved To: '..g.out..'\n'
gg.alert(ClU, '')
print("\n▬▬▬▬▬▬▬▬▬▬▬▬▬\n📂 File Saved To :" .. g.out .. "\n▬▬▬▬▬▬▬▬▬▬▬▬▬")
return 
end
 end

function encv8()

g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 gg.alert([[

📌 Features
 
Encrypy binary +
obscureEncode +
sha  + 
Working gg 101.1✔️

by Batman Games🍿 
My telegram @batmangamesS 
]])
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

while true do
  g.info = gg.prompt({
    '📂 Select file :', -- 1
    '📂 Select folder  :' -- 2
  }, g.info, {
    'file', -- 1
    'path' -- 2
  })
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  gg.saveVariable(g.info, g.config)
  g.last = g.info[1]
  if loadfile(g.last) == nil then
    gg.alert("⚠️ Script not Found! ⚠️")
    return
  else
    g.out = g.last:match("[^/]+$")
    g.out = g.out:gsub(".lua", ".Batman")
    g.out = g.info[2] .. "/" .. g.out .. ".lua"
  end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  local file = io.open(g.last, "r")
  local DATA = file:read('*a')
  file:close()
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  -- Função para codificar uma mensagem em um código  simplificado com ofuscação
function byteToBinary(byte)
    local binary = ""
    for i = 7, 0, -1 do
        binary = binary .. tostring((byte >> i) & 1)
    end
    return binary
end

function encodeToQR(str)
    local qr_code = ""
    for i = 1, #str do
        local char = str:sub(i, i)
        local byte = char:byte()
        local binary = byteToBinary(byte)
        qr_code = qr_code .. binary .. "0000"  -- Adiciona separador entre caracteres
    end
    return qr_code
end

DATA = encodeToQR(DATA)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function obscureEncode(str)
    local result = ""
    for i = 1, #str do
        local original_byte = str:byte(i)
        local obscured_byte = original_byte * 2 - 10
        result = result .. string.char(obscured_byte)
    end
    return result
end

DATA = obscureEncode(DATA)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  io.open(g.out,"w"):write(DATA):close()
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  local descript_code = [[
 
 if gg.isPackageInstalled("com.goushi.gtpcanary") then
  print("Packet Capture detect")
  os.exit()
else
end
if gg.isPackageInstalled("com.packagesniffer.frtparlak") then
  print("Packet Capture detect")
  os.exit()
else
end
if gg.isPackageInstalled("app.greyshirts.sslcapture") then
  print("Packet Capture detect")
  os.exit()
else
end

if gg.isPackageInstalled("com.minhui.networkcapture") then
  print("Desinstale o Packet Capture")
  os.exit()
else
end

if gg.isPackageInstalled("frtparlak.rootsniffer") then
  print("Packet Capture detect")
  os.exit()
else
end
if gg.isPackageInstalled("com.minhui.wifianalyzer") then
  print("Packet Capture detect")
  os.exit()
else
end
if gg.isPackageInstalled("jp.co.taosoftware.android.packetcapture") then
  print("Packet Capture detect")
  os.exit()
else
end
if gg.isPackageInstalled("com.prabalgaming.logger") then
print("GG LOG detect")
  os.exit()
else
end
if gg.isPackageInstalled("frtparlak.rootsniffer") then
  print("Packet Capture detect")
  os.exit()
else
end

if gg.isPackageInstalled("any_.body_.can_.fuck_.tencent_") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.s.fyojrme") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.rjvsbmhdspmnfbame") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.redwolfgaming.ripgg") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.vrexqfftfsxekm.kl") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.nochqxpucsbldqqx") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.ghueczxrttlhgd") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.yy.qptvrjwerw.ghoex") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.nochqxpucsbldqqx") then
  print("GG LOG detect")
  os.exit()
end

if gg.isPackageInstalled("com.Egypt.yuosseef") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.tssfjipkmrco") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.vip.paidhacksonly.mr.toxin") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.ioyysvgfsrig") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.mrteamz.id") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.jtbodgpqxox") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.eidymumcghpfeeeavps") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.mod.iraq") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.dzelttwyuyyes") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.sxqa") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.xyyxgxfn") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.zgb") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.tssfjipkmrco") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.vnpqk") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.mwjvnwesbghkxbjznbwo") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.blackduty.gc") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.s.fyojrme") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.roxmemek") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.fhshwhpvqvruvjtu") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.fireongaming.fog") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.paranoiaworks.unicus.android.sse") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.raincitygaming.ggmod") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.pvt4u") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.nydpvsb.z.r.pkgh") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.ioyysvgfsrig") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.gmsm") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.sudsjcqvvcmgutdjeg") then
  print("GG LOG detect")
  os.exit()
end

if gg.isPackageInstalled("com.coolfoolggfuckscript.tm") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.eidymumcghpfeeeavps") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.dzelttwyuyyes") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.foxcyber.gg") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.sxqa") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.zgb") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.hckeam.mjgql") then 
print("GG LOG detect")
os.exit()
end

if gg.isPackageInstalled("com.rgkttz.rausqwl") then 
print("GG LOG detect")
os.exit()
end

if gg.isPackageInstalled("sstool.only.com.sstool") then
  print(" SSTOOL detect")
  os.exit()
end

file,err=io.open("/storage/emulated/0/Android/data/com.decrypt.tool.by.joker.gg") 
jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
Link = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQv6ctApDWsXvQT0MDDuYdJf0glNlUzpS6Hww&usqp=CAU"
      path = "/sdcard/"
      Name = "you_is_noob.png"
      Slapper = gg.makeRequest(Link).content
      io.open(path .. "/" ..Name ,"w"):write(Slapper)
      gg.alert("GG DECRYPT DETECTED")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.goushi.gtpcanary")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.packagesniffer.frtparlak")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/app.greyshirts.sslcapture")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.minhui.networkcapture")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/frtparlak.rootsniffer")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.minhui.wifianalyzer")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/jp.co.taosoftware.android.packetcapture")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/frtparlak.rootsniffer")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/any_.body_.can_.fuck_.tencent_")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.s.fyojrme")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.rjvsbmhdspmnfbame")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.redwolfgaming.ripgg")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.vrexqfftfsxekm.kl")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.nochqxpucsbldqqx")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.ghueczxrttlhgd")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.yy.qptvrjwerw.ghoex")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.nochqxpucsbldqqx")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.Egypt.yuosseef")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.tssfjipkmrco")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.vip.paidhacksonly.mr.toxin")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.ioyysvgfsrig")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.mrteamz.id")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.jtbodgpqxox")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.eidymumcghpfeeeavps")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.mod.iraq")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.dzelttwyuyyes")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.sxqa")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.xyyxgxfn")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.zgb")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.tssfjipkmrco")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.vnpqk")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.mwjvnwesbghkxbjznbwo")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.blackduty.gc")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.s.fyojrme")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.roxmemek")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.fhshwhpvqvruvjtu")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.fireongaming.fog")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.paranoiaworks.unicus.android.sse")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.raincitygaming.ggmod")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.pvt4u")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.nydpvsb.z.r.pkgh")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.ioyysvgfsrig")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.gmsm")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.sudsjcqvvcmgutdjeg")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.coolfoolggfuckscript.tm")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.eidymumcghpfeeeavps")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.dzelttwyuyyes")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.foxcyber.gg")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.sxqa")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.zgb")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.hckeam.mjgql") 
jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.rgkttz.rausqwl") 
jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/sstool.only.com.sstool")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function binaryToByte(binary)
    local byte = 0
    for i = 1, 8 do
        byte = byte << 1
        if binary:sub(i, i) == "1" then
            byte = byte | 1
        end
    end
    return byte
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function decodeFromQR(qr_code)
    local message = ""
    local separator = "0000"
    local index = 1
    while index <= #qr_code do
        local binary = qr_code:sub(index, index + 7)
        if binary == separator then
            index = index + 8  -- Avança para o próximo caractere
        else
            local byte = binaryToByte(binary)
            message = message .. string.char(byte)
            index = index + 12  -- Avança para o próximo caractere, pulando o separador
        end
    end
    return message
end
    
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function obscureDecode(str)
    local result = ""
    for i = 1, #str do
        local obscured_byte = str:byte(i)
        local original_byte = (obscured_byte + 10) / 2
        result = result .. string.char(original_byte)
    end
    return result
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    -- Recuperar o código original
    local encrypted_code = "]] .. DATA .. [["
    local decrypted_code = decodeFromQR(obscureDecode(encrypted_code))
    assert(load(decrypted_code))()
  ]]
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  DATA = descript_code
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

io.open(g.out,"w"):write(DATA):close()


local arquivo_saida2 = io.open(g.out, "r")
local xxx = arquivo_saida2:read("*a")
arquivo_saida2:close()

S = math.random(1, 60)
SS = math.random(80, 302)
SSS = math.random(1, 60)
T = math.random(190, 340)
TT = math.random(1, 60)
TTT = math.random(190, 470)
AB = math.random(1000,2000)
AC = math.random(3000,4000)
AD = math.random(5000,6000)
AE = math.random(6000,8000)
AF = math.random(9000,10000)
AG = math.random(400,600)
ABB = math.random(2000,2000)
ACC = math.random(3000,4000)
ADD = math.random(5000,6000)
AFF = math.random(9000,10000)
AGG = math.random(400,600)
AX = math.random(200,800)
ABBB = math.random(1000,2000)
ACCC = math.random(3000,4000)
ADDD = math.random(5000,6000)
AXE = math.random(7000,8000)
AFFF = math.random(9000,10000)
AGGG = math.random(400,600)

local KEY = {AB+AC-AD*AE,AB+AB-AC,AE+AD/2*5,50/2*5+AC}
local KEY1 = (AB+AC-AD) + (AE-AF+AB)
local KEY2 = (AB*AC-KEY1) * (AB+AC+AG) / (5)
local KEY3 = (AD-AC+100) + (AG+AE-AF/2*50)

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local key = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD}
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local Amk = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+3,AC}
local Kei = {(SS-S)+T,SSS+TT-S,SS+TTT,TT,TT+12,SS-S*4}
local KY1 = (key[1]+key[3]-key[1])-key[5] 
local KY2 = (key[1]-Amk[2]*key[3]*Amk[4])-key[5]
local KY3 = (Amk[2]-Amk[1]*Amk[4]-Amk[3])+Amk[1]
local KY4 = (key[1]+AE-key[1])*key[2]
local KY5 = (key[3]+Amk[4]-ADD)+key[2]
local KY6 = (Amk[1]-Amk[3]+key[1])+AFFF

local X = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD, ACC, AGG+3000,AC}
local Y = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+4000,AB+7000,AC}
local X1 = (X[1]+X[3]-X[1]) -X[5] 
local X2 = (X[1]-Y[2]*X[3]*Y[4]) -X[5]
local X3 = (Y[2]-Y[1]*Y[4]-Y[3]) +Y[1]
local X5 = (X[3]+Y[4]-ADD) +X[2]
local X6 = (Y[1]-Y[3]+X[1])+AFFF

local Key1 = math.random(1000,50000)
local Key2 = math.random(1000,50000)
local Key3 = math.random(1000,50000)
local Key4 = math.random(1000,50000)
local Key5 = math.random(1000,50000)
local Key6 = math.random(1000,50000)
local Key7 = math.random(1000,50000)
local Key8 = math.random(1000,50000)
local Key9 = math.random(1000,50000)
local Key10 = math.random(1000,50000)
local Key11 = math.random(1000,50000)
local Key12 = math.random(1000,50000)
local Key13 = math.random(1000,50000)
local Key14 = math.random(1000,50000)
local Key15 = math.random(1000,50000)
local Key16 = math.random(1000,50000)
local Key17 = math.random(1000,50000)
local Key18 = math.random(1000,50000)
local Key19 = math.random(1000,50000)
local Key20 = math.random(1000,50000)
local KeyHex1 = math.random(1000,50000)
local KeyHex2 = math.random(1000,50000)
local KeyHex3 = math.random(1000,50000)
local KeyHex4 = math.random(1000,50000)
local KeyHex5 = math.random(1000,50000)

local inv256 
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function ShaMod(str)str = str:gsub("\n", "\n") if not inv256 then inv256 = {} for M = 1, 100 do local inv = -1 repeat inv = inv + 2 until inv * (2*M + 1) % 256 == 1 inv256[M] = inv end;end local K, F = X1 - X3 + X2, X2 - X3 * X5 return (str:gsub('.', function(m) local L = K % X6; local H = (K - L) / X6; local M = H % 27; local m = m:byte() local c = (m * inv256[M] - (H - M) / 27) % 256 K = L * F + H + c + m
return ('%02x'):format(c)end)) end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function Sha(str)str = str:gsub("\\n", "\n") if not inv256 then inv256 = {} for M = 0, 127 do local inv = -1 repeat inv = inv + 2 until inv * (2*M + 1) % 256 == 1 inv256[M] = inv end;end local K, F = KY1 - KY3 + KY2, KY2 - KY3 * KY5 return (str:gsub('.', function(m)local L = K % KY6;local H = (K - L) / KY6;local M = H % 27;local m = m:byte()local c = (m * inv256[M] - (H - M) / 27) % 256 K = L * F + H + c + m  return ('%02x'):format(c)end)) end
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function SHA(str)
    str = str:gsub("\\n","\n"):gsub("\\t","\t")
    if not inv256 then 
        inv256 = {} 
        for M = 1, 100 do 
            local inv = -1 
            repeat  
                inv = inv + 2 
            until inv * (2*M + 1) % 256 == 1 
            inv256[M] = inv 
        end 
    end
    local K, F = X1 - X3 + X2, X2 - X3 * X5 
    return (str:gsub('.', function(m) 
        local L = K % X6 
        local H = (K - L) / X6 
        local M = H % 27 
        local m = m:byte() 
        local c = (m * inv256[M] - (H - M) / 27) % 256 
        K = L * F + H + c + m 
        return ('%02x'):format(c) 
    end)) 
end

function EncodeFunc(str)
str = str:gsub("\\n", "\n"):gsub("\\t","\t")
	return str:gsub('.', function (c)
		return string.format('%02x ', (string.byte(c)-KEY1-KEY2+KEY3/KEY[1]*KEY[2])%256)
	end):gsub(" $", "", 1)
end

 
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function encodegg(code)
	return '_G["gg"][BGames({BGA = "' .. SHA(code) .. '"})]('
end
function encodeio(code)
	return '_G["io"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeos(code)
return '_G["os"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodevalue(code)
	return 'BGames({BGA = "' .. Sha(code) .. '"})'
end

function encodetbl(code)
return '_G["table"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodedebug(code)
return '_G["debug"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeprint(code)
return '_G["print"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodefile(code)
return '_G["loadfile"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end

function encodestr(str)
	return 'string[DecodeFunc("' .. EncodeFunc(str) .. '")]('
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Decode =[[
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
local ABBB = "]]..ABBB..[[";local ACC = "]]..ACC..[[";local i = "]]..math.random(100,800)..[[";local AB = "]]..AB..[[";local i = "]]..math.random(200,900)..[[";local ADD = "]]..ADD..[[";local ADDD = "]]..ADDD..[[";local AGG = "]]..AGG..[[";local AD = "]]..AD..[[";local AXE = "]]..AXE..[[";local i = "]]..math.random(200,900)..[[";local AC = "]]..AC..[[";local AGGG = "]]..AGGG..[[";local AFF = "]]..AFF..[[";local AE = "]]..AE..[[";
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
local ACC = "]]..ACC..[[";local AE = "]]..AE..[[";local AX = "]]..AX..[[";local ACCC = "]]..ACCC..[[";local AG = "]]..AG..[[";local ABB = "]]..ABB..[[";local AF = "]]..AF..[[";local AFFF = "]]..AFFF..[[";local i = "]]..math.random(100,800)..[[";
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end

local key = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD};local Amk = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+3,AC};local KY1 = (key[1]+key[3]-key[1])-key[5] ;local KY2 = (key[1]-Amk[2]*key[3]*Amk[4])-key[5];local KY3 = (Amk[2]-Amk[1]*Amk[4]-Amk[3])+Amk[1];local KY4 = (key[1]+AE-key[1])*key[2];local KY5 = (key[3]+Amk[4]-ADD)+key[2];local KY6 = (Amk[1]-Amk[3]+key[1])+AFFF;local inv256 
local BGames = function(str) str = str.BGA local K, F = KY1 - KY3 + KY2, KY2 - KY3 * KY5 return (str:gsub('%x%x', function(c) local L = K % KY6 local H = (K - L) / KY6 local M = H % 27 c = tonumber(c, 16) local m = (c + (H - M) / 27) * (2*M + 1) % 256 K = L * F + H + c + m 
 if true then return string.char(m)end if true then return end if true then return end end))end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]

Decode2 =[[

local AB = ]]..AB..[[;for i = 1,0 do;OP='OP';end;for i = 1,0 do;OP='OP';end;
local AC = ]]..AC..[[;for i = 1,0 do;OP='OP';end;for i = 1,0 do;OP='OP';end;
local AD = ]]..AD..[[;for i = 1,0 do;OP='OP';end;for i = 1,0 do;OP='OP';end;
if(nil)then;(function()end)();end;for i = 1,0 do;OP='OP';end;for i = 1,0 do;OP='OP';end;local AE = ]]..AE..[[;for i = 1,0 do;OP='OP';end;for i = 1,0 do;OP='OP';end;

local AF = ]]..AF..[[;for i = 1,0 do;OP='OP';end;for i = 1,0 do;OP='OP';end;local AG = ]]..AG..[[;if(nil)then;(function()end)();end;for i = 1,0 do;OP='OP';end;
for i = 1,0 do;OP='OP';end;for i = 1,0 do;OP='OP';end;

local KEY = {AB+AC-AD*AE,AB+AB-AC,AE+AD/2*5,50/2*5+AC};if(nil)then;(function()end)();end;for i = 1,0 do;OP='OP';end;for i = 1,0 do;OP='OP';end;local KEY1 = ((AB+AC-AD) + (AE-AF+AB));if(nil)then;(function()end)();end;for i = 1,0 do;OP='OP';end;for i = 1,0 do;OP='OP';end;
local KEY2 = ((AB*AC-KEY1) * (AB+AC+AG) / (5));if(nil)then;(function()end)();end;for i = 1,0 do;OP='OP';end;local KEY3 = ((AD-AC+100) + (AG+AE-AF/2*50));if(nil)then;(function()end)();end;for i = 1,0 do;OP='OP';end;
local function DecodeFunc(Text)
Text = Text:gsub(" ","")
return (Text:gsub("..",function (Text)
return string.char((tonumber(Text,16)+KEY1+KEY2-KEY3/KEY[1]*KEY[2])%256)
end))
end
if(nil)then;(function()end)();end;if(nil)then;(function()end)();end;

]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

lock2 =[[
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
gg.toast("Encrypt by ꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂")

	if true then
		if string.match('/' .. tostring(os.time()), '/([^/]+)$') ~= tostring(os.time()) then
			while true do
				if true then
					gg.alert('Error, time is not acceptable.')
					os.exit()
				end
				if false then
				end
			end
		end
	end
	
local GetTableSpam = {}
local b, toStr, GetSpamName = 0, tostring;

local tmp = (function()
  local tempString = ''
  while (b < (10^2)) do
    tempString = tempString .. toStr(b * b);
    b = b + 1
  end
  GetSpamName = (function() local HashName = '' for i = 1, 10 do HashName = "ðŸŒ¨ï¸" .. HashName .. "â˜ƒï¸" .. HashName .. "â„ï¸" end return HashName:rep(100) end)()
  return tempString;
end)();

local spam = "Boar"
local c, b = "'" .. math.random(1, 255) .. "'",  math.random(100, 300)
if tostring("@") == "" then
	return
end

for k, v in next, _ENV do
	if tostring(v):match("function: @.-:") then
		return
	end

local func = os.exit
if tostring(func):match("-") or tostring(func):match("//") or tostring(func):match("@") or tostring(func):match("%d+") then
	return
end
end

local spam_2 = "is top"

for i = 1, #tmp do
    GetTableSpam[i] = {["address"] = GetSpamName, ["flags"] = GetSpamName, ["value"] = GetSpamName, ["freeze"] = GetSpamName, ["name"] = GetSpamName, GetTableSpam[i - 1]}
    gg.refineNumber(GetTableSpam)
	gg.refineAddress(GetTableSpam)
end

local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
os.exit()
os.exit()
os["]==])..string.char(math.random(128,255),math.random(128,255),math.random(128,255),math.random(128,255))..([==["]()
gg.processKill()
return
end
end
if pcall(_ENV["os"]["exit"]) or _ENV["string"]["rep"]("'",'2')~="''" or not _ENV["debug"]["getinfo"](_ENV["tostring"])["isvararg"] or _ENV["debug"]["getinfo"](gg["searchNumber"])["what"]=="Lua" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

_ENV["B1"]= _ENV["debug"]["getinfo"](gg.refineNumber).short_src
if _ENV["B1"]~=_ENV["debug"]["getinfo"](1).short_src and _ENV["B1"]~=gg.getFile() then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if debug.getinfo(1).istailcall then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

x=debug.getinfo(gg.searchNumber)
if x.what~=('Java') then 
os.exit() 
while true do 
end 
end 
local i = {}
local g = {}
local ppi, ppb
g["last"] = _ENV["gg"]["getFile"]()
g["xxx"] = _ENV["loadfile"](g["last"])
g["cpp"] = g["xxx"]
if g["cpp"] ~= nil then 
g["xxx"] = nil
local ppb = g["last"]:match("[^/]+$")
local ppi = "lohhhggg"
local pu = _ENV["gg"]["getResults"](5000)
_ENV["os"]["rename"](''..g["last"]..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'') 
local prt = _ENV["loadfile"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'')
if prt ~= nil then
_ENV["os"]["rename"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppb..'')
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
for i in _ENV["ipairs"]({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])}) do 
if _ENV["string"]["match"](({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])})[i], ("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if _ENV["string"]["rep"]("a", 2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if ("a"):rep(2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _ENV["tostring"](_ENV["gg"]):find(("@")) then 
if not _ENV["tostring"](_ENV["debug"]):find(("@")) then 
if not _ENV["tostring"](_ENV["io"]):find(("@")) then 
if _ENV["tostring"](_ENV["string"]):find(("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
        until x== 20000
        gg["sleep"](0)
        os.exit()
      until false
     end
   end
 end 
end
if _G["debug"]["getlocal"](2, 4) == nil then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _G["utf8"] then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

if _ENV["debug"]["traceback"] == nil then
return 
end

if _ENV["string"]["rep"]("a", 2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

if ("a"):rep(2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

local log = _ENV["string"]["char"](("255"),("255"),("255"),("255"),("255"),("255")):rep("999"):rep("999"):rep(4)
for i = 1,("3340") do
_ENV["gg"]["refineNumber"]("0",log,log,log,log,log,log,log)
end

local GG={"art","ART","Art","dec","Dec","DEC","hook","Hook","HooK","HOOK","log","Log","LOG",}
local _gg={gg.CACHE_DIR,gg.EXT_FILES_DIR,gg.EXT_CACHE_DIR,gg.FILES_DIR,gg.PACKAGE}
for i,v in pairs(GG) do
if string.find(tostring(_gg),v) or(not string.find(tostring(_gg),"com"))then
Error(true)
end
end

while gg.PACKAGE == "catch.Art.Tool.seatch" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.VERSION == "96.0" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.BUILD == "15993" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while string.find(gg.EXT_CACHE_DIR,"com.Art.Tool") do
end
while string.find(gg.EXT_CACHE_DIR,"catch_.me_.if_.you_.can_93") do
end

_ENV["debug"]["getinfo"]=function(a)
return _ENV["debug"]["getinfo"]("BATMANN")
end

for i in string.gmatch(tostring(debug.traceback()), '(.-)\n') do
if string.match(i, '.(/.-):') and string.match(i, '.(/.-):') ~= gg.getFile() then

os.exit()

print("ï¸")
return
end
end

]] 
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

AntiLasm=[[
mmk = ''
for i = 1, math.random(5, 10) do
    fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
    mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nif fucklog or debug.getinfo(2) ~= nil then\n\n   print('Tentativa de log ou disassembly detectada!')\n   -- Encerrar a execução ou tomar outra ação adequada\n   return\nend\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" 
end
]]

 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Infinite = [[

for i = 1,5 do
    if(nil) then 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
    end
    loadfile = loadfile
    load = load
    loadfile(gg.getFile()) 
    load(string.dump(load("os.exit()"),false,false)) 
    io.open(gg.getFile() .. "c" .. tostring(string.dump(loadfile(gg.getFile()),false,false)),"w") 
end

for i = 1, 5000 do
    table.insert({}, {})
end
for i = 1, 5000 do
    table.insert({}, {})
end

gg.setVisible(false)
for i = 1, 6 do
    gg.addListItems({})
end

gg.setVisible(false)
gg.removeListItems({})

if os.time() > os.time() then
    return 
end
if os.time() < os.time() then
end
if os.difftime(os.time(), (os.time())) > 2 then
    return 
end

gg.setVisible(false)
if os.clock() > os.clock() then
    return 
end
if os.clock() < os.clock() then
end
if os.difftime(os.clock(), (os.clock())) > 2 then
    return 
end

gg.setVisible(false)
for i = 3, 100 do
    load(gg.getFile())
end

while(nil)do
    local i={}
    if(i.i)then
        i.i=(i.i(i))
    end
end

while(nil)do
    for i=i,i do
        local i={}
        if(i.i)then
            i.i=(i.i(i))
        end
        for ii=i.i,i.i,i.i do
            local ii={}
            if(ii.i)then
                ii.i=ii.i()
            end
            for iii=i,ii.i,i do
                local iii={}
                if(iii.i)then
                    iii.i=iii.i(i)
                end
                for iiii=i,ii,iii.i do
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=iiii.i(i)
                    end
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=(iiii|iii|ii|i)(i)
                    end
                end
                local iii={}
                if(iii.i)then
                    iii.i=(true|iii|ii|i)(i)
                end
            end
            local ii={}
            if(ii.i)then
                ii.i=(true|false|ii|i)(i)
            end
        end
        local i={}
        if(i.i)then
            i.i=(true|false|nil|i)(i)
        end
        return(true|false|nil)
    end
    return
end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Infinite2 = [[
function obfuscate(code, x)
    x = x or ""
    code = x .. code
    local dmpbool = true
    local proccess = {
        "%%%%%%",
        "@@@@@@",
        "&&&&&&",
        "******"
    } 
    local temporary = "temp.lua" 
    for i = 1, #proccess do
        local f = load(code) or function() error("Error") end
        local dumped_code = string.dump(f, dmpbool)
        local f2 = load(dumped_code) or function() error("Error") end
        gg.internal2(f2, temporary)
        local a, b = {}, {}
        local xxx = {}
        for line in io.lines(temporary) do
            if line:match("^%s*%.func") or line:match("^%s*%.end") then
                b[#b + 1] = #xxx
                if #b == 2 then
                    if b[2] > b[1] + 2 then
                        a[#a + 1] = b
                    end
                    b = {b[2]}
                end
            end
            xxx[#xxx + 1] = line
        end
        code = table.concat(xxx, "\n")
        os.remove(temporary)
        for k, v in pairs(a) do
            local pattern = ""
            for i = v[1], v[2] do
                pattern = pattern .. xxx[i]:gsub("%p", function(c)
                    return "%" .. c
                end) .. "\n"
            end
            code = code:gsub(pattern, proccess[i])
        end
        dmpbool = false
    end
    return code
end

]]
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

blocksstol = [[

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end

while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

xxx = xxx:gsub("%'.-(.-)%'", encodevalue)
xxx = xxx:gsub('%".-(.-)%"', encodevalue)
xxx = xxx:gsub('%[%[.-(.-)%]%]', encodevalue)
xxx = xxx:gsub("gg%.(%a+)%(", encodegg)
xxx = xxx:gsub("io%.(%a+)%(", encodeio)
xxx = xxx:gsub("os%.(%a+)%(", encodeos)
xxx = xxx:gsub("table%.(%a+)%(", encodetbl)
xxx = xxx:gsub("debug%.(%a+)%(", encodedebug)
xxx = xxx:gsub("print%.(%a+)%(", encodeprint)
xxx = xxx:gsub("loadfile%.(%a+)%(", encodefile)
xxx = xxx:gsub("string%.(%a+)%(", encodestr)

xxx = Decode..Decode2.. xxx
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

xxx = blocksstol..lock2..Infinite..Infinite2..AntiLasm..Decode..xxx

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

io.open(g.out,"w"):write(string.gsub(string.dump(load(xxx), true), 'LuaR', 'LuaR', 1)):close()
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
ClU = '📂 File Saved To: '..g.out..'\n'
gg.alert(ClU, '')
print("\n▬▬▬▬▬▬▬▬▬▬▬▬▬\n📂 File Saved To :" .. g.out .. "\n▬▬▬▬▬▬▬▬▬▬▬▬▬")
return 
end
end

function encv9()

g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
gg.alert([[

📌 Features
 
Encryption  base 48 +
blocks +
Working gg 101.1✔️

by Batman Games🍿 
My telegram @batmangamesS 
]])
while true do
  g.info = gg.prompt({
    '📂 Select file :', -- 1
    '📂 Select folder  :' -- 2
  }, g.info, {
    'file', -- 1
    'path' -- 2
  })
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  gg.saveVariable(g.info, g.config)
  g.last = g.info[1]
  if loadfile(g.last) == nil then
    gg.alert("⚠️ Script not Found! ⚠️")
    return
  else
    g.out = g.last:match("[^/]+$")
    g.out = g.out:gsub(".lua", ".Batman")
    g.out = g.info[2] .. "/" .. g.out .. ".lua"
  end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  local file = io.open(g.last, "r")
  local DATA = file:read('*a')
  file:close()
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local DecToBase48 = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_'

function enc48(S)
    local T = {}
    local j = 1
    local B
    for i = 1, #S do
        B = S:byte(i) / 4 + 1
        T[j] = DecToBase48:sub(B, B)
        B = S:byte(i) % 4 + 1
        T[j + 1] = DecToBase48:sub(B, B)
        j = j + 2
    end
    return table.concat(T)
end

  local descript_code = [[
 local DecToBase48 = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_'

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

gg.setVisible(true)
  function dec48(S)
    local T = {}
    local j = 1
    local B
    for i = 1, #S, 2 do
        local char1 = S:sub(i, i)
        local char2 = S:sub(i + 1, i + 1)
        local index1 = DecToBase48:find(char1) - 1
        local index2 = DecToBase48:find(char2) - 1
        local byte = index1 * 4 + index2
        T[j] = string.char(byte)
        j = j + 1
    end
    return table.concat(T)
end

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end
  ]]
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

lock2 =[[
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
gg.toast("Encrypt by ꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂")

	if true then
		if string.match('/' .. tostring(os.time()), '/([^/]+)$') ~= tostring(os.time()) then
			while true do
				if true then
					gg.alert('Error, time is not acceptable.')
					os.exit()
				end
				if false then
				end
			end
		end
	end
	
local GetTableSpam = {}
local b, toStr, GetSpamName = 0, tostring;

local tmp = (function()
  local tempString = ''
  while (b < (10^2)) do
    tempString = tempString .. toStr(b * b);
    b = b + 1
  end
  GetSpamName = (function() local HashName = '' for i = 1, 10 do HashName = "ðŸŒ¨ï¸" .. HashName .. "â˜ƒï¸" .. HashName .. "â„ï¸" end return HashName:rep(100) end)()
  return tempString;
end)();

local spam = "Boar"
local c, b = "'" .. math.random(1, 255) .. "'",  math.random(100, 300)
if tostring("@") == "" then
	return
end

for k, v in next, _ENV do
	if tostring(v):match("function: @.-:") then
		return
	end

local func = os.exit
if tostring(func):match("-") or tostring(func):match("//") or tostring(func):match("@") or tostring(func):match("%d+") then
	return
end
end

local spam_2 = "is top"

for i = 1, #tmp do
    GetTableSpam[i] = {["address"] = GetSpamName, ["flags"] = GetSpamName, ["value"] = GetSpamName, ["freeze"] = GetSpamName, ["name"] = GetSpamName, GetTableSpam[i - 1]}
    gg.refineNumber(GetTableSpam)
	gg.refineAddress(GetTableSpam)
end

local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
os.exit()
os.exit()
os["]==])..string.char(math.random(128,255),math.random(128,255),math.random(128,255),math.random(128,255))..([==["]()
gg.processKill()
return
end
end
if pcall(_ENV["os"]["exit"]) or _ENV["string"]["rep"]("'",'2')~="''" or not _ENV["debug"]["getinfo"](_ENV["tostring"])["isvararg"] or _ENV["debug"]["getinfo"](gg["searchNumber"])["what"]=="Lua" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

_ENV["B1"]= _ENV["debug"]["getinfo"](gg.refineNumber).short_src
if _ENV["B1"]~=_ENV["debug"]["getinfo"](1).short_src and _ENV["B1"]~=gg.getFile() then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if debug.getinfo(1).istailcall then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

x=debug.getinfo(gg.searchNumber)
if x.what~=('Java') then 
os.exit() 
while true do 
end 
end 
local i = {}
local g = {}
local ppi, ppb
g["last"] = _ENV["gg"]["getFile"]()
g["xxx"] = _ENV["loadfile"](g["last"])
g["cpp"] = g["xxx"]
if g["cpp"] ~= nil then 
g["xxx"] = nil
local ppb = g["last"]:match("[^/]+$")
local ppi = "lohhhggg"
local pu = _ENV["gg"]["getResults"](5000)
_ENV["os"]["rename"](''..g["last"]..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'') 
local prt = _ENV["loadfile"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'')
if prt ~= nil then
_ENV["os"]["rename"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppb..'')
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
for i in _ENV["ipairs"]({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])}) do 
if _ENV["string"]["match"](({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])})[i], ("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if _ENV["string"]["rep"]("a", 2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if ("a"):rep(2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _ENV["tostring"](_ENV["gg"]):find(("@")) then 
if not _ENV["tostring"](_ENV["debug"]):find(("@")) then 
if not _ENV["tostring"](_ENV["io"]):find(("@")) then 
if _ENV["tostring"](_ENV["string"]):find(("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
        until x== 20000
        gg["sleep"](0)
        os.exit()
      until false
     end
   end
 end 
end
if _G["debug"]["getlocal"](2, 4) == nil then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _G["utf8"] then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

if _ENV["debug"]["traceback"] == nil then
return 
end

if _ENV["string"]["rep"]("a", 2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

if ("a"):rep(2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

local log = _ENV["string"]["char"](("255"),("255"),("255"),("255"),("255"),("255")):rep("999"):rep("999"):rep(4)
for i = 1,("3340") do
_ENV["gg"]["refineNumber"]("0",log,log,log,log,log,log,log)
end

local GG={"art","ART","Art","dec","Dec","DEC","hook","Hook","HooK","HOOK","log","Log","LOG",}
local _gg={gg.CACHE_DIR,gg.EXT_FILES_DIR,gg.EXT_CACHE_DIR,gg.FILES_DIR,gg.PACKAGE}
for i,v in pairs(GG) do
if string.find(tostring(_gg),v) or(not string.find(tostring(_gg),"com"))then
Error(true)
end
end

while gg.PACKAGE == "catch.Art.Tool.seatch" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.VERSION == "96.0" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.BUILD == "15993" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while string.find(gg.EXT_CACHE_DIR,"com.Art.Tool") do
end
while string.find(gg.EXT_CACHE_DIR,"catch_.me_.if_.you_.can_93") do
end

_ENV["debug"]["getinfo"]=function(a)
return _ENV["debug"]["getinfo"]("BATMANN")
end

for i in string.gmatch(tostring(debug.traceback()), '(.-)\n') do
if string.match(i, '.(/.-):') and string.match(i, '.(/.-):') ~= gg.getFile() then

os.exit()

print("ï¸")
return
end
end
]] 
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

AntiLasm=[[
mmk = ''
for i = 1, math.random(5, 10) do
    fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
    mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nif fucklog or debug.getinfo(2) ~= nil then\n\n   print('Tentativa de log ou disassembly detectada!')\n   -- Encerrar a execução ou tomar outra ação adequada\n   return\nend\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" 
end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Infinite = [[

for i = 1,5 do
    if(nil) then 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
    end
    loadfile = loadfile
    load = load
    loadfile(gg.getFile()) 
    load(string.dump(load("os.exit()"),false,false)) 
    io.open(gg.getFile() .. "c" .. tostring(string.dump(loadfile(gg.getFile()),false,false)),"w") 
end

for i = 1, 5000 do
    table.insert({}, {})
end
for i = 1, 5000 do
    table.insert({}, {})
end

gg.setVisible(false)
for i = 1, 6 do
    gg.addListItems({})
end

gg.setVisible(false)
gg.removeListItems({})

if os.time() > os.time() then
    return 
end
if os.time() < os.time() then
end
if os.difftime(os.time(), (os.time())) > 2 then
    return 
end

gg.setVisible(false)
if os.clock() > os.clock() then
    return 
end
if os.clock() < os.clock() then
end
if os.difftime(os.clock(), (os.clock())) > 2 then
    return 
end

gg.setVisible(false)
for i = 3, 100 do
    load(gg.getFile())
end

while(nil)do
    local i={}
    if(i.i)then
        i.i=(i.i(i))
    end
end

while(nil)do
    for i=i,i do
        local i={}
        if(i.i)then
            i.i=(i.i(i))
        end
        for ii=i.i,i.i,i.i do
            local ii={}
            if(ii.i)then
                ii.i=ii.i()
            end
            for iii=i,ii.i,i do
                local iii={}
                if(iii.i)then
                    iii.i=iii.i(i)
                end
                for iiii=i,ii,iii.i do
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=iiii.i(i)
                    end
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=(iiii|iii|ii|i)(i)
                    end
                end
                local iii={}
                if(iii.i)then
                    iii.i=(true|iii|ii|i)(i)
                end
            end
            local ii={}
            if(ii.i)then
                ii.i=(true|false|ii|i)(i)
            end
        end
        local i={}
        if(i.i)then
            i.i=(true|false|nil|i)(i)
        end
        return(true|false|nil)
    end
    return
end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Infinite2 = [[
function obfuscate(code, x)
    x = x or ""
    code = x .. code
    local dmpbool = true
    local proccess = {
        "%%%%%%",
        "@@@@@@",
        "&&&&&&",
        "******"
    } 
    local temporary = "temp.lua" 
    for i = 1, #proccess do
        local f = load(code) or function() error("Error") end
        local dumped_code = string.dump(f, dmpbool)
        local f2 = load(dumped_code) or function() error("Error") end
        gg.internal2(f2, temporary)
        local a, b = {}, {}
        local xxx = {}
        for line in io.lines(temporary) do
            if line:match("^%s*%.func") or line:match("^%s*%.end") then
                b[#b + 1] = #xxx
                if #b == 2 then
                    if b[2] > b[1] + 2 then
                        a[#a + 1] = b
                    end
                    b = {b[2]}
                end
            end
            xxx[#xxx + 1] = line
        end
        code = table.concat(xxx, "\n")
        os.remove(temporary)
        for k, v in pairs(a) do
            local pattern = ""
            for i = v[1], v[2] do
                pattern = pattern .. xxx[i]:gsub("%p", function(c)
                    return "%" .. c
                end) .. "\n"
            end
            code = code:gsub(pattern, proccess[i])
        end
        dmpbool = false
    end
    return code
end

]]

blocksstol = [[

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end

while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

]]
SSFUCK=[[

for i in ipairs({}) do local Cok = {} if not xs then else local Kntoll = {};local Cok = {} Cok.Kntoll = Cok.Kntoll() if Cok.Kntoll ~= Cok.Kntoll then Cok.Kntoll = Cok.Kntoll() end local Cok = {};local Asu = {} Cok.Asu = Cok.Asu() if Cok.Asu ~= Cok.Asu then Cok.Asu = Cok.Asu() end end end
while(nil)do;local UwU = {} if(UwU.UwU)then;UwU.UwU=(UwU.UwU(UwU))end;end;
for i = 1, 0 do local UwU = {} UwU.ngentot = UwU.xnxx() if UwU.xnxx ~= nil then UwU.ngentot = UwU.xnxx() end UwU = nil end
for i in ipairs({}) do local Cok = {} if not xs then else local Kntoll = {};local Cok = {} Cok.Kntoll = Cok.Kntoll() if Cok.Kntoll ~= Cok.Kntoll then Cok.Kntoll = Cok.Kntoll() end local Cok = {};local Asu = {} Cok.Asu = Cok.Asu() if Cok.Asu ~= Cok.Asu then Cok.Asu = Cok.Asu() end end end
]]

SPAM=[[

if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
]]

SPAM2 =[[
 if nil then  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  ::s:: end _X=_X 
 
 while (function(_) if _ then for _ = _, _ do _._ = _[_] + _.__ - _.___ repeat _.__ = _._ * _.___ / _.____ if not _ then _.___ = _._ - _.___._.____(function(_) _._____._ = _.__.____.____ for _, _ in pairs(_) do _.______ = _._.__.___.____.____ if pairs(_) then (_)._ = pairs(_) else (_)[_] = _ return (_) end end _._____._ = _.__.____.____ return (function(_) _.__ = _._ * _.___ / _.____ while _ do _._ = _[_] + _.__ - _.___ for _ = -_, _ - _ do _.__ = _._ * _.___ / _.____ if _ then _ = not _ return not _ or _ and _ end _.___ = _._ - _.___._.____end end end _._____._ = _.__.____.____ end)(_) end)(_) _.______ = _._.__.___.____._____ end until not _ or _ _.__ = _._ * _.___ / _.____ end return not _ end end)(not true) do end

while (nil)do;local o={{-nil,{nil%- nil,{-nil%nil,{nil%nil%- nil,{""..BD..""}},{BD},}},{{"\n\n"},o.uo,{{"\n"},p.p,{{"\n\n\n"},fq.qo.o,{{"\t\n\n\t\n"},p.p,{{"\t\n"},q.q{o}.uo,{{"\n\n\t\t\n\n"},p.p,{{"\n\n\t\n\t\n\n\t\n"},q.qo.o,{{"\n\t\n\n\t\n"},p.p,{{"\n\n\t\n"},q.q}}}}}}}}}}} local p={o.o,{{"\n"},S,n,i,p,e,r,G,a,m,e,r,T,M,p,{{"\n"},p.p,q.qo.o,{p.p,{q.q.o,{p.s{"\n\n"},p,{q.q}}}}}}} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={S,n,i,p,e,r,G,a,m,e,r,T,M} local q={o.o,p.p,q.qo.uo,p.p,q,qi,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end

if nil then end if (tonumber(-727)<tonumber(-918)) then end for o=1,0 do _() local _={} _._=_ _._=_._ _._={} for o in (_) do _[_]=_ end _() goto _ goto _ goto _ ::_:: local o={(__~__)|nil} if o.o==o.o then o.o=o.o() end end while(true) do if true then if (tonumber(-758)<tonumber(-524)) then break end local _={} _._=_ _._=_._ _._={} end local o={(__~__)|nil} end

for i in ipairs({}) do local GetProtectValues = {} if not GetProtectValues then else GetProtectValues = Plugin local SUBAIecompile = {} SUBAIecompile.GetError.Crash = SUBAIecompile.GetError.Crash() if SUBAIecompile.GetError.Crash ~= SUBAIecompile.GetError.Crash then SUBAIecompile.GetError.Crash = SUBAIecompile.GetError.Crash()  local SUBAIecompile = {} SUBAIecompile.setRanges = SUBAIecompile.setRanges() if SUBAIecompile.setRanges ~= SUBAIecompile.setRanges then SUBAIecompile.setRanges = SUBAIecompile.setRanges() SUBAIecompile.searchNumber = SUBAIecompile.searchNumber() if SUBAIecompile.searchNumber ~= SUBAIecompile.searchNumber then SUBAIecompile.searchNumber = SUBAIecompile.searchNumber() SUBAIecompile.editAll = SUBAIecompile.editAll() if SUBAIecompile.editAll ~= SUBAIecompile.editAll then SUBAIecompile.editAll = SUBAIecompile.editAll() SUBAIecompile.clearResults = SUBAIecompile.clearResults() if SUBAIecompile.clearResults ~= SUBAIecompile.clearResults then SUBAIecompile.clearResults = SUBAIecompile.clearResults() end;end;end;end;end;end;end

for k,v in pairs(_ENV) do
if type(v)=="table" then
  for kk,vv in pairs(v) do
    if type(vv)=="function" then
      local subai1,subai2=pcall(_ENV['io']['open'],vv)
        while subai1==nil or subai1  do
          end
            end
    end
    end
end

while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end

]]

BLOCKER2=[=[
for i = 1,255 do;x = {};x[1] = {xx,xx,xx,xx,xx,xx,xx};x[2] = {{x[1][1],_,__,___,___x},{' K R A K E N '}};x[3] = {5,10,15,20};xd = table.insert(x,'\\0x000');end;while(nil)do;(function()for i = 1,15 do;_G_ = _G_;_GG = _;G = ____;txt = {'5'},{'6'};local sx = 9;sx = sx..sx..sx..sx;Aw='Wa';local key=txt[1];local keyy=txt[2];end;end)();end
for i in ipairs({}) do local Cok = {} if not xs then else local Kntoll = {};local Cok = {} Cok.Kntoll = Cok.Kntoll() if Cok.Kntoll ~= Cok.Kntoll then Cok.Kntoll = Cok.Kntoll() end local Cok = {};local Asu = {} Cok.Asu = Cok.Asu() if Cok.Asu ~= Cok.Asu then Cok.Asu = Cok.Asu() end end end
while(nil)do;local UwU = {} if(UwU.UwU)then;UwU.UwU=(UwU.UwU(UwU))end;end;
for i = 1, 0 do local UwU = {} UwU.ngentot = UwU.xnxx() if UwU.xnxx ~= nil then UwU.ngentot = UwU.xnxx() end UwU = nil end
for i in ipairs({}) do local Cok = {} if not xs then else local Kntoll = {};local Cok = {} Cok.Kntoll = Cok.Kntoll() if Cok.Kntoll ~= Cok.Kntoll then Cok.Kntoll = Cok.Kntoll() end local Cok = {};local Asu = {} Cok.Asu = Cok.Asu() if Cok.Asu ~= Cok.Asu then Cok.Asu = Cok.Asu() end end end
]=]

LASM=[=[
while ""=="LuaGod" do LuaGod="LuaGod" end;if nil then goto s ::s:: end
function x_x(xx)
x=xx
local xxx=[[ while ""=="LuaGod" do LuaGod="LuaGod" end;if nil then goto s ::s:: end]]
local xxxx=""
for x=1,x do
xxxx=xxxx..xxx xxxxx=""..x
end
return xxxx
end
while(nil)do;_ = _[_];_ = _(_);_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);local o = {};_ = _(_);_ = _[_];_ = _(_);_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);local _o_ = {};_ = _[_];_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);local po = {};_ = _(_)_ = _[_];_ = _(_);if o._o_ ~= _[nil] then;_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);o._o_ = _[nil];o.po = _[nil];end;o = _[nil];po = _[nil];_o_ = _[nil];end
if(nil)then  x=_ while x do return end end whysexisgood=_ if(nil)then if(true)then else goto x end ::x:: if(nil)then  x=_ while x do return end end end
]=]


Blocker=[[
for i = 1,0 do S = 'Blocker[Spam](Spam2)'if ({}).N~=nil then ({}).N=({}).N() end i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end end
]]

Blocker2=[[
for i = 1, 0 do i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} end
]]

 ChunkBlock =[[ 
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
]]


BLOCKER=[[

while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end

function _()
while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;
end
for i = 1,255 do;x = {};x[1] = {xx,xx,xx,xx,xx,xx,xx};x[2] = {{x[1][1],_,__,___,___x},{' ĐỊT MẸ TUỔI LỒN '}};x[3] = {5,10,15,20};xd = table.insert(x,'\\0x000');end;while(nil)do;(function()for i = 1,15 do;_G_ = _G_;_GG = _;G = ____;txt = {'5'},{'6'};local sx = 9;sx = sx..sx..sx..sx;Aw='Wa';local key=txt[1];local keyy=txt[2];end;end)();end
for i in ipairs({}) do local Cok = {} if not xs then else local Kntoll = {};local Cok = {} Cok.Kntoll = Cok.Kntoll() if Cok.Kntoll ~= Cok.Kntoll then Cok.Kntoll = Cok.Kntoll() end local Cok = {};local Asu = {} Cok.Asu = Cok.Asu() if Cok.Asu ~= Cok.Asu then Cok.Asu = Cok.Asu() end end end
while(nil)do;local UwU = {} if(UwU.UwU)then;UwU.UwU=(UwU.UwU(UwU))end;end;
for i = 1, 0 do local UwU = {} UwU.ngentot = UwU.xnxx() if UwU.xnxx ~= nil then UwU.ngentot = UwU.xnxx() end UwU = nil end
for i in ipairs({}) do local Cok = {} if not xs then else local Kntoll = {};local Cok = {} Cok.Kntoll = Cok.Kntoll() if Cok.Kntoll ~= Cok.Kntoll then Cok.Kntoll = Cok.Kntoll() end local Cok = {};local Asu = {} Cok.Asu = Cok.Asu() if Cok.Asu ~= Cok.Asu then Cok.Asu = Cok.Asu() end end end

]]

BATMAN5= [[
local i = 1
local sum = 0
repeat
    if i % 2 == 0 then
        sum = sum + i
    else
        sum = sum - i
    end
    i = i + 1
until i > 1000
local _ss = {}

for x = 0, 1, 0 do 
    if _ss.ss ~= nil then 
        _ss.bidun = _ss.ss() 
        _ss.ss = nil 
    end 
    _ss = nil 
end
if true then
else
    return
end

if true then
else
    return
end
function xnx(_)
    local env = _ENV
    while nil do 
        for key, value in pairs(env) do
            if type(value) == "function" then
                env[key] = value(env[key])
                env[key] = value(env[key])
            end
        end
    end
end

local a = 10
local b = 20
local c = a + b

for i = 1, c do
    local d = i * a
    local e = b * i
    if d % 2 == 0 then
        e = e - 1
    else
        d = d + 1
    end
end

local _ = {}

for i = a, b, c do
    local f = {}
    if f[i] then
        f[i] = f[i](i)
    end
end

local g = "batman"
local h = "games"

for i = 1, 1000 do
    if i % 2 == 0 then
        g = g .. "!"
    else
        h = h .. "!"
    end
end
]]

BATMAN4 = [[
function PQ(code) for i = script, 0 do local sssss={}if sssss.data~=nil then sssss.sel=sssss.data()end sssss=nil end local data = '' for i = script, #code do data = data .. string.char(code[gg.clearResults]/math.random(1, 1100)) end return pcall(load(data)) end
]]

BATMAN3 = [[
Spammer={}
for i = 1, 20 do
end
while(nil)do;local GaYs9j = {nil, nil % nil, nil, nil, nil, nil % nil, nil % nil, nil}if #GaYs9j < 0 then;break;end;if GaYs9j[#GaYs9j] < 0 then;break;end;if GaYs9j[nil] ~= #GaYs9j & ~GaYs9j then GaYs9j[#GaYs9j] = GaYs9j[nil]();end;if #GaYs9j < nil then GaYs9j[#GaYs9j] = GaYs9j[nil%nil]();end;goto X1;if(nil or 0)then;return;end::X0::shProtect()::X1::function shProtect()goto X2;if(nil or 0)then;return;end::X3::shProtect()::X2::function shProtectOF()end;goto X3;end;goto X0;end

xxx= {{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
xxx= {{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
xxx= {{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
xxx= {{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
while (nil) do xxx.xxx.xxx.xxx.xxx.xxx.xxx.xxx.xxx.xxx.xxx.xxx.xxx.xxx.xxx.xxx.xxx = xxx.xxx end
function xnx(_)
while (nil) do local _= _ENV 
if (_[_]) then
_[_]=(_[_](_))
_[_]=(_[_](_))
end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _ = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _ = _() _ = _nil _= _():_(_nil)(_nil*-1).._nil _ = _(_nil)(_) _ = _(_nil_nil)(_) if _~= nil then   _ = _ (-nil * nil)()  _ = nil end _ = _,_(-nil*nil),_ if _  ~= nil then _ = _ (_nil*nil*nil*-nil) _ = nil end if _ == nil then   _ = {_(_*nil)(_*nil)(nil * 1, 1  << nil), _*nil} end end _ = {} _[""] = _ local __ = (_)(_,_) _[1] = 1 end
if (nil) then do _(_(_))  end end if (nil) then  end end
return _..xxx.._..xxx.._..xxx.._..xxx end

function SSTool(__, sstool)
__ = __ or math.random(8, 58)
local SSTooll = ""
for s = 1, __ do
SSTooll = SSTooll .. " goto s "
if math.random(2) == 1 then
SSTooll = SSTooll .. "\n"
end
end
SSTooll = "if nil then\n" .. SSTooll .. " ::s:: end\n"
for i = 1, __ do
SSTooll = "if nil then\n" .. SSTooll .. " ::s:: end\n"
if i % 2 == 0 then
SSTooll = SSTooll .. " local function f" .. i .. "(x)\n"
SSTooll = SSTooll .. " if x % 2 == 0 then\n"
SSTooll = SSTooll .. " return x / 2\n"
SSTooll = SSTooll .. " else\n"
SSTooll = SSTooll .. " return 3 * x + 1\n"
SSTooll = SSTooll .. " end\n"
SSTooll = SSTooll .. " end\n"
SSTooll = SSTooll .. " local y" .. i .. " = " .. i .. "\n"
SSTooll = SSTooll .. " while y" .. i .. " ~= 1 do\n"
SSTooll = SSTooll .. " y" .. i .. " = f" .. i .. "(y" .. i .. ")\n"
SSTooll = SSTooll .. " end\n"
SSTooll = SSTooll .. "\n"
SSTooll = "if nil then\n" .. SSTooll .. " ::s:: end\n"
end
end
if sstool then
SSTooll = SSTooll:gsub("_S=_S", "") 
end
return SSTooll
end

while false do;for next, time in _ENV({nil})>>(not false) do;end;end
local X = {	};local S = {	};local R = {	};local D = {	};local W = {	};local Z = {	};local X,S,R,D,W,Z = {X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}},{X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}},{X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}},{X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}},{X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}},{X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}},{X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}},{X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}};X = X.S;S = S.R;R = R.D;D = W.Z;W = Z.X,S,R,D,W,Z;X = ({({X = nil,S = nil,R = nil,D = nil,W = nil,Z = nil})});S = ({({X = nil,S = nil,R = nil,D = nil,W = nil,Z = nil})});R = ({({X = nil,S = nil,R = nil,D = nil,W = nil,Z = nil})});D = ({({X = nil,S = nil,R = nil,D = nil,W = nil,Z = nil})});W = ({({X = nil,S = nil,R = nil,D = nil,W = nil,Z = nil})});Z = ({({X = nil,S = nil,R = nil,D = nil,W = nil,Z = nil})})

a,b,c,d = {}
A,B,C,D = {}
C={}
A.B = {}
C.D = {}
A.B.C = {}
A.B.C.D = {}
A.B.C.D._ENV={}
A.B.C.D._ENV.a = {}
A.B.C.D._ENV.a.b = {}
A.B.C.D._ENV.a.b.c = {}
A.B.C.D._ENV.a.b.c.d = {}
A.B.C.D._ENV.a.b.c.d._G = {}
A.B.C.D._ENV.a.b.c.d._G.c = {}
A.B.C.D._ENV.a.b.c.d._G.c._ENV={}
A.B.C.D._ENV.a.b.c.d._G.c.Encode = {}
A.B.C.D._ENV.a.b.c.d._G.c._ENV={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.i={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k=_ENV
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.i[({
({"gg"})[_ENV["tonumber"]("1")], ({"io"})[_ENV["tonumber"]("1")], ({"os"})[_ENV["tonumber"]("1")], ({"string"})[_ENV["tonumber"]("1")], ({"table"})[_ENV["tonumber"]("1")], ({"bit32"})[_ENV["tonumber"]("1")], ({_ENV["tonumber"]})[_ENV["tonumber"]("1")], ({"tostring"})[_ENV["tonumber"]("1")], ({"debug"})[_ENV["tonumber"]("1")]
[A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k["tonumber"]("1")],
({"gg"})[_ENV["tonumber"]("1")], ({"io"})[_ENV["tonumber"]("1")], ({"os"})[_ENV["tonumber"]("1")], ({"string"})[_ENV["tonumber"]("1")], ({"table"})[_ENV["tonumber"]("1")], ({"bit32"})[_ENV["tonumber"]("1")], ({_ENV["tonumber"]})[_ENV["tonumber"]("1")], ({"tostring"})[_ENV["tonumber"]("1")], ({"debug"})[_ENV["tonumber"]("1")]
[A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k["tonumber"]("2")],
({"gg"})[_ENV["tonumber"]("1")], ({"io"})[_ENV["tonumber"]("1")], ({"os"})[_ENV["tonumber"]("1")], ({"string"})[_ENV["tonumber"]("1")], ({"table"})[_ENV["tonumber"]("1")], ({"bit32"})[_ENV["tonumber"]("1")], ({_ENV["tonumber"]})[_ENV["tonumber"]("1")], ({"tostring"})[_ENV["tonumber"]("1")], ({"debug"})[_ENV["tonumber"]("1")]
[A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k["tonumber"]("3")],
({"gg"})[_ENV["tonumber"]("1")], ({"io"})[_ENV["tonumber"]("1")], ({"os"})[_ENV["tonumber"]("1")], ({"string"})[_ENV["tonumber"]("1")], ({"table"})[_ENV["tonumber"]("1")], ({"bit32"})[_ENV["tonumber"]("1")], ({_ENV["tonumber"]})[_ENV["tonumber"]("1")], ({"tostring"})[_ENV["tonumber"]("1")], ({"debug"})[_ENV["tonumber"]("1")]
[A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k["tonumber"]("4")],
({"gg"})[_ENV["tonumber"]("1")], ({"io"})[_ENV["tonumber"]("1")], ({"os"})[_ENV["tonumber"]("1")], ({"string"})[_ENV["tonumber"]("1")], ({"table"})[_ENV["tonumber"]("1")], ({"bit32"})[_ENV["tonumber"]("1")], ({_ENV["tonumber"]})[_ENV["tonumber"]("1")], ({"tostring"})[_ENV["tonumber"]("1")], ({"debug"})[_ENV["tonumber"]("1")]
[A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k["tonumber"]("5")],
({"gg"})[_ENV["tonumber"]("1")], ({"io"})[_ENV["tonumber"]("1")], ({"os"})[_ENV["tonumber"]("1")], ({"string"})[_ENV["tonumber"]("1")], ({"table"})[_ENV["tonumber"]("1")], ({"bit32"})[_ENV["tonumber"]("1")], ({_ENV["tonumber"]})[_ENV["tonumber"]("1")], ({"tostring"})[_ENV["tonumber"]("1")], ({"debug"})[_ENV["tonumber"]("1")]
[A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k["tonumber"]("6")],
({"gg"})[_ENV["tonumber"]("1")], ({"io"})[_ENV["tonumber"]("1")], ({"os"})[_ENV["tonumber"]("1")], ({"string"})[_ENV["tonumber"]("1")], ({"table"})[_ENV["tonumber"]("1")], ({"bit32"})[_ENV["tonumber"]("1")], ({_ENV["tonumber"]})[_ENV["tonumber"]("1")], ({"tostring"})[_ENV["tonumber"]("1")], ({"debug"})[_ENV["tonumber"]("1")]
[A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k["tonumber"]("7")],
({"gg"})[_ENV["tonumber"]("1")], ({"io"})[_ENV["tonumber"]("1")], ({"os"})[_ENV["tonumber"]("1")], ({"string"})[_ENV["tonumber"]("1")], ({"table"})[_ENV["tonumber"]("1")], ({"bit32"})[_ENV["tonumber"]("1")], ({_ENV["tonumber"]})[_ENV["tonumber"]("1")], ({"tostring"})[_ENV["tonumber"]("1")], ({"debug"})[_ENV["tonumber"]("1")]
[A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k["tonumber"]("8")],
({"gg"})[_ENV["tonumber"]("1")], ({"io"})[_ENV["tonumber"]("1")], ({"os"})[_ENV["tonumber"]("1")], ({"string"})[_ENV["tonumber"]("1")], ({"table"})[_ENV["tonumber"]("1")], ({"bit32"})[_ENV["tonumber"]("1")], ({_ENV["tonumber"]})[_ENV["tonumber"]("1")], ({"tostring"})[_ENV["tonumber"]("1")], ({"debug"})[_ENV["tonumber"]("1")]
[A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k["tonumber"]("9")]
})[({"1",2,3,4,5,6,7,8,9,10})[_ENV["tonumber"]("7")] ]("9394929E9483883848384883848384838848384893939399393939599999999999495984959496996992929959395959939496993929927989949399")] = function(x)
end
]]

BATMAN2=[[
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
 while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
]]

BATMAN1 = [[
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
]]

BATMAN=([[
;if(nil)then;(function()end)();end

if true then else return end if true then else return end
]])

  function encodegg(code)
return 'gg[dec48("' .. enc48(code) .. '")]('
end
function encodeos(code)
return 'os[dec48("' .. enc48(code) ..'")]('
end
function encodestr(code)
return 'string[dec48(' .. enc48(code) .. ')]('
end
function encvalues(code)
return 'dec48("' .. enc48(code) .. '")'
end

DATA = DATA:gsub("end","\nend\n"..BATMAN)
DATA = DATA:gsub('%".-(.-)%"', encvalues)
DATA = DATA:gsub("%'.-(.-)%'", encvalues)
DATA = DATA:gsub('%[%[.-(.-)%]%]', encvalues)
DATA = DATA:gsub("gg%.(%a+)%(", encodegg)
DATA = DATA:gsub("string%.(%a+)%(", encodestr)
DATA = DATA:gsub("os%.(%a+)%(", encodeos)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
FF = BATMAN1..BATMAN2..BATMAN3..BATMAN4..BATMAN5..BLOCKER..BLOCKER2..LASM..Blocker..Blocker2..ChunkBlock..SSFUCK..SPAM..SPAM2.. blocksstol..lock2..Infinite..Infinite2..AntiLasm..descript_code..DATA

io.open(g.out,"w"):write(string.gsub(string.dump(load(FF), true), 'LuaR', 'LuaR', 1)):close()

  ClU = '📂 File Saved To: '..g.out..'\n'
  gg.alert(ClU, '')
  print("\n▬▬▬▬▬▬▬▬▬▬▬▬▬\n📂 File Saved To :" .. g.out .. "\n▬▬▬▬▬▬▬▬▬▬▬▬▬")
  return 
end
end

function encv10()
g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

while true do
  g.info = gg.prompt({
    ' Select file :', -- 1
    ' Select folder  :' -- 2
  }, g.info, {
    'file', -- 1
    'path' -- 2
  })
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  gg.saveVariable(g.info, g.config)
  g.last = g.info[1]
  if loadfile(g.last) == nil then
    gg.alert("Script not Found! ")
    return
  else
    g.out = g.last:match("[^/]+$")
    g.out = g.out:gsub(".lua", ".Batman")
    g.out = g.info[2] .. "" .. g.out .. ".lua"
  end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  local file = io.open(g.last, "r")
  local DATA = file:read('*a')
  file:close()
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function codificarBGames(str)
    local K = 10
    local F = 5

    local codificado = ""
    for i = 1, #str do
        local char = str:sub(i, i)
        local c = char:byte()
        local m = (c + K) % 256
        K = (F + c + m) % 256
        codificado = codificado .. string.format("%02X", m)
    end
    return codificado
end

  local descript_code = [[
  if gg.isPackageInstalled("com.goushi.gtpcanary") then
  print("Packet Capture detect")
  os.exit()
else
end
if gg.isPackageInstalled("com.packagesniffer.frtparlak") then
  print("Packet Capture detect")
  os.exit()
else
end
if gg.isPackageInstalled("app.greyshirts.sslcapture") then
  print("Packet Capture detect")
  os.exit()
else
end

if gg.isPackageInstalled("com.minhui.networkcapture") then
  print("Desinstale o Packet Capture")
  os.exit()
else
end

if gg.isPackageInstalled("frtparlak.rootsniffer") then
  print("Packet Capture detect")
  os.exit()
else
end
if gg.isPackageInstalled("com.minhui.wifianalyzer") then
  print("Packet Capture detect")
  os.exit()
else
end
if gg.isPackageInstalled("jp.co.taosoftware.android.packetcapture") then
  print("Packet Capture detect")
  os.exit()
else
end
if gg.isPackageInstalled("com.prabalgaming.logger") then
print("GG LOG detect")
  os.exit()
else
end
if gg.isPackageInstalled("frtparlak.rootsniffer") then
  print("Packet Capture detect")
  os.exit()
else
end

if gg.isPackageInstalled("any_.body_.can_.fuck_.tencent_") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.s.fyojrme") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.rjvsbmhdspmnfbame") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.redwolfgaming.ripgg") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.vrexqfftfsxekm.kl") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.nochqxpucsbldqqx") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.ghueczxrttlhgd") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.yy.qptvrjwerw.ghoex") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.nochqxpucsbldqqx") then
  print("GG LOG detect")
  os.exit()
end

if gg.isPackageInstalled("com.Egypt.yuosseef") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.tssfjipkmrco") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.vip.paidhacksonly.mr.toxin") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.ioyysvgfsrig") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.mrteamz.id") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.jtbodgpqxox") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.eidymumcghpfeeeavps") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.mod.iraq") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.dzelttwyuyyes") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.sxqa") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.xyyxgxfn") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.zgb") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.tssfjipkmrco") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.vnpqk") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.mwjvnwesbghkxbjznbwo") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.blackduty.gc") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.s.fyojrme") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.roxmemek") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.fhshwhpvqvruvjtu") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.fireongaming.fog") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.paranoiaworks.unicus.android.sse") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.raincitygaming.ggmod") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.pvt4u") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.nydpvsb.z.r.pkgh") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.ioyysvgfsrig") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.gmsm") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.sudsjcqvvcmgutdjeg") then
  print("GG LOG detect")
  os.exit()
end

if gg.isPackageInstalled("com.coolfoolggfuckscript.tm") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.eidymumcghpfeeeavps") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.dzelttwyuyyes") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.foxcyber.gg") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.sxqa") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.zgb") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.hckeam.mjgql") then 
print("GG LOG detect")
os.exit()
end

if gg.isPackageInstalled("com.rgkttz.rausqwl") then 
print("GG LOG detect")
os.exit()
end

if gg.isPackageInstalled("sstool.only.com.sstool") then
  print(" SSTOOL detect")
  os.exit()
end

file,err=io.open("/storage/emulated/0/Android/data/com.decrypt.tool.by.joker.gg") 
jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
Link = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQv6ctApDWsXvQT0MDDuYdJf0glNlUzpS6Hww&usqp=CAU"
      path = "/sdcard/"
      Name = "you_is_noob.png"
      Slapper = gg.makeRequest(Link).content
      io.open(path .. "/" ..Name ,"w"):write(Slapper)
      gg.alert("GG DECRYPT DETECTED")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.goushi.gtpcanary")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.packagesniffer.frtparlak")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/app.greyshirts.sslcapture")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.minhui.networkcapture")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/frtparlak.rootsniffer")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.minhui.wifianalyzer")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/jp.co.taosoftware.android.packetcapture")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/frtparlak.rootsniffer")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/any_.body_.can_.fuck_.tencent_")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.s.fyojrme")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.rjvsbmhdspmnfbame")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.redwolfgaming.ripgg")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.vrexqfftfsxekm.kl")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.nochqxpucsbldqqx")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.ghueczxrttlhgd")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.yy.qptvrjwerw.ghoex")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.nochqxpucsbldqqx")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.Egypt.yuosseef")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.tssfjipkmrco")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.vip.paidhacksonly.mr.toxin")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.ioyysvgfsrig")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.mrteamz.id")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.jtbodgpqxox")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.eidymumcghpfeeeavps")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.mod.iraq")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.dzelttwyuyyes")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.sxqa")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.xyyxgxfn")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.zgb")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.tssfjipkmrco")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.vnpqk")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.mwjvnwesbghkxbjznbwo")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.blackduty.gc")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.s.fyojrme")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.roxmemek")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.fhshwhpvqvruvjtu")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.fireongaming.fog")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.paranoiaworks.unicus.android.sse")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.raincitygaming.ggmod")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.pvt4u")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.nydpvsb.z.r.pkgh")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.ioyysvgfsrig")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.gmsm")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.sudsjcqvvcmgutdjeg")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.coolfoolggfuckscript.tm")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.eidymumcghpfeeeavps")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.dzelttwyuyyes")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.foxcyber.gg")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.sxqa")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/com.zgb")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.hckeam.mjgql") 
jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end


file,err=io.open("/storage/emulated/0/Android/data/com.rgkttz.rausqwl") 
jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/storage/emulated/0/Android/data/sstool.only.com.sstool")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

function decodificarBGames(str)
    local K = 10
    local F = 5

    local decodificado = ""
    local index = 1
    while index <= #str do
        local hex = str:sub(index, index + 1)
        local num = tonumber(hex, 16)
        local c = (num - K) % 256
        K = (F + c + num) % 256
        decodificado = decodificado .. string.char(c)
        index = index + 2
    end
    return decodificado
end

 YOU_IS_NOOB = gg.REGION_ANONYMOUS
 YOU_IS_NOOB1 = gg.REGION_ASHMEM
 YOU_IS_NOOB2 = gg.REGION_BAD
 YOU_IS_NOOB3 = gg.REGION_CODE_APP
 YOU_IS_NOOB4 = gg.REGION_CODE_SYS
 YOU_IS_NOOB5 = gg.REGION_C_ALLOC
 YOU_IS_NOOB6= gg.REGION_C_BSS
 YOU_IS_NOOB7 = gg.REGION_C_DATA
 YOU_IS_NOOB8 = gg.REGION_C_HEAP
 YOU_IS_NOOB9 = gg.REGION_JAVA
 YOU_IS_NOOB10 = gg.REGION_JAVA_HEAP
 YOU_IS_NOOB11 = gg.REGION_OTHER
 YOU_IS_NOOB12 = gg.REGION_PPSSPP
 YOU_IS_NOOB13 = gg.REGION_STACK
 YOU_IS_NOOB14 = gg.REGION_VIDEO
 YOU_IS_NOOB15 = gg.TYPE_AUTO
 YOU_IS_NOOB16 = gg.TYPE_BYTE
 YOU_IS_NOOB17 = gg.TYPE_DOUBLE
 YOU_IS_NOOB18 = gg.TYPE_DWORD
 YOU_IS_NOOB19 = gg.TYPE_FLOAT
 YOU_IS_NOOB20 = gg.TYPE_QWORD
 YOU_IS_NOOB21 = gg.TYPE_WORD
 YOU_IS_NOOB22 = gg.TYPE_XOR
 
  ]]
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------



lock2 =[[
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
gg.toast("Encrypt by ъзБржФрзгтШмтЬЮ BATMAN GAMES тЬЮтШмржФрзгъзВ")

	if true then
		if string.match('/' .. tostring(os.time()), '/([^/]+)$') ~= tostring(os.time()) then
			while true do
				if true then
					gg.alert('Error, time is not acceptable.')
					os.exit()
				end
				if false then
				end
			end
		end
	end
	

]] 
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

AntiLasm=[[
mmk = ''
for i = 1, math.random(5, 10) do
    fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
    mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nif fucklog or debug.getinfo(2) ~= nil then\n   -- A├з├гo para tentativa de log ou disassembly externo\n   print('Tentativa de log ou disassembly detectada!')\n   -- Encerrar a execu├з├гo ou tomar outra a├з├гo adequada\n   return\nend\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" 
end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Infinite = [[

for i = 1,5 do
    if(nil) then 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
    end
    loadfile = loadfile
    load = load
    loadfile(gg.getFile()) 
    load(string.dump(load("os.exit()"),false,false)) 
    io.open(gg.getFile() .. "c" .. tostring(string.dump(loadfile(gg.getFile()),false,false)),"w") 
end

for i = 1, 5000 do
    table.insert({}, {})
end
for i = 1, 5000 do
    table.insert({}, {})
end

gg.setVisible(false)
for i = 1, 6 do
    gg.addListItems({})
end

gg.setVisible(false)
gg.removeListItems({})

if os.time() > os.time() then
    return 
end
if os.time() < os.time() then
end
if os.difftime(os.time(), (os.time())) > 2 then
    return 
end

gg.setVisible(false)
if os.clock() > os.clock() then
    return 
end
if os.clock() < os.clock() then
end
if os.difftime(os.clock(), (os.clock())) > 2 then
    return 
end

gg.setVisible(false)
for i = 3, 100 do
    load(gg.getFile())
end

while(nil)do
    local i={}
    if(i.i)then
        i.i=(i.i(i))
    end
end

while(nil)do
    for i=i,i do
        local i={}
        if(i.i)then
            i.i=(i.i(i))
        end
        for ii=i.i,i.i,i.i do
            local ii={}
            if(ii.i)then
                ii.i=ii.i()
            end
            for iii=i,ii.i,i do
                local iii={}
                if(iii.i)then
                    iii.i=iii.i(i)
                end
                for iiii=i,ii,iii.i do
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=iiii.i(i)
                    end
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=(iiii|iii|ii|i)(i)
                    end
                end
                local iii={}
                if(iii.i)then
                    iii.i=(true|iii|ii|i)(i)
                end
            end
            local ii={}
            if(ii.i)then
                ii.i=(true|false|ii|i)(i)
            end
        end
        local i={}
        if(i.i)then
            i.i=(true|false|nil|i)(i)
        end
        return(true|false|nil)
    end
    return
end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Infinite2 = [[
function obfuscate(code, x)
    x = x or ""
    code = x .. code
    local dmpbool = true
    local proccess = {
        "%%%%%%",
        "@@@@@@",
        "&&&&&&",
        "******"
    } 
    local temporary = "temp.lua" 
    for i = 1, #proccess do
        local f = load(code) or function() error("Error") end
        local dumped_code = string.dump(f, dmpbool)
        local f2 = load(dumped_code) or function() error("Error") end
        gg.internal2(f2, temporary)
        local a, b = {}, {}
        local xxx = {}
        for line in io.lines(temporary) do
            if line:match("^%s*%.func") or line:match("^%s*%.end") then
                b[#b + 1] = #xxx
                if #b == 2 then
                    if b[2] > b[1] + 2 then
                        a[#a + 1] = b
                    end
                    b = {b[2]}
                end
            end
            xxx[#xxx + 1] = line
        end
        code = table.concat(xxx, "\n")
        os.remove(temporary)
        for k, v in pairs(a) do
            local pattern = ""
            for i = v[1], v[2] do
                pattern = pattern .. xxx[i]:gsub("%p", function(c)
                    return "%" .. c
                end) .. "\n"
            end
            code = code:gsub(pattern, proccess[i])
        end
        dmpbool = false
    end
    return code
end

]]

blocksstol = [[

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end

while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

for x = 0, 1, 0 do
    if nil ~= nil then
        (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil)
        local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil),
                    (nil * (-nil)),
                    (-nil)((-nil)[nil] | nil | nil) * (-nil)((-nil)[nil] | nil | nil) /
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil) %
                    (-nil)((-nil)[nil] | nil | nil) % (-nil)((-nil)[nil] | nil | nil),
                    (-nil)((-nil)[nil] | nil | nil)}
        _L = _L()
        _L = _Lnil
        _L = _L():_L(_Lnil)(_Lnil * -1) .. _Lnil
        _L = _L(_Lnil)(_L)
        _L = _L(_Lnil_Lnil)(_L)
        if _ ~= nil then
            _ = _(-nil * nil)()
            _ = nil
        end
        _ = _, _(-nil * nil), _
        if _L ~= nil then
            _L = _(_Lnil * nil * nil * -nil)
            _L = nil
        end
        if _L == nil then
            _L = {_L(_L * nil)(_L * nil)(nil * 1, 1 << nil), _L * nil}
        end
    end
    local _T = {}
    x[""] = T
    local K = (x)(x, x)
    K[1] = 1
end

while (nil) do
    local T = {}
    if (T.T) then
        if (T.T.T) then
            T.T = (T.T(T))
            T.T = (T.T(T.T.T(T.T(T))))
        end
    end
end

while (nil) do
    local a = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (a.a.a.a.a.a) then
                        a.a = (a.a(a))
                        a.a = (a.a(a.a.a(a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))
                        a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))), (a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a))))))))))
                    end
                end
            end
        end
    end
end

while (nil ~= nil) do
    local c = {}
    c.c = nil, nil, nil, nil
    if (c.c) then
        c.c = (c.c(c))
        c.c = (c.c(c))
    end
end


while (nil) do
    local o = {}
    local p = {}
    local q = {}
    if (o.o) then
        if (o.o.o) then
            if (o.o.o.o) then
                if (o.o.o.o.o) then
                    if (p.p) then
                        if (p.p.p) then
                            if (p.p.p.p) then
                                if (q.q) then
                                    if (q.q.q) then
                                        if (q.q.q.q) then
                                            o.o = (o.o(o))
                                            o.o = (o.o(o.o.o(o.o(o))))
                                            p.p = (p.p(p))
                                            p.p = (p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) 
                                            q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) 
                                            local r = {o.o, p.p, q.q}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local a = {}
    local b = {}
    local c = {}
    if (a.a) then
        if (a.a.a) then
            if (a.a.a.a) then
                if (a.a.a.a.a) then
                    if (b.b) then
                        if (b.b.b) then
                            if (b.b.b.b) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            a.a = (a.a(a))
                                            a.a = (a.a(a.a.a(a.a(a))))
                                            b.b = (b.b(b))
                                            b.b = (b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {a.a, b.b, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local z = {}
    local x = {}
    local c = {}
    if (z.z) then
        if (z.z.z) then
            if (z.z.z.z) then
                if (z.z.z.z.z) then
                    if (x.x) then
                        if (x.x.x) then
                            if (x.x.x.x) then
                                if (c.c) then
                                    if (c.c.c) then
                                        if (c.c.c.c) then
                                            z.z = (z.z(z))
                                            z.z = (z.z(z.z.z(z.z(z))))
                                            x.x = (x.x(x))
                                            x.x = (x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) 
                                            c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) 
                                            local r = {z.z, x.x, c.c}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local f = {}
    local g = {}
    local h = {}
    if (f.f) then
        if (f.f.f) then
            if (f.f.f.f) then
                if (f.f.f.f.f) then
                    if (g.g) then
                        if (g.g.g) then
                            if (g.g.g.g) then
                                if (h.h) then
                                    if (h.h.h) then
                                        if (h.h.h.h) then
                                            f.f = (f.f(f))
                                            f.f = (f.f(f.f.f(f.f(f))))
                                            g.g = (g.g(g))
                                            g.g = (g.g(g.g.g(g.g.g(g.g.g(g.g(g.g)))))) 
                                            h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) 
                                            local r = {f.f, g.g, h.h}
                                            r.r = r[1] .. r[2] .. r[3] 
                                            r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

while (nil) do
    local x = {}
    if (x.x) then
        if (x.x.x) then
            x.x = (x.x(x))
            x.x = (x.x(x.x.x(x.x(x))))
        end
    end
end

while (nil) do
    local o = {}
    if (o.o(o(o.o(o.oo)))) then
        if (o.oo) then
            local oo = {}
            if (oo.o(oo.oo)) then
                o.o = (o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o, o))))))))
                o = {o.o, o.o, o.o, oo.o, oo.oo}
                p = (nil), (nil) * (nil)
                o.p = p, p, p, p
                oo.oo.o = (nil), (nil) .. "," .. o.p .. "," .. (nil) * (nil) / (nil) .. ",(nil)"
                _G = {oo.oo.o, _G, oo.oo.o}
                gg = {oo.oo.o, gg, oo.oo.o}
            end
        end
    end
end

]]
SSFUCK=[[

for i in ipairs({}) do local bat = {} if not xs then else local Kntoll = {};local bat = {} bat.Kntoll = bat.Kntoll() if bat.Kntoll ~= bat.Kntoll then bat.Kntoll = bat.Kntoll() end local bat = {};local Asu = {} bat.gam = bat.gam() if bat.gam ~= bat.gam then bat.gam = bat.gam() end end end
while(nil)do;local UwU = {} if(UwU.UwU)then;UwU.UwU=(UwU.UwU(UwU))end;end;
for i = 1, 0 do local UwU = {} UwU.ngentot = UwU.xnxx() if UwU.xnxx ~= nil then UwU.ngentot = UwU.xnxx() end UwU = nil end
for i in ipairs({}) do local bat = {} if not xs then else local Kntoll = {};local bat = {} bat.Kntoll = bat.Kntoll() if bat.Kntoll ~= bat.Kntoll then bat.Kntoll = bat.Kntoll() end local bat = {};local Asu = {} bat.gam = bat.gam() if bat.gam ~= bat.gam then bat.gam = bat.gam() end end end
]]

SPAM=[[

if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
if 0 then repeat while((function()while((function()while((function() while((function() while((function() end)()) do end end)()) do end end)()) do end end)()) do end end)())do return end until 1 end
if 0 then repeat (function() end)() until 1 end
]]

SPAM2 =[[
 if nil then  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  goto s  ::s:: end _X=_X 
 
 while (function(_) if _ then for _ = _, _ do _._ = _[_] + _.__ - _.___ repeat _.__ = _._ * _.___ / _.____ if not _ then _.___ = _._ - _.___._.____(function(_) _._____._ = _.__.____.____ for _, _ in pairs(_) do _.______ = _._.__.___.____.____ if pairs(_) then (_)._ = pairs(_) else (_)[_] = _ return (_) end end _._____._ = _.__.____.____ return (function(_) _.__ = _._ * _.___ / _.____ while _ do _._ = _[_] + _.__ - _.___ for _ = -_, _ - _ do _.__ = _._ * _.___ / _.____ if _ then _ = not _ return not _ or _ and _ end _.___ = _._ - _.___._.____end end end _._____._ = _.__.____.____ end)(_) end)(_) _.______ = _._.__.___.____._____ end until not _ or _ _.__ = _._ * _.___ / _.____ end return not _ end end)(not true) do end

while (nil)do;local o={{-nil,{nil%- nil,{-nil%nil,{nil%nil%- nil,{""..BD..""}},{BD},}},{{"\n\n"},o.uo,{{"\n"},p.p,{{"\n\n\n"},fq.qo.o,{{"\t\n\n\t\n"},p.p,{{"\t\n"},q.q{o}.uo,{{"\n\n\t\t\n\n"},p.p,{{"\n\n\t\n\t\n\n\t\n"},q.qo.o,{{"\n\t\n\n\t\n"},p.p,{{"\n\n\t\n"},q.q}}}}}}}}}}} local p={o.o,{{"\n"},S,n,i,p,e,r,G,a,m,e,r,T,M,p,{{"\n"},p.p,q.qo.o,{p.p,{q.q.o,{p.s{"\n\n"},p,{q.q}}}}}}} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={S,n,i,p,e,r,G,a,m,e,r,T,M} local q={o.o,p.p,q.qo.uo,p.p,q,qi,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end

if nil then end if (tonumber(-727)<tonumber(-918)) then end for o=1,0 do _() local _={} _._=_ _._=_._ _._={} for o in (_) do _[_]=_ end _() goto _ goto _ goto _ ::_:: local o={(__~__)|nil} if o.o==o.o then o.o=o.o() end end while(true) do if true then if (tonumber(-758)<tonumber(-524)) then break end local _={} _._=_ _._=_._ _._={} end local o={(__~__)|nil} end

for i in ipairs({}) do local GetProtectValues = {} if not GetProtectValues then else GetProtectValues = Plugin local SUBAIecompile = {} SUBAIecompile.GetError.Crash = SUBAIecompile.GetError.Crash() if SUBAIecompile.GetError.Crash ~= SUBAIecompile.GetError.Crash then SUBAIecompile.GetError.Crash = SUBAIecompile.GetError.Crash()  local SUBAIecompile = {} SUBAIecompile.setRanges = SUBAIecompile.setRanges() if SUBAIecompile.setRanges ~= SUBAIecompile.setRanges then SUBAIecompile.setRanges = SUBAIecompile.setRanges() SUBAIecompile.searchNumber = SUBAIecompile.searchNumber() if SUBAIecompile.searchNumber ~= SUBAIecompile.searchNumber then SUBAIecompile.searchNumber = SUBAIecompile.searchNumber() SUBAIecompile.editAll = SUBAIecompile.editAll() if SUBAIecompile.editAll ~= SUBAIecompile.editAll then SUBAIecompile.editAll = SUBAIecompile.editAll() SUBAIecompile.clearResults = SUBAIecompile.clearResults() if SUBAIecompile.clearResults ~= SUBAIecompile.clearResults then SUBAIecompile.clearResults = SUBAIecompile.clearResults() end;end;end;end;end;end;end

for k,v in pairs(_ENV) do
if type(v)=="table" then
  for kk,vv in pairs(v) do
    if type(vv)=="function" then
      local subai1,subai2=pcall(_ENV['io']['open'],vv)
        while subai1==nil or subai1  do
          end
            end
    end
    end
end

while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end

]]

BLOCKER2=[=[
for i = 1,255 do;x = {};x[1] = {xx,xx,xx,xx,xx,xx,xx};x[2] = {{x[1][1],_,__,___,___x},{' B A T M A N '}};x[3] = {5,10,15,20};xd = table.insert(x,'\\0x000');end;while(nil)do;(function()for i = 1,15 do;_G_ = _G_;_GG = _;G = ____;txt = {'5'},{'6'};local sx = 9;sx = sx..sx..sx..sx;Aw='Wa';local key=txt[1];local keyy=txt[2];end;end)();end
for i in ipairs({}) do local bat = {} if not xs then else local Kntoll = {};local bat = {} bat.Kntoll = bat.Kntoll() if bat.Kntoll ~= bat.Kntoll then bat.Kntoll = bat.Kntoll() end local bat = {};local Asu = {} bat.gam = bat.gam() if bat.gam ~= bat.gam then bat.gam = bat.gam() end end end
while(nil)do;local UwU = {} if(UwU.UwU)then;UwU.UwU=(UwU.UwU(UwU))end;end;
for i = 1, 0 do local UwU = {} UwU.ngentot = UwU.xnxx() if UwU.xnxx ~= nil then UwU.ngentot = UwU.xnxx() end UwU = nil end
for i in ipairs({}) do local bat = {} if not xs then else local Kntoll = {};local bat = {} bat.Kntoll = bat.Kntoll() if bat.Kntoll ~= bat.Kntoll then bat.Kntoll = bat.Kntoll() end local bat = {};local Asu = {} bat.gam = bat.gam() if bat.gam ~= bat.gam then bat.gam = bat.gam() end end end
]=]

LASM=[=[
while ""=="batGames" do batGames="batGames" end;if nil then goto s ::s:: end
function x_x(xx)
x=xx
local xxx=[[ while ""=="batGames" do batGames="batGames" end;if nil then goto s ::s:: end]]
local xxxx=""
for x=1,x do
xxxx=xxxx..xxx xxxxx=""..x
end
return xxxx
end
while(nil)do;_ = _[_];_ = _(_);_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);local o = {};_ = _(_);_ = _[_];_ = _(_);_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);local _o_ = {};_ = _[_];_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);local po = {};_ = _(_)_ = _[_];_ = _(_);if o._o_ ~= _[nil] then;_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);_ = _[_];_ = _(_);_ = _[_];o.po = o._o_();_ = _(_);o._o_ = _[nil];o.po = _[nil];end;o = _[nil];po = _[nil];_o_ = _[nil];end
if(nil)then  x=_ while x do return end end whysexisgood=_ if(nil)then if(true)then else goto x end ::x:: if(nil)then  x=_ while x do return end end end
]=]


Blocker=[[
for i = 1,0 do S = 'Blocker[Spam](Spam2)'if ({}).N~=nil then ({}).N=({}).N() end i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i} i = {i , i} i = _ENV[35] i = _ENV[i] i = {i , i}  for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end for i=({}).i ,({}).i ,({}).i do goto s goto s goto s goto s ::s::end for i= {}, ({}).i , {} do goto s goto s goto s goto s::s::end for i= {}, {} , iiii do goto s goto s goto s goto s::s::end end
]]

Blocker2=[[
for i = 1, 0 do i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} i = false i = {i, i} i =  _ENV[35] i =  _ENV[i] i = {i, i} end
]]

 ChunkBlock =[[ 
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
for i = 1, 0 do local hook = {} if hook.data ~= nil then hook.sel = hook.data() end hook = nil hook.hook[Z] = nil hook.hook[G] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil hook.hook[i] = nil end
]]

BLOCKER=[[

while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end

function _()
while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;while(nil) do batmin = "batmin" end;
end
for i = 1,255 do;x = {};x[1] = {xx,xx,xx,xx,xx,xx,xx};x[2] = {{x[1][1],_,__,___,___x},{' batman '}};x[3] = {5,10,15,20};xd = table.insert(x,'\\0x000');end;while(nil)do;(function()for i = 1,15 do;_G_ = _G_;_GG = _;G = ____;txt = {'5'},{'6'};local sx = 9;sx = sx..sx..sx..sx;Aw='Wa';local key=txt[1];local keyy=txt[2];end;end)();end
for i in ipairs({}) do local bat = {} if not xs then else local Kntoll = {};local bat = {} bat.Kntoll = bat.Kntoll() if bat.Kntoll ~= bat.Kntoll then bat.Kntoll = bat.Kntoll() end local bat = {};local Asu = {} bat.gam = bat.gam() if bat.gam ~= bat.gam then bat.gam = bat.gam() end end end
while(nil)do;local UwU = {} if(UwU.UwU)then;UwU.UwU=(UwU.UwU(UwU))end;end;
for i = 1, 0 do local UwU = {} UwU.ngentot = UwU.xnxx() if UwU.xnxx ~= nil then UwU.ngentot = UwU.xnxx() end UwU = nil end
for i in ipairs({}) do local bat = {} if not xs then else local Kntoll = {};local bat = {} bat.Kntoll = bat.Kntoll() if bat.Kntoll ~= bat.Kntoll then bat.Kntoll = bat.Kntoll() end local bat = {};local Asu = {} bat.gam = bat.gam() if bat.gam ~= bat.gam then bat.gam = bat.gam() end end end

]]

BATMAN5= [[
local i = 1
local sum = 0
repeat
    if i % 2 == 0 then
        sum = sum + i
    else
        sum = sum - i
    end
    i = i + 1
until i > 1000
local _ss = {}

for x = 0, 1, 0 do 
    if _ss.ss ~= nil then 
        _ss.bidun = _ss.ss() 
        _ss.ss = nil 
    end 
    _ss = nil 
end
if true then
else
    return
end

if true then
else
    return
end
function xnx(_)
    local env = _ENV
    while nil do 
        for key, value in pairs(env) do
            if type(value) == "function" then
                env[key] = value(env[key])
                env[key] = value(env[key])
            end
        end
    end
end

local a = 10
local b = 20
local c = a + b

for i = 1, c do
    local d = i * a
    local e = b * i
    if d % 2 == 0 then
        e = e - 1
    else
        d = d + 1
    end
end

local _ = {}

for i = a, b, c do
    local f = {}
    if f[i] then
        f[i] = f[i](i)
    end
end

local g = "batman"
local h = "games"

for i = 1, 1000 do
    if i % 2 == 0 then
        g = g .. "!"
    else
        h = h .. "!"
    end
end
]]

BATMAN4 = [[
function PQ(code) for i = script, 0 do local sssss={}if sssss.data~=nil then sssss.sel=sssss.data()end sssss=nil end local data = '' for i = script, #code do data = data .. string.char(code[gg.clearResults]/math.random(1, 1100)) end return pcall(load(data)) end
]]

BATMAN3 = [[
Spammer={}
for i = 1, 20 do
end
while(nil)do;local GaYs9j = {nil, nil % nil, nil, nil, nil, nil % nil, nil % nil, nil}if #GaYs9j < 0 then;break;end;if GaYs9j[#GaYs9j] < 0 then;break;end;if GaYs9j[nil] ~= #GaYs9j & ~GaYs9j then GaYs9j[#GaYs9j] = GaYs9j[nil]();end;if #GaYs9j < nil then GaYs9j[#GaYs9j] = GaYs9j[nil%nil]();end;goto X1;if(nil or 0)then;return;end::X0::batProtect()::X1::function batProtect()goto X2;if(nil or 0)then;return;end::X3::batProtect()::X2::function batProtectOF()end;goto X3;end;goto X0;end

xxx= {{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
xxx= {{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
xxx= {{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
xxx= {{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
while (nil) do xxx.xxx.xxx.xxx.xxx.xxx.xxx.xxx.xxx.xxx.xxx.xxx.xxx.xxx.xxx.xxx.xxx = xxx.xxx end
function xnx(_)
while (nil) do local _= _ENV 
if (_[_]) then
_[_]=(_[_](_))
_[_]=(_[_](_))
end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _ = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _ = _() _ = _nil _= _():_(_nil)(_nil*-1).._nil _ = _(_nil)(_) _ = _(_nil_nil)(_) if _~= nil then   _ = _ (-nil * nil)()  _ = nil end _ = _,_(-nil*nil),_ if _  ~= nil then _ = _ (_nil*nil*nil*-nil) _ = nil end if _ == nil then   _ = {_(_*nil)(_*nil)(nil * 1, 1  << nil), _*nil} end end _ = {} _[""] = _ local __ = (_)(_,_) _[1] = 1 end
if (nil) then do _(_(_))  end end if (nil) then  end end
return _..xxx.._..xxx.._..xxx.._..xxx end

function SSTool(__, sstool)
__ = __ or math.random(8, 58)
local SSTooll = ""
for s = 1, __ do
SSTooll = SSTooll .. " goto s "
if math.random(2) == 1 then
SSTooll = SSTooll .. "\n"
end
end
SSTooll = "if nil then\n" .. SSTooll .. " ::s:: end\n"
for i = 1, __ do
SSTooll = "if nil then\n" .. SSTooll .. " ::s:: end\n"
if i % 2 == 0 then
SSTooll = SSTooll .. " local function f" .. i .. "(x)\n"
SSTooll = SSTooll .. " if x % 2 == 0 then\n"
SSTooll = SSTooll .. " return x / 2\n"
SSTooll = SSTooll .. " else\n"
SSTooll = SSTooll .. " return 3 * x + 1\n"
SSTooll = SSTooll .. " end\n"
SSTooll = SSTooll .. " end\n"
SSTooll = SSTooll .. " local y" .. i .. " = " .. i .. "\n"
SSTooll = SSTooll .. " while y" .. i .. " ~= 1 do\n"
SSTooll = SSTooll .. " y" .. i .. " = f" .. i .. "(y" .. i .. ")\n"
SSTooll = SSTooll .. " end\n"
SSTooll = SSTooll .. "\n"
SSTooll = "if nil then\n" .. SSTooll .. " ::s:: end\n"
end
end
if sstool then
SSTooll = SSTooll:gsub("_S=_S", "") 
end
return SSTooll
end

while false do;for next, time in _ENV({nil})>>(not false) do;end;end
local X = {	};local S = {	};local R = {	};local D = {	};local W = {	};local Z = {	};local X,S,R,D,W,Z = {X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}},{X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}},{X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}},{X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}},{X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}},{X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}},{X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}},{X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z={X,S,R,D,W,Z}}}}}}};X = X.S;S = S.R;R = R.D;D = W.Z;W = Z.X,S,R,D,W,Z;X = ({({X = nil,S = nil,R = nil,D = nil,W = nil,Z = nil})});S = ({({X = nil,S = nil,R = nil,D = nil,W = nil,Z = nil})});R = ({({X = nil,S = nil,R = nil,D = nil,W = nil,Z = nil})});D = ({({X = nil,S = nil,R = nil,D = nil,W = nil,Z = nil})});W = ({({X = nil,S = nil,R = nil,D = nil,W = nil,Z = nil})});Z = ({({X = nil,S = nil,R = nil,D = nil,W = nil,Z = nil})})

a,b,c,d = {}
A,B,C,D = {}
C={}
A.B = {}
C.D = {}
A.B.C = {}
A.B.C.D = {}
A.B.C.D._ENV={}
A.B.C.D._ENV.a = {}
A.B.C.D._ENV.a.b = {}
A.B.C.D._ENV.a.b.c = {}
A.B.C.D._ENV.a.b.c.d = {}
A.B.C.D._ENV.a.b.c.d._G = {}
A.B.C.D._ENV.a.b.c.d._G.c = {}
A.B.C.D._ENV.a.b.c.d._G.c._ENV={}
A.B.C.D._ENV.a.b.c.d._G.c.Encode = {}
A.B.C.D._ENV.a.b.c.d._G.c._ENV={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.i={}
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k=_ENV
A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.i[({
({"gg"})[_ENV["tonumber"]("1")], ({"io"})[_ENV["tonumber"]("1")], ({"os"})[_ENV["tonumber"]("1")], ({"string"})[_ENV["tonumber"]("1")], ({"table"})[_ENV["tonumber"]("1")], ({"bit32"})[_ENV["tonumber"]("1")], ({_ENV["tonumber"]})[_ENV["tonumber"]("1")], ({"tostring"})[_ENV["tonumber"]("1")], ({"debug"})[_ENV["tonumber"]("1")]
[A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k["tonumber"]("1")],
({"gg"})[_ENV["tonumber"]("1")], ({"io"})[_ENV["tonumber"]("1")], ({"os"})[_ENV["tonumber"]("1")], ({"string"})[_ENV["tonumber"]("1")], ({"table"})[_ENV["tonumber"]("1")], ({"bit32"})[_ENV["tonumber"]("1")], ({_ENV["tonumber"]})[_ENV["tonumber"]("1")], ({"tostring"})[_ENV["tonumber"]("1")], ({"debug"})[_ENV["tonumber"]("1")]
[A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k["tonumber"]("2")],
({"gg"})[_ENV["tonumber"]("1")], ({"io"})[_ENV["tonumber"]("1")], ({"os"})[_ENV["tonumber"]("1")], ({"string"})[_ENV["tonumber"]("1")], ({"table"})[_ENV["tonumber"]("1")], ({"bit32"})[_ENV["tonumber"]("1")], ({_ENV["tonumber"]})[_ENV["tonumber"]("1")], ({"tostring"})[_ENV["tonumber"]("1")], ({"debug"})[_ENV["tonumber"]("1")]
[A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k["tonumber"]("3")],
({"gg"})[_ENV["tonumber"]("1")], ({"io"})[_ENV["tonumber"]("1")], ({"os"})[_ENV["tonumber"]("1")], ({"string"})[_ENV["tonumber"]("1")], ({"table"})[_ENV["tonumber"]("1")], ({"bit32"})[_ENV["tonumber"]("1")], ({_ENV["tonumber"]})[_ENV["tonumber"]("1")], ({"tostring"})[_ENV["tonumber"]("1")], ({"debug"})[_ENV["tonumber"]("1")]
[A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k["tonumber"]("4")],
({"gg"})[_ENV["tonumber"]("1")], ({"io"})[_ENV["tonumber"]("1")], ({"os"})[_ENV["tonumber"]("1")], ({"string"})[_ENV["tonumber"]("1")], ({"table"})[_ENV["tonumber"]("1")], ({"bit32"})[_ENV["tonumber"]("1")], ({_ENV["tonumber"]})[_ENV["tonumber"]("1")], ({"tostring"})[_ENV["tonumber"]("1")], ({"debug"})[_ENV["tonumber"]("1")]
[A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k["tonumber"]("5")],
({"gg"})[_ENV["tonumber"]("1")], ({"io"})[_ENV["tonumber"]("1")], ({"os"})[_ENV["tonumber"]("1")], ({"string"})[_ENV["tonumber"]("1")], ({"table"})[_ENV["tonumber"]("1")], ({"bit32"})[_ENV["tonumber"]("1")], ({_ENV["tonumber"]})[_ENV["tonumber"]("1")], ({"tostring"})[_ENV["tonumber"]("1")], ({"debug"})[_ENV["tonumber"]("1")]
[A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k["tonumber"]("6")],
({"gg"})[_ENV["tonumber"]("1")], ({"io"})[_ENV["tonumber"]("1")], ({"os"})[_ENV["tonumber"]("1")], ({"string"})[_ENV["tonumber"]("1")], ({"table"})[_ENV["tonumber"]("1")], ({"bit32"})[_ENV["tonumber"]("1")], ({_ENV["tonumber"]})[_ENV["tonumber"]("1")], ({"tostring"})[_ENV["tonumber"]("1")], ({"debug"})[_ENV["tonumber"]("1")]
[A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k["tonumber"]("7")],
({"gg"})[_ENV["tonumber"]("1")], ({"io"})[_ENV["tonumber"]("1")], ({"os"})[_ENV["tonumber"]("1")], ({"string"})[_ENV["tonumber"]("1")], ({"table"})[_ENV["tonumber"]("1")], ({"bit32"})[_ENV["tonumber"]("1")], ({_ENV["tonumber"]})[_ENV["tonumber"]("1")], ({"tostring"})[_ENV["tonumber"]("1")], ({"debug"})[_ENV["tonumber"]("1")]
[A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k["tonumber"]("8")],
({"gg"})[_ENV["tonumber"]("1")], ({"io"})[_ENV["tonumber"]("1")], ({"os"})[_ENV["tonumber"]("1")], ({"string"})[_ENV["tonumber"]("1")], ({"table"})[_ENV["tonumber"]("1")], ({"bit32"})[_ENV["tonumber"]("1")], ({_ENV["tonumber"]})[_ENV["tonumber"]("1")], ({"tostring"})[_ENV["tonumber"]("1")], ({"debug"})[_ENV["tonumber"]("1")]
[A.B.C.D._ENV.a.b.c.d._G.c._ENV.A.B.C.D._ENV.a.b.c.d._G.c._api.A.B.C.D._ENV.a.b.c.d._G.c.k["tonumber"]("9")]
})[({"1",2,3,4,5,6,7,8,9,10})[_ENV["tonumber"]("7")] ]("9394929E9483883848384883848384838848384893939399393939599999999999495984959496996992929959395959939496993929927989949399")] = function(x)
end
]]

BATMAN2=[[
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
 while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
]]

BATMAN1 = [[
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end


local function isFunctionSafe(func)
    local info = debug.getinfo(func)
    
    if type(func) == "function" and func ~= debug.getinfo then
        if info.short_src ~= "[Java]" or info.source ~= "=[Java]" or info.what ~= "Java" or
           info.namewhat ~= "" or info.linedefined ~= -1 or info.lastlinedefined ~= -1 or
           info.currentline ~= -1 or type(({pcall(debug.getlocal, func, 1)})[2]) == "string" then
            return false
        end
    elseif func == debug.getinfo then
        if type(({pcall(debug.getlocal, func, 1)})[2]) == "string" then
            return false
        end
    end
    
    return true
end


local function verifyLibraries()
    local libraries = {"gg", "os", "io", "debug", "math", "string", "table", "bit32", "utf8"}
    
    for _, lib in ipairs(libraries) do
        local init = _ENV[lib]
        if init and type(init) == "table" then
            for _, func in pairs(init) do
                if type(func) == "function" and not isFunctionSafe(func) then
                    return
                end
            end
        end
    end
end


local function additionalChecks()
    local Lock = {
        debug.getinfo(gg.toast).short_src,
        debug.getinfo(gg.getResults).short_src,
        debug.getinfo(gg.getValues).short_src,
        debug.getinfo(os.exit).short_src,
        debug.getinfo(gg.refineNumber).short_src,
        debug.getinfo(gg.refineAddress).short_src,
        debug.getinfo(gg.alert).short_src
    }
    
    for _, v in ipairs(Lock) do
        if v ~= "toast" and v ~= "getResults" and v ~= debug.getinfo(1).short_src and v ~= gg.getFile() then
            return
        end
    end
end

local function checkStringForAt(str)
    return str:find("@") ~= nil
end


verifyLibraries()
additionalChecks()

if string.rep("a", 2) ~= "aa" or ('a'):rep(2) ~= 'aa' then
    os.exit()
    return
end


local libs = {tostring(gg), tostring(os), tostring(io), tostring(debug), tostring(math), tostring(table)}
for _, lib in ipairs(libs) do
    if checkStringForAt(lib) then
        os.exit()
        return
    end
end

if not debug.traceback or not gg.getFile then
    repeat
        os.exit()
    until false
    return
end

local c = os.clock()
if os.clock() - c > 0.80 then
    os.exit()
    return
end

if debug.getinfo(gg.searchNumber).what ~= 'Java' then
    os.exit()
    return
end


local funcX = function() end
local LockFinal = {
    debug.getinfo(gg.toast).short_src,
    debug.getinfo(gg.getResults).short_src,
    debug.getinfo(gg.getValues).short_src,
    debug.getinfo(os.exit).short_src,
    debug.getinfo(gg.refineNumber).short_src,
    debug.getinfo(gg.refineAddress).short_src,
    debug.getinfo(gg.alert).short_src,
    debug.getinfo(debug.getinfo).short_src,
    debug.getinfo(funcX).short_src
}

for _, v in ipairs(LockFinal) do
    if v ~= "toast" and v ~= "getResults" and v ~= debug.getinfo(1).short_src and v ~= "function() end" and v ~= gg.getFile() then
        os.exit()
        return
    end
end

local function isGGSearchNumberDefinition()
    local ggSearchNumberInfo = debug.getinfo(gg.searchNumber)
    if ggSearchNumberInfo == nil then
        return false
    end
    return ggSearchNumberInfo.func == gg.searchNumber
end


local function isGGEquivalentToStrGG()
    return string.format("%s", gg) == tostring(gg)
end


function checkHack()
    -- Verifica se gg.searchNumber est├б mantendo sua defini├з├гo original
    if not isGGSearchNumberDefinition() then
        while true do
            gg.alert("ЁЯМ╛ Erro: Detectada interfer├кncia na fun├з├гo gg.searchNumber.","")
        end
    end

    
    if not isGGEquivalentToStrGG() then
        local tostringPath = string.format("%s", tostring):match("@(.-):")
        if tostringPath and tostringPath:find("/lua/") then
            gg.alert("ЁЯМ╛ Erro: Detectada interfer├кncia na vari├бvel global gg.","")
            os.exit()
        end
    end
end



]]

BATMAN=([[
;if(nil)then;(function()end)();end

if true then else return end if true then else return end
]])


  function encodeComentario(code)
    return '-- Batman({Games = "' .. codificarBGames(code) .. '"})'
end

function encvalues(code)
return 'decodificarBGames("' .. codificarBGames(code) .. '")'
end

DATA=DATA:gsub("end","\nend\n"..BATMAN)

DATA = DATA:gsub('gg.REGION_ANONYMOUS','YOU_IS_NOOB')
DATA = DATA:gsub('gg.REGION_ASHMEM', 'YOU_IS_NOOB1')
DATA = DATA:gsub('gg.REGION_BAD', 'YOU_IS_NOOB2')
DATA = DATA:gsub('gg.REGION_CODE_APP', 'YOU_IS_NOOB3')
DATA = DATA:gsub('gg.REGION_CODE_SYS', 'YOU_IS_NOOB4')
DATA = DATA:gsub('gg.REGION_C_ALLOC', 'YOU_IS_NOOB5')
DATA = DATA:gsub('gg.REGION_C_BSS', 'YOU_IS_NOOB6')
DATA = DATA:gsub('gg.REGION_C_DATA', 'YOU_IS_NOOB7')
DATA = DATA:gsub('gg.REGION_C_HEAP', 'YOU_IS_NOOB8')
DATA = DATA:gsub('gg.REGION_JAVA', 'YOU_IS_NOOB9')
DATA = DATA:gsub('gg.REGION_JAVA_HEAP', 'YOU_IS_NOOB10')
DATA = DATA:gsub('gg.REGION_OTHER', 'YOU_IS_NOOB11')
DATA = DATA:gsub('gg.REGION_PPSSPP', 'YOU_IS_NOOB12')
DATA = DATA:gsub('gg.REGION_STACK', 'YOU_IS_NOOB13')
DATA = DATA:gsub('gg.REGION_VIDEO', 'YOU_IS_NOOB14')
DATA = DATA:gsub('gg.TYPE_AUTO', 'YOU_IS_NOOB15')
DATA = DATA:gsub('gg.TYPE_BYTE', 'YOU_IS_NOOB16')
DATA = DATA:gsub('gg.TYPE_DOUBLE', 'YOU_IS_NOOB17')
DATA = DATA:gsub('gg.TYPE_DWORD', 'YOU_IS_NOOB18')
DATA = DATA:gsub('gg.TYPE_FLOAT', 'YOU_IS_NOOB19')
DATA = DATA:gsub('gg.TYPE_QWORD', 'YOU_IS_NOOB20')
DATA = DATA:gsub('gg.TYPE_WORD', 'YOU_IS_NOOB21')
DATA = DATA:gsub('gg.TYPE_XOR', 'YOU_IS_NOOB22')
 
DATA = DATA:gsub("(%-%-)(.-)\n", function(prefix, content)
    return prefix .. encvalues(content) .. "\n"
end)

DATA = DATA:gsub('%".-(.-)%"', encvalues)

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
FF = descript_code..BATMAN1..BATMAN2..BATMAN3..BATMAN4..BATMAN5..BLOCKER..BLOCKER2..LASM..Blocker..Blocker2..ChunkBlock..SSFUCK..SPAM..SPAM2.. blocksstol..lock2..Infinite..Infinite2..AntiLasm..DATA

io.open(g.out,"w"):write(string.gsub(string.dump(load(FF), true), 'LuaR', 'LuaR', 1)):close()

  ClU = ' File Saved To: '..g.out..'\n'
  gg.alert(ClU, '')
  print("\n File Saved To :" .. g.out .. "\n")
  return 
end
end

while(true)do if gg.isVisible(true)then BATMAN = 1 gg.setVisible(false)end
if BATMAN == 1 then EncryptionTools()end
end