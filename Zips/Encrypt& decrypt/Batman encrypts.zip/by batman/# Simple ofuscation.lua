(function()

local SecureConfig = {
    magicKey = 0x55AA1234,
}
local function secure_bitxor(a, b)
    return (a ~ b) & 0xFFFFFFFF
end

local prompt = gg.prompt({ "📂 Select File" }, { "/storage/emulated/0/# script.lua" }, { "file" })
if not prompt then return end
local file = prompt[1]
local path = string.gsub(file, "%.lua$", "") .. ".[⛩️].lua"

local fh = io.open(file, "r")
if not fh then
    gg.alert("Error: Could not open file")
    return
end
local data = fh:read("*a")
fh:close()

local replacements = {
   ["gg%.(%a+)%("] = "_G[\"gg\"][\"%1\"](",
    ["io%.(%a+)%("] = "_G[\"io\"][\"%1\"](",
    ["os%.(%a+)%("] = "_G[\"os\"][\"%1\"](",
    ["table%.(%a+)%("] = "_G[\"table\"][\"%1\"](",
    ["debug%.(%a+)%("] = "_G[\"debug\"][\"%1\"](",
    ["string%.(%a+)%("] = "_G[\"string\"][\"%1\"](",
    ["bit32%.(%a+)%("] = "_G[\"bit32\"][\"%1\"]("
}
for pattern, replacement in pairs(replacements) do
    data = data:gsub(pattern, replacement)
end

data = data:gsub('%[===%[(.-)%]===%]', function(c)
    local bytes = {}
    for b in string.gmatch(c, ".") do
        bytes[#bytes+1] = string.byte(b)
    end
    return "char(unpack({" .. table.concat(bytes, ",") .. "}))"
end)

data = data:gsub("[\"'](.-)[\"']", function(c)
    local bytes = {}
    for b in string.gmatch(c, ".") do
        bytes[#bytes+1] = string.byte(b)
    end
    return "char(unpack({" .. table.concat(bytes, ",") .. "}))"
end)

local var_declaration = ""
for i = 1, 128 do
    var_declaration = var_declaration .. "\nlocal v" .. i .. " = " .. secure_bitxor(i, SecureConfig.magicKey % 256)
end

data = [[(function()]] .. var_declaration .. [[

    (function()
        local gg, io, os, table, debug, string, bit32 =
          _G["gg"], 
            _G["io"], _G["os"], _G["table"],
            _G["debug"], _G["string"], _G["bit32"]
        local char, unpack = string.char, table.unpack
       
]] .. data.. [[

    end)()
end)()]]

local out = io.open(path, "w")
if out then
    out:write(data)
    out:close()
    gg.alert("✅ File encrypted successfully!\nSaved to: " .. path)
else
    gg.alert("Error: Could not save output file")
end
end)()