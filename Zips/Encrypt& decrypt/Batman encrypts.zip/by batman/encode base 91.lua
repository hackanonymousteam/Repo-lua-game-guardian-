local b91 = {}

local function lshift(x, n)
  return x * (2 ^ n)
end

local function rshift(x, n)
  return math.floor(x / (2 ^ n))
end

local function band(a, b)
  local res, bit = 0, 1
  while a > 0 and b > 0 do
    local a_bit = a % 2
    local b_bit = b % 2
    if a_bit == 1 and b_bit == 1 then
      res = res + bit
    end
    a = math.floor(a / 2)
    b = math.floor(b / 2)
    bit = bit * 2
  end
  return res
end

local enctab = {}
local dectab = {}
do
  local chars = [[ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!#$%&()*+,./:;<=>?@[]^_`{|}~"]]
  for i = 1, #chars do
    local ch = chars:sub(i, i)
    enctab[i - 1] = ch
    dectab[ch] = i - 1
  end
end

function b91.encode(data)
  local b, n = 0, 0
  local out = {}

  for i = 1, #data do
    b = b + lshift(data:byte(i), n)
    n = n + 8
    if n > 13 then
      local v = band(b, 8191)
      if v > 88 then
        b = rshift(b, 13)
        n = n - 13
      else
        v = band(b, 16383)
        b = rshift(b, 14)
        n = n - 14
      end
      table.insert(out, enctab[v % 91])
      table.insert(out, enctab[math.floor(v / 91)])
    end
  end

  if n > 0 then
    table.insert(out, enctab[b % 91])
    if n > 7 or b > 90 then
      table.insert(out, enctab[math.floor(b / 91)])
    end
  end

  return table.concat(out)
end

function b91.decode(data)
  local v, b, n = -1, 0, 0
  local out = {}

  for i = 1, #data do
    local c = dectab[data:sub(i, i)]
    if c then
      if v < 0 then
        v = c
      else
        v = v + c * 91
        local bits = (band(v, 8191) > 88) and 13 or 14
        b = b + lshift(v, n)
        n = n + bits
        while n >= 8 do
          table.insert(out, string.char(b % 256))
          b = rshift(b, 8)
          n = n - 8
        end
        v = -1
      end
    end
  end

  if v >= 0 then
    b = b + lshift(v, n)
    n = n + 13
    while n >= 8 do
      table.insert(out, string.char(b % 256))
      b = rshift(b, 8)
      n = n - 8
    end
  end

  return table.concat(out)
end

local input = "oooooooooobbcccoi"
local encoded = b91.encode(input)
local decoded = b91.decode(encoded)

--print("Original:     " .. input)
print("encrypted:   " .. encoded)
print("Decrypted: " .. decoded)





