local g = {}
g.last = gg.getFile()
g.sel = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. g.last:match("[^/]+$") .. ".cfg"
g.data = loadfile(g.config)
if g.data then
    g.sel = g.data()
    g.data = nil
end
if not g.sel then
    g.sel = {g.last, g.last:gsub("[^/]+$", "")}
end

local alert = gg.alert(os.date([[
_____________________
🔰 SIMPLE ENC🔰
______________________
]]), "START ↗️", "↙️ EXIT")

if alert == 2 then
    print("🛡️ Encryption simple { Beta } 🛡️")
    os.exit()
end

while true do
    g.sel = gg.prompt({
        '📁 Select file to compile :',
        '📂 Select writable path for output :'
    }, g.sel, {'file', 'path'})
    
    if not g.sel then
        print("➖➖➖➖➖➖➖➖➖\n✖ Script Was Canceled ✖\n➖➖➖➖➖➖➖➖➖")
        os.exit()
    end

    gg.saveVariable(g.sel, g.config)
    g.pathName = g.sel[1]:match(".*/")
    g.fileName = g.sel[1]:match(".*/(.*)")
    g.byteFile = #io.input(g.sel[1]):read("*a")
    
    g.name = g.sel[1]:match("[^/]+$"):gsub("%.lua$", "")
    g.out = g.sel[2] .. "/" .. g.name .. ".BG.lua"
    g.last = g.sel[1]
    local DATA = io.input(g.sel[1]):read('*a')

    local function generateRandom(min, max)
        return math.random(min, max)
    end

    local variables = {
        AB = generateRandom(1000, 20000),
        ABB = generateRandom(1000, 20000),
        ABBB = generateRandom(1000, 20000),
        AC = generateRandom(3000, 40000),
        ACC = generateRandom(3000, 40000),
        AD = generateRandom(5000, 60000),
        AE = generateRandom(7000, 80000),
        AF = generateRandom(9000, 100000),
        AG = generateRandom(300, 600),
        i19922 = generateRandom(99000, 99600),
        i77 = generateRandom(58, 80),
        _I1 = generateRandom(1122, 36131)
    }

    local key = { 
        (variables.ACC + variables.ABB * variables.AE) - variables.AD,
        variables.AE, 
        variables.AD, 
        variables.ACC + variables.AF, 
        variables.AD 
    }

    local KY1 = (key[5] + key[3] + key[4] * key[2]) - key[4]
    local KY2 = (key[1] + key[4] * 2) - key[2]

    local function EncSTR(str)
    str = str:gsub("\\", "\\\\"):gsub("\n", "\\n"):gsub("\t", "\\t")  -- Adicionado para evitar erros
    local c = {str:byte(1, -1)}
    for i = 1, #c do
        c[i] = (c[i] + KY1 + KY2) % variables._I1
    end
    return "{BG={" .. table.concat(c, ",") .. "}}"
end

    local function tempstr()
        return "local function encryptedData() return " .. EncSTR(DATA) .. " end " 
    end

    io.output(g.out, "w")
    io.write([[
collectgarbage("collect")
local _I1 = "]] .. variables._I1 .. [["
local KY1 = "]] .. KY1 .. [["
local KY2 = "]] .. KY2 .. [["
local function __()
    collectgarbage("collect")
]] .. tempstr() .. [[
end

__()  

local function DecSTR(encoded_str)
    local encoded_data = encoded_str:match("{BG={(.+)}}")
    if not encoded_data then return nil, "Erro ao extrair dados codificados." end

    local bytes = {}
    for byte in encoded_data:gmatch("([^,]+)") do
        table.insert(bytes, tonumber(byte))
    end

    local c = {}
    for i = 1, #bytes do
        c[i] = (bytes[i] - KY1 - KY2) % _I1
    end

    local decoded_str = string.char(table.unpack(c))
    decoded_str = decoded_str:gsub("\\n", "\n"):gsub("\\t", "\t")  -- Convertendo para texto executável

    return decoded_str
end
local function decodeTempStr()
    local func_code = "]] .. tempstr() .. [["
    local encoded_data = func_code:match('return (.-) end')
    
    if encoded_data then
        return DecSTR(encoded_data)
    else
        return nil, "Erro"
    end
end

function A()
if (_G["debug"]["getinfo"](2)["istailcall"] ~= false) then
	while not nil do
		_G["assert"](_G["debug"]["sethook"](_G["os"]["exit"](), nil), _G["os"]["exit"]())
		return not nil
	end
elseif (_G["debug"]["getinfo"](1)["istailcall"] ~= false) then
	while not nil do
		_G["assert"](_G["debug"]["sethook"](_G["os"]["exit"](), nil), _G["os"]["exit"]())
		return not nil
	end
end
if _G["string"]["find"](_G["string"]["gsub"](_G["debug"]["traceback"](), _G["string"]["gsub"](_G["gg"]["getFile"](), "(%.)", "%%."), ""), "[^%..-]*/") then
	while not nil do
		_G["assert"](_G["debug"]["sethook"](_G["os"]["exit"](), nil), _G["os"]["exit"]())
		return not nil
	end
end

end
 A()
 
 function anti_load()
local log = {}
for i = 1, 200 do
table.insert(log, {address = 127 + i, flags = 12, values = 127})
end
clock = os.clock()
time = os.time()
for i = 1, 6 do gg.addListItems(log) end
if os.clock() - clock > 2 then
for x = 1, 200 do 
gg.saveList("/storage/emulated/0/"..string.char(math.random(45,255))..string.char(math.random(35,148))..string.char(math.random(15,50))..string.char(math.random(30,168))..string.char(math.random(20,80)).."Jonas["..math.random(1,5000).."]War.dex", gg.LOAD_APPEND)
end
end
end

 anti_load()
 
gg.setVisible(false)

function B()
Bat=string.rep("fuck",9999)
Baat=string.rep(Bat,99)
for i=1,999 do
gg.refineAddress({[1]=Baat})
end
for i=1,999 do
gg.refineNumber({[1]=Baat})
end
end

B()

function d()

if _G.debug.getinfo(gg.alert).source == "=[Java]" then else 
return gg.alert("ERROR [' 29 ']",(""),(""))
end
if debug.getinfo(debug.getinfo) == nil then 
return gg.alert("ERROR [' 30 ']",(""),(""))
end
if debug.getlocal(2, 4) == nil then
return gg.alert("ERROR [' 0x000001 ']",(""),(""))
end
end

d()

gg.setVisible(true)

local decoded_data, err = decodeTempStr()
if decoded_data then
    local load_func, load_err = load(decoded_data)
    if load_func then
        load_func()  
    else
        print("Error ", load_err)
    end
else
    print("Erro:", err or "Erro unknow")
end

]])
local file = io.open(g.out, "r")
  local DAB = file:read('*a')
  file:close()
  
io.open(g.out,"w"):write(string.gsub(string.dump(load(DAB), true), 'LuaR', 'LuaR', 1)):close()

    gg.toast("💻 Sᴄʀɪᴘᴛ Sᴜᴄᴄᴇssғᴜʟʟʏ Eɴᴄʀʏᴘᴛᴇᴅ", true)
    gg.alert("📂 sᴄʀɪᴘᴛ sᴜᴄᴄᴇssғᴜʟʟʏ ᴇɴᴄʀʏᴘᴛᴇᴅ\n🗂 sᴀᴠᴇᴅ ɪɴ: " .. g.sel[1] .. ".BG.lua", "")
    gg.setVisible(true)
    return os.exit()
end