local g = {}
g.last = gg.getFile()
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
DATA = loadfile(g.config)
if DATA ~= nil then g.info = DATA() DATA = nil end
if g.info == nil then g.info = {g.last, g.last:gsub("/[^/]+$", "")} end

local OBF_LEVEL = 5
local STRING_PROTECTION = true
local BYTECODE_OBFUSCATION = true

local function RandomName()
    local parts = {}
    for i = 1, math.random(5,10) do
        parts[i] = string.char(math.random(97, 122))
    end
    return table.concat(parts)
end

local function EncodeBytecode(bc)
    local encoded = {}
    for i = 1, #bc do
        encoded[i] = string.format("%03d", bc:byte(i))
    end
    return table.concat(encoded)
end

local LOADER_TEMPLATE = [[
local function _L()
    local b = "%s"
    if #b %% 3 ~= 0 then return nil end
    
    local c = {}
    for i = 1, #b, 3 do
        local byte_str = b:sub(i, i+2)
        local byte_num = tonumber(byte_str)
        if not byte_num or byte_num < 0 or byte_num > 255 then
            return nil
        end
        c[#c+1] = string.char(byte_num)
    end
    local chunk = load(table.concat(c))
    if not chunk then return nil end
    return chunk()
end

_L()
]]

while true do
    g.info = gg.prompt({
        '[🔒] file for simple protect:',
        '[📂] folder to save:'
    }, g.info, {
        "file",
        "path"
    })
    
    if g.info == nil then return end
    
    gg.saveVariable(g.info, g.config)
    g.last = g.info[1]
    
    local chunk, err = loadfile(g.last)
    if not chunk then
        gg.alert("❌ Erro: "..(err or "file error"))
    else
        g.out = g.info[2].."/"..g.last:match("([^/]+)$"):gsub("%.lua$","_protected.lua")
        
        local bytecode = string.dump(chunk)
        
        local encoded = EncodeBytecode(bytecode)
        
        local protected = "--[[ Bytecode protected simple ]]--\n"
        protected = protected..string.format(LOADER_TEMPLATE, encoded)
        
        local f = io.open(g.out, "w")
        if f then
            f:write(protected)
            f:close()
            gg.alert("✅ ok!\nsave in :\n"..g.out)
            os.exit()
        else
            gg.alert("❌ error")
        end
    end
end