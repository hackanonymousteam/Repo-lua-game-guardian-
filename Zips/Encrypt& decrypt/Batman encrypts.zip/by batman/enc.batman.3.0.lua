-- Encrypt by batman Games
g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = {
    g.last,
    g.last:gsub("/[^/]+$", "")
  }
end while true do
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

g.info = gg.prompt({
'📂 Select file :',--1
'📂 select folder  :',--2
'🕒 Add date expire',--3
'🔐 Add password',--4
'🛡️ Add GG Version',--5
'📝 Antirename',--6
'⚠️ Add anti GG Decrypt',--7
'🗳 Add package GameGuardian',--8
'🎮 Add Package Game',--9
'💀 Add Verify Human Mode',--10
'📓 block LOAD',--11
'👀 antiview',--12
'📶 Block htpp canary',--13
'🔐 required root to start script',--14
'🔐 Add alert with time and date'--15




----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
},g.info,{
'file',--1
'path',--2
'checkbox',--3
'checkbox',--4
'checkbox',--5
'checkbox',--6
'checkbox',--7
'checkbox',--8
'checkbox',--9
'checkbox',--10
'checkbox',--11
'checkbox',--12
'checkbox',--13
'checkbox',--14
'checkbox'


})
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

gg.saveVariable(g.info, g.config)
g.last = g.info[1]
if loadfile(g.last) == nil then
return gg.alert([[⚠️Script not Found! ⚠️]])
else
g.out = g.last:match("[^/]+$")
g.out = g.out:gsub(".lua", ".Batman")
g.out = g.info[2] .. "" .. g.out .. ".lua"
info = {g.out}
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local DATA = io.input(g.last):read('*a')
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[3] == true then
day = os.date("%d")
exp_date = gg.prompt({
"📆 Set Expired Date : ",
"📝 Type Expired Message : "},
{os.date("%Y%m" .. day + 5),"⚠️ Script Expired ⚠️️"},{"number", "text"})
end
if not exp_date then
gg.setVisible(true)
elseif exp_date[1] == nil then gg.alert("📆 Date Can Not Be Empty !") gg.setVisible(true)
else
print("📅 Added Expired Date : True✔")
DATA = '\n if os.date("%Y%m%d") >= "'..exp_date[1]..'" then print("'..exp_date[2]..'") return gg.alert("' ..exp_date[2] ..'")end\n' .. DATA
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[4] == true then
PASS = gg.prompt({
"🔐 Set Password For Script :",
"📝 Type Message For Wrong Password : "
}, {"","⚠️ Wrong Password, Try Again!!! ⚠️"},{
"text",
"text"})
end--if
if not PASS then
gg.setVisible(true)
elseif PASS[1] == nil then
gg.alert("⚠️ Input Password !")
gg.setVisible(true)
else
print("🔐 Added Password Script : True✔")
DATA = '\nlocal CXY = "'.. PASS[1]..'"\nPASSW = gg.prompt({"🔒 Input password: "},{[1]=""},{[1]="text"})\n if not PASSW the﻿n print("'..PASS[2]..'")  return end\n if PASSW[1] == "" then gg.alert("❌Password Can Not Be Empty ❌") os.exit(print("❌Password Can Not Be Empty ❌"))end\n if PASSW[1] ~= CXY then print("'..PASS[2]..'")return end\nif PASSW[1] == CXY then gg.toast("🎉Wellcome🎉")end\n' .. DATA
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[5] == true then
VERSION = gg.prompt({
"🔐 Set Minimal GG Version : ",
"🗒️ Set Error GG Message :"
}, {gg.VERSION,"⚠️ Error GG VERSION ⚠️"}, {
"number",
"text"})
end--if
if not VERSION then
gg.setVisible(true)
elseif VERSION[1] == nil then
gg.alert("🛡️ Input Minimal Required GG Version !")
gg.setVisible(true)
else
print("🛡 Minimal Version Required : True✔")
DATA = '\nlocal LynX = gg;local Xslow = LynX.VERSION;if Xslow ~= "'..VERSION[1] .. '" then print("'..VERSION[2]..'") return gg.alert("' ..VERSION[2].. '")end\n' .. DATA
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[6] == true then
NAME = gg.prompt({
"🗒️ Set Name For Script :",
"📝 Type Message For Name Changed :",
}, {g.out:match("[^/]+$"),
"⚠️ RENAME DETECTED ⚠️"}, {
"text",
"text"})
end
if not NAME then
gg.setVisible(true)
elseif NAME[1] == nil then
gg.alert("📝 Set Name Can Not Be Empty !")
gg.setVisible(true)
else
print("📝 Added Rename Blocker : True✔")
DATA = '\nlocal HckUtdProtect = gg.getFile():match("[^/]+$")local tptd =  "'..NAME[1]..'"\nif HckUtdProtect ~= tptd then gg.copyText("'..NAME[1]..'")gg.setVisible(true) print("'..NAME[2]..'") return gg.alert("'..NAME[2].. '")end\n' ..DATA
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[7] == true then
DATA = ([[if gg.isPackageInstalled("com.goushi.gtpcanary") then
  print("uninstall o Packet Capture")
  os.exit()
else
end
if gg.isPackageInstalled("com.packagesniffer.frtparlak") then
  print("uninstall o Packet Capture")
  os.exit()
else
end
if gg.isPackageInstalled("com.rhmsoft.edit") then
  print("uninstall o Packet Capture")
  os.exit()
else
end
if gg.isPackageInstalled("app.greyshirts.sslcapture") then
  print("uninstall o Packet Capture")
  os.exit()
else
end
if gg.isPackageInstalled("frtparlak.rootsniffer") then
  print("uninstall o Packet Capture")
  os.exit()
else
end
if gg.isPackageInstalled("com.minhui.wifianalyzer") then
  print("uninstall o Packet Capture")
  os.exit()
else
end
if gg.isPackageInstalled("jp.co.taosoftware.android.packetcapture") then
  print("uninstall o Packet Capture")
  os.exit()
else
end
if gg.isPackageInstalled("com.prabalgaming.logger") then
  print("uninstall your logger gg to Run Script")
  os.exit()
else
end
if gg.isPackageInstalled("any_.body_.can_.fuck_.tencent_") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.s.fyojrme") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.rjvsbmhdspmnfbame") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.redwolfgaming.ripgg") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.vrexqfftfsxekm.kl") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.nochqxpucsbldqqx") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.ghueczxrttlhgd") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.yy.qptvrjwerw.ghoex") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.nochqxpucsbldqqx") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.pvt4u") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.Egypt.yuosseef") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.tssfjipkmrco") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.vip.paidhacksonly.mr.toxin") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.ioyysvgfsrig") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.mrteamz.id") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.jtbodgpqxox") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.eidymumcghpfeeeavps") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.mod.iraq") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.dzelttwyuyyes") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.sxqa") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.xyyxgxfn") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.zgb") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.tssfjipkmrco") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.vnpqk") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.mwjvnwesbghkxbjznbwo") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.blackduty.gc") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.s.fyojrme") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.roxmemek") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.fhshwhpvqvruvjtu") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.fireongaming.fog") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.paranoiaworks.unicus.android.sse") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.raincitygaming.ggmod") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.pvt4u") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.nydpvsb.z.r.pkgh") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.ioyysvgfsrig") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.gmsm") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.sudsjcqvvcmgutdjeg") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.redwolfgaming.ripgg") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.coolfoolggfuckscript.tm") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.eidymumcghpfeeeavps") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.dzelttwyuyyes") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.foxcyber.gg") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.sxqa") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("com.zgb") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("catch_.me_.if_.you_.can_") then
  print("uninstall ur Decrypt GG")
  os.exit()
end
if gg.isPackageInstalled("sstool.only.com.sstool") then
  print("Uninstall SSTOOL Deceypt")
  os.exit()
end
if gg.isPackageInstalled("sstool.only.com.sstool") then
  print("Uninstall SSTOOL Deceypt")
  os.exit()
end
if gg.isPackageInstalled("catch_.me_.if_.you_.can_") then
  print("Uninstall orginal GG")
  os.exit()
end
]])..DATA
print('🛡 Auto Detect Decrypt : True √ ')
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[8] == true then
_Hacks_Unlimited_ = gg.prompt({
"✏️ Set Your Package GameGuardian",
"📝 Type Message If Package Is Wrong :"
}, {"com.GameGuardian.id","⚠ Use MY GG For Run This Script ⚠"},{
"text",
"text"})
end--if
if not _Hacks_Unlimited_ then
gg.setVisible(true)
elseif _Hacks_Unlimited_[1] == nil then
gg.alert("⚠️ Set Package GameGuardian Can Not Bd Empty!")
gg.setVisible(true)
else
print("⚠ SetPeckage GG : True√ ")
DATA = '\nif gg.PACKAGE == "' .. _Hacks_Unlimited_[1] .. '" then\nelse\ngg.alert("' .. _Hacks_Unlimited_[2] .. '")\nprint("' .. _Hacks_Unlimited_[2] .. '")\nos.exit()\nend\n' .. DATA
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[9] == true then
_Hacks_Unlimited_g = gg.prompt({
"✏️ Set Package Game",
"📝 Type Message If Package Is Wrong :"
}, {"com.hacks.unlimited.apk","⚠ Use Script In Game ⚠"},{
"text",
"text"})
end--if
if not _Hacks_Unlimited_g then
gg.setVisible(true)
elseif _Hacks_Unlimited_g[1] == nil then
gg.alert("⚠️ Set Package GameGuardian Can Not Be Empty!")
gg.setVisible(true)
else
print("🎮 SetPeckage Game : True√ ")
DATA = '\nif gg.getTargetInfo().processName ~= "'.._Hacks_Unlimited_g[1]..'" then\ngg.alert("'.._Hacks_Unlimited_g[2]..'")\nos.exit()\nend\n'..DATA
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[10] == true then
print("💀 Added Verify Human Mode")
print("")
DATA = "local code = math.random(10000, 99999)\nlocal hmn = gg.prompt({'🔒 Input This Code to Verify: '..code..' !'},{[1]=''},{[1]='number'}) if not hmn then os.exit() end if hmn[1]..'1' == code..'1' then gg.toast('☑ Code correct!') else gg.alert('✖ Wrong Code!') os.exit() end\n" ..DATA
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[11] == true then
DATA = ([[
for i = 1,5 do
local ii = i * i local iii = i / i local iiii = i + i local iiiii = i - i
local _ = i * ii * iii * iiii * iiiii local __ = i / ii / iii / iiii / iiiii local ___ = i + ii + iii + iiii + iiiii local ____ = i - ii - iii - iiii - iiiii local _____ = _ * __ * ___ * ____ / _ / __ / ___ / ____ + _ + __ + ___ + ____ - _ - __ - ___ - ____ local ssenl = load(_____) if load(_____) then ssenl() pcall(ssenl) load(_____)() ssenl().ssenl() else load(_____)  end
end

for i = 1,5 do
local ii = i * i local iii = i / i local iiii = i + i local iiiii = i - i
local _ = i * ii * iii * iiii * iiiii local __ = i / ii / iii / iiii / iiiii local ___ = i + ii + iii + iiii + iiiii local ____ = i - ii - iii - iiii - iiiii local _____ = _ * __ * ___ * ____ / _ / __ / ___ / ____ + _ + __ + ___ + ____ - _ - __ - ___ - ____ local ssenl = load(_____) if load(_____) then ssenl() pcall(ssenl) load(_____)() ssenl().ssenl() else load(_____)  end
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function PQ(code)
    -- Verifica se o código foi carregado externamente
    if debug.getinfo(2) ~= nil then
        error("Acesso não autorizado!", 2)
    end

    local data = ''
    for i = script, #code do
        data = data .. string.char(code[gg.clearResults] / math.random(1, 1100))
    end
    return pcall(load(data))
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--codifica em ASCI
--function dzsh(Text)Text=Text:gsub(" ","") return (Text:gsub("..", function (jie)return string.char((tonumber(jie,16))%256) end))end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function tempstr()
  local debug_found = debug.getinfo(1, "S").what == "C"
  local sz = debug_found and 79 or math.random(9, 79)
  local se = " goto s "
  local sa = " i = ~i i = _ENV[35] i = _ENV[i] i = ~i  i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i  i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i  i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i  i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = _ENV[i] i = ~i  i = ~i i = _ENV[35] i = _ENV[i] i = ~i i = ~i i = _ENV[35] i = ~i "
  local strs = ""
  for s = 1, sz do
    strs = strs .. se
    saa = "" .. sa
  end
  if debug_found then
    strs = " if(nil)then for i = 1,0 do M = 'BatDev[BG]'if ({}).M~=nil then ({}).M=({}).M() end" .. saa .. "for i=({}).i ,({}).i ,({}).i do goto s goto s::s::end for i= {}, ({}).i , {} do goto s goto s::s::end for i= {}, {} , iiii do goto s goto s::s::end while(nil)do;for i=i,i do;local i={}if(i.i)then;i.i=i.i(i)end;for ii=i.i,i.i,i.i do;local ii={}if(ii.i)then;ii.i=ii.i()end;for iii=i,ii.i,i do;local iii={}if(iii.i)then;iii.i=iii.i(i)end;for iiii=i,ii,iii.i do;local iiii={}if(iiii.i)then;iiii.i=iiii.i(i)end;local iiii={}if(iiii.i)then;iiii.i=(iiii|iii|ii|i)(i)end;end;local iii={}if(iii.i)then;iii.i=(true|iii|ii|i)(i)end;end;local ii={}if(ii.i)then;ii.i=(true|false|ii|i)(i)end;end;local i={}if(i.i)then;i.i=(true|false|nil|i)(i)end;return(true|false|nil)end;return;end end if(nil)then " .. strs .. " ::s:: end for x = 1,0 do if x.x ~= nil then x.x = x.x() end end _={} _.__() _.___() _.____() _._____() end "
  end
  return strs
end

]])..DATA
print('🛡ANTISSTOOL by Batman games : Sucess √ ')
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[12] == true then
DATA = ([[if true then
    local org = gg.searchNumber
    local hook = function(...)
        gg.setVisible(false)
        local ret = org(...)
        if gg.isVisible() then
        gg.alert("ANTI VIEW CODE😂")
        gg.clearResults()
            while true do os.exit() end
        end
        return ret
    end
    gg.searchNumber = hook
end
]])..DATA
print('🛡ANTIVIEW  by Batman games : Sucess √ ')
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[13] == true then
DATA = ([[file,err=io.open("/storage/emulated/0/Android/data/com.guoshi.httpcanary")
jg=err:match("%((.-)%)")
if jg=="Is a directory" then 
gg.alert("ERROR⚡⚡")
os.exit() 
elseif jg=="No such file or directory" then  
--os.exit() 
end

]])..DATA
print('🛡 block canary by Batman games : Sucess √ ')
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
if g.info[14] == true then
DATA = ([[file, err = io.open("/system/bin/su", "r")

if file then
    gg.alert("Rooted device! Starting the script...")
    file:close()
else
    gg.alert("Non-rooted device. This script requires a rooted device.")
    os.exit()
end

]])..DATA
print('🛡 required root to start script by Batman games : Sucess √ ')
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if g.info[15] == true then
DATA = ([[ modbybatman = os.date ('           🦇 ENCRYPT BY BATMAN GAMES 🦇

           ❦ ════ •⊰❂ - ❂⊱• ════ ❦

           📆Dᴀᴛᴇ📆 : %Y/%m/%d\

          🕛Tɪᴍᴇ🕛 : %H:%M:%S\


           ❦ ════ •⊰❂ - ❂⊱• ════ ❦')
gg.alert(modbybatman)
]])..DATA
print('🛡 included alert with time and date by Batman games : Sucess √ ')
end


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


S = math.random(1, 60)
SS = math.random(80, 302)
SSS = math.random(1, 60)
T = math.random(190, 340)
TT = math.random(1, 60)
TTT = math.random(190, 470)
AB = math.random(1000,2000)
AC = math.random(3000,4000)
AD = math.random(5000,6000)
AE = math.random(6000,8000)
AF = math.random(9000,10000)
AG = math.random(400,600)
ABB = math.random(2000,2000)
ACC = math.random(3000,4000)
ADD = math.random(5000,6000)
AFF = math.random(9000,10000)
AGG = math.random(400,600)
AX = math.random(200,800)
ABBB = math.random(1000,2000)
ACCC = math.random(3000,4000)
ADDD = math.random(5000,6000)
AXE = math.random(7000,8000)
AFFF = math.random(9000,10000)
AGGG = math.random(400,600)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local key = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD}
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local Amk = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+3,AC}
local Kei = {(SS-S)+T,SSS+TT-S,SS+TTT,TT,TT+12,SS-S*4}
local KY1 = (key[1]+key[3]-key[1])-key[5] 
local KY2 = (key[1]-Amk[2]*key[3]*Amk[4])-key[5]
local KY3 = (Amk[2]-Amk[1]*Amk[4]-Amk[3])+Amk[1]
local KY4 = (key[1]+AE-key[1])*key[2]
local KY5 = (key[3]+Amk[4]-ADD)+key[2]
local KY6 = (Amk[1]-Amk[3]+key[1])+AFFF

local X = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD, ACC, AGG+3000,AC}
local Y = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+4000,AB+7000,AC}
local X1 = (X[1]+X[3]-X[1]) -X[5] 
local X2 = (X[1]-Y[2]*X[3]*Y[4]) -X[5]
local X3 = (Y[2]-Y[1]*Y[4]-Y[3]) +Y[1]
local X5 = (X[3]+Y[4]-ADD) +X[2]
local X6 = (Y[1]-Y[3]+X[1])+AFFF

local Key1 = math.random(1000,50000)
local Key2 = math.random(1000,50000)
local Key3 = math.random(1000,50000)
local Key4 = math.random(1000,50000)
local Key5 = math.random(1000,50000)
local Key6 = math.random(1000,50000)
local Key7 = math.random(1000,50000)
local Key8 = math.random(1000,50000)
local Key9 = math.random(1000,50000)
local Key10 = math.random(1000,50000)
local Key11 = math.random(1000,50000)
local Key12 = math.random(1000,50000)
local Key13 = math.random(1000,50000)
local Key14 = math.random(1000,50000)
local Key15 = math.random(1000,50000)
local Key16 = math.random(1000,50000)
local Key17 = math.random(1000,50000)
local Key18 = math.random(1000,50000)
local Key19 = math.random(1000,50000)
local Key20 = math.random(1000,50000)
local KeyHex1 = math.random(1000,50000)
local KeyHex2 = math.random(1000,50000)
local KeyHex3 = math.random(1000,50000)
local KeyHex4 = math.random(1000,50000)
local KeyHex5 = math.random(1000,50000)

local inv256 
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function ShaMod(str)str = str:gsub("\n", "\n") if not inv256 then inv256 = {} for M = 1, 100 do local inv = -1 repeat inv = inv + 2 until inv * (2*M + 1) % 256 == 1 inv256[M] = inv end;end local K, F = X1 - X3 + X2, X2 - X3 * X5 return (str:gsub('.', function(m) local L = K % X6; local H = (K - L) / X6; local M = H % 27; local m = m:byte() local c = (m * inv256[M] - (H - M) / 27) % 256 K = L * F + H + c + m
return ('%02x'):format(c)end)) end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function Sha(str)str = str:gsub("\\n", "\n") if not inv256 then inv256 = {} for M = 0, 127 do local inv = -1 repeat inv = inv + 2 until inv * (2*M + 1) % 256 == 1 inv256[M] = inv end;end local K, F = KY1 - KY3 + KY2, KY2 - KY3 * KY5 return (str:gsub('.', function(m)local L = K % KY6;local H = (K - L) / KY6;local M = H % 27;local m = m:byte()local c = (m * inv256[M] - (H - M) / 27) % 256 K = L * F + H + c + m  return ('%02x'):format(c)end)) end
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function SHA(str)
    str = str:gsub("\\n","\n"):gsub("\\t","\t")
    if not inv256 then 
        inv256 = {} 
        for M = 1, 100 do 
            local inv = -1 
            repeat  
                inv = inv + 2 
            until inv * (2*M + 1) % 256 == 1 
            inv256[M] = inv 
        end 
    end
    local K, F = X1 - X3 + X2, X2 - X3 * X5 
    return (str:gsub('.', function(m) 
        local L = K % X6 
        local H = (K - L) / X6 
        local M = H % 27 
        local m = m:byte() 
        local c = (m * inv256[M] - (H - M) / 27) % 256 
        K = L * F + H + c + m 
        return ('%02x'):format(c) 
    end)) 
end
 
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function encodegg(code)
	return '_G["gg"][BGames({BGA = "' .. SHA(code) .. '"})]('
end
function encodeio(code)
	return '_G["io"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeos(code)
return '_G["os"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodevalue(code)
	return 'BGames({BGA = "' .. Sha(code) .. '"})'
end

function encodestr(code)
return '_G["string"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodetbl(code)
return '_G["table"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodedebug(code)
return '_G["debug"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodeprint(code)
return '_G["print"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end
function encodefile(code)
return '_G["loadfile"][BGames({BGA = "' .. ShaMod(code) .. '"})]('
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Decode =[[
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
local ABBB = "]]..ABBB..[[";local ACC = "]]..ACC..[[";local i = "]]..math.random(100,800)..[[";local AB = "]]..AB..[[";local i = "]]..math.random(200,900)..[[";local ADD = "]]..ADD..[[";local ADDD = "]]..ADDD..[[";local AGG = "]]..AGG..[[";local AD = "]]..AD..[[";local AXE = "]]..AXE..[[";local i = "]]..math.random(200,900)..[[";local AC = "]]..AC..[[";local AGGG = "]]..AGGG..[[";local AFF = "]]..AFF..[[";local AE = "]]..AE..[[";
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end
local ACC = "]]..ACC..[[";local AE = "]]..AE..[[";local AX = "]]..AX..[[";local ACCC = "]]..ACCC..[[";local AG = "]]..AG..[[";local ABB = "]]..ABB..[[";local AF = "]]..AF..[[";local AFFF = "]]..AFFF..[[";local i = "]]..math.random(100,800)..[[";
for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end;while(nil)do;i = {nil % nil};for i in ipairs(i) do i = {{nil % nil}, {nil % nil}} i.i = _ENV[{(nil % nil)}] end;local x = {} x[-{~nil, -nil % nil}] = x local t = ({~x, -x % x})(({~x, -x % x})[-{~nil , -nil % nil}]) t[-{~nil, -nil % nil}] = ({~nil , -nil % nil}) end;for _ii = 1,0 do if _ii ~= nil then local _ii = {} _ii._ii = _ii._ii() end end

local key = {(AGG+ACC*AX)-AFF,AX,AX*1,ACC+AGG,ADD};local Amk = {(AF+AC*AD-AE+AF*AB)-AE,AC-10*AB,AD*2-AB,AE+AD,AF*AD,AB,AG+AF,AD-2,AC+3,AC};local KY1 = (key[1]+key[3]-key[1])-key[5] ;local KY2 = (key[1]-Amk[2]*key[3]*Amk[4])-key[5];local KY3 = (Amk[2]-Amk[1]*Amk[4]-Amk[3])+Amk[1];local KY4 = (key[1]+AE-key[1])*key[2];local KY5 = (key[3]+Amk[4]-ADD)+key[2];local KY6 = (Amk[1]-Amk[3]+key[1])+AFFF;local inv256 
local BGames = function(str) str = str.BGA local K, F = KY1 - KY3 + KY2, KY2 - KY3 * KY5 return (str:gsub('%x%x', function(c) local L = K % KY6 local H = (K - L) / KY6 local M = H % 27 c = tonumber(c, 16) local m = (c + (H - M) / 27) * (2*M + 1) % 256 K = L * F + H + c + m 
 if true then return string.char(m)end if true then return end if true then return end end))end

for i = 1, 0 do;Batman = 'Batman';end;for i = 1, 0 do;if(nil)then;Batman = 'Batman';end;end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

lock2 =[[
while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
gg.toast("Encrypt by ꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂")

	if true then
		if string.match('/' .. tostring(os.time()), '/([^/]+)$') ~= tostring(os.time()) then
			while true do
				if true then
					gg.alert('Error, time is not acceptable.')
					os.exit()
				end
				if false then
				end
			end
		end
	end
	
local GetTableSpam = {}
local b, toStr, GetSpamName = 0, tostring;

local tmp = (function()
  local tempString = ''
  while (b < (10^2)) do
    tempString = tempString .. toStr(b * b);
    b = b + 1
  end
  GetSpamName = (function() local HashName = '' for i = 1, 10 do HashName = "ðŸŒ¨ï¸" .. HashName .. "â˜ƒï¸" .. HashName .. "â„ï¸" end return HashName:rep(100) end)()
  return tempString;
end)();

local spam = "Boar"
local c, b = "'" .. math.random(1, 255) .. "'",  math.random(100, 300)
if tostring("@") == "" then
	return
end

for k, v in next, _ENV do
	if tostring(v):match("function: @.-:") then
		return
	end

local func = os.exit
if tostring(func):match("-") or tostring(func):match("//") or tostring(func):match("@") or tostring(func):match("%d+") then
	return
end
end

local spam_2 = "is top"

for i = 1, #tmp do
    GetTableSpam[i] = {["address"] = GetSpamName, ["flags"] = GetSpamName, ["value"] = GetSpamName, ["freeze"] = GetSpamName, ["name"] = GetSpamName, GetTableSpam[i - 1]}
    gg.refineNumber(GetTableSpam)
	gg.refineAddress(GetTableSpam)
end

local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
os.exit()
os.exit()
os["]==])..string.char(math.random(128,255),math.random(128,255),math.random(128,255),math.random(128,255))..([==["]()
gg.processKill()
return
end
end
if pcall(_ENV["os"]["exit"]) or _ENV["string"]["rep"]("'",'2')~="''" or not _ENV["debug"]["getinfo"](_ENV["tostring"])["isvararg"] or _ENV["debug"]["getinfo"](gg["searchNumber"])["what"]=="Lua" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

_ENV["B1"]= _ENV["debug"]["getinfo"](gg.refineNumber).short_src
if _ENV["B1"]~=_ENV["debug"]["getinfo"](1).short_src and _ENV["B1"]~=gg.getFile() then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
local i;
for i in ipairs({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)}) do
if _ENV["string"]["match"](({tostring(gg),tostring(os),tostring(io),tostring(debug),tostring(math),tostring(table)})[i], "@") then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if debug.getinfo(1).istailcall then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

x=debug.getinfo(gg.searchNumber)
if x.what~=('Java') then 
os.exit() 
while true do 
end 
end 
local i = {}
local g = {}
local ppi, ppb
g["last"] = _ENV["gg"]["getFile"]()
g["DATA"] = _ENV["loadfile"](g["last"])
g["cpp"] = g["DATA"]
if g["cpp"] ~= nil then 
g["DATA"] = nil
local ppb = g["last"]:match("[^/]+$")
local ppi = "lohhhggg"
local pu = _ENV["gg"]["getResults"](5000)
_ENV["os"]["rename"](''..g["last"]..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'') 
local prt = _ENV["loadfile"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'')
if prt ~= nil then
_ENV["os"]["rename"](''..g["last"]:gsub('/[^/]+$', '')..'/'..ppi..'', ''..g["last"]:gsub('/[^/]+$', '')..'/'..ppb..'')
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
for i in _ENV["ipairs"]({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])}) do 
if _ENV["string"]["match"](({
_ENV["tostring"](_ENV["gg"]),
_ENV["tostring"](_ENV["os"]),
_ENV["tostring"](_ENV["io"]),
_ENV["tostring"](_ENV["debug"]),
_ENV["tostring"](_ENV["math"]),
_ENV["tostring"](_ENV["table"])})[i], ("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
end
if _ENV["string"]["rep"]("a", 2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if ("a"):rep(2) ~= "aa" then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _ENV["tostring"](_ENV["gg"]):find(("@")) then 
if not _ENV["tostring"](_ENV["debug"]):find(("@")) then 
if not _ENV["tostring"](_ENV["io"]):find(("@")) then 
if _ENV["tostring"](_ENV["string"]):find(("@")) then 
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
        until x== 20000
        gg["sleep"](0)
        os.exit()
      until false
     end
   end
 end 
end
if _G["debug"]["getlocal"](2, 4) == nil then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end
if not _G["utf8"] then
repeat
  x= 0
      repeat
          x= x+1
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
           gg.sleep(2000)
           gg.setVisible(false)
           gg.sleep(0)
           gg.setVisible(true)
       until x== 20000
        gg["sleep"](0)
      os.exit()
    until false
  end

if _ENV["debug"]["traceback"] == nil then
return 
end

if _ENV["string"]["rep"]("a", 2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

if ("a"):rep(2) ~= "aa" then
while true do
_ENV["gg"]["alert"]("BATMAN")
return
Detectid()
end
end

local log = _ENV["string"]["char"](("255"),("255"),("255"),("255"),("255"),("255")):rep("999"):rep("999"):rep(4)
for i = 1,("3340") do
_ENV["gg"]["refineNumber"]("0",log,log,log,log,log,log,log)
end

local GG={"art","ART","Art","dec","Dec","DEC","hook","Hook","HooK","HOOK","log","Log","LOG",}
local _gg={gg.CACHE_DIR,gg.EXT_FILES_DIR,gg.EXT_CACHE_DIR,gg.FILES_DIR,gg.PACKAGE}
for i,v in pairs(GG) do
if string.find(tostring(_gg),v) or(not string.find(tostring(_gg),"com"))then
Error(true)
end
end

while gg.PACKAGE == "catch.Art.Tool.seatch" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.VERSION == "96.0" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while gg.BUILD == "15993" do
while true do
os.exit(print("꧁ঔৣ☬✞ BATMAN GAMES ✞☬ঔৣ꧂?"))
end
end
while string.find(gg.EXT_CACHE_DIR,"com.Art.Tool") do
end
while string.find(gg.EXT_CACHE_DIR,"catch_.me_.if_.you_.can_93") do
end

_ENV["debug"]["getinfo"]=function(a)
return _ENV["debug"]["getinfo"]("BATMANN")
end

for i in string.gmatch(tostring(debug.traceback()), '(.-)\n') do
if string.match(i, '.(/.-):') and string.match(i, '.(/.-):') ~= gg.getFile() then

os.exit()

print("ï¸")
return
end
end

]] 
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

AntiLasm=[[
mmk = ''
for i = 1, math.random(5, 10) do
    fname = string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))..string.char(math.random(97, 120))
    mmk = mmk.."while(nil)do;goto PROX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname.." goto PXXXX"..fname..";::PXXXX"..fname.."::;end\nlocal function FakeFunc"..fname.."()\nif fucklog or debug.getinfo(2) ~= nil then\n   -- Ação para tentativa de log ou disassembly externo\n   print('Tentativa de log ou disassembly detectada!')\n   -- Encerrar a execução ou tomar outra ação adequada\n   return\nend\ngoto PXXXX"..fname.."\n::PXXXX"..fname.."::\nfucklog = nil;end\n" 
end
]]

 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Infinite = [[

for i = 1,5 do
    if(nil) then 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
        if true then 
            return 
        end 
    end
    loadfile = loadfile
    load = load
    loadfile(gg.getFile()) 
    load(string.dump(load("os.exit()"),false,false)) 
    io.open(gg.getFile() .. "c" .. tostring(string.dump(loadfile(gg.getFile()),false,false)),"w") 
end

for i = 1, 5000 do
    table.insert({}, {})
end
for i = 1, 5000 do
    table.insert({}, {})
end

gg.setVisible(false)
for i = 1, 6 do
    gg.addListItems({})
end

gg.setVisible(false)
gg.removeListItems({})

if os.time() > os.time() then
    return 
end
if os.time() < os.time() then
end
if os.difftime(os.time(), (os.time())) > 2 then
    return 
end

gg.setVisible(false)
if os.clock() > os.clock() then
    return 
end
if os.clock() < os.clock() then
end
if os.difftime(os.clock(), (os.clock())) > 2 then
    return 
end

gg.setVisible(false)
for i = 3, 100 do
    load(gg.getFile())
end

while(nil)do
    local i={}
    if(i.i)then
        i.i=(i.i(i))
    end
end

while(nil)do
    for i=i,i do
        local i={}
        if(i.i)then
            i.i=(i.i(i))
        end
        for ii=i.i,i.i,i.i do
            local ii={}
            if(ii.i)then
                ii.i=ii.i()
            end
            for iii=i,ii.i,i do
                local iii={}
                if(iii.i)then
                    iii.i=iii.i(i)
                end
                for iiii=i,ii,iii.i do
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=iiii.i(i)
                    end
                    local iiii={}
                    if(iiii.i)then
                        iiii.i=(iiii|iii|ii|i)(i)
                    end
                end
                local iii={}
                if(iii.i)then
                    iii.i=(true|iii|ii|i)(i)
                end
            end
            local ii={}
            if(ii.i)then
                ii.i=(true|false|ii|i)(i)
            end
        end
        local i={}
        if(i.i)then
            i.i=(true|false|nil|i)(i)
        end
        return(true|false|nil)
    end
    return
end
]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


Infinite2 = [[
function obfuscate(code, x)
    x = x or ""
    code = x .. code
    local dmpbool = true
    local proccess = {
        "%%%%%%",
        "@@@@@@",
        "&&&&&&",
        "******"
    } -- Adicionando padrões de substituição mais complexos
    local temporary = "temp.lua" -- Nome do arquivo temporário
    for i = 1, #proccess do
        local f = load(code) or function() error("Error") end
        local dumped_code = string.dump(f, dmpbool)
        local f2 = load(dumped_code) or function() error("Error") end
        gg.internal2(f2, temporary)
        local a, b = {}, {}
        local DATA = {}
        for line in io.lines(temporary) do
            if line:match("^%s*%.func") or line:match("^%s*%.end") then
                b[#b + 1] = #DATA
                if #b == 2 then
                    if b[2] > b[1] + 2 then
                        a[#a + 1] = b
                    end
                    b = {b[2]}
                end
            end
            DATA[#DATA + 1] = line
        end
        code = table.concat(DATA, "\n")
        os.remove(temporary)
        for k, v in pairs(a) do
            local pattern = ""
            for i = v[1], v[2] do
                pattern = pattern .. DATA[i]:gsub("%p", function(c)
                    return "%" .. c
                end) .. "\n"
            end
            code = code:gsub(pattern, proccess[i])
        end
        dmpbool = false
    end
    return code
end

]]
 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

DATA = DATA:gsub("%'.-(.-)%'", encodevalue)
DATA = DATA:gsub('%".-(.-)%"', encodevalue)
DATA = DATA:gsub('%[%[.-(.-)%]%]', encodevalue)
DATA = DATA:gsub("gg%.(%a+)%(", encodegg)
DATA = DATA:gsub("io%.(%a+)%(", encodeio)
DATA = DATA:gsub("os%.(%a+)%(", encodeos)
DATA = DATA:gsub("table%.(%a+)%(", encodetbl)
DATA = DATA:gsub("debug%.(%a+)%(", encodedebug)
DATA = DATA:gsub("print%.(%a+)%(", encodeprint)
DATA = DATA:gsub("loadfile%.(%a+)%(", encodefile)
DATA = DATA:gsub("string%.(%a+)%(", encodestr)

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--DATA = Decode .. DATA
DATA = lock2..Infinite..Infinite2..AntiLasm..Decode..DATA

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

DATA = ""..DATA

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

io.open(g.out,"w"):write(string.gsub(string.dump(load(DATA), true), 'LuaR', 'LuaR', 1)):close()
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
ClU = '📂 File Saved To: '..g.out..'\n'
gg.alert(ClU, '')
print("\n▬▬▬▬▬▬▬▬▬▬▬▬▬\n📂 File Saved To :" .. g.out .. "\n▬▬▬▬▬▬▬▬▬▬▬▬▬")
return 

end
