.class public Lluaj/LoadState;
.super Ljava/lang/Object;
.source "LoadState.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lluaj/LoadState$BadHeader;,
        Lluaj/LoadState$GlobalsUndumper;
    }
.end annotation


# static fields
.field public static final LUAC_FORMAT:I = 0x0

.field public static final LUAC_HEADERSIZE:I = 0xc

.field public static final LUAC_TAIL:[B

.field public static final LUAC_VERSION:I = 0x52

.field public static final LUA_SIGNATURE:[B

.field public static final LUA_TBOOLEAN:I = 0x1

.field public static final LUA_TFUNCTION:I = 0x6

.field public static final LUA_TINT:I = -0x2

.field public static final LUA_TNIL:I = 0x0

.field public static final LUA_TNONE:I = -0x1

.field public static final LUA_TNUMBER:I = 0x3

.field public static final LUA_TSTRING:I = 0x4

.field public static final LUA_TTABLE:I = 0x5

.field public static final LUA_TTHREAD:I = 0x8

.field public static final LUA_TUSERDATA:I = 0x7

.field public static final LUA_TVALUE:I = 0x9

.field private static final NOINTS:[I

.field private static final NOLOCVARS:[Lluaj/LocVars;

.field private static final NOPROTOS:[Lluaj/Prototype;

.field private static final NOUPVALDESCS:[Lluaj/Upvaldesc;

.field private static final NOVALUES:[Lluaj/LuaValue;

.field public static final NUMBER_FORMAT_FLOATS_OR_DOUBLES:I = 0x0

.field public static final NUMBER_FORMAT_INTS_ONLY:I = 0x1

.field public static final NUMBER_FORMAT_NUM_PATCH_INT32:I = 0x4

.field public static final SOURCE_BINARY_STRING:Ljava/lang/String; = "=?"

.field public static volatile badHeader:Z

.field public static encoding:Ljava/lang/String;

.field public static final instance:Lluaj/Globals$Undumper;


# instance fields
.field private buf:[B

.field public final is:Ljava/io/DataInputStream;

.field private luacFormat:I

.field private luacLittleEndian:Z

.field private luacNumberFormat:I

.field private luacSizeofInstruction:I

.field private luacSizeofInt:I

.field private luacSizeofLuaNumber:I

.field private luacSizeofSizeT:I

.field private luacVersion:I

.field name:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    new-instance v0, Lluaj/LoadState$GlobalsUndumper;

    invoke-direct {v0, v2}, Lluaj/LoadState$GlobalsUndumper;-><init>(Lluaj/LoadState$GlobalsUndumper;)V

    sput-object v0, Lluaj/LoadState;->instance:Lluaj/Globals$Undumper;

    sput-object v2, Lluaj/LoadState;->encoding:Ljava/lang/String;

    const/4 v0, 0x4

    new-array v0, v0, [B

    fill-array-data v0, :array_32

    sput-object v0, Lluaj/LoadState;->LUA_SIGNATURE:[B

    const/4 v0, 0x6

    new-array v0, v0, [B

    fill-array-data v0, :array_38

    sput-object v0, Lluaj/LoadState;->LUAC_TAIL:[B

    new-array v0, v1, [Lluaj/LuaValue;

    sput-object v0, Lluaj/LoadState;->NOVALUES:[Lluaj/LuaValue;

    new-array v0, v1, [Lluaj/Prototype;

    sput-object v0, Lluaj/LoadState;->NOPROTOS:[Lluaj/Prototype;

    new-array v0, v1, [Lluaj/LocVars;

    sput-object v0, Lluaj/LoadState;->NOLOCVARS:[Lluaj/LocVars;

    new-array v0, v1, [Lluaj/Upvaldesc;

    sput-object v0, Lluaj/LoadState;->NOUPVALDESCS:[Lluaj/Upvaldesc;

    new-array v0, v1, [I

    sput-object v0, Lluaj/LoadState;->NOINTS:[I

    sput-boolean v1, Lluaj/LoadState;->badHeader:Z

    return-void

    :array_32
    .array-data 1
        0x1bt
        0x4ct
        0x75t
        0x61t
    .end array-data

    :array_38
    .array-data 1
        0x19t
        -0x6dt
        0xdt
        0xat
        0x1at
        0xat
    .end array-data
.end method

.method private constructor <init>(Ljava/io/InputStream;Ljava/lang/String;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x200

    new-array v0, v0, [B

    iput-object v0, p0, Lluaj/LoadState;->buf:[B

    iput-object p2, p0, Lluaj/LoadState;->name:Ljava/lang/String;

    new-instance v0, Ljava/io/DataInputStream;

    invoke-direct {v0, p1}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    iput-object v0, p0, Lluaj/LoadState;->is:Ljava/io/DataInputStream;

    return-void
.end method

.method private static fillSource(Lluaj/Prototype;Lluaj/LuaString;)Lluaj/Prototype;
    .registers 5

    iget-object v1, p0, Lluaj/Prototype;->source:Lluaj/LuaString;

    if-nez v1, :cond_6

    iput-object p1, p0, Lluaj/Prototype;->source:Lluaj/LuaString;

    :cond_6
    const/4 v0, 0x0

    :goto_7
    iget-object v1, p0, Lluaj/Prototype;->p:[Lluaj/Prototype;

    array-length v1, v1

    if-lt v0, v1, :cond_d

    return-object p0

    :cond_d
    iget-object v1, p0, Lluaj/Prototype;->p:[Lluaj/Prototype;

    aget-object v1, v1, v0

    iget-object v2, p0, Lluaj/Prototype;->source:Lluaj/LuaString;

    invoke-static {v1, v2}, Lluaj/LoadState;->fillSource(Lluaj/Prototype;Lluaj/LuaString;)Lluaj/Prototype;

    add-int/lit8 v0, v0, 0x1

    goto :goto_7
.end method

.method public static getSourceName(Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    move-object v0, p0

    const-string v1, "@"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_11

    const-string v1, "="

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_17

    :cond_11
    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    :cond_16
    :goto_16
    return-object v0

    :cond_17
    const-string v1, "\u001b"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_16

    const-string v0, "=?"

    goto :goto_16
.end method

.method public static install(Lluaj/Globals;)V
    .registers 2

    sget-object v0, Lluaj/LoadState;->instance:Lluaj/Globals$Undumper;

    iput-object v0, p0, Lluaj/Globals;->undumper:Lluaj/Globals$Undumper;

    return-void
.end method

.method public static longBitsToLuaNumber(J)Lluaj/LuaValue;
    .registers 14

    const-wide v8, 0x7fffffffffffffffL

    and-long/2addr v8, p0

    const-wide/16 v10, 0x0

    cmp-long v7, v8, v10

    if-nez v7, :cond_f

    sget-object v7, Lluaj/LuaValue;->ZERO:Lluaj/LuaNumber;

    :goto_e
    return-object v7

    :cond_f
    const/16 v7, 0x34

    shr-long v8, p0, v7

    const-wide/16 v10, 0x7ff

    and-long/2addr v8, v10

    long-to-int v7, v8

    add-int/lit16 v0, v7, -0x3ff

    if-ltz v0, :cond_4f

    const/16 v7, 0x1f

    if-ge v0, v7, :cond_4f

    const-wide v8, 0xfffffffffffffL

    and-long v2, p0, v8

    rsub-int/lit8 v6, v0, 0x34

    const-wide/16 v8, 0x1

    shl-long/2addr v8, v6

    const-wide/16 v10, 0x1

    sub-long v4, v8, v10

    and-long v8, v2, v4

    const-wide/16 v10, 0x0

    cmp-long v7, v8, v10

    if-nez v7, :cond_4f

    shr-long v8, v2, v6

    long-to-int v7, v8

    const/4 v8, 0x1

    shl-int/2addr v8, v0

    or-int v1, v7, v8

    const/16 v7, 0x3f

    shr-long v8, p0, v7

    const-wide/16 v10, 0x0

    cmp-long v7, v8, v10

    if-eqz v7, :cond_49

    neg-int v1, v1

    :cond_49
    int-to-long v8, v1

    invoke-static {v8, v9}, Lluaj/LuaLong;->valueOf(J)Lluaj/LuaLong;

    move-result-object v7

    goto :goto_e

    :cond_4f
    invoke-static {p0, p1}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v8

    invoke-static {v8, v9}, Lluaj/LuaValue;->valueOf(D)Lluaj/LuaNumber;

    move-result-object v7

    goto :goto_e
.end method

.method public static undump(Ljava/io/InputStream;Ljava/lang/String;)Lluaj/Prototype;
    .registers 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    if-nez p1, :cond_f

    move-object v1, v2

    :goto_4
    new-instance v0, Lluaj/LoadState;

    invoke-direct {v0, p0, v1}, Lluaj/LoadState;-><init>(Ljava/io/InputStream;Ljava/lang/String;)V

    invoke-virtual {v0}, Lluaj/LoadState;->loadHeader()V

    if-nez p1, :cond_14

    :goto_e
    return-object v2

    :cond_f
    invoke-static {p1}, Lluaj/LoadState;->getSourceName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_4

    :cond_14
    iget v2, v0, Lluaj/LoadState;->luacNumberFormat:I

    packed-switch v2, :pswitch_data_3e

    :pswitch_19  #0x2, 0x3
    new-instance v2, Lluaj/LuaError;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "unsupported int size: "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v4, v0, Lluaj/LoadState;->luacNumberFormat:I

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Lluaj/LuaError;-><init>(Ljava/lang/String;)V

    throw v2

    :pswitch_30  #0x0, 0x1, 0x4
    invoke-virtual {v0}, Lluaj/LoadState;->loadFunction()Lluaj/Prototype;

    move-result-object v2

    invoke-static {v1}, Lluaj/LuaString;->valueOf(Ljava/lang/String;)Lluaj/LuaString;

    move-result-object v3

    invoke-static {v2, v3}, Lluaj/LoadState;->fillSource(Lluaj/Prototype;Lluaj/LuaString;)Lluaj/Prototype;

    move-result-object v2

    goto :goto_e

    nop

    :pswitch_data_3e
    .packed-switch 0x0
        :pswitch_30  #00000000
        :pswitch_30  #00000001
        :pswitch_19  #00000002
        :pswitch_19  #00000003
        :pswitch_30  #00000004
    .end packed-switch
.end method


# virtual methods
.method loadConstants(Lluaj/Prototype;)V
    .registers 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0}, Lluaj/LoadState;->loadInt()I

    move-result v1

    if-lez v1, :cond_1b

    new-array v3, v1, [Lluaj/LuaValue;

    :goto_8
    const/4 v0, 0x0

    :goto_9
    if-lt v0, v1, :cond_1e

    iput-object v3, p1, Lluaj/Prototype;->k:[Lluaj/LuaValue;

    invoke-virtual {p0}, Lluaj/LoadState;->loadInt()I

    move-result v1

    if-lez v1, :cond_60

    new-array v2, v1, [Lluaj/Prototype;

    :goto_15
    const/4 v0, 0x0

    :goto_16
    if-lt v0, v1, :cond_63

    iput-object v2, p1, Lluaj/Prototype;->p:[Lluaj/Prototype;

    return-void

    :cond_1b
    sget-object v3, Lluaj/LoadState;->NOVALUES:[Lluaj/LuaValue;

    goto :goto_8

    :cond_1e
    iget-object v4, p0, Lluaj/LoadState;->is:Ljava/io/DataInputStream;

    invoke-virtual {v4}, Ljava/io/DataInputStream;->readByte()B

    move-result v4

    packed-switch v4, :pswitch_data_6c

    :pswitch_27  #0xffffffff, 0x2
    new-instance v4, Ljava/lang/IllegalStateException;

    const-string v5, "bad constant"

    invoke-direct {v4, v5}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v4

    :pswitch_2f  #0x0
    sget-object v4, Lluaj/LuaValue;->NIL:Lluaj/LuaValue;

    aput-object v4, v3, v0

    :goto_33
    add-int/lit8 v0, v0, 0x1

    goto :goto_9

    :pswitch_36  #0x1
    iget-object v4, p0, Lluaj/LoadState;->is:Ljava/io/DataInputStream;

    invoke-virtual {v4}, Ljava/io/DataInputStream;->readUnsignedByte()I

    move-result v4

    if-eqz v4, :cond_43

    sget-object v4, Lluaj/LuaValue;->TRUE:Lluaj/LuaBoolean;

    :goto_40
    aput-object v4, v3, v0

    goto :goto_33

    :cond_43
    sget-object v4, Lluaj/LuaValue;->FALSE:Lluaj/LuaBoolean;

    goto :goto_40

    :pswitch_46  #0xfffffffe
    invoke-virtual {p0}, Lluaj/LoadState;->loadInt()I

    move-result v4

    int-to-long v4, v4

    invoke-static {v4, v5}, Lluaj/LuaLong;->valueOf(J)Lluaj/LuaLong;

    move-result-object v4

    aput-object v4, v3, v0

    goto :goto_33

    :pswitch_52  #0x3
    invoke-virtual {p0}, Lluaj/LoadState;->loadNumber()Lluaj/LuaValue;

    move-result-object v4

    aput-object v4, v3, v0

    goto :goto_33

    :pswitch_59  #0x4
    invoke-virtual {p0}, Lluaj/LoadState;->loadString()Lluaj/LuaString;

    move-result-object v4

    aput-object v4, v3, v0

    goto :goto_33

    :cond_60
    sget-object v2, Lluaj/LoadState;->NOPROTOS:[Lluaj/Prototype;

    goto :goto_15

    :cond_63
    invoke-virtual {p0}, Lluaj/LoadState;->loadFunction()Lluaj/Prototype;

    move-result-object v4

    aput-object v4, v2, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_16

    :pswitch_data_6c
    .packed-switch -0x2
        :pswitch_46  #fffffffe
        :pswitch_27  #ffffffff
        :pswitch_2f  #00000000
        :pswitch_36  #00000001
        :pswitch_27  #00000002
        :pswitch_52  #00000003
        :pswitch_59  #00000004
    .end packed-switch
.end method

.method loadDebug(Lluaj/Prototype;)V
    .registers 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0}, Lluaj/LoadState;->loadString()Lluaj/LuaString;

    move-result-object v3

    if-eqz v3, :cond_8

    iput-object v3, p1, Lluaj/Prototype;->source:Lluaj/LuaString;

    :cond_8
    invoke-virtual {p0}, Lluaj/LoadState;->loadIntArray()[I

    move-result-object v6

    iput-object v6, p1, Lluaj/Prototype;->lineinfo:[I

    invoke-virtual {p0}, Lluaj/LoadState;->loadInt()I

    move-result v2

    if-lez v2, :cond_23

    new-array v6, v2, [Lluaj/LocVars;

    :goto_16
    iput-object v6, p1, Lluaj/Prototype;->locvars:[Lluaj/LocVars;

    const/4 v1, 0x0

    :goto_19
    if-lt v1, v2, :cond_26

    invoke-virtual {p0}, Lluaj/LoadState;->loadInt()I

    move-result v2

    const/4 v1, 0x0

    :goto_20
    if-lt v1, v2, :cond_3e

    return-void

    :cond_23
    sget-object v6, Lluaj/LoadState;->NOLOCVARS:[Lluaj/LocVars;

    goto :goto_16

    :cond_26
    invoke-virtual {p0}, Lluaj/LoadState;->loadString()Lluaj/LuaString;

    move-result-object v5

    invoke-virtual {p0}, Lluaj/LoadState;->loadInt()I

    move-result v4

    invoke-virtual {p0}, Lluaj/LoadState;->loadInt()I

    move-result v0

    iget-object v6, p1, Lluaj/Prototype;->locvars:[Lluaj/LocVars;

    new-instance v7, Lluaj/LocVars;

    invoke-direct {v7, v5, v4, v0}, Lluaj/LocVars;-><init>(Lluaj/LuaString;II)V

    aput-object v7, v6, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_19

    :cond_3e
    iget-object v6, p1, Lluaj/Prototype;->upvalues:[Lluaj/Upvaldesc;

    aget-object v6, v6, v1

    invoke-virtual {p0}, Lluaj/LoadState;->loadString()Lluaj/LuaString;

    move-result-object v7

    iput-object v7, v6, Lluaj/Upvaldesc;->name:Lluaj/LuaString;

    add-int/lit8 v1, v1, 0x1

    goto :goto_20
.end method

.method public loadFunction()Lluaj/Prototype;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    new-instance v0, Lluaj/Prototype;

    invoke-direct {v0}, Lluaj/Prototype;-><init>()V

    invoke-virtual {p0}, Lluaj/LoadState;->loadInt()I

    move-result v1

    const/4 v2, 0x1

    if-eq v1, v2, :cond_14

    new-instance v0, Lluaj/LuaError;

    const-string v1, "no suport for this"

    invoke-direct {v0, v1}, Lluaj/LuaError;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_14
    invoke-virtual {p0}, Lluaj/LoadState;->loadInt()I

    move-result v1

    iput v1, v0, Lluaj/Prototype;->linedefined:I

    invoke-virtual {p0}, Lluaj/LoadState;->loadInt()I

    move-result v1

    iput v1, v0, Lluaj/Prototype;->lastlinedefined:I

    iget-object v1, p0, Lluaj/LoadState;->is:Ljava/io/DataInputStream;

    invoke-virtual {v1}, Ljava/io/DataInputStream;->readUnsignedByte()I

    move-result v1

    iput v1, v0, Lluaj/Prototype;->numparams:I

    iget-object v1, p0, Lluaj/LoadState;->is:Ljava/io/DataInputStream;

    invoke-virtual {v1}, Ljava/io/DataInputStream;->readUnsignedByte()I

    move-result v1

    iput v1, v0, Lluaj/Prototype;->is_vararg:I

    iget-object v1, p0, Lluaj/LoadState;->is:Ljava/io/DataInputStream;

    invoke-virtual {v1}, Ljava/io/DataInputStream;->readUnsignedByte()I

    move-result v1

    iput v1, v0, Lluaj/Prototype;->maxstacksize:I

    iget v1, v0, Lluaj/Prototype;->maxstacksize:I

    iget v2, v0, Lluaj/Prototype;->numparams:I

    if-ge v1, v2, :cond_67

    new-instance v1, Lluaj/LuaError;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Damaged script 2: .maxstacksize ("

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v3, v0, Lluaj/Prototype;->maxstacksize:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ") < .numparams ("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v3, v0, Lluaj/Prototype;->numparams:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ")"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Lluaj/LuaError;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_67
    invoke-virtual {p0}, Lluaj/LoadState;->loadIntArray()[I

    move-result-object v1

    iput-object v1, v0, Lluaj/Prototype;->code:[I

    invoke-virtual {p0, v0}, Lluaj/LoadState;->loadConstants(Lluaj/Prototype;)V

    invoke-virtual {p0, v0}, Lluaj/LoadState;->loadUpvalues(Lluaj/Prototype;)V

    invoke-virtual {p0, v0}, Lluaj/LoadState;->loadDebug(Lluaj/Prototype;)V

    return-object v0
.end method

.method public loadHeader()V
    .registers 16
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v14, 0x4

    const v13, 0x7f070338

    const/4 v12, 0x2

    const/4 v7, 0x0

    const/4 v6, 0x1

    iget-object v5, p0, Lluaj/LoadState;->is:Ljava/io/DataInputStream;

    invoke-virtual {v5}, Ljava/io/DataInputStream;->readByte()B

    move-result v5

    and-int/lit16 v5, v5, 0xff

    iput v5, p0, Lluaj/LoadState;->luacVersion:I

    iget-object v5, p0, Lluaj/LoadState;->is:Ljava/io/DataInputStream;

    invoke-virtual {v5}, Ljava/io/DataInputStream;->readByte()B

    move-result v5

    and-int/lit16 v5, v5, 0xff

    iput v5, p0, Lluaj/LoadState;->luacFormat:I

    iget-object v5, p0, Lluaj/LoadState;->is:Ljava/io/DataInputStream;

    invoke-virtual {v5}, Ljava/io/DataInputStream;->readByte()B

    move-result v0

    if-eqz v0, :cond_379

    move v5, v6

    :goto_24
    iput-boolean v5, p0, Lluaj/LoadState;->luacLittleEndian:Z

    iget-object v5, p0, Lluaj/LoadState;->is:Ljava/io/DataInputStream;

    invoke-virtual {v5}, Ljava/io/DataInputStream;->readByte()B

    move-result v5

    and-int/lit16 v5, v5, 0xff

    iput v5, p0, Lluaj/LoadState;->luacSizeofInt:I

    iget-object v5, p0, Lluaj/LoadState;->is:Ljava/io/DataInputStream;

    invoke-virtual {v5}, Ljava/io/DataInputStream;->readByte()B

    move-result v5

    and-int/lit16 v5, v5, 0xff

    iput v5, p0, Lluaj/LoadState;->luacSizeofSizeT:I

    iget-object v5, p0, Lluaj/LoadState;->is:Ljava/io/DataInputStream;

    invoke-virtual {v5}, Ljava/io/DataInputStream;->readByte()B

    move-result v5

    and-int/lit16 v5, v5, 0xff

    iput v5, p0, Lluaj/LoadState;->luacSizeofInstruction:I

    iget-object v5, p0, Lluaj/LoadState;->is:Ljava/io/DataInputStream;

    invoke-virtual {v5}, Ljava/io/DataInputStream;->readByte()B

    move-result v5

    and-int/lit16 v5, v5, 0xff

    iput v5, p0, Lluaj/LoadState;->luacSizeofLuaNumber:I

    iget-object v5, p0, Lluaj/LoadState;->is:Ljava/io/DataInputStream;

    invoke-virtual {v5}, Ljava/io/DataInputStream;->readByte()B

    move-result v5

    and-int/lit16 v5, v5, 0xff

    iput v5, p0, Lluaj/LoadState;->luacNumberFormat:I

    const-string v2, ""

    iget v5, p0, Lluaj/LoadState;->luacVersion:I

    const/16 v8, 0x52

    if-eq v5, v8, :cond_cc

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v5, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const v8, 0x7f070332

    invoke-static {v8}, Landroid/ext/Re;->s(I)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, " "

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-static {v13}, Landroid/ext/Re;->s(I)Ljava/lang/String;

    move-result-object v8

    new-array v9, v12, [Ljava/lang/Object;

    new-instance v10, Ljava/lang/StringBuilder;

    const-string v11, "\'"

    invoke-direct {v10, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v11, 0x52

    invoke-static {v11}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, "\'"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    aput-object v10, v9, v7

    new-instance v10, Ljava/lang/StringBuilder;

    const-string v11, "\'"

    invoke-direct {v10, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v11, p0, Lluaj/LoadState;->luacVersion:I

    invoke-static {v11}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, "\'"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    aput-object v10, v9, v6

    invoke-static {v8, v9}, Landroid/ext/Tools;->stringFormat(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, "\n"

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :cond_cc
    iget v5, p0, Lluaj/LoadState;->luacFormat:I

    if-eqz v5, :cond_11f

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v5, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const v8, 0x7f070333

    invoke-static {v8}, Landroid/ext/Re;->s(I)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, " "

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-static {v13}, Landroid/ext/Re;->s(I)Ljava/lang/String;

    move-result-object v8

    new-array v9, v12, [Ljava/lang/Object;

    const-string v10, "\'0\'"

    aput-object v10, v9, v7

    new-instance v10, Ljava/lang/StringBuilder;

    const-string v11, "\'"

    invoke-direct {v10, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v11, p0, Lluaj/LoadState;->luacFormat:I

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, "\'"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    aput-object v10, v9, v6

    invoke-static {v8, v9}, Landroid/ext/Tools;->stringFormat(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, "\n"

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :cond_11f
    if-eqz v0, :cond_18c

    if-eq v0, v6, :cond_18c

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v5, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const v8, 0x7f070334

    invoke-static {v8}, Landroid/ext/Re;->s(I)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, " "

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-static {v13}, Landroid/ext/Re;->s(I)Ljava/lang/String;

    move-result-object v8

    new-array v9, v12, [Ljava/lang/Object;

    new-instance v10, Ljava/lang/StringBuilder;

    const-string v11, "\'0\' "

    invoke-direct {v10, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const v11, 0x7f070339

    invoke-static {v11}, Landroid/ext/Re;->s(I)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, " \'1\'"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    aput-object v10, v9, v7

    new-instance v10, Ljava/lang/StringBuilder;

    const-string v11, "\'"

    invoke-direct {v10, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    and-int/lit16 v11, v0, 0xff

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, "\'"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    aput-object v10, v9, v6

    invoke-static {v8, v9}, Landroid/ext/Tools;->stringFormat(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, "\n"

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :cond_18c
    iget v5, p0, Lluaj/LoadState;->luacSizeofInt:I

    if-eq v5, v14, :cond_1e9

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v5, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const v8, 0x7f070335

    invoke-static {v8}, Landroid/ext/Re;->s(I)Ljava/lang/String;

    move-result-object v8

    new-array v9, v6, [Ljava/lang/Object;

    const-string v10, "int"

    aput-object v10, v9, v7

    invoke-static {v8, v9}, Landroid/ext/Tools;->stringFormat(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, " "

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-static {v13}, Landroid/ext/Re;->s(I)Ljava/lang/String;

    move-result-object v8

    new-array v9, v12, [Ljava/lang/Object;

    const-string v10, "\'4\'"

    aput-object v10, v9, v7

    new-instance v10, Ljava/lang/StringBuilder;

    const-string v11, "\'"

    invoke-direct {v10, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v11, p0, Lluaj/LoadState;->luacSizeofInt:I

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, "\'"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    aput-object v10, v9, v6

    invoke-static {v8, v9}, Landroid/ext/Tools;->stringFormat(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, "\n"

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :cond_1e9
    iget v5, p0, Lluaj/LoadState;->luacSizeofSizeT:I

    if-eq v5, v14, :cond_246

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v5, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const v8, 0x7f070335

    invoke-static {v8}, Landroid/ext/Re;->s(I)Ljava/lang/String;

    move-result-object v8

    new-array v9, v6, [Ljava/lang/Object;

    const-string v10, "size_t"

    aput-object v10, v9, v7

    invoke-static {v8, v9}, Landroid/ext/Tools;->stringFormat(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, " "

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-static {v13}, Landroid/ext/Re;->s(I)Ljava/lang/String;

    move-result-object v8

    new-array v9, v12, [Ljava/lang/Object;

    const-string v10, "\'4\'"

    aput-object v10, v9, v7

    new-instance v10, Ljava/lang/StringBuilder;

    const-string v11, "\'"

    invoke-direct {v10, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v11, p0, Lluaj/LoadState;->luacSizeofSizeT:I

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, "\'"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    aput-object v10, v9, v6

    invoke-static {v8, v9}, Landroid/ext/Tools;->stringFormat(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, "\n"

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :cond_246
    iget v5, p0, Lluaj/LoadState;->luacSizeofInstruction:I

    if-eq v5, v14, :cond_299

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v5, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const v8, 0x7f070336

    invoke-static {v8}, Landroid/ext/Re;->s(I)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, " "

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-static {v13}, Landroid/ext/Re;->s(I)Ljava/lang/String;

    move-result-object v8

    new-array v9, v12, [Ljava/lang/Object;

    const-string v10, "\'4\'"

    aput-object v10, v9, v7

    new-instance v10, Ljava/lang/StringBuilder;

    const-string v11, "\'"

    invoke-direct {v10, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v11, p0, Lluaj/LoadState;->luacSizeofInstruction:I

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, "\'"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    aput-object v10, v9, v6

    invoke-static {v8, v9}, Landroid/ext/Tools;->stringFormat(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, "\n"

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :cond_299
    iget v5, p0, Lluaj/LoadState;->luacSizeofLuaNumber:I

    if-eq v5, v14, :cond_30c

    iget v5, p0, Lluaj/LoadState;->luacSizeofLuaNumber:I

    const/16 v8, 0x8

    if-eq v5, v8, :cond_30c

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v5, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const v8, 0x7f070337

    invoke-static {v8}, Landroid/ext/Re;->s(I)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v8, " "

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-static {v13}, Landroid/ext/Re;->s(I)Ljava/lang/String;

    move-result-object v8

    new-array v9, v12, [Ljava/lang/Object;

    new-instance v10, Ljava/lang/StringBuilder;

    const-string v11, "\'4\' "

    invoke-direct {v10, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const v11, 0x7f070339

    invoke-static {v11}, Landroid/ext/Re;->s(I)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, " \'8\'"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    aput-object v10, v9, v7

    new-instance v7, Ljava/lang/StringBuilder;

    const-string v10, "\'"

    invoke-direct {v7, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v10, p0, Lluaj/LoadState;->luacSizeofLuaNumber:I

    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v10, "\'"

    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    aput-object v7, v9, v6

    invoke-static {v8, v9}, Landroid/ext/Tools;->stringFormat(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v7, "\n"

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :cond_30c
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v5

    if-gez v5, :cond_390

    sget-boolean v5, Lluaj/LoadState;->badHeader:Z

    if-nez v5, :cond_397

    invoke-static {}, Landroid/ext/ThreadManager;->isInUiThread()Z

    move-result v5

    if-nez v5, :cond_397

    sput-boolean v6, Lluaj/LoadState;->badHeader:Z

    new-instance v4, Lluaj/LoadState$BadHeader;

    invoke-direct {v4}, Lluaj/LoadState$BadHeader;-><init>()V

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    iput-object v5, v4, Lluaj/LoadState$BadHeader;->msg:Ljava/lang/String;

    monitor-enter v4

    :try_start_32a
    new-instance v5, Lluaj/LoadState$1;

    invoke-direct {v5, p0, v4}, Lluaj/LoadState$1;-><init>(Lluaj/LoadState;Lluaj/LoadState$BadHeader;)V

    invoke-static {v5}, Landroid/ext/ThreadManager;->runOnUiThread(Ljava/lang/Runnable;)V

    invoke-virtual {v4}, Ljava/lang/Object;->wait()V

    iget-object v5, v4, Lluaj/LoadState$BadHeader;->msg:Ljava/lang/String;

    if-eqz v5, :cond_38f

    new-instance v5, Lluaj/LuaError;

    new-instance v6, Ljava/lang/StringBuilder;

    const v7, 0x7f070331

    invoke-static {v7}, Landroid/ext/Re;->s(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v7, "\n\n"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, "\n"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    const v7, 0x7f07033b

    invoke-static {v7}, Landroid/ext/Re;->s(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Lluaj/LuaError;-><init>(Ljava/lang/String;)V

    throw v5

    :catchall_376
    move-exception v5

    monitor-exit v4
    :try_end_378
    .catchall {:try_start_32a .. :try_end_378} :catchall_376

    throw v5

    :cond_379
    move v5, v7

    goto/16 :goto_24

    move-exception v1

    :try_start_37d
    const-string v5, "Interrupted wait"

    invoke-static {v5, v1}, Landroid/ext/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Thread;->interrupt()V

    new-instance v5, Lluaj/LuaError;

    invoke-direct {v5, v1}, Lluaj/LuaError;-><init>(Ljava/lang/Throwable;)V

    throw v5

    :cond_38f
    monitor-exit v4
    :try_end_390
    .catchall {:try_start_37d .. :try_end_390} :catchall_376

    :cond_390
    :goto_390
    const/4 v3, 0x0

    :goto_391
    sget-object v5, Lluaj/LoadState;->LUAC_TAIL:[B

    array-length v5, v5

    if-lt v3, v5, :cond_3e3

    return-void

    :cond_397
    new-instance v5, Ljava/lang/StringBuilder;

    const-string v7, "-------------------\n"

    invoke-direct {v5, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const v7, 0x7f070331

    invoke-static {v7}, Landroid/ext/Re;->s(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v7, "\n\n"

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v7, "\n"

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const v7, 0x7f07033b

    invoke-static {v7}, Landroid/ext/Re;->s(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v7, "\n-------------------\n"

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5, v6}, Landroid/ext/Tools;->showToast(Ljava/lang/String;I)V

    sget-object v5, Lluaj/Print;->ps:Ljava/io/PrintStream;

    invoke-virtual {v5, v2}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    goto :goto_390

    :cond_3e3
    iget-object v5, p0, Lluaj/LoadState;->is:Ljava/io/DataInputStream;

    invoke-virtual {v5}, Ljava/io/DataInputStream;->readByte()B

    move-result v0

    sget-object v5, Lluaj/LoadState;->LUAC_TAIL:[B

    aget-byte v5, v5, v3

    if-eq v0, v5, :cond_426

    new-instance v5, Lluaj/LuaError;

    new-instance v6, Ljava/lang/StringBuilder;

    const-string v7, "Unexpected byte in luac tail of header, index = "

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " ("

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    and-int/lit16 v7, v0, 0xff

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, ", not "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    sget-object v7, Lluaj/LoadState;->LUAC_TAIL:[B

    aget-byte v7, v7, v3

    and-int/lit16 v7, v7, 0xff

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, ")"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Lluaj/LuaError;-><init>(Ljava/lang/String;)V

    throw v5

    :cond_426
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_391
.end method

.method loadInt()I
    .registers 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lluaj/LoadState;->is:Ljava/io/DataInputStream;

    iget-object v1, p0, Lluaj/LoadState;->buf:[B

    const/4 v2, 0x4

    invoke-virtual {v0, v1, v3, v2}, Ljava/io/DataInputStream;->readFully([BII)V

    iget-boolean v0, p0, Lluaj/LoadState;->luacLittleEndian:Z

    if-eqz v0, :cond_30

    iget-object v0, p0, Lluaj/LoadState;->buf:[B

    aget-byte v0, v0, v6

    shl-int/lit8 v0, v0, 0x18

    iget-object v1, p0, Lluaj/LoadState;->buf:[B

    aget-byte v1, v1, v5

    and-int/lit16 v1, v1, 0xff

    shl-int/lit8 v1, v1, 0x10

    or-int/2addr v0, v1

    iget-object v1, p0, Lluaj/LoadState;->buf:[B

    aget-byte v1, v1, v4

    and-int/lit16 v1, v1, 0xff

    shl-int/lit8 v1, v1, 0x8

    or-int/2addr v0, v1

    iget-object v1, p0, Lluaj/LoadState;->buf:[B

    aget-byte v1, v1, v3

    and-int/lit16 v1, v1, 0xff

    or-int/2addr v0, v1

    :goto_2f
    return v0

    :cond_30
    iget-object v0, p0, Lluaj/LoadState;->buf:[B

    aget-byte v0, v0, v3

    shl-int/lit8 v0, v0, 0x18

    iget-object v1, p0, Lluaj/LoadState;->buf:[B

    aget-byte v1, v1, v4

    and-int/lit16 v1, v1, 0xff

    shl-int/lit8 v1, v1, 0x10

    or-int/2addr v0, v1

    iget-object v1, p0, Lluaj/LoadState;->buf:[B

    aget-byte v1, v1, v5

    and-int/lit16 v1, v1, 0xff

    shl-int/lit8 v1, v1, 0x8

    or-int/2addr v0, v1

    iget-object v1, p0, Lluaj/LoadState;->buf:[B

    aget-byte v1, v1, v6

    and-int/lit16 v1, v1, 0xff

    or-int/2addr v0, v1

    goto :goto_2f
.end method

.method loadInt64()J
    .registers 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-boolean v2, p0, Lluaj/LoadState;->luacLittleEndian:Z

    if-eqz v2, :cond_19

    invoke-virtual {p0}, Lluaj/LoadState;->loadInt()I

    move-result v0

    invoke-virtual {p0}, Lluaj/LoadState;->loadInt()I

    move-result v1

    :goto_c
    int-to-long v2, v1

    const/16 v4, 0x20

    shl-long/2addr v2, v4

    int-to-long v4, v0

    const-wide v6, 0xffffffffL

    and-long/2addr v4, v6

    or-long/2addr v2, v4

    return-wide v2

    :cond_19
    invoke-virtual {p0}, Lluaj/LoadState;->loadInt()I

    move-result v1

    invoke-virtual {p0}, Lluaj/LoadState;->loadInt()I

    move-result v0

    goto :goto_c
.end method

.method loadIntArray()[I
    .registers 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0}, Lluaj/LoadState;->loadInt()I

    move-result v4

    if-nez v4, :cond_9

    sget-object v0, Lluaj/LoadState;->NOINTS:[I

    :cond_8
    return-object v0

    :cond_9
    shl-int/lit8 v3, v4, 0x2

    iget-object v5, p0, Lluaj/LoadState;->buf:[B

    array-length v5, v5

    if-ge v5, v3, :cond_14

    new-array v5, v3, [B

    iput-object v5, p0, Lluaj/LoadState;->buf:[B

    :cond_14
    iget-object v5, p0, Lluaj/LoadState;->is:Ljava/io/DataInputStream;

    iget-object v6, p0, Lluaj/LoadState;->buf:[B

    const/4 v7, 0x0

    invoke-virtual {v5, v6, v7, v3}, Ljava/io/DataInputStream;->readFully([BII)V

    new-array v0, v4, [I

    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_20
    if-ge v1, v4, :cond_8

    iget-boolean v5, p0, Lluaj/LoadState;->luacLittleEndian:Z

    if-eqz v5, :cond_54

    iget-object v5, p0, Lluaj/LoadState;->buf:[B

    add-int/lit8 v6, v2, 0x3

    aget-byte v5, v5, v6

    shl-int/lit8 v5, v5, 0x18

    iget-object v6, p0, Lluaj/LoadState;->buf:[B

    add-int/lit8 v7, v2, 0x2

    aget-byte v6, v6, v7

    and-int/lit16 v6, v6, 0xff

    shl-int/lit8 v6, v6, 0x10

    or-int/2addr v5, v6

    iget-object v6, p0, Lluaj/LoadState;->buf:[B

    add-int/lit8 v7, v2, 0x1

    aget-byte v6, v6, v7

    and-int/lit16 v6, v6, 0xff

    shl-int/lit8 v6, v6, 0x8

    or-int/2addr v5, v6

    iget-object v6, p0, Lluaj/LoadState;->buf:[B

    add-int/lit8 v7, v2, 0x0

    aget-byte v6, v6, v7

    and-int/lit16 v6, v6, 0xff

    or-int/2addr v5, v6

    :goto_4d
    aput v5, v0, v1

    add-int/lit8 v1, v1, 0x1

    add-int/lit8 v2, v2, 0x4

    goto :goto_20

    :cond_54
    iget-object v5, p0, Lluaj/LoadState;->buf:[B

    add-int/lit8 v6, v2, 0x0

    aget-byte v5, v5, v6

    shl-int/lit8 v5, v5, 0x18

    iget-object v6, p0, Lluaj/LoadState;->buf:[B

    add-int/lit8 v7, v2, 0x1

    aget-byte v6, v6, v7

    and-int/lit16 v6, v6, 0xff

    shl-int/lit8 v6, v6, 0x10

    or-int/2addr v5, v6

    iget-object v6, p0, Lluaj/LoadState;->buf:[B

    add-int/lit8 v7, v2, 0x2

    aget-byte v6, v6, v7

    and-int/lit16 v6, v6, 0xff

    shl-int/lit8 v6, v6, 0x8

    or-int/2addr v5, v6

    iget-object v6, p0, Lluaj/LoadState;->buf:[B

    add-int/lit8 v7, v2, 0x3

    aget-byte v6, v6, v7

    and-int/lit16 v6, v6, 0xff

    or-int/2addr v5, v6

    goto :goto_4d
.end method

.method loadNumber()Lluaj/LuaValue;
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget v0, p0, Lluaj/LoadState;->luacNumberFormat:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_f

    invoke-virtual {p0}, Lluaj/LoadState;->loadInt()I

    move-result v0

    int-to-long v0, v0

    invoke-static {v0, v1}, Lluaj/LuaLong;->valueOf(J)Lluaj/LuaLong;

    move-result-object v0

    :goto_e
    return-object v0

    :cond_f
    invoke-virtual {p0}, Lluaj/LoadState;->loadInt64()J

    move-result-wide v0

    invoke-static {v0, v1}, Lluaj/LoadState;->longBitsToLuaNumber(J)Lluaj/LuaValue;

    move-result-object v0

    goto :goto_e
.end method

.method loadString()Lluaj/LuaString;
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x0

    iget v2, p0, Lluaj/LoadState;->luacSizeofSizeT:I

    const/16 v3, 0x8

    if-ne v2, v3, :cond_10

    invoke-virtual {p0}, Lluaj/LoadState;->loadInt64()J

    move-result-wide v2

    long-to-int v1, v2

    :goto_c
    if-nez v1, :cond_15

    const/4 v2, 0x0

    :goto_f
    return-object v2

    :cond_10
    invoke-virtual {p0}, Lluaj/LoadState;->loadInt()I

    move-result v1

    goto :goto_c

    :cond_15
    new-array v0, v1, [B

    iget-object v2, p0, Lluaj/LoadState;->is:Ljava/io/DataInputStream;

    invoke-virtual {v2, v0, v4, v1}, Ljava/io/DataInputStream;->readFully([BII)V

    array-length v2, v0

    add-int/lit8 v2, v2, -0x1

    invoke-static {v0, v4, v2}, Lluaj/LuaString;->valueUsing([BII)Lluaj/LuaString;

    move-result-object v2

    goto :goto_f
.end method

.method loadUpvalues(Lluaj/Prototype;)V
    .registers 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-virtual {p0}, Lluaj/LoadState;->loadInt()I

    move-result v3

    if-lez v3, :cond_1e

    new-array v4, v3, [Lluaj/Upvaldesc;

    :goto_8
    iput-object v4, p1, Lluaj/Prototype;->upvalues:[Lluaj/Upvaldesc;

    const/4 v0, 0x0

    const/4 v5, 0x0

    :goto_c
    if-lt v0, v3, :cond_21

    iget-object v4, p0, Lluaj/LoadState;->is:Ljava/io/DataInputStream;

    invoke-virtual {v4}, Ljava/io/DataInputStream;->readByte()B

    move-result v4

    if-eq v5, v4, :cond_40

    new-instance v4, Ljava/io/IOException;

    const-string v5, "Checksum invalid"

    invoke-direct {v4, v5}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v4

    :cond_1e
    sget-object v4, Lluaj/LoadState;->NOUPVALDESCS:[Lluaj/Upvaldesc;

    goto :goto_8

    :cond_21
    iget-object v4, p0, Lluaj/LoadState;->is:Ljava/io/DataInputStream;

    invoke-virtual {v4}, Ljava/io/DataInputStream;->readByte()B

    move-result v4

    if-eqz v4, :cond_41

    const/4 v2, 0x1

    :goto_2a
    iget-object v4, p0, Lluaj/LoadState;->is:Ljava/io/DataInputStream;

    invoke-virtual {v4}, Ljava/io/DataInputStream;->readByte()B

    move-result v4

    and-int/lit16 v1, v4, 0xff

    add-int/2addr v5, v1

    iget-object v4, p1, Lluaj/Prototype;->upvalues:[Lluaj/Upvaldesc;

    new-instance v6, Lluaj/Upvaldesc;

    const/4 v7, 0x0

    invoke-direct {v6, v7, v2, v1}, Lluaj/Upvaldesc;-><init>(Lluaj/LuaString;ZI)V

    aput-object v6, v4, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_c

    :cond_40
    return-void

    :cond_41
    const/4 v2, 0x0

    goto :goto_2a
.end method
