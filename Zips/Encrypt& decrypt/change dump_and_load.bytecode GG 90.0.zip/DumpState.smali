.class public Lluaj/compiler/DumpState;
.super Ljava/lang/Object;
.source "DumpState.java"


# static fields
.field public static final ALLOW_INTEGER_CASTING:Z = false

.field public static final NUMBER_FORMAT_DEFAULT:I = 0x0

.field public static final NUMBER_FORMAT_FLOATS_OR_DOUBLES:I = 0x0

.field public static final NUMBER_FORMAT_INTS_ONLY:I = 0x1

.field public static final NUMBER_FORMAT_NUM_PATCH_INT32:I = 0x4

.field public static final SIZEOF_INSTRUCTION:I = 0x4

.field public static final SIZEOF_INT:I = 0x4

.field public static final SIZEOF_SIZET:I = 0x4


# instance fields
.field private IS_LITTLE_ENDIAN:Z

.field private NUMBER_FORMAT:I

.field private SIZEOF_LUA_NUMBER:I

.field fix:Z

.field status:I

.field strip:Z

.field writer:Ljava/io/DataOutputStream;


# direct methods
.method public constructor <init>(Ljava/io/OutputStream;ZZ)V
    .registers 6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lluaj/compiler/DumpState;->IS_LITTLE_ENDIAN:Z

    iput v1, p0, Lluaj/compiler/DumpState;->NUMBER_FORMAT:I

    const/16 v0, 0x8

    iput v0, p0, Lluaj/compiler/DumpState;->SIZEOF_LUA_NUMBER:I

    new-instance v0, Ljava/io/DataOutputStream;

    invoke-direct {v0, p1}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    iput-object v0, p0, Lluaj/compiler/DumpState;->writer:Ljava/io/DataOutputStream;

    iput-boolean p2, p0, Lluaj/compiler/DumpState;->strip:Z

    iput-boolean p3, p0, Lluaj/compiler/DumpState;->fix:Z

    iput v1, p0, Lluaj/compiler/DumpState;->status:I

    return-void
.end method

.method public static dump(Lluaj/Prototype;Ljava/io/OutputStream;ZIZ)I
    .registers 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    packed-switch p3, :pswitch_data_36

    :pswitch_3  #0x2, 0x3
    new-instance v1, Ljava/lang/IllegalArgumentException;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "number format not supported: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :pswitch_18  #0x0, 0x1, 0x4
    new-instance v0, Lluaj/compiler/DumpState;

    const/4 v1, 0x0

    invoke-direct {v0, p1, p2, v1}, Lluaj/compiler/DumpState;-><init>(Ljava/io/OutputStream;ZZ)V

    iput-boolean p4, v0, Lluaj/compiler/DumpState;->IS_LITTLE_ENDIAN:Z

    iput p3, v0, Lluaj/compiler/DumpState;->NUMBER_FORMAT:I

    const/4 v1, 0x1

    if-ne p3, v1, :cond_32

    const/4 v1, 0x4

    :goto_26
    iput v1, v0, Lluaj/compiler/DumpState;->SIZEOF_LUA_NUMBER:I

    invoke-virtual {v0}, Lluaj/compiler/DumpState;->dumpHeader()V

    const/4 v1, 0x0

    invoke-virtual {v0, p0, v1}, Lluaj/compiler/DumpState;->dumpFunction(Lluaj/Prototype;Lluaj/LuaString;)V

    iget v1, v0, Lluaj/compiler/DumpState;->status:I

    return v1

    :cond_32
    const/16 v1, 0x8

    goto :goto_26

    nop

    :pswitch_data_36
    .packed-switch 0x0
        :pswitch_18  #00000000
        :pswitch_18  #00000001
        :pswitch_3  #00000002
        :pswitch_3  #00000003
        :pswitch_18  #00000004
    .end packed-switch
.end method

.method public static dump(Lluaj/Prototype;Ljava/io/OutputStream;ZZ)I
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    new-instance v0, Lluaj/compiler/DumpState;

    invoke-direct {v0, p1, p2, p3}, Lluaj/compiler/DumpState;-><init>(Ljava/io/OutputStream;ZZ)V

    invoke-virtual {v0}, Lluaj/compiler/DumpState;->dumpHeader()V

    const/4 v1, 0x0

    invoke-virtual {v0, p0, v1}, Lluaj/compiler/DumpState;->dumpFunction(Lluaj/Prototype;Lluaj/LuaString;)V

    iget v1, v0, Lluaj/compiler/DumpState;->status:I

    return v1
.end method


# virtual methods
.method dumpBlock([BI)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p0, Lluaj/compiler/DumpState;->writer:Ljava/io/DataOutputStream;

    const/4 v1, 0x0

    invoke-virtual {v0, p1, v1, p2}, Ljava/io/DataOutputStream;->write([BII)V

    return-void
.end method

.method dumpChar(I)V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p0, Lluaj/compiler/DumpState;->writer:Ljava/io/DataOutputStream;

    invoke-virtual {v0, p1}, Ljava/io/DataOutputStream;->write(I)V

    return-void
.end method

.method dumpCode(Lluaj/Prototype;)V
    .registers 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p1, Lluaj/Prototype;->code:[I

    array-length v2, v0

    invoke-virtual {p0, v2}, Lluaj/compiler/DumpState;->dumpInt(I)V

    iget-boolean v4, p0, Lluaj/compiler/DumpState;->fix:Z

    if-eqz v4, :cond_17

    new-array v1, v2, [I

    :goto_c
    iget-boolean v4, p0, Lluaj/compiler/DumpState;->fix:Z

    if-eqz v4, :cond_13

    invoke-static {p1, v1}, Lluaj/Print;->fix(Lluaj/Prototype;[I)[B

    :cond_13
    const/4 v3, 0x0

    :goto_14
    if-lt v3, v2, :cond_19

    return-void

    :cond_17
    move-object v1, v0

    goto :goto_c

    :cond_19
    aget v4, v1, v3

    invoke-virtual {p0, v4}, Lluaj/compiler/DumpState;->dumpInt(I)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_14
.end method

.method dumpConstants(Lluaj/Prototype;)V
    .registers 13
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v6, 0x1

    const/4 v7, 0x0

    const/4 v10, 0x3

    iget-object v4, p0, Lluaj/compiler/DumpState;->writer:Ljava/io/DataOutputStream;

    iget-object v1, p1, Lluaj/Prototype;->k:[Lluaj/LuaValue;

    array-length v2, v1

    invoke-virtual {p0, v2}, Lluaj/compiler/DumpState;->dumpInt(I)V

    const/4 v0, 0x0

    :goto_c
    if-lt v0, v2, :cond_18

    iget-object v5, p1, Lluaj/Prototype;->p:[Lluaj/Prototype;

    array-length v2, v5

    invoke-virtual {p0, v2}, Lluaj/compiler/DumpState;->dumpInt(I)V

    const/4 v0, 0x0

    :goto_15
    if-lt v0, v2, :cond_c1

    return-void

    :cond_18
    aget-object v3, v1, v0

    invoke-virtual {v3}, Lluaj/LuaValue;->type()I

    move-result v5

    packed-switch v5, :pswitch_data_ce

    :pswitch_21  #0x2
    new-instance v5, Ljava/lang/IllegalArgumentException;

    new-instance v6, Ljava/lang/StringBuilder;

    const-string v7, "bad type for "

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v5

    :pswitch_36  #0x0
    invoke-virtual {v4, v7}, Ljava/io/DataOutputStream;->write(I)V

    :goto_39
    add-int/lit8 v0, v0, 0x1

    goto :goto_c

    :pswitch_3c  #0x1
    invoke-virtual {v4, v6}, Ljava/io/DataOutputStream;->write(I)V

    invoke-virtual {v3}, Lluaj/LuaValue;->toboolean()Z

    move-result v5

    if-eqz v5, :cond_4a

    move v5, v6

    :goto_46
    invoke-virtual {p0, v5}, Lluaj/compiler/DumpState;->dumpChar(I)V

    goto :goto_39

    :cond_4a
    move v5, v7

    goto :goto_46

    :pswitch_4c  #0x3
    iget v5, p0, Lluaj/compiler/DumpState;->NUMBER_FORMAT:I

    packed-switch v5, :pswitch_data_dc

    :pswitch_51  #0x2, 0x3
    new-instance v5, Ljava/lang/IllegalArgumentException;

    new-instance v6, Ljava/lang/StringBuilder;

    const-string v7, "number format not supported: "

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v7, p0, Lluaj/compiler/DumpState;->NUMBER_FORMAT:I

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v5

    :pswitch_68  #0x0
    invoke-virtual {v4, v10}, Ljava/io/DataOutputStream;->write(I)V

    invoke-virtual {v3}, Lluaj/LuaValue;->todouble()D

    move-result-wide v8

    invoke-virtual {p0, v8, v9}, Lluaj/compiler/DumpState;->dumpDouble(D)V

    goto :goto_39

    :pswitch_73  #0x1
    invoke-virtual {v3}, Lluaj/LuaValue;->isint()Z

    move-result v5

    if-nez v5, :cond_8e

    new-instance v5, Ljava/lang/IllegalArgumentException;

    new-instance v6, Ljava/lang/StringBuilder;

    const-string v7, "not an integer: "

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v5

    :cond_8e
    invoke-virtual {v4, v10}, Ljava/io/DataOutputStream;->write(I)V

    invoke-virtual {v3}, Lluaj/LuaValue;->toint()I

    move-result v5

    invoke-virtual {p0, v5}, Lluaj/compiler/DumpState;->dumpInt(I)V

    goto :goto_39

    :pswitch_99  #0x4
    invoke-virtual {v3}, Lluaj/LuaValue;->isint()Z

    move-result v5

    if-eqz v5, :cond_ab

    const/4 v5, -0x2

    invoke-virtual {v4, v5}, Ljava/io/DataOutputStream;->write(I)V

    invoke-virtual {v3}, Lluaj/LuaValue;->toint()I

    move-result v5

    invoke-virtual {p0, v5}, Lluaj/compiler/DumpState;->dumpInt(I)V

    goto :goto_39

    :cond_ab
    invoke-virtual {v4, v10}, Ljava/io/DataOutputStream;->write(I)V

    invoke-virtual {v3}, Lluaj/LuaValue;->todouble()D

    move-result-wide v8

    invoke-virtual {p0, v8, v9}, Lluaj/compiler/DumpState;->dumpDouble(D)V

    goto :goto_39

    :pswitch_b6  #0x4
    const/4 v5, 0x4

    invoke-virtual {v4, v5}, Ljava/io/DataOutputStream;->write(I)V

    check-cast v3, Lluaj/LuaString;

    invoke-virtual {p0, v3}, Lluaj/compiler/DumpState;->dumpString(Lluaj/LuaString;)V

    goto/16 :goto_39

    :cond_c1
    iget-object v5, p1, Lluaj/Prototype;->p:[Lluaj/Prototype;

    aget-object v5, v5, v0

    iget-object v6, p1, Lluaj/Prototype;->source:Lluaj/LuaString;

    invoke-virtual {p0, v5, v6}, Lluaj/compiler/DumpState;->dumpFunction(Lluaj/Prototype;Lluaj/LuaString;)V

    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_15

    :pswitch_data_ce
    .packed-switch 0x0
        :pswitch_36  #00000000
        :pswitch_3c  #00000001
        :pswitch_21  #00000002
        :pswitch_4c  #00000003
        :pswitch_b6  #00000004
    .end packed-switch

    :pswitch_data_dc
    .packed-switch 0x0
        :pswitch_68  #00000000
        :pswitch_73  #00000001
        :pswitch_51  #00000002
        :pswitch_51  #00000003
        :pswitch_99  #00000004
    .end packed-switch
.end method

.method dumpDebug(Lluaj/Prototype;Lluaj/LuaString;)V
    .registers 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v6, 0x0

    iget-boolean v7, p0, Lluaj/compiler/DumpState;->strip:Z

    if-nez v7, :cond_f

    if-eqz p2, :cond_3a

    iget-object v7, p1, Lluaj/Prototype;->source:Lluaj/LuaString;

    invoke-virtual {p2, v7}, Lluaj/LuaString;->eq_b(Lluaj/LuaValue;)Z

    move-result v7

    if-eqz v7, :cond_3a

    :cond_f
    invoke-virtual {p0, v6}, Lluaj/compiler/DumpState;->dumpInt(I)V

    :goto_12
    iget-object v1, p1, Lluaj/Prototype;->lineinfo:[I

    iget-boolean v7, p0, Lluaj/compiler/DumpState;->strip:Z

    if-eqz v7, :cond_40

    move v4, v6

    :goto_19
    invoke-virtual {p0, v4}, Lluaj/compiler/DumpState;->dumpInt(I)V

    const/4 v0, 0x0

    :goto_1d
    if-lt v0, v4, :cond_42

    iget-object v2, p1, Lluaj/Prototype;->locvars:[Lluaj/LocVars;

    iget-boolean v7, p0, Lluaj/compiler/DumpState;->strip:Z

    if-eqz v7, :cond_4a

    move v4, v6

    :goto_26
    invoke-virtual {p0, v4}, Lluaj/compiler/DumpState;->dumpInt(I)V

    const/4 v0, 0x0

    :goto_2a
    if-lt v0, v4, :cond_4c

    iget-object v5, p1, Lluaj/Prototype;->upvalues:[Lluaj/Upvaldesc;

    iget-boolean v7, p0, Lluaj/compiler/DumpState;->strip:Z

    if-eqz v7, :cond_60

    move v4, v6

    :goto_33
    invoke-virtual {p0, v4}, Lluaj/compiler/DumpState;->dumpInt(I)V

    const/4 v0, 0x0

    :goto_37
    if-lt v0, v4, :cond_62

    return-void

    :cond_3a
    iget-object v7, p1, Lluaj/Prototype;->source:Lluaj/LuaString;

    invoke-virtual {p0, v7}, Lluaj/compiler/DumpState;->dumpString(Lluaj/LuaString;)V

    goto :goto_12

    :cond_40
    array-length v4, v1

    goto :goto_19

    :cond_42
    aget v7, v1, v0

    invoke-virtual {p0, v7}, Lluaj/compiler/DumpState;->dumpInt(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_1d

    :cond_4a
    array-length v4, v2

    goto :goto_26

    :cond_4c
    aget-object v3, v2, v0

    iget-object v7, v3, Lluaj/LocVars;->varname:Lluaj/LuaString;

    invoke-virtual {p0, v7}, Lluaj/compiler/DumpState;->dumpString(Lluaj/LuaString;)V

    iget v7, v3, Lluaj/LocVars;->startpc:I

    invoke-virtual {p0, v7}, Lluaj/compiler/DumpState;->dumpInt(I)V

    iget v7, v3, Lluaj/LocVars;->endpc:I

    invoke-virtual {p0, v7}, Lluaj/compiler/DumpState;->dumpInt(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_2a

    :cond_60
    array-length v4, v5

    goto :goto_33

    :cond_62
    aget-object v6, v5, v0

    iget-object v6, v6, Lluaj/Upvaldesc;->name:Lluaj/LuaString;

    invoke-virtual {p0, v6}, Lluaj/compiler/DumpState;->dumpString(Lluaj/LuaString;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_37
.end method

.method dumpDouble(D)V
    .registers 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    invoke-static {p1, p2}, Ljava/lang/Double;->doubleToLongBits(D)J

    move-result-wide v0

    iget-boolean v2, p0, Lluaj/compiler/DumpState;->IS_LITTLE_ENDIAN:Z

    if-eqz v2, :cond_c

    invoke-static {v0, v1}, Ljava/lang/Long;->reverseBytes(J)J

    move-result-wide v0

    :cond_c
    iget-object v2, p0, Lluaj/compiler/DumpState;->writer:Ljava/io/DataOutputStream;

    invoke-virtual {v2, v0, v1}, Ljava/io/DataOutputStream;->writeLong(J)V

    return-void
.end method

.method dumpFunction(Lluaj/Prototype;Lluaj/LuaString;)V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lluaj/compiler/DumpState;->dumpInt(I)V

    iget v0, p1, Lluaj/Prototype;->linedefined:I

    invoke-virtual {p0, v0}, Lluaj/compiler/DumpState;->dumpInt(I)V

    iget v0, p1, Lluaj/Prototype;->lastlinedefined:I

    invoke-virtual {p0, v0}, Lluaj/compiler/DumpState;->dumpInt(I)V

    iget v0, p1, Lluaj/Prototype;->numparams:I

    invoke-virtual {p0, v0}, Lluaj/compiler/DumpState;->dumpChar(I)V

    iget v0, p1, Lluaj/Prototype;->is_vararg:I

    invoke-virtual {p0, v0}, Lluaj/compiler/DumpState;->dumpChar(I)V

    iget v0, p1, Lluaj/Prototype;->maxstacksize:I

    invoke-virtual {p0, v0}, Lluaj/compiler/DumpState;->dumpChar(I)V

    invoke-virtual {p0, p1}, Lluaj/compiler/DumpState;->dumpCode(Lluaj/Prototype;)V

    invoke-virtual {p0, p1}, Lluaj/compiler/DumpState;->dumpConstants(Lluaj/Prototype;)V

    invoke-virtual {p0, p1}, Lluaj/compiler/DumpState;->dumpUpvalues(Lluaj/Prototype;)V

    invoke-virtual {p0, p1, p2}, Lluaj/compiler/DumpState;->dumpDebug(Lluaj/Prototype;Lluaj/LuaString;)V

    return-void
.end method

.method dumpHeader()V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v3, 0x4

    iget-object v0, p0, Lluaj/compiler/DumpState;->writer:Ljava/io/DataOutputStream;

    sget-object v2, Lluaj/LoadState;->LUA_SIGNATURE:[B

    invoke-virtual {v0, v2}, Ljava/io/DataOutputStream;->write([B)V

    const/16 v2, 0x52

    invoke-virtual {v0, v2}, Ljava/io/DataOutputStream;->write(I)V

    invoke-virtual {v0, v1}, Ljava/io/DataOutputStream;->write(I)V

    iget-boolean v2, p0, Lluaj/compiler/DumpState;->IS_LITTLE_ENDIAN:Z

    if-eqz v2, :cond_16

    const/4 v1, 0x1

    :cond_16
    invoke-virtual {v0, v1}, Ljava/io/DataOutputStream;->write(I)V

    invoke-virtual {v0, v3}, Ljava/io/DataOutputStream;->write(I)V

    invoke-virtual {v0, v3}, Ljava/io/DataOutputStream;->write(I)V

    invoke-virtual {v0, v3}, Ljava/io/DataOutputStream;->write(I)V

    iget v1, p0, Lluaj/compiler/DumpState;->SIZEOF_LUA_NUMBER:I

    invoke-virtual {v0, v1}, Ljava/io/DataOutputStream;->write(I)V

    iget v1, p0, Lluaj/compiler/DumpState;->NUMBER_FORMAT:I

    invoke-virtual {v0, v1}, Ljava/io/DataOutputStream;->write(I)V

    sget-object v1, Lluaj/LoadState;->LUAC_TAIL:[B

    invoke-virtual {v0, v1}, Ljava/io/DataOutputStream;->write([B)V

    return-void
.end method

.method dumpInt(I)V
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p0, Lluaj/compiler/DumpState;->writer:Ljava/io/DataOutputStream;

    iget-boolean v1, p0, Lluaj/compiler/DumpState;->IS_LITTLE_ENDIAN:Z

    if-eqz v1, :cond_a

    invoke-static {p1}, Ljava/lang/Integer;->reverseBytes(I)I

    move-result p1

    :cond_a
    invoke-virtual {v0, p1}, Ljava/io/DataOutputStream;->writeInt(I)V

    return-void
.end method

.method dumpString(Lluaj/LuaString;)V
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    if-nez p1, :cond_9

    const-string v1, ""

    invoke-static {v1}, Lluaj/LuaValue;->valueOf(Ljava/lang/String;)Lluaj/LuaString;

    move-result-object p1

    :cond_9
    invoke-virtual {p1}, Lluaj/LuaString;->len()Lluaj/LuaValue;

    move-result-object v1

    invoke-virtual {v1}, Lluaj/LuaValue;->toint()I

    move-result v0

    add-int/lit8 v1, v0, 0x1

    invoke-virtual {p0, v1}, Lluaj/compiler/DumpState;->dumpInt(I)V

    iget-object v1, p0, Lluaj/compiler/DumpState;->writer:Ljava/io/DataOutputStream;

    invoke-virtual {p1, v1, v2, v0}, Lluaj/LuaString;->write(Ljava/io/DataOutputStream;II)V

    iget-object v1, p0, Lluaj/compiler/DumpState;->writer:Ljava/io/DataOutputStream;

    invoke-virtual {v1, v2}, Ljava/io/DataOutputStream;->write(I)V

    return-void
.end method

.method dumpUpvalues(Lluaj/Prototype;)V
    .registers 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v4, p0, Lluaj/compiler/DumpState;->writer:Ljava/io/DataOutputStream;

    iget-object v3, p1, Lluaj/Prototype;->upvalues:[Lluaj/Upvaldesc;

    array-length v1, v3

    invoke-virtual {p0, v1}, Lluaj/compiler/DumpState;->dumpInt(I)V

    const/4 v0, 0x0

    const/4 v5, 0x0

    :goto_a
    if-lt v0, v1, :cond_10

    invoke-virtual {v4, v5}, Ljava/io/DataOutputStream;->writeByte(I)V

    return-void

    :cond_10
    aget-object v2, v3, v0

    iget-boolean v6, v2, Lluaj/Upvaldesc;->instack:Z

    if-eqz v6, :cond_23

    const/4 v6, 0x1

    :goto_17
    invoke-virtual {v4, v6}, Ljava/io/DataOutputStream;->writeByte(I)V

    iget-short v6, v2, Lluaj/Upvaldesc;->idx:S

    invoke-virtual {v4, v6}, Ljava/io/DataOutputStream;->writeByte(I)V

    add-int/2addr v5, v6

    add-int/lit8 v0, v0, 0x1

    goto :goto_a

    :cond_23
    const/4 v6, 0x0

    goto :goto_17
.end method
