
local validacao = {}

function validacao.verificar_gradiente_numerico(f, x, h)

    local fx = f(x)
    local fx_plus = f(x + h)
    local fx_minus = f(x - h)
    
    local derivada_numerica = (fx_plus - fx_minus) / (2*h)
    local segunda_derivada = (fx_plus - 2*fx + fx_minus) / (h*h)
    
    return {
        derivada = derivada_numerica,
        segunda_derivada = segunda_derivada,
        erro_relativo = math.abs(derivada_numerica - x.grad) / (math.abs(derivada_numerica) + 1e-10)
    }
end

function validacao.teste_porta_and(model)
    local testes = {
        {{0,0}, 0},
        {{0,1}, 0},
        {{1,0}, 0},
        {{1,1}, 1}
    }
    
    local acertos = 0
    for _, teste in ipairs(testes) do
        local inputs, esperado = teste[1], teste[2]
        local pred = model(inputs)
        local resultado = pred.data > 0.5 and 1 or 0
        
        if resultado == esperado then
            acertos = acertos + 1
        end
    end
    
    return acertos / #testes
end

function validacao.comparar_modelos()
    print("\n🔬 VALIDAÇÃO NUMÉRICA")
    print("-"..string.rep("-", 40))
    
    -- Teste derivada de x²
    local micrograd = require("micrograd")
    local x = micrograd.Value(3.0)
    local y = x * x
    y:backward()
    
    local derivada_analitica = 2 * x.data  -- 6
    local derivada_autograd = x.grad
    
    print(string.format("f(x)=x², f'(3):"))
    print(string.format("  Analítico:   %.6f", derivada_analitica))
    print(string.format("  Autograd:    %.6f", derivada_autograd))
    print(string.format("  Diferença:   %.6f", math.abs(derivada_analitica - derivada_autograd)))
    
    if math.abs(derivada_analitica - derivada_autograd) < 1e-10 then
        print("  ✓ Gradiente CORRETO")
    else
        print("  ✗ Gradiente INCORRETO")
    end
end

return validacao