import requests
from bs4 import BeautifulSoup

# Fungsi untuk mengambil data gambar, tautan, dan teks dari website
def scrape_website(url, save_to_file=False):
    try:
        # Mengirimkan permintaan HTTP GET ke URL
        response = requests.get(url)
        
        # Jika berhasil mendapatkan response (status code 200)
        if response.status_code == 200:
            # Parsing HTML menggunakan BeautifulSoup
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Menyimpan semua elemen gambar (src) dalam list
            images = soup.find_all('img')
            links = soup.find_all('a')
            paragraphs = soup.find_all('p')  # Menyimpan semua teks dalam tag <p>
            
            # Format untuk menampilkan hasil scraping
            result = ""
            result += "=====================\n"
            result += "Gambar:\n"
            for img in images:
                img_url = img.get('src')
                if img_url:
                    result += f"{img_url}\n"
            
            result += "\n=====================\n"
            result += "Tautan:\n"
            for link in links:
                href = link.get('href')
                if href:
                    result += f"{href}\n"
            
            result += "\n=====================\n"
            result += "Teks:\n"
            for para in paragraphs:
                result += f"{para.text.strip()}\n"
            
            # Jika pilihan untuk menyimpan ke file
            if save_to_file:
                output_file = 'hasil_scrape.txt'
                with open(output_file, 'w') as f:
                    f.write(result)
                print(f"Data berhasil disimpan di {output_file}")
            
            # Jika tidak menyimpan ke file, tampilkan hasil di terminal
            else:
                print(result)

        else:
            print(f"Terjadi kesalahan. Status code: {response.status_code}")
    
    except Exception as e:
        print(f"Terjadi kesalahan: {e}")

# Main function untuk meminta URL dan pilihan dari pengguna
def main():
    while True:
        # Meminta URL website dari pengguna
        url = input("Masukkan URL website yang ingin di-scrape: ")

        # Menampilkan pilihan
        print("\nPilih opsi:")
        print("1. Simpan hasil ke dalam file txt")
        print("2. Tampilkan hasil langsung di terminal")
        print("3. Keluar")
        
        # Meminta pilihan dari pengguna
        choice = input("Masukkan pilihan (1/2/3): ")
        
        if choice == '1':
            scrape_website(url, save_to_file=True)
        elif choice == '2':
            scrape_website(url, save_to_file=False)
        elif choice == '3':
            print("Keluar dari program...")
            break
        else:
            print("Pilihan tidak valid, silakan coba lagi.")

if __name__ == "__main__":
    main()