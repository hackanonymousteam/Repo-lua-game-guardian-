import random
import requests
import json

# Konfigurasi global
egg = "15"  
loc = "1"
domain = "https://windowsx95.seacreaft.my.id"
apikey = "ptla_DoWxg9bVwmRk5AAsXsBifEkBfRYdiPZwWUGEpxx2faG"
capikey = "ptlc_x6ZO7vT2FDkgctfNdHdyqxim7Jr0ZP8kLVTxjT1coCS"

# Daftar paket RAM
ram_options = {
    "1": {"ram": 1100, "disk": 1000, "cpu": 100},
    "2": {"ram": 2200, "disk": 2000, "cpu": 150},
    "3": {"ram": 3300, "disk": 3000, "cpu": 200},
    "4": {"ram": 4400, "disk": 4000, "cpu": 250},
    "5": {"ram": 5500, "disk": 5000, "cpu": 300},
    "6": {"ram": 6600, "disk": 6000, "cpu": 350},
    "7": {"ram": 7700, "disk": 7000, "cpu": 400},
    "8": {"ram": 8800, "disk": 8000, "cpu": 400},
    "9": {"ram": 9900, "disk": 9000, "cpu": 450},
    "10": {"ram": 0, "disk": 0, "cpu": 0},
}

# Fungsi untuk membuat password acak
def generate_password():
    random_chars = "abcdefghijklmnopqrstuvwxyz"
    return "cry-" + "".join(random.choice(random_chars) for _ in range(5))

# Memilih paket RAM
print("Pilih Paket RAM:")
for key, value in ram_options.items():
    print(f"{key}. {value['ram']} MB RAM")
selected = input("Masukkan pilihan RAM (1-10): ")
username = input("Masukkan username: ")

if selected not in ram_options:
    print("Pilihan RAM tidak valid!")
    exit()

# Data server
ram = ram_options[selected]["ram"]
disk = ram_options[selected]["disk"]
cpu = ram_options[selected]["cpu"]
password = generate_password()
email = f"{username}@lynzz.id"
name = f"{username} lynzz"

# Membuat user di panel
user_data = {
    "email": email,
    "username": username,
    "first_name": username,
    "last_name": username,
    "language": "en",
    "password": password,
    "capikey": capikey
}

headers = {
    "Accept": "application/json",
    "Content-Type": "application/json",
    "Authorization": f"Bearer {apikey}"
}

# Mengirim request untuk membuat user di panel
response = requests.post(f"{domain}/api/application/users", headers=headers, data=json.dumps(user_data))
user_response = response.json()

if "errors" in user_response:
    print("Error saat membuat user:", user_response["errors"])
    exit()

user_id = user_response.get("attributes", {}).get("id", "N/A")

# Mengambil startup command untuk egg
egg_response = requests.get(f"{domain}/api/application/nests/5/eggs/{egg}", headers=headers)

if egg_response.status_code != 200:
    print("Gagal mendapatkan startup command untuk egg.")
    exit()

startup_cmd = egg_response.json().get("attributes", {}).get("startup", "")

# Membuat server di panel
server_data = {
    "name": name,
    "description": "Server Panel Lynzz",
    "user": user_id,
    "egg": int(egg),
    "docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
    "startup": startup_cmd,
    "environment": {
        "INST": "npm",
        "USER_UPLOAD": "0",
        "AUTO_UPDATE": "0",
        "CMD_RUN": "npm start",
        "CAPIK": capikey
    },
    "limits": {
        "memory": ram,
        "swap": 0,
        "disk": disk,
        "io": 500,
        "cpu": cpu
    },
    "feature_limits": {"databases": 5, "backups": 5, "allocations": 1},
    "deploy": {
        "locations": [int(loc)],
        "dedicated_ip": False,
        "port_range": []
    }
}

server_response = requests.post(f"{domain}/api/application/servers", headers=headers, data=json.dumps(server_data))

server_result = server_response.json()

if "errors" in server_result:
    print("Error saat membuat server:", server_result["errors"])
    exit()

# Mendapatkan server ID
server_id = server_result.get("attributes", {}).get("id", "N/A")

# Output hasil ke konsol
print("\n=== Panel Berhasil Dibuat ===")
print(f"👤 Username: {username}")
print(f"🔐 Password: {password}")
print(f"🔗 Link Login: {domain}")
print(f"🆔 ID Panel/User: {user_id}")
print(f"🖥 ID Server: {server_id}")
print(f"💾 RAM: {ram} MB")
print(f"📂 Disk: {disk} MB")
print(f"⚙ CPU: {cpu}%")