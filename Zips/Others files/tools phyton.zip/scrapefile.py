import os

# Fungsi untuk mengecek dependencies dalam file Python
def detect_python_dependencies(content):
    dependencies = []
    for line in content.splitlines():
        line = line.strip()
        if line.startswith('import '):
            dep = line.replace('import ', '').strip()
            dependencies.append(dep)
        elif line.startswith('from '):
            dep = line.split(' ')[1].strip()
            dependencies.append(dep)
    return dependencies

# Fungsi untuk mengecek dependencies dalam file JS
def detect_npm_dependencies(content):
    dependencies = []
    for line in content.splitlines():
        line = line.strip()
        if 'require(' in line:
            start = line.find('require(') + len('require(')
            quote_start = line.find('"', start)
            quote_end = line.find('"', quote_start + 1)
            if quote_start != -1 and quote_end != -1:
                dep = line[quote_start + 1:quote_end]
                dependencies.append(dep)

        elif 'import ' in line and 'from' in line:
            parts = line.split('from')
            if len(parts) > 1:
                dep = parts[1].split('"')[1].strip()
                dependencies.append(dep)

    return dependencies

# Fungsi untuk membaca dependencies dalam file HTML, CSS, atau TXT
def detect_generic_dependencies(content):
    dependencies = []
    if '<script' in content:
        start_idx = content.find('src="') + len('src="')
        if start_idx != -1:
            end_idx = content.find('"', start_idx)
            if end_idx != -1:
                dep = content[start_idx:end_idx]
                dependencies.append(dep)
    return dependencies

# Fungsi untuk scrape file dari folder
def scrape_files(directory):
    dependencies_dict = {
        "pip": set(),
        "npm": set(),
        "pkg": set()
    }

    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(('py', 'js', 'html', 'css', 'txt')):
                filepath = os.path.join(root, file)

                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        content = f.read()

                        if file.endswith('.py'):
                            deps = detect_python_dependencies(content)
                            dependencies_dict['pip'].update(deps)

                        elif file.endswith('.js'):
                            deps = detect_npm_dependencies(content)
                            dependencies_dict['npm'].update(deps)

                        else:
                            generic = detect_generic_dependencies(content)
                            dependencies_dict['pkg'].update(generic)

                except:
                    print(f"Failed to open {filepath}")

    with open("dependencies.txt", "w") as result:
        for key, dep in dependencies_dict.items():
            result.write(f"{key} packages:\n")
            for d in dep:
                result.write(f" - {d}\n")

print("\nScraping dependencies...")
scrape_files("./")
print("\nDependencies extracted.")