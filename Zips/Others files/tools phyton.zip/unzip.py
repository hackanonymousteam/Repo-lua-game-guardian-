import os
import zipfile

# Fungsi untuk meng-extract file ZIP
def unzip_file(file_path, dest):
    try:
        with zipfile.ZipFile(file_path, 'r') as zip_ref:
            zip_ref.extractall(dest)
            print(f"[✓] File {file_path} berhasil di-extract ke {dest}")
    except FileNotFoundError:
        print("[✖️] File tidak ditemukan.")
    except zipfile.BadZipFile:
        print("[✖️] File tidak valid atau rusak.")

# Mengambil input dari pengguna
file_path = input("Masukkan path file ZIP: ")
dest_path = input("Masukkan folder tujuan untuk extract: ")

# Membuat folder tujuan jika belum ada
if not os.path.exists(dest_path):
    os.makedirs(dest_path)

# Menjalankan fungsi unzip
unzip_file(file_path, dest_path)