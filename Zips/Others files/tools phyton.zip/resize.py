from PIL import Image
import os

def resize_image(image_path, output_path, width, height):
    try:
        # Membuka gambar
        img = Image.open(image_path)
        print(f"Ukuran asli: {img.size}")
        
        # Mengubah ukuran gambar menggunakan LANCZOS
        img_resized = img.resize((width, height), Image.Resampling.LANCZOS)
        
        # Menyimpan gambar yang diubah ukurannya
        img_resized.save(output_path)
        print(f"Gambar yang diubah ukurannya disimpan di: {output_path}")
    except Exception as e:
        print(f"Terjadi kesalahan: {e}")

def main():
    print("=== Image Resizer ===")
    image_path = input("Masukkan path gambar (contoh: gambar.jpg): ")
    
    if not os.path.exists(image_path):
        print("File tidak ditemukan!")
        return
    
    width = int(input("Masukkan lebar baru (px): "))
    height = int(input("Masukkan tinggi baru (px): "))
    output_path = input("Masukkan path untuk menyimpan gambar baru (contoh: resized.jpg): ")
    
    resize_image(image_path, output_path, width, height)

if __name__ == "__main__":
    main()