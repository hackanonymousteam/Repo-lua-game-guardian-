import subprocess
import os
import getpass
import time
import sys
from colorama import Fore, Style, init
def clear_screen():
    # Membersihkan layar sesuai OS yang digunakan
    os.system('cls' if os.name == 'nt' else 'clear')
init(autoreset=True)

def loading_effect():
    print("❄ Waitt.... :", end="")
    for _ in range(5):
        time.sleep(0.9)  # Delay loading selama 0.5 detik
        print("⚡", end="")
        sys.stdout.flush()  # Memastikan output langsung muncul di terminal
    print("\n")
    
def show_main_menu():
    ascii_art = r"""
███████╗░█████╗░██╗░░██╗
╚════██║██╔══██╗╚██╗██╔╝
░░███╔═╝██║░░██║░╚███╔╝░
██╔══╝░░██║░░██║░██╔██╗░
███████╗╚█████╔╝██╔╝╚██╗
╚══════╝░╚════╝░╚═╝░░╚═╝

████████╗░█████╗░░█████╗░██╗░░░░░░██████╗
╚══██╔══╝██╔══██╗██╔══██╗██║░░░░░██╔════╝
░░░██║░░░██║░░██║██║░░██║██║░░░░░╚█████╗░
░░░██║░░░██║░░██║██║░░██║██║░░░░░░╚═══██╗
░░░██║░░░╚█████╔╝╚█████╔╝███████╗██████╔╝
░░░╚═╝░░░░╚════╝░░╚════╝░╚══════╝╚═════╝░
    """

    aascii_art = r"""
    ────────────────────────────────────────
─────────────▄▄██████████▄▄─────────────
─────────────▀▀▀───██───▀▀▀─────────────
─────▄██▄───▄▄████████████▄▄───▄██▄─────
───▄███▀──▄████▀▀▀────▀▀▀████▄──▀███▄───
──████▄─▄███▀──────────────▀███▄─▄████──
─███▀█████▀▄████▄──────▄████▄▀█████▀███─
─██▀──███▀─██████──────██████─▀███──▀██─
──▀──▄██▀──▀████▀──▄▄──▀████▀──▀██▄──▀──
─────███───────────▀▀───────────███─────
─────██████████████████████████████─────
─▄█──▀██──███───██────██───███──██▀──█▄─
─███──███─███───██────██───███▄███──███─
─▀██▄████████───██────██───████████▄██▀─
──▀███▀─▀████───██────██───████▀─▀███▀──
───▀███▄──▀███████────███████▀──▄███▀───
─────▀███────▀▀██████████▀▀▀───███▀─────
───────▀─────▄▄▄───██───▄▄▄──────▀──────
──────────── ▀▀███████████▀▀ ────────────
────────────────────────────────────────
    """
    
    # Menampilkan ASCII Art
    print(f"{Fore.RED}{ascii_art}{Style.RESET_ALL}")

    # Menampilkan menu ke pengguna
    print(f"{Fore.GREEN}Pilih Menu:{Style.RESET_ALL}")
    print(f"{Fore.RED}Welcome To Tools Menu By Zox \nTools Ini Di Buat Untuk Kebutuhan Dan Lain²{Style.RESET_ALL}")
    print(f"{Fore.RED}┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━>>")
    print(f"{Fore.RED}┣1. ♻️ Cari Jawab View Source                   | 31. 🐉 Lpanel")
    print(f"{Fore.YELLOW}┣2. 🔧 Web Scrape                              | 32. ⚡ Text Repeat")
    print(f"{Fore.GREEN}┣3. ⚡ Short Link                              | 33. ☎ UUID Generator")
    print(f"{Fore.BLUE}┣4. 🕐 Ping                                    | 34. 🔷 Url Openned")
    print(f"{Fore.BLUE}┣5. 🧊 Text To Audio                           | 35. 📗 Qr code Read")
    print(f"{Fore.BLUE}┣6. ❄ Get IP                                   | 36. 🆔 QR Code Crate")
    print(f"{Fore.RED}┣7. 🔷 Mediafire Download                      | 37. 📔 Mengambil Module Yg Perlu Di Install")
    print(f"{Fore.YELLOW}┣8. ⛳ Cek Host                                | 38. 🔷 Resize Gambar")
    print(f"{Fore.WHITE}┣9. 💻 Play Store Search                       | 39. ❄ Nampilkan File² Yg ada")
    print(f"{Fore.RED}┣10. 💿 Game Mod Search                        | 40. ⚙️ Edit File Lewat Terminal")
    print(f"{Fore.GREEN}┣11. ☎ Track IP                                | 41. 📔 Mengubah Nama File")
    print(f"{Fore.YELLOW}┣12. 🎚 Kalkulator                              | 42. 🧊 Copy File")
    print(f"{Fore.BLUE}┣13. 🛢 Kalkulator Lengkap                      | 43. 💿 Delete File")
    print(f"{Fore.RED}┣14. 📟 Kalender                               | 44. 🐉 Edit File V2")
    print(f"{Fore.GREEN}┣15. 🎛 Unzip File                              | 45. ☠️ Git Clone")
    print(f"{Fore.YELLOW}┣16. ⚙️ Enc & Dec BS                            | 46. 🐉 Image To Text")
    print(f"{Fore.BLUE}┣17. ♻️ Ytmp3                                   | 47. 👤 Web Scraps V2")
    print(f"{Fore.RED}┣18. ⚙️ Ytmp4                                   | 48. 🧊 Ubah Sound Effect")
    print(f"{Fore.GREEN}┣19. ❄ Test Jaringan (Speed)                   | 49. 🐉 Fake Enc")
    print(f"{Fore.YELLOW}┣20. 📔 Zip Cek                                | 50. 📁 Mourse Code")
    print(f"{Fore.BLUE}┣21. 🔷 Game Menu                              | 51. 🔷 AI")
    print(f"{Fore.RED}┣22. ⚙️ Money Convert                           | 52. 🐉 Pin")
    print(f"{Fore.YELLOW}┣23. 🕐 Hero ML Scrape                         | 53. 🐉Black Box")
    print(f"{Fore.GREEN}┣24. ⚙️ Enc Menu                                | 54. Haka")
    print(f"{Fore.RED}┣25. ❄ TT Download                             | 55. Haka")
    print(f"{Fore.GREEN}┣26. ☠️ Pin Video Download                     | 56. Haka")
    print(f"{Fore.RED}┣27. 🐲 Word Counter                           | 57. Haka")
    print(f"{Fore.GREEN}┣28. ❄ URL Encoded                             | 58. Haka")
    print(f"{Fore.RED}┣29. 🐉 Cpanel                                 | 59. Haka")
    print(f"{Fore.GREEN}┣30. Dpanel                                    | 60. Haka")

    print(f"{Fore.YELLOW}┣00. 🗑️ Clear Layar")
    print(f"{Fore.BLUE}┣0. 🚫 Keluar")
    print(f"{Fore.BLUE}┣999. 🧊 Tools V2")
    print(f"{Fore.BLUE}┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━>>")
    print(f"{Fore.GREEN}{aascii_art}{Style.RESET_ALL}")

def pause_before_menu():
    input(f"{Fore.YELLOW}Tekan Enter untuk kembali ke menu utama...{Style.RESET_ALL}")

def main():
    key = getpass.getpass(prompt=f"""{Fore.RED}────────────────────────────────────────
─────────────▄▄██████████▄▄─────────────
─────────────▀▀▀───██───▀▀▀─────────────
─────▄██▄───▄▄████████████▄▄───▄██▄─────
───▄███▀──▄████▀▀▀────▀▀▀████▄──▀███▄───
──████▄─▄███▀──────────────▀███▄─▄████──
─███▀█████▀▄████▄──────▄████▄▀█████▀███─
─██▀──███▀─██████──────██████─▀███──▀██─
──▀──▄██▀──▀████▀──▄▄──▀████▀──▀██▄──▀──
─────███───────────▀▀───────────███─────
─────██████████████████████████████─────
─▄█──▀██──███───██────██───███──██▀──█▄─
─███──███─███───██────██───███▄███──███─
─▀██▄████████───██────██───████████▄██▀─
──▀███▀─▀████───██────██───████▀─▀███▀──
───▀███▄──▀███████────███████▀──▄███▀───
─────▀███────▀▀██████████▀▀▀───███▀─────
───────▀─────▄▄▄───██───▄▄▄──────▀──────
──────────── ▀▀███████████▀▀ ────────────
────────────────────────────────────────
⚡ Welcome To Zox Tools☠️
📗 Owner : Zox ⚡
⚙️ Premium : Yes 🔷
🕘 Create At : 17-Maret-2024 🆔
🆔 ID : 2033 🐉
🧊 Type : Python ❄
🎛 Editor : MT Meneger ☎
📲 Feature Total : 37 🔷
📗 Type : Random JS & PY 🔐
🔐 Use Key : Yes 📗
🔷 Versi : 5📁
❄ Enter Key To Unlock Menu / Tools⚙️: {Style.RESET_ALL}""")
    print("\n⚡ Verifying Key, please wait...")
    loading_effect()  # Menampilkan efek loading

    if key == "10":  # Ganti dengan kunci yang diinginkan
        show_main_menu()
    else:
        print("⚡ Invalid Key ❌")
        exit()  # Keluar dari program

if __name__ == "__main__":
    main()


def main():
    while True:
        clear_screen()  # Membersihkan layar setiap kali menu muncul
        show_main_menu()

        choice = input(f"{Fore.CYAN}Pilih nomor menu: {Style.RESET_ALL}")

        if choice == "1":
            print(f"{Fore.CYAN}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "jawaban.py"])
            pause_before_menu()

        elif choice == "2":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "web scrape.py"])
            pause_before_menu()

        elif choice == "3":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "short link.py"])
            pause_before_menu()

        elif choice == "4":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "ping.py"])
            pause_before_menu()

        elif choice == "5":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "txt audio.py"])
            pause_before_menu()

        elif choice == "6":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "get ip.py"])
            pause_before_menu()

        elif choice == "7":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "media.py"])
            pause_before_menu()

        elif choice == "8":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "cekhost.py"])
            pause_before_menu()

        elif choice == "9":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "playstore.py"])
            pause_before_menu()
        
        elif choice == "10":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "mod.py"])
            pause_before_menu()
                 
        elif choice == "11":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "track.py"])
            pause_before_menu()
                  
        elif choice == "12":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "kalku.py"])
            pause_before_menu()
                 
        elif choice == "13":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "kalku2.py"])
            pause_before_menu()
                 
        elif choice == "14":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "date.py"])
            pause_before_menu()
                 
        elif choice == "15":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "unzip.py"])
            pause_before_menu()
                 
        elif choice == "16":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "base.py"])
            pause_before_menu()
                 
        elif choice == "17":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "ytmp3.py"])
            pause_before_menu()
                 
        elif choice == "18":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "ytmp4.py"])
            pause_before_menu()
                 
        elif choice == "19":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "speed.py"])
            pause_before_menu()
                 
        elif choice == "20":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "zip.py"])
            pause_before_menu()
                 
        elif choice == "21":
            print(f"{Fore.BLUE}Loadin.g...{Style.RESET_ALL}")
            subprocess.run(["python3", "game.py"])
            pause_before_menu()
                 
        elif choice == "22":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "money.py"])
            pause_before_menu()
                 
        elif choice == "23":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "mlbb.py"])
            pause_before_menu()
                 
        elif choice == "24":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["node", "enc.js"])
            pause_before_menu()
                          
        elif choice == "25":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "tiktok.py"])
            pause_before_menu()
                 
        elif choice == "26":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "pin.py"])
            pause_before_menu()
                           
        elif choice == "27":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "Word.py"])
            pause_before_menu()
                 
        elif choice == "28":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "url.py"])
            pause_before_menu()
                          
        elif choice == "29":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "cpanel.py"])
            pause_before_menu()
                 
        elif choice == "30":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "ddpanel.py"])
            pause_before_menu()
                          
        elif choice == "31":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "lpanel.py"])
            pause_before_menu()
                 
        elif choice == "32":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "repe.py"])
            pause_before_menu()
                          
        elif choice == "33":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "san.py"])
            pause_before_menu()
                 
        elif choice == "34":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["node", "urlopen.js"])
            pause_before_menu()
                                   
        elif choice == "35":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "qrre.py"])
            pause_before_menu()
                 
        elif choice == "36":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "qrc.py"])
            pause_before_menu()
                                    
        elif choice == "37":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "scrapefile.py"])
            pause_before_menu()
                 
        elif choice == "38":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "resize.py"])
            pause_before_menu()
                                   
        elif choice == "39":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "ls.py"])
            pause_before_menu()
                 
        elif choice == "40":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "edit.py"])
            pause_before_menu()
                                   
        elif choice == "41":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "rename.py"])
            pause_before_menu()
                 
        elif choice == "42":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "sal.py"])
            pause_before_menu()
                                   
        elif choice == "43":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "del.py"])
            pause_before_menu()
                 
        elif choice == "44":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "editv2.py"])
            pause_before_menu()
                                   
        elif choice == "45":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "gitcl.py"])
            pause_before_menu()
                 
        elif choice == "46":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "image.py"])
            pause_before_menu()
                                   
        elif choice == "47":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "mwebsscrape.py"])
            pause_before_menu()
                 
        elif choice == "48":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "effek.py"])
            pause_before_menu()
                             
        elif choice == "49":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "ecenc.py"])
            pause_before_menu()
                              
        elif choice == "50":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "code.py"])
            pause_before_menu()
                             
        elif choice == "51":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "ai.py"])
            pause_before_menu()
                             
        elif choice == "52":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "painters.py"])
            pause_before_menu()
                             
        elif choice == "53":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "ai2.py"])
            pause_before_menu()
                             
        elif choice == "10":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "mod.py"])
            pause_before_menu()
                             
        elif choice == "10":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "mod.py"])
            pause_before_menu()
                             
        elif choice == "10":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "mod.py"])
            pause_before_menu()
                             
        elif choice == "10":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "mod.py"])
            pause_before_menu()
                             
        elif choice == "10":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "mod.py"])
            pause_before_menu()
                             
        elif choice == "10":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "mod.py"])
            pause_before_menu()
                             
        elif choice == "10":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
            subprocess.run(["python3", "mod.py"])
            pause_before_menu()
            
            
        elif choice == "999":
            print(f"{Fore.BLUE}Loading...{Style.RESET_ALL}")
    # Path lengkap ke file mod.py
            mod_path = "/storage/emulated/0/toolsv2/alatv2.py"
            subprocess.run(["python3", mod_path])
            pause_before_menu()
         

        elif choice == "00":
            clear_screen()
            pause_before_menu()

        elif choice == "0":
            print(f"{Fore.RED}Sampai Jumpa!{Style.RESET_ALL}")
            break

        else:
            print("[ERROR] Menu tidak ditemukan, silakan coba lagi")
            pause_before_menu()

# Memulai aplikasi utama
main()