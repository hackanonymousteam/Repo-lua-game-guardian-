const chalk = require('chalk');
const https = require('https');
const os = require('os');

const validUsername = "satu";
const validPassword = "satu";

let loginAttempts = 0;

// Daftar IP yang diperbolehkan
const allowedIPs = [
  "103.177.106.11",
  "103.177.106.6",
  "103.177.106.9"
];

let deviceInfo = {
  buildVersion: "PD2226KF_EX_A_14.2.12.0.W20",
  cpuModel: "Termux environment",
  memory: `${(os.totalmem() / 1e+9).toFixed(2)} GB`
};

const getPublicIP = async () => {
  return new Promise((resolve) => {
    const sources = [
      'https://ipinfo.io/json',
      'https://www.whatismyipaddress.com/'
    ];

    let attempts = 0;

    const getIPFromSource = (url) => {
      https.get(url, (res) => {
        let data = '';
        
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          const ipMatch = data.match(/(\d+\.\d+\.\d+\.\d+)/);
          const ip = ipMatch ? ipMatch[0] : null;

          if (allowedIPs.includes(ip)) {
            return resolve(ip);
          } else {
            attempts++;
            if (attempts < sources.length) {
              getIPFromSource(sources[attempts]);
            } else {
              resolve(null);
            }
          }
        });
      }).on('error', () => {
        attempts++;
        if (attempts < sources.length) {
          getIPFromSource(sources[attempts]);
        } else {
          resolve(null);
        }
      });
    };

    getIPFromSource(sources[attempts]);
  });
};

const promptInput = async (question) => {
  return new Promise((resolve) => {
    process.stdout.write(question);
    process.stdin.once('data', (data) => resolve(data.toString().trim()));
  });
};

const displayDeviceInfo = () => {
  console.log(chalk.green(`Versi Build HP: ${deviceInfo.buildVersion}`));
  console.log(chalk.cyan(`CPU Model: ${deviceInfo.cpuModel}`));
  console.log(chalk.magenta(`Memori Terpakai: ${deviceInfo.memory}`));
};

const keamananLinkValidasi = async () => {
  const aksesLink = await promptInput('Masukkan URL link valid: ');
  
  if (aksesLink === "https://google.com") {
    console.log(chalk.green('URL valid terdeteksi'));
    return true;
  } else {
    console.log(chalk.red('URL tidak valid! Akses ditolak.'));
    return false;
  }
};

const loginPrompt = async () => {
  const username = await promptInput('Username: ');
  const password = await promptInput('Password: ');

  if (username === validUsername && password === validPassword) {
    const ip = await getPublicIP();

    if (ip) {
      console.log(chalk.green(`IP Valid: ${ip}`));

      await keamananLinkValidasi();

      displayDeviceInfo();
      return true;
    }
  }

  loginAttempts++;
  console.log(chalk.red(`Login failed (${loginAttempts}x)`));

  if (loginAttempts >= 3) {
    console.log(chalk.bgRed('Suspensi! Hubungi Telegram.'));
    return false;
  }

  return await loginPrompt();
};

const mainMenu = async () => {
  const isLoggedIn = await loginPrompt();

  if (!isLoggedIn) return;

  console.log(chalk.yellow('Menu Sistem Terbuka'));
  console.log('Klik untuk keluar dari Aplikasi...');
};

mainMenu();