from pyzbar.pyzbar import decode
from PIL import Image

# Fungsi untuk membaca QR Code dari file gambar
def read_qr_code(filename):
    try:
        img = Image.open(filename)  # Membuka file gambar
        decoded_objects = decode(img)  # Membaca QR Code dalam gambar

        if decoded_objects:
            for obj in decoded_objects:
                data = obj.data.decode('utf-8')
                print(f"QR Code berhasil dibaca dari {filename}: {data}")
        else:
            print(f"Tidak ditemukan QR Code di {filename}")

    except FileNotFoundError:
        print(f"Gambar {filename} tidak ditemukan!")

# Meminta input dari pengguna
filename = input("Masukkan nama file gambar (misalnya code.png atau code.jpg): ")
read_qr_code(filename)