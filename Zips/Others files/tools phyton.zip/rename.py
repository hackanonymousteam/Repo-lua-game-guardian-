import os

def rename_file(old_name, new_name):
    """
    Fungsi untuk mengganti nama file di direktori saat ini.
    
    Parameters:
    - old_name (str): Nama file lama yang ingin diganti.
    - new_name (str): Nama baru untuk file.
    """
    # Cek apakah file lama ada di direktori saat ini
    if os.path.isfile(old_name):
        try:
            os.rename(old_name, new_name)
            print(f"File berhasil diganti dari {old_name} menjadi {new_name}")
        except Exception as e:
            print(f"Terjadi kesalahan: {e}")
    else:
        print(f"File {old_name} tidak ditemukan di direktori saat ini.")

def main():
    print("Selamat datang di File Renamer Tool!\n")
    
    # Input nama file lama dan nama baru
    old_name = input("Masukkan nama file yang ingin diubah: ").strip()
    new_name = input("Masukkan nama baru untuk file: ").strip()
    
    # Memanggil fungsi rename_file
    rename_file(old_name, new_name)

if __name__ == "__main__":
    main()