import requests
from bs4 import BeautifulSoup

def extract_questions_answers(url, output_file):
    try:
        response = requests.get(url)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")
        questions = soup.find_all("p")
        hidden_inputs = soup.find_all("input", {"type": "hidden", "name": lambda x: x and "kunci" in x})

        with open(output_file, "w", encoding="utf-8") as txt_file:
            for i, (question, hidden_input) in enumerate(zip(questions, hidden_inputs), start=1):
                text = question.text.strip()
                answer = hidden_input.get("value")
                txt_file.write(f"Soal Nomor {i}: {text}\n")
                txt_file.write(f"Jawaban: {answer}\n\n")

        print(f"Jawaban dan soal telah disimpan di {output_file}")
    except requests.RequestException as e:
        print(f"Gagal mengambil data dari link: {e}")

# Bagian utama yang dipanggil saat script dijalankan
if __name__ == "__main__":
    url = input("Masukkan URL sumber soal: ")
    output_file = input("Masukkan nama file untuk menyimpan soal: ")
    extract_questions_answers(url, output_file)