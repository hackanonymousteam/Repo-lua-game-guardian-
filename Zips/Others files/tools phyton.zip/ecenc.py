import base64

def encode_to_base64(text):
    return base64.b64encode(text.encode()).decode()

def encode_to_base32(text):
    return base64.b32encode(text.encode()).decode()

def encode_to_binary(text):
    return ' '.join(format(ord(char), '08b') for char in text)

def encode_to_hex(text):
    return text.encode().hex()

def unescape_text(text):
    return bytes(text, "utf-8").decode("unicode_escape")

def main():
    print("Pilihan Encoding:")
    print("1. Base64")
    print("2. Base32")
    print("3. Binary")
    print("4. Hex")
    print("5. Unescape")
    print("6. Keluar")

    try:
        # Meminta input file teks
        input_file = input("Masukkan nama file input (contoh: file.txt): ")
        with open(input_file, 'r') as file:
            text = file.read().strip()

        # Memilih metode encoding
        choice = input("Pilih metode encoding (1-5): ")
        output_file = input("Masukkan nama file output (contoh: hasil.txt): ")

        if choice == "1":
            encoded_text = encode_to_base64(text)
        elif choice == "2":
            encoded_text = encode_to_base32(text)
        elif choice == "3":
            encoded_text = encode_to_binary(text)
        elif choice == "4":
            encoded_text = encode_to_hex(text)
        elif choice == "5":
            encoded_text = unescape_text(text)
        elif choice == "6":
            print("Keluar...")
            return
        else:
            print("Pilihan tidak valid.")
            return

        # Menyimpan hasil encoding ke file output
        with open(output_file, 'w') as file:
            file.write(encoded_text)
        print(f"Hasil encoding berhasil disimpan di {output_file}")

    except FileNotFoundError:
        print("File tidak ditemukan. Pastikan nama file benar.")
    except Exception as e:
        print(f"Terjadi kesalahan: {e}")

if __name__ == "__main__":
    main()