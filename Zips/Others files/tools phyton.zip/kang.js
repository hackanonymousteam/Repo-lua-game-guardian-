const readline = require('readline');
const os = require('os');

// Daftar IP yang diperbolehkan
const allowedIPs = [
  "103.177.106.11",
  "103.177.106.6",
  "103.177.106.9"
];

const validLink = "http://kang.com";

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const correctUsername1 = "1";
const correctUsername2 = "2";
const correctKey1 = "3";
const correctKey2 = "4";

function getCurrentIP() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return null;
}

function verifyUser() {
  rl.question('Masukkan Username ke-1: ', (username1) => {
    rl.question('Masukkan Username ke-2: ', (username2) => {
      rl.question('Masukkan Key ke-1: ', (key1) => {
        rl.question('Masukkan Key ke-2: ', (key2) => {
          const ip = getCurrentIP();

          console.log(`IP saat ini: ${ip}`);

          if (allowedIPs.includes(ip)) {
            if (username1 === correctUsername1 && username2 === correctUsername2 &&
                key1 === correctKey1 && key2 === correctKey2) {
              
              rl.question(`Masukkan Link Valid (${validLink}): `, (link) => {
                if (link === validLink) {
                  console.log('Keamanan terverifikasi. Menu dapat dibuka.');
                  showMenu();
                } else {
                  console.log('Link tidak valid.');
                  rl.close();
                }
              });

            } else {
              console.log('Username dan Key tidak cocok.');
              rl.close();
            }
          } else {
            console.log('IP tidak sesuai daftar yang diperbolehkan.');
            rl.close();
          }
        });
      });
    });
  });
}

function showMenu() {
  console.log("Menu aktif. Sistem akses penuh.");
  rl.close();
}

verifyUser();