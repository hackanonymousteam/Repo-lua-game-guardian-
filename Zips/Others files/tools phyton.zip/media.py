import os
import requests
from bs4 import BeautifulSoup

def download_mediafire_file(url, output_folder="downloads"):
    try:
        # Mengatur User-Agent untuk meniru browser
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36"
        }

        # Mengirim permintaan GET ke URL MediaFire
        response = requests.get(url, headers=headers)
        response.raise_for_status()

        # Mengurai HTML untuk menemukan tautan unduhan langsung
        soup = BeautifulSoup(response.text, "html.parser")
        download_link = soup.find("a", {"id": "downloadButton"})

        if not download_link:
            print("Gagal menemukan tautan unduhan. Pastikan URL benar.")
            return

        file_url = download_link["href"]
        file_name = file_url.split("/")[-1]

        # Membuat folder jika belum ada
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

        # Mengunduh file ke folder
        print(f"Mengunduh file: {file_name}")
        file_response = requests.get(file_url, headers=headers, stream=True)
        file_response.raise_for_status()

        file_path = os.path.join(output_folder, file_name)

        with open(file_path, "wb") as file:
            for chunk in file_response.iter_content(chunk_size=1024):
                if chunk:
                    file.write(chunk)

        print(f"File berhasil diunduh ke: {file_path}")

    except requests.RequestException as e:
        print(f"Terjadi kesalahan saat mengunduh file: {e}")

# Bagian untuk mengeksekusi skrip langsung
if __name__ == "__main__":
    url = input("Masukkan URL MediaFire: ")
    download_mediafire_file(url)
    input("\nTekan Enter untuk keluar...")