import requests
from bs4 import BeautifulSoup

def search_sfile(query):
    """Cari file di Sfile.mobi berdasarkan keyword."""
    print(f"\nMencari file untuk kata kunci: {query}")
    base_url = f"https://sfile.mobi/search.php?q={query}"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }
    
    response = requests.get(base_url, headers=headers)
    if response.status_code != 200:
        print("Gagal mengakses Sfile.mobi. Pastikan Anda terhubung ke internet.")
        return None

    soup = BeautifulSoup(response.text, "html.parser")
    results = []

    # Cari file dengan ikon zip, 7z, atau rar
    for item in soup.find_all("div", class_="list"):
        icon = item.find("img", src=lambda x: x and ("zip.svg" in x or "7z.svg" in x or "rar.svg" in x))
        if icon:
            link = item.find("a")
            if link:
                file_name = link.text
                file_url = f"https://sfile.mobi{link['href']}"
                results.append({"name": file_name, "url": file_url})
    
    return results


def get_download_link(file_url):
    """Ambil link download langsung dari halaman view-source."""
    print(f"Mengambil link download untuk: {file_url}")
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }
    
    response = requests.get(file_url, headers=headers)
    if response.status_code != 200:
        print(f"Gagal mengakses halaman file: {file_url}")
        return None

    soup = BeautifulSoup(response.text, "html.parser")
    download_button = soup.find("a", {"id": "download"})
    
    if download_button and download_button.get("href"):
        return download_button["href"]
    else:
        print("Link download tidak ditemukan.")
        return None


def save_to_file(results, filename):
    """Simpan hasil scraping ke file txt."""
    try:
        with open(filename, "w", encoding="utf-8") as f:
            for i, result in enumerate(results, 1):
                f.write(f"{i}. {result['name']}\n   Link File: {result['url']}\n   Link Download: {result.get('download_link', 'Tidak ditemukan')}\n\n")
        print(f"Hasil berhasil disimpan ke file: {filename}")
    except Exception as e:
        print(f"Terjadi kesalahan saat menyimpan file: {e}")


def main():
    while True:
        print("\n=== Sfile Mobi Scraper ===")
        print("1. Cari file berdasarkan keyword")
        print("2. Keluar")
        choice = input("Pilih menu (1/2): ")

        if choice == "1":
            query = input("Masukkan kata kunci pencarian: ")
            results = search_sfile(query)

            if results:
                print("\nFile ditemukan:")
                for i, result in enumerate(results, 1):
                    print(f"{i}. {result['name']} ({result['url']})")
                
                # Ambil link download untuk setiap file
                for result in results:
                    result['download_link'] = get_download_link(result['url'])

                print("\n1. Simpan hasil ke file txt")
                print("2. Tampilkan langsung di console")
                action = input("Pilih opsi (1/2): ")

                if action == "1":
                    filename = input("Masukkan nama file (contoh: hasil.txt): ")
                    save_to_file(results, filename)
                elif action == "2":
                    for i, result in enumerate(results, 1):
                        print(f"{i}. {result['name']}\n   Link File: {result['url']}\n   Link Download: {result.get('download_link', 'Tidak ditemukan')}\n")
                else:
                    print("Pilihan tidak valid!")
            else:
                print("Tidak ada hasil yang ditemukan.")
        elif choice == "2":
            print("Keluar dari program.")
            break
        else:
            print("Pilihan tidak valid!")


if __name__ == "__main__":
    main()