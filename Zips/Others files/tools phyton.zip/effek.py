from pydub import AudioSegment
from pydub.playback import play

def apply_audio_effect(input_file, effect, output_file):
    try:
        # Memuat file audio
        audio = AudioSegment.from_file(input_file)
        
        # Efek pengubah suara
        if effect == "bass":
            audio = audio.low_pass_filter(80).apply_gain(10)
        elif effect == "blown":
            audio = audio.apply_gain(15).distort(0.8)
        elif effect == "deep":
            audio = audio.low_pass_filter(300).apply_gain(-5)
        elif effect == "earrape":
            audio = audio.apply_gain(20)
        elif effect == "fast":
            audio = audio.speedup(playback_speed=1.5)
        elif effect == "fat":
            audio = audio.set_frame_rate(8000)
        elif effect == "nightcore":
            audio = audio.speedup(playback_speed=2.0).set_frame_rate(48000)
        elif effect == "reverse":
            audio = audio.reverse()
        elif effect == "robot":
            audio = audio.overlay(audio.low_pass_filter(300))
        elif effect == "slow":
            audio = audio.speedup(playback_speed=0.5)
        elif effect == "smooth":
            audio = audio.high_pass_filter(200).apply_gain(3)
        elif effect == "tupai":
            audio = audio.speedup(playback_speed=1.5).set_frame_rate(60000)
        else:
            print("Efek tidak dikenal.")
            return
        
        # Menyimpan file output
        audio.export(output_file, format="mp3")
        print(f"Audio dengan efek '{effect}' berhasil disimpan sebagai {output_file}")
    except Exception as e:
        print(f"Terjadi kesalahan: {e}")

def main():
    print("Daftar Efek Suara:\n.bass\n.blown\n.deep\n.earrape\n.fast\n.fat\n.nightcore\n.reverse\n.robot\n.slow\n.smooth\n.tupai")
    input_file = input("Masukkan nama file audio (contoh: audio.mp3): ")
    effect = input("Pilih efek suara (contoh: bass): ")
    output_file = input("Masukkan nama file output (contoh: hasil.mp3): ")
    
    apply_audio_effect(input_file, effect, output_file)

if __name__ == "__main__":
    main()

