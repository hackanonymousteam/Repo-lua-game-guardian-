const axios = require('axios');
const fs = require('fs');
const qs = require('qs');

// Meminta nama file input dan output
const readline = require('readline').createInterface({
    input: process.stdin,
    output: process.stdout
});

readline.question('Masukkan nama file Python (misal: tes.py): ', (inputFile) => {
    if (!fs.existsSync(inputFile)) {
        console.log('File tidak ditemukan!');
        readline.close();
        return;
    }

    readline.question('Masukkan nama file hasil enkripsi (misal: hasil.py): ', (outputFile) => {
        let code = fs.readFileSync(inputFile, 'utf8');

        let data = qs.stringify({ 'text': code });

        let config = {
            method: 'POST',
            url: 'https://pyobfuscate.com/rename-obf',
            headers: {
                'User-Agent': 'Mozilla/5.0',
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            data: data
        };

        axios.request(config)
            .then(response => {
                let encCode = response.data.match(/<textarea id="codeInput2"[^>]*>([\s\S]*?)<\/textarea>/);
                if (encCode) {
                    let hasil = encCode[1]
                        .replace(/&#39;/g, "'")  // Ubah &#39; jadi '
                        .replace(/&#34;/g, '"') // Ubah &#34; jadi "
                        .replace(/&gt;/g, '>')  // Ubah &gt; jadi >
                        .replace(/&lt;/g, '<'); // Ubah &lt; jadi <
                    
                    fs.writeFileSync(outputFile, hasil, 'utf8');
                    console.log(`Hasil enkripsi disimpan di ${outputFile}`);
                } else {
                    console.log('Gagal mendapatkan hasil enkripsi.');
                }
            })
            .catch(error => console.log('Error:', error))
            .finally(() => readline.close());
    });
});