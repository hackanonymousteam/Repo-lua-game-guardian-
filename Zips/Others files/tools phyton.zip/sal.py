import shutil

# Fungsi untuk menyalin file
def copy_file():
    # Memasukkan nama file yang ingin dicopy
    source_file = input("Masukkan nama file yang ingin dicopy (misalnya kaka.py): ")
    
    # Memasukkan nama file hasil copy
    destination_file = input("Masukkan nama file hasil copy (misalnya pepe.py): ")
    
    try:
        # Menyalin file
        shutil.copy(source_file, destination_file)
        print(f"File {source_file} berhasil dicopy menjadi {destination_file}.")
    except FileNotFoundError:
        print(f"File {source_file} tidak ditemukan.")
    except Exception as e:
        print(f"Terjadi kesalahan: {e}")

# Program utama
def main():
    print("Selamat datang di tools kita!")
    while True:
        # Tampilkan menu atau pilihan
        print("\nPilih aksi:")
        print("1. Salin File")
        print("2. Keluar")

        choice = input("\nMasukkan pilihan (1/2): ")

        if choice == "1":
            # Panggil fungsi untuk menyalin file
            copy_file()
        elif choice == "2":
            print("Keluar dari program...")
            break
        else:
            print("Pilihan tidak valid, coba lagi.")

# Menjalankan program utama
if __name__ == "__main__":
    main()