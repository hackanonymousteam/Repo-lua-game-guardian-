import requests

def lookup_ip(ip):
    url = f"https://ipwho.is/{ip}"

    try:
        response = requests.get(url)

        if response.status_code == 200:
            data = response.json()

            if data.get('success'):
                print(f"\n🧊 INI HASIL TRACK IP NYA : {data.get('ip', 'N/A')}")
                print(f"{'-'*30}")
                print(f"{'Success:':<15} {data.get('success', 'N/A')}")
                print(f"{'Type:':<15} {data.get('type', 'N/A')}")
                print(f"{'Continent:':<15} {data.get('continent', 'N/A')}")
                print(f"{'Continent Code:':<15} {data.get('continent_code', 'N/A')}")
                print(f"{'Negara:':<15} {data.get('country', 'N/A')}")
                print(f"{'Kode Negara:':<15} {data.get('country_code', 'N/A')}")
                print(f"{'Region:':<15} {data.get('region', 'N/A')}")
                print(f"{'Region Code:':<15} {data.get('region_code', 'N/A')}")
                print(f"{'Kota:':<15} {data.get('city', 'N/A')}")
                print(f"{'Latitude:':<15} {data.get('latitude', 'N/A')}")
                print(f"{'Longitude:':<15} {data.get('longitude', 'N/A')}")
                print(f"{'Is EU:':<15} {'Yes' if data.get('is_eu') else 'No'}")
                print(f"{'Postal:':<15} {data.get('postal', 'N/A')}")
                print(f"{'Calling Code:':<15} {data.get('calling_code', 'N/A')}")
                print(f"{'Capital:':<15} {data.get('capital', 'N/A')}")
                print(f"{'Borders:':<15} {data.get('borders', 'N/A')}")
                print(f"{'ASN:':<15} {data.get('connection', {}).get('asn', 'N/A')}")
                print(f"{'Organisasi:':<15} {data.get('connection', {}).get('org', 'N/A')}")
                print(f"{'Isp:':<15} {data.get('connection', {}).get('isp', 'N/A')}")
                print(f"{'Domain:':<15} {data.get('connection', {}).get('domain', 'N/A')}")
                print(f"{'Timezone ID:':<15} {data.get('timezone', {}).get('id', 'N/A')}")
                print(f"{'Timezone Abbr:':<15} {data.get('timezone', {}).get('abbr', 'N/A')}")
                print(f"{'IS DST:':<15} {'Yes' if data.get('timezone', {}).get('is_dst') else 'No'}")
                print(f"{'Offset:':<15} {data.get('timezone', {}).get('offset', 'N/A')}")
                print(f"{'UTC:':<15} {data.get('timezone', {}).get('utc', 'N/A')}")
                print(f"{'Current Time:':<15} {data.get('timezone', {}).get('current_time', 'N/A')}")

                # Menghasilkan tautan Google Maps berdasarkan latitude dan longitude
                latitude = data.get('latitude', 'N/A')
                longitude = data.get('longitude', 'N/A')

                if latitude != 'N/A' and longitude != 'N/A':
                    print(f"{'Google Maps:':<15} https://www.google.com/maps?q={latitude},{longitude}")

            else:
                print("[ERROR] Tidak dapat melacak IP.")

        else:
            print(f"[ERROR] Mengakses ipwho.is gagal, status code: {response.status_code}")

    except requests.RequestException as err:
        print(f"[ERROR] Kesalahan saat lookup IP: {str(err)}")


if __name__ == "__main__":
    ip_address = input("Masukkan IP yang ingin Anda lacak: ")
    lookup_ip(ip_address)