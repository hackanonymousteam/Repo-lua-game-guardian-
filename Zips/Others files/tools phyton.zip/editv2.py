import os

def edit_file():
    # Masukkan nama file yang ingin diedit
    file_name = input("Masukkan nama file yang ingin diedit (misalnya halo.py): ")

    # Cek apakah file ada
    if not os.path.exists(file_name):
        print(f"File {file_name} tidak ditemukan.")
        return

    with open(file_name, 'r') as file:
        lines = file.readlines()

    print("\nIsi file:")
    for i, line in enumerate(lines, start=1):
        print(f"{i}. {line.rstrip()}")  # Menghapus newline di akhir baris agar lebih rapi

    while True:
        try:
            # Pilih nomor baris yang ingin diubah
            line_number = input("\nMasukkan nomor baris yang ingin diubah (atau ketik 'selesai' untuk keluar): ")

            if line_number.lower() == 'selesai':  # Cek jika input 'selesai'
                break  # Keluar dari loop

            # Mengonversi input menjadi integer
            line_number = int(line_number)

            # Pastikan baris nomor tersebut ada
            if line_number < 1 or line_number > len(lines):
                print("Nomor baris tidak valid.")
                continue

            print(f"\nBaris yang akan diubah: {lines[line_number - 1].rstrip()}")

            # Simpan indentasi asli baris
            original_indent = len(lines[line_number - 1]) - len(lines[line_number - 1].lstrip())

            new_content = input("Masukkan konten baru untuk baris ini (tekan Enter untuk tetap): ")

            # Mengatur indentasi yang sama seperti aslinya
            if new_content:
                new_content = ' ' * original_indent + new_content  # Menambahkan indentasi yang sama
                lines[line_number - 1] = new_content + '\n'
            else:
                print("Konten tetap sama.")

            # Tampilkan isi file setelah perubahan
            print("\nIsi file setelah perubahan:")
            for i, line in enumerate(lines, start=1):
                print(f"{i}. {line.rstrip()}")
        
        except ValueError:
            print("Input tidak valid. Harap masukkan nomor baris atau ketik 'selesai' untuk keluar.")

    # Simpan perubahan ke file
    with open(file_name, 'w') as file:
        file.writelines(lines)

    print(f"\nPerubahan telah disimpan di {file_name}.")

# Panggil fungsi edit file
edit_file()