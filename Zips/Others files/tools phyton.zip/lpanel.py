import requests

# Konfigurasi API
domain2 = "https://windowsx95.seacreaft.my.id"
apikey2 = "ptla_DoWxg9bVwmRk5AAsXsBifEkBfRYdiPZwWUGEpxx2faG"
capikey2 = "ptlc_x6ZO7vT2FDkgctfNdHdyqxim7Jr0ZP8kLVTxjT1coCS"

# Fungsi untuk mengambil daftar server
def list_servers():
    try:
        # Mengambil daftar server dari endpoint API
        response = requests.get(
            f"{domain2}/api/application/servers?page=1",
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": f"Bearer {apikey2}"
            }
        )

        if response.status_code != 200:
            print(f"Gagal mendapatkan daftar server, status code: {response.status_code}")
            return

        res = response.json()
        servers = res.get('data', [])
        total_servers = res.get('meta', {}).get('pagination', {}).get('count', 0)

        if not servers:
            print("Tidak ada server yang tersedia.")
            return

        message_text = "𝐋𝐈𝐒𝐓 𝐏𝐀𝐍𝐄𝐋 & 𝐇𝐨𝐬𝐭\n\n"

        # Loop melalui daftar server untuk menampilkan informasi
        for server in servers:
            s = server.get('attributes', {})
            
            server_id = s.get('id', "N/A")
            server_name = s.get('name', "N/A")
            limits = s.get('limits', {})
            memory_limit = limits.get('memory', 0)
            cpu_limit = limits.get('cpu', 0)

            # Format memori dan CPU untuk ditampilkan
            memory_str = f"{memory_limit} GB" if memory_limit else "∞"
            cpu_str = f"{cpu_limit}%" if cpu_limit else "∞"

            message_text += f"𝗡𝗮𝗺𝗲: {server_name}\n"
            message_text += f"𝗦𝗽𝗲𝗸: Memory: {memory_str} / CPU: {cpu_str}\n"
            message_text += f"𝗜𝗗: {server_id}\n\n"

        message_text += f"Total servers: {total_servers}\n"

        # Menampilkan hasil server di console
        print(message_text)

    except requests.RequestException as e:
        print(f"Terjadi kesalahan saat mengakses API: {str(e)}")

# Menjalankan fungsi untuk mencetak daftar server
list_servers()