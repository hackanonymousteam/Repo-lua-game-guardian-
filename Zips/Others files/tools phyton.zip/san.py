import random
import string

def generate_uuid():
    # Membuat UUID acak 16 karakter (angka dan huruf)
    characters = string.ascii_letters + string.digits  # Menggabungkan huruf dan angka
    uuid = ''.join(random.choice(characters) for _ in range(16))
    return uuid

# Membuat UUID secara otomatis saat script dijalankan
print("UUID Generator Random 16 Karakter:")
print(generate_uuid())