import requests
from bs4 import BeautifulSoup

def search_game_playstore(game_name):
    base_url = "https://play.google.com/store/search?q="
    query = game_name.replace(" ", "+")
    search_url = f"{base_url}{query}"

    try:
        # Mengirim request GET ke PlayStore
        response = requests.get(search_url, headers={"User-Agent": "Mozilla/5.0"})

        if response.status_code == 200:
            soup = BeautifulSoup(response.text, "html.parser")

            # Mengambil semua elemen tautan yang sesuai
            result = soup.find_all("a", href=True)

            links = []
            for link in result:
                href = link.get('href')
                if href and href.startswith('/store/apps/details?id='):
                    full_url = "https://play.google.com" + href
                    links.append(full_url)

            if links:
                print(f"[INFO] Game {game_name} ditemukan di Play Store:")
                for idx, link in enumerate(links[:5], start=1):
                    print(f"{idx}. {link}")
            else:
                print("[ERROR] Tidak ditemukan hasil di Play Store.")

        else:
            print(f"[ERROR] Tidak dapat mengakses Play Store. Status code: {response.status_code}")

    except Exception as ex:
        print(f"[ERROR] Terjadi kesalahan: {str(ex)}")

if __name__ == "__main__":
    game_name = input("Masukkan nama game yang ingin dicari di Play Store: ")
    search_game_playstore(game_name)