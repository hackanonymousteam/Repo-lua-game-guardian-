import requests
import random
import os
from PIL import Image
from io import BytesIO

def shuffle_array(array):
    """Mengacak urutan elemen dalam array."""
    random.shuffle(array)

def fetch_pinterest_images(keyword):
    """Mengambil gambar dari Pinterest berdasarkan kata kunci."""
    url = f"https://www.pinterest.com/resource/BaseSearchResource/get/"
    params = {
        "source_url": f"/search/pins/?q={keyword}",
        "data": '{"options":{"isPrefetch":false,"query":"' + keyword + '","scope":"pins","no_fetch_context_on_resource":false},"context":{}}'
    }
    try:
        response = requests.get(url, params=params)
        if response.status_code == 200:
            data = response.json()
            images = [
                result["images"]["orig"]["url"]
                for result in data["resource_response"]["data"]["results"]
            ]
            return images
        else:
            print(f"Error: {response.status_code}")
            return []
    except Exception as e:
        print(f"Terjadi kesalahan: {e}")
        return []

def save_images(images, folder_name):
    """Menyimpan gambar yang diambil dari URL ke dalam folder tertentu."""
    os.makedirs(folder_name, exist_ok=True)  # Membuat folder berdasarkan nama pencarian
    for idx, image_url in enumerate(images):
        try:
            response = requests.get(image_url)
            if response.status_code == 200:
                img = Image.open(BytesIO(response.content))
                img.save(f"{folder_name}/image_{idx + 1}.jpg")
                print(f"Gambar ke-{idx + 1} berhasil disimpan di folder '{folder_name}'.")
            else:
                print(f"Gambar ke-{idx + 1} gagal diambil.")
        except Exception as e:
            print(f"Terjadi kesalahan saat menyimpan gambar ke-{idx + 1}: {e}")

def delete_images(folder_name):
    """Menghapus gambar-gambar dalam folder tertentu."""
    if os.path.exists(folder_name):
        for file_name in os.listdir(folder_name):
            file_path = os.path.join(folder_name, file_name)
            if os.path.isfile(file_path):
                os.remove(file_path)
                print(f"{file_name} telah dihapus.")
        print(f"Semua gambar dalam folder '{folder_name}' telah dihapus.")
    else:
        print(f"Folder '{folder_name}' tidak ditemukan.")

def show_menu():
    """Menampilkan menu utama."""
    print("\n=== Menu ===")
    print("1. Cari Gambar")
    print("2. Hapus Gambar")
    print("3. Cari Gambar Berdasarkan Jumlah")
    print("4. Keluar")
    choice = input("Pilih menu (1/2/3/4): ")
    return choice

def main():
    """Menjalankan program utama."""
    while True:
        choice = show_menu()
        
        if choice == "1":
            # Menu 1: Cari Gambar
            keyword = input("Masukkan kata kunci pencarian gambar: ")
            print("Mengambil gambar, mohon tunggu...")
            images = fetch_pinterest_images(keyword)

            if not images:
                print("Tidak ada gambar ditemukan.")
                continue

            # Acak hasil gambar
            shuffle_array(images)

            # Pilih 10 gambar pertama (atau kurang jika tidak ada 10)
            selected_images = images[:10]

            # Simpan gambar ke folder dengan nama sesuai kata kunci
            folder_name = f"pin/{keyword}"
            save_images(selected_images, folder_name)

            # Tampilkan hasil di console
            print("\nHasil pencarian:")
            for idx, image_url in enumerate(selected_images):
                print(f"{idx + 1}. {image_url}")

        elif choice == "2":
            # Menu 2: Hapus Gambar
            folder_name = input("Masukkan nama folder untuk menghapus gambar (contoh: pin/sunset): ")
            delete_images(folder_name)

        elif choice == "3":
            # Menu 3: Cari Gambar Berdasarkan Jumlah
            keyword = input("Masukkan kata kunci pencarian gambar: ")
            jumlah = input("Berapa banyak gambar yang ingin Anda ambil? (misal: 5): ")

            try:
                jumlah = int(jumlah)
                if jumlah < 1:
                    print("Jumlah harus lebih besar dari 0.")
                    continue
            except ValueError:
                print("Input jumlah tidak valid.")
                continue

            print("Mengambil gambar, mohon tunggu...")
            images = fetch_pinterest_images(keyword)

            if not images:
                print("Tidak ada gambar ditemukan.")
                continue

            # Acak hasil gambar
            shuffle_array(images)

            # Pilih gambar sesuai jumlah yang diminta
            selected_images = images[:jumlah]

            # Simpan gambar ke folder dengan nama sesuai kata kunci
            folder_name = f"pin/{keyword}"
            save_images(selected_images, folder_name)

            # Tampilkan hasil di console
            print(f"\nHasil pencarian ({jumlah} gambar):")
            for idx, image_url in enumerate(selected_images):
                print(f"{idx + 1}. {image_url}")

        elif choice == "4":
            # Menu 4: Keluar
            print("Keluar dari program...")
            break
        
        else:
            print("Pilihan tidak valid. Coba lagi.")

if __name__ == "__main__":
    main()