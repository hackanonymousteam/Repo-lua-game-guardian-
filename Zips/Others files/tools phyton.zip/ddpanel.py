import requests

# Konfigurasi API
egg = "15"
loc = "1"
domain = "https://windowsx95.seacreaft.my.id"
apikey = "ptla_DoWxg9bVwmRk5AAsXsBifEkBfRYdiPZwWUGEpxx2faG"
capikey = "ptlc_x6ZO7vT2FDkgctfNdHdyqxim7Jr0ZP8kLVTxjT1coCS"

# Menghapus panel berdasarkan ID
def delete_panel_by_id(server_id):
    try:
        response = requests.delete(
            f"{domain}/api/application/servers/{server_id}",
            headers={"Authorization": f"Bearer {apikey}"}
        )

        if response.status_code == 200:
            print(f"✅ Panel {server_id} berhasil dihapus.")
        else:
            print(f"❌ Gagal menghapus panel {server_id}. Status code: {response.status_code}")

    except requests.RequestException as e:
        print(f"⚠️ Error saat menghapus panel: {str(e)}")


# Menghapus semua panel sekaligus
def delete_all_panels():
    try:
        response = requests.get(
            f"{domain}/api/application/servers",
            headers={"Authorization": f"Bearer {apikey}"}
        )

        if response.status_code != 200:
            print("❌ Gagal mengambil daftar panel.")
            return

        panels = response.json().get('data', [])
        for panel in panels:
            panel_id = panel.get('attributes', {}).get('id')
            del_response = requests.delete(
                f"{domain}/api/application/servers/{panel_id}",
                headers={"Authorization": f"Bearer {apikey}"}
            )

            if del_response.status_code == 200:
                print(f"✅ Panel {panel_id} berhasil dihapus.")
            else:
                print(f"❌ Gagal menghapus panel {panel_id}. Status code: {del_response.status_code}")

    except requests.RequestException as e:
        print(f"⚠️ Error saat menghapus semua panel: {str(e)}")


# Menu Interaktif
def main_menu():
    try:
        print("\nMenu:")
        print("1. Hapus panel berdasarkan ID")
        print("2. Hapus semua panel")
        choice = input("Pilih opsi: ")

        if choice == "1":
            server_id = input("Masukkan ID panel yang ingin dihapus: ")
            delete_panel_by_id(server_id)
        elif choice == "2":
            delete_all_panels()
        else:
            print("Pilihan tidak valid, silakan coba lagi.")

    except KeyboardInterrupt:
        print("\nProgram dihentikan oleh pengguna.")

# Menjalankan menu utama
main_menu()