import pytesseract
from PIL import Image

# Tentukan path ke Tesseract (di Termux biasanya sudah otomatis ditemukan)
# Jika perlu, tentukan path manual
# pytesseract.pytesseract.tesseract_cmd = '/data/data/com.termux/files/usr/bin/tesseract'

def image_to_text(image_path, output_file):
    try:
        # Membuka gambar
        image = Image.open(image_path)

        # Menggunakan pytesseract untuk mengonversi gambar menjadi teks
        text = pytesseract.image_to_string(image)

        # Menyimpan hasil teks ke dalam file
        with open(output_file, 'w') as f:
            f.write(text)

        print(f"Teks berhasil diekstrak dan disimpan di {output_file}.")
    
    except Exception as e:
        print(f"Terjadi kesalahan: {e}")

if __name__ == "__main__":
    # Input nama file gambar dan nama file hasil
    image_file = input("Masukkan nama file gambar (misalnya halo.jpg): ")
    output_file = input("Masukkan nama file hasil (misalnya file.txt): ")

    # Mengekstrak teks dari gambar
    image_to_text(image_file, output_file)