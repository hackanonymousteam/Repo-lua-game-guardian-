import urllib.parse


def encode_url(text):
    """Meng-encode teks menjadi URL encoded."""
    return urllib.parse.quote(text)


def main():
    print("Pilihan:")
    print("1. Encode teks langsung")
    print("2. Encode dari file")
    choice = input("Masukkan pilihan (1/2): ").strip()

    if choice == "1":
        text = input("Masukkan teks yang ingin di-encode: ").strip()
    elif choice == "2":
        file_name = input("Masukkan nama file (contoh: input.txt): ").strip()
        try:
            with open(file_name, 'r', encoding='utf-8') as file:
                text = file.read().strip()
        except FileNotFoundError:
            print(f"File '{file_name}' tidak ditemukan.")
            return
    else:
        print("Pilihan tidak valid.")
        return

    encoded_text = encode_url(text)
    print("\nTeks URL Encoded:")
    print(encoded_text)

    # Menyimpan hasil ke file
    save_file = input("Masukkan nama file untuk menyimpan hasil (contoh: encoded.txt): ").strip()
    try:
        with open(save_file, 'w', encoding='utf-8') as file:
            file.write(encoded_text)
        print(f"Hasil URL Encoded berhasil disimpan ke '{save_file}'.")
    except Exception as e:
        print(f"Gagal menyimpan file: {e}")


if __name__ == "__main__":
    main()