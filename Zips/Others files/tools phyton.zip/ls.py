import os

# Fungsi untuk menampilkan file di direktori saat ini
def list_files_in_current_directory():
    # Mendapatkan daftar file dan folder di direktori saat ini
    files = os.listdir()
    
    print("Daftar file dan folder di direktori saat ini:")
    for file in files:
        print(file)

# Panggil fungsi
list_files_in_current_directory()