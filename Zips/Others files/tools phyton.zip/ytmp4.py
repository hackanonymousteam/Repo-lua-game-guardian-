import os
import subprocess

def download_youtube_video(url):
    try:
        print("[+] Mengunduh video dari YouTube menggunakan yt_dlp.")
        command = [
            'yt-dlp',
            '-o', '%(title)s.%(ext)s',
            url
        ]
        subprocess.run(command)

        print("[✓] Video berhasil diunduh.")

    except Exception as e:
        print(f"[!] Terjadi error: {str(e)}")


def main():
    video_url = input("Masukkan Link Video: ")
    download_youtube_video(video_url)


if __name__ == "__main__":
    main()