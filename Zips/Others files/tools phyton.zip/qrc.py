import qrcode

# Fungsi untuk membuat QR Code
def generate_qr_code(data, filename):
    qr = qrcode.make(data)
    qr.save(filename)
    print(f"QR Code berhasil dibuat dan disimpan sebagai {filename}")

# Meminta input dari pengguna
data = input("Masukkan URL atau teks untuk QR Code: ")
filename = input("Nama file QR Code (misalnya qr_code.png): ")

generate_qr_code(data, filename)