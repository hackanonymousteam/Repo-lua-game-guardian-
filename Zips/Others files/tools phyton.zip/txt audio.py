from gtts import gTTS

def text_to_audio(text, output_file):
    try:
        tts = gTTS(text, lang="id")
        tts.save(output_file)
        print(f"Audio berhasil disimpan ke {output_file}")
    except Exception as e:
        print(f"Gagal membuat audio: {e}")

    # Tunggu input sebelum kembali ke menu utama
    input("\nTekan Enter untuk kembali ke menu utama...")

def main():
    text = input("Masukkan teks yang ingin diubah menjadi audio: ")
    output_file = input("Masukkan nama file output audio (misal: output.mp3): ")
    text_to_audio(text, output_file)

if __name__ == "__main__":
    main()