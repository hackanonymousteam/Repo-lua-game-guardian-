import socket
import subprocess
import requests
from urllib.parse import urlparse

def check_host_tools():
    url = input("Masukkan link (URL): ").strip()

    # Mengambil hostname dari URL
    parsed_url = urlparse(url)
    host = parsed_url.netloc

    if not host:
        print("[ERROR] Host tidak ditemukan dalam URL.")
        return

    # Membuka file untuk menyimpan hasil
    with open("host_check_results.txt", "w", encoding="utf-8") as file:
        file.write(f"Mengecek host: {host}\n")
        file.write("-" * 40 + "\n")

        try:
            # Mengambil alamat IP host
            ip = socket.gethostbyname(host)
            file.write(f"[INFO] Host {host} memiliki IP Address: {ip}\n")

            # Menggunakan ping untuk mengecek koneksi
            try:
                output = subprocess.check_output(["ping", "-c", "4", host], stderr=subprocess.STDOUT, universal_newlines=True)
                file.write(f"[PING] Host {host} dapat dijangkau:\n{output}\n")
            except subprocess.CalledProcessError:
                file.write(f"[PING] Host {host} tidak dapat dijangkau.\n")

            # Mengecek status HTTP Response
            try:
                response = requests.get(f"http://{host}")
                status_code = response.status_code
                response_time = response.elapsed.total_seconds() * 1000  # dalam milidetik
                file.write(f"[HTTP CHECK] Host {host} mengembalikan status {status_code}\n")
                file.write(f"Waktu response: {response_time:.2f} ms\n")
            except requests.RequestException as e:
                file.write(f"[HTTP CHECK] Gagal mengakses {host}: {str(e)}\n")

            # Menggunakan socket untuk mendapatkan alamat IP tambahan
            try:
                ip = socket.gethostbyname(host)
                file.write(f"[INFO] Menggunakan socket untuk host {host}, Alamat IP: {ip}\n")
            except socket.gaierror:
                file.write("[INFO] Tidak dapat menemukan IP Address untuk host.\n")

        except socket.gaierror:
            file.write(f"[ERROR] Tidak dapat menemukan IP Address untuk {host}\n")

        file.write("-" * 40 + "\n")

    print("[INFO] Hasil telah disimpan di host_check_results.txt")

# Bagian untuk mengeksekusi skrip langsung
if __name__ == "__main__":
    check_host_tools()
    input("\nTekan Enter untuk keluar...")