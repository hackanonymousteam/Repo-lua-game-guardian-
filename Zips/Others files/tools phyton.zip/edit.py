def edit_file():
    # Meminta pengguna memasukkan nama file yang ingin diedit
    filename = input("Masukkan nama file (contoh: halo.py): ")

    try:
        # Membuka dan membaca isi file (akan menampilkan isinya sebelum mengedit)
        with open(filename, 'r') as file:
            content = file.read()
            print("\nIsi file saat ini:\n")
            print(content)

        # Meminta pengguna memasukkan kode baru untuk mengganti seluruh isi file
        print("\nMasukkan kode baru untuk file (ketik 'selesai' untuk mengakhiri):")

        new_code = []
        while True:
            line = input(">>> ")
            if line.lower() == 'selesai':
                break
            new_code.append(line)

        # Menulis kode baru ke file, menggantikan isi yang lama
        with open(filename, 'w') as file:  # 'w' untuk menulis ulang isi file
            file.write("\n".join(new_code))  # Menulis kode baru ke dalam file

        print(f"\nFile '{filename}' telah berhasil diperbarui dengan kode baru.")

    except FileNotFoundError:
        print(f"File '{filename}' tidak ditemukan. Pastikan nama file sudah benar.")
    except Exception as e:
        print(f"Terjadi kesalahan: {e}")

# Memanggil fungsi untuk menjalankan tools edit file
edit_file()