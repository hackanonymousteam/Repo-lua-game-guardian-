import os
from colorama import Fore, Style

def clear_screen():
    # Membersihkan layar sesuai OS yang digunakan
    os.system('cls' if os.name == 'nt' else 'clear')

def show_main_menu():
    print(f"{Fore.GREEN}Selamat Datang di Kalkulator Uji!{Style.RESET_ALL}")
    print(f"{Fore.CYAN}Pilih Operasi:")
    print("1. ➕ Penjumlahan")
    print("2. ➖ Pengurangan")
    print("3. ✖️ Perkalian")
    print("4. ➗ Pembagian")
    print("5. 🗑️ Keluar")

def pause_before_menu():
    input(f"{Fore.YELLOW}Tekan Enter untuk kembali ke menu utama...{Style.RESET_ALL}")

def main():
    while True:
        clear_screen()  
        show_main_menu()

        choice = input(f"{Fore.CYAN}Pilih Operasi: {Style.RESET_ALL}")

        if choice == "1":
            num1 = float(input("Angka pertama: "))
            num2 = float(input("Angka kedua: "))
            print(f"{Fore.MAGENTA}Hasil Penjumlahan: {num1 + num2}{Style.RESET_ALL}")

        elif choice == "2":
            num1 = float(input("Angka pertama: "))
            num2 = float(input("Angka kedua: "))
            print(f"{Fore.MAGENTA}Hasil Pengurangan: {num1 - num2}{Style.RESET_ALL}")

        elif choice == "3":
            num1 = float(input("Angka pertama: "))
            num2 = float(input("Angka kedua: "))
            print(f"{Fore.MAGENTA}Hasil Perkalian: {num1 * num2}{Style.RESET_ALL}")

        elif choice == "4":
            num1 = float(input("Angka pertama: "))
            num2 = float(input("Angka kedua: "))
            if num2 == 0:
                print("[ERROR] Tidak dapat membagi oleh nol!")
            else:
                print(f"{Fore.MAGENTA}Hasil Pembagian: {num1 / num2}{Style.RESET_ALL}")

        elif choice == "5":
            print(f"{Fore.RED}Sampai jumpa!{Style.RESET_ALL}")
            break

        else:
            print(f"{Fore.RED}[ERROR] Menu tidak ditemukan, coba lagi!{Style.RESET_ALL}")

        pause_before_menu()

main()