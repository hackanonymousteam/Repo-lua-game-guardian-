const readline = require('readline');
const { exec } = require('child_process');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question('Masukkan URL yang ingin dibuka: ', (url) => {
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
        url = 'https://' + url;
    }
    console.log(`Membuka URL: ${url}`);

    // Menggunakan perintah "start" untuk Windows, atau "open" untuk macOS/Linux
    const command = process.platform === 'win32' ? `start ${url}` : `xdg-open ${url}`;
    
    exec(command, (err) => {
        if (err) {
            console.error('Gagal membuka URL:', err.message);
        } else {
            console.log('URL berhasil dibuka di browser');
        }
        rl.close();
    });
});