import requests
import re
import os

def print_in_border(text, width=60):
    lines = []
    words = text.split()
    line = ""

    for word in words:
        if len(line) + len(word) + 1 > width:
            lines.append(line)
            line = word
        else:
            if line:
                line += " "
            line += word
    if line:
        lines.append(line)

    os.system("clear")
    print("+" + "-" * (width + 2) + "+")
    for line in lines:
        print("| " + line.ljust(width) + " |")
    print("+" + "-" * (width + 2) + "+")

def send_request():
    pertanyaan = input("Masukkan pertanyaan Anda: ")
    
    url = "https://www.blackbox.ai/api/chat"
    headers = {
        "Host": "www.blackbox.ai",
        "Content-Length": "676",
        "Sec-CH-UA-Platform": "\"Android\"",
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36",
        "Sec-CH-UA": "\"Google Chrome\";v=\"131\", \"Chromium\";v=\"131\", \"Not_A Brand\";v=\"24\"",
        "Content-Type": "application/json",
        "Sec-CH-UA-Mobile": "?1",
        "Accept": "*/*",
        "Origin": "https://www.blackbox.ai",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
        "Referer": "https://www.blackbox.ai/"
    }

    body = {
        "messages": [
            {
                "role": "user",
                "content": pertanyaan,
                "id": "pzlUPKb"
            }
        ],
        "agentMode": {},
        "id": "mEWrc8Z",
        "previewToken": None,
        "userId": None,
        "codeModelMode": True,
        "trendingAgentMode": {},
        "isMicMode": False,
        "userSystemPrompt": None,
        "maxTokens": 1024,
        "playgroundTopP": None,
        "playgroundTemperature": None,
        "isChromeExt": False,
        "githubToken": "",
        "clickedAnswer2": False,
        "clickedAnswer3": False,
        "clickedForceWebSearch": False,
        "visitFromDelta": False,
        "mobileClient": False,
        "userSelectedModel": None,
        "validated": "00f37b34-a166-4efb-bce5-1312d87f2f94",
        "imageGenerationMode": False,
        "webSearchModePrompt": False,
        "deepSearchMode": False,
        "domains": None,
        "vscodeClient": False,
        "codeInterpreterMode": False
    }

    try:
        response = requests.post(url, headers=headers, json=body)
        if response.status_code == 200:
            raw_response = response.text
            match = re.search(r'\]\$~~~\$(.*)', raw_response, re.DOTALL)
            if match:
                hasil = match.group(1).strip()
                print_in_border(hasil, width=60)
            else:
                print_in_border("Tidak ada hasil yang ditemukan dalam respons.", width=60)
        else:
            print_in_border(f"Permintaan gagal dengan status kode: {response.status_code}", width=60)
    except Exception as e:
        print_in_border(f"Terjadi kesalahan: {e}", width=60)

send_request()