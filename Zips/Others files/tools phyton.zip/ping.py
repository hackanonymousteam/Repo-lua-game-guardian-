import os

def ping_host(host):
    response = os.system(f"ping -c 1 {host}")
    if response == 0:
        print(f"{host} aktif (reachable).")
    else:
        print(f"{host} tidak aktif (unreachable).")

    # Tunggu input sebelum kembali ke menu utama
    input("\nTekan Enter untuk kembali ke menu utama...")

def main():
    host = input("Masukkan Host atau IP yang ingin di-ping: ")
    ping_host(host)

if __name__ == "__main__":
    main()