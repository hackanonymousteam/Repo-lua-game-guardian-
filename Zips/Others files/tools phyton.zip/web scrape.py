import requests

# Mengambil HTML dari URL dan menyimpannya ke file lokal
def fetch_html(url, output_file):
    try:
        response = requests.get(url)
        response.raise_for_status()
        with open(output_file, "w", encoding="utf-8") as html_file:
            html_file.write(response.text)
        print(f"Kode HTML telah disimpan di {output_file}")
    except requests.RequestException as e:
        print(f"Gagal mengambil data dari link: {e}")

# Fungsi utama untuk menjalankan tools
def main():
    url = input("Masukkan URL: ")
    output_file = input("Masukkan nama file untuk menyimpan HTML: ")
    fetch_html(url, output_file)

# Menjalankan fungsi utama
if __name__ == "__main__":
    main()