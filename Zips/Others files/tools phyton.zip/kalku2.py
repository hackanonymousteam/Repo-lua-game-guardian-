import os
from colorama import Fore, Style
import math

# Membersihkan layar sesuai OS yang digunakan
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

# Menampilkan menu utama kalkulator
def show_main_menu():
    print(f"{Fore.GREEN}Kalkulator Super Lengkap HP 🗿{Style.RESET_ALL}")
    print(f"{Fore.CYAN}Pilih Fitur:")
    print("1. ➕ Penjumlahan")
    print("2. ➖ Pengurangan")
    print("3. ✖️ Perkalian")
    print("4. ➗ Pembagian")
    print("5. 🔢 Pangkat dan Akar")
    print("6. 📐 Trigonometri (sin, cos, tan)")
    print("7. 🔍 Logaritma")
    print("8. 🔄 Konversi Unit")
    print("9. 📁 Memori Kalkulasi")
    print("0. 🔙 Keluar")

# Mengatur memori kalkulasi
memory = 0

# Memilih fitur kalkulasi
def main():
    global memory
    while True:
        clear_screen()
        show_main_menu()

        choice = input(f"{Fore.CYAN}Pilih menu: {Style.RESET_ALL}")

        if choice == "1":
            num1 = float(input("Angka pertama: "))
            num2 = float(input("Angka kedua: "))
            print(f"{Fore.MAGENTA}Hasil Penjumlahan: {num1 + num2}{Style.RESET_ALL}")

        elif choice == "2":
            num1 = float(input("Angka pertama: "))
            num2 = float(input("Angka kedua: "))
            print(f"{Fore.MAGENTA}Hasil Pengurangan: {num1 - num2}{Style.RESET_ALL}")

        elif choice == "3":
            num1 = float(input("Angka pertama: "))
            num2 = float(input("Angka kedua: "))
            print(f"{Fore.MAGENTA}Hasil Perkalian: {num1 * num2}{Style.RESET_ALL}")

        elif choice == "4":
            num1 = float(input("Angka pertama: "))
            num2 = float(input("Angka kedua: "))
            if num2 == 0:
                print("[ERROR] Tidak dapat membagi oleh nol!")
            else:
                print(f"{Fore.MAGENTA}Hasil Pembagian: {num1 / num2}{Style.RESET_ALL}")

        elif choice == "5":
            num = float(input("Angka: "))
            print(f"{Fore.MAGENTA}Pangkat 2: {num**2}")
            print(f"{Fore.MAGENTA}Pangkat 3: {num**3}")
            print(f"{Fore.MAGENTA}Akar kuadrat: {math.sqrt(num)}")

        elif choice == "6":
            angle = float(input("Sudut dalam derajat: "))
            angle_rad = math.radians(angle)
            print(f"{Fore.MAGENTA}Sin: {math.sin(angle_rad)}")
            print(f"{Fore.MAGENTA}Cos: {math.cos(angle_rad)}")
            print(f"{Fore.MAGENTA}Tan: {math.tan(angle_rad)}")

        elif choice == "7":
            num = float(input("Angka: "))
            base = float(input("Basis: "))
            print(f"{Fore.MAGENTA}Logaritma ({base}): {math.log(num, base)}")

        elif choice == "8":
            print("Konversi Unit:")
            print("1. Panjang (meter ↔ kilometer)")
            print("2. Massa (gram ↔ kilogram)")
            print("3. Suhu (C ↔ F)")
            unit = input("Pilih konversi: ")

            if unit == "1":
                meter = float(input("Masukkan dalam meter: "))
                print(f"{Fore.MAGENTA}{meter} meter = {meter / 1000} kilometer")

            elif unit == "2":
                gram = float(input("Masukkan dalam gram: "))
                print(f"{Fore.MAGENTA}{gram} gram = {gram / 1000} kilogram")

            elif unit == "3":
                celsius = float(input("Suhu dalam Celsius: "))
                fahrenheit = (celsius * 1.8) + 32
                print(f"{Fore.MAGENTA}{celsius}°C = {fahrenheit}°F")

        elif choice == "9":
            print(f"{Fore.YELLOW}Menggunakan memori: {memory}")
            num = float(input("Simpan angka ke memori: "))
            memory = num
            print(f"{Fore.MAGENTA}Angka {num} disimpan di memori.")

        elif choice == "0":
            print(f"{Fore.RED}Keluar Kalkulator...{Style.RESET_ALL}")
            break

        else:
            print(f"{Fore.RED}[ERROR] Menu tidak ditemukan, coba lagi.")

        input("Tekan Enter untuk melanjutkan...")

main()