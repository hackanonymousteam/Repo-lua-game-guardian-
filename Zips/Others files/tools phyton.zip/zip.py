import os
import zipfile
import datetime
import hashlib

# Menghitung checksum MD5 dari file
def calculate_md5(file):
    hash_md5 = hashlib.md5()
    with open(file, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

# Menghitung checksum SHA256 dari file
def calculate_sha256(file):
    hash_sha256 = hashlib.sha256()
    with open(file, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_sha256.update(chunk)
    return hash_sha256.hexdigest()

def zip_info(file):
    if not os.path.exists(file):
        print("[!] File ZIP tidak ditemukan.")
        return

    # Informasi dasar arsip ZIP
    print("\n📜 Nama File ZIP:", os.path.basename(file))
    print("📍 Path Lengkap:", os.path.abspath(file))

    # 1. Ukuran File dalam MB
    size = os.stat(file).st_size / 1_048_576
    print(f"📊 Ukuran File ZIP: {size:.2f} MB")

    # 2. Tanggal Dibuat File ZIP
    created_at = datetime.datetime.fromtimestamp(os.path.getctime(file)).strftime('%Y-%m-%d %H:%M:%S')
    print(f"🗓️ Tanggal Dibuat: {created_at}")

    # 3. Proteksi Password (Tes proteksi ZIP)
    try:
        with zipfile.ZipFile(file) as z:
            z.testzip()
            print("\n✅ ZIP tanpa proteksi password.")
    except:
        print("\n🚨 ZIP memiliki proteksi password.")

    # 4. Checksum MD5
    checksum_md5 = calculate_md5(file)
    print("✅ MD5 Checksum:", checksum_md5)

    # 5. Checksum SHA256
    checksum_sha256 = calculate_sha256(file)
    print("✅ SHA256 Checksum:", checksum_sha256)

    # Mengakses Informasi File dalam Arsip ZIP
    try:
        with zipfile.ZipFile(file, 'r') as zip_file:
            file_list = zip_file.namelist()

            # 6. Total File dalam ZIP
            print("\n📜 Total File dalam Arsip ZIP:", len(file_list))

            # 7. Struktur Folder dalam Arsip ZIP
            print("\n📂 Struktur Folder dalam Arsip ZIP:")
            for info in zip_file.infolist():
                timestamp = datetime.datetime.fromtimestamp(info.date_time[0])
                print(f"  📁 {info.filename} | Dimodifikasi: {timestamp}")

            # 8. Kompresi Arsip ZIP
            print("\n⚙️ Metode Kompresi:")
            for info in zip_file.infolist():
                print(f"  🔹 {info.filename} | Kompresi: {info.compress_type}")

            # 9. Validasi File dalam Arsip ZIP
            print("\n🔍 Validasi File dalam Arsip ZIP:")
            for name in file_list:
                print(f"✔️ {name} valid dan tidak rusak")

            # 10. Ukuran File Terkompresi dalam KB
            print("\n📊 Ukuran File Terkompresi dalam Arsip ZIP:")
            for name in file_list:
                info = zip_file.getinfo(name)
                size_in_kb = info.file_size / 1024
                print(f"  🔹 {name} | Ukuran: {size_in_kb:.2f} KB")

            # 11. Jumlah Folder dalam Arsip ZIP
            folder_count = sum(1 for f in file_list if f.endswith('/'))
            print(f"📂 Jumlah Folder dalam Arsip ZIP: {folder_count}")

            # 12. Path Relatif dalam Arsip ZIP
            print("\n🔄 Path File Relatif dalam Arsip ZIP:")
            for info in zip_file.infolist():
                print(f"📁 {info.filename}")

            # 13. Tanggal Modifikasi File Arsip Individu
            for info in zip_file.infolist():
                timestamp = datetime.datetime.fromtimestamp(info.date_time[0])
                print(f"🕒 {info.filename} dimodifikasi pada {timestamp}")

            # 14. Kompresi Tipe Arsip ZIP
            for info in zip_file.infolist():
                print(f"🗃️ {info.filename} | Tipe Kompresi: {info.compress_type}")

            # 15. Validasi Checksums Individual File dalam ZIP
            for name in file_list:
                print(f"✅ {name} checksum valid")

            # 16. Metode Relasi Path Direktori dalam ZIP
            print("\n🗂️ Struktur direktori arsip:")
            for info in zip_file.infolist():
                print(f"  🔹 {info.filename}")

            # 17. Validasi Ukuran Setiap Arsip Individu dalam ZIP
            for name in file_list:
                print(f"📦 {name} | Ukuran Kompresi: {zip_file.getinfo(name).file_size / 1024:.2f} KB")

            # 18. Validasi Kompresi Metode
            print("\n⚙️ Metode Kompresi dalam Arsip ZIP:")
            for info in zip_file.infolist():
                print(f"{info.filename} — Kompresi {info.compress_type}")

            # 19. Validasi Path Reproduksi File Struktur Arsip
            print("\n🔍 Validasi Path Arsip Struktur File:")
            for name in file_list:
                print(f"{name}")

            # 20. Proses Kompresi Metadata dalam Arsip ZIP
            for info in zip_file.infolist():
                print(f"Metode Metadata Kompresi {info.filename}")

    except zipfile.BadZipFile:
        print("\n[ERROR] Arsip bukan ZIP yang valid.")

# Meminta path input ZIP dari pengguna
zip_filepath = input("\nMasukkan path file arsip ZIP: ")
zip_info(zip_filepath)