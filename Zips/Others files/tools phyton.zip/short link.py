import requests

def shorten_url(long_url):
    try:
        api_url = f"http://tinyurl.com/api-create.php?url={long_url}"
        response = requests.get(api_url)
        response.raise_for_status()
        print(f"URL Pendek: {response.text}")
    except requests.RequestException as e:
        print(f"Gagal memendekkan URL: {e}")

# Bagian utama yang dipanggil saat script dijalankan
if __name__ == "__main__":
    long_url = input("Masukkan URL panjang yang ingin dipendekkan: ")
    shorten_url(long_url)