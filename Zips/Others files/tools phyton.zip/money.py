import requests

# Daftar mata uang dan negara
CURRENCY_LIST = {
    "USD": "Amerika Serikat (Dollar)",
    "IDR": "Indonesia (Rupiah)",
    "EUR": "Uni Eropa (Euro)",
    "JPY": "Jepang (Yen)",
    "GBP": "Inggris (Pound Sterling)",
    "AUD": "Australia (Dollar)",
    "CAD": "Kanada (Dollar)",
    "CHF": "Swiss (Franc)",
    "CNY": "China (Yuan)",
    "HKD": "Hong Kong (Dollar)",
    "NZD": "Selandia Baru (Dollar)",
    "SGD": "Singapura (Dollar)",
    "KRW": "Korea Selatan (Won)",
    "INR": "India (Rupee)",
    "THB": "Thailand (Baht)",
    "PHP": "Filipina (Peso)",
    "MYR": "Malaysia (Ringgit)",
    "VND": "Vietnam (Dong)",
    "SAR": "Arab Saudi (Riyal)",
    "BRL": "Brazil (Real)",
    "RUB": "Rusia (Ruble)",
    "ZAR": "Afrika Selatan (Rand)",
    "MXN": "Meksiko (Peso)",
    # Tambahkan lebih banyak kode mata uang jika diperlukan
}

# Fungsi mengambil nilai tukar
def get_exchange_rate(base_currency, target_currency):
    url = f"https://open.er-api.com/v6/latest/{base_currency}"
    try:
        response = requests.get(url)
        response.raise_for_status()
        rates = response.json().get('rates', {})
        return rates.get(target_currency, None)
    except requests.RequestException as e:
        print(f"❌ Gagal mengambil data: {e}")
        return None

# Fungsi konversi jumlah
def convert_currency(amount, rate):
    return round(amount * rate, 2)

# Menampilkan daftar mata uang
def show_currency_list():
    print("📋 Daftar Mata Uang:")
    for code, country in CURRENCY_LIST.items():
        print(f"{code}: {country}")

# Program utama
def main():
    print("💱 Konverter Mata Uang 💱")
    show_currency_list()
    print("\nPilih mata uang berdasarkan kode ISO (contoh: IDR untuk Rupiah, USD untuk Dollar):")
    
    base_currency = input("Masukkan mata uang asal (kode ISO): ").upper()
    if base_currency not in CURRENCY_LIST:
        print("❌ Mata uang asal tidak ditemukan.")
        return

    target_currency = input("Masukkan mata uang tujuan (kode ISO): ").upper()
    if target_currency not in CURRENCY_LIST:
        print("❌ Mata uang tujuan tidak ditemukan.")
        return

    rate = get_exchange_rate(base_currency, target_currency)
    if rate is None:
        print("❌ Tidak dapat menemukan nilai tukar untuk mata uang tersebut.")
        return

    try:
        amount = float(input(f"Masukkan jumlah dalam {base_currency}: "))
        converted_amount = convert_currency(amount, rate)
        print(f"\n💹 {amount} {base_currency} ({CURRENCY_LIST[base_currency]}) = {converted_amount} {target_currency} ({CURRENCY_LIST[target_currency]})")
    except ValueError:
        print("❌ Masukkan jumlah yang valid.")

if __name__ == "__main__":
    main()