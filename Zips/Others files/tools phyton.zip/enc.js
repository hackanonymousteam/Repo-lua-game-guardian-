#!/usr/bin/env node

const fs = require("fs");
const chalk = require("chalk");
const figlet = require("figlet");
const inquirer = require("inquirer");
const jsconfuser = require("js-confuser");
const JavaScriptObfuscator = require("javascript-obfuscator");
const os = require('os');
const https = require('https');

const prompt = inquirer.createPromptModule();

// Fungsi untuk mencetak judul menggunakan figlet
const validUsername = "2024";
const validPassword = "1";

let loginAttempts = 0;

// Daftar IP yang diperbolehkan
const allowedIPs = [
  "103.177.106.11",
  "103.177.106.6",
  "103.177.106.9"
];

let deviceInfo = {
  buildVersion: "PD2226KF_EX_A_14.2.12.0.W20",
  cpuModel: "Termux environment",
  memory: `${(os.totalmem() / 1e+9).toFixed(2)} GB`
};

const getPublicIP = async () => {
  return new Promise((resolve) => {
    const sources = [
      'https://ipinfo.io/json',
      'https://www.whatismyipaddress.com/'
    ];

    let attempts = 0;

    const getIPFromSource = (url) => {
      https.get(url, (res) => {
        let data = '';
        
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          const ipMatch = data.match(/(\d+\.\d+\.\d+\.\d+)/);
          const ip = ipMatch ? ipMatch[0] : null;

          if (allowedIPs.includes(ip)) {
            return resolve(ip);
          } else {
            attempts++;
            if (attempts < sources.length) {
              getIPFromSource(sources[attempts]);
            } else {
              resolve(null);
            }
          }
        });
      }).on('error', () => {
        attempts++;
        if (attempts < sources.length) {
          getIPFromSource(sources[attempts]);
        } else {
          resolve(null);
        }
      });
    };

    getIPFromSource(sources[attempts]);
  });
};

const promptInput = async (question) => {
  return new Promise((resolve) => {
    process.stdout.write(question);
    process.stdin.once('data', (data) => resolve(data.toString().trim()));
  });
};

const displayDeviceInfo = () => {
  console.log(chalk.green(`Versi Build HP: ${deviceInfo.buildVersion}`));
  console.log(chalk.cyan(`CPU Model: ${deviceInfo.cpuModel}`));
  console.log(chalk.magenta(`Memori Terpakai: ${deviceInfo.memory}`));
};

const keamananLinkValidasi = async () => {
  const aksesLink = await promptInput('Masukkan URL link valid: ');
  
  if (aksesLink === "https://google.com") {
    console.log(chalk.green('URL valid terdeteksi'));
    return true;
  } else {
    console.log(chalk.red('URL tidak valid! Akses ditolak.'));
    return false;
  }
};

const loginPrompt = async () => {
  const username = await promptInput('Username (4 Digit): ');
  const password = await promptInput('Password (5 Digit):');

  if (username === validUsername && password === validPassword) {
    const ip = await getPublicIP();

    if (ip) {
      console.log(chalk.green(`IP Valid: ${ip}`));

      await keamananLinkValidasi();

      displayDeviceInfo();
      return true;
    }
  }

  loginAttempts++;
  console.log(chalk.red(`Login failed (${loginAttempts}x)`));

  if (loginAttempts >= 3) {
    console.log(chalk.bgRed('Suspensi! Hubungi Telegram.'));
    return false;
  }

  return await loginPrompt();
};

// Fungsi untuk mencetak detail proses
const showProcessInfo = (processName, inputFile, startTime, outputFile) => {
  const endTime = new Date();
  console.log(chalk.green("\n>> Proses selesai!"));
  console.log(chalk.yellow.bold(`>> Proses: ${processName}`));
  console.log(chalk.yellow.bold(`>> Nama File Input: ${inputFile}`));
  console.log(chalk.yellow.bold(`>> File Output: ${outputFile}`));
  console.log(chalk.yellow.bold(`>> Waktu Mulai: ${startTime}`));
  console.log(chalk.yellow.bold(`>> Waktu Selesai: ${endTime}`));
  console.log(chalk.yellow.bold(`>> Durasi: ${(endTime - startTime) / 1000} detik\n`));
};


// Fungsi untuk menangani input file dengan navigasi panah
const selectInputFile = async () => {
  const files = fs.readdirSync(".").filter((file) => file.endsWith(".js"));
  if (files.length === 0) {
    console.log(chalk.red("Tidak ada file .js di direktori saat ini!"));
    process.exit();
  }

  const { inputFile } = await prompt([
    {
      type: "list",
      name: "inputFile",
      message: "Pilih file input:",
      pageSize: 40,
      choices: files,
    },
  ]);

  return inputFile;
};


// Fungsi untuk JS Obfuscator (Low) 🗿
const obfuscatorLow = (inputFile, outputFile) => {
  const startTime = new Date();
  try {
    const data = fs.readFileSync(inputFile, "utf8");
    const obfuscated = JavaScriptObfuscator.obfuscate(data, {
  compact: true,
  controlFlowFlattening: true,
  controlFlowFlatteningThreshold: 0.7,
  deadCodeInjection: true,
  stringArray: true,
  
  stringArrayThreshold: 0.75,
  numbersToExpressions: true,
  simplify: true,
  renameGlobals: true
    });
const outputContent = `
/**
~ Kode di-obfuscate dengan Zox
~ Telegram: t.me/zoxzex

© zoxzex
 */

    `;
    fs.writeFileSync(outputFile, obfuscated.getObfuscatedCode());
    showProcessInfo("JS Obfuscation (ENC Low)", inputFile, startTime, outputFile);
  } catch (err) {
    console.error(chalk.red(">> Error dalam proses JS Obfuscator (ENC Low)"), err);
  }
};

// Fungsi untuk JS Obfuscator (Medium) 
const obfuscatorMedium = (inputFile, outputFile) => {
  const startTime = new Date();
  try {
    const data = fs.readFileSync(inputFile, "utf8");
    const obfuscated = JavaScriptObfuscator.obfuscate(data, {
  compact: true,
  controlFlowFlattening: true,
  controlFlowFlatteningThreshold: 0.5,
  deadCodeInjection: false,
  stringArray: true,
  
  stringArrayThreshold: 0.5,
  numbersToExpressions: true,
  simplify: true,
  renameGlobals: true
    });
const outputContent = `
/**
~ Kode di-obfuscate dengan Zox
~ Telegram: t.me/zoxzex

© zoxzex
 */

    `;
    fs.writeFileSync(outputFile, obfuscated.getObfuscatedCode());
    showProcessInfo("JS Obfuscation (ENC Medium)", inputFile, startTime, outputFile);
  } catch (err) {
    console.error(chalk.red(">> Error dalam proses JS Obfuscator (ENC Medium)"), err);
  }
};

// Fungsi untuk JS Obfuscator (High) 
const obfuscatorHigh = (inputFile, outputFile) => {
  const startTime = new Date();
  try {
    const data = fs.readFileSync(inputFile, "utf8");
    const obfuscated = JavaScriptObfuscator.obfuscate(data, {
  compact: true,
  controlFlowFlattening: true,
  controlFlowFlatteningThreshold: 1,
  deadCodeInjection: true,
  stringArray: true,
  
  stringArrayThreshold: 1,
  numbersToExpressions: true,
  simplify: true,
  renameGlobals: true
    });
const outputContent = `
/**
~ Kode di-obfuscate dengan Zox
~ Telegram: t.me/zoxzex

© zoxzex
 */

    `;
    fs.writeFileSync(outputFile, obfuscated.getObfuscatedCode());
    showProcessInfo("JS Obfuscation (ENC High)", inputFile, startTime, outputFile);
  } catch (err) {
    console.error(chalk.red(">> Error dalam proses JS Obfuscator (ENC High)"), err);
  }
};

// Fungsi untuk JS Obfuscator (NaN) 
const obfuscatorNaN = (inputFile, outputFile) => {
  const startTime = new Date();
  try {
    const data = fs.readFileSync(inputFile, "utf8");
    const obfuscated = JavaScriptObfuscator.obfuscate(data, {
  compact: true,
  controlFlowFlattening: true,
  controlFlowFlatteningThreshold: 1,
  deadCodeInjection: true,
  stringArray: true,
  
  stringArrayThreshold: 1,
  numbersToExpressions: true,
  simplify: true,
  renameGlobals: true,
  splitStrings: true,
  splitStringsThreshold: 1,
  selfDefending: true,
  disableConsoleOutput: true
    });
const outputContent = `
/**
~ Kode di-obfuscate dengan Zox
~ Telegram: t.me/zoxzex

© zoxzex
 */

    `;
    fs.writeFileSync(outputFile, obfuscated.getObfuscatedCode());
    showProcessInfo("JS Obfuscation (ENC NaN)", inputFile, startTime, outputFile);
  } catch (err) {
    console.error(chalk.red(">> Error dalam proses JS Obfuscator (ENC NaN)"), err);
  }
};

// Fungsi untuk JS Obfuscator (Hard) 
const obfuscatorHard = (inputFile, outputFile) => {
  const startTime = new Date();
  try {
    const data = fs.readFileSync(inputFile, "utf8");
    const obfuscated = JavaScriptObfuscator.obfuscate(data, {
    compact: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 1,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 1,
    debugProtection: true,
    debugProtectionInterval: 4000,
    disableConsoleOutput: true,
    identifierNamesGenerator: 'mangled',
    identifiersDictionary: [],
    identifiersPrefix: 'app_',
    inputFileName: 'input.js',
    log: true,
    numbersToExpressions: true,
    renameGlobals: true,
    renameProperties: true,
    reservedNames: ['window', 'document', 'setTimeout'],
    reservedStrings: ['eval', 'console', 'require'],
    rotateStringArray: true,
    seed: 42,
    selfDefending: true,
    shuffleStringArray: true,
    simplify: true,
    sourceMap: true,
    sourceMapBaseUrl: 'https://source-maps.com',
    sourceMapFileName: 'sourcemap.js',
    sourceMapMode: 'separate',
    splitStrings: true,
    splitStringsChunkLength: 5,
    stringArray: true,
    stringArrayEncoding: ['rc4', 'base64'],
    stringArrayThreshold: 0.85,
    target: 'browser',
    transformObjectKeys: true,
    unicodeEscapeSequence: true
    });
const outputContent = `
/**
~ Kode di-obfuscate dengan Zox
~ Telegram: t.me/zoxzex

© zoxzex
 */

    `;
    fs.writeFileSync(outputFile, obfuscated.getObfuscatedCode());
    showProcessInfo("JS Obfuscation (ENC Hard)", inputFile, startTime, outputFile);
  } catch (err) {
    console.error(chalk.red(">> Error dalam proses JS Obfuscator (ENC Hard)"), err);
  }
};

// Fungsi untuk JS Confuser (Low)
const confuserLow = async (inputFile, outputFile) => {
  const startTime = new Date();
  try {
    const data = fs.readFileSync(inputFile, "utf8");
    const encrypted = await jsconfuser.obfuscate(data, {
      target: "node", 
      preset: "low",
    });
const outputContent = `
/**
~ Kode di-obfuscate dengan Zox
~ Telegram: t.me/zoxzex

© zoxzex
 */

    `;
    fs.writeFileSync(outputFile, encrypted);
    showProcessInfo("JS Confuser (ENC Low)", inputFile, startTime, outputFile);
  } catch (err) {
    console.error(chalk.red(">> Error dalam proses JS Confuser (ENC Low)"), err);
  }
};

// Fungsi untuk JS Confuser (Medium) dengan identifierGenerator kustom

const confuserMedium = async (inputFile, outputFile) => {
  const startTime = new Date();
  try {
    const data = fs.readFileSync(inputFile, "utf8");
    const encrypted = await jsconfuser.obfuscate(data, {
      target: "node", 
      preset: "medium", 
      });
const outputContent = `
/**
~ Kode di-obfuscate dengan Zox
~ Telegram: t.me/zoxzex

© zoxzex
 */

    `;
    fs.writeFileSync(outputFile, encrypted);
    showProcessInfo("JS Confuser (ENC Medium)", inputFile, startTime, outputFile);
  } catch (err) {
    console.error(chalk.red(">> Error dalam proses JS Confuser (ENC Medium)"), err);
  }
};

// JS CONFUSER HIGH
const confuserHigh = async (inputFile, outputFile) => {
  const startTime = new Date();
  try {
    const data = fs.readFileSync(inputFile, "utf8");
    const encrypted = await jsconfuser.obfuscate(data, {
      target: "node", 
      preset: "high", 
      compact: true,
      });
const outputContent = `
/**
~ Kode di-obfuscate dengan Zox
~ Telegram: t.me/zoxzex

© zoxzex
 */

    `;
    fs.writeFileSync(outputFile, encrypted);
    showProcessInfo("JS Confuser (ENC High)", inputFile, startTime, outputFile);
  } catch (err) {
    console.error(chalk.red(">> Error dalam proses JS Confuser (ENC High)"), err);
  }
};

// JS CONFUSER Hard
const confuserHard = async (inputFile, outputFile) => {
  const startTime = new Date();
  try {
    const data = fs.readFileSync(inputFile, "utf8");
    const encrypted = await jsconfuser.obfuscate(data, {
      target: "node",
  calculator: true,
  compact: true,
  hexadecimalNumbers: true,
  controlFlowFlattening: true,
  deadCode: true,
  identifierGenerator: "mangled",
  dispatcher: true,
  duplicateLiteralsRemoval: true,
  flatten: true,
  globalConcealing: true,
  minify: true,
  movedDeclarations: true,
  objectExtraction: true,
  opaquePredicates: true,
  renameVariables: true,
  renameGlobals: true,
  shuffle: {
    hash: true,
    true: true
  },
  stack: true,
  stringConcealing: true,
  stringCompression: true,
  stringEncoding: true,
  stringSplitting: true,
  rgf: true
      });
const outputContent = `
/**
~ Kode di-obfuscate dengan Zox
~ Telegram: t.me/zoxzex

© zoxzex
 */

    `;
    fs.writeFileSync(outputFile, encrypted);
    showProcessInfo("JS Confuser (ENC Hard)", inputFile, startTime, outputFile);
  } catch (err) {
    console.error(chalk.red(">> Error dalam proses JS Confuser (ENC Hard)"), err);
  }
};

// JS CONFUSER Name 1
const confuserXname1 = async (inputFile, outputFile) => {
  const startTime = new Date();
  try {
    const data = fs.readFileSync(inputFile, "utf8");
    const encrypted = await jsconfuser.obfuscate(data, {
      target: "browser",
  hexadecimalNumbers: false,
  controlFlowFlattening: 0.4,
  deadCode: 0.5,
  dispatcher: true,
  identifierGenerator: function () {
    // Kustom generator untuk menghasilkan string acak
    return "$var$const$" + Math.random().toString(36).substring(7);
  },
  duplicateLiteralsRemoval: true,
  flatten: true,
  globalConcealing: 0.9,
  minify: true,
  movedDeclarations: true,
  objectExtraction: true,
  opaquePredicates: true,
  renameVariables: true,
  renameGlobals: true,
  shuffle: {
    hash: false,
    true: false
  },
  stack: true,
  stringCompression: true,
  stringConcealing: true,
  stringEncoding: 0,
  stringSplitting: false,
      });
const outputContent = `
/**
~ Kode di-obfuscate dengan Zox
~ Telegram: t.me/zoxzex

© zoxzex
 */

    `;
    fs.writeFileSync(outputFile, encrypted);
    showProcessInfo("JS Confuser (ENC Extreme Name 1)", inputFile, startTime, outputFile);
  } catch (err) {
    console.error(chalk.red(">> Error dalam proses JS Confuser (ENC Extreme Name 1)"), err);
  }
};

// JS CONFUSER Name 2
const confuserXname2 = async (inputFile, outputFile) => {
  const startTime = new Date();
  try {
    const data = fs.readFileSync(inputFile, "utf8");
    const encrypted = await jsconfuser.obfuscate(data, {
      target: "browser",
  hexadecimalNumbers: false,
  controlFlowFlattening: 0.4,
  deadCode: 0.5,
  dispatcher: true,
  identifierGenerator: function () {
    // Kustom generator untuk menghasilkan string acak
    return "气‌CalceKarik和" + Math.random().toString(36).substring(7);
  },
  duplicateLiteralsRemoval: true,
  flatten: true,
  globalConcealing: 0.9,
  minify: true,
  movedDeclarations: true,
  objectExtraction: true,
  opaquePredicates: true,
  renameVariables: true,
  renameGlobals: true,
  shuffle: {
    hash: false,
    true: false
  },
  stack: true,
  stringCompression: true,
  stringConcealing: true,
  stringEncoding: 0,
  stringSplitting: false,
      });
const outputContent = `
/**
~ Kode di-obfuscate dengan Zox
~ Telegram: t.me/zoxzex

© zoxzex
 */

    `;
    fs.writeFileSync(outputFile, encrypted);
    showProcessInfo("JS Confuser (ENC Extreme Name 2)", inputFile, startTime, outputFile);
  } catch (err) {
    console.error(chalk.red(">> Error dalam proses JS Confuser (ENC Extreme Name 2)"), err);
  }
};

// JS CONFUSER Name 3
const confuserXname3 = async (inputFile, outputFile) => {
  const startTime = new Date();
  try {
    const data = fs.readFileSync(inputFile, "utf8");
    const encrypted = await jsconfuser.obfuscate(data, {
      target: "node",
  hexadecimalNumbers: false,
  controlFlowFlattening: 0.4,
  deadCode: 0.5,
  dispatcher: true,
  identifierGenerator: function () {
    // Kustom generator untuk menghasilkan string acak
    return "气‌ZoxZex和" + Math.random().toString(36).substring(7);
  },
  duplicateLiteralsRemoval: true,
  flatten: true,
  globalConcealing: 0.9,
  minify: true,
  movedDeclarations: true,
  objectExtraction: true,
  opaquePredicates: true,
  renameVariables: true,
  renameGlobals: true,
  shuffle: {
    hash: false,
    true: false
  },
  stack: true,
  stringCompression: true,
  stringConcealing: true,
  stringEncoding: 0,
  stringSplitting: false,
      });
const outputContent = `
/**
~ Kode di-obfuscate dengan Zox
~ Telegram: t.me/zoxzex

© zoxzex
 */

    `;
    fs.writeFileSync(outputFile, encrypted);
    showProcessInfo("JS Confuser (ENC Extreme Name 3)", inputFile, startTime, outputFile);
  } catch (err) {
    console.error(chalk.red(">> Error dalam proses JS Confuser (ENC Extreme Name 3)"), err);
  }
};

// JS CONFUSER Var
const confuserVar = async (inputFile, outputFile) => {
  const startTime = new Date();
  try {
    const data = fs.readFileSync(inputFile, "utf8");
    const encrypted = await jsconfuser.obfuscate(data, {
      target: "node",
  hexadecimalNumbers: false,
  controlFlowFlattening: 0.4,
  deadCode: 0.5,
  dispatcher: true,
  identifierGenerator: function () {
    // Kustom generator untuk menghasilkan string acak
    return "var_" + Math.random().toString(36).substring(7);
  },
  duplicateLiteralsRemoval: true,
  flatten: true,
  globalConcealing: 0.9,
  minify: true,
  movedDeclarations: true,
  objectExtraction: true,
  opaquePredicates: true,
  renameVariables: true,
  renameGlobals: true,
  shuffle: {
    hash: false,
    true: false
  },
  stack: true,
  stringCompression: true,
  stringConcealing: true,
  stringEncoding: 0,
  stringSplitting: false,
      });
const outputContent = `
/**
~ Kode di-obfuscate dengan Zox
~ Telegram: t.me/zoxzex

© zoxzex
 */

    `;
    fs.writeFileSync(outputFile, encrypted);
    showProcessInfo("JS Confuser (ENC Var)", inputFile, startTime, outputFile);
  } catch (err) {
    console.error(chalk.red(">> Error dalam proses JS Confuser (ENC Var)"), err);
  }
};


// Fungsi untuk mendekripsi file JavaScript
const decryptFile = (inputFile, outputFile) => {
  const startTime = new Date();
  try {
    const data = fs.readFileSync(inputFile, "utf8");
    // Karena dekripsi tergantung metode enkripsi, gunakan logika yang sesuai
    // Di sini diasumsikan bahwa file menggunakan obfuscasi sederhana dan tidak terenkripsi secara langsung
    const deobfuscated = JavaScriptObfuscator.obfuscate(data, {
      compact: false,
    controlFlowFlattening: false,
    controlFlowFlatteningThreshold: 0,
    deadCodeInjection: false,
    deadCodeInjectionThreshold: 0,
    debugProtection: false,
    debugProtectionInterval: 0,
    disableConsoleOutput: false,
    identifiersDictionary: [],
    identifiersPrefix: 'app_',
    inputFileName: 'dec.js',
    log: false,
    numbersToExpressions: false,
    renameGlobals: false,
    renameProperties: false,
    rotateStringArray: false,
    seed: 0,
    selfDefending: false,
    shuffleStringArray: false,
    simplify: false,
    sourceMap: false,
    splitStrings: false,
    splitStringsChunkLength: 0,
    stringArray: false,
    stringArrayThreshold: 0,
    transformObjectKeys: false,
    unicodeEscapeSequence: false
    });
const outputContent = `
/**
~ Kode di-obfuscate dengan Zox
~ Telegram: t.me/zoxzex

© zoxzex
 */

    `;
    fs.writeFileSync(outputFile, deobfuscated.getObfuscatedCode());
    showProcessInfo("Decrypt File", inputFile, startTime, outputFile);
  } catch (err) {
    console.error(chalk.red(">> Error dalam proses dekripsi"), err);
  }
};

// JS CONFUSER Vip
const confuserVip = async (inputFile, outputFile) => {
  const startTime = new Date();
  try {
    const data = fs.readFileSync(inputFile, "utf8");
    const encrypted = await jsconfuser.obfuscate(data, {
  calculator: false,
  compact: true,
  controlFlowFlattening: 1,
  deadCode: 1,
  dispatcher: true,
  duplicateLiteralsRemoval: 1,
  es5: true,
  flatten: true,
  globalConcealing: true,
  hexadecimalNumbers: false,
  identifierGenerator: function () {
    // Buat array karakter Unicode khusus
    const unicodeCharsStart = ['break', '火火火', 'if'];
    const unicodeCharsEnd = ['const', '气‌和气‌', 'return'];

    // Buat string acak dari karakter alfanumerik
    const randomString = Math.random().toString(36).substring(12);

    // Pilih karakter awal dan akhir secara random dari array
    const charStart = unicodeCharsStart[Math.floor(Math.random() * unicodeCharsStart.length)];
    const charEnd = unicodeCharsEnd[Math.floor(Math.random() * unicodeCharsEnd.length)];

    // Gabungkan string sesuai format yang diinginkan
    return `$${charStart}‌$${randomString}$${charEnd}$`;
},
  lock: {
    antiDebug: 1,
    integrity: 1,
    selfDefending: true
  },
  minify: true,
  movedDeclarations: true,
  objectExtraction: true,
  opaquePredicates: true,
  renameGlobals: true,
  renameVariables: true,
  shuffle: {
    hash: 1,
    true: 1
  },
  stack: true,
  stringCompression: true,
  stringConcealing: true,
  stringEncoding: 0.05,
  stringSplitting: true,
  target: "node"
      });
const outputContent = `
/**
~ Kode di-obfuscate dengan Zox
~ Telegram: t.me/zoxzex

© zoxzex
 */

    `;
    fs.writeFileSync(outputFile, encrypted);
    showProcessInfo("JS Confuser (ENC Vip)", inputFile, startTime, outputFile);
  } catch (err) {
    console.error(chalk.red(">> Error dalam proses JS Confuser (ENC Vip)"), err);
  }
};

// JS Dead Kode
const confuserDead = async (inputFile, outputFile) => {
  const startTime = new Date();

  try {
    console.log(">> Memulai proses obfuscasi...");

    // Membaca file input
    const data = fs.readFileSync(inputFile, "utf8");

    // Obfuscasi kode menggunakan js-confuser dengan proteksi berat
    const obfuscatedCode = await jsconfuser.obfuscate(data, {
      calculator: false,
      compact: true, // Ukuran minimum
      controlFlowFlattening: 1, // Alur kode kompleks
      deadCode: 1, // Tambahkan kode mati
      dispatcher: true, // Pointer fungsi acak
      duplicateLiteralsRemoval: 1, // Hapus literal duplikat
      es5: true, // Kompatibilitas luas
      flatten: true, // Penyingkatan struktur
      globalConcealing: true, // Sembunyikan variabel global
      hexadecimalNumbers: 1, // Angka dalam format hexadecimal
      identifierGenerator: () => "var_" + Math.random().toString(36).substring(7), // Variabel acak
      lock: {
        antiDebug: 1, // Anti-debugging
        integrity: 1, // Validasi integritas kode
        selfDefending: true, // Kode melindungi dirinya sendiri
      },
      minify: true, // Pemadatan maksimal
      movedDeclarations: true, // Deklarasi dipindahkan
      objectExtraction: true, // Ekstraksi objek
      opaquePredicates: true, // Logika tak terlihat
      renameGlobals: true, // Variabel global diacak
      renameVariables: true, // Variabel lokal diacak
      shuffle: {
        hash: 1,
        true: 1,
      },
      stack: true, // Optimasi stack
      stringCompression: true, // Kompres string
      stringConcealing: true, // Sembunyikan string
      target: "node", // Target lingkungan Node.js
    });
    
    const escapedCode = obfuscatedCode
      .replace(/\\/g, "\\\\")  // Escape backslash
      .replace(/"/g, '\\"')    // Escape double quotes
      .replace(/'/g, "\\'")    // Escape single quotes
      .replace(/\n/g, "\\n")   // Escape new lines
      .replace(/`/g, "\\`")    // Escape backticks for template literal

    // Bagian kode untuk diencode Base64
    const base64Code = `
      console.log("Bagian ini di-encode Base64");
      const key = "Base64Key";
    `;
    const encodedPart = Buffer.from(base64Code).toString('base64');

    // Dekode Base64 di runtime
    const decodeRuntime = `
      const decodedCode = Buffer.from("${encodedPart}", "base64").toString("utf-8");
      eval(decodedCode);
    `;

    // Format output akhir
    const outputContent = `
/**
~ Kode di-obfuscate Advanced Obf
~ Telegram: t.me/zoxzex
~ Js Crackers

© zoxzex
 */
(function () {
  const obfuscated = "${escapedCode}";
  eval(obfuscated);

  // Jalankan bagian yang diencode Base64
  ${decodeRuntime}
})();
    `;

    // Simpan file hasil
    fs.writeFileSync(outputFile, outputContent);

    const endTime = new Date();
    console.log(chalk.green(">> Proses selesai!"));
    console.log(chalk.yellow(`File disimpan di: ${outputFile}`));
    console.log(`Durasi proses: ${(endTime - startTime) / 1000} detik`);
  } catch (err) {
    console.error(chalk.red(">> Error dalam proses JS Dead (Enc Dead):"), err);
  }
}

// JS Base 64
const confuserBase64 = async (inputFile, outputFile) => {
  const startTime = new Date();

  try {
    console.log(chalk.blue(">> Memulai proses JS Base 64 (Enc Base64)..."));
    const data = fs.readFileSync(inputFile, "utf8");

    // Obfuscasi kode menggunakan jsconfuser
    const encrypted = await jsconfuser.obfuscate(data, {
      compact: true,
      controlFlowFlattening: true,
      deadCode: true,
      dispatcher: true,
      duplicateLiteralsRemoval: true,
      es5: true,
      flatten: true,
      globalConcealing: true,
      renameVariables: true,
      renameGlobals: true,
      opaquePredicates: true,
      target: "node",
      stringEncoding: true,
      stringConcealing: true,
      stringCompression: true,
      lock: {
        antiDebug: true,
        integrity: true,
        selfDefending: true,
      },
    });

    // Encode hasil obfuscasi ke Base64 (untuk memastikan "mati total")
    const base64Encoded = Buffer.from(encrypted).toString("base64");

    // Format output agar benar-benar mati
    const outputContent = `
/**
~ Kode di-obfuscate dengan Zox
~ Telegram: t.me/zoxzex

© zoxzex
 */
(function () {
  const encryptedCode = "${base64Encoded}";
  const decodedCode = Buffer.from(encryptedCode, "base64").toString("utf8");
  eval(decodedCode);
})();
    `;

    // Simpan file hasil
    fs.writeFileSync(outputFile, outputContent);

    const endTime = new Date();
    console.log(chalk.green(">> Proses selesai!"));
    console.log(chalk.yellow(`File disimpan di: ${outputFile}`));
    console.log(`Durasi proses: ${(endTime - startTime) / 1000} detik`);
  } catch (err) {
    console.error(chalk.red(">> Error dalam proses JS Base 64 (Enc Base64):"), err);
  }
};

// JS CONFUSER Vip
const confuserDec = async (inputFile, outputFile) => {
  const startTime = new Date();
  try {
    const data = fs.readFileSync(inputFile, "utf8");
    const encrypted = await jsconfuser.obfuscate(data, {
  calculator: 0,
  compact: 0,
  controlFlowFlattening: 0,
  deadCode: 0,
  dispatcher: 0,
  duplicateLiteralsRemoval: 0,
  es5: 0,
  flatten: 0,
  globalConcealing: 0,
  hexadecimalNumbers: 0,
  lock: {
    antiDebug: 0,
    integrity: 0,
    selfDefending: 0
  },
  minify: 0,
  movedDeclarations: 0,
  objectExtraction: 0,
  opaquePredicates: 0,
  renameGlobals: 0,
  renameVariables: 0,
  shuffle: {
    hash: 0,
    true: 0
  },
  stack: 0,
  stringCompression: 0,
  stringConcealing: 0,
  stringEncoding: 0,
  stringSplitting: 0,
  target: "node"
      });
const outputContent = `
/**
~ Kode di-obfuscate dengan Zox
~ Telegram: t.me/zoxzex

© zoxzex
 */

    `;
    fs.writeFileSync(outputFile, encrypted);
    showProcessInfo("Dec File (JS)", inputFile, startTime, outputFile);
  } catch (err) {
    console.error(chalk.red(">> Error dalam proses Dec File (JS)"), err);
  }
};


// Fungsi untuk menangani pilihan menu
const processMenuChoice = async (choice) => {
  const inputFile = await selectInputFile();

  const { outputFile } = await prompt({
    type: "input",
    name: "outputFile",
    message: "Masukkan nama file output:",
    default: `processed_${inputFile}`,
  });

  switch (choice) {
    case "1. JS Confuser (ENC Low)":
      await confuserLow(inputFile, outputFile);
      break;
    case "2. JS Confuser (ENC Medium)":
      await confuserMedium(inputFile, outputFile);
      break;
    case "3. JS Confuser (ENC High)":
      await confuserHigh(inputFile, outputFile);
      break;
      case "4. JS Confuser (ENC Hard)":
      await confuserHard(inputFile, outputFile);
      break;
      case "5. JS Confuser (ENC Extreme Name 1)":
      await confuserXname1(inputFile, outputFile);
      break;
      case "6. JS Confuser (ENC Extreme Name 2)":
      await confuserXname2(inputFile, outputFile);
      break;
      case "7. JS Confuser (ENC Extreme Name 3)":
      await confuserXname3(inputFile, outputFile);
      break;
      case "8. JS Confuser (ENC Var)":
      await confuserVar(inputFile, outputFile);
      break;
      case "9. JS Confuser (ENC Vip)":
      await confuserVip(inputFile, outputFile);
      break;
      case "10. JS Obfuscation (ENC Low)":
      await obfuscatorLow(inputFile, outputFile);
      break;
      case "11. JS Obfuscation (ENC Medium)":
      await obfuscatorMedium(inputFile, outputFile);
      break;
      case "12. JS Obfuscation (ENC High)":
      await obfuscatorHigh(inputFile, outputFile);
      break;
      case "13. JS Obfuscation (ENC NaN)":
      await obfuscatorNaN(inputFile, outputFile);
      break;
      case "14. JS Obfuscation (ENC Hard)":
      await obfuscatorHard(inputFile, outputFile);
      break;
      case "15. JS Dead (Enc Dead)":
      await confuserDead(inputFile, outputFile);
      break;
      case "16. JS Base 64 (Enc Base64)":
      await confuserBase64(inputFile, outputFile);
      break;
      case "100. Dec File (JS)":
      await confuserDec(inputFile, outputFile);
      break;
    case "99. Dekripsi File (DEC)":
      decryptFile(inputFile, outputFile);
      break;
    default:
      console.log(chalk.red("Pilihan tidak valid!"));
  }
};

// Fungsi untuk menu utama 🗿
const mainMenu = async () => {
  const isLoggedIn = await loginPrompt();

  if (!isLoggedIn) return;

  let exit = false;

  while (!exit) {
    const { choice } = await prompt([
      {
        type: "list",
        name: "choice",
        message: "Di Buat Oleh Zox 🗿\nDi Test² Dulu Eror apa Kagak\nMaklum Kalo Eror Namanya Juga Free\nMoga Membantu 🗿\nTerimakasih Telah Menggunakan Enc Kami\nUntuk Dec Agak Ampas\nMau No Enc? 100% Enak aja\n\nPilih Jenis Enkripsi Nya:",
        pageSize: 40,
        choices: [
          "1. JS Confuser (ENC Low)",
          "2. JS Confuser (ENC Medium)",
          "3. JS Confuser (ENC High)",
          "4. JS Confuser (ENC Hard)",
          "5. JS Confuser (ENC Extreme Name 1)",
          "6. JS Confuser (ENC Extreme Name 2)",
          "7. JS Confuser (ENC Extreme Name 3)",
          "8. JS Confuser (ENC Var)",
          "9. JS Confuser (ENC Vip)",
          "--------------------------------------------------------",
          "10. JS Obfuscation (ENC Low)",
          "11. JS Obfuscation (ENC Medium)",
          "12. JS Obfuscation (ENC High)",
          "13. JS Obfuscation (ENC NaN)",
          "14. JS Obfuscation (ENC Hard)",
          "------------------------NEW ENC-------------------------",
          "VITUR 2 INI GK SEMUA JS BISA YA 🗿",
          "15. JS Dead (Enc Dead)",
          "16. JS Base 64 (Enc Base64)",
          "99. Dekripsi File (DEC)",
          "100. Dec File (JS)",
          "Keluar",
        ],
      },
    ]);

    if (choice === "Keluar") {
      console.log(chalk.bgYellow.black("Keluar..."));
      exit = true;
    } else {
      await processMenuChoice(choice);
    }
  }
};

// Jalankan menu utama
mainMenu();