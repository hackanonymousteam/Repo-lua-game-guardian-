import os
from yt_dlp import YoutubeDL

def download_pinterest_video(video_url, save_path='output/'):
    if not os.path.exists(save_path):
        os.makedirs(save_path)

    ydl_opts = {
        'outtmpl': os.path.join(save_path, '%(title)s.%(ext)s'),
        'format': 'best',
    }

    try:
        with YoutubeDL(ydl_opts) as ydl:
            ydl.download([video_url])
        print("[+] Video Pinterest telah disimpan dalam folder output/")

    except Exception as e:
        print(f"[!] Error: {str(e)}")


def main():
    video_url = input("Masukkan URL Pinterest: ")

    print("\nPilih opsi unduh:")
    print("1. Unduh Video dari Pinterest")

    choice = input("Pilih opsi (1): ")

    if choice == "1":
        download_pinterest_video(video_url)
    else:
        print("[!] Pilihan tidak valid. Silakan pilih 1.")


if __name__ == "__main__":
    main()