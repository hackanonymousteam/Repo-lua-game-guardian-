import requests
import os

def openai_chat(prompt):
    url = "https://chateverywhere.app/api/chat/"
    data = {
        "model": {
            "id": "gpt-4",
            "name": "GPT-4",
            "maxLength": 32000,
            "tokenLimit": 80000000,
            "completionTokenLimit": 50000000,
            "deploymentName": "gpt-4"
        },
        "messages": [
            {
                "pluginId": None,
                "content": prompt,
                "role": "user"
            }
        ],
        "prompt": "",
        "temperature": 0.5
    }
    headers = {
        "Accept": "/*/",
        "User-Agent": "Mozilla/5.0"
    }

    try:
        response = requests.post(url, json=data, headers=headers)

        if response.headers.get("Content-Type", "").startswith("application/json"):
            result = response.json()
            return result["response"]["content"] if "response" in result else "AI tidak dapat memberikan jawaban."
        else:
            return response.text.strip()
    except requests.exceptions.RequestException as e:
        return f"Terjadi kesalahan saat menghubungi API: {e}"

def print_in_border(text, width=60):
    lines = []
    words = text.split()
    line = ""


    for word in words:
        if len(line) + len(word) + 1 > width:
            lines.append(line)
            line = word
        else:
            if line:
                line += " "
            line += word
    if line:
        lines.append(line)

    os.system("clear")
    print("+" + "-" * (width + 2) + "+")
    for line in lines:
        print("| " + line.ljust(width) + " |")
    print("+" + "-" * (width + 2) + "+")

def main():
    print("=== AI Chat ===")
    print("Ketik 'exit' untuk keluar.\n")
    
    while True:
        user_input = input("Anda: ")
        if user_input.lower() == "exit":
            print("Keluar dari AI Chat.")
            break

        response = openai_chat(user_input)

        print_in_border(response, width=60)

if __name__ == "__main__":
    main()