import os
from yt_dlp import YoutubeDL

def download_tiktok_audio(video_url, save_path='output/'):
    if not os.path.exists(save_path):
        os.makedirs(save_path)

    ydl_opts = {
        'outtmpl': os.path.join(save_path, '%(title)s.%(ext)s'),
        'format': 'bestaudio/best',
        'ffmpeg_location': '/data/data/com.termux/files/usr/bin/ffmpeg',  # Path ffmpeg di Termux
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
    }

    try:
        with YoutubeDL(ydl_opts) as ydl:
            ydl.download([video_url])
        print("[+] Audio telah disimpan dalam format MP3 di folder output/")

    except Exception as e:
        print(f"[!] Error saat mengunduh audio: {str(e)}")


def download_tiktok_video(video_url, save_path='output/'):
    if not os.path.exists(save_path):
        os.makedirs(save_path)

    ydl_opts = {
        'outtmpl': os.path.join(save_path, '%(title)s.%(ext)s'),
        'format': 'best',
        'ffmpeg_location': '/data/data/com.termux/files/usr/bin/ffmpeg',  # Path ffmpeg di Termux
    }

    try:
        with YoutubeDL(ydl_opts) as ydl:
            ydl.download([video_url])
        print("[+] Video telah disimpan dalam format MP4 di folder output/")

    except Exception as e:
        print(f"[!] Error saat mengunduh video: {str(e)}")


def main():
    video_url = input("Masukkan URL TikTok: ")

    print("\nPilih opsi unduh:")
    print("1. Unduh Audio (MP3)")
    print("2. Unduh Video (MP4)")

    choice = input("Pilih opsi (1/2): ")

    if choice == "1":
        download_tiktok_audio(video_url)
    elif choice == "2":
        download_tiktok_video(video_url)
    else:
        print("[!] Pilihan tidak valid. Silakan pilih 1 atau 2.")


if __name__ == "__main__":
    main()