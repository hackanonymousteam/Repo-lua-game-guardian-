def count_statistics(text):
    """Menghitung statistik dari teks."""
    words = len(text.split())
    characters = len(text)
    characters_with_spaces = len(text.replace(" ", ""))
    paragraphs = len(text.split("\n"))
    return words, characters, characters_with_spaces, paragraphs


def from_file(file_name):
    """Menghitung statistik dari file."""
    try:
        with open(file_name, 'r', encoding='utf-8') as file:
            text = file.read()
        return text
    except FileNotFoundError:
        print(f"File '{file_name}' tidak ditemukan.")
        return None


def main():
    print("Pilihan:")
    print("1. Baca dari file")
    print("2. Ketik teks langsung")
    choice = input("Masukkan pilihan (1/2): ").strip()

    if choice == "1":
        file_name = input("Masukkan nama file (contoh: halo.txt): ").strip()
        text = from_file(file_name)
        if text is None:
            return
    elif choice == "2":
        print("Ketik teks di bawah ini (ketik 'SELESAI' untuk mengakhiri):")
        lines = []
        while True:
            line = input()
            if line.strip().upper() == "SELESAI":
                break
            lines.append(line)
        text = "\n".join(lines)
    else:
        print("Pilihan tidak valid.")
        return

    words, characters, characters_with_spaces, paragraphs = count_statistics(text)
    print("\nHasil Statistik:")
    print(f"Kata (Words): {words}")
    print(f"Karakter (Characters): {characters}")
    print(f"Karakter (tanpa spasi): {characters_with_spaces}")
    print(f"Paragraf (Paragraphs): {paragraphs}")


if __name__ == "__main__":
    main()