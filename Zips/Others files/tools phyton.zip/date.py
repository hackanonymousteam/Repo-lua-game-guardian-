import requests
from bs4 import BeautifulSoup
from pytube import YouTube
import os

def search_youtube(query):
    """Mencari video di YouTube berdasarkan kata kunci."""
    print(f"\nMencari video untuk kata kunci: {query}")
    search_url = f"https://m.youtube.com/results?search_query={query.replace(' ', '+')}"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }

    response = requests.get(search_url, headers=headers)
    if response.status_code != 200:
        print("Gagal mengakses YouTube. Pastikan Anda terhubung ke internet.")
        return None

    soup = BeautifulSoup(response.text, "html.parser")
    video_links = []
    
    for video in soup.find_all("a", {"class": "yt-simple-endpoint inline-block style-scope ytd-thumbnail"}):
        video_url = video.get("href")
        if video_url and "/watch?v=" in video_url:
            video_links.append(f"https://www.youtube.com{video_url}")
    
    return video_links[:2]  # Ambil 2 link video pertama


def download_video(video_url, save_folder):
    """Download video dari YouTube menggunakan pytube."""
    try:
        yt = YouTube(video_url)
        print(f"Mendownload: {yt.title}")
        stream = yt.streams.filter(progressive=True, file_extension="mp4").first()
        if not stream:
            print("Stream tidak ditemukan untuk video ini.")
            return

        # Unduh dan simpan video
        stream.download(save_folder)
        print(f"Video berhasil didownload dan disimpan di: {save_folder}")
    except Exception as e:
        print(f"Terjadi kesalahan saat mendownload video: {e}")


def main():
    save_folder = "downloads"  # Folder default untuk menyimpan video
    os.makedirs(save_folder, exist_ok=True)  # Buat folder jika belum ada

    while True:
        print("\n=== YouTube Search & Downloader ===")
        print("1. Cari dan download video dari YouTube")
        print("2. Keluar")
        choice = input("Pilih menu (1/2): ")

        if choice == "1":
            query = input("Masukkan kata kunci pencarian: ")
            video_links = search_youtube(query)

            if video_links:
                print("\nLink video yang ditemukan:")
                for i, link in enumerate(video_links, 1):
                    print(f"{i}. {link}")

                # Download video pertama dan kedua (jika ada)
                for i, video_url in enumerate(video_links, 1):
                    print(f"\nMendownload video {i}: {video_url}")
                    download_video(video_url, save_folder)
            else:
                print("Tidak ada hasil yang ditemukan.")
        elif choice == "2":
            print("Keluar dari program.")
            break
        else:
            print("Pilihan tidak valid!")


if __name__ == "__main__":
    main()