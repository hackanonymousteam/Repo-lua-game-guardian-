import requests
from bs4 import BeautifulSoup
from colorama import Fore, Style, init

# Inisialisasi Colorama
init(autoreset=True)

def get_hero_info(hero_name):
    # Format nama hero agar sesuai URL (mengganti spasi dengan garis bawah)
    formatted_name = hero_name.replace(" ", "_")
    url = f"https://mobile-legends.fandom.com/wiki/{formatted_name}"  # MLBB Fandom Hero URL
    headers = {"User-Agent": "Mozilla/5.0"}
    
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")
        
        # Scrape informasi utama hero
        title = soup.find("h1", {"class": "page-header__title"}).text.strip()
        hero_info = soup.find("aside", {"class": "portable-infobox"})
        
        if hero_info:
            details = {}
            for row in hero_info.find_all("div", {"class": "pi-item"}):
                label = row.find("h3")
                value = row.find("div")
                if label and value:
                    details[label.text.strip()] = value.text.strip()
            
            print(f"\n{Fore.BLUE}Informasi Hero: {Fore.YELLOW}{title}{Style.RESET_ALL}")
            print(f"{Fore.GREEN}{'=' * 50}")
            for key, value in details.items():
                print(f"{Fore.CYAN}{key}: {Fore.MAGENTA}{value}")
            print(f"{Fore.GREEN}{'=' * 50}")
        else:
            print(f"{Fore.RED}Detail hero tidak ditemukan di halaman ini.")
    except Exception as e:
        print(f"{Fore.RED}Error: {e}")
        print(f"{Fore.RED}Pastikan nama hero benar atau periksa koneksi internet Anda.")

def main():
    print(f"{Fore.CYAN}=== MLBB Hero Scraper ===")
    while True:
        hero_name = input(f"\n{Fore.YELLOW}Masukkan Nama Hero (atau ketik 'x' untuk keluar): {Style.RESET_ALL}").strip()
        if hero_name.lower() == "x":
            print(f"{Fore.RED}Keluar dari program. Sampai jumpa!")
            break
        elif hero_name:
            print(f"\n{Fore.BLUE}Mencari informasi untuk hero '{hero_name}'...{Style.RESET_ALL}")
            get_hero_info(hero_name)
        else:
            print(f"{Fore.RED}Nama hero tidak boleh kosong. Coba lagi!")

if __name__ == "__main__":
    main()