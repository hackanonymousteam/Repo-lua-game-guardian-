import base64
import os

# Fungsi untuk encode file ke Base64
def encode_file(file_name):
    try:
        # Membaca isi file
        with open(file_name, "rb") as file:
            file_data = file.read()
            encoded_data = base64.b64encode(file_data).decode('utf-8')

        # Menyimpan hasil encode
        output_file = file_name + ".b64"
        with open(output_file, "w") as encoded_file:
            encoded_file.write(encoded_data)
        print(f"File berhasil di-encode dan disimpan sebagai: {output_file}")
    except FileNotFoundError:
        print("File tidak ditemukan. Pastikan nama file benar.")
    except Exception as e:
        print(f"Terjadi kesalahan: {e}")

# Fungsi untuk decode Base64 ke file asli
def decode_file(encoded_file_name):
    try:
        # Membaca file Base64
        with open(encoded_file_name, "r") as file:
            encoded_data = file.read()
            decoded_data = base64.b64decode(encoded_data.encode('utf-8'))

        # Menyimpan hasil decode
        original_file = encoded_file_name.replace(".b64", "")
        with open(original_file, "wb") as decoded_file:
            decoded_file.write(decoded_data)
        print(f"File berhasil di-decode dan disimpan sebagai: {original_file}")
    except FileNotFoundError:
        print("File tidak ditemukan. Pastikan nama file benar.")
    except Exception as e:
        print(f"Terjadi kesalahan: {e}")

# Menu utama
def main():
    print("=== Base64 Encode/Decode Tool ===")
    print("1. Encode file ke Base64")
    print("2. Decode file Base64 ke file asli")
    choice = input("Pilih opsi (1/2): ")

    if choice == "1":
        file_name = input("Masukkan nama file yang ingin di-encode (contoh: file.js): ")
        encode_file(file_name)
    elif choice == "2":
        encoded_file_name = input("Masukkan nama file Base64 (.b64) yang ingin di-decode: ")
        decode_file(encoded_file_name)
    else:
        print("Pilihan tidak valid.")

if __name__ == "__main__":
    main()