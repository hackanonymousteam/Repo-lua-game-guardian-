import requests
from bs4 import BeautifulSoup

def search_game_mod(game_name):
    base_url = "https://an1.com/games/"
    search_url = f"{base_url}?q={game_name.replace(' ', '+')}"

    try:
        # Mengirim request ke an1.com
        response = requests.get(search_url, headers={"User-Agent": "Mozilla/5.0"})
        
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, "html.parser")

            # Mengambil tautan dari hasil pencarian
            result = soup.find_all("a", href=True)

            mod_links = []
            for link in result:
                href = link.get('href')
                if href and "apk" in href and "an1.com" in href:
                    mod_links.append(f"{base_url}{href}")

            if mod_links:
                print(f"[INFO] Game MOD {game_name} ditemukan di an1.com:")
                for i, mod in enumerate(mod_links):
                    print(f"{i + 1}. {mod}")

            else:
                print("[ERROR] Tidak ditemukan game MOD di an1.com.")

        else:
            print(f"[ERROR] Tidak dapat mengakses an1.com, status {response.status_code}")

    except requests.RequestException as err:
        print(f"[ERROR] Terjadi kesalahan saat mencari game: {str(err)}")

if __name__ == "__main__":
    game_name = input("Masukkan nama game yang ingin dicari di an1.com (MOD): ")
    search_game_mod(game_name)