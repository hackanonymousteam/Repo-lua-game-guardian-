import random
import curses
from colorama import Fore, Style

def clear_screen():
    print("\033[H\033[J", end="")  # Clear screen

def tebak_angka():
    print(f"{Fore.BLUE}🎮 Game Tebak Angka 🎮")
    angka_rahasia = random.randint(1, 20)
    kesempatan = 5

    for i in range(1, kesempatan + 1):
        try:
            tebakan = int(input(f"[{i}/{kesempatan}] Masukkan tebakan Anda (1-20): "))
        except ValueError:
            print(f"{Fore.BLUE}❌ Input tidak valid! Masukkan angka.")
            continue

        if tebakan == angka_rahasia:
            print(f"🎉 Selamat! Anda menebak angka {angka_rahasia} dengan benar!")
            return
        elif tebakan < angka_rahasia:
            print(f"{Fore.BLUE}📉 Terlalu kecil!")
        else:
            print(f"{Fore.BLUE}📈 Terlalu besar!")

    print(f"❌ Anda kehabisan kesempatan! Angka yang benar adalah {angka_rahasia}.\n")

def tebak_bendera():
    print(f"{Fore.BLUE}🎮 Game Tebak Bendera 🎮")
    bendera = {
        "Indonesia": "🇮🇩",
        "Amerika": "🇺🇸",
        "Jepang": "🇯🇵",
        "India": "🇮🇳",
        "Brazil": "🇧🇷",
        "Australia": "🇦🇺",
        "China": "🇨🇳",
        "Rusia": "🇷🇺",
        "Perancis": "🇫🇷",
        "Italia": "🇮🇹"
    }

    negara, emoji = random.choice(list(bendera.items()))
    kesempatan = 5

    print(f"Petunjuk: {emoji}")
    for i in range(1, kesempatan + 1):
        tebakan = input(f"[{i}/{kesempatan}] Tebak nama negara: ").capitalize()

        if tebakan == negara:
            print(f"🎉 Benar! Bendera ini adalah milik {negara}.\n")
            return
        else:
            print(f"{Fore.BLUE}❌ Salah! Coba lagi.")

    print(f"❌ Anda gagal! Jawaban yang benar adalah {negara}.\n")

def tic_tac_toe():
    print(f"{Fore.BLUE}🎮 Game Tic Tac Toe (vs Bot) 🎮")

    board = [str(i + 1) for i in range(9)]

    def display_board():
        print("\n")
        for i in range(3):
            print(f" {board[i*3]} | {board[i*3+1]} | {board[i*3+2]} ")
            if i < 2:
                print(f"{Fore.BLUE}---|---|---")
        print("\n")

    def player_move():
        while True:
            try:
                move = int(input("Pilih kotak (1-9): ")) - 1
                if board[move].isdigit():
                    board[move] = "X"
                    break
                else:
                    print(f"{Fore.BLUE}❌ Kotak sudah diisi!")
            except (ValueError, IndexError):
                print(f"{Fore.BLUE}❌ Masukkan angka antara 1-9 yang valid!")

    def bot_move():
        available_moves = [i for i, spot in enumerate(board) if spot.isdigit()]
        move = random.choice(available_moves)
        board[move] = "O"

    def check_winner(symbol):
        win_positions = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8],
            [0, 3, 6], [1, 4, 7], [2, 5, 8],
            [0, 4, 8], [2, 4, 6]
        ]
        return any(all(board[pos] == symbol for pos in win) for win in win_positions)

    while any(spot.isdigit() for spot in board):
        display_board()
        player_move()

        if check_winner("X"):
            display_board()
            print(f"{Fore.BLUE}🎉 Anda menang!")
            return

        if not any(spot.isdigit() for spot in board):
            break

        bot_move()

        if check_winner("O"):
            display_board()
            print(f"{Fore.BLUE}💻 Bot menang!")
            return

    display_board()
    print(f"{Fore.BLUE}😐 Seri!")

def snake_game():
    print(f"{Fore.BLUE}🎮 Game Snake 🎮")
    curses.wrapper(play_snake)

def play_snake(stdscr):
    curses.curs_set(0)
    stdscr.nodelay(1)
    stdscr.timeout(100)

    sh, sw = stdscr.getmaxyx()
    w = curses.newwin(sh, sw, 0, 0)
    w.keypad(1)
    w.timeout(100)

    snake_x = sw//4
    snake_y = sh//2
    snake = [
        [snake_y, snake_x],
        [snake_y, snake_x-1],
        [snake_y, snake_x-2]
    ]
    food = [sh//2, sw//2]
    w.addch(food[0], food[1], curses.ACS_PI)

    key = curses.KEY_RIGHT
    score = 0

    while True:
        next_key = w.getch()
        key = key if next_key == -1 else next_key

        if snake[0][0] in [0, sh] or \
           snake[0][1] in [0, sw] or \
           snake[0] in snake[1:]:
            w.clear()
            w.addstr(sh//2, sw//2-5, "GAME OVER")
            w.refresh()
            w.getch()
            return

        new_head = [snake[0][0], snake[0][1]]

        if key == curses.KEY_DOWN:
            new_head[0] += 1
        if key == curses.KEY_UP:
            new_head[0] -= 1
        if key == curses.KEY_LEFT:
            new_head[1] -= 1
        if key == curses.KEY_RIGHT:
            new_head[1] += 1

        snake.insert(0, new_head)

        if snake[0] == food:
            score += 1
            food = None
            while food is None:
                nf = [random.randint(1, sh-1), random.randint(1, sw-1)]
                food = nf if nf not in snake else None
            w.addch(food[0], food[1], curses.ACS_PI)
        else:
            tail = snake.pop()
            w.addch(tail[0], tail[1], ' ')

        w.addch(snake[0][0], snake[0][1], curses.ACS_CKBOARD)

def main_menu():
    while True:
        clear_screen()
        print(f"{Fore.BLUE}🎮 PILIH GAME 🎮")
        print(f"{Fore.BLUE}1. Tebak Angka (1-20)")
        print(f"{Fore.BLUE}2. Tebak Huruf (A-Z)")
        print(f"{Fore.BLUE}3. Tebak Bendera")
        print(f"{Fore.BLUE}4. Tic Tac Toe (vs Bot)")
        print(f"{Fore.BLUE}5. Snake Game (Nokia)")
        print(f"{Fore.BLUE}0. Keluar")

        pilihan = input("Pilih menu: ")

        if pilihan == "1":
            tebak_angka()
        elif pilihan == "2":
            tebak_huruf()
        elif pilihan == "3":
            tebak_bendera()
        elif pilihan == "4":
            tic_tac_toe()
        elif pilihan == "5":
            snake_game()
        elif pilihan == "0":
            print(f"{Fore.BLUE}Sampai jumpa!")
            break
        else:
            print(f"{Fore.BLUE}❌ Pilihan tidak valid!")

if __name__ == "__main__":
    main_menu()