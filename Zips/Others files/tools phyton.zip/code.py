MORSE_CODE_DICT = {
    'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 'F': '..-.',
    'G': '--.', 'H': '....', 'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..',
    'M': '--', 'N': '-.', 'O': '---', 'P': '.--.', 'Q': '--.-', 'R': '.-.',
    'S': '...', 'T': '-', 'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-',
    'Y': '-.--', 'Z': '--..', '1': '.----', '2': '..---', '3': '...--',
    '4': '....-', '5': '.....', '6': '-....', '7': '--...', '8': '---..',
    '9': '----.', '0': '-----', ',': '--..--', '.': '.-.-.-', '?': '..--..',
    '/': '-..-.', '-': '-....-', '(': '-.--.', ')': '-.--.-', '&': '.-...',
    ':': '---...', ';': '-.-.-.', '=': '-...-', '+': '.-.-.', '_': '..--.-',
    '"': '.-..-.', '$': '...-..-', '!': '-.-.--', '@': '.--.-.', ' ': '|'
}

# Encode text to Morse code
def encode_to_morse(text):
    return ' '.join(MORSE_CODE_DICT.get(char.upper(), '') for char in text)

# Decode Morse code to text
def decode_from_morse(morse):
    reversed_dict = {value: key for key, value in MORSE_CODE_DICT.items()}
    return ''.join(reversed_dict.get(code, '') for code in morse.split())

def main():
    print("Pilihan Menu:")
    print("1. Encode (Text ke Morse)")
    print("2. Decode (Morse ke Text)")
    print("3. Keluar")
    
    choice = input("Pilih opsi (1/2/3): ")

    if choice == "1":
        input_option = input("Masukkan teks langsung (Ketik '1') atau dari file (Ketik '2'): ")
        if input_option == "1":
            text = input("Masukkan teks untuk diubah ke kode Morse: ")
        elif input_option == "2":
            input_file = input("Masukkan nama file input (misalnya input.txt): ")
            try:
                with open(input_file, 'r') as file:
                    text = file.read()
            except FileNotFoundError:
                print("File input tidak ditemukan.")
                return
        else:
            print("Pilihan tidak valid.")
            return

        morse_code = encode_to_morse(text)
        output_choice = input("Simpan ke file (Ketik '1') atau tampilkan di terminal (Ketik '2'): ")
        if output_choice == "1":
            output_file = input("Masukkan nama file output (misalnya output.txt): ")
            with open(output_file, 'w') as file:
                file.write(morse_code)
            print(f"Hasil disimpan di {output_file}.")
        elif output_choice == "2":
            print("Hasil Morse Code:")
            print(morse_code)
        else:
            print("Pilihan tidak valid.")

    elif choice == "2":
        input_option = input("Masukkan kode Morse langsung (Ketik '1') atau dari file (Ketik '2'): ")
        if input_option == "1":
            morse = input("Masukkan kode Morse untuk diubah ke teks: ")
        elif input_option == "2":
            input_file = input("Masukkan nama file input (misalnya input.txt): ")
            try:
                with open(input_file, 'r') as file:
                    morse = file.read()
            except FileNotFoundError:
                print("File input tidak ditemukan.")
                return
        else:
            print("Pilihan tidak valid.")
            return

        text = decode_from_morse(morse)
        output_choice = input("Simpan ke file (Ketik '1') atau tampilkan di terminal (Ketik '2'): ")
        if output_choice == "1":
            output_file = input("Masukkan nama file output (misalnya output.txt): ")
            with open(output_file, 'w') as file:
                file.write(text)
            print(f"Hasil disimpan di {output_file}.")
        elif output_choice == "2":
            print("Hasil Teks:")
            print(text)
        else:
            print("Pilihan tidak valid.")

    elif choice == "3":
        print("Keluar dari program...")
    else:
        print("Pilihan tidak valid.")

if __name__ == "__main__":
    main()