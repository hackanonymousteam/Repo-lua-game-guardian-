import os
import subprocess
from yt_dlp import YoutubeDL

# Fungsi mengunduh MP3 dari video YouTube
def download_youtube_mp3(url):
    try:
        # Mengatur opsi yt_dlp untuk hanya mengunduh audio MP3
        ydl_opts = {
            'format': 'bestaudio/best',
            'outtmpl': 'downloads/%(title)s.%(ext)s',
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'mp3',
                'preferredquality': '192',
            }]
        }

        if not os.path.exists('downloads'):
            os.makedirs('downloads')

        # Menggunakan yt_dlp untuk mengunduh audio
        with YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])

        print(f"[✓] MP3 berhasil diunduh ke folder 'downloads'")

    except Exception as e:
        print(f"[!] Error saat mengunduh MP3: {str(e)}")


def main():
    video_url = input("Masukkan URL Video YouTube: ")
    download_youtube_mp3(video_url)


if __name__ == "__main__":
    main()