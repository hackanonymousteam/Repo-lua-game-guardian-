import requests

def get_public_ip():
    try:
        response = requests.get("https://api.ipify.org?format=json")
        response.raise_for_status()
        data = response.json()
        print(f"IP Publik Anda: {data['ip']}")
    except requests.RequestException as e:
        print(f"Gagal mendapatkan IP publik: {e}")

    input("\nTekan Enter untuk kembali ke menu utama...")

def main():
    get_public_ip()

if __name__ == "__main__":
    main()