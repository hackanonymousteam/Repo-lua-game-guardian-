import subprocess

def git_clone():
    # Meminta URL repository Git dari pengguna
    repo_url = input("Masukkan URL repository Git (misalnya https://github.com/user/repo.git): ")
    
    # Meminta nama folder tempat repositori akan disalin
    destination_folder = input("Masukkan nama folder tujuan (misalnya nama_folder): ")

    try:
        # Menjalankan perintah git clone
        print(f"Meng-clone repositori dari {repo_url} ke folder {destination_folder}...")
        subprocess.run(["git", "clone", repo_url, destination_folder], check=True)
        print(f"Repositori berhasil di-clone ke folder {destination_folder}.")
    except subprocess.CalledProcessError:
        print("Terjadi kesalahan saat melakukan git clone.")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    git_clone()