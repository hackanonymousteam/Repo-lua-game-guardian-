import requests
from bs4 import BeautifulSoup

def get_youtube_description(video_url):
    try:
        # Mengambil HTML dari link video YouTube
        response = requests.get(video_url)
        if response.status_code == 200:
            html_content = response.text

            # Menggunakan BeautifulSoup untuk parsing HTML
            soup = BeautifulSoup(html_content, "html.parser")

            # Mengambil elemen deskripsi dari YouTube
            description_tag = soup.find("meta", {"name": "description"})
            
            if description_tag:
                description = description_tag.get("content", "Deskripsi tidak ditemukan.")

                # Merapikan deskripsi agar lebih rapi di dalam file
                formatted_description = f"{'-'*30}\n"
                formatted_description += f"{'Video Deskripsi':^60}\n"
                formatted_description += f"{'-'*30}\n\n"
                formatted_description += f"{description}\n"
                formatted_description += f"{'-'*60}\n"

                filename = "youtube_description.txt"
                with open(filename, "w", encoding="utf-8") as f:
                    f.write(formatted_description)

                print(f"[✅ Deskripsi berhasil disimpan dalam {filename}]")
            
            else:
                print("[⚠️ Deskripsi tidak ditemukan! Video mungkin tidak memiliki deskripsi.]")

        else:
            print("[⚠️ Gagal mengambil data dari YouTube! Server error.")

    except requests.RequestException as e:
        print(f"[❌ Kesalahan: {str(e)}]")

# Meminta input link dari pengguna
video_url = input("[🔹 Masukkan Link Video YouTube: ")
get_youtube_description(video_url)