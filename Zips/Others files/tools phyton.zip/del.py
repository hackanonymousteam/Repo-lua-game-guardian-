import os

# Fungsi untuk menghapus file berdasarkan tipe
def delete_file():
    while True:
        print("\nPilih tipe penghapusan file:")
        print("1. Hapus file dengan ekstensi '.bak'")
        print("2. Hapus file berdasarkan nama")
        print("3. Keluar")
        
        choice = input("\nMasukkan pilihan (1/2/3): ")
        
        if choice == '1':
            # Hapus file dengan ekstensi .bak
            file_name = input("Masukkan nama file yang ingin dihapus (misalnya date.py.bak): ")
            
            if file_name.endswith(".bak"):
                try:
                    os.remove(file_name)
                    print(f"File {file_name} berhasil dihapus.")
                except FileNotFoundError:
                    print(f"File {file_name} tidak ditemukan.")
                except Exception as e:
                    print(f"Terjadi kesalahan: {e}")
            else:
                print("File yang dimasukkan bukan ekstensi .bak.")
        
        elif choice == '2':
            # Hapus file berdasarkan nama
            file_name = input("Masukkan nama file yang ingin dihapus: ")
            
            try:
                os.remove(file_name)
                print(f"File {file_name} berhasil dihapus.")
            except FileNotFoundError:
                print(f"File {file_name} tidak ditemukan.")
            except Exception as e:
                print(f"Terjadi kesalahan: {e}")
        
        elif choice == '3':
            print("Keluar dari program.")
            break
        
        else:
            print("Pilihan tidak valid. Silakan coba lagi.")

# Panggil fungsi
delete_file()