import speedtest

def test_kecepatan():
    st = speedtest.Speedtest()

    # Memilih server terbaik secara otomatis berdasarkan ping
    st.get_best_server()

    # Mengukur kecepatan download, upload, dan ping
    download_speed = st.download() / 1_000_000  # dalam Mbps
    upload_speed = st.upload() / 1_000_000      # dalam Mbps
    ping_val = st.results.ping                # dalam milidetik (ms)

    print("\n🏅 Hasil Test Kecepatan Jaringan 🏅")
    print(f"- Download Speed: {download_speed:.2f} Mbps")
    print(f"- Upload Speed: {upload_speed:.2f} Mbps")
    print(f"- Ping: {ping_val:.2f} ms\n")

def main():
    try:
        print("[+] Menguji Kecepatan Jaringan...")
        test_kecepatan()

    except Exception as ex:
        print("[⚠️] Error saat mengecek kecepatan:", ex)

if __name__ == '__main__':
    main()