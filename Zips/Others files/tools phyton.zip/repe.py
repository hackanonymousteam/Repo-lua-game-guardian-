import os

def save_to_file(text, content):
    # Membuat folder 'hasil' jika tidak ada
    if not os.path.exists("hasil"):
        os.makedirs("hasil")
    
    # Menulis hasil ke dalam file repeat.txt
    with open("hasil/repeat.txt", "w") as file:
        file.write(content)

    print("\nHasil pengulangan disimpan di hasil/repeat.txt")

def text_repeat():
    while True:
        print("\nMenu:")
        print("1. Ulangi teks")
        print("2. Keluar")

        choice = input("\nPilih opsi: ")

        if choice == "1":
            text = input("\nMasukkan teks yang ingin diulang: ")
            repeat = input("Masukkan jumlah pengulangan (ketik '0' untuk tanpa batas): ")

            try:
                repeat = int(repeat)

                if repeat == 0:
                    print("\nPengulangan tanpa batas! Tekan Ctrl+C untuk berhenti.\n")
                    content = ""

                    try:
                        count = 0
                        while True:
                            count += 1
                            line = f"{count}: {text}\n"
                            content += line

                    except KeyboardInterrupt:
                        save_to_file(text, content)

                elif repeat > 0:
                    content = ""

                    for i in range(repeat):
                        line = f"{i+1}: {text}\n"
                        content += line

                    save_to_file(text, content)

                else:
                    print("\nJumlah pengulangan tidak valid. Silakan masukkan angka positif atau 0 untuk tanpa batas.")

            except ValueError:
                print("\nHarap masukkan angka yang valid untuk jumlah pengulangan.")

        elif choice == "2":
            print("\nKeluar dari tools.")
            break

        else:
            print("\nPilihan tidak valid! Silakan coba lagi.")

# Menjalankan tools
text_repeat()