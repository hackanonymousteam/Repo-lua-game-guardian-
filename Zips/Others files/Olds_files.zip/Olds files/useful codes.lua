
function ARM(arm,ret)
gg.setVisible(false)
local addr_list = gg.getRangesList('libc.so')
local addr
for _, v in ipairs(addr_list) do
if v.type:sub(2, 2) == 'w' then
addr = {address = v.start, flags = gg.TYPE_DWORD}
break
end
end
if not addr then gg.alert("Failed","") return end
local function update_arm()
local addr_num = tonumber('', 16)
local num = tonumber(arm:match('0[xX](%x+)'), 16)
end
local old = gg.getValues({addr})
addr.value = '~A ' .. arm
pcall(gg.setValues, {addr})
local Result  = gg.getValues({addr})[1].value & 0xFFFFFFFF
gg.setValues(old)
Result  = string.unpack('>I4', string.pack('<I4', Result ))
Result  = string.format('%08X', Result )
if ret == "BX LR" then Result = Result.."1EFF2FE1" end
return "h"..Result
end



function repeatValues(values, count)
	local repeated = {}
	local valuesCount = #values
	for i = 1, count do
	    table.insert(repeated, values[(i - 1) % valuesCount + 1])
	end
	return repeated
end

function editValues(addresses, values, valueType)
	local edits = {}
	for i, address in ipairs(addresses) do
	    table.insert(edits, {address = address, flags = valueType, value = values[i]})
	end
	gg.setValues(edits)
end

function getAddresses(a)
	local addresses = {}
	for i, v in ipairs(a) do
	    table.insert(addresses, v.address)
	end
	return addresses
end

function Searchvalue(a1, a2, a3)
Check_Visible()
gg.clearResults()
gg.setRanges(a1)
gg.searchNumber(a3, a2)
a4 = gg.getResults(gg.getResultsCount())
return a4
end

function LoadResults(a)
	gg.loadResults(a[1])
	local results = gg.getResults(gg.getResultsCount())
	gg.editAll(a[2], results[1].flags)
	gg.clearResults()
	return results
end

function Refinenumber(ReValue)
gg.refineNumber(ReValue[1], ReValue[2])
Tablet = gg.getResults(gg.getResultsCount())
return Tablet
end

function TamPxScriptRun(a1, a2, a3)
	local tt = {}
	tt[1] = {}
	tt[1].address = a1
	tt[1].flags = a2
	tt[1].value = a3
	gg.setValues(tt)
	return tt
end

function RestoreValues(revert)
	if revert ~= nil then
		gg.setValues(revert)
	end
end

function CheckStateChange(oldState, newState, Number)
	for i = Number[1], Number[2] do
		if oldState[i] ~= newState[i] then
			return true
		end
	end
	return false
end

