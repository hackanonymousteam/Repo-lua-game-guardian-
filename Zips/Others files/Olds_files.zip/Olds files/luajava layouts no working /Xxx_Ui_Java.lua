local imports = {
    "android.view.*",
    "android.widget.*",
    "android.graphics.*",
    "android.graphics.drawable.GradientDrawable",
    "android.view.MotionEvent",
    "java.lang.Thread",     
    "android.os.Build",
    "android.graphics.PorterDuff",
    "java.lang.System",     
    "java.lang.Runnable",   
    "android.graphics.Typeface",
    "android.animation.Animator",
    "android.animation.AnimatorListenerAdapter",
    "android.animation.ValueAnimator",
    "android.content.Context",
    "android.graphics.drawable.GradientDrawable",
    "android.os.Handler",
    "android.widget.FrameLayout",
    "android.widget.TextView",
    "android.view.animation.AccelerateDecelerateInterpolator",
    "android.view.animation.AccelerateInterpolator",
    "android.view.animation.DecelerateInterpolator",
    "android.app.*",
    "android.content.*",
    "android.os.*",
    "java.io.*",
    "java.util.*",
}

for _, lib in ipairs(imports) do
    import(lib)
end

local Gravity = luajava.bindClass("android.view.Gravity")
local PixelFormat = luajava.bindClass("android.graphics.PixelFormat")
local Build = luajava.bindClass("android.os.Build")
local WindowManager = luajava.bindClass("android.view.WindowManager")
local View = luajava.bindClass("android.view.View")
local Color = luajava.bindClass("android.graphics.Color")
local PorterDuffMode = luajava.bindClass("android.graphics.PorterDuff$Mode") 
local RelativeLayout = luajava.bindClass("android.widget.RelativeLayout") 
local LinearLayout = luajava.bindClass("android.widget.LinearLayout")
local Thread = luajava.bindClass("java.lang.Thread")  
local System = luajava.bindClass("java.lang.System")  
local Typeface = luajava.bindClass("android.graphics.Typeface")
local File = luajava.bindClass("java.io.File")
local FileInputStream = luajava.bindClass("java.io.FileInputStream")
local FileOutputStream = luajava.bindClass("java.io.FileOutputStream")
local ZipEntry = luajava.bindClass("java.util.zip.ZipEntry")
local ZipInputStream = luajava.bindClass("java.util.zip.ZipInputStream")
local IOException = luajava.bindClass("java.io.IOException")
local ActivityManager = luajava.bindClass("android.app.ActivityManager")
local Context = luajava.bindClass("android.content.Context")
local Debug = luajava.bindClass("android.os.Debug")

toast.setGravity(Gravity.BOTTOM)
toast.setMode(1)
local context = activity
local window = context.getSystemService("window")

local DEEP_PURPLE = 0xFF6A0DAD
local ELECTRIC_BLUE = 0xFF00D4FF
local NEON_PINK = 0xFFFF00FF
local DARK_PURPLE = 0xFF2D0042
local LIGHT_PURPLE = 0xFF9D4EDD
local WHITE = 0xFFFFFFFF
local GRAY = 0xFFCCCCCC
local DARK_GRAY = 0xFF303030
local TRANSPARENT_BLACK = 0xCC000000

local link_font = "https://github.com/google/fonts/raw/main/ofl/russoone/RussoOne-Regular.ttf"
local link_image = "https://iili.io/"

local activeThreads = {}

local function activateMod(name)
    toast.show(name .. " activated!", 2000)
end

local function deactivateMod(name)
    toast.show(name .. " deactivated!", 2000)
end

local function getProcessMemoryUsage(pid)
    local memoryUsage = {
        pss = "N/A",
        uss = "N/A", 
        privateDirty = "N/A",
        total = "N/A"
    }
    
    pcall(function()
        local activityManager = context.getSystemService(Context.ACTIVITY_SERVICE)
        local pids = { tonumber(pid) }
        local memoryStats = activityManager.getProcessMemoryInfo(pids)
        
        if memoryStats and #memoryStats > 0 then
            local memInfo = memoryStats[1]
            memoryUsage.pss = tostring(math.floor(memInfo.getTotalPss() / 1024)) .. " MB"
            memoryUsage.uss = tostring(math.floor(memInfo.getTotalPrivateDirty() / 1024)) .. " MB"
            memoryUsage.privateDirty = tostring(math.floor(memInfo.getTotalPrivateDirty() / 1024)) .. " MB"
            memoryUsage.total = tostring(math.floor(memInfo.getTotalPss() / 1024)) .. " MB"
        end
    end)
    
    return memoryUsage
end

local function getProcessDetailedInfo(pid, processName)
    local info = {
        memory = "N/A",
        status = "N/A",
        threads = "N/A",
        importance = "N/A",
        architecture = "32-bit"
    }
    
    pcall(function()
        local activityManager = context.getSystemService(Context.ACTIVITY_SERVICE)
        
        local pids = { tonumber(pid) }
        local memoryStats = activityManager.getProcessMemoryInfo(pids)
        
        if memoryStats and #memoryStats > 0 then
            local memInfo = memoryStats[1]
            info.memory = tostring(math.floor(memInfo.getTotalPss() / 1024)) .. " MB"
        end
        
        local runningApps = activityManager.getRunningAppProcesses()
        for i = 0, runningApps.size() - 1 do
            local app = runningApps.get(i)
            if tostring(app.pid) == pid then
                info.importance = tostring(app.importance)
                
                if processName:find("64") or processName:find("x64") or processName:find("64bit") then
                    info.architecture = "64-bit"
                else
                    info.architecture = "32-bit"
                end
                break
            end
        end
    end)
    
    return info
end

local function listAllRunningProcessesWithMemory()
    local activityManager = context.getSystemService(Context.ACTIVITY_SERVICE)
    if not activityManager then 
        return {} 
    end
    
    local runningProcesses = activityManager.getRunningAppProcesses()
    if not runningProcesses or runningProcesses.size() == 0 then 
        return {} 
    end
    
    local allProcesses = {}
    local totalMemoryUsed = 0
    
    for i = 0, runningProcesses.size() - 1 do
        local process = runningProcesses.get(i)
        local processName = process.processName or "Unknown"
        local pid = tostring(process.pid)
        local uid = tostring(process.uid)
        
        local detailedInfo = getProcessDetailedInfo(pid, processName)
        local memoryUsage = getProcessMemoryUsage(pid)
        
        if memoryUsage.total ~= "N/A" then
            totalMemoryUsed = totalMemoryUsed + (tonumber(string.match(memoryUsage.total, "(%d+)")) or 0)
        end
        
        table.insert(allProcesses, {
            name = processName,
            pid = pid,
            uid = uid,
            memory = memoryUsage.total,
            memoryDetailed = memoryUsage,
            importance = detailedInfo.importance,
            architecture = detailedInfo.architecture,
            index = i + 1
        })
    end
    
    return allProcesses, runningProcesses.size(), totalMemoryUsed
end

local function selectProcess(processName)
    local success, result = pcall(function()
        gg.setProcess(processName)
        return true
    end)
    
    if success then
        toast.show("Process selected: " .. processName, 2000)
        return true
    else
        toast.show("Error: " .. processName, 2000)
        return false
    end
end
local FONT_URL = link_font
local FONT_FILENAME = "russoone.ttf"

local IMAGE_SOURCES = {
    img_icon_youtube = { url = link_image.."f9KFCp2.png", filename = "logo_yt.png" },
    img_icon_telegram = { url = link_image.."f9K3Lqg.png", filename = "logo_tg.png" },
    img_icon_instagram = { url = link_image.."f9KFuEu.png", filename = "logo_ig.png" },
}

local cache_dir = gg.EXT_CACHE_DIR
if string.sub(cache_dir, -1) ~= "/" then
    cache_dir = cache_dir .. "/"
end

local path_youtube = cache_dir .. IMAGE_SOURCES.img_icon_youtube.filename
local path_telegram = cache_dir .. IMAGE_SOURCES.img_icon_telegram.filename
local path_instagram = cache_dir .. IMAGE_SOURCES.img_icon_instagram.filename
local FONT_PATH = cache_dir .. FONT_FILENAME 

local isFPSLow = false 

local function getShapeBackground(color, radius)
    local drawable = luajava.new(GradientDrawable)
    drawable.setShape(GradientDrawable.RECTANGLE)
    drawable.setColor(color)
    drawable.setCornerRadius(radius)
    return drawable
end

local function getBorderBackground(bgColor, borderColor, borderWidth, radius, isTopCorners)
    local drawable = luajava.new(GradientDrawable)
    drawable.setShape(GradientDrawable.RECTANGLE)
    drawable.setColor(bgColor)
    drawable.setStroke(borderWidth, borderColor) 
    if isTopCorners then
        drawable.setCornerRadii({radius, radius, radius, radius, 0, 0, 0, 0})
    else
        drawable.setCornerRadius(radius)
    end
    return drawable
end

local function getLayoutParams()
    local LayoutParams = WindowManager.LayoutParams
    local layoutParams = luajava.new(LayoutParams)
    layoutParams.type = (Build.VERSION.SDK_INT >= 26) and LayoutParams.TYPE_APPLICATION_OVERLAY or LayoutParams.TYPE_PHONE
    layoutParams.format = PixelFormat.RGBA_8888
    layoutParams.flags = LayoutParams.FLAG_NOT_FOCUSABLE
    layoutParams.gravity = Gravity.TOP | Gravity.LEFT
    layoutParams.width = LayoutParams.WRAP_CONTENT
    layoutParams.height = LayoutParams.WRAP_CONTENT
    return layoutParams
end

local function CustomToggleLayout(id, text, defaultState, customTypeface)
    _G[id .. "_state"] = defaultState or false
    return {
        LinearLayout;
        layout_width = "match_parent";
        layout_height = "wrap_content";
        layout_margin = "2dp";
        padding = "7dp";
        orientation = "horizontal";
        gravity = "center_vertical";
        {
            TextView;
            text = text;
            textColor = WHITE; 
            textSize = "16sp";
            layout_weight = 1;
            typeface = customTypeface; 
        };
        {
            RelativeLayout;
            id = id .. "_track_container";
            layout_width = "60dp";
            layout_height = "30dp";
            layout_gravity = Gravity.CENTER_VERTICAL;
            layout_marginLeft = "10dp";
            
            {
                TextView;
                id = id;
                layout_width = "26dp";
                layout_height = "26dp"; 
                layout_centerVertical = true;
                layout_margin = "2dp";
            };
        }
    }
end

local function create_tab_button(id, text, customTypeface)
    return {
        Button;
        id = id;
        text = text;
        textSize = "14sp";
        textColor = WHITE; 
        background = getShapeBackground(TRANSPARENT_BLACK, 0);
        layout_weight = 1;
        layout_height = "40dp";
        typeface = customTypeface; 
    }
end

local function create_exit_button(id, text, extra_params, customTypeface)
    local button_layout = {
        Button;
        id = id;
        text = text;
        textSize = "16sp";
        textColor = WHITE;
        background = getBorderBackground(0x00000000, ELECTRIC_BLUE, 3, 15); 
        layout_width = "match_parent";
        layout_height = "50dp";
        typeface = customTypeface; 
    }
    if extra_params then
        for k_extra, v_extra in pairs(extra_params) do
            button_layout[k_extra] = v_extra
        end
    end
    return button_layout
end 

local function create_social_icon_with_text(id_image, id_text, color, text_label, image_path_src, customTypeface)
    return {
        LinearLayout;
        id = "ll_" .. id_text; 
        layout_width = "wrap_content";
        layout_height = "wrap_content";
        orientation = "vertical";
        gravity = "center_horizontal";
        layout_marginLeft = "5dp";
        layout_marginRight = "5dp";
        
        {
            ImageView;
            id = id_image;
            layout_width = "50dp";
            layout_height = "50dp";
            src = image_path_src; 
            background = getShapeBackground(DARK_PURPLE, 50); 
            layout_marginBottom = "10dp";
            layout_marginLeft = "4dp";
            scaleType = "fitCenter";
        };
        
        {
            TextView;
            id = id_text;
            text = text_label;
            textColor = WHITE; 
            textSize = "12sp";
            layout_marginBottom = "10dp";
            typeface = customTypeface; 
        };
    }
end

local function create_process_item(process, index, customTypeface)
    local packageManager = context.getPackageManager()
    local appIcon = nil
    
    pcall(function()
        local appInfo = packageManager.getApplicationInfo(process.name, 0)
        if appInfo then
            appIcon = appInfo.loadIcon(packageManager)
        end
    end)
    
    return {
        LinearLayout;
        id = "process_item_" .. index;
        layout_width = "match_parent";
        layout_height = "wrap_content";
        orientation = "horizontal";
        gravity = "center_vertical";
        padding = "8dp";
        background = getShapeBackground(DARK_PURPLE, 8);
        layout_margin = "2dp";
        
        {
            ImageView;
            layout_width = "32dp";
            layout_height = "32dp";
            background = getShapeBackground(ELECTRIC_BLUE, 16);
            scaleType = "fitCenter";
            id = "process_icon_" .. index;
        };
        
        {
            LinearLayout;
            layout_width = "0dp";
            layout_height = "wrap_content";
            layout_weight = 1;
            orientation = "vertical";
            paddingLeft = "10dp";
            
            {
                TextView;
                text = string.sub(process.name, 1, 25);
                textColor = WHITE;
                textSize = "12sp";
                typeface = customTypeface;
                id = "process_name_" .. index;
            };
            
            {
                TextView;
                text = "PID: " .. process.pid .. " | " .. process.architecture;
                textColor = GRAY;
                textSize = "10sp";
                id = "process_pid_" .. index;
            };
        };
        
        {
            TextView;
            text = process.memory;
            textColor = LIGHT_PURPLE;
            textSize = "11sp";
            typeface = customTypeface;
            gravity = Gravity.RIGHT;
            id = "process_memory_" .. index;
        };
    }
end

local function create_resize_handle(customTypeface)
    return {
        LinearLayout;
        id = "resize_handle";
        layout_width = "match_parent";
        layout_height = "40dp";
        visibility = "gone";
        orientation = "horizontal";
        gravity = "center";
        background = getShapeBackground(DARK_PURPLE, 0);
        
        {
            TextView;
            text = "⇲ Drag here to resize window"; 
            textColor = ELECTRIC_BLUE;
            textSize = "14sp";
            gravity = "center";
            typeface = customTypeface;
        };
    }
end

local isMenuOpen = false
local current_tab = "mod_tab"

local function select_tab(tab_id)
    if mod_tab_content and util_tab_content and info_tab_content and process_tab_content
    and mod_tab_button and util_tab_button and info_tab_button and process_tab_button then
        
        mod_tab_content.setVisibility(View.GONE)
        util_tab_content.setVisibility(View.GONE)
        info_tab_content.setVisibility(View.GONE)
        process_tab_content.setVisibility(View.GONE)
        
        mod_tab_button.setBackgroundDrawable(getShapeBackground(0x00000000, 0))
        util_tab_button.setBackgroundDrawable(getShapeBackground(0x00000000, 0))
        info_tab_button.setBackgroundDrawable(getShapeBackground(0x00000000, 0))
        process_tab_button.setBackgroundDrawable(getShapeBackground(0x00000000, 0))
        
        local border_drawable = luajava.new(GradientDrawable)
        border_drawable.setColor(0x00000000)
        border_drawable.setStroke(3, ELECTRIC_BLUE) 
        
        if tab_id == "mod_tab" then
            mod_tab_content.setVisibility(View.VISIBLE)
            mod_tab_button.setBackgroundDrawable(border_drawable)
        elseif tab_id == "util_tab" then
            util_tab_content.setVisibility(View.VISIBLE)
            util_tab_button.setBackgroundDrawable(border_drawable)
        elseif tab_id == "process_tab" then
            process_tab_content.setVisibility(View.VISIBLE)
            process_tab_button.setBackgroundDrawable(border_drawable)
            updateProcessList()
        elseif tab_id == "info_tab" then
            info_tab_content.setVisibility(View.VISIBLE)
            info_tab_button.setBackgroundDrawable(border_drawable)
        end
        current_tab = tab_id
    end
end

local function setToggleColor(tv_thumb, isChecked)
    local density = context.getResources().getDisplayMetrics().density or 1.0
    local trackContainer = tv_thumb.getParent()
    local trackBgColor
    local thumbBgColor
    
    if isChecked then
        trackBgColor = NEON_PINK
        thumbBgColor = ELECTRIC_BLUE 
    else
        trackBgColor = NEON_PINK
        thumbBgColor = GRAY
    end
    
    trackContainer.setBackgroundDrawable(getShapeBackground(trackBgColor, 15 * density))
    tv_thumb.setBackgroundDrawable(getShapeBackground(thumbBgColor, 15))

    local movement_dp = 30
    local newX = isChecked and (movement_dp * density) or 0
    
    tv_thumb.setTranslationX(newX)
end

local function updateProcessList()
    local thread = luajava.new(Thread, function()
        local allProcesses, totalCount, totalMemoryUsed = listAllRunningProcessesWithMemory()
        
        context.runOnUiThread(function()
            local processContainer = _G["process_list_container"]
            if not processContainer then return end
            
            processContainer.removeAllViews()
            
            table.sort(allProcesses, function(a, b)
                local memA = tonumber(string.match(a.memory or "0", "(%d+)")) or 0
                local memB = tonumber(string.match(b.memory or "0", "(%d+)")) or 0
                return memA > memB
            end)
            
            local headerLayout = {
                LinearLayout;
                layout_width = "match_parent";
                layout_height = "wrap_content";
                orientation = "vertical";
                padding = "10dp";
                background = getShapeBackground(0xFF1A0033, 8);
                layout_margin = "5dp";
                
                {
                    TextView;
                    text = "Total Processes: " .. totalCount;
                    textColor = ELECTRIC_BLUE;
                    textSize = "12sp";
                    gravity = Gravity.CENTER;
                };
                {
                    TextView;
                    text = "Total Memory: " .. totalMemoryUsed .. " MB";
                    textColor = LIGHT_PURPLE;
                    textSize = "12sp";
                    gravity = Gravity.CENTER;
                };
            }
            
            local headerView = loadlayout(headerLayout)
            processContainer.addView(headerView)
            
            for i, process in ipairs(allProcesses) do
                if i <= 15 then
                    local processView = loadlayout(create_process_item(process, i, customTypeface))
                    
                    processView.onClick = function()
                        selectProcess(process.name)
                    end
                    
                    processContainer.addView(processView)
                end
            end
            
            if #allProcesses > 15 then
                local footerLayout = {
                    TextView;
                    text = "... and " .. (#allProcesses - 15) .. " more processes";
                    textColor = GRAY;
                    textSize = "11sp";
                    gravity = Gravity.CENTER;
                    layout_margin = "10dp";
                }
                
                local footerView = loadlayout(footerLayout)
                processContainer.addView(footerView)
            end
        end)
    end)
    table.insert(activeThreads, thread)
    thread.start()
end

local function createLayout(customTypeface)
    return {
        LinearLayout;
        id = "main_window";
        layout_width = "350dp";
        layout_height = "wrap_content";
        background = getBorderBackground(DARK_PURPLE, ELECTRIC_BLUE, 3, 15); 
        orientation = "vertical";
        padding = "1dp"; 
        
        {
            LinearLayout;
            id = "touch_handler";
            layout_width = "match_parent";
            layout_height = "wrap_content";
            orientation = "horizontal";
            gravity = "center_vertical";
            padding = "5dp";
            background = getBorderBackground(DEEP_PURPLE, ELECTRIC_BLUE, 3, 15, true);
            
            {
                TextView;
                id = "btn_toggle_menu";
                text = "▼"; 
                textColor = WHITE; 
                textSize = "20sp";
                gravity = "center";
                layout_width = "40dp";
                layout_height = "40dp";
                background = getShapeBackground(0x00000000, 20);
                padding = "2dp";
                layout_marginRight = "5dp";
                typeface = customTypeface; 
            };

            {
                TextView;
                id = "txt_title"; 
                text = "Neon | Ui ";
                textSize = "16sp";
                textColor = WHITE;
                gravity = Gravity.LEFT | Gravity.CENTER_VERTICAL;
                layout_weight = 1;
                layout_width = "0dp";
                layout_marginLeft = "10dp"; 
                typeface = customTypeface; 
            };
            
            {
                TextView;
                id = "txt_fps_counter"; 
                text = "FPS: Loading"; 
                visibility = "gone";
                textStyle = "bold"; 
                textSize = "14sp";
                textColor = ELECTRIC_BLUE; 
                gravity = Gravity.RIGHT | Gravity.CENTER_VERTICAL;
                layout_width = "wrap_content";
                layout_height = "wrap_content";
                padding = "1dp";
                layout_marginRight = "15dp";
            };
        };
        
      create_resize_handle(customTypeface),
        
        {
            LinearLayout;
            id = "menu_content";
            layout_height = "325dp";
            orientation = "vertical";
            layout_width = "match_parent";
            padding = "6dp";
            visibility = "gone";
            
            {
                LinearLayout;
                layout_width = "match_parent";
                layout_height = "wrap_content";
                orientation = "horizontal";
                layout_margin = "10dp 0dp 0dp 0dp"; 
                
                create_tab_button("mod_tab_button", "Game", customTypeface),
                create_tab_button("util_tab_button", "Player", customTypeface), 
                create_tab_button("process_tab_button", "Process", customTypeface),
                create_tab_button("info_tab_button", "Info", customTypeface),
            };
            
            {
                FrameLayout;
                layout_width = "match_parent";
                layout_height = "match_parent";
                
                {
                    LinearLayout; 
                    id = "mod_tab_content";
                    layout_width = "match_parent";
                    layout_height = "match_parent";
                    orientation = "vertical";
                    padding = "5dp";

                    {
                        ScrollView; 
                        layout_width = "match_parent";
                        layout_height = "0dp";      
                        layout_weight = 1;          
                        
                        {
                            LinearLayout;
                            layout_height = "wrap_content";
                            orientation = "vertical";
                            layout_width = "match_parent";
                            padding = "5dp";
                            
                            table.unpack({
                                CustomToggleLayout("switch_mod1", "Modification 1", false, customTypeface),
                                CustomToggleLayout("switch_mod2", "Modification 2", false, customTypeface),
                                CustomToggleLayout("switch_mod3", "Modification 3", false, customTypeface),
                            });
                        };
                    };
                };
                
                {
                    LinearLayout; 
                    id = "util_tab_content";
                    layout_width = "match_parent";
                    layout_height = "match_parent";
                    orientation = "vertical"; 
                    padding = "5dp"; 
                    visibility = "gone";

                    {
                        ScrollView; 
                        layout_width = "match_parent";
                        layout_height = "0dp"; 
                        layout_weight = 1; 

                        {
                            LinearLayout;
                            layout_width = "match_parent";
                            layout_height = "wrap_content";
                            orientation = "vertical";
                            padding = "5dp"; 
                            
                            table.unpack({
                                CustomToggleLayout("switch_util1", "Utility 1", false, customTypeface),
                                CustomToggleLayout("switch_util2", "Utility 2", false, customTypeface),
                            });
                        };
                    };
                };
                
                {
                    LinearLayout; 
                    id = "process_tab_content";
                    layout_width = "match_parent";
                    layout_height = "match_parent";
                    orientation = "vertical"; 
                    padding = "5dp"; 
                    visibility = "gone";

                    {
                        ScrollView; 
                        layout_width = "match_parent";
                        layout_height = "0dp"; 
                        layout_weight = 1; 

                        {
                            LinearLayout;
                            id = "process_list_container";
                            layout_width = "match_parent";
                            layout_height = "wrap_content";
                            orientation = "vertical";
                            padding = "5dp"; 
                        };
                    };
                    
                    {
                        LinearLayout;
                        layout_width = "match_parent";
                        layout_height = "wrap_content";
                        orientation = "horizontal";
                        padding = "5dp";
                        
                        {
                            Button;
                            id = "btn_refresh_processes";
                            text = "Refresh";
                            textSize = "14sp";
                            textColor = WHITE;
                            background = getBorderBackground(DARK_PURPLE, ELECTRIC_BLUE, 2, 8);
                            layout_weight = 1;
                            layout_height = "40dp";
                            layout_marginRight = "5dp";
                            typeface = customTypeface;
                        };
                        
                        {
                            Button;
                            id = "btn_current_process";
                            text = "Current";
                            textSize = "14sp";
                            textColor = WHITE;
                            background = getBorderBackground(DARK_PURPLE, LIGHT_PURPLE, 2, 8);
                            layout_weight = 1;
                            layout_height = "40dp";
                            layout_marginLeft = "5dp";
                            typeface = customTypeface;
                        };
                    };
                };
                
                {
                    RelativeLayout;
                    id = "info_tab_content";
                    layout_width = "match_parent";
                    layout_height = "match_parent";
                    visibility = "gone"; 
                    padding = "10dp";

                    
                    
                    {
                        ScrollView; 
                        id = "info_scroll_view";
                        layout_width = "match_parent";
                        layout_height = "match_parent";
                        layout_above = "btn_exit_info";
                        layout_marginBottom = "10dp";

                        {
                            LinearLayout;
                            layout_width = "match_parent";
                            layout_height = "wrap_content";
                            orientation = "vertical";
                            gravity = "center_horizontal";



                            {
                                LinearLayout;
                                layout_width = "wrap_content";
                                layout_height = "wrap_content";
                                orientation = "horizontal";
                                layout_marginTop = "1dp";
                                layout_marginBottom = "20dp"; 
                                gravity = "center";
                                
                                create_social_icon_with_text("img_icon_youtube", "txt_youtube", 0xFFFF0000, "YouTube", path_youtube, customTypeface), 
                                create_social_icon_with_text("img_icon_telegram", "txt_telegram", 0xFF0088CC, "Telegram", path_telegram, customTypeface), 
                                create_social_icon_with_text("img_icon_instagram", "txt_instagram", 0xFFD62976, "Instagram", path_instagram, customTypeface), 
                                
           
                            };
                            
                            
                            {
                                LinearLayout;
                                layout_width = "wrap_content";
                                layout_height = "wrap_content";
                                orientation = "horizontal";
                                layout_marginTop = "1dp";
                                layout_marginBottom = "20dp"; 
                                gravity = "center";
                                
create_exit_button("btn_exit_info", "Exit Script"),
     
                     };
                        };
                    };
                };
            };
        };
    }
end

local function download_file_if_needed(url, filename)
    local full_path = cache_dir .. filename
    if file.exists(full_path) then return full_path end
    local success = file.download(url, full_path)
    if success and file.exists(full_path) then return full_path else return nil end
end

local thread_download = luajava.new(Thread, function()
    for id, source in pairs(IMAGE_SOURCES) do
        download_file_if_needed(source.url, source.filename)
    end
    download_file_if_needed(FONT_URL, FONT_FILENAME)
end)

local mainLayoutParams = getLayoutParams()
local mainView = nil

local function toggleMenu()
    if isMenuOpen then
        menu_content.setVisibility(View.GONE)
        btn_toggle_menu.setText("▼") 
        isMenuOpen = false
    else
        menu_content.setVisibility(View.VISIBLE)
        btn_toggle_menu.setText("▲") 
        select_tab(current_tab)
        isMenuOpen = true
    end
end

local function removeFloatingView()
    if mainView then
        window.removeView(mainView)
        mainView = nil
        toast.show("UI removed successfully", 2000)
    end
end

local function exitScript()
    removeFloatingView()
    gg.exit() 
end

local function startFPScounter()
    local UPDATE_INTERVAL = 1.0   
    local lastTime = os.clock()
    local frameCount = 0
    local textViewFPS = txt_fps_counter 
    
    local fps_thread = luajava.new(Thread, function()
        while true do
            frameCount = frameCount + 1
            local currentTime = os.clock()
            local elapsedTime = currentTime - lastTime
            
            if elapsedTime >= UPDATE_INTERVAL then
                local estimatedFPS = frameCount / elapsedTime
                local wholeFPS = math.floor(estimatedFPS) 
                local fpsMessage = "FPS: " .. string.format("%d", wholeFPS) 
                
                isFPSLow = (wholeFPS <= 30)

                context.runOnUiThread(function()
                    if textViewFPS then
                        textViewFPS.setText(fpsMessage)
                    end
                end)
                
                frameCount = 0
                lastTime = currentTime
            end
            Thread.sleep(20) 
        end
    end)
    table.insert(activeThreads, fps_thread)
    fps_thread.start()
end

local function startBlinkingTitle()
    local COLOR_1 = WHITE      
    local COLOR_2 = ELECTRIC_BLUE  
    local DELAY_MS = 500       
    local isColor1 = true
    
    local title_thread = luajava.new(Thread, function()
        local textViewTitle = txt_title 
        while true do
            local nextColor = isColor1 and COLOR_2 or COLOR_1
            isColor1 = not isColor1
            context.runOnUiThread(function()
                if textViewTitle then
                    textViewTitle.setTextColor(nextColor)
                end
            end)
            Thread.sleep(DELAY_MS)
        end
    end)
    table.insert(activeThreads, title_thread)
    title_thread.start()
end

local function startFPSBlinker()
    local DELAY_MS = 500       
    local textViewFPS = txt_fps_counter 
    local isColor1 = true 

    local blink_thread = luajava.new(Thread, function()
        while true do
            if isFPSLow then
                local nextColor = isColor1 and NEON_PINK or ELECTRIC_BLUE
                isColor1 = not isColor1
                
                context.runOnUiThread(function()
                    if textViewFPS then
                        textViewFPS.setTextColor(nextColor)
                    end
                end)
            else
                context.runOnUiThread(function()
                    if textViewFPS and textViewFPS.getCurrentTextColor() ~= ELECTRIC_BLUE then
                        textViewFPS.setTextColor(ELECTRIC_BLUE)
                    end
                end)
                isColor1 = true 
            end
            
            Thread.sleep(DELAY_MS) 
        end
    end)
    table.insert(activeThreads, blink_thread)
    blink_thread.start()
end

invoke = function()
    thread_download.start()
    thread_download.join() 
    
    local customTypeface = nil
    if file.exists(FONT_PATH) then
        customTypeface = Typeface.createFromFile(FONT_PATH)
    else
        customTypeface = Typeface.DEFAULT
    end
    
    mainView = loadlayout(createLayout(customTypeface))
    
    current_tab = "mod_tab"

    setToggleColor(switch_mod1, _G["switch_mod1_state"])
    setToggleColor(switch_mod2, _G["switch_mod2_state"])
    setToggleColor(switch_mod3, _G["switch_mod3_state"])
    setToggleColor(switch_util1, _G["switch_util1_state"])
    setToggleColor(switch_util2, _G["switch_util2_state"])

    startFPScounter()
    startBlinkingTitle()
    startFPSBlinker()
    
    mainLayoutParams.x = 50
    mainLayoutParams.y = 100
    window.addView(mainView, mainLayoutParams)

    toggleMenu() 
    
    btn_toggle_menu.onClick = function(v)
        toggleMenu()
    end

    mod_tab_button.onClick = function(v) select_tab("mod_tab") end
    util_tab_button.onClick = function(v) select_tab("util_tab") end
    process_tab_button.onClick = function(v) select_tab("process_tab") end
    info_tab_button.onClick = function(v) select_tab("info_tab") end
    
    local function setupToggleClickHandler(toggle_id, mod_name)
        local tv_thumb = _G[toggle_id]
        tv_thumb.onClick = function(v)
            local newState = not _G[toggle_id .. "_state"]
            _G[toggle_id .. "_state"] = newState
            
            context.runOnUiThread(function()
                setToggleColor(tv_thumb, newState)
            end)
            
            if newState then
                activateMod(mod_name)
            else
                deactivateMod(mod_name)
            end
        end
        
        local tv_track_container = _G[toggle_id .. "_track_container"]
        if tv_track_container then
            tv_track_container.onClick = tv_thumb.onClick 
        end
    end

    setupToggleClickHandler("switch_mod1", "Modification 1")
    setupToggleClickHandler("switch_mod2", "Modification 2")
    setupToggleClickHandler("switch_mod3", "Modification 3")
    setupToggleClickHandler("switch_util1", "Utility 1")
    setupToggleClickHandler("switch_util2", "Utility 2")
    
    btn_exit_info.onClick = function(v)
        exitScript()
    end
    
    btn_refresh_processes.onClick = function(v)
        updateProcessList()
        toast.show("Process list updated", 1000)
    end
    
    btn_current_process.onClick = function(v)
        local currentPackage = gg.getTargetPackage()
        if currentPackage then
            toast.show("Current process: " .. currentPackage, 2000)
        else
            toast.show("No process selected", 2000)
        end
    end
    
    ll_txt_youtube.onClick = function(v)
        local youtube_url = "https://www.youtube.com/" 
        gg.intent(youtube_url)
    end
    
    ll_txt_telegram.onClick = function(v)
        local telegram_url = "https://t.me/" 
        gg.intent(telegram_url)
    end
    
    ll_txt_instagram.onClick = function(v)
        local instagram_url = "https://www.instagram.com/" 
        gg.intent(instagram_url)
    end
    
    local isResizing = false
    local startWidth, startHeight, startX, startY
    
    resize_handle.onTouch = function(v, event)
        local action = event.getAction()
        if action == MotionEvent.ACTION_DOWN then
            isResizing = true
            startWidth = mainView.getWidth()
            startHeight = mainView.getHeight()
            startX = event.getRawX()
            startY = event.getRawY()
            
            mainView.setLayoutParams(luajava.new(WindowManager.LayoutParams, 
                startWidth, startHeight, mainLayoutParams.x, mainLayoutParams.y, 
                mainLayoutParams.type, mainLayoutParams.flags, mainLayoutParams.format))
                
        elseif action == MotionEvent.ACTION_MOVE and isResizing then
            local newWidth = startWidth + (event.getRawX() - startX)
            local newHeight = startHeight + (event.getRawY() - startY)
            
            newWidth = math.max(300, math.min(newWidth, 800))
            newHeight = math.max(200, math.min(newHeight, 600))
            
            mainView.getLayoutParams().width = newWidth
            mainView.getLayoutParams().height = newHeight
            window.updateViewLayout(mainView, mainView.getLayoutParams())
        elseif action == MotionEvent.ACTION_UP then
            isResizing = false
        end
        return true
    end
    
    local RawX, RawY, x, y
    touch_handler.onTouch = function(v, event)
        local action = event.getAction()
        if action == MotionEvent.ACTION_DOWN then
            RawX = event.getRawX()
            RawY = event.getRawY()
            x = mainLayoutParams.x
            y = mainLayoutParams.y
        elseif action == MotionEvent.ACTION_MOVE then
            mainLayoutParams.x = x + (event.getRawX() - RawX)
            mainLayoutParams.y = y + (event.getRawY() - RawY)
            window.updateViewLayout(mainView, mainLayoutParams)
        end
        return true
    end
    
end
gg.setVisible(false)
Lock.Ui(invoke)