import 'android.app.*'
import 'android.os.*'
import 'android.widget.*'
import 'android.view.*'
import 'android.content.*'
import 'java.util.*'
import 'java.lang.*'
import 'android.*'
import 'android.graphics.drawable.*'
import 'android.graphics.PixelFormat'
import 'android.view.animation.Animation'
import 'android.view.animation.AnimationUtils'
import 'android.view.animation.RotateAnimation'
import 'android.animation.ObjectAnimator'
import 'android.view.animation.DecelerateInterpolator'
import 'android.ext.*'
import 'android.view.inputmethod.InputMethodManager'
import 'android.widget.ListView'
import 'android.widget.ArrayAdapter'
import 'android.widget.AdapterView'
import 'android.widget.LinearLayout'
import 'android.widget.EditText'
import 'android.widget.TextView'
import 'android.text.InputType'
import 'android.view.inputmethod.EditorInfo'

context = activity
window = context.getSystemService('window')
local mObjectAnimator
local dObjectAnimator

local startX, startY, endX, endY

function runInBackground(taskFunction, parameter)
    local Runnable = luajava.bindClass("java.lang.Runnable")
    local Thread = luajava.bindClass("java.lang.Thread")
    local runnableProxy = luajava.createProxy("java.lang.Runnable", {
        run = function()
            taskFunction(parameter)
        end
    })
    local threadInstance = luajava.newInstance("java.lang.Thread", runnableProxy)
    threadInstance.start()
end

resourceDirectory = gg.EXT_CACHE_DIR -- Directory that script resources will be stored in

bcVfUi = {
    getResources = function() -- Resources required by the UI are downloaded in this function
  
        if not file.exists(fontDestinationPath) then
            file.download("https://batmangames.simdif.com/images/th/sd_66d8a0bf92ee1.jpg?no_cache=1725473070", resourceDirectory .. "/bclogo.png") -- Downloads the logo icon that is displayed in the upper left of the UI
            end
    end,
    settings = {
    logo = resourceDirectory .. "/bclogo.png",
    
    dialogHeightPortrait = 30, 
    dialogWidthPortrait = 75, 
    dialogWidthLogoPortrait = 12,

    dialogHeightLandscape = 55, 
    dialogWidthLandscape = 45, 
    dialogWidthLogoLandscape = 9,  

       textColorPageHeaders = "0xFFFFC107", 

    textSizePageSwitches = "20sp", 
    textStylePageSwitches = "bold", 
    textColorPageSwitches = "0xFFFFC107", 
    
    dialogColor = "#FF6200EA", 

    pageColors = {
        [1] = "#FF26A69A", 
    },

        dialogHeader = {
            },
    },
    pageData = { 
        [1] = {
                 },
    },
    preLoadLayout = function() 
    end,
    
    populateTab = function(tabNumber, populateType, populateData)
        local index = tabNumber + 1
        
        local cardBackground
        local rightPadding
        local paddingTop
        if bcVfUi.settings.pageColors[tabNumber] then
            cardBackground = bcVfUi.settings.pageColors[tabNumber]
        else
            cardBackground = '#FF808080'
        end
    
        xfc[2][2][3][2][index + 1] = {
            Button,
            id = 'exit_button',
            tag = "tab_button",
            text = "Exit",
            textColor = bcVfUi.settings.textColorTabButtons,
            textSize = bcVfUi.settings.textSizeTabButtons,
            textStyle = bcVfUi.settings.textStyleTabButtons,
            layout_width = 'wrap_content',
            layout_height = 'wrap_content',
            onClick = function(view)
            window.removeView(xfc)
                activity.stopFunc()
                  end
        }
        
        xfc[2][2][3][2][index + 2] = {
            Button,
            id = 'exi_button',
            tag = "tab_button",
            text = "function 1 ",
            textColor = bcVfUi.settings.textColorTabButtons,
            textSize = bcVfUi.settings.textSizeTabButtons,
            textStyle = bcVfUi.settings.textStyleTabButtons,
            layout_width = 'wrap_content',
            layout_height = 'wrap_content',
            onClick = function(view)
            
            -- start function 1 here
            
                  end
        }
        xfc[2][2][3][2][index + 3] = {
            Button,
            id = 'exi_button',
            tag = "tab_button",
            text = "function 2",
            textColor = bcVfUi.settings.textColorTabButtons,
            textSize = bcVfUi.settings.textSizeTabButtons,
            textStyle = bcVfUi.settings.textStyleTabButtons,
            layout_width = 'wrap_content',
            layout_height = 'wrap_content',
            onClick = function(view)
            
            
            -- start function 2 here
            
            
                  end
        }
        
        local config = activity.getResources().getConfiguration()
        local orientation = config.orientation
        local currentWidth
        local currentHeight

        if orientation == 1 then
            currentWidth = bcVfUi.settings.dialogWidthPortrait
        else
            currentWidth = bcVfUi.settings.dialogWidthLandscape
        end

        if orientation == 1 then
            currentHeight = bcVfUi.settings.dialogHeightPortrait
        else
            currentHeight = bcVfUi.settings.dialogHeightLandscape
        end
  end,
    
    onTouchEvent = function(event, doNotClose)
        local action = event.getAction()
        local x = event.getX()
        local y = event.getY()
        if action == MotionEvent.ACTION_DOWN then
            startX, startY = x, y
        elseif action == MotionEvent.ACTION_UP then
            endX, endY = x, y
            local deltaX = endX - startX
            local deltaY = endY - startY
            if math.abs(deltaX) > math.abs(deltaY) then
                bcVfUi.updateAnimations()
                if deltaX > 50 then
                    viewFlipper.setInAnimation(bcVfUi.animations.slideInLeft)
                    viewFlipper.setOutAnimation(bcVfUi.animations.slideOutRight)
                    local currentTab = viewFlipper.getDisplayedChild() + 1
                    local editsPage
                    if currentTab == 1 then
                        editsPage = #bcVfUi.pageData + 1
                    else
                        editsPage = currentTab - 1
                    end
                    if bcVfUi.pageData[editsPage] and bcVfUi.pageData[editsPage].addressTable and bcVfUi.pageData[editsPage].addressTable[1] then
                        runInBackground(_G["bcVfUi"]["updateEditAddresses"], editsPage)
                    end
                    viewFlipper.showPrevious()
                    return true
                elseif deltaX < -50 then
                    viewFlipper.setInAnimation(bcVfUi.animations.slideInRight)
                    viewFlipper.setOutAnimation(bcVfUi.animations.slideOutLeft)
                    local currentTab = viewFlipper.getDisplayedChild() + 1
                    local editsPage
                    if currentTab == #bcVfUi.pageData + 1 then
                        editsPage = 1
                    else
                        editsPage = currentTab + 1
                    end
                    if bcVfUi.pageData[editsPage] and bcVfUi.pageData[editsPage].addressTable and bcVfUi.pageData[editsPage].addressTable[1] then
                        runInBackground(_G["bcVfUi"]["updateEditAddresses"], editsPage)
                    end
                    viewFlipper.showNext()
                    return true
                end
            else
                if deltaY > 50 then
                    return true
                elseif deltaY < -50 then
                    return true
                elseif not doNotClose then
                    bcVfUi.switchViews(xfc, xfq)
                    window.updateViewLayout(xfq, buttonLayoutParams)
                end
            end
        end
    end,
    
    animations = {},
    updateAnimations = function()
        bcVfUi.animations = {}
        local drawDistance = viewFlipper.getWidth()
        bcVfUi.animations.slideInLeft = luajava.newInstance('android.view.animation.TranslateAnimation', -drawDistance, 0, 0, 0)
        bcVfUi.animations.slideInLeft.setDuration(300)
        bcVfUi.animations.slideOutRight = luajava.newInstance('android.view.animation.TranslateAnimation', 0, drawDistance, 0, 0)
        bcVfUi.animations.slideOutRight.setDuration(300)
        bcVfUi.animations.slideInRight = luajava.newInstance('android.view.animation.TranslateAnimation', drawDistance, 0, 0, 0)
        bcVfUi.animations.slideInRight.setDuration(300)
        bcVfUi.animations.slideOutLeft = luajava.newInstance('android.view.animation.TranslateAnimation', 0, -drawDistance, 0, 0)
        bcVfUi.animations.slideOutLeft.setDuration(300)
    end,
    
}

bcVfUi.getResources()

bcVfUi.preLoadLayout()

local config = activity.getResources().getConfiguration()
local orientation = config.orientation

if orientation == 1 then
elseif orientation == 2 then
end

function sparkle_animation(view)
    if (mObjectAnimator == nil) then
        mObjectAnimator = ObjectAnimator.ofFloat(view, 'alpha', 0, 1)
        mObjectAnimator.setDuration(800)
        mObjectAnimator.setInterpolator(DecelerateInterpolator())
    end
end

function zoom_animation(view)
    if (dObjectAnimator == nil) then
        dObjectAnimator = ObjectAnimator.ofFloat(view, 'scaleX', 0, 1)
        dObjectAnimator.setDuration(600)
        dObjectAnimator.setInterpolator(DecelerateInterpolator())
    end
end

function zoom_startanimation()
    dObjectAnimator.start()
end

function sparkle_startanimation()
    mObjectAnimator.start()
end

function getLayoutParams()
    local LayoutParams = WindowManager.LayoutParams
    local layoutParams = luajava.new(LayoutParams)
    
    layoutParams.type = (Build.VERSION.SDK_INT >= 26) and LayoutParams.TYPE_APPLICATION_OVERLAY or LayoutParams.TYPE_PHONE
    layoutParams.format = PixelFormat.RGBA_8888
    layoutParams.flags = bit32.bor(LayoutParams.FLAG_NOT_TOUCH_MODAL, LayoutParams.FLAG_LAYOUT_IN_SCREEN)
    layoutParams.gravity = Gravity.CENTER
    layoutParams.width = LayoutParams.WRAP_CONTENT
    layoutParams.height = LayoutParams.WRAP_CONTENT
    
    return layoutParams
end

function getButtonLayoutParams()
    local LayoutParams = WindowManager.LayoutParams
    local layoutParams = luajava.new(LayoutParams)
    
    layoutParams.type = (Build.VERSION.SDK_INT >= 26) and LayoutParams.TYPE_APPLICATION_OVERLAY or LayoutParams.TYPE_PHONE
    layoutParams.format = PixelFormat.RGBA_8888
    layoutParams.flags = bit32.bor(LayoutParams.FLAG_NOT_TOUCH_MODAL, LayoutParams.FLAG_LAYOUT_IN_SCREEN, LayoutParams.FLAG_NOT_FOCUSABLE)
    layoutParams.gravity = Gravity.CENTER
    layoutParams.width = LayoutParams.WRAP_CONTENT
    layoutParams.height = LayoutParams.WRAP_CONTENT
    
    return layoutParams
end

function getShepeBackground(color, radiu)
    local drawable = luajava.new(GradientDrawable)
    drawable.setShape(GradientDrawable.RECTANGLE)
    drawable.setColor(color)
    drawable.setCornerRadius(radiu) 
    return drawable
end
xfc = {
    CardView,
    radius = '8dp',
    cardElevation = '8dp',
    id = 'touch',
    layout_height = 'fill',
    layout_width = 'fill',
    cardBackgroundColor = bcVfUi.settings.dialogColor,
    {
        LinearLayout,
        id = 'ooo',
        layout_height = bcVfUi.settings.dialogHeight,
        layout_width = bcVfUi.settings.dialogWidth,
        orientation = 'horizontal',
        paddingTop = '10dp',
        paddingBottom = '10dp',
        paddingRight = '10dp',
        {
            LinearLayout,
            layout_width = "wrap_content",
            layout_height = "match_parent",
            orientation = "vertical",
            gravity = "center",
            paddingLeft = '10dp',
            paddingRight = '10dp',
            {
            	
            Button,
            id = 'hide_button',
            tag = "tab_button",
            text = "Hide menu",
            textColor = bcVfUi.settings.textColorTabButtons,
            textSize = bcVfUi.settings.textSizeTabButtons,
            textStyle = bcVfUi.settings.textStyleTabButtons,
            layout_width = 'wrap_content',
            layout_height = 'wrap_content',
            onClick = function(view)
            window.removeView(xfc)
                    window.addView(xfq, buttonLayoutParams)

                  end
        },
            {
                ScrollView,
                layout_height = 'match_parent',
                layout_width = "wrap_content",
                {
                    LinearLayout,
                    layout_width = "wrap_content",
                    layout_height = "match_parent",
                    orientation = "vertical",
                    gravity = "center",
                }
            }
        },
        {
            LinearLayout,
            orientation = "vertical",
            layout_width = "match_parent",
            layout_height = "match_parent",
            {
                LinearLayout,
                orientation = "horizontal",
                layout_width = "match_parent",
                layout_height = "wrap_content",
                
            },
            {
                ViewFlipper,
                id = "viewFlipper",
                layout_width = "match_parent",
                layout_height = "match_parent",
            },
        },
    }
}

local tabCount = 0
repeat
    tabCount = tabCount + 1
    if _G['bcVfUi']['pageData'][tabCount] then
        local pageData = _G['bcVfUi']['pageData'][tabCount]
        local pageType
        if pageData.defaultStates then
            pageType = 'checkbox'
        
        end
        bcVfUi.populateTab(tabCount, pageType, pageData)
    end
until (not _G['bcVfUi']['pageData'][tabCount])

xfq = {
    LinearLayout,
    layout_height = '100dp',
    layout_width = 'fill',
    {
        LinearLayout,
        layout_width = '50dp',
        {
            ImageView,
            layout_width = '50dp',
            src = bcVfUi.settings.logo,
            id = 'suspended_ball',
            layout_height = '50dp'
        }
    }
}

mainLayoutParams = getLayoutParams()
buttonLayoutParams = getButtonLayoutParams()
xfq = loadlayout(xfq)
xfc = loadlayout(xfc)
xfc.post(function()
    bcVfUi.fixButtonText(xfc)
end)

bcVfUi.updateAnimations()
viewFlipper.setInAnimation(bcVfUi.animations.slideInLeft)
viewFlipper.setOutAnimation(bcVfUi.animations.slideOutRight)

function ooo.onTouch(v, event)
    local Action = event.getAction()
    if Action == MotionEvent.ACTION_DOWN then
        isMove = false
        RawX = event.getRawX()
        RawY = event.getRawY()
        x = mainLayoutParams.x
        y = mainLayoutParams.y
    elseif Action == MotionEvent.ACTION_MOVE then
        isMove = true
        mainLayoutParams.x = tonumber(x) + (event.getRawX() - RawX)
        mainLayoutParams.y = tonumber(y) + (event.getRawY() - RawY)
        buttonLayoutParams.x = tonumber(x) + (event.getRawX() - RawX)
        buttonLayoutParams.y = tonumber(y) + (event.getRawY() - RawY)
        window.updateViewLayout(xfc, mainLayoutParams)
        window.updateViewLayout(xfq, buttonLayoutParams)
    end
    bcVfUi.onTouchEvent(event)
end

function suspended_ball.onTouch(v, event)
    local Action = event.getAction()
    if Action == MotionEvent.ACTION_DOWN then
        isMove = false
        RawX = event.getRawX()
        RawY = event.getRawY()
        x = mainLayoutParams.x
        y = mainLayoutParams.y
    elseif Action == MotionEvent.ACTION_MOVE then
        isMove = true
        mainLayoutParams.x = tonumber(x) + (event.getRawX() - RawX)
        mainLayoutParams.y = tonumber(y) + (event.getRawY() - RawY)
        buttonLayoutParams.x = tonumber(x) + (event.getRawX() - RawX)
        buttonLayoutParams.y = tonumber(y) + (event.getRawY() - RawY)
        window.updateViewLayout(xfq, buttonLayoutParams)
        window.updateViewLayout(xfc, mainLayoutParams)
    end
end

function suspended_ball.onClick(v)
    window.removeView(xfq)
    zoom_animation(ooo)
    zoom_startanimation()
    window.addView(xfc, mainLayoutParams)
end

function touch.onTouch(v, event)
    local Action = event.getAction()
    if Action == MotionEvent.ACTION_DOWN then
        isMove = false
        RawX = event.getRawX()
        RawY = event.getRawY()
        x = mainLayoutParams.x
        y = mainLayoutParams.y
    elseif Action == MotionEvent.ACTION_MOVE then
        isMove = true
        mainLayoutParams.x = tonumber(x) + (event.getRawX() - RawX)
        mainLayoutParams.y = tonumber(y) + (event.getRawY() - RawY)
        buttonLayoutParams.x = tonumber(x) + (event.getRawX() - RawX)
        buttonLayoutParams.y = tonumber(y) + (event.getRawY() - RawY)
        window.updateViewLayout(xfc, mainLayoutParams)
        window.updateViewLayout(xfq, buttonLayoutParams)
    end
end

function setUi(arr)
    function invoke()
        sparkle_animation(suspended_ball)
        sparkle_startanimation()
        window.addView(xfq, buttonLayoutParams)
    end
    activity.postFunc(invoke)
end
gg.setVisible(false)
setUi() 