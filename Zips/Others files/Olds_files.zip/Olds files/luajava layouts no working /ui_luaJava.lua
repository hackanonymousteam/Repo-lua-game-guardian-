import 'android.app.*'
import 'android.os.*'
import 'android.widget.*'
import 'android.view.*'
import 'android.content.*'
import 'java.util.*'
import 'java.lang.*'
import 'android.*'
import 'android.graphics.drawable.*'
import 'android.graphics.PixelFormat'
import 'android.view.animation.Animation'
import 'android.view.animation.AnimationUtils'
import 'android.view.animation.RotateAnimation'
import 'android.animation.ObjectAnimator'
import 'android.view.animation.DecelerateInterpolator'
import 'android.ext.*'
import 'android.view.inputmethod.InputMethodManager'
import 'android.widget.ListView'
import 'android.widget.ArrayAdapter'
import 'android.widget.AdapterView'
import 'android.widget.LinearLayout'
import 'android.widget.EditText'
import 'android.widget.TextView'
import 'android.text.InputType'
import 'android.view.inputmethod.EditorInfo'

context = activity
window = context.getSystemService('window')

local mObjectAnimator
local dObjectAnimator

local startX, startY, endX, endY

import "android.media.MediaPlayer"
import "android.provider.Settings"

function playBeep()
    local mp = MediaPlayer.create(activity, Settings.System.DEFAULT_NOTIFICATION_URI)
    if mp ~= nil then
        mp.start()
    else
        print("Error")
    end
end

local toggleStates = {
    aimbot = false,
    wallhack = false,
    godmode = false
}
local function getAvailableRAM()
    local activityManager = activity.getSystemService(Context.ACTIVITY_SERVICE)
    local memoryInfo = ActivityManager.MemoryInfo()
    activityManager.getMemoryInfo(memoryInfo)
    
    local availableMegabytes = memoryInfo.availMem / (1024 * 1024)
    local totalMegabytes = memoryInfo.totalMem / (1024 * 1024)
    
    return math.floor(availableMegabytes), math.floor(totalMegabytes)
end

function getLayoutParams()
    local LayoutParams = WindowManager.LayoutParams
    local layoutParams = luajava.new(LayoutParams)
    
    layoutParams.type = (Build.VERSION.SDK_INT >= 26) and LayoutParams.TYPE_APPLICATION_OVERLAY or LayoutParams.TYPE_PHONE
    layoutParams.format = PixelFormat.RGBA_8888
    layoutParams.flags = bit32.bor(LayoutParams.FLAG_NOT_TOUCH_MODAL, LayoutParams.FLAG_LAYOUT_IN_SCREEN)
    layoutParams.gravity = Gravity.CENTER
    layoutParams.width = LayoutParams.WRAP_CONTENT
    layoutParams.height = LayoutParams.WRAP_CONTENT
    
    return layoutParams
end

function getButtonLayoutParams()
    local LayoutParams = WindowManager.LayoutParams
    local layoutParams = luajava.new(LayoutParams)
    
    layoutParams.type = (Build.VERSION.SDK_INT >= 26) and LayoutParams.TYPE_APPLICATION_OVERLAY or LayoutParams.TYPE_PHONE
    layoutParams.format = PixelFormat.RGBA_8888
    layoutParams.flags = bit32.bor(LayoutParams.FLAG_NOT_TOUCH_MODAL, LayoutParams.FLAG_LAYOUT_IN_SCREEN, LayoutParams.FLAG_NOT_FOCUSABLE)
    layoutParams.gravity = Gravity.CENTER
    layoutParams.width = LayoutParams.WRAP_CONTENT
    layoutParams.height = LayoutParams.WRAP_CONTENT
    
    return layoutParams
end

xfq = {
    ScrollView,
    layout_width = "wrap_content",
    layout_height = "wrap_content",
    fillViewport = true,
    background = "#FF222222",
    {
        LinearLayout,
        orientation = "vertical",
        layout_width = "fill",
        layout_height = "wrap_content",
        padding = "16dp",

        -- Header with logo and close button
        {
            RelativeLayout,
            layout_width = "fill",
            layout_height = "wrap_content",
            layout_marginBottom = "10dp",
            
            {
                ImageView,
                id = "img_logo",
                layout_width = "40dp",
                layout_height = "40dp",
                scaleType = "fitCenter",
                src = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbNhOPaWqNW0gL9M-4HOyrxiKiJ5zrX1TY6WKtQses8mXG6szsNQjIchv3&s=10", 
                layout_alignParentLeft = "true",
            },
            
            {
                TextView,
                text = "TOOLS",
                textSize = "22sp",
                textColor = "#FFD700",
                gravity = "center",
                textStyle = "bold",
                layout_centerInParent = "true",
            },
            
            {
                Button,
                text = "X",
                textSize = "16sp",
                textColor = "#FFFFFF",
                background = "#FFFF0000",
                layout_width = "40dp",
                layout_height = "40dp",
                layout_alignParentRight = "true",
                id = "btn_close",
                onClick = function()
                    window.removeView(xfq)
                end,
            },
        },

        {
            TextView,
            text = os.date("📅 %d/%m/%Y  🕒 %H:%M:%S"),
            textSize = "12sp",
            textColor = "#AAAAAA",
            gravity = "center",
            id = "txt_time",
            layout_marginBottom = "15dp",
        },


        {
            TextView,
            id = "txt_ram",
            text = "📊 RAM: Loading...",
            textSize = "12sp",
            textColor = "#AAAAAA",
            gravity = "center",
            layout_marginBottom = "15dp",
        },

        {
            TextView,
            text = "🔧 MAIN FUNCTIONS",
            textSize = "16sp",
            textColor = "#FF9800",
            layout_marginBottom = "10dp",
        },
        {
            Button,
            layout_width = "fill",
            layout_height = "50dp",
            text = "🎯 AIMBOT",
            textColor = "#FFFFFF",
            background = "#FF4CAF50",
            id = "btn_aimbot",
            layout_marginBottom = "8dp",
            onClick = function()
playBeep()
                gg.toast("Aimbot")
            end,
        },
        {
            Button,
            layout_width = "fill",
            layout_height = "50dp",
            text = "👁️ WALLHACK",
            textColor = "#FFFFFF",
            background = "#FF2196F3",
            id = "btn_wallhack",
            layout_marginBottom = "8dp",
            onClick = function()
playBeep()
                gg.toast("Wallhack ")
            end,
        },
        {
            Button,
            layout_width = "fill",
            layout_height = "50dp",
            text = "🛡️ GOD MODE",
            textColor = "#FFFFFF",
            background = "#FFE91E63",
            id = "btn_godmode",
            layout_marginBottom = "20dp",
            onClick = function()
playBeep()
                gg.toast("God Mode")
            end,
        },
    }
}

mainLayoutParams = getLayoutParams()
buttonLayoutParams = getButtonLayoutParams()
xfq = loadlayout(xfq)

-- Function to update time every second
function updateTime()
    txt_time.setText(os.date("📅 %d/%m/%Y  🕒 %H:%M:%S"))
    Handler().postDelayed(updateTime, 1000)
end

-- Function to update RAM info every second
function updateRAM()
    local available, total = getAvailableRAM()
    local used = total - available
    local percentage = math.floor((used / total) * 100)
    
    txt_ram.setText(string.format("📊 RAM: %d/%d MB (%d%%)", used, total, percentage))
    Handler().postDelayed(updateRAM, 1000)
end

function setUi(arr)
    function invoke()
        window.addView(xfq, buttonLayoutParams)
        updateTime() -- Start time updater
        updateRAM()  -- Start RAM updater
    end
    activity.postFunc(invoke)
end

setUi()