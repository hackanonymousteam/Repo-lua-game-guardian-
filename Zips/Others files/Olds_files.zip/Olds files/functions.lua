gg.codeKey = function()
    local currentTime = os.date("!*t", os.time())
    return currentTime.hour * 60 + currentTime.min
end

gg.editLink = function(link)
    return link:gsub(" ", "%%20")
end

gg.clearTable = function(tbl)
    for k, v in pairs(tbl) do
        tbl[k] = nil
    end
end

gg.arithmeticHexOffset = function(addr, offset, isAdd, returnHex)
    local result
    if isAdd then
        result = addr + offset
    else
        result = addr - offset
    end
    
    if returnHex then
        return string.format("0x%X", result):gsub("0x", "")
    else
        return string.format("0x%X", result & 0xFFFFFFFF)
    end
end

gg.roundFloat = function(num, decimals)
    decimals = decimals or 0
    local mult = 10 ^ decimals
    return math.floor(num * mult + 0.5) / mult
end

gg.checkSystem = function()
    state_emul = false
    local ranges = gg.getRangesList("^/data/*.odex*$")
    if ranges[1] and ranges[1].internalName:find("/x86") then
        state_emul = true
    end
end

--how to usage:

local chave = gg.codeKey()
print("key:", chave) 

local url = "https://example.com/script test.lua"
local urlEditada = gg.editLink(url)
print("url edited:", urlEditada) 

local minhaTabela = {a = 1, b = 2, c = 3}
print("<-:", #minhaTabela) 
gg.clearTable(minhaTabela)
print("->:", #minhaTabela) 

local addr = 0x12345678
local offset = 0x100

local novoAddr = gg.arithmeticHexOffset(addr, offset, true, false)
print("adress + offset:", novoAddr) -- 
local novoAddr2 = gg.arithmeticHexOffset(addr, offset, false, true)
print("adress - offset:", novoAddr2) 

local num = 3.14159

local arredondado = gg.roundFloat(num, 2)
print("", arredondado) -- 3.14

if gg.checkSystem then
print("running in device real")
else
print("x86 detected")
end

