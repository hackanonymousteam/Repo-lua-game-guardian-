
function getUptime()
    local uptime = os.clock()
    local hours = math.floor(uptime / 3600)
    local minutes = math.floor((uptime % 3600) / 60)
    local seconds = math.floor(uptime % 60)
    return string.format("%02d:%02d:%02d", hours, minutes, seconds)
end

function byteToMb(bytes)
    return string.format("%.2f MB", bytes / (1024 * 1024))
end

function getMemoryUsage()
    local memoryUsage = collectgarbage("count") -- Em KB
    return byteToMb(memoryUsage * 1024)
end

function getPing()
    local startTime = os.clock()
    for i = 1, 1e6 do end 
    local endTime = os.clock()
    return string.format("%.2f ms", (endTime - startTime) * 1000)
end

function showStatistics()
    local uptime = getUptime()
    local memoryUsage = getMemoryUsage()
    local ping = getPing()
    gg.alert("📊 Statistics 📊\n\n" ..
             "Uptime: " .. uptime .. "\n" ..
             "Memory Usage: " .. memoryUsage .. "\n" ..
             "Ping: " .. ping .. "\n\n" ..
             "❤️ by Batman Games ❤️")
end

showStatistics()