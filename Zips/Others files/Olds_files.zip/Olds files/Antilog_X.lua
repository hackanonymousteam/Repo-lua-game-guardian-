local logged
local clock=os['clock']
gg['clearResults']()
local time1=clock()
gg['setRanges']('262144')
for i=0,2 do
 gg.searchNumber('0',4,true)
end
local time2=clock()
while time2-time1-('0.80'-0)>0 do
 print(time2-time1)
 _ENV=nil return
end

local long,pcall="\092",_ENV['pcall']
for i=1,'23' do
 long=long..long
end

local long_={}
long_['value']=long long_['noob']=1
long_['😅']=2 long_['yeyeye']=3
long_['log me']=4 long_['easy right?']=5
long_['address']="0x1" long_['flags']='4'

local long2={}
for i=1,'1024' do
 long2[#long2+1]={address=i,value=long_.value,flags=long_.flags,name=long_.name}
end

gg['removeListItems'](long2)

for i,v in pairs({gg["getResultsCount"],gg["getTargetPackage"],gg["getValuesRange"],gg["loadResults"],gg["alert"],gg["bytes"],gg["copyText"],gg["searchAddress"],io["open"],gg["refineAddress"],string["reverse"],gg["toast"],gg['getValues'],gg['setValues'],string["dump"],debug["traceback"],gg["removeResults"],gg["removeListItems"],string["char"],gg['editAll'],gg['searchNumber']}) do
 pcall(v,long2)
end

local getinfo,traceback=debug['getinfo'],debug['traceback']
for i=1,'1000' do
 getinfo(i,nil,long2)
 traceback(long2,nil,long2)
end

gg['getResults']('999999999')

local res_count=gg['getResultCount']
for i=1,'30000' do
 res_count()
end
local refine=gg['refineNumber']
for i=1,'5' do
 refine(long2,long2,long2,long2,long2,long2)
 for m=1,'10' do
  pcall(refine,long)
 end
 pcall(gg['edtiAll'],long2)
end
local clock=clock()
clock=clock-time1
local l,ll=1.0 l=l+l+l
ll=l*l l=ll+l
while clock>l do
 print("LOAD FAIL(Used too much time)")
 _ENV=nil return
end
clock=os['clock']
local a = debug.getinfo(tostring)
if #(tostring(a.func)) ~= 18 or type(a.func) ~= "function" or a.short_src ~= "[Java]" or a.what ~= "Java" then
while true do
gg.alert("Function Modified")
end
end

if tostring("@") ~= "@" or #(tostring(true)) ~= 4 or tostring(2005) ~= "2005" then
while true do
gg.alert("Function Modified")
end
end

local a = debug.getinfo(type)
if tostring(a.func) ~= "function: type" or type(a.func) ~= "function" or a.short_src ~= "[Java]" or a.what ~= "Java" then
while true do
gg.alert("Function Modified")
end
end

if type(function ()
end) ~= "function" or type("Tùng đen") ~= "string" or type(2005) ~= "number" or type(true) ~= "boolean" then
while true do
gg.alert("Function Modified")
end
end

local a = debug.getinfo(debug.getinfo)
if #(tostring(a.func)) ~= 23 or type(a.func) ~= "function" or a.short_src ~= "[Java]" or a.what ~= "Java" then
while true do
gg.alert("Function Modified")
end
end

local a = debug.getinfo(gg.refineNumber)
if #(tostring(a.func)) ~= 283 or type(a.func) ~= "function" or a.short_src ~= "[Java]" or a.what ~= "Java" then
while true do
gg.alert("Function Modified")
end
end

local a = debug.getinfo(string.rep)
if #(tostring(a.func)) ~= 20 or #(type(a.func)) ~= 8 or a.short_src ~= "[Java]" or a.what ~= "Java" then
while true do
gg.alert("Function Modified")
end
end

if string.rep("AA", 2) ~= "AAAA" or #(string.rep("AA", 2)) ~= string.len(string.rep("AA", 2)) or #(string.rep("AA", 2)) ~= 4 or string.len(string.rep("AA", 2)) ~= 4 then
while true do
gg.alert("Function Modified")
end
end

local a = debug.getinfo(string.char)
if tostring(a.func) ~= "function: string.char" or type(a.func) ~= "function" or a.short_src ~= "[Java]" or a.what ~= "Java" then
while true do
gg.alert("Function Modified")
end
end

if #(string.char(1)) ~= 1 or #string.char(195, 185) ~= 2 or string.char(84, 195, 185, 110, 103, 32, 196, 145, 101, 110) ~= "Tùng đen" then
while true do
gg.alert("Function Modified")
end
end

local a = debug.getinfo(gg.refineAddress)
if #(tostring(a.func)) ~= 271 or type(a.func) ~= "function" or a.short_src ~= "[Java]" or a.what ~= "Java" then
while true do
gg.alert("Function Modified")
end
end

local a = debug.getinfo(math.random)
if tostring(a.func) ~= "function: math.random" or type(a.func) ~= "function" or a.short_src ~= "[Java]" or a.what ~= "Java" then
while true do
gg.alert("Function Modified")
end
end

if math.random(0, 4) == math.random(5, 9) or #(tostring(math.random(0, 9))) ~= string.len(tostring(math.random(0, 9))) or #(tostring(math.random(0, 9))) ~= 1 or string.len(tostring(math.random(0, 9))) ~= 1 then
while true do
gg.alert("Function Modified")
end
end

local a = debug.getinfo(pcall)
if #(tostring(a.func)) ~= 15 or type(a.func) ~= "function" or a.short_src ~= "[Java]" or a.what ~= "Java" then
while true do
gg.alert("Function Modified")
end
end

local a = debug.getinfo(gg.setRanges)
if #(tostring(a.func)) ~= 57 or type(a.func) ~= "function" or a.short_src ~= "[Java]" or a.what ~= "Java" then
while true do
gg.alert("Function Modified")
end
end

local a = debug.getinfo(gg.setValues)
if #(tostring(a.func)) ~= 81 or type(a.func) ~= "function" or a.short_src ~= "[Java]" or a.what ~= "Java" then
while true do
gg.alert("Function Modified")
end
end

local a = debug.getinfo(gg.searchNumber)
if #(tostring(a.func)) ~= 283 or type(a.func) ~= "function" or a.short_src ~= "[Java]" or a.what ~= "Java" then
while true do
gg.alert("Function Modified")
end
end

local a = debug.getinfo(gg.SIGN_EQUAL)
if a ~= nil or type(gg.SIGN_EQUAL) ~= "number" then

end

local a = debug.getinfo(gg.editAll)
if #(tostring(a.func)) ~= 106 or type(a.func) ~= "function" or a.short_src ~= "[Java]" or a.what ~= "Java" then
while true do
gg.alert("Function Modified")
end
end

local a = debug.getinfo(gg.getRangesList)
if #(tostring(a.func)) ~= 73 or type(a.func) ~= "function" or a.short_src ~= "[Java]" or a.what ~= "Java" then
while true do
gg.alert("Function Modified")
end
end

local a = debug.getinfo(os.clock)
if tostring(a.func) ~= "function: clock" or type(a.func) ~= "function" or a.short_src ~= "[Java]" or a.what ~= "Java" then
while true do
gg.alert("Function Modified")
end
end

local a = debug.getinfo(gg.sleep)
if #(tostring(a.func)) ~= 65 or type(a.func) ~= "function" or a.short_src ~= "[Java]" or a.what ~= "Java" then
while true do
gg.alert("Function Modified")
end
end

if string.rep("AA", 2) ~= "AAAA" or #(string.rep("AA", 2)) ~= string.len(string.rep("AA", 2)) or #(string.rep("AA", 2)) ~= 4 or string.len(string.rep("AA", 2)) ~= 4 then
  while true do
    gg.alert("Function Modified")
  end
end

local a, b = "'" .. math.random(1, 255), math.random(100, 300)
if tostring("@") ~= "@" then
  while true do
    gg.alert("Function Modified")
  end
end
if math.random(100, 101) < 100 or math.random(100, 101) > 101 or math.random(98882997) == 98882997 then
  while true do
    gg.alert("Function Modified")
  end
elseif string.match(tostring(debug.getinfo), "@") then
  while true do
    gg.alert("Function Modified")
  end
elseif string.match(a, a) ~= a then
  while true do
    gg.alert("Function Modified")
  end
elseif string.len(tostring(string.match)) ~= 22 or string.len(b) == 22 or type(string.len(b)) ~= "number" then
  while true do
    gg.alert("Function Modified")
  end
elseif string.find(tostring(string.match), "@") then
  while true do
    gg.alert("Function Modified")
  end
elseif string.match("a", "a") == string.match("b", "b") then
  while true do
    gg.alert("Function Modified")
  end
elseif string.match("aa", "aa") == nil then
  while true do
    gg.alert("Function Modified")
  end
elseif string.find("aa", "aa") == nil then
  while true do
    gg.alert("Function Modified")
  end
end
for k, v in next, _ENV do
  if string.match(tostring(v), "function: @.-:") then
    while true do
      gg.alert("Function Modified")
    end
  end
end
if string.match(tostring(os.exit), "-") or string.match(tostring(os.exit), "//") or string.match(tostring(os.exit), "@") or string.match(tostring(os.exit), "%%d+") then
  while true do
    gg.alert("Function Modified")
  end
end

for i in string.gmatch(tostring(debug.traceback()), "(.-)\n") do
  if string.match(i, ".(/.-):") and string.match(i, ".(/.-):") ~= gg.getFile() then
    while true do
      gg.alert("Function Modified")
    end
  end
end
for i in ipairs({
  tostring(gg),
  tostring(os),
  tostring(io),
  tostring(debug),
  tostring(math),
  tostring(table)
}) do
  if string.match(({
    tostring(gg),
    tostring(os),
    tostring(io),
    tostring(debug),
    tostring(math),
    tostring(table)
  })[i], "@") then
    while true do
      gg.alert("Function Modified")
    end
  end
end

for k, v in pairs({
  debug.getinfo(gg.toast).short_src,
  debug.getinfo(gg.getResults).short_src,
  debug.getinfo(gg.getValues).short_src,
  debug.getinfo(os.exit).short_src,
  debug.getinfo(gg.refineNumber).short_src,
  debug.getinfo(gg.refineAddress).short_src,
  debug.getinfo(gg.alert).short_src,
  debug.getinfo(gg.searchNumber).short_src,
  debug.getinfo(gg.setRanges).short_src,
  debug.getinfo(gg.isVisible).short_src,
  debug.getinfo(gg.setVisible).short_src,
  debug.getinfo(gg.saveList).short_src
}) do
  if v ~= "[Java]" then
    while true do
      gg.alert("Function Modified")
    end
  end
end

local a = 0
local b = function ()
  a = a + 1
  return "Function Modified"
end
local c = tostring
tostring = b
string.gsub(0, "", b)
tostring = c
if a ~= 2 then
  while true do
    gg.alert("Function Modified")
  end
end
local d = {
  tostring,
  type,
  string.match,
  pairs,
  load
}
for i = 1, #d do
  local e = d[i]
  local r = debug.getinfo(e)
  if not r or r["func"] ~= e or r["istailcall"] or r["what"] ~= "Java" then
    while true do
      gg.alert("Function Modified")
    end
  end
end