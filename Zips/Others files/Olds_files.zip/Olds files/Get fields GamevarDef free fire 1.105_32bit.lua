
gg.setVisible(false)
gg.clearResults()
gg.clearList()
gg.alert("by Batman Games")

gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("3.25;1.39999997616;1.89999997616::9", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.refineNumber("3.25", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
local t = gg.getResults(1, nil, nil, nil, nil, nil, nil, nil, nil)
gg.addListItems(t)t = nil
local copy = false
local t = gg.getListItems()
if not copy then gg.removeListItems(t) end
for i, v in ipairs(t) do
	v.address = v.address - 0x44
	v.name = ' public static readonly Single ReservedFloat01' 
end

   gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ReservedFloat02' 
	end end -- 0x4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ReservedFloat03' 
	end end -- 0x8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ReservedFloat04' 
	end end -- 0xc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 ReservedInt01' 
	end end -- 0x10
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 ReservedInt02' 
	end end -- 0x14
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 ReservedInt03' 
	end end -- 0x18
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 ReservedInt04' 
	end end -- 0x1c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int64 ReservedLong01' 
	end end -- 0x20
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int64 ReservedLong02' 
	end end -- 0x28
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int64 ReservedLong03' 
	end end -- 0x30
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int64 ReservedLong04' 
	end end -- 0x38
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ReservedBool01' 
	end end -- 0x40
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ReservedBool02' 
	end end -- 0x41
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ReservedBool03' 
	end end -- 0x42
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ReservedBool04' 
	end end -- 0x43
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableResetScheduleNotifyAsync' 
	end end -- 0x44
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single RunSpeed' 
	end end -- 0x48
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single DashSpeedScale' 
	end end -- 0x4c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CrouchSpeed' 
	end end -- 0x50
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CreepSpeed' 
	end end -- 0x54
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single DieingSpeed' 
	end end -- 0x58
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single StropSpeed' 
	end end -- 0x5c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CatapultSpeed' 
	end end -- 0x60
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single StropUseCooldown' 
	end end -- 0x64
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single StropFOV' 
	end end -- 0x68
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single StropFOVFadeDuration' 
	end end -- 0x6c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CannonFOV' 
	end end -- 0x70
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ZiplineUseCD' 
	end end -- 0x74
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ZipLineCancelCD' 
	end end -- 0x78
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ShoalSpeedScale' 
	end end -- 0x7c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SimGravityY' 
	end end -- 0x80
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single LightLaserTime' 
	end end -- 0x84
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MaxJumpHeight' 
	end end -- 0x88
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single HighFallingHeight' 
	end end -- 0x8c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single StandingColliderHeight' 
	end end -- 0x90
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CrouchingColliderHeight' 
	end end -- 0x94
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MovingCrouchingColliderHeight' 
	end end -- 0x98
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single LowGravityAreaFallingHeight' 
	end end -- 0x9c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SniperStandingColliderHeight' 
	end end -- 0xa0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SniperStandingColliderRadius' 
	end end -- 0xa4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SniperCrouchingColliderHeight' 
	end end -- 0xa8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SniperCrouchingColliderRadius' 
	end end -- 0xac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SniperCreapingColliderYPos' 
	end end -- 0xb0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SniperCreepingColliderHeight' 
	end end -- 0xb4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SniperCreepingColliderRadius' 
	end end -- 0xb8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PlayerACEFirstVFXContinueTime' 
	end end -- 0xbc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PlayerACESecondVFXDelayTime' 
	end end -- 0xc0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PlayerACESoundDelayTime' 
	end end -- 0xc4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String FootstepEnableMaps' 
	end end -- 0xc8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String IsInSearching' 
	end end -- 0xcc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single Hudsettingright' 
	end end -- 0xd0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single Hudsettingleft' 
	end end -- 0xd4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single Hudsettingtop' 
	end end -- 0xd8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single Hudsettingbuttom' 
	end end -- 0xdc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DisableMakePixelPerfectForLowQuality' 
	end end -- 0xe0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single LobbyshowAllReadyVfx' 
	end end -- 0xe4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FallingTimeToCheckHighFalling' 
	end end -- 0xe8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FallingHeightScaleToCheckHighFalling' 
	end end -- 0xec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FreeMoveAngularSpeed' 
	end end -- 0xf0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FreeMoveAngularSpeedStand' 
	end end -- 0xf4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FreeMoveAngularSpeedCrouch' 
	end end -- 0xf8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FreeMoveAngularSpeedCreep' 
	end end -- 0xfc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FreeMoveAngularSpeedKnockDown' 
	end end -- 0x100
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single InCarColliderHeight' 
	end end -- 0x104
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SkyDivingSpeedDelta' 
	end end -- 0x108
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SkyDivingRotationSpeed' 
	end end -- 0x10c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SkyDivingTimeToOpenParachute' 
	end end -- 0x110
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SkySurfingRotationSpeed' 
	end end -- 0x114
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SkySurfingSpeedDelta' 
	end end -- 0x118
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SkyDashingRotationSpeed' 
	end end -- 0x11c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SkySurfingStanceButtonOffHeight' 
	end end -- 0x120
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UseLContainer' 
	end end -- 0x124
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean AsyncLoadLContainer' 
	end end -- 0x125
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ParachutingMaxAngleTilt' 
	end end -- 0x128
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ParachutingMinAngleTilt' 
	end end -- 0x12c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ParachutingTiltSpeed' 
	end end -- 0x130
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ParachutingMaxAngleRoll' 
	end end -- 0x134
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ParachutingMinAngleRoll' 
	end end -- 0x138
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ParachutingRollSpeed' 
	end end -- 0x13c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ParachutingTurningRadius' 
	end end -- 0x140
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ParachutingOpenDuration' 
	end end -- 0x144
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 DefaultBagCapacity' 
	end end -- 0x148
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single HitDamageRatioHead' 
	end end -- 0x14c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single HitDamageRatioBody' 
	end end -- 0x150
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single HitDamageRatioLimb' 
	end end -- 0x154
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single HitDamageRatioVehicle' 
	end end -- 0x158
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single HitDamageRatioSniperExtension' 
	end end -- 0x15c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SkyDivingCameraUpOffset' 
	end end -- 0x160
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SkyDivingCameraBackOffset' 
	end end -- 0x164
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single OnBoardCameraUpOffset' 
	end end -- 0x168
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single OnBoardCameraBackOffset' 
	end end -- 0x16c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SkySurfingCameraUpOffset' 
	end end -- 0x170
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SkySurfingCameraBackOffset' 
	end end -- 0x174
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ParachutingCameraUpOffset' 
	end end -- 0x178
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ParachutingCameraBackOffset' 
	end end -- 0x17c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SkyDivingCameraShakeFactor' 
	end end -- 0x180
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ParachutingCameraShakeDuring' 
	end end -- 0x184
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ParachutingCameraShakeFactor' 
	end end -- 0x188
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single LandingCameraShakeDuration' 
	end end -- 0x18c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single LandingCameraShakeFactor' 
	end end -- 0x190
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GroupInviteCoolDown' 
	end end -- 0x194
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single AnimSpeedRunFist' 
	end end -- 0x198
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single AnimSpeedRunPistol' 
	end end -- 0x19c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single AnimSpeedRunGun' 
	end end -- 0x1a0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single AnimSpeedRunAWM' 
	end end -- 0x1a4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single AnimSpeedDash' 
	end end -- 0x1a8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single AnimSpeedCrouch' 
	end end -- 0x1ac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single AnimSpeedCrawl' 
	end end -- 0x1b0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single AnimSpeedFireWalk' 
	end end -- 0x1b4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single AnimSpeedFireCrouchWalk' 
	end end -- 0x1b8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 AlarmSoundChangeRadius' 
	end end -- 0x1bc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single AlarmSoundStartSecound' 
	end end -- 0x1c0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single AlarmSoundDuringSecound' 
	end end -- 0x1c4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GunFireBoneDeltaAngeX' 
	end end -- 0x1c8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GunFireBoneDeltaAngeX_Crouch' 
	end end -- 0x1cc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GunFireBoneDeltaAngeZ_Crouch' 
	end end -- 0x1d0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single IKBoneRotateSpeed' 
	end end -- 0x1d4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleHitSoundMinSpeedSqr' 
	end end -- 0x1d8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 EnableGameVoice' 
	end end -- 0x1dc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ReleaseMicWhenMute' 
	end end -- 0x1e0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean OpenNewPlayerHud' 
	end end -- 0x1e1
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean OpenNewDownloadHandlerWay' 
	end end -- 0x1e2
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean LimitPickupItem' 
	end end -- 0x1e3
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableExitCommModeWhenHeadsetPlugin' 
	end end -- 0x1e4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean RemoveDeadTeammatesOnMap' 
	end end -- 0x1e5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 DurationDeadTeammatesOnMap' 
	end end -- 0x1e8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowTeammateFiringOnMap' 
	end end -- 0x1ec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowEnemyFiringOnMap' 
	end end -- 0x1ed
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ModifyAvatarCode' 
	end end -- 0x1ee
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ModifyAvatarDataCode' 
	end end -- 0x1ef
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 VegetationNewViewDistance' 
	end end -- 0x1f0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single DeadFlySpeedByCar' 
	end end -- 0x1f4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single AnimSpeedSwim' 
	end end -- 0x1f8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single DynamicSplashOffsetY' 
	end end -- 0x1fc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String CSTutorialPopupCDN' 
	end end -- 0x200
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableUpdateAxisTouchOptimize' 
	end end -- 0x204
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 PartyGameMoviePlayTime' 
	end end -- 0x208
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 PartyGameSoloDancePosMarkCloseDistance' 
	end end -- 0x20c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 PartyGameSoloDanceCheckIsInZoneDistance' 
	end end -- 0x210
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PartyGameSoloDanceInvitationInterval' 
	end end -- 0x214
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PartyGameSoloDanceInvitationAutoHideTime' 
	end end -- 0x218
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PartyGameSoloDancePosMarkAutoHideTime' 
	end end -- 0x21c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 PartyGameSoloDanceDefaultEmoteId' 
	end end -- 0x220
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean RegisterCheckNewbiePickNewbie' 
	end end -- 0x224
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PartyGamMusicBeatIntervalThreshold' 
	end end -- 0x228
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SwitchWeaponInterval' 
	end end -- 0x22c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean SingersBModeNotShowClothForLowest' 
	end end -- 0x230
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadData' 
	end end -- 0x231
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalMapRefOptionalRedefId' 
	end end -- 0x232
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ChangeToWalkingWhileGetOnVehicleInSkyState' 
	end end -- 0x233
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableRUDPFastResend' 
	end end -- 0x234
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 OptionalAutoDownLoadStandard' 
	end end -- 0x238
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableCdnCacheInAdvance' 
	end end -- 0x23c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 CacheCDNImageSizeMinBytes' 
	end end -- 0x240
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableLevelClimbTriggerOnStart' 
	end end -- 0x244
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UDP_MTU_LIMIT' 
	end end -- 0x248
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Double UDP_RECONNECT_DELAY' 
	end end -- 0x250
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Double UDP_RESEND_TIMEOUT' 
	end end -- 0x258
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Double UDP_HELLO_RESEND_TIMEOUT' 
	end end -- 0x260
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UDP_HELLO_MAX_RESEND_COUNT' 
	end end -- 0x268
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UDP_MAX_RESEND_COUNT' 
	end end -- 0x26c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UDP_MSG_KEY_MIN' 
	end end -- 0x270
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UDP_MSG_KEY_MAX' 
	end end -- 0x274
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UDP_MSG_KEY_MID' 
	end end -- 0x278
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 SAPTeamMatePortalsDeleteTime' 
	end end -- 0x27c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean IsTurnOnBuffHUDSupportBuffECA' 
	end end -- 0x280
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 RUDPFastResendTimeoutMaxStepCount' 
	end end -- 0x284
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single RUDPFastResendTimeoutStepInterval' 
	end end -- 0x288
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 HandleUDPPacketsFrameNumLowest' 
	end end -- 0x28c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 HandleUDPPacketsFrameNumLow' 
	end end -- 0x290
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 HandleUDPPacketsFrameNumUltra' 
	end end -- 0x294
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 HandleUDPPacketsMinPerFrameLowest' 
	end end -- 0x298
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 HandleUDPPacketsMinPerFrameLow' 
	end end -- 0x29c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 HandleUDPPacketsMinPerFrameUltra' 
	end end -- 0x2a0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableCollectionEffect' 
	end end -- 0x2a4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableQualityNewIsEffect' 
	end end -- 0x2a5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableUnSerializeRudpMsgThread' 
	end end -- 0x2a6
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableSerializeRudpMsgThread' 
	end end -- 0x2a7
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 AutoExpandBrGroupModeLevel' 
	end end -- 0x2a8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean HandleUDPPacketsTimeLimit' 
	end end -- 0x2ac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 HandleUDPPacketsTimeLimitMS' 
	end end -- 0x2b0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single HandleUDPPacketsWaitTimeMaxMs' 
	end end -- 0x2b4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean HandleUDPPacketsTimeLimitEnableLog' 
	end end -- 0x2b8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 HandleUDPPacketsTimeLimitMSForDeath' 
	end end -- 0x2bc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean HandleUDPPacketsWaitTimeMax' 
	end end -- 0x2c0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean HandleUDPPacketsWaitTimeMaxDelayEnable' 
	end end -- 0x2c1
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single HandleUDPPacketsWaitTimeMaxDelaySec' 
	end end -- 0x2c4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EndGameEventLogComplete' 
	end end -- 0x2c8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DelaySendEndGameEventLog' 
	end end -- 0x2c9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CSRankLoadingTimeLength' 
	end end -- 0x2cc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single BRRankLoadingTimeLength' 
	end end -- 0x2d0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 CupApplyNoteMax' 
	end end -- 0x2d4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 CupInviteNoteMax' 
	end end -- 0x2d8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 EmptySkillId' 
	end end -- 0x2dc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single LobbyEnterItemSizeRatio' 
	end end -- 0x2e0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single TransferLeaderCd' 
	end end -- 0x2e4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String RankGroup' 
	end end -- 0x2e8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String CSRankGroup' 
	end end -- 0x2ec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String PeriodicRankGroup' 
	end end -- 0x2f0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 RankingTokenID' 
	end end -- 0x2f4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableChangeResolutionHippo' 
	end end -- 0x2f8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DisableReset3dCameraByPreviewComp' 
	end end -- 0x2f9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CarCrashSpeedScale' 
	end end -- 0x2fc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CarCrashAngle' 
	end end -- 0x300
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleKillPersonMinSpeedSqr' 
	end end -- 0x304
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CarCrashDamageScaleToPlayer' 
	end end -- 0x308
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CarCrashDamageScaleToTeamate' 
	end end -- 0x30c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CarCrashDamageScaleToVehicle' 
	end end -- 0x310
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CarCrashDamageScaleToPlayerInVehicle' 
	end end -- 0x314
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CarCrashDamageScaleWhenHitWall' 
	end end -- 0x318
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CarCrashProtectTimeForHitPlayer' 
	end end -- 0x31c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CarCrashProtectTimeForHitCar' 
	end end -- 0x320
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CarCrashProtectTimeForHitWall' 
	end end -- 0x324
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UseNewCarCrash' 
	end end -- 0x328
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SwapWeaponCD' 
	end end -- 0x32c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableRebateCard' 
	end end -- 0x330
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnablePaymentBundle' 
	end end -- 0x331
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean PaymentPriceShowLoading' 
	end end -- 0x332
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean PreferExternalUnityPaymentShop_ThirdParty' 
	end end -- 0x333
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String PaymentShopFallbackStrategy' 
	end end -- 0x334
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SilenceWeaponHintRange' 
	end end -- 0x338
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String ForceBlackBloodRegions' 
	end end -- 0x33c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String OptionalBlackBloodRegions' 
	end end -- 0x340
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DisableWebViewWindow' 
	end end -- 0x344
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DisableWebViewScaling' 
	end end -- 0x345
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DisableWebViewCookie' 
	end end -- 0x346
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DisableWebViewJavascriptInjection' 
	end end -- 0x347
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DisableWebViewMediaManipulationOnHideAndShowByJavaScript' 
	end end -- 0x348
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String WebPageFallbackStrategy_iOS' 
	end end -- 0x34c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String WebPageFallbackStrategy_Android' 
	end end -- 0x350
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean WebView_OnlyAutoPlayMediaWithWIFI_iOS' 
	end end -- 0x354
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean WebView_OnlyAutoPlayMediaWithWIFI_Android' 
	end end -- 0x355
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean AndroidWebViewUseActivity' 
	end end -- 0x356
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean AndroidEnhancedNetworkType' 
	end end -- 0x357
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single UavRange' 
	end end -- 0x358
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single UavModelDisplayRange' 
	end end -- 0x35c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single UavRevealTime' 
	end end -- 0x360
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SwimSpeed' 
	end end -- 0x364
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SwimSurfSpeed' 
	end end -- 0x368
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CharacterRecvShadow' 
	end end -- 0x36c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SwimDashScale' 
	end end -- 0x370
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableLightmapInLowQuality' 
	end end -- 0x374
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableANO' 
	end end -- 0x375
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableSkySurfing' 
	end end -- 0x376
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single EatMushroomTime' 
	end end -- 0x378
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single UseArmortoolsTime' 
	end end -- 0x37c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single UseInfoBoxTime' 
	end end -- 0x380
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 NickNameMaxLength' 
	end end -- 0x384
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean Enable3PAsyncLoadSkateboard' 
	end end -- 0x388
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableClimb' 
	end end -- 0x389
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableMoveDirectionCheckInClimb' 
	end end -- 0x38a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CrossOverAnimTime' 
	end end -- 0x38c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CrossOverJumpTimeDefault' 
	end end -- 0x390
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CrossOverFallTimeDefault' 
	end end -- 0x394
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ClimbCameraDuration' 
	end end -- 0x398
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single AskChangeSeatCoolDown' 
	end end -- 0x39c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single WaitingForConfirmationTimeout' 
	end end -- 0x3a0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GunTrace3PMinDistanceSqr' 
	end end -- 0x3a4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GunTrace3PTimeInterval' 
	end end -- 0x3a8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ChangingOcclusionTransparency' 
	end end -- 0x3ac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ChangeOcclusionTransparencyWhenMoving' 
	end end -- 0x3ad
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ChangeOcclusionTransparencyWithoutLowQuality' 
	end end -- 0x3ae
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ChangingTransparencyTimeLimit' 
	end end -- 0x3b0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ChangingTransparencyStep' 
	end end -- 0x3b4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ChangingTransparencyTarget' 
	end end -- 0x3b8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean SaveLocationInPlatform' 
	end end -- 0x3bc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 HeatEndTime' 
	end end -- 0x3c0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 VersionUpDateTime' 
	end end -- 0x3c8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GunTrace3PMaxDistance' 
	end end -- 0x3d0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FastReviveAfterBooyah' 
	end end -- 0x3d4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableCustomRoom' 
	end end -- 0x3d8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableCustomRoomAuthority' 
	end end -- 0x3d9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 AbbreviationMaxCharacters' 
	end end -- 0x3dc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String AbbreviationSeparator' 
	end end -- 0x3e0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 CustomRoomCSShopMaxCost' 
	end end -- 0x3e4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 CustomRoomCSShopCostInterval' 
	end end -- 0x3e8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 CustomRoomCSMaxRound' 
	end end -- 0x3ec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String CustomRoomCSInitCoin' 
	end end -- 0x3f0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 EsportsSplashWidth' 
	end end -- 0x3f4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 EsportsSplashHeight' 
	end end -- 0x3f8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 EsportsSplashPosX' 
	end end -- 0x3fc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 EsportsSplashPosY' 
	end end -- 0x400
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 VeteranActivateVeteranReminderTime' 
	end end -- 0x404
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableLateInitGameVoice' 
	end end -- 0x408
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 MaxReleaseCDNSetTimesForEasyList' 
	end end -- 0x40c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableLUTHighQuality' 
	end end -- 0x410
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableLUTMidQuality' 
	end end -- 0x411
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean HighFPSSetting' 
	end end -- 0x412
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleSkyDivingCameraUpOffset' 
	end end -- 0x414
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleSkyDivingCameraBackOffset' 
	end end -- 0x418
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleParachutingCameraUpOffset' 
	end end -- 0x41c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleParachutingCameraBackOffset' 
	end end -- 0x420
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleSkyDivingMinVSpeed' 
	end end -- 0x424
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleSkyDivingMaxVSpeed' 
	end end -- 0x428
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleSkyDivingMinHSpeed' 
	end end -- 0x42c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleSkyDivingMaxHSpeed' 
	end end -- 0x430
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleSkyDivingRotationSpeed' 
	end end -- 0x434
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleParachutingMinHSpeed' 
	end end -- 0x438
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleParachutingMaxHSpeed' 
	end end -- 0x43c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleParachutingMinVSpeed' 
	end end -- 0x440
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleParachutingMaxVSpeed' 
	end end -- 0x444
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleParachutingRollSpeed' 
	end end -- 0x448
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableShootTraceAdjustment' 
	end end -- 0x44c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ShootTraceAdjustmentDistanceThreshold' 
	end end -- 0x450
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 RejoinMatchWaitingForSteaming' 
	end end -- 0x454
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SlopeLimit' 
	end end -- 0x458
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single StepOffset' 
	end end -- 0x45c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SkinWidth' 
	end end -- 0x460
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CCTRadiusNormal' 
	end end -- 0x464
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CCTRadiusCreep' 
	end end -- 0x468
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CCTRadiusUGCNormal' 
	end end -- 0x46c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CCTRadiusUGCCreep' 
	end end -- 0x470
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CreepSlopeLimit' 
	end end -- 0x474
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CreepStepOffset' 
	end end -- 0x478
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CreepColliderHeight' 
	end end -- 0x47c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single BoardSurfingColliderHeight' 
	end end -- 0x480
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableBoardSurfingResizeCCT' 
	end end -- 0x484
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single LobbyAdAutoScrollTime' 
	end end -- 0x488
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SeventhBLobbyAdAutoScrollTime' 
	end end -- 0x48c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GachaAdAutoScrollTime' 
	end end -- 0x490
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CDNAutoScrollTime' 
	end end -- 0x494
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GachaClothTabAutoScrollTime' 
	end end -- 0x498
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single IAPCDNAdAutoScrollTime' 
	end end -- 0x49c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SpectatorCameraHeight' 
	end end -- 0x4a0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SpectatorCameraHDis' 
	end end -- 0x4a4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SpectatorCameraAngle' 
	end end -- 0x4a8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SeventhBGamePlayTipsTime' 
	end end -- 0x4ac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 SeventhBSyncLimitedTime' 
	end end -- 0x4b0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SPHudNameScale' 
	end end -- 0x4b8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SPHudNameFixedRadius' 
	end end -- 0x4bc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SPHudNameFreeRadius' 
	end end -- 0x4c0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SPHudNameShiftRadius' 
	end end -- 0x4c4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SPHudNameSightingAlpha' 
	end end -- 0x4c8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SpectatorNamePlateScaleOffset' 
	end end -- 0x4cc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SpectatorNamePlateScaleOffsetMiniMap' 
	end end -- 0x4d0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SpectatorNamePlateScaleMiniMapCSMode' 
	end end -- 0x4d4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SpectatorBombZoneScaleOnMiniMap' 
	end end -- 0x4d8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SpectatorBombZoneScaleOnBigMap' 
	end end -- 0x4dc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SPCSHudShowTeamExtraInfoTime' 
	end end -- 0x4e0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SPMatchResultScrollViewMoveSpeed' 
	end end -- 0x4e4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FireSoundMiddleSqrRange' 
	end end -- 0x4e8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FireSoundLongSqrRange' 
	end end -- 0x4ec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single BulletDropSoundDelay' 
	end end -- 0x4f0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 GuestPlayLadderMatchLevelLimit' 
	end end -- 0x4f4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 OildrumMaxDurability' 
	end end -- 0x4f8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 ReactorMaxDurability' 
	end end -- 0x4fc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ReactorExplodeTime' 
	end end -- 0x500
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 OildrumExplodeRadius' 
	end end -- 0x504
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 OildrumExplodeMaxDamage' 
	end end -- 0x508
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 OildrumExplodeMinDamage' 
	end end -- 0x50c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 OildrumExplodeThreshold' 
	end end -- 0x510
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SmokedrumUsePrepareTime' 
	end end -- 0x514
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single AmmoBoxUsePrepareTime' 
	end end -- 0x518
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SkyDivingForceToOpenParachuteHeight' 
	end end -- 0x51c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean SpeedRoyalBGMEnable' 
	end end -- 0x520
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SpeedRoyalBGMDelay' 
	end end -- 0x524
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 StropFallingDamageMax' 
	end end -- 0x528
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableTreasureMap' 
	end end -- 0x52c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableBountyContract' 
	end end -- 0x52d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DisplayLocalizedPriceForIAP' 
	end end -- 0x52e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String IAPProductsVersion' 
	end end -- 0x530
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String PaymentBundlesVersion' 
	end end -- 0x534
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String RebateCardsVersion' 
	end end -- 0x538
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SpectatorCameraMoveSpeed' 
	end end -- 0x53c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SpectatorCameraFastMoveSpeedRatio' 
	end end -- 0x540
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SpectatorCamreraRotateSpeed' 
	end end -- 0x544
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SpectatorCameraMoveAcceleration' 
	end end -- 0x548
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SpectatorCameraMoveDeceleration' 
	end end -- 0x54c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SpectatorCameraMoveSpeedRatioMin' 
	end end -- 0x550
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SpectatorCameraMoveSpeedRatioMax' 
	end end -- 0x554
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SpectatorCameraRotateSpeedRatioMin' 
	end end -- 0x558
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SpectatorCameraRotateSpeedRatioMax' 
	end end -- 0x55c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SpectatorCameraRotate360Time' 
	end end -- 0x560
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 LimitClothUnlockLevel' 
	end end -- 0x564
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean ChatChannelShowTitleEffects' 
	end end -- 0x568
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean IsNewPGCResRefEnabled' 
	end end -- 0x569
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean IsNewPGCTagDownloadEnabled' 
	end end -- 0x56a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SpectatorSoundRange' 
	end end -- 0x56c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UMAMeshOptimize' 
	end end -- 0x570
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single AirlineStartDistance' 
	end end -- 0x574
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballRadius' 
	end end -- 0x578
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballRadius_SnowMan' 
	end end -- 0x57c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballRadiusGrowUp' 
	end end -- 0x580
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballRadiusGrowUpSnowMan' 
	end end -- 0x584
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballRadiusMax' 
	end end -- 0x588
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballRadiusSnowManReborn' 
	end end -- 0x58c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballBackOffsetFactor' 
	end end -- 0x590
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballUpOffsetFactor' 
	end end -- 0x594
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballDuration' 
	end end -- 0x598
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballStartMinSpeed' 
	end end -- 0x59c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballStartMaxSpeed' 
	end end -- 0x5a0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballSpeedYFloor' 
	end end -- 0x5a4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballSpeedBounceFade' 
	end end -- 0x5a8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballSpeedBounceFadeAfterGoals' 
	end end -- 0x5ac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballSpeedBounceFadeXZ' 
	end end -- 0x5b0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballLauncherHAngleMax' 
	end end -- 0x5b4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballLauncherVAngleMax' 
	end end -- 0x5b8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballAdjustAccForward' 
	end end -- 0x5bc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballAdjustAccRight' 
	end end -- 0x5c0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballAdjustAccForward_SnowMan' 
	end end -- 0x5c4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballAdjustAccRight_SnowMan' 
	end end -- 0x5c8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballAdjustAccForward_RushingPets' 
	end end -- 0x5cc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballAdjustAccRight_RushingPets' 
	end end -- 0x5d0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballSpeedBounceFadeXZ_RushingPets' 
	end end -- 0x5d4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballRadiusGrowUp_RushingPets' 
	end end -- 0x5d8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FootballRadiusMax_RushingPets' 
	end end -- 0x5dc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String ANODefenceLevel' 
	end end -- 0x5e0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ANOLightInitOnThread' 
	end end -- 0x5e4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableCustom' 
	end end -- 0x5e5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 CarePackageMaxNum' 
	end end -- 0x5e8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean VehicleMissileUsingPlayerAimUI' 
	end end -- 0x5ec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean NewNotchForAndroid' 
	end end -- 0x5ed
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean LeavesNotchForAndroid' 
	end end -- 0x5ee
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single NotchForAndroidThreshold' 
	end end -- 0x5f0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single NotchSizeForAndroid' 
	end end -- 0x5f4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single NotchSizeForiOS' 
	end end -- 0x5f8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean AutoNotchForiOS' 
	end end -- 0x5fc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean AutoNotchForAndroid' 
	end end -- 0x5fd
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single AutoNotchSizeBiasForiOS' 
	end end -- 0x600
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single AutoNotchSizeBiasForAndroid' 
	end end -- 0x604
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String PGSRecallReadIPRegions_Mobile' 
	end end -- 0x608
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String PGSRecallReadIPRegions_HPE' 
	end end -- 0x60c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String PGSRecallWriteIPRegions_Mobile' 
	end end -- 0x610
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String PGSRecallWriteIPRegions_HPE' 
	end end -- 0x614
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CanEnemySeeActionCollection' 
	end end -- 0x618
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableVibrateFeature' 
	end end -- 0x619
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean NeedSignatureInfo' 
	end end -- 0x61a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean PanicButtonForLocalNotification' 
	end end -- 0x61b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int64 LocalNotificationStatsEventLogInterval' 
	end end -- 0x620
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 DaysOfNotifyForAll' 
	end end -- 0x628
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 DaysOfNotifyForRebateCards' 
	end end -- 0x62c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 DaysOfNotifyForFreeGacha' 
	end end -- 0x630
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableFirebase' 
	end end -- 0x634
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableFirebase_Messaging' 
	end end -- 0x635
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableFirebase_Analytics' 
	end end -- 0x636
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableFirebase_Crashlytics' 
	end end -- 0x637
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 FirebaseCrashlytics_LogTypes' 
	end end -- 0x638
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean FirebaseMessaging_UseUserProperties' 
	end end -- 0x63c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean FirebaseMesaging_UseTopics' 
	end end -- 0x63d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean disableCacheForFirebaseAnalytics' 
	end end -- 0x63e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean disableCacheForFirebaseMessaging' 
	end end -- 0x63f
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UseEventLogForFcmRmtNtfRecv' 
	end end -- 0x640
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowIAPBundleForIOSReview' 
	end end -- 0x641
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MinutesOfNotifyBeforeIAPBundleEnds' 
	end end -- 0x644
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MaxMinutesOfDelayForRebateCardsNotify' 
	end end -- 0x648
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MaxMinutesOfDelayForFreeGachaNotify' 
	end end -- 0x64c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MaxMinutesOfDelayForVeteranActivation' 
	end end -- 0x650
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MaxMinutesOfDelayForVeteranReminder' 
	end end -- 0x654
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MaxMinutesOfDelayForNewPlayerLevelUpTask' 
	end end -- 0x658
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MaxMinutesOfDelayForBooyahDayActivity' 
	end end -- 0x65c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MaxMinutesOfDelayForBigEventActivityStart' 
	end end -- 0x660
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MaxMinutesOfDelayForBigEventTemplateActivityStart' 
	end end -- 0x664
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MaxMinutesOfDelayForLiveTvNotify' 
	end end -- 0x668
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MaxMinutesOfDelayForEsportsAnnouncementNotify' 
	end end -- 0x66c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MaxMinutesOfDelayForClanWarNotify' 
	end end -- 0x670
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 DaysFromLastLoginForFriendReunion' 
	end end -- 0x674
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableVeteranBundle' 
	end end -- 0x678
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableNewPlayerBundle' 
	end end -- 0x679
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String FriendReunionUrl' 
	end end -- 0x67c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String AvatarGuildUrl' 
	end end -- 0x680
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 Ping1' 
	end end -- 0x684
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 Ping2' 
	end end -- 0x688
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean PingColor' 
	end end -- 0x68c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 PingCount' 
	end end -- 0x690
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 PingMaxValue' 
	end end -- 0x694
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String ShowTestXHRate' 
	end end -- 0x698
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String ShowTestXHRegion' 
	end end -- 0x69c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MTUFix' 
	end end -- 0x6a0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ObserverSwitchDelay' 
	end end -- 0x6a4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single TeamDefeatedDelay' 
	end end -- 0x6a8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MissileTraceLength' 
	end end -- 0x6ac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ScanAirLineTransparency' 
	end end -- 0x6b0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean SkinOnQualitySwitch' 
	end end -- 0x6b4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean TeammateSkinCheckMemorySwitch' 
	end end -- 0x6b5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean HudTeamAvoidSameUID' 
	end end -- 0x6b6
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleJoyStick_Range' 
	end end -- 0x6b8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleJoyStick_ThrottleAndBrakeDeadZoneAngle' 
	end end -- 0x6bc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleJoyStick_TurnDeadZoneAngleStart' 
	end end -- 0x6c0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleJoyStick_TurnDeadZoneAngleEnd' 
	end end -- 0x6c4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleJoyStick_LeftBaseVector_x' 
	end end -- 0x6c8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleJoyStick_LeftBaseVector_z' 
	end end -- 0x6cc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String APIToken' 
	end end -- 0x6d0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowEPTopPlayerOnAirplane' 
	end end -- 0x6d4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowEPRankingOnInHud' 
	end end -- 0x6d5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CanSwimSurfing' 
	end end -- 0x6d6
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PingTimeout' 
	end end -- 0x6d8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single TCPPingTimeout' 
	end end -- 0x6dc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleSkinHideDelay' 
	end end -- 0x6e0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowSkinOnQualityMiddle' 
	end end -- 0x6e4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UseAsyncSceneUnload' 
	end end -- 0x6e5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UseNewUnloadType' 
	end end -- 0x6e6
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UnloadType' 
	end end -- 0x6e8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UnloadMaxScene' 
	end end -- 0x6ec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UnloadMaxFreeMemory' 
	end end -- 0x6f0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UnloadMaxFreeMemoryIOS' 
	end end -- 0x6f4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UnloadProcessMemory' 
	end end -- 0x6f8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single UnloadProcessMemFreq' 
	end end -- 0x6fc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean OpenProcessMemUnload' 
	end end -- 0x700
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UnloadMaxUsedMemory' 
	end end -- 0x704
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single UnloadMaxWaitTime' 
	end end -- 0x708
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single UnloadMaxFreeMemFreq' 
	end end -- 0x70c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 AlarmtAvailMemorySize' 
	end end -- 0x710
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 CustomRoomSimulationInfoLevel' 
	end end -- 0x714
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableUMAGC' 
	end end -- 0x718
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableUMAGCOnIOS' 
	end end -- 0x719
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowEPOnWaitland' 
	end end -- 0x71a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowEPAvatarNormal' 
	end end -- 0x71b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowEPOnWaitForLow' 
	end end -- 0x71c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CardCloseTime' 
	end end -- 0x720
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ClanGroupInviteIconShowTime' 
	end end -- 0x724
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ClanGroupInviteCoolDownTime' 
	end end -- 0x728
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ClanWarNewsMapAutoScrollTime' 
	end end -- 0x72c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ClanWarShowProbability' 
	end end -- 0x730
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 ClanWarReadyCountDown' 
	end end -- 0x734
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 ClanWarMatchCD' 
	end end -- 0x738
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 ClanWarGroupMode' 
	end end -- 0x740
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean LogoutSDKOnBindSuccess' 
	end end -- 0x744
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String SecondaryRegionOn' 
	end end -- 0x748
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PickupInstantTime' 
	end end -- 0x74c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MallPurchaseMaxCount' 
	end end -- 0x750
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowHighFrameRateSetting' 
	end end -- 0x754
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ApplyNewRecommendQualitySettingRule' 
	end end -- 0x755
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowEnemyFireHint' 
	end end -- 0x756
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowEnemyFootStepHint' 
	end end -- 0x757
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowEnemyFireHintDefault' 
	end end -- 0x758
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowEnemyFootStepHintDefault' 
	end end -- 0x759
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MissileStartPosOffsetFactor' 
	end end -- 0x75c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean IOSTextureHDSupport' 
	end end -- 0x760
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean IsRedEnvelopeEnable' 
	end end -- 0x761
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 RedEnvelopeMaxPlantNumPerMatch' 
	end end -- 0x764
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableSparkEvent' 
	end end -- 0x768
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableFixBackMountWpInvisibleFor3P' 
	end end -- 0x769
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableTrainingModeExitTriggersWhenTeleport' 
	end end -- 0x76a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableCheckNullPlayerWhenIterator' 
	end end -- 0x76b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableForceDelPlayerWhenDestoryPlayerGO' 
	end end -- 0x76c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableFixRedAimingSpot' 
	end end -- 0x76d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableArrangeDestroyMultiplePlayer' 
	end end -- 0x76e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 VisibleFlagInWaitingRoom' 
	end end -- 0x770
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 VisibleFlagInWaitingRoomLow' 
	end end -- 0x778
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 VisibleFlagInWaitingRoomLowest' 
	end end -- 0x780
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 ClothFlagInSoloBrLowest' 
	end end -- 0x788
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 ClothFlagInBattleLow' 
	end end -- 0x790
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 ClothFlagInReapeLow' 
	end end -- 0x798
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 ClothFlagInBattleTeamLow' 
	end end -- 0x7a0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ClothCacheInWaitingRoomForLow' 
	end end -- 0x7a8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ClothesFlagsForIOSLowMem' 
	end end -- 0x7a9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean KeepClothFlagSameForBattleAndWaitingRoom' 
	end end -- 0x7aa
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean HideTeammateClothesForLowMemInWaitingRoomForBrMode' 
	end end -- 0x7ab
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean HideTeammateClothesForLowMemInBattleForBrMode' 
	end end -- 0x7ac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 ClothFlagInBattleFor32bitUltra' 
	end end -- 0x7b0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 ClothFlagInBattleTeamFor32bitUltra' 
	end end -- 0x7b8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 ClothFlagInBattleLowIOS' 
	end end -- 0x7c0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ClothCacheInWaitingRoomForLowIOS' 
	end end -- 0x7c8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 ClothFlagInBattleLowIOS12' 
	end end -- 0x7d0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ClothCacheInWaitingRoomForLowIOS12' 
	end end -- 0x7d8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 GachaCouponExpireInfoDaysLimit' 
	end end -- 0x7dc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 ANOEXT_SPLIT_THRESHOLD' 
	end end -- 0x7e0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UMA1PTextureScaleLow' 
	end end -- 0x7e4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UMA1PTextureScaleTeamLow' 
	end end -- 0x7e8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UMA1PTextureScaleLowIOS' 
	end end -- 0x7ec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UMA1PTextureScaleLowIOS12' 
	end end -- 0x7f0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UMA3PTextureScaleHD' 
	end end -- 0x7f4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UMA3PTextureScaleNormal' 
	end end -- 0x7f8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UMA3PTextureScaleLow' 
	end end -- 0x7fc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 ShangrilaMaxShowDays' 
	end end -- 0x800
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean Apply3PSkinOffSwitch' 
	end end -- 0x804
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 Apply3PSkinMask' 
	end end -- 0x808
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean OptimizePet' 
	end end -- 0x80c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean NoPetShowingForOtherTeamsTeammates' 
	end end -- 0x80d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean NoPet3PActiveAnimShowing' 
	end end -- 0x80e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ReleasePetAnimByRefCnt' 
	end end -- 0x80f
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean AsyncLoadPetAnim' 
	end end -- 0x810
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowTurtleDecreaseDamageArrow' 
	end end -- 0x811
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VehicleSpeedEulerPerKm' 
	end end -- 0x814
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SkyDivingTimeToOpenParachuteRebornDelta' 
	end end -- 0x818
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single RebornSkyDivingSpeedRate' 
	end end -- 0x81c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SkyDivingForceToOpenParachuteHeightRebornDelta' 
	end end -- 0x820
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MaxAP' 
	end end -- 0x824
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single RevengeInfoHintRange' 
	end end -- 0x828
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single DamageResistPerAP' 
	end end -- 0x82c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UIInvitationMiniMode' 
	end end -- 0x830
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableABHotUpdatesFileExistOptimize' 
	end end -- 0x831
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableABFileFindOptimize' 
	end end -- 0x832
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableHotUpdateInternalStorage' 
	end end -- 0x833
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 EnableFlagAutoStartDownload' 
	end end -- 0x834
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean OptionalDownloadOpenCantSaveWithoutFiles' 
	end end -- 0x838
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 OptionalDownloadMaxThreads' 
	end end -- 0x83c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 OptionalDownloadRepairTimeCD' 
	end end -- 0x840
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean OptionalDownloadFixOpen' 
	end end -- 0x844
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean OptionalDownloadHashCheckOpen' 
	end end -- 0x845
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 OptionalDownloadFixWndToastTimes' 
	end end -- 0x848
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 OptionalBackgroundDownloadThreadSleepTime' 
	end end -- 0x84c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean OptionalDeepFileCheck' 
	end end -- 0x850
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOverrideWithFullData' 
	end end -- 0x851
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableRimLighting' 
	end end -- 0x852
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 PetMotionLerpMaxTargetTickCount' 
	end end -- 0x854
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PetVisibleRange' 
	end end -- 0x858
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PetPlayButtonCD' 
	end end -- 0x85c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PetWanderSpeed' 
	end end -- 0x860
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PetRunSpeed' 
	end end -- 0x864
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PetDashSpeedScale' 
	end end -- 0x868
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean HideTeammatePet' 
	end end -- 0x86c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MinutesBetweenSendingCachedEventLogs' 
	end end -- 0x870
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean SpawnEventBonusAI' 
	end end -- 0x874
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CanEatMushroomDuringTransform' 
	end end -- 0x875
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableSnowFlake' 
	end end -- 0x876
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableMultiThreadDownload' 
	end end -- 0x877
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ClanPointsRankRequestIntervalTime' 
	end end -- 0x878
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single RTShadowDistance' 
	end end -- 0x87c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single RTShadowDistanceOnAndroid' 
	end end -- 0x880
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single RTShadowDistanceIfNotUsed' 
	end end -- 0x884
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean RTShadowV2' 
	end end -- 0x888
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean RTShadowLowResolution_Android' 
	end end -- 0x889
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean RTShadowLowResolution_IOS' 
	end end -- 0x88a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single LeaderBoardRequestCDTime' 
	end end -- 0x88c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single WeaponPowerLeaderBoardRequestCDTime' 
	end end -- 0x890
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 ClanWarRecruitCDTime' 
	end end -- 0x898
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean OpenWholeBodyAttackWeapon' 
	end end -- 0x8a0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single TrendAgentBVoteNextTime' 
	end end -- 0x8a4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single TrendAgentBVoteIntervalTime' 
	end end -- 0x8a8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean HD3PInWaitingRoom' 
	end end -- 0x8ac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single RTShadowNormalBias' 
	end end -- 0x8b0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableCharacterBackLight' 
	end end -- 0x8b4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableInGameAsyncPreload' 
	end end -- 0x8b5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableFrontEndGameAsyncPreload' 
	end end -- 0x8b6
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean FirstLoginNeedWaitePreload' 
	end end -- 0x8b7
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableAsyncGetTreasuryModel' 
	end end -- 0x8b8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableAsyncLoadAirDropModel' 
	end end -- 0x8b9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableFireFastWeaponStateFixed' 
	end end -- 0x8ba
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ModifyGrassUtrlaLODDist' 
	end end -- 0x8bb
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableSmallerGrassMesh' 
	end end -- 0x8bc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 PreloadCountPerFrame' 
	end end -- 0x8c0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MaxCDNDownloadCount' 
	end end -- 0x8c4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShouldClearCDNCoroutines' 
	end end -- 0x8c8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableShowTargetOnMap' 
	end end -- 0x8c9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableShowTargetOnHud' 
	end end -- 0x8ca
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single InvitationCDTime' 
	end end -- 0x8cc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single HighPingCountDownTime' 
	end end -- 0x8d0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single InvitationBlockTime' 
	end end -- 0x8d4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 RoomTickBlockTime' 
	end end -- 0x8d8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single WaitingRoom3PVolume' 
	end end -- 0x8dc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PVEGunVolume' 
	end end -- 0x8e0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DefaultAutoFire' 
	end end -- 0x8e4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableNewLocParse' 
	end end -- 0x8e5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableNewLocFix' 
	end end -- 0x8e6
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableNewUMABuild' 
	end end -- 0x8e7
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 WaitingIslandGiantEasterEggHp' 
	end end -- 0x8e8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single DurationForEatingChicken' 
	end end -- 0x8ec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UseUIHudPickupListControllerV2' 
	end end -- 0x8f0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CatapultHorizontalMinAngle' 
	end end -- 0x8f4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CatapultHorizontalMaxAngle' 
	end end -- 0x8f8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CatapultVerticalMinAngle' 
	end end -- 0x8fc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CatapultVerticalMaxAngle' 
	end end -- 0x900
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PropCatapultHorizontalMinAngle' 
	end end -- 0x904
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PropCatapultHorizontalMaxAngle' 
	end end -- 0x908
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PropCatapultVerticalMinAngle' 
	end end -- 0x90c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PropCatapultVerticalMaxAngle' 
	end end -- 0x910
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PropCatapultSpeed' 
	end end -- 0x914
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CannonHorizontalMinAngle' 
	end end -- 0x918
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CannonHorizontalMaxAngle' 
	end end -- 0x91c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CannonVerticalMinAngle' 
	end end -- 0x920
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CannonVerticalMaxAngle' 
	end end -- 0x924
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String MemoryCheckString' 
	end end -- 0x928
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FlashEffectScale' 
	end end -- 0x92c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String GER_SponsorId' 
	end end -- 0x930
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String GER_ApiKey' 
	end end -- 0x934
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single TcpBackgroundDeactiveTime_IOS' 
	end end -- 0x938
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single TcpBackgroundDeactiveTime_Android' 
	end end -- 0x93c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UdpReuseStreamWriter' 
	end end -- 0x940
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MapUpLength' 
	end end -- 0x944
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MapRightLength' 
	end end -- 0x948
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MapDownLength' 
	end end -- 0x94c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MapLeftLength' 
	end end -- 0x950
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 LowestQualityMemoryThre' 
	end end -- 0x954
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 IOSMemoryLevelLowThre' 
	end end -- 0x958
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MemoryLevelLowThre' 
	end end -- 0x95c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MemoryLevelMediumThre' 
	end end -- 0x960
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MemoryLevelHighThre' 
	end end -- 0x964
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MemoryLevelSuperHighThre' 
	end end -- 0x968
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowBooyahTvInLowMem' 
	end end -- 0x96c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 CloseTriBufMemThreshold' 
	end end -- 0x970
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 DisabelGhostShadowEffectMemoryLevelHighThre' 
	end end -- 0x974
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean IsTurnOnGhostShadowEffect' 
	end end -- 0x978
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableGoogleEngagementRewards' 
	end end -- 0x979
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String GoogleEngagementRewards_ElitePassPurchase' 
	end end -- 0x97c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single LobbyChatDispearDelay' 
	end end -- 0x980
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single LobbyChatShowTime' 
	end end -- 0x984
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 WorldChatLevelLimit' 
	end end -- 0x988
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 WorldChannelSendCD' 
	end end -- 0x990
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 WorldChannelVFXCD' 
	end end -- 0x998
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 MentoringChannelSendCD' 
	end end -- 0x9a0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single LiftTopMessageShowTime' 
	end end -- 0x9a8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single LiftTopMessageListShowTime' 
	end end -- 0x9ac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 ShowPrivateWarningCD' 
	end end -- 0x9b0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ChatClanLuckyBagMessageShowTime' 
	end end -- 0x9b4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 ChatBlockMaxCount' 
	end end -- 0x9b8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 FastRecruitValidTime' 
	end end -- 0x9c0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 ChatCharacterLimit' 
	end end -- 0x9c8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 RoomChatCharacterLimit' 
	end end -- 0x9cc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 ChatReportMaxTimes' 
	end end -- 0x9d0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 EsportsBubbleTweenDuration' 
	end end -- 0x9d4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 EsportsBubbleScrollTime' 
	end end -- 0x9d8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableNewAudioResource' 
	end end -- 0x9dc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean SimpleDamageCheckForAI' 
	end end -- 0x9dd
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 TreasureBoxMaxOpenCount' 
	end end -- 0x9e0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 PVEResurrectionCoinID' 
	end end -- 0x9e4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 ReviveTimeout' 
	end end -- 0x9e8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 PengdingReviveCamraTime' 
	end end -- 0x9ec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 LocalDeathCamraTime' 
	end end -- 0x9f0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 LocalPlayerDestroyDelayTime' 
	end end -- 0x9f4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableShowMaxHypePlayerPosInMap' 
	end end -- 0x9f8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableShowHypeEnemyHudLevel' 
	end end -- 0x9f9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableRankCardFeature' 
	end end -- 0x9fa
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GrapplingHookMinRange' 
	end end -- 0x9fc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GrapplingHookJumpHeightOffset' 
	end end -- 0xa00
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GrapplingHookPlayerMaxRadianHeightRange' 
	end end -- 0xa04
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GrapplingHookPlayerMaxRadianHeight' 
	end end -- 0xa08
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GrapplingHookPlayerMinSpeed' 
	end end -- 0xa0c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GrapplingHookPlayerMaxSpeed' 
	end end -- 0xa10
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GrapplingHookPlayerMinSpeedDist' 
	end end -- 0xa14
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GrapplingHookPlayerMaxSpeedDist' 
	end end -- 0xa18
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GrapplingHookPlayerSpeedReachFactor' 
	end end -- 0xa1c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FaithJumpingPlayerMaxRadianHeight' 
	end end -- 0xa20
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FaithJumpingPlayerG' 
	end end -- 0xa24
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MGSLockRadiusRate' 
	end end -- 0xa28
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MGSLockTime' 
	end end -- 0xa2c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MGSLockPreTime' 
	end end -- 0xa30
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single NoHeadshotTimeAfterPoseSwitch' 
	end end -- 0xa34
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean IsCrouchScatterOpen' 
	end end -- 0xa38
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CrouchScatterAngle' 
	end end -- 0xa3c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CrouchScatterTime' 
	end end -- 0xa40
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 ShootingTargetMaxHP' 
	end end -- 0xa44
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PriorityStepVolumeRate' 
	end end -- 0xa48
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptimizeUnZip' 
	end end -- 0xa4c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableParachutingBGM' 
	end end -- 0xa4d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String RebateCardSubscribableRegions_iOS' 
	end end -- 0xa50
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String RebateCardSubscribableRegions_Android' 
	end end -- 0xa54
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String EvoPassSubscribableRegions_iOS' 
	end end -- 0xa58
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String EvoPassSubscribableRegions_Android' 
	end end -- 0xa5c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String ElitePassSubscribableRegions_iOS' 
	end end -- 0xa60
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String ElitePassSubscribableRegions_Android' 
	end end -- 0xa64
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String SubscriptionBundleSubscribableRegions_iOS' 
	end end -- 0xa68
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String SubscriptionBundleSubscribableRegions_Android' 
	end end -- 0xa6c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String RecommitBeforePaymentRegions_iOS' 
	end end -- 0xa70
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String RecommitBeforePaymentRegions_Android' 
	end end -- 0xa74
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean PreventDuplicatePaymentAfterScanAndClear' 
	end end -- 0xa78
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOBBCheck' 
	end end -- 0xa79
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ForceShowNewVersionEP' 
	end end -- 0xa7a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowPaymentFailureSignature' 
	end end -- 0xa7b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowBlackWhiteEffect' 
	end end -- 0xa7c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FoldWingGlidingStartMinHeight' 
	end end -- 0xa80
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FoldWingGlidingAutoStopHeight' 
	end end -- 0xa84
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FoldWingGlidingManualStopMinTime' 
	end end -- 0xa88
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FoldWingGlidingHSpeed' 
	end end -- 0xa8c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FoldWingGlidingVSpeed' 
	end end -- 0xa90
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FoldWingFallingVSpeed' 
	end end -- 0xa94
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FoldWingGlidingAngleDelta' 
	end end -- 0xa98
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CCTCheckInterval' 
	end end -- 0xa9c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DynamicBoneRotateOptimize' 
	end end -- 0xaa0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DynamicBoneRotateUseNewPitch' 
	end end -- 0xaa1
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single DynamicBoneRotateMin' 
	end end -- 0xaa4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean SetGroundFor3P' 
	end end -- 0xaa8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean SetGroundOnlyInFrustum' 
	end end -- 0xaa9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean SetPosForInvisible3P' 
	end end -- 0xaaa
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 SubscribableBeforePreorder_Hours' 
	end end -- 0xaac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 SubscribableAfterPreorder_Hours' 
	end end -- 0xab0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PCAutoBattleCheckTimeInterval' 
	end end -- 0xab4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean PCAutoBattleTypeCheckDamage' 
	end end -- 0xab8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean PCAutoBattleTypeCheckKnockedDown' 
	end end -- 0xab9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 PCDelayOBSeconds' 
	end end -- 0xabc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowBRAndCSFinalKill' 
	end end -- 0xac0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MatchEndFinalKillTimeScale' 
	end end -- 0xac4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MatchEndFinalKillDuration' 
	end end -- 0xac8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single WhizBySoundHappenRate' 
	end end -- 0xacc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single WhizBySoundVolumeMin' 
	end end -- 0xad0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single WhizBySoundVolumeMax' 
	end end -- 0xad4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 OneShotLimitInOneFrame' 
	end end -- 0xad8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single RotationSensitivityMin' 
	end end -- 0xadc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single RotationSensitivityMax' 
	end end -- 0xae0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single AimRotationSensitivityMin' 
	end end -- 0xae4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single AimRotationSensitivityMax' 
	end end -- 0xae8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GooglePCRotationSensitivityMin' 
	end end -- 0xaec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GooglePCRotationSensitivityMax' 
	end end -- 0xaf0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single UGC1PSensitivitySettingDefault' 
	end end -- 0xaf4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SensitivityMaxSetting' 
	end end -- 0xaf8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single Sensitivity1PMaxSetting' 
	end end -- 0xafc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single X1ScopeMaxSetting' 
	end end -- 0xb00
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single X2ScopeMaxSetting' 
	end end -- 0xb04
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single X4ScopeMaxSetting' 
	end end -- 0xb08
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single X8ScopeMaxSetting' 
	end end -- 0xb0c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FreeLookMaxSetting' 
	end end -- 0xb10
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UseXG' 
	end end -- 0xb14
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DisableXGForLowMemoryLevel' 
	end end -- 0xb15
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UseXG_FCM' 
	end end -- 0xb16
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean IgnoreBigEventTemplateIfHaveBigEvent' 
	end end -- 0xb17
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableQualitySettingCache' 
	end end -- 0xb18
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 EnableLobbyHDRecipe' 
	end end -- 0xb1c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PlayerAssistantAudioCDTime' 
	end end -- 0xb20
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PlayerAssistantItemMarkTime' 
	end end -- 0xb24
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PlayerAssistantItemMarkDistance' 
	end end -- 0xb28
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PlayerAssistantItemMarkCDTime' 
	end end -- 0xb2c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single InGameItemMarkAlphaThreshold' 
	end end -- 0xb30
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single InGameItemMarkAlphaValue' 
	end end -- 0xb34
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single InGameItemMarkOneClickInterval' 
	end end -- 0xb38
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single InGameThumbUpStayTime' 
	end end -- 0xb3c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UseSniperCollider' 
	end end -- 0xb40
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 ChampionshipContactIDMaxLength' 
	end end -- 0xb44
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 ChampionshipTeamInfoEditCoolDown' 
	end end -- 0xb48
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 ChampionLeaderboardCD' 
	end end -- 0xb50
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 SetFriendAliasCD' 
	end end -- 0xb58
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean WebViewPromptFaulty' 
	end end -- 0xb60
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean WebViewFallbackToBrowser' 
	end end -- 0xb61
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean WebViewDeferredDisplay' 
	end end -- 0xb62
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single WebViewLoadingProgressAnimationDuration' 
	end end -- 0xb64
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single WebViewPromptReloadDuration' 
	end end -- 0xb68
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single webViewProgressBarLaunchPercentage' 
	end end -- 0xb6c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single webViewProgressBarLaunchDuration' 
	end end -- 0xb70
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String webViewProgressTextLaunchColor' 
	end end -- 0xb74
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String webViewProgressTextLoadColor' 
	end end -- 0xb78
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean IngameAvatarPoolDynamicEffects' 
	end end -- 0xb7c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean LobbyAvatarMateriaAnimEffects' 
	end end -- 0xb7d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean IngameAvatarMateriaAnimEffects' 
	end end -- 0xb7e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single TeamBarStrikeDownIconShowTime' 
	end end -- 0xb80
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String KillNotificationTeamSoundTime' 
	end end -- 0xb84
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DoFixBugDonotInitUIState' 
	end end -- 0xb88
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DoFixMatchEndWinnerQuit' 
	end end -- 0xb89
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DoFixOBReconnectLocalMatchEnd' 
	end end -- 0xb8a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DoFixClearTriggersOnRevive' 
	end end -- 0xb8b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DoFixStuckWhenKnockdownDuringCrossover' 
	end end -- 0xb8c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UIGroupSwitchUsePos' 
	end end -- 0xb8d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UIGroupSwitchOpt' 
	end end -- 0xb8e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single STREAMING_TILE_STREAMING_RANGE' 
	end end -- 0xb90
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single STREAMING_TILE_SIZE_X' 
	end end -- 0xb94
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single STREAMING_TILE_SIZE_Y' 
	end end -- 0xb98
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single STREAMING_TILE_SIZE_Z' 
	end end -- 0xb9c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 NeedPingIDCDelayThreshold' 
	end end -- 0xba0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UseLiveScreen' 
	end end -- 0xba4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PaintSprayerFloatingCheckMaxDiffuse' 
	end end -- 0xba8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PaintSprayerOutNormalDistance' 
	end end -- 0xbac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PaintSprayerShowDelay' 
	end end -- 0xbb0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowGrowManual' 
	end end -- 0xbb4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableFoliageSupportScreenShot' 
	end end -- 0xbb5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean PVPFireShakeEnable' 
	end end -- 0xbb6
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean PVEFireShakeEnable' 
	end end -- 0xbb7
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 CSFactionShowTime' 
	end end -- 0xbb8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CSFactionDelayTime' 
	end end -- 0xbbc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FactionShowTime' 
	end end -- 0xbc0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single BombFactionShowTime' 
	end end -- 0xbc4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String ArabicExtraString' 
	end end -- 0xbc8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single HighQualityOptionalSpeedScale' 
	end end -- 0xbcc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single HighQualityOptionalSpeedScaleLimit' 
	end end -- 0xbd0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MiddleQualityOptionalSpeedScale' 
	end end -- 0xbd4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MiddleQualityOptionalSpeedScaleLimit' 
	end end -- 0xbd8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single LowQualityOptionalSpeedScale' 
	end end -- 0xbdc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single LowQualityOptionalSpeedScaleLimit' 
	end end -- 0xbe0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single OptionalSpeedUpDelay' 
	end end -- 0xbe4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 GetTeamMatchStatsHistoryCacheTime' 
	end end -- 0xbe8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CSShopDelayClose' 
	end end -- 0xbf0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String WebViewJavaScriptName' 
	end end -- 0xbf4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean WebViewRunJavaScript' 
	end end -- 0xbf8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableUnloadUnusedAssetAfterSplash' 
	end end -- 0xbf9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SetMusicVolumeOnPlayAvatarVoice' 
	end end -- 0xbfc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 HealingDanceEmoteID' 
	end end -- 0xc00
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single HealingDanceAudioLength' 
	end end -- 0xc04
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single DistanceWithDownloadEffectControl' 
	end end -- 0xc08
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single DownloadEffectDuration' 
	end end -- 0xc0c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FindTreasureMapTime' 
	end end -- 0xc10
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FindFoxToriiTime' 
	end end -- 0xc14
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 EnableGuideRegisterDay' 
	end end -- 0xc18
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 EnableGuideLevel' 
	end end -- 0xc1c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableSafeZoneExistOnMapWhenShrinkEnd' 
	end end -- 0xc20
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ThresholdSafeZoneMinRadiusWhenShrinkEnd' 
	end end -- 0xc24
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single BattleFlagSpawnDistanceForward' 
	end end -- 0xc28
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single BattleFlagSpawnDistanceRight' 
	end end -- 0xc2c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single BattleFlagSpawnDistanceUp' 
	end end -- 0xc30
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single BattleFlagDirectionRightOffset' 
	end end -- 0xc34
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableLobbyBgRotate' 
	end end -- 0xc38
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean HasOptionalAbs' 
	end end -- 0xc39
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CheckOptionalInLauncher' 
	end end -- 0xc3a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadVoice' 
	end end -- 0xc3b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadMap' 
	end end -- 0xc3c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadPet' 
	end end -- 0xc3d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalFullScreenCG' 
	end end -- 0xc3e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalAvatar' 
	end end -- 0xc3f
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloaEmotion' 
	end end -- 0xc40
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadMap1' 
	end end -- 0xc41
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadMap1HD' 
	end end -- 0xc42
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadMap2' 
	end end -- 0xc43
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadMap4' 
	end end -- 0xc44
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadMap4HD' 
	end end -- 0xc45
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadCloth' 
	end end -- 0xc46
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadWerewolves' 
	end end -- 0xc47
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadRushB' 
	end end -- 0xc48
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadRushingPets' 
	end end -- 0xc49
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadNewBlast' 
	end end -- 0xc4a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadSingersB' 
	end end -- 0xc4b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadHuntingGround' 
	end end -- 0xc4c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadInGameRes' 
	end end -- 0xc4d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableUGCCustomRes' 
	end end -- 0xc4e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DisableUGC1PModelShadow' 
	end end -- 0xc4f
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadMapMax' 
	end end -- 0xc50
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadLudo' 
	end end -- 0xc51
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadLobbyResource' 
	end end -- 0xc52
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadInfection' 
	end end -- 0xc53
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadFootball' 
	end end -- 0xc54
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadUGC' 
	end end -- 0xc55
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadTraining' 
	end end -- 0xc56
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadSocial' 
	end end -- 0xc57
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadLoneWolf' 
	end end -- 0xc58
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadLoneWolfStrikeOut' 
	end end -- 0xc59
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadMapHippo' 
	end end -- 0xc5a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadMapHippoVersionCheck' 
	end end -- 0xc5b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadMapHippoVersionCheckInIOS' 
	end end -- 0xc5c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadMapHippoVersionCheckHD' 
	end end -- 0xc5d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadMapHippoVersionCheckHDInIOS' 
	end end -- 0xc5e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadMapHippoVersionCheckTrail' 
	end end -- 0xc5f
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableOptionalDownloadSnowDuel' 
	end end -- 0xc60
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableBackgroundDownloadLocalNotify' 
	end end -- 0xc61
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableReCheckOptional' 
	end end -- 0xc62
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DisableTerrainBlendingShadow' 
	end end -- 0xc63
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 VehicleNetworkSpeedQueueCount' 
	end end -- 0xc64
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean VehicleSeatsSetVisible' 
	end end -- 0xc68
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean VehicleTeleportWhenSetVisible' 
	end end -- 0xc69
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean PlayerTeleportWhenSetVisible' 
	end end -- 0xc6a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableMambetUnityVoiceCapture' 
	end end -- 0xc6b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableMambetExternalVoiceCapture' 
	end end -- 0xc6c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableFreeFireVoiceMemberChanged' 
	end end -- 0xc6d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single LudoLocalPlayerHeadInfoScale' 
	end end -- 0xc70
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UnLoadNoCacheConfigText' 
	end end -- 0xc74
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowMallGround' 
	end end -- 0xc75
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnabledSortInventory' 
	end end -- 0xc76
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnabledFixInventory' 
	end end -- 0xc77
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single NetworkDetectionCDTime' 
	end end -- 0xc78
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 WinNeedFinishChessNumber' 
	end end -- 0xc7c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 WinNeedFinishPlayerNumber' 
	end end -- 0xc80
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single TrainingMode_ShowPlayerListRange' 
	end end -- 0xc84
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean TrainingMode_EnableWeatherTime' 
	end end -- 0xc88
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean TrainingMode_Build1PImmediately' 
	end end -- 0xc89
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single TrainingWeaponVolumeInSocial' 
	end end -- 0xc8c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableCrossFrameUpdate' 
	end end -- 0xc90
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableCrossFrameUpdateForMax' 
	end end -- 0xc91
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean FastUmaReadyForAnimCrossFrameUpdate' 
	end end -- 0xc92
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 CrossFrameUpdateQualityLevel' 
	end end -- 0xc94
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 CrossFrameDistQualityLevel' 
	end end -- 0xc98
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 CrossFrameUpdateInterval' 
	end end -- 0xc9c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CrossFrameDistThresholdSqr' 
	end end -- 0xca0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UnloadPreviewDataSwitch' 
	end end -- 0xca4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean Android32BitMallCloseClearMemory' 
	end end -- 0xca5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean LowMemoryPhoneClearAssetInFrontend' 
	end end -- 0xca6
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean LowMemoryPhoneClearCDN' 
	end end -- 0xca7
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean Android32BitClearCDN' 
	end end -- 0xca8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean LowMemoryPhoneSkipGachaFullCG' 
	end end -- 0xca9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean LowMemoryPhoneClearAssetsForPreview3DModel' 
	end end -- 0xcaa
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ClearCDNCacheAfterAutoTask' 
	end end -- 0xcab
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ClearUnusedAssetsAfterSplashBannerForAllPlatform' 
	end end -- 0xcac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean IsLobbyGachaConfirmWndDifferent' 
	end end -- 0xcad
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MovieLevelOpeningTimepoint' 
	end end -- 0xcb0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 VeteranReminderDays' 
	end end -- 0xcb4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single AutoOpenBoxBundleVFXTime' 
	end end -- 0xcb8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean NeedUIBGGlassBlur' 
	end end -- 0xcbc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean NeedUIGrabScene' 
	end end -- 0xcbd
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String AndroidTryFixingSubscriptionOnHoldURL' 
	end end -- 0xcc0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String FastTipsUrl' 
	end end -- 0xcc4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String AndroidTryFixingSubscriptionGracePeriodURL' 
	end end -- 0xcc8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 SubscriptionGracePeriodReminderWindowDismissCountdown_S' 
	end end -- 0xccc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 Team1Index' 
	end end -- 0xcd0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 Team2Index' 
	end end -- 0xcd4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String Team1ColorStr' 
	end end -- 0xcd8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String Team2ColorStr' 
	end end -- 0xcdc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String DefaultTeamColorStr' 
	end end -- 0xce0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String MovieLevelOpeningRegions_IOS' 
	end end -- 0xce4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String MovieLevelOpeningRegions_Android' 
	end end -- 0xce8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String NewBackButtonStyleRegion' 
	end end -- 0xcec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String AndroidSensityParams' 
	end end -- 0xcf0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String IosSensityParams' 
	end end -- 0xcf4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String GooglePCSensityParams' 
	end end -- 0xcf8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String UseNewDeathCameraMode' 
	end end -- 0xcfc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String CrashTipMapList' 
	end end -- 0xd00
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String BugReportDisabledIPRegions' 
	end end -- 0xd04
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String ANODisabledRegions' 
	end end -- 0xd08
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String ANODisabledClientVariant' 
	end end -- 0xd0c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String ANOEmulatorCheckDisbaledClientVariant' 
	end end -- 0xd10
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean NeedFirstGuideMatch' 
	end end -- 0xd14
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FirstGuideMatchMakingDuration' 
	end end -- 0xd18
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 FirstGuideMatchMapID' 
	end end -- 0xd1c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 FirstGuideMatchMode' 
	end end -- 0xd20
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 FirstGuideMatchGameMode' 
	end end -- 0xd24
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean IsBrScoreboardGuideOpen' 
	end end -- 0xd28
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean IsCsNewScoreboardOpen' 
	end end -- 0xd29
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ScoreBoardOpenTime' 
	end end -- 0xd2c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 TutorialBRMapID' 
	end end -- 0xd30
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 TutorialBRMatchMode' 
	end end -- 0xd34
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 TutorialBRGameMode' 
	end end -- 0xd38
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 TutorialBRLobbyGuideMaskPR' 
	end end -- 0xd3c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single TutorialBRShrinkZoneSecondsAfterSoloGame' 
	end end -- 0xd40
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String TutorialsWontShowAfterTutorialSingleGame' 
	end end -- 0xd44
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String PickupListNewMode' 
	end end -- 0xd48
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean NeedTutorialCSMatch' 
	end end -- 0xd4c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 TutorialCSMapID' 
	end end -- 0xd50
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 TutorialCSMatchMode' 
	end end -- 0xd54
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 TutorialCSGameMode' 
	end end -- 0xd58
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single TutorialCSPathArrowHideDelay' 
	end end -- 0xd5c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single TutorialCSPathArrowInterval' 
	end end -- 0xd60
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 RelaunchDelayAfterObbDownloadedMS' 
	end end -- 0xd64
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableForceGC' 
	end end -- 0xd68
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 ForceGCCount' 
	end end -- 0xd6c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableClearAllLoadedResourceAfterCleanAssets' 
	end end -- 0xd70
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean NeedOptimizeCSVInMemory' 
	end end -- 0xd71
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean NeedOptimizeCSVInMemoryAll' 
	end end -- 0xd72
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean NeedOptimizeCSVInMemory32Bit' 
	end end -- 0xd73
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean NeedOptimizeBundle32Bit' 
	end end -- 0xd74
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ShowNewTutorial' 
	end end -- 0xd75
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 NicknameLengthMin' 
	end end -- 0xd78
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 EffectPoolMaxSize' 
	end end -- 0xd7c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableBundleOptimize' 
	end end -- 0xd80
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableUGCOutline' 
	end end -- 0xd81
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single HoverBoardAniBlendSpeed' 
	end end -- 0xd84
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single HB_DoubleJumpInterval' 
	end end -- 0xd88
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single HB_CheckSkateboardJumpInterval' 
	end end -- 0xd8c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single TutorialDefaultDuration' 
	end end -- 0xd90
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 TutoEpInfoVal' 
	end end -- 0xd94
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single TutoBagNotEnoughProportion' 
	end end -- 0xd98
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean OptimzeNGUIVisible' 
	end end -- 0xd9c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean OptimzeNGUIAlpha' 
	end end -- 0xd9d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableDesertStorm' 
	end end -- 0xd9e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean GameModeUseMediumSize' 
	end end -- 0xd9f
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MultiDownloadGCIndex' 
	end end -- 0xda0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean NeedInitFileLength' 
	end end -- 0xda4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 FrontEndLowMemCDNCountThreshold' 
	end end -- 0xda8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 FrontEndLowMemCGCountThreshold' 
	end end -- 0xdac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 FrontEndLowMemUMACountThreshold' 
	end end -- 0xdb0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 FrontEndLowMemPreview3dModelCountThreshold' 
	end end -- 0xdb4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableCDNDownloadOptimized' 
	end end -- 0xdb8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableCDNLocalLoadOptimized' 
	end end -- 0xdb9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UseFixedPointGetTextureData' 
	end end -- 0xdba
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UseSmallRtForMatchEndPlayer' 
	end end -- 0xdbb
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ResultPlayerAvatarDelayRelease' 
	end end -- 0xdbc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ResultPlayerAvatarRelease' 
	end end -- 0xdbd
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ResultPlayerAnimRelease' 
	end end -- 0xdbe
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableMatchResultReleaseMemoryOnlyLowMemory' 
	end end -- 0xdbf
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ReleaseResourcesOnMatchEndForLowMemory' 
	end end -- 0xdc0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DeleteDcsOnReleaseResourcesForMatchEnd' 
	end end -- 0xdc1
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ReleaseLightmapMemoryFor64bitHigh' 
	end end -- 0xdc2
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ReleaseLightmapMemoryFor64bitHigh_IOS' 
	end end -- 0xdc3
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ReleaseLightmapMemoryOnUnloading' 
	end end -- 0xdc4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ReleaseLightmapMemoryOnUnloading_IOS' 
	end end -- 0xdc5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ReleaseAssetsOnUnload' 
	end end -- 0xdc6
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ResultPlayerAvatarReleaseFor32bit' 
	end end -- 0xdc7
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ResultPlayerAvatarReleaseForIOSLowMem' 
	end end -- 0xdc8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableMatchResultReleaseMemoryLowSetting' 
	end end -- 0xdc9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableInGameUIDontDestroy' 
	end end -- 0xdca
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DontDestroyABNotUnLoad' 
	end end -- 0xdcb
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean MaualGcWhenCloseInGameAutoGC' 
	end end -- 0xdcc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean LoadLoadingSceneWaitEndOfFrame_1' 
	end end -- 0xdcd
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean LoadLoadingSceneWaitEndOfFrame_2' 
	end end -- 0xdce
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean LoadGameProcessWaitEndOfFrame_1' 
	end end -- 0xdcf
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean LoadGameProcessWaitEndOfFrame_2' 
	end end -- 0xdd0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean LoadLoadingSceneSyncLoadGameProcess' 
	end end -- 0xdd1
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean StopAsyncLoadWhenIsLoading' 
	end end -- 0xdd2
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 SyncLoadUmasCount' 
	end end -- 0xdd4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 AsyncLoadCount' 
	end end -- 0xdd8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean AsyncLoadCountLimit' 
	end end -- 0xddc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean AsyncCallBackTimeLimit' 
	end end -- 0xddd
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableAsyncLoadVehicleBeyond100m' 
	end end -- 0xdde
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean LoadLoadingSceneSingleNoGc' 
	end end -- 0xddf
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean LoadGameSceneSingleNoGc' 
	end end -- 0xde0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DisableApplyTexturUnloadUnusedAssets' 
	end end -- 0xde1
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 AsyncCallBackTime' 
	end end -- 0xde4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 AsyncCallBackTimeCabin' 
	end end -- 0xde8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean PoolManagerCallBackTimeLimit' 
	end end -- 0xdec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 PoolManagerCallBackTime' 
	end end -- 0xdf0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 PoolManagerCallBackTimeCabin' 
	end end -- 0xdf4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnablecCabinLimitTime' 
	end end -- 0xdf8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CacheAnimtiorCtrl_Fist' 
	end end -- 0xdf9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean StreamerStaticHandlerTimeLimit' 
	end end -- 0xdfa
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 StreamerStaticDefaultHandlerTime' 
	end end -- 0xdfc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean StreamerStaticHandlerFinishImmediate' 
	end end -- 0xe00
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ReleaseMemOnCsRoundChangeForUltraQuality32bitNonAbScene' 
	end end -- 0xe01
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single CsRoundLowMemThresholdGB' 
	end end -- 0xe04
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ForceGCOnCsRoundChangeForLowMemory' 
	end end -- 0xe08
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ReleaseMemOnCsRoundChangeForLowMemoryNonAbScene' 
	end end -- 0xe09
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UseSmallOverlayTextureFor32bitIOSLowMem' 
	end end -- 0xe0a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UseSmallOverlayTextureFor32bitInGameNonTeammate' 
	end end -- 0xe0b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean NotShowingTeammatePetFor32Bit' 
	end end -- 0xe0c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean NotShowingTeammatePetFor32BitIOSLowMem' 
	end end -- 0xe0d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean NotShowingEnemyCollectionResFor32Bit' 
	end end -- 0xe0e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean NotPlay3PNonTeammateEmoteFor32Bit' 
	end end -- 0xe0f
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableForceMiddleQualityFor32Bit' 
	end end -- 0xe10
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ChecksOverlayInSlotBeforeResource' 
	end end -- 0xe11
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMARenderTextureGetTemporaryFor32Bit' 
	end end -- 0xe12
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMARenderTextureGetTemporaryFor64Bit' 
	end end -- 0xe13
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DisableWhiteScreenFor32Bit' 
	end end -- 0xe14
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UseRTGetTemporary' 
	end end -- 0xe15
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 DefaultGlobalMaximumLOD' 
	end end -- 0xe18
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 DefaultGlobalMaximumLODFor32Bit' 
	end end -- 0xe1c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UseLodWarmUp' 
	end end -- 0xe20
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 ClanIDLengthMax' 
	end end -- 0xe24
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CountFpsByFrame' 
	end end -- 0xe28
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean LevelContainerBaseInventoryListDirtyUpdate' 
	end end -- 0xe29
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableUIHudItemMarkBtn' 
	end end -- 0xe2a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MapMarkCloseDelayTime' 
	end end -- 0xe2c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single HudNameEnemyKnifeDelayTime' 
	end end -- 0xe30
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single HudNameEnemyRemoveDelayTime' 
	end end -- 0xe34
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FreeLookCameraSensitivityScale' 
	end end -- 0xe38
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FreeLookCameraSensitivityScaleOnVehicle' 
	end end -- 0xe3c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean FollowCameraRightTraceCameraCollision' 
	end end -- 0xe40
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ANOSDKDetailEncryptBySHA1' 
	end end -- 0xe41
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 BlocklistMaxNum' 
	end end -- 0xe44
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 RefAllAvailableNum' 
	end end -- 0xe48
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MaxRecentPlayersCount' 
	end end -- 0xe4c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 RefreshPlayerPresenceCD' 
	end end -- 0xe50
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 RefreshPlayerPresenceForceCD' 
	end end -- 0xe54
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableCheckFileStates' 
	end end -- 0xe58
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 AmountToAddFriendByContinuousTalk' 
	end end -- 0xe5c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 GroupInviteRefreshTimeCD' 
	end end -- 0xe60
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 GroupChangepublicCD' 
	end end -- 0xe68
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 ProfileSettingCD' 
	end end -- 0xe70
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt64 DressUpClickCD' 
	end end -- 0xe78
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 ProfileInputMaxLength' 
	end end -- 0xe80
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UUGProfileInputMaxLength' 
	end end -- 0xe84
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean ClearReplicationPool' 
	end end -- 0xe88
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CanAddFriendTabRefreshState' 
	end end -- 0xe89
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DisableItemOutline' 
	end end -- 0xe8a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GlideDistAfterGrapplingHookMax' 
	end end -- 0xe8c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GlideSpeedAfterGrapplingHook' 
	end end -- 0xe90
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GlideAngleAfterGrapplingHook' 
	end end -- 0xe94
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MVEPlayerMaxRadianHeight' 
	end end -- 0xe98
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean RemoveUIRigidbody' 
	end end -- 0xe9c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ImmediateRemoveUIRigidbody' 
	end end -- 0xe9d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ImmediateRemoveUIRigidbodyUsingDestroy' 
	end end -- 0xe9e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UseUITextureClipper' 
	end end -- 0xe9f
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UseUILabelCheckCharBeforeShape' 
	end end -- 0xea0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UMAReleaseDataOnRaceChange' 
	end end -- 0xea1
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UMAUsingAvatarSimple' 
	end end -- 0xea2
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UMAPreAsyncLoading' 
	end end -- 0xea3
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAUseSharedSbStrForUrl' 
	end end -- 0xea4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAUseMutableStringForUrl' 
	end end -- 0xea5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAAsyncLoadingLobby' 
	end end -- 0xea6
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAAsyncLoadingLobbyOnce' 
	end end -- 0xea7
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAAsyncLoadingInGame1P' 
	end end -- 0xea8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAAsyncLoadingInGame3P' 
	end end -- 0xea9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMATryLoadOnSetSlot' 
	end end -- 0xeaa
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAReAddBaseSlotsWhenLoadFailed' 
	end end -- 0xeab
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMASkipBuildIfNotVisibleV2' 
	end end -- 0xeac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMASkipBuildIfNotVisible' 
	end end -- 0xead
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMASkipBuildIfNoVisibleChange' 
	end end -- 0xeae
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMANoSkipForceUpdateAfterBuild' 
	end end -- 0xeaf
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMABlitForRT' 
	end end -- 0xeb0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMADrawTextureForRT' 
	end end -- 0xeb1
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMARefCntInLobby' 
	end end -- 0xeb2
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean BuildAfterWardrobeSlotsLoadedProtect' 
	end end -- 0xeb3
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAPoolSlotOverlays' 
	end end -- 0xeb4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAPoolSlotOverlaysFixMatch' 
	end end -- 0xeb5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAOptBuildGc' 
	end end -- 0xeb6
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAUnsafeParseRecipeData' 
	end end -- 0xeb7
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAFixNoClothTextureMergeForAdditive' 
	end end -- 0xeb8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMALobbyTeammateScaleNormalSpecTex' 
	end end -- 0xeb9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMALowMemLobbyScaleNormalSpecTex' 
	end end -- 0xeba
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMALowMemInGameScaleNormalSpecTex' 
	end end -- 0xebb
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMA32BitInGameScaleNormalSpecTex' 
	end end -- 0xebc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMA32BitInGameScaleDiffuseTex' 
	end end -- 0xebd
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAIOSLowMemInGameScaleDiffuseTex' 
	end end -- 0xebe
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMALowMemLobby1PUsingRGBA565' 
	end end -- 0xebf
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMALowMemLobby3PUsingRGBA565' 
	end end -- 0xec0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMALowMemInGame1PUsingRGBA565' 
	end end -- 0xec1
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMALowMemInGame3PUsingRGBA565' 
	end end -- 0xec2
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean BetterListUsePool' 
	end end -- 0xec3
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean BetterListPoolClearBuffer' 
	end end -- 0xec4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAInGameReleaseByRefCountForLow' 
	end end -- 0xec5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAInGameReleaseByRefCountForLowest' 
	end end -- 0xec6
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAInGameReleaseByRefCountForUltra' 
	end end -- 0xec7
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableAstcAbForEtc' 
	end end -- 0xec8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAInGameClearSlotMeshes' 
	end end -- 0xec9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAInGameReleaseSlotMeshes' 
	end end -- 0xeca
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAInGameReleaseOverlayTextures' 
	end end -- 0xecb
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAEnableHeadAdditiveFlow' 
	end end -- 0xecc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMANoTextureMergeFor1P' 
	end end -- 0xecd
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMANoClothTextureMergeForLow1P' 
	end end -- 0xece
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAUpdateLoobyTextureSize' 
	end end -- 0xecf
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAFastGenerationInGame' 
	end end -- 0xed0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAReuseDynamicBoneInGame' 
	end end -- 0xed1
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAReuseMaterial' 
	end end -- 0xed2
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UMATryFixNullMatChannels' 
	end end -- 0xed4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UMAOptGc' 
	end end -- 0xed8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean OptLocLoadingGc' 
	end end -- 0xed9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UseLocBytes' 
	end end -- 0xeda
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean SpawnPoolOptAsyncGc' 
	end end -- 0xedb
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean SAPLand_HideScenes' 
	end end -- 0xedc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CabinWaiting_UmaSkipBuildForNotVisible' 
	end end -- 0xedd
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CabinWaiting_HideScenes' 
	end end -- 0xede
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CabinWaiting_StopStreamerUpdate' 
	end end -- 0xedf
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CabinWaiting_SetOnBoardBeforeSetVisible' 
	end end -- 0xee0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CabinWaiting_PreloadInvisiblePlayerClothes32Bit' 
	end end -- 0xee1
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CabinWaiting_PreloadInvisiblePlayerClothes64Bit' 
	end end -- 0xee2
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CabinWaiting_PreloadInvisiblePlayerClothesIOSMem' 
	end end -- 0xee3
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CabinWaiting_AsyncPreloadInvisiblePlayerClothes' 
	end end -- 0xee4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CabinWaiting_PreloadTeammateClothesForLowMem' 
	end end -- 0xee5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CabinWaiting_PreloadAirplaneModel' 
	end end -- 0xee6
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CabinWaiting_NoCrossFrameUpdateAnimator' 
	end end -- 0xee7
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CabinWaiting_Gc' 
	end end -- 0xee8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CabinWaiting_NoRequestStopEmotion' 
	end end -- 0xee9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CabinWaiting_ShowWeaponSkin' 
	end end -- 0xeea
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 CabinWaiting_DelayCloseMaskFrames' 
	end end -- 0xeec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CabinWaiting_ClearAllLoadedResource' 
	end end -- 0xef0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CabinWaiting_CancelAsyncLoadings' 
	end end -- 0xef1
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CabinWaiting_CancelUmaAsyncLoadings' 
	end end -- 0xef2
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CabinWaiting_DestroyCabinImmidiately' 
	end end -- 0xef3
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CabinWaiting_DestroyCabinColliders' 
	end end -- 0xef4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean CabinWaiting_UnloadBgmForLowMem' 
	end end -- 0xef5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean SetFireLayersOnInitCollider' 
	end end -- 0xef6
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean SkateboardChangeRaycastCheckOb32' 
	end end -- 0xef7
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean SkateboardBlendMoveSoundsFor3P' 
	end end -- 0xef8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean HoverboardGetOnByGs' 
	end end -- 0xef9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableInGameJoinVoiceRoomAfterPlayerAdd' 
	end end -- 0xefa
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableInGameReturnToLobbyPopupMsg' 
	end end -- 0xefb
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableReconnectIfReachMaxResendCount' 
	end end -- 0xefc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 ReconnectTimesIfReachMaxResendCount' 
	end end -- 0xf00
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 ReconnectConfirmMaxDelayAllowed' 
	end end -- 0xf04
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableReconnectIfJoinMatchTimeout' 
	end end -- 0xf08
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableReconnectIfInGameDisconnect' 
	end end -- 0xf09
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DropMatchIfLoadingFailed' 
	end end -- 0xf0a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableWaitingRoomOverrideBagPack' 
	end end -- 0xf0b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableButtonDisableForKnockDown' 
	end end -- 0xf0c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 ResolutionReduceType' 
	end end -- 0xf10
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ResolutionReduceRate' 
	end end -- 0xf14
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String ResolutionReduceRegions' 
	end end -- 0xf18
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ChangeResolutionOnAppPause' 
	end end -- 0xf1c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ResolutionHeightReduceRateLow' 
	end end -- 0xf20
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableMinResolutionHeightLow' 
	end end -- 0xf24
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MinResolutionHeightLow' 
	end end -- 0xf28
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ResolutionHeightReduceRateLowSp' 
	end end -- 0xf2c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableMinResolutionHeightLowSp' 
	end end -- 0xf30
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MinResolutionHeightLowSp' 
	end end -- 0xf34
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean ForceBlitTypeAlways' 
	end end -- 0xf38
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 BlitTypeNeverMinAPILevel' 
	end end -- 0xf3c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean Skill_PlayerSkillTransform_VisibleChange' 
	end end -- 0xf40
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean Skill_BloodPoolOrb_VisibleChange' 
	end end -- 0xf41
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean Skill_LevelSpaceShield_VisibleChange' 
	end end -- 0xf42
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean Skill_LevelSkylerSkillBombArea_VisibleChange' 
	end end -- 0xf43
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean Skill_LevelGraffitiMonitor_VisibleChange' 
	end end -- 0xf44
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean Skill_LevelThrowSilenceBall_VisibleChange' 
	end end -- 0xf45
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean Skill_LevelSilenceZone_VisibleChange' 
	end end -- 0xf46
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean Skill_LevelAutoFlightBomb_VisibleChange' 
	end end -- 0xf47
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean Skill_PlayerSkillDetective_VisibleChange' 
	end end -- 0xf48
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean Skill_PlayerSkillRunSpeedUp_VisibleChange' 
	end end -- 0xf49
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean Skill_LevelSantinoDummy_VisibleChange' 
	end end -- 0xf4a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean Skill_PlayerSkillAutoPathBomb_VisibleChange' 
	end end -- 0xf4b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean Skill_PlayerSkillTeamShield_VisibleChange' 
	end end -- 0xf4c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UseObjectPool' 
	end end -- 0xf4d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UseObjectPoolLowMemory' 
	end end -- 0xf4e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableGetResAsync' 
	end end -- 0xf4f
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableConcurrentGetResAsync' 
	end end -- 0xf50
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableLoadAbAsync' 
	end end -- 0xf51
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableWeaponSkinResAsync' 
	end end -- 0xf52
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableWeaponEffectResAsyncFor1P' 
	end end -- 0xf53
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableWeaponModelResAsync' 
	end end -- 0xf54
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePickUpModelResAsync' 
	end end -- 0xf55
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableVehicleSkinResAsyncFor3P' 
	end end -- 0xf56
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAsyncLoadLootBoxSkin' 
	end end -- 0xf57
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAsyncLoadClothesEffect' 
	end end -- 0xf58
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAsyncLoadClothesEffectFor1P' 
	end end -- 0xf59
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAsyncLoadGrenadeSkin' 
	end end -- 0xf5a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableExtraClothEffectWithNoUMA' 
	end end -- 0xf5b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAsyncLoadAudioClipForLowest' 
	end end -- 0xf5c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAsyncLoadAudioClipForLow' 
	end end -- 0xf5d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAsyncLoadAudioClipForHigh' 
	end end -- 0xf5e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single AsyncLoadAudioClipMaxDelay' 
	end end -- 0xf60
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAsyncLoadContinueKDAudio' 
	end end -- 0xf64
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAsyncLoadVehicleBurnAudio' 
	end end -- 0xf65
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAsyncLoadVehicleSmokeAudio' 
	end end -- 0xf66
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAsyncLoadDeIceWallAudio' 
	end end -- 0xf67
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAsyncLoadQuickChatAudio' 
	end end -- 0xf68
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAsyncLoadGroupAnim' 
	end end -- 0xf69
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePreDistCheckForDefaultAudioSrc' 
	end end -- 0xf6a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePreLoadFontTextute' 
	end end -- 0xf6b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableBackgroundCache' 
	end end -- 0xf6c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableBackgroundCacheWeaponAnimator' 
	end end -- 0xf6d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableBackgroundCacheWeaponEffect' 
	end end -- 0xf6e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableBackgroundCacheSkill' 
	end end -- 0xf6f
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableBackgroundCache3PSkill' 
	end end -- 0xf70
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableCSBackgroundCache3PIcewall' 
	end end -- 0xf71
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableBackgroundCacheCSBuff' 
	end end -- 0xf72
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableBackgroundCacheAutoPickupWeapon' 
	end end -- 0xf73
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableBackgroundCacheAutoPickupFppWeapon' 
	end end -- 0xf74
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAsyncLoadIngameEmoteEffect' 
	end end -- 0xf75
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAsyncLoadIngameTransEffect' 
	end end -- 0xf76
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAsyncLoadIngameGroupEffect' 
	end end -- 0xf77
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAsyncLoadIngameLastKillEffect' 
	end end -- 0xf78
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAsyncLoadIngameEmoteAnim' 
	end end -- 0xf79
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAsyncLoadIngameDuoEmoteAnim' 
	end end -- 0xf7a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAsyncLoadIngameTransAnim' 
	end end -- 0xf7b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableLevelObjectByType' 
	end end -- 0xf7c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableLevelObjectNameWithID' 
	end end -- 0xf7d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAllRecipePreloadForHighMem' 
	end end -- 0xf7e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAllRecipePreloadForMediumMem' 
	end end -- 0xf7f
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePreloadVestHelmetBackpack' 
	end end -- 0xf80
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableWaitingRoomEPPlayerEffect' 
	end end -- 0xf81
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 SmokeEffectMaxNum' 
	end end -- 0xf84
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean TokenModeEnableAllyPick' 
	end end -- 0xf88
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean IsTokenFollowPlayer' 
	end end -- 0xf89
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 GIANT_OverFighting_CountDown' 
	end end -- 0xf8c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean isShowCSLeaderboard' 
	end end -- 0xf90
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableTrustItemCountFromServer' 
	end end -- 0xf91
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableSliderTrigger' 
	end end -- 0xf92
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableNativeCheck' 
	end end -- 0xf93
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePlatformCheck' 
	end end -- 0xf94
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableMMKPlatformCheck' 
	end end -- 0xf95
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableSupCheck' 
	end end -- 0xf96
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableVersionRowErrorUpdate' 
	end end -- 0xf97
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single PlantGrownTotalTime' 
	end end -- 0xf98
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single PlantAccRatePerPerson' 
	end end -- 0xf9c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean RescureShowTimeToOther' 
	end end -- 0xfa0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single HumanTireCheckDistanceThreshold' 
	end end -- 0xfa4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single HumanTireCheckHeightThreshold' 
	end end -- 0xfa8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean WeaponSkinFistEffectEnabled' 
	end end -- 0xfac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean CanReloadContinueShoot' 
	end end -- 0xfad
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean WeaponStateMachineStartFiringOnlyDoOnce' 
	end end -- 0xfae
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean WeaponStateMachineClearFireTrigger' 
	end end -- 0xfaf
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean CanRunSpeedUpSkillContinueShoot' 
	end end -- 0xfb0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean CanInvincibleContinueShoot' 
	end end -- 0xfb1
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean CanInvincibleReloadAndSwapWeapon' 
	end end -- 0xfb2
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single MapLengththreshold' 
	end end -- 0xfb4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LoginFailedCd1' 
	end end -- 0xfb8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LoginFailedCd2' 
	end end -- 0xfbc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LoginFailedCd3' 
	end end -- 0xfc0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 LoginFailedCd4' 
	end end -- 0xfc4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean ForbidenRepeatLogin' 
	end end -- 0xfc8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean SetSpecialPlayerRotationInCabin' 
	end end -- 0xfc9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableUMAGCForUltra' 
	end end -- 0xfca
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UnloadSplashTexture' 
	end end -- 0xfcb
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAutoPopupSplashBannerFor32BitPhone' 
	end end -- 0xfcc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SpectatorMinimapScale1' 
	end end -- 0xfd0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableVehicleBrakeLightFunction' 
	end end -- 0xfd4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableVehicleBrakeLightAtLowSetting' 
	end end -- 0xfd5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableVehicleBrakeLightAtLowSettingInCommonVersion' 
	end end -- 0xfd6
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single VehicleScratchOverGroundHeightThreshold' 
	end end -- 0xfd8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single PlayerPosDistDiffAllowedInOneFrame' 
	end end -- 0xfdc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean PlayerPosDistDiffCheckEnable' 
	end end -- 0xfe0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean PlayerPosDistDiffCheckIgnoreGroundedEnable' 
	end end -- 0xfe1
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean PlayerPosStuckFixEnable' 
	end end -- 0xfe2
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single PlayerPosStuckFixTime' 
	end end -- 0xfe4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePhysXStateSwitchPreCheck' 
	end end -- 0xfe8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableVehilceHornFunction' 
	end end -- 0xfe9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single AirtransportDestroyDelayTime' 
	end end -- 0xfec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single VehicleLowSpeedThreshold' 
	end end -- 0xff0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single VehicleMiddleSpeedThreshold' 
	end end -- 0xff4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single VehicleHighSpeedThreshold' 
	end end -- 0xff8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single ParachutingStateMinAngleX' 
	end end -- 0xffc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single ParachutingStateMaxAngleX' 
	end end -- 0x1000
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableFixForPlayerDelayReady' 
	end end -- 0x1004
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean SendMallItemClickLog' 
	end end -- 0x1005
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableVoluner' 
	end end -- 0x1006
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single VehicleResetTime' 
	end end -- 0x1008
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single VehicleResetThresholdSpped' 
	end end -- 0x100c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableTrainingVideoPlay' 
	end end -- 0x1010
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableTrainingVideoUpdate' 
	end end -- 0x1011
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 OwnPlayerVoice' 
	end end -- 0x1014
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 WaitingIsland_MainLightColor' 
	end end -- 0x1018
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single UIPaymentDiamondEventProgressRunSpeed' 
	end end -- 0x101c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single UIPaymentDiamondEventProgressDelayTime' 
	end end -- 0x1020
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MaxVersionMinMemory' 
	end end -- 0x1024
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 TerrainTextureStreaming' 
	end end -- 0x1028
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 PaymentAdLevel' 
	end end -- 0x102c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 PaymentGrowthLevel' 
	end end -- 0x1030
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableCustomRoomSonoranNight' 
	end end -- 0x1034
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAimAssistChange' 
	end end -- 0x1035
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableSkillIgnoreAimAssistInVehicle' 
	end end -- 0x1036
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean FullScreenPreviewSwith' 
	end end -- 0x1037
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single SuicideCD' 
	end end -- 0x1038
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean FixSightingCameraWallPierce' 
	end end -- 0x103c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean Phobid3PEmote4LowQuality' 
	end end -- 0x103d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean NeedShowBounceModelInAzores' 
	end end -- 0x103e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UseNewSniperRaycast' 
	end end -- 0x103f
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean OptimizeAnimator' 
	end end -- 0x1040
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableGenerate' 
	end end -- 0x1041
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableGen' 
	end end -- 0x1042
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableSendLibs' 
	end end -- 0x1043
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean NoUnloadWhileAsyncLoading' 
	end end -- 0x1044
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean StreamSceneByIndex' 
	end end -- 0x1045
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String PetSkillTurtleBackDecreaseWeaponType' 
	end end -- 0x1048
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 PetSkillTurtleBackDecreaseAngle' 
	end end -- 0x104c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean PreloadSAPBR' 
	end end -- 0x1050
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean PreloadSAPCS' 
	end end -- 0x1051
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean CSVAsyncDataMapAsyncLoad' 
	end end -- 0x1052
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableSkeletonUtilityBoneOnReset' 
	end end -- 0x1053
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableSkeletonUtilityBoneOnResetCallback' 
	end end -- 0x1054
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableSetBackCamerasVisible' 
	end end -- 0x1055
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableSetGameCameraVisible' 
	end end -- 0x1056
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableCSVMultiThreadParse' 
	end end -- 0x1057
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableGraphicsJobs' 
	end end -- 0x1058
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableResetLowMemoryAsyncUploadBufferSize' 
	end end -- 0x1059
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableSkipShaderWarmUp' 
	end end -- 0x105a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 MaxWarmUpFrames' 
	end end -- 0x105c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableStateStoreForSniperFiringDeactive' 
	end end -- 0x1060
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAllowedSightListCheck' 
	end end -- 0x1061
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableCSShopPurchaseSFX' 
	end end -- 0x1062
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableBombShopPurchaseSFX' 
	end end -- 0x1063
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableTrainingShopPurchaseSFX' 
	end end -- 0x1064
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePreZPass' 
	end end -- 0x1065
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean HDEnablePreZPass' 
	end end -- 0x1066
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePreZV2Pass' 
	end end -- 0x1067
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean HDEnablePreZV2Pass' 
	end end -- 0x1068
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String DisablePreZGrapicDevices' 
	end end -- 0x106c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String DisablePreZGpu' 
	end end -- 0x1070
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String HDDisablePreZGpu' 
	end end -- 0x1074
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnbaleVersion' 
	end end -- 0x1078
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableForceSyncReqWhenAppResume' 
	end end -- 0x1079
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableIcewallAreaOccupiedCheck' 
	end end -- 0x107a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableVehiclePhysicAfterSceneReady' 
	end end -- 0x107b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableQuitGameWhenMM7' 
	end end -- 0x107c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableContainerReactiveFor2018Emulator' 
	end end -- 0x107d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableContainerReactiveFor2018RealPhone' 
	end end -- 0x107e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableStaticContainerModelFixRotation' 
	end end -- 0x107f
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableDynamicContainerModelFixRotation' 
	end end -- 0x1080
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableCombinePRICallbackFor1P' 
	end end -- 0x1081
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single TwoToOneScreenLength' 
	end end -- 0x1084
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single FourToThreeScreenLength' 
	end end -- 0x1088
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single SmallTwoToOneScreenLength' 
	end end -- 0x108c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single SmallFourToThreeScreenLength' 
	end end -- 0x1090
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single MoveJoyStickAngle' 
	end end -- 0x1094
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single PreMoveJoyStickAngle' 
	end end -- 0x1098
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean MoveJoyStickKeepDashAfterFire' 
	end end -- 0x109c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single MistakenlyTouchMovingJoystickSize' 
	end end -- 0x10a0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single MistakenlyTouchMovingJoystickTime' 
	end end -- 0x10a4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean NeedCheckMovingJoystickConflictWithButton' 
	end end -- 0x10a8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean DisableUserControlTouchWhenSettingWndOpen' 
	end end -- 0x10a9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean IosShowRestoreButton' 
	end end -- 0x10aa
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableIceWallOverlapPlayerCheck' 
	end end -- 0x10ab
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableIceWallOverlapPlayerCheckInterval' 
	end end -- 0x10ac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single IceWallOverlapPlayerCheckInterval' 
	end end -- 0x10b0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single IceWallOverlapPlayerCheckHalfSizeExpand' 
	end end -- 0x10b4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single IceWallOverlapPlayerCheckStep' 
	end end -- 0x10b8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single IceWallOverlapPlayerCheckStartDelay' 
	end end -- 0x10bc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableSeqPreload' 
	end end -- 0x10c0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single SendJoinGameTimeoutTime' 
	end end -- 0x10c4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single RegisterExitDuration' 
	end end -- 0x10c8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UIBaseProfileLevelHideWhenZero' 
	end end -- 0x10cc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnemyUseLowModelBackPack' 
	end end -- 0x10cd
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableIceWallOverlapPlayerCheckOnlyUsing' 
	end end -- 0x10ce
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableIceWallOverlapPlayerCheckByCheckBox' 
	end end -- 0x10cf
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableIceWallVFXForQualityLowest' 
	end end -- 0x10d0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableIceWallVFXForQualityLow' 
	end end -- 0x10d1
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single IceWallGrowUpTime' 
	end end -- 0x10d4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableIceWallIgnoreTraceFlagFire' 
	end end -- 0x10d8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableEntityNeedStreamerDynaimc' 
	end end -- 0x10d9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single IceWallDisappearHintShowTime' 
	end end -- 0x10dc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single IceWallDisappearHintShowDecalStartAlp' 
	end end -- 0x10e0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single IceWallDisappearHintShowDecalEndAlp' 
	end end -- 0x10e4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single IceWallDisappearHintAnimFrequency' 
	end end -- 0x10e8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean IsBRShowAceTeamIcon' 
	end end -- 0x10ec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableLobbyLookAt' 
	end end -- 0x10ed
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableTriggerGrenade' 
	end end -- 0x10ee
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean NoPowerGunCombine' 
	end end -- 0x10ef
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single AutoThrowGrenadeDelayTime' 
	end end -- 0x10f0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableHintTriggeredGrenade' 
	end end -- 0x10f4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean TCPTokenEncrypt' 
	end end -- 0x10f5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 TCPDeactiveTime' 
	end end -- 0x10f8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 TCPQuickConnectTime' 
	end end -- 0x10fc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean TCPUnserializeMessageContentInThread' 
	end end -- 0x1100
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean DevicePerformanceSdk_Test' 
	end end -- 0x1101
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean DevicePerformanceSdk_Enable' 
	end end -- 0x1102
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean DevicePerformanceSdk_GameMode' 
	end end -- 0x1103
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean DevicePerformanceSdk_MainThreadTargetFrame' 
	end end -- 0x1104
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean DevicePerformanceSdk_Thermal' 
	end end -- 0x1105
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 ShieldMaxHP' 
	end end -- 0x1108
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 PhotographEmoteID1' 
	end end -- 0x110c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 PhotographEmoteID2' 
	end end -- 0x1110
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 PhotographEmoteID3' 
	end end -- 0x1114
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 PhotographEmoteID4' 
	end end -- 0x1118
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 PhotographEmoteID5' 
	end end -- 0x111c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 PhotographEmoteID6' 
	end end -- 0x1120
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 PhotographEmoteID7' 
	end end -- 0x1124
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 PhotographEmoteID8' 
	end end -- 0x1128
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 PhotographPartyEmoteID1' 
	end end -- 0x112c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 PhotographPartyEmoteID2' 
	end end -- 0x1130
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 PhotographPartyEmoteID3' 
	end end -- 0x1134
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 PhotographPartyEmoteID4' 
	end end -- 0x1138
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 PhotographPartyEmoteID5' 
	end end -- 0x113c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 PhotographPartyEmoteID6' 
	end end -- 0x1140
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 PhotographPartyEmoteID7' 
	end end -- 0x1144
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 PhotographPartyEmoteID8' 
	end end -- 0x1148
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 TrainingSnowBallItemID' 
	end end -- 0x114c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableRefreshFile' 
	end end -- 0x1150
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single RefreshCD' 
	end end -- 0x1154
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 EventLogCacheTime' 
	end end -- 0x1158
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 EventLogTimeout' 
	end end -- 0x115c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean NeedSendEventLogOnGameQuit' 
	end end -- 0x1160
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean NeedSendEventLogOnGamePause' 
	end end -- 0x1161
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean AppleLoginWhite' 
	end end -- 0x1162
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean HttpRequestDelegateCheck' 
	end end -- 0x1163
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UIModelSceneChangeCalledInLoadAndRun' 
	end end -- 0x1164
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UIModelSceneChangeRemoveUIObserver' 
	end end -- 0x1165
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UIModelObseverCheck' 
	end end -- 0x1166
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 LobbyStartGameCoolDownTime' 
	end end -- 0x1168
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableGroundNoise' 
	end end -- 0x116c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableSimpleInvokeExceptionInfo' 
	end end -- 0x116d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean AndroidNotchUIAdapte' 
	end end -- 0x116e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean OpenUINoReflection' 
	end end -- 0x116f
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 HttpTokenExpiredTime' 
	end end -- 0x1170
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String LobbyBGM2Region' 
	end end -- 0x1174
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean Enable3DPlaceName' 
	end end -- 0x1178
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean Enable3DPlaceName32andLowMem' 
	end end -- 0x1179
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean InjectFixBeforeLaunchGame' 
	end end -- 0x117a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String CodePatchUrl' 
	end end -- 0x117c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean HidePingSignal' 
	end end -- 0x1180
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 OptionalDownloadErrMsgShowCD' 
	end end -- 0x1184
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 AccountInfoCacheTime' 
	end end -- 0x1188
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean SupportIPv6Only' 
	end end -- 0x118c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean HttpRequestDispose' 
	end end -- 0x118d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean HttpDeserializeInThread' 
	end end -- 0x118e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean HttpSendNextSameFrame' 
	end end -- 0x118f
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single AngularSleepTolerance_ON' 
	end end -- 0x1190
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single AngularSleepTolerance_OFF' 
	end end -- 0x1194
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LinearSleepTolerance_ON' 
	end end -- 0x1198
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LinearSleepTolerance_OFF' 
	end end -- 0x119c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LoadoutScannerDestroyTime' 
	end end -- 0x11a0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableFontTextureOpt' 
	end end -- 0x11a4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableSkinnedCompressInLowMemory' 
	end end -- 0x11a5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableSkinnedCompressInUltraQuality' 
	end end -- 0x11a6
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 EngineSwitchFlags' 
	end end -- 0x11a8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 EngineSwitchFlags2' 
	end end -- 0x11ac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 CustomGfxDeviceRingBufferSize' 
	end end -- 0x11b0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableShaderStripSettings' 
	end end -- 0x11b4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableShaderKeywordStripByConfig' 
	end end -- 0x11b5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 Il2cppSwitchFlags' 
	end end -- 0x11b8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean OpenIl2cppThreadStackShrink' 
	end end -- 0x11bc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 BackgroundJobSystemThreadNum' 
	end end -- 0x11c0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 KillNotifiyFilter' 
	end end -- 0x11c4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableForceUseApkShader' 
	end end -- 0x11c8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableStripABShader_Android' 
	end end -- 0x11c9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableStripABShader_IOS' 
	end end -- 0x11ca
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableStripShader_Android_32bit' 
	end end -- 0x11cb
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableStripShader_Android_64bit_lowMem' 
	end end -- 0x11cc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableStripShader_Android_64bit_highMem' 
	end end -- 0x11cd
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableStripShader_Android_64bit_UltraMem' 
	end end -- 0x11ce
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableStripShader_iOS_32bit' 
	end end -- 0x11cf
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableStripShader_iOS_64bit_lowMem' 
	end end -- 0x11d0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableStripSahder_iOS_64bit_highMem' 
	end end -- 0x11d1
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableStripShader_iOS_64bit_UltraMem' 
	end end -- 0x11d2
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableSaveCustomSettings' 
	end end -- 0x11d3
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 ApplicationInitOptSwitch' 
	end end -- 0x11d4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 Adjust8CoreOnly1Big' 
	end end -- 0x11d8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 ResMgrCacheClose' 
	end end -- 0x11dc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 GlobalGameMgrCacheClose' 
	end end -- 0x11e0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String SystemFontsWhiteList' 
	end end -- 0x11e4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String SystemFontsBlackList' 
	end end -- 0x11e8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableSystemFontsTrim' 
	end end -- 0x11ec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean CSSOTeamThemeColor' 
	end end -- 0x11ed
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String FemaleAvatarColorStart' 
	end end -- 0x11f0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String AvatarColorStart' 
	end end -- 0x11f4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String AvatarColorEnd' 
	end end -- 0x11f8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UMAEnableHighRGB565' 
	end end -- 0x11fc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UMAEnableMAXHighRGB565' 
	end end -- 0x11fd
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UMAEnableAtlasResolutionScale' 
	end end -- 0x11fe
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UMAEnableMAXAtlasResolutionScale' 
	end end -- 0x11ff
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single UMAAtlasResolutionScale' 
	end end -- 0x1200
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UMATextureProcessSetEffectType' 
	end end -- 0x1204
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableEasternText' 
	end end -- 0x1205
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LiteDataCoolDownSecs' 
	end end -- 0x1208
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LiteDataDelaySecs' 
	end end -- 0x120c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean DisableNonExpectionLogsFor64bit' 
	end end -- 0x1210
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean DisableNonExceptionLogsFor32bit' 
	end end -- 0x1211
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single UAVFightTime' 
	end end -- 0x1214
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableTrainingVideoForLowQualityPhone' 
	end end -- 0x1218
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableCameraMatrixCheck' 
	end end -- 0x1219
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single CenterSafeZoneTargetRadius' 
	end end -- 0x121c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single MiniMapSafeZoneTargetRadius' 
	end end -- 0x1220
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single SideMapSafeZoneTargetRadius' 
	end end -- 0x1224
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single BigMapCenterSafeZoneMaxRatio' 
	end end -- 0x1228
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt64 OBMapCenterSafeZoneEnableCD' 
	end end -- 0x1230
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single BooyahEmoteTime' 
	end end -- 0x1238
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableMapMaskSupplement' 
	end end -- 0x123c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableHippoMapMaskSupplement' 
	end end -- 0x123d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single FountainFallingMoveRatio' 
	end end -- 0x1240
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean FountainFallingCanMove' 
	end end -- 0x1244
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LobbyDailyTaskTipProbability' 
	end end -- 0x1248
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LobbyDailyTaskTipInterval' 
	end end -- 0x124c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 LessIsMoreMinReloadInterval' 
	end end -- 0x1250
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 LessIsMoreMaxReloadFailures' 
	end end -- 0x1254
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 LessIsMorePendingReloadInterval' 
	end end -- 0x1258
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String PaymentOfferPersonalized_TypesPerLockRegion_GooglePlay' 
	end end -- 0x125c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UnloadEmbeddedSceneObjects' 
	end end -- 0x1260
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UnloadEmbeddedSceneObjectsFor64bitHigh' 
	end end -- 0x1261
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UnloadEmbeddedSceneObjectsFor64bitHigh_IOS' 
	end end -- 0x1262
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean ShowLegPack' 
	end end -- 0x1263
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean LowQuality1PShowSecondaryWeapon' 
	end end -- 0x1264
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean LowQuality3PShowSecondaryWeapon' 
	end end -- 0x1265
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean ShowSecondaryWeaponModel' 
	end end -- 0x1266
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single InGameMusicElementPlayIntervalTime' 
	end end -- 0x1268
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean PlayAvatarVoiceWithChannel' 
	end end -- 0x126c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 InGameTokenUnitCount' 
	end end -- 0x1270
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 MuchTokenCount' 
	end end -- 0x1274
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UseNewDeathCamera' 
	end end -- 0x1278
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UseNewDeathCameraInRanking' 
	end end -- 0x1279
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single TeleportDoorDuration' 
	end end -- 0x127c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single TeleportDoorUseCD' 
	end end -- 0x1280
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean TeleportDoorToOtherDoor_TriggerOn' 
	end end -- 0x1284
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean CheckSoloMatchMakingGameMode' 
	end end -- 0x1285
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 MiniGameRankCnt' 
	end end -- 0x1288
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean DynamicGeneratorCheckCamDown' 
	end end -- 0x128c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single DynamicGeneratorCamBackOffset' 
	end end -- 0x1290
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean DecalSystemCheckCamDown' 
	end end -- 0x1294
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean DecalSystemShowAllinCell' 
	end end -- 0x1295
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single DecalVisibleMaxHeight' 
	end end -- 0x1298
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 DecalSystemInstanceNumLimit' 
	end end -- 0x129c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single HighGrassHeightScale_Neo' 
	end end -- 0x12a0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single MiddleGrassHeightScale_Neo' 
	end end -- 0x12a4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LowGrassHeightScale_Shangrila' 
	end end -- 0x12a8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single MiddleGrassHeightScale_Shangrila' 
	end end -- 0x12ac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single HighGrassHeightScale_Shangrila' 
	end end -- 0x12b0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single PlayerSkillSpaceShieldScale' 
	end end -- 0x12b4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableVariableFadeSpeed' 
	end end -- 0x12b8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean OpenClickEffect' 
	end end -- 0x12b9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 StreamerMaxParallel' 
	end end -- 0x12bc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 FriendMatchStartTime' 
	end end -- 0x12c0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 RecommendFriendCountLimit' 
	end end -- 0x12c4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 RecommendFriendRankLimit' 
	end end -- 0x12c8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 RecommendFriendCSRankLimit' 
	end end -- 0x12cc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 RecommendFriendLevelLimit' 
	end end -- 0x12d0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 RecommendFriendMatchCD' 
	end end -- 0x12d4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 RecommentFriendTeamRankLimit' 
	end end -- 0x12d8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 FriendCountLimit' 
	end end -- 0x12dc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 ReservationCountLimit' 
	end end -- 0x12e0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 ReservationAcceptLimit' 
	end end -- 0x12e4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single ReservationTimeoutDuration' 
	end end -- 0x12e8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 BookPlayerRefreshCD' 
	end end -- 0x12ec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean Enable3PDelayDestroyProjectile' 
	end end -- 0x12f0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableQuickChat' 
	end end -- 0x12f1
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableQuickChatInRankMatch' 
	end end -- 0x12f2
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 ChooseQuickChatMaxCount' 
	end end -- 0x12f4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single QuickChatSendCD' 
	end end -- 0x12f8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 QuickMessageAfterDeathCD' 
	end end -- 0x12fc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single QuickChatShowTime' 
	end end -- 0x1300
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean NameAlphaEnable' 
	end end -- 0x1304
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single NameAlphaDist' 
	end end -- 0x1308
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single NameAlphaValue' 
	end end -- 0x130c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single NameAlphaScreenWidthRatio' 
	end end -- 0x1310
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single NameAlphaScreenHeightRatio' 
	end end -- 0x1314
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean IsPoenHeadShotSound' 
	end end -- 0x1318
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single BombDropPosAlphaValue' 
	end end -- 0x131c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single BombDropPosAlphaScreenWidthRatio' 
	end end -- 0x1320
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single BombDropPosAlphaScreenHeightRatio' 
	end end -- 0x1324
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single BombCountDownDangerousTime' 
	end end -- 0x1328
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 SelfHeroicMarkCDTime' 
	end end -- 0x132c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 FetchHeroicMarkCDTime' 
	end end -- 0x1330
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 FetchRelationshipCDTime' 
	end end -- 0x1334
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableQuickVersionCheck' 
	end end -- 0x1338
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 QuickVersionCheckCount' 
	end end -- 0x133c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LobbyAvatarTouchOffsetX' 
	end end -- 0x1340
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LobbyAvatarTouchOffsetY' 
	end end -- 0x1344
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single EmoteLeaderRange' 
	end end -- 0x1348
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 MaxEmoteFollower' 
	end end -- 0x134c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single DuoEmoteInviteRange' 
	end end -- 0x1350
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single DuoEmoteLobbyInviteTime' 
	end end -- 0x1354
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 HUDGrenadeAttackDefaultDirection' 
	end end -- 0x1358
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 HUDGrenadeDefenceDefaultDirection' 
	end end -- 0x135c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 HUDThreeGrenadeAttackDefaultDirection' 
	end end -- 0x1360
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 HUDThreeGrenadeDefenceDefaultDirection' 
	end end -- 0x1364
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean CanHUDGrenadeSlotChangeInGame' 
	end end -- 0x1368
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean CanHUDSmartIceWallShowInGame' 
	end end -- 0x1369
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String EnableIngameKillRegion' 
	end end -- 0x136c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String EnableRoomGunSkinAttrSetting' 
	end end -- 0x1370
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String UGCRecommendMapSwitch' 
	end end -- 0x1374
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableDrivingFlightOnBoard' 
	end end -- 0x1378
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single FlightRoamColliderHeight' 
	end end -- 0x137c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single CCTRadiusFlightRoam' 
	end end -- 0x1380
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LagTimeToHint' 
	end end -- 0x1384
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LagHintCooldown' 
	end end -- 0x1388
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LagHintDuration' 
	end end -- 0x138c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String EnableEmulatorWarning' 
	end end -- 0x1390
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean CanShowCameraAnimInPreview' 
	end end -- 0x1394
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UseHDModelInPartyGame' 
	end end -- 0x1395
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean HDAllowIOSLowMemory' 
	end end -- 0x1396
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean FixRefreshConfigOrderInRestart' 
	end end -- 0x1397
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean FixTeamFlightSound' 
	end end -- 0x1398
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean HDUseSplashBannerPreviewMixCamera' 
	end end -- 0x1399
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean DisableFlareLayerForGameCamera_Lowest' 
	end end -- 0x139a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean AimCheckPlayerStreamerVisibility' 
	end end -- 0x139b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 PhysicsSpecialCheckLimit' 
	end end -- 0x139c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 UIScreenDelayFrame' 
	end end -- 0x13a0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UIScreenOptimization' 
	end end -- 0x13a4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean ABSceneUnloadMesh' 
	end end -- 0x13a5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean ABSceneUnloadTexture' 
	end end -- 0x13a6
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean ABSceneSkipUnloadForMapAzores' 
	end end -- 0x13a7
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 ABSceneUnloadMemoryThreshold' 
	end end -- 0x13a8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 ABSceneUnloadMemoryThresholdIOS' 
	end end -- 0x13ac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableAllEyeLookAt' 
	end end -- 0x13b0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean StreamingSceneUnloadMesh' 
	end end -- 0x13b1
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean StreamingSceneUnloadTexture' 
	end end -- 0x13b2
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 StreamingSceneUnloadMemoryThreshold' 
	end end -- 0x13b4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 StreamingSceneUnloadMemoryThresholdIOS' 
	end end -- 0x13b8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single WaitSecsBeforeMatchResult' 
	end end -- 0x13bc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean WaitStreamerBeforeMatchResult' 
	end end -- 0x13c0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single WaitStreamerBeforeMatchResultMaxSecs' 
	end end -- 0x13c4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean TryFixStreamerCurrentSceneLoading' 
	end end -- 0x13c8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String StreamPerformanceMap' 
	end end -- 0x13cc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 LowMemPreviewStreamRange' 
	end end -- 0x13d0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LowMemPreviewStreamMaxY' 
	end end -- 0x13d4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 WaitingLandCreateOthersFireworksCount_Quality_Lowest' 
	end end -- 0x13d8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 WaitingLandCreateOthersFireworksCount_Quality_High' 
	end end -- 0x13dc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 WaitingLandCreateOthersFireworksCount_Quality_Ultra' 
	end end -- 0x13e0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 SPHUDCSRoundMVPTime' 
	end end -- 0x13e4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 RevivePointMarkShowDis' 
	end end -- 0x13e8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single RevivePointVFXShowDelta' 
	end end -- 0x13ec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean RevivePointMarkStick' 
	end end -- 0x13f0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableBriefBoxTween' 
	end end -- 0x13f1
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 AutoEnemyMarkSwitch' 
	end end -- 0x13f4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single AutoEnemyMarkDuration' 
	end end -- 0x13f8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single AutoRecommendMessageDuration' 
	end end -- 0x13fc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean AutoRecommendMessageSwitch' 
	end end -- 0x1400
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableFixWorkSyncRemoveData' 
	end end -- 0x1401
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single SPHudNameDangerTime' 
	end end -- 0x1404
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableDecryptionStaticBufferOpt' 
	end end -- 0x1408
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableMedkitUseSound' 
	end end -- 0x1409
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableCheckWaterWhileSwimming' 
	end end -- 0x140a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EsportsGotoInternalBrowser' 
	end end -- 0x140b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableRunNewGameWhenLoading' 
	end end -- 0x140c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String DefaultMaleClothList' 
	end end -- 0x1410
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String DefaultFeMaleClothList' 
	end end -- 0x1414
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single DriftBottleAddFriendAutoCloseTime' 
	end end -- 0x1418
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String HudEnableHiddenList' 
	end end -- 0x141c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String MonitorNetworkReachabilityHostName' 
	end end -- 0x1420
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single NetworkCallbackForceReconnectCooldown' 
	end end -- 0x1424
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableLeadEmotionIgnoreSameId' 
	end end -- 0x1428
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String AutoClearOverTimeOptionalType' 
	end end -- 0x142c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String AutoClearUnOwnedOptionalType' 
	end end -- 0x1430
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 AutoClearTimeDel' 
	end end -- 0x1434
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 AutoClearDelFileOneFrameNum' 
	end end -- 0x1438
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableLoginQueue' 
	end end -- 0x143c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 RequestQueueInfoIntervalWhileQueueIsFull' 
	end end -- 0x1440
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 MinIntervalForRequestQueueInfo' 
	end end -- 0x1444
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 MaxIntervalForRequestQueueInfo' 
	end end -- 0x1448
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single PartyModeDiceSpeedScale' 
	end end -- 0x144c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableVersionCode' 
	end end -- 0x1450
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String VNLinkUrl' 
	end end -- 0x1454
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 UGCNotifyTimeOutLimit' 
	end end -- 0x1458
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 UGCGameTimeMax' 
	end end -- 0x145c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 CustomRoomCountDownTime' 
	end end -- 0x1460
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 UGCRoomCountDownTime' 
	end end -- 0x1464
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 UGCCustomHudMaxDepth' 
	end end -- 0x1468
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 UGCCustomHudMinDepth' 
	end end -- 0x146c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 UGCCustomHud3DContainerZBase' 
	end end -- 0x1470
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 UGCCustomHud3DContainerZStep' 
	end end -- 0x1474
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 UGCTeammatesCountMax' 
	end end -- 0x1478
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 WereWolvesWinPointCountDown' 
	end end -- 0x147c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single WereWolvesChatIntervalCoolDown' 
	end end -- 0x1480
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableRushingPetsRoomTab' 
	end end -- 0x1484
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableWereWolvesRoomTab' 
	end end -- 0x1485
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 GachaNewAnimationSwitch' 
	end end -- 0x1488
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean CanEsocrtVehicleBeDamaged' 
	end end -- 0x148c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableGameVoiceRegion' 
	end end -- 0x148d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean InAppReviewEnabled' 
	end end -- 0x148e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean ScreenShotWithPostEffect' 
	end end -- 0x148f
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean DisablePostEffectFor32BitUltra' 
	end end -- 0x1490
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single BROpeningDubbingDelay' 
	end end -- 0x1494
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single ItemMarkPressThreshold' 
	end end -- 0x1498
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single ResetPlayerInputInterval' 
	end end -- 0x149c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single ItemMarkObjectCheckDistance' 
	end end -- 0x14a0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single ItemMarkWndAutoHideTime' 
	end end -- 0x14a4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single PCReplayEventForwardSec' 
	end end -- 0x14a8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean SendBRDeadInfoEventLog' 
	end end -- 0x14ac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean OpenGrassMergeFreeBuffer' 
	end end -- 0x14ad
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableGrassNormal' 
	end end -- 0x14ae
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableFoliageSplitUpdate' 
	end end -- 0x14af
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableVegetationMultiGrid' 
	end end -- 0x14b0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 VegetationClearPSDelayCount' 
	end end -- 0x14b4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 FoliageSpliteUpdateDelayFrame' 
	end end -- 0x14b8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single GrassSplitUpdateEnableAngle' 
	end end -- 0x14bc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single TreeSplitUpdateEnableAngle' 
	end end -- 0x14c0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single TreeSplitUpdateEnablePos' 
	end end -- 0x14c4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UnloadTreeMeshByLod' 
	end end -- 0x14c8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean DisableDeviceIdentifier_iOS' 
	end end -- 0x14c9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean DisableDeviceIdentifier_Android' 
	end end -- 0x14ca
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableMessagePoolOptimization' 
	end end -- 0x14cb
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableNewOnceAmmoMethod' 
	end end -- 0x14cc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableFrameByFrameShotGunHitEffectLoading' 
	end end -- 0x14cd
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableANOInfoExtra' 
	end end -- 0x14ce
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean OptUIPanel' 
	end end -- 0x14cf
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 RenderUIToMainCam' 
	end end -- 0x14d0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UpdateUISprite' 
	end end -- 0x14d4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean OptimzeFrameTimeOB37' 
	end end -- 0x14d5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean AllowForceCheckBtnChange' 
	end end -- 0x14d6
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean PanelLateUpdateToPreCull' 
	end end -- 0x14d7
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UseMutableString' 
	end end -- 0x14d8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UIInGamePoolCheckDuplicate' 
	end end -- 0x14d9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean ReplaceDicWithIntervalTree' 
	end end -- 0x14da
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean MergeSortForIntervalTree' 
	end end -- 0x14db
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean SortCsvForIntervalTreeAtBuildTime' 
	end end -- 0x14dc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean ClearAnimControllerWhenSwitchWeaponFor2018' 
	end end -- 0x14dd
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean SkipWeaponAnimCtrlChangeIfSame' 
	end end -- 0x14de
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single CupMatchRequestUseTicketCD' 
	end end -- 0x14e0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean AnimationUseRecordUniqueID' 
	end end -- 0x14e4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String BRMasterDefaultRankIconBig' 
	end end -- 0x14e8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String BRMasterDefaultRankIconSmall' 
	end end -- 0x14ec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String CSMasterDefaultRankIconBig' 
	end end -- 0x14f0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String CSMasterDefaultRankIconSmall' 
	end end -- 0x14f4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String MasterDefaultRankNameKey' 
	end end -- 0x14f8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableWorkShopBg' 
	end end -- 0x14fc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 WorkShopBitMapBasicSize' 
	end end -- 0x1500
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 WorkShopIconMinSize' 
	end end -- 0x1504
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean PromptInstallFacebookAfterLoginFailure_AndroidDevice' 
	end end -- 0x1508
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean PromptInstallFacebookAfterLoginFailure_AndroidEmulator' 
	end end -- 0x1509
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableUnsafeReplicationData' 
	end end -- 0x150a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableArrayMap' 
	end end -- 0x150b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableWheelRollGSSidePhysics' 
	end end -- 0x150c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean HackEpicClothesToMaxLevel' 
	end end -- 0x150d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UseOptEventDispatch' 
	end end -- 0x150e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean VegetationManagerUseJobs' 
	end end -- 0x150f
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean DynamicGeneratorUseJobs' 
	end end -- 0x1510
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableForceDestroyCDNTextures' 
	end end -- 0x1511
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 CupApplicationListRequestCD' 
	end end -- 0x1514
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 CupInvitationListRequestCD' 
	end end -- 0x1518
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 CupFriendTeamInfoRequestCD' 
	end end -- 0x151c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 PropCatapultMaxUseTimes' 
	end end -- 0x1520
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 RoomShowChatMessageMaxCount' 
	end end -- 0x1524
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 SceneEdit_RotateDegree' 
	end end -- 0x1528
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 SceneEdit_PressRotateSpeed' 
	end end -- 0x152c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single SceneEdit_LongPressInterval' 
	end end -- 0x1530
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single SceneEdit_ContinuousDeleteInterval' 
	end end -- 0x1534
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single SceneEdit_DeleteTutorialInterval' 
	end end -- 0x1538
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single UGCMiniSentryAttackRangeNear' 
	end end -- 0x153c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single UGCMiniSentryAttackRangeMiddle' 
	end end -- 0x1540
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single UGCMiniSentryAttackRangeFar' 
	end end -- 0x1544
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EndHudActionTriggerOnDead' 
	end end -- 0x1548
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean ReturnStropTriggerOnDead' 
	end end -- 0x1549
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UseMemberShipSystemReplaceRebateCardSystem' 
	end end -- 0x154a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean MobileReplay_Enabled' 
	end end -- 0x154b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean MobileReplay_SaveAfterPlay' 
	end end -- 0x154c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single MobileReplay_MinDiskSpace' 
	end end -- 0x1550
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean MobileReplay_ForceOpen' 
	end end -- 0x1554
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single MobileReplay_TimeForward' 
	end end -- 0x1558
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MobileReplay_PanelLifeTime' 
	end end -- 0x155c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MobileRelay_AchievementDelay' 
	end end -- 0x1560
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MobileRelay_AchievementDuration' 
	end end -- 0x1564
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean ShowChatBubble' 
	end end -- 0x1568
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single TeamChatBubbleDuration' 
	end end -- 0x156c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single AimAssistTeammateScore' 
	end end -- 0x1570
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean ShowHealingGunScreenEffect' 
	end end -- 0x1574
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean PhysicFreezeBlockUserControl' 
	end end -- 0x1575
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single RefreshLuckyBagInfoCoolDownTime' 
	end end -- 0x1578
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean FixStationaryAxisMoving' 
	end end -- 0x157c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single FixStationaryAxisMovingThreshold' 
	end end -- 0x1580
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean DisableRushingPetsUMA' 
	end end -- 0x1584
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single MapUIShowDeadBoxDuration' 
	end end -- 0x1588
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableFixTrainingSoundCloseWhenZoneChange' 
	end end -- 0x158c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String PollEventCounts' 
	end end -- 0x1590
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String PollDuration' 
	end end -- 0x1594
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MaxImmediateEventCount' 
	end end -- 0x1598
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 ObGlobalEventEffectTimeMs' 
	end end -- 0x159c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 ObEventEntryShowTimeSeconds' 
	end end -- 0x15a0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DisableHDTeammateFor32Bit' 
	end end -- 0x15a4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 InGameChatSendCD' 
	end end -- 0x15a8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String SkipShadowCasterCheck' 
	end end -- 0x15ac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean SetCastShadowAccordingToPlaneActive' 
	end end -- 0x15b0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean LightShadowChangedInGroupMode' 
	end end -- 0x15b1
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean LobbyCloserShadow' 
	end end -- 0x15b2
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UseCurrentServerTime' 
	end end -- 0x15b3
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean LoadDynamicAnimationClip' 
	end end -- 0x15b4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean FixDynamicAniamtionClip1' 
	end end -- 0x15b5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean DateTimeUtilServerTimeToLong' 
	end end -- 0x15b6
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean FixDynamicAniamtionClip2' 
	end end -- 0x15b7
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean LoadDynamicAnimationClipOpt' 
	end end -- 0x15b8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean LoadDynamicAnimationClipOptForInfectionMode' 
	end end -- 0x15b9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean LoadAllDynamicAnimationClipsForHigh' 
	end end -- 0x15ba
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean LoadAllDynamicAnimationClipsFor32BitHigh' 
	end end -- 0x15bb
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean LoadDynamicAnimationClipInUGC' 
	end end -- 0x15bc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean OptSwitchAnimatorController' 
	end end -- 0x15bd
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 RUSHINGPETSDISABLEBGM' 
	end end -- 0x15c0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean OpenBrightnessStretch' 
	end end -- 0x15c4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single DefaultBrightnessStretchThreshold' 
	end end -- 0x15c8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single DefaultBrightnessStretchSpeed' 
	end end -- 0x15cc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 VeteranLeaveTime' 
	end end -- 0x15d0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 VeteranBrLifetime' 
	end end -- 0x15d4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 VeteranBrKill' 
	end end -- 0x15d8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 VeteranBrMostKillsInMatch' 
	end end -- 0x15dc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 VeteranBrRevives' 
	end end -- 0x15e0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 VeteranBrSurvival' 
	end end -- 0x15e4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 VeteranBrLimit' 
	end end -- 0x15e8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 VeteranCsLifetime' 
	end end -- 0x15ec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 VeteranCsQuadraKill' 
	end end -- 0x15f0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 VeteranCsTripleKill' 
	end end -- 0x15f4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 VeteranCsDoubleKill' 
	end end -- 0x15f8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single VeteranCsWinRate' 
	end end -- 0x15fc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single VeteranCsHeadshotRate' 
	end end -- 0x1600
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 VeteranCsKill' 
	end end -- 0x1604
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 VeteranCsLimit' 
	end end -- 0x1608
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 VeteranShowGunsLimit' 
	end end -- 0x160c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 VeteranShowLadderMatchSeasonInfoCsLimit' 
	end end -- 0x1610
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean VeteranReturnShowNewGamePlay' 
	end end -- 0x1614
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePetModeVoiceChat' 
	end end -- 0x1615
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean OptSkillTemplateRaycast' 
	end end -- 0x1616
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean OptCsShopShowHide' 
	end end -- 0x1617
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 EnableLoadResconfAndLocEarly' 
	end end -- 0x1618
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableVibrateSDK' 
	end end -- 0x161c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VibrateVehicleSpeedUpMaxFactor' 
	end end -- 0x1620
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VibrateVehicleSpeedDownMaxFactor' 
	end end -- 0x1624
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VibrateVehicleStartFactor' 
	end end -- 0x1628
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VibrateEnemyMaxDistance' 
	end end -- 0x162c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single VibrateVehicleCheckInterval' 
	end end -- 0x1630
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean VIBRATION_FOOTSTEPSSWITCH' 
	end end -- 0x1634
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean VIBRATION_GUNFIRESWITCH' 
	end end -- 0x1635
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean VIBRATION_HUNTSWITCH' 
	end end -- 0x1636
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean VIBRATION_AUTOWEAPONSSWITCH' 
	end end -- 0x1637
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean VIBRATION_HALFAUTOWEAPONSSWITCH' 
	end end -- 0x1638
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean VIBRATION_BLOTWEAPONSSWITCH' 
	end end -- 0x1639
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean VIBRATION_MELEEWEAPONSSWITCH' 
	end end -- 0x163a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean VIBRATION_OTHERWEAPONSSWITCH' 
	end end -- 0x163b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean VIBRATION_CARDRIVINGSWITCH' 
	end end -- 0x163c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean VIBRATION_CARHUNTSWITCH' 
	end end -- 0x163d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean VIBRATION_CARCRASHSWITCH' 
	end end -- 0x163e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean VIBRATION_ROULETTE' 
	end end -- 0x163f
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean VIBRATION_PICKUPITEM' 
	end end -- 0x1640
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 CardCoolDownCasual' 
	end end -- 0x1644
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 CardCoolDownAdvanced' 
	end end -- 0x1648
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 CardCoolDownWerewolves' 
	end end -- 0x164c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 CardCoolDownWorkshop' 
	end end -- 0x1650
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 RecommandedNeedKillCount' 
	end end -- 0x1654
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 RecommandedNeedDamage' 
	end end -- 0x1658
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean IsBRModeDestructibleEnabled' 
	end end -- 0x165c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean StorePreviewKeepHairWhenSameAvatarIDSwitch' 
	end end -- 0x165d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MAX_WorkshopSettingLength' 
	end end -- 0x1660
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MAX_AttributeSettingLength' 
	end end -- 0x1664
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MAX_ModeSettingLength' 
	end end -- 0x1668
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single WinterLandBGMReducePrecent' 
	end end -- 0x166c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single WorkShopItemCirclePlayTime' 
	end end -- 0x1670
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 MaxTempReplayNumber' 
	end end -- 0x1674
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 EnableFluxInLobbyIfQualityGreaterEqualThan' 
	end end -- 0x1678
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 EnableFluxInGameIfQualityGreaterEqualThan' 
	end end -- 0x167c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GameMissionTimeWarningPercentage' 
	end end -- 0x1680
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GameMissionStartTipsDuration' 
	end end -- 0x1684
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GameMissionEndTipsDuration' 
	end end -- 0x1688
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String GameMission_SpawnPoint_MatchMode' 
	end end -- 0x168c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean GameMission_HitList_RoomSwitch' 
	end end -- 0x1690
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single LobbyGachaIntroDuration' 
	end end -- 0x1694
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single EmoteBGMReducePrecent' 
	end end -- 0x1698
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single ModePreference' 
	end end -- 0x169c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 RankModePrefenceCount' 
	end end -- 0x16a0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableIOSDeleteAccount' 
	end end -- 0x16a4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single TreasuryGateOpenTime' 
	end end -- 0x16a8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single UGCMapContentScopeScale' 
	end end -- 0x16ac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single MaxAnimSpeed' 
	end end -- 0x16b0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean NeedAimAssistOnChargeFinish' 
	end end -- 0x16b4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean Use3pPetModelIfPoolQualityOrMemory' 
	end end -- 0x16b5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SkateStartCameraAnimOffset' 
	end end -- 0x16b8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SkateCameraAnimTime' 
	end end -- 0x16bc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single StarFallingSpeedH' 
	end end -- 0x16c0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single StarFallingSpeedV' 
	end end -- 0x16c4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableBloom' 
	end end -- 0x16c8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FlightGravity' 
	end end -- 0x16cc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single TunnelSkateBoardFowardSpeed' 
	end end -- 0x16d0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single TunnelSkateBoardLeftAndRightSpeed' 
	end end -- 0x16d4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SingersHudTonePreTime' 
	end end -- 0x16d8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SingersBPlayerCallDanceScale' 
	end end -- 0x16dc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 SingerBSkateBoardID' 
	end end -- 0x16e0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 SingerBFlightID' 
	end end -- 0x16e4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 SingerBTimeLineFastSpeed' 
	end end -- 0x16e8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SingersBHoverBoardAniBlendSpeed' 
	end end -- 0x16ec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 SingersBLowQualityShowPlayerCount' 
	end end -- 0x16f0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SingersBBigScreenShotShowTime' 
	end end -- 0x16f4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single SingersBStarFallingSafeHeight' 
	end end -- 0x16f8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String MshopLandingWebFlag' 
	end end -- 0x16fc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String MshopTestLandingWebFlag' 
	end end -- 0x1700
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String AutoFlightRootPos' 
	end end -- 0x1704
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String AutoFlightRootRot' 
	end end -- 0x1708
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single BalloonCoolDownTime' 
	end end -- 0x170c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single BalloonUpSpeed' 
	end end -- 0x1710
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single BalloonExistTime' 
	end end -- 0x1714
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 BalloonMaxNum' 
	end end -- 0x1718
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single Treatment_warn_boundary' 
	end end -- 0x171c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single UIAvatarLinkBubbleDisplayLength' 
	end end -- 0x1720
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 UIAvatarLinkBubbleClickCooldown' 
	end end -- 0x1724
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LagEffectDurationTime' 
	end end -- 0x1728
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LagEffectKeepScaleDistance' 
	end end -- 0x172c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LagEffectScaleMaxDistance' 
	end end -- 0x1730
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LagEffectMaxShowDistance' 
	end end -- 0x1734
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single LagEffectMaxScale' 
	end end -- 0x1738
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UseFixCrossHeight' 
	end end -- 0x173c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 CreditBehaviorHighPingValue' 
	end end -- 0x1740
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 CreditBehaviorHighPingLastTime' 
	end end -- 0x1744
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String CustomRoomModeNum' 
	end end -- 0x1748
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single DWShieldOffset' 
	end end -- 0x174c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String VersionDownloadLink' 
	end end -- 0x1750
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean BlockUrlAndEmail' 
	end end -- 0x1754
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean BlockPhoneNumber' 
	end end -- 0x1755
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean BRShowStackKillVfx' 
	end end -- 0x1756
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 UGCQuitFeedback' 
	end end -- 0x1758
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UGCQuitMidwayNeedShowMatchResultComment' 
	end end -- 0x175c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean DeleteInventoryByUniqueID' 
	end end -- 0x175d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 RoomAutoRevivalToken' 
	end end -- 0x1760
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 RoomAutoRevivalLimitStage' 
	end end -- 0x1764
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 RoomAutoRevivalLimitTimes' 
	end end -- 0x1768
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 DWShieldFixPosInterval' 
	end end -- 0x176c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean SkillUpgradeMaxWhenPlayerLevelMax' 
	end end -- 0x1770
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean Use3PStopFire_WaitingChangeClipAnim' 
	end end -- 0x1771
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UseIngameHudMiniSwitch' 
	end end -- 0x1772
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean OptimizeLoadUmaText' 
	end end -- 0x1773
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single GrapplingHookGunFOV' 
	end end -- 0x1774
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single FateRandomSubmodeShowTime' 
	end end -- 0x1778
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single DigitaluniverseBGScaleMin' 
	end end -- 0x177c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single DigitaluniverseBGScaleMax' 
	end end -- 0x1780
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single DigitaluniverseBGScaleHideNameThre' 
	end end -- 0x1784
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single DigitaluniverseBGPosx' 
	end end -- 0x1788
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single DigitaluniverseBGPosy' 
	end end -- 0x178c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single DigitaluniverseBGBlurMin' 
	end end -- 0x1790
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single DigitaluniverseBGBlurMax' 
	end end -- 0x1794
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single DigitaluniverseFake3DParam' 
	end end -- 0x1798
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single DigitaluniverseBGPosx1' 
	end end -- 0x179c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single DigitaluniverseBGPosy1' 
	end end -- 0x17a0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single LevelContainerUpDelta' 
	end end -- 0x17a4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean NoLevelContainerUpDeltaForZeroRadius' 
	end end -- 0x17a8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single BlockEditHoldDelay' 
	end end -- 0x17ac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String BigPrizePushCameraEndPosition' 
	end end -- 0x17b0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly String BigPrizePushCameraRotation' 
	end end -- 0x17b4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 BRAirDropLightPickUpDeleteTime' 
	end end -- 0x17b8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single BRAirDropLaserShrinkPercent' 
	end end -- 0x17bc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single UseEnergyStoneBoxTime' 
	end end -- 0x17c0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single UseChokePointTime' 
	end end -- 0x17c4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PCKillLeaderAnimationTime' 
	end end -- 0x17c8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UploadCheckDataOnlyOnce' 
	end end -- 0x17cc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 MedkitElseID' 
	end end -- 0x17d0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean EnableTrainingIslandBloom' 
	end end -- 0x17d4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean UseNewPin' 
	end end -- 0x17d5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single PickUpPinDeltaDelayTime' 
	end end -- 0x17d8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 RoyaleVFXNumUpper' 
	end end -- 0x17dc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 LoadingWaitingTime' 
	end end -- 0x17e0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean DelayShowKillNotification' 
	end end -- 0x17e4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean PlayerEffectUseAsyncLoad' 
	end end -- 0x17e5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean PlayerParachuteSkinUseAsyncLoad' 
	end end -- 0x17e6
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 PreInitPoolMaxSize' 
	end end -- 0x17e8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean PrePoolInstantResource' 
	end end -- 0x17ec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 PrePoolInstantPerFrame' 
	end end -- 0x17f0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean PrePoolInstantResource_FrontEndGame' 
	end end -- 0x17f4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean PreInstantHudName' 
	end end -- 0x17f5
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean OpenInventorySmooth' 
	end end -- 0x17f6
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean InitInventoryItemPool' 
	end end -- 0x17f7
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean InitSkillTemplatePool' 
	end end -- 0x17f8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean DisableCharactorColliderAndAnimatorOnPlane' 
	end end -- 0x17f9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Single UGCWeaponDamageRateSuper' 
	end end -- 0x17fc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean UseColliderFilter' 
	end end -- 0x1800
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single Gun_Line_Check_Step_Change_Threshold' 
	end end -- 0x1804
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean RecycleCarAudioOnGetOff' 
	end end -- 0x1808
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean DelayInstCarShoalAudio' 
	end end -- 0x1809
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean RecycleWeaponBoxOpenEffect' 
	end end -- 0x180a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String UGCOptionalMapConfigIdArray' 
	end end -- 0x180c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String SkipOptionalMapConfigIdArray' 
	end end -- 0x1810
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 UGCAutoDownloadSizeOutsideRoom' 
	end end -- 0x1814
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 UGCAutoDownloadSizeInRoom' 
	end end -- 0x1818
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String UGCUnlockForSmallSizeRemainToDownloadRegions' 
	end end -- 0x181c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableUGCCustomLevelObjectEditor' 
	end end -- 0x1820
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean FixPreLoadResourceID' 
	end end -- 0x1821
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean RouletteChatEnable' 
	end end -- 0x1822
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean MedkitRouletteEnable' 
	end end -- 0x1823
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean GrenadeRouletteEnable' 
	end end -- 0x1824
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single IcewallReleaseDistance1' 
	end end -- 0x1828
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single IcewallReleaseDistance2' 
	end end -- 0x182c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean SmartIcewallOpen' 
	end end -- 0x1830
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single NewbieIcewallControl' 
	end end -- 0x1834
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single SmartIcewallTime' 
	end end -- 0x1838
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single SmartIceWallDownRayLength' 
	end end -- 0x183c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 SmartIceWallFireWaitTickCnt' 
	end end -- 0x1840
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single SmartIceWallDownRayLength2' 
	end end -- 0x1844
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 SmartIceWallDownRayMaxCheckCnt' 
	end end -- 0x1848
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean IsHotMapUGCMatchMakingEnabled' 
	end end -- 0x184c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 HalfWayJoinPerTimes' 
	end end -- 0x1850
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String DisableInGameQuitMatchMode' 
	end end -- 0x1854
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String DisableKillDetailMatchMode' 
	end end -- 0x1858
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String DisableKillDetailGameMode' 
	end end -- 0x185c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single ReplayHighlightScore' 
	end end -- 0x1860
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single CoinCountChangeTime' 
	end end -- 0x1864
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single ChangeToSuperMedkitHP' 
	end end -- 0x1868
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single ChangeToSuperMedkitCD' 
	end end -- 0x186c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single UsingShieldRecoverHPThreshold' 
	end end -- 0x1870
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single InfectionHPShowTime' 
	end end -- 0x1874
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean InfectionOpenGameVoice' 
	end end -- 0x1878
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single ReplayOverlookHeight' 
	end end -- 0x187c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single SpecialCharacterVoiceCoolDown' 
	end end -- 0x1880
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 ModeChooseType' 
	end end -- 0x1884
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableHighlightAnim' 
	end end -- 0x1888
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single HighlightAnimForwardSecond' 
	end end -- 0x188c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single HighlightAnimTotalSecond' 
	end end -- 0x1890
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 HighlightMemoryLowMB' 
	end end -- 0x1894
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 HighlightMemoryMidMB' 
	end end -- 0x1898
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single HighlightStartDelayShort' 
	end end -- 0x189c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single HighlightStartDelayLong' 
	end end -- 0x18a0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 HighlightStartDelayMemoryMB' 
	end end -- 0x18a4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableConveyer' 
	end end -- 0x18a8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean Enable3PEnterMovePlatform' 
	end end -- 0x18a9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single DigitalUniverseBCoreImageDistance' 
	end end -- 0x18ac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single DigitalUniverseBFake3DFocusDistance' 
	end end -- 0x18b0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 DigitalUniverseBTrackPeopleMaximumNumberFactor' 
	end end -- 0x18b4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 Trackradius' 
	end end -- 0x18b8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single Coefficientofcompressibility' 
	end end -- 0x18bc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single Planetoffset' 
	end end -- 0x18c0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 DigitaluniverseBGuiderail' 
	end end -- 0x18c4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableVegetationSimulateInterval' 
	end end -- 0x18c8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableVegetationLODUnload' 
	end end -- 0x18c9
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 VegetationSimulateFrameInterval' 
	end end -- 0x18cc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 VegetationFindPotentVisibleInterval' 
	end end -- 0x18d0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single VegetationSplitUpdateEnableAngle' 
	end end -- 0x18d4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single VegetationSplitUpdateEnablePos' 
	end end -- 0x18d8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 QuadraKillThumbTimerMaxLimit' 
	end end -- 0x18dc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 WaitingPhaseThumbUpBtnShowTime' 
	end end -- 0x18e0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableDynamicGeneratorTickInterval' 
	end end -- 0x18e4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 DynamicGeneratorTickInterval' 
	end end -- 0x18e8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single DynamicGeneratorTickUpdateEnableAngle' 
	end end -- 0x18ec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single DynamicGeneratorTickUpdateEnablePos' 
	end end -- 0x18f0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePlayerPostUpdateInterval' 
	end end -- 0x18f4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 PlayerPostUpdateInterval' 
	end end -- 0x18f8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePlayerPostUpdateIntervalByFrustum' 
	end end -- 0x18fc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 PlayerShadowUpdateInterval' 
	end end -- 0x1900
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePlayerUpdateKinematicsInterval' 
	end end -- 0x1904
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 PlayerUpdateKinematicsInterval' 
	end end -- 0x1908
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePlayerUpdateBehaviourInterval' 
	end end -- 0x190c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 PlayerUpdateBehaviourInterval' 
	end end -- 0x1910
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePlayerUpdateBehaviourIntervalByFrustum' 
	end end -- 0x1914
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePlayerUpdateIntervalByFrustum' 
	end end -- 0x1915
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single CameraFrustumDeltaAngle' 
	end end -- 0x1918
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePlayerUpdateIntervalByDistance' 
	end end -- 0x191c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 PlayerUpdateIntervalDistance' 
	end end -- 0x1920
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 ForcePlayerUpdateDistance' 
	end end -- 0x1924
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 PlayerNotUpdateDistance' 
	end end -- 0x1928
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean FrezeeInvisiblePlayerUpdate' 
	end end -- 0x192c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableClickEffectInputPosCheck' 
	end end -- 0x192d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableOptAnimationIntervalByFrustum' 
	end end -- 0x192e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableHudItemMarkUpdateInterval' 
	end end -- 0x192f
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableMinimapUpdateInterval' 
	end end -- 0x1930
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableHudNameBaseUpdateInterval' 
	end end -- 0x1931
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableMapContentUpdateInterval' 
	end end -- 0x1932
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single MapContentUpdateDistance' 
	end end -- 0x1934
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 MapContentUpdateAngle' 
	end end -- 0x1938
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableWeaponSwitchInfoUpdateInterval' 
	end end -- 0x193c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableHudNameControllerUpdateInterval' 
	end end -- 0x193d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single HudNameControllerUpdateDistance' 
	end end -- 0x1940
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single HudNameControllerHPDiff' 
	end end -- 0x1944
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single EliteHPShowDistance' 
	end end -- 0x1948
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableRescureUpdateInterval' 
	end end -- 0x194c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableSafeZoneInfoUpdateInterval' 
	end end -- 0x194d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableDirectionRulerUpdateInterval' 
	end end -- 0x194e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableHudKillNotificationUpdateInterval' 
	end end -- 0x194f
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePVS' 
	end end -- 0x1950
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePVSAsyncLoad' 
	end end -- 0x1951
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePVSDebug' 
	end end -- 0x1952
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePVSOnLowMemory' 
	end end -- 0x1953
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePVSCullParticleSystem' 
	end end -- 0x1954
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePotentiallyVisibleSet' 
	end end -- 0x1955
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePVSStaticObject' 
	end end -- 0x1956
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnablePVSCombineData' 
	end end -- 0x1957
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 DisablePVSItemTyeFlag' 
	end end -- 0x1958
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableWeaponSkinPokedex' 
	end end -- 0x195c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableWeaponSKinPokedexShare' 
	end end -- 0x195d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean PlayerHookOnZeppelin' 
	end end -- 0x195e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean AirZeppelinUseSpecifiedStropPoint' 
	end end -- 0x195f
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 SingersBSpeedSkill' 
	end end -- 0x1960
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean AirZeppelinOpenBattle' 
	end end -- 0x1964
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 LobbyFaultVFXSwitch' 
	end end -- 0x1968
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableLuckyDrawBoxLevelEffect' 
	end end -- 0x196c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean Stop3PFireAnimLocally' 
	end end -- 0x196d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 ReplaceRGB565Behavior' 
	end end -- 0x1970
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single VehicleDirveCameraHeightCheck' 
	end end -- 0x1974
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean GachaNeedRecoverPreview' 
	end end -- 0x1978
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean IsDeadTalkOpen' 
	end end -- 0x1979
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean IsDownMarkMapOpen' 
	end end -- 0x197a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 CSShopRecommendRank' 
	end end -- 0x197c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 CSShopRecommendFightLimit' 
	end end -- 0x1980
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 CSItemNewTagLimit' 
	end end -- 0x1984
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 BRHotTagRank' 
	end end -- 0x1988
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 BRItemHotTagLimit' 
	end end -- 0x198c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 BRItemNewTagLimit' 
	end end -- 0x1990
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single OpenItemNewHotTagValue' 
	end end -- 0x1994
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 SAPinIslandLikeMax' 
	end end -- 0x1998
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 SAPOLDFFReviveTime' 
	end end -- 0x199c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String SAPNameBoardScrolling' 
	end end -- 0x19a0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 SAPNameBoardPresuppose' 
	end end -- 0x19a4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 SAPFlyToSocialAreaTime' 
	end end -- 0x19a8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 SAPFlyToSocialAreaFoldWingID' 
	end end -- 0x19ac
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 SAPSignBoardUpdateTime' 
	end end -- 0x19b0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 SAPFlodWingJumpHight' 
	end end -- 0x19b4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 SAPFlodWingJumpSpeed' 
	end end -- 0x19b8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 SAPFlodWingID' 
	end end -- 0x19bc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean RefreshCapacityByServerSync' 
	end end -- 0x19c0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String ObserverEmojiRes' 
	end end -- 0x19c4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Int32 ObserveEmojiCd' 
	end end -- 0x19c8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly Boolean KickUserInMatchGame' 
	end end -- 0x19cc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean CadetInvite' 
	end end -- 0x19cd
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean IsLiftUpSquatIconOpen' 
	end end -- 0x19ce
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single WholeBodyFireMaxWaitTime' 
	end end -- 0x19d0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single FootballGame_MaxHitSoundSpeed' 
	end end -- 0x19d4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single FootballGame_WaitingTime' 
	end end -- 0x19d8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single FootballGame_MatchTime' 
	end end -- 0x19dc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean FootballGame_Open' 
	end end -- 0x19e0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String FootballGameOpenTime' 
	end end -- 0x19e4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String FootballGameEndTime' 
	end end -- 0x19e8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String Football_ItemInfo' 
	end end -- 0x19ec
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableResourcePathCompression' 
	end end -- 0x19f0
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableStoreResMemOptimize' 
	end end -- 0x19f1
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableActivityInfoMemOptimize' 
	end end -- 0x19f2
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableStringCache' 
	end end -- 0x19f3
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean EnableUMAMaxNumOpt' 
	end end -- 0x19f4
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single BPSpineAnimStepFourTime' 
	end end -- 0x19f8
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single BPSpineAnimStepTwoTime' 
	end end -- 0x19fc
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single AbandomLifeTime' 
	end end -- 0x1a00
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 LockInZepplinTickCount' 
	end end -- 0x1a04
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Single NewSeasonTipTime' 
	end end -- 0x1a08
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean IsWinCountResultAnimationOn' 
	end end -- 0x1a0c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean IsWinCountResultOn' 
	end end -- 0x1a0d
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean IsWinCountLeaderboardOn' 
	end end -- 0x1a0e
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static String WinCountLobbyGameMode' 
	end end -- 0x1a10
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 MinWinCountNum' 
	end end -- 0x1a14
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 MinBooyahCountNum' 
	end end -- 0x1a18
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 CSSpecialWinStreakNum' 
	end end -- 0x1a1c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static readonly UInt32 BRSpecialWinStreakNum' 
	end end -- 0x1a20
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean LogFpsToFileOnLeaveGame' 
	end end -- 0x1a24
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean shouldDumpVisibleRenderers' 
	end end -- 0x1a25
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean RegisterGcFinished' 
	end end -- 0x1a26
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean LogGcFinished' 
	end end -- 0x1a27
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean CloseGCInRefreshConfig' 
	end end -- 0x1a28
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean CloseGCInRefreshConfigForLowMem' 
	end end -- 0x1a29
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean CloseGCInRefreshConfigForIOS' 
	end end -- 0x1a2a
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean FastQuit_JoinThreadsWithTimeout' 
	end end -- 0x1a2b
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Int32 FastQuit_JoinThreadsTimeoutMs' 
	end end -- 0x1a2c
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static Boolean FastQuit_KillOnJoinThreadsTimeout' 
	end end -- 0x1a30
	gg.addListItems(t)   for i, v in ipairs(t) do if v.flags == gg.TYPE_FLOAT then v.address = v.address + 0x4 		v.name = 'public static UInt32 LazyInitIl2cppMetaInfo' 
		end end -- 0x1a34
		
	
	
	
	
	