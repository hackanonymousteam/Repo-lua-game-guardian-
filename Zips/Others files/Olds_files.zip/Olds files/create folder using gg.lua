
g = {}
g.last = "my folder"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end

gg.alert([[

script for create folder

please select  process game

by Batman Games🍿 

My telegram @batmangamesS 
]])

while true do
  g.info = gg.prompt({
    '📂 Select name folder', -- 1
    '📂 Select folder to to create new directory:' -- 2
  }, g.info, {
    'file', -- 1
    'path' -- 2
  })

  if g.info == nil then
    return
  end

  local myFile = g.info[1]
  local saveFolder = g.info[2]

local a = saveFolder..'/'..myFile
  
  gg.saveVariable(g.info, g.config)
  
local startAddress = 0x0
local endAddress = 0x1

gg.dumpMemory(startAddress, endAddress, a)

local def = "-maps.txt"
local batmen = gg.getTargetInfo()
local Batman = batmen.processName

local last = saveFolder..'/' ..myFile..'/'.. Batman .. def
os.remove(last)
local new = saveFolder..'/' ..myFile

local file = io.open(last, "rb")
if file then
    local data = file:read('*a')
    file:close()
    
    end
    gg.alert('new folder create: '..new)
    
os.exit()

    end
    