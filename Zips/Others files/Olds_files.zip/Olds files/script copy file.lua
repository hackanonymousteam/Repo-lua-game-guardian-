g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end

gg.alert([[

script for copy files

suport all format files

by Batman Games🍿 

My telegram @batmangamesS 
]])

while true do
  g.info = gg.prompt({
    '📂 Select file to copy:', -- 1
    '📂 Select folder to save file copied :' -- 2
  }, g.info, {
    'file', -- 1
    'path' -- 2
  })

  if g.info == nil then
    return
  end

  local myFile = g.info[1]
  local saveFolder = g.info[2]

  local FileName = myFile:match("[^/]+$")
  local FilePath = saveFolder .. "/" .. FileName

  gg.saveVariable(g.info, g.config)
  g.last = myFile

  local file = io.open(g.last, "rb") 
  if file then
    local data = file:read('*a')
    file:close()
    
    local outFile = io.open(FilePath, "wb") 
    if outFile then
      outFile:write(data)
      outFile:close()
    else
      gg.alert('❌ Error opening file for writing.')
      return
    end
  else
    gg.alert('❌ Error opening file for reading.')
    return
  end

  local confirmationMessage = '📂 File saved to: ' .. FilePath .. '\n'
  gg.alert(confirmationMessage, '')
  print("\n▬▬▬▬▬▬▬▬▬▬▬▬▬\n📂 File saved to: " .. FilePath .. "\n▬▬▬▬▬▬▬▬▬▬▬▬▬")
  return
end