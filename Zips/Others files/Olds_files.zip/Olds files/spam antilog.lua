local Rep_=string.rep("🍒虛弱的🍒[∆]🍒獵人 🍒",99)
for k=9,2000 do
gg.refineNumber(Rep_)
end

local tab = {}

Copy = function(orig)
    local orig_type = type(orig)
    local copy
    if orig_type == 'table' then
        copy = {}
        for orig_key, orig_value in next, orig, nil do
            copy[Copy(orig_key)] = Copy(orig_value)
        end
        setmetatable(copy, Copy(getmetatable(orig)))
    else
        copy = orig
    end
    return copy
end

local gen = function (min, max)
 local str = ""
 --for ind = min, max, max / 1024 do
  --str = str .. string.rep(string.char(math.random(33, 126)), max / 1024) 
 --end
 return string.rep(string.char(math.random(32, 126)), max) 
end

local list = {
 gg.getValues,
 gg.clearList, 
 gg.clearResults, 
 gg.getActiveTab, 
 gg.getFile, 
 gg.getLine,
 gg.ListItems, 
 gg.getLocale, 
 gg.getRanges, 
 gg.getResultsCount, 
 gg.SelectedElements, 
 gg.SelectedResults, 
 gg.getSpeed, 
 gg.getTargetInfo, 
 gg.getTargetPackage, 
 gg.hideUiButton, 
 gg.isClickedUiButton, 
 gg.isProcessPaused, 
 gg.isVisible, 
 gg.loadResults, 
 gg.removeListItems, 
 gg.removeResults, 
 gg.setValues, 
 gg.skipRestoreState
}

function table.shuffle(tab)
 for ind = #tab, 2, -1 do
  local newInd = math.random(ind)
  tab[ind], tab[newInd] = tab[newInd], tab[ind]
 end
 
 return tab
end

local time = os.time()

for ind = 0, (512) do
 tab[gen(0, math.random(1024, 1024*8))] = gen(0, math.random(1024, 1024*8)) 
end

for x = 0, 5 do
 table.insert(tab, Copy(tab)) 
end

local spam = function (reps, func)
 for k = 1, reps do
  local bool = pcall(func, tab) 
 end
end

for k = 1, 64 do
 for index, arg in pairs(list) do
  spam(math.random(1, 3), arg)
 end
end
