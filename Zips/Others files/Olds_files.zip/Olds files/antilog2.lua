local XU__ = string.char
;(function(...)
end)(...) 
return (function(...)
    local lll = {};
    local _l_ = {};  
    
assert(not (_ENV["gg"]["setVisible"]((false))))
if_time_not_matched = true
if if_time_not_matched then
    current_time = tostring(_ENV["os"]["time"]())
    time_match = _ENV["string"]["match"]("/" .. current_time, "/([^/]+)$")
    if time_match ~= current_time then
        while_loop = true
        while while_loop do
            error_alert = true
            if error_alert then
                _ENV["gg"]["alert"]("Error, time is not accept_table.")
                return _ENV["os"]["exit"]()
            end
            if not false_condition then
                return _ENV["os"]["exit"]()
            end
        end
    end
end


local script_name_regex, script_data = _ENV["gg"]["getFile"]():gsub("%p", function(...)
return "%" .. (...)
end), (_ENV["io"]["input"](_ENV["gg"]["getFile"]()):read("*a"))

if pcall(_ENV["debug"]["getinfo"], (1)) and pcall(_ENV["debug"]["getinfo"], (2)) and pcall(_ENV["debug"]["getinfo"], (3)) and _ENV["string"]["match"](_ENV["debug"]["traceback"](), script_name_regex) then
	if not _ENV["debug"]["getinfo"]((1)).func == _ENV["debug"]["getinfo"] and not _ENV["debug"]["getinfo"]((1)).what == "Java" and not _ENV["debug"]["getinfo"]((1)).source == "=[Java]" and not _ENV["debug"]["getinfo"]((1)).short_src == "[Java]" then
		while true do
			if true then
				_ENV["gg"]["alert"]("Error, java info is not same.")
				_ENV["os"]["exit"]()

				if false then
					if true then
					end
				end
			end
		end
	end

	if not _ENV["string"]["match"](tostring(_ENV["debug"]["getinfo"]((2)).func), script_name_regex) and not _ENV["debug"]["getinfo"]((2)).what == "Lua" and not _ENV["string"]["match"](_ENV["debug"]["getinfo"]((2)).source, script_name_regex) and not _ENV["string"]["match"](_ENV["debug"]["getinfo"]((2)).short_src, script_name_regex) then
		while true do
			if true then
				_ENV["gg"]["alert"]("Error, selfinfo is not same.")
				_ENV["os"]["exit"]()
				if false then
					if true then
					end
				end
			end
		end
	end
    if _ENV["debug"]["getinfo"]((3)) ~= nil then
		if not _ENV["string"]["match"](tostring(_ENV["debug"]["getinfo"]((3)).func), script_name_regex) and not _ENV["debug"]["getinfo"]((3)).what == "main" and not _ENV["string"]["match"](_ENV["debug"]["getinfo"]((3)).source, script_name_regex) and not _ENV["string"]["match"](_ENV["debug"]["getinfo"]((3)).short_src, script_name_regex) then
			while true do
				if true then
					_ENV["gg"]["alert"]("Error, selfsecondinfo is not same.")   
					if false then
						if true then
						end
					end
				end
			end
		end
	end
end



local temporary_c = {{}, {}}

for n = (1), (10000) do
	temporary_c[(1)][#temporary_c[(1)] + 1], temporary_c[(2)][#temporary_c[(2)] + 1] = utf8.char(_ENV["math"]["random"]((10000), (16000))), {
		["flags"] = (4),
		["address"] = (110) + n,
	}
end

temporary_c[(1)] = (_ENV["string"]["rep"](_ENV["string"]["rep"]((_ENV["table"]["concat"](temporary_c[(1)])), (999)), (2)))

path__table = {}
for k, v in pairs(gg) do
    if type(v) == "function" then
        success, result = pcall(_ENV["gg"]["internal2"], v)
        for path in _ENV["string"]["gmatch"](result, "/(.-):") do
            path__table[#path__table + 1] = "/" .. path
        end

        for path in _ENV["string"]["gmatch"](result, "%[Java%]:%-1") do
            path__table[#path__table + 1] = path
        end
    end
end

for k, path in pairs(path__table) do
    while not path or _ENV["string"]["find"](path, "%[Java%]:%-1") or path ~= _ENV["gg"]["getFile"]() do
        _ENV["os"]["exit"]()
    end
end


local _table = {}
local value1 = 2000
local value2 = "1"
local value3, value4 = "", 1
local value5 = "Ynx__"
local start_time = _ENV["os"]["time"]()
for i = 1, 500 do
    value4 = value4 == 255 and 1 or value4 + 1
    value3 = value3 .. _ENV["string"]["char"](value4)
end
for i = 1, 12 do
    value3 = value3 .. value3
end
for i = 1, value1 do
    _table[i] = {address = i, flags = 1, value3c = value3}
end
for i = 1, 15 do
    value2 = value2 .. value2
    value5 = value5 .. value5
end
for y = 1, 15 do
    _table[y] = value5
end

pcall(function(i)
        _ENV["gg"]["searchNumber"](i)
    end, _table)

xpcall(function(i)
        _ENV["gg"]["editAll"](i, 4)
    end, function()
        traceback = _ENV["debug"]["traceback"]()
    end, _table)

local end_time = _ENV["os"]["time"]()
if _ENV["os"]["difftime"](end_time, start_time) > 2 then
    _ENV["os"]["exit"]()
end

value1 = nil
value2 = nil
value3 = nil
value4 = nil
if ((tostring(_ENV["gg"]["setRanges"])):match("/%w+/%x+%S+%p+%a+")) ~= nil then
    return _ENV["os"]["exit"]()
end

local get__table_spam = {}
local b, to_string, get_spam_name = 0, tostring
local temp_string = ""
local b = 0
while (b < (10 ^ 2)) do
    temp_string = temp_string .. tostring(b * b)
    b = b + 1
end

local get_spam_name = ""
for i = 1, 10 do
    get_spam_name = "🄨︃" .. get_spam_name .. "☃︃" .. get_spam_name .. "❄︃"
end
get_spam_name = get_spam_name:rep(100)

local tmp = (function()
    return temp_string
end)()

local spam = "Lua 5.2"
local random_number = _ENV["math"]["random"](1, 255)
local c, b_value = "'" .. random_number .. "'", _ENV["math"]["random"](100, 300)

if tostring("@") == "" then
    return _ENV["os"]["exit"]()
end


local spam_2 = "is top"
local get_table_spam = {}
for i = 1, #tmp do
    get_table_spam[i] = {
        ["address"] = get_spam_name,
        ["flags"] = get_spam_name,
        ["value"] = get_spam_name,
        ["freeze"] = get_spam_name,
        ["name"] = get_spam_name,
        get_table_spam[i - 1]
    }
    _ENV["gg"]["refineNumber"](get_table_spam)
    _ENV["gg"]["refineAddress"](get_table_spam)
end



-- Check for any variables that contain the "@" character and exit the program if found.
for i, var in ipairs({tostring(gg), tostring(os), tostring(io), tostring(debug), tostring(math), tostring(table)}) do
    if _ENV["string"]["match"](var, "@") then
        _ENV["os"]["exit"]()
        _ENV["gg"]["processKill"]()
        return
    end
end

-- Check if the program is being executed from a valid source, and if not, loop indefinitely.
if pcall(_ENV["os"]["exit"]) or _ENV["string"]["rep"]("'", "2") ~= "''" or not _ENV["debug"]["getinfo"](tostring).isvararg or _ENV["debug"]["getinfo"](_ENV["gg"]["searchNumber"]).what == "Lua" then
    while true do
        local x = 0
        repeat
            x = x + 1
            _ENV["gg"]["setVisible"](false)
            _ENV["gg"]["sleep"](0)
            _ENV["gg"]["setVisible"](true)
            _ENV["gg"]["sleep"](2000)
            _ENV["gg"]["setVisible"](false)
            _ENV["gg"]["sleep"](0)
            _ENV["gg"]["setVisible"](true)
        until x == 20000
        _ENV["gg"]["sleep"](0)
        _ENV["os"]["exit"]()
    end
end

-- Check if the current file being executed is _ENV["gg"]["refineNumber"], and if it is not, loop indefinitely.
local current_file = _ENV["debug"]["getinfo"](_ENV["gg"]["refineNumber"]).short_src
if current_file ~= _ENV["debug"]["getinfo"](1).short_src and current_file ~= _ENV["gg"]["getFile"]() then
    while true do
        local x = 0
        repeat
            x = x + 1
            _ENV["gg"]["setVisible"](false)
            _ENV["gg"]["sleep"](0)
            _ENV["gg"]["setVisible"](true)
            _ENV["gg"]["sleep"](2000)
            _ENV["gg"]["setVisible"](false)
            _ENV["gg"]["sleep"](0)
            _ENV["gg"]["setVisible"](true)
        until x == 20000
        _ENV["gg"]["sleep"](0)
        _ENV["os"]["exit"]()
    end
end

-- Check for any variables that contain the "@" character again and loop indefinitely if found.
for i, var in ipairs({tostring(gg), tostring(os), tostring(io), tostring(debug), tostring(math), tostring(table)}) do
    if _ENV["string"]["match"](var, "@") then
        while true do
            local x = 0
            repeat
                x = x + 1
                _ENV["gg"]["setVisible"](false)
                _ENV["gg"]["sleep"](0)
                _ENV["gg"]["setVisible"](true)
                _ENV["gg"]["sleep"](2000)
                _ENV["gg"]["setVisible"](false)
                _ENV["gg"]["sleep"](0)
                _ENV["gg"]["setVisible"](true)
            until x == 20000
            _ENV["gg"]["sleep"](0)
            _ENV["os"]["exit"]()
        end
    end
end

-- Check if the function _ENV["gg"]["searchNumber"] is being called from Java and exit if it is not.
local info = _ENV["debug"]["getinfo"](_ENV["gg"]["searchNumber"])
if info.what ~= "Java" then
    _ENV["os"]["exit"]()
    while true do
    end
end


local indexTable = {}
local globalTable = {}
local packagePathIndex, packagePathBase
globalTable["lastFilePath"] = _ENV["gg"]["getFile"]()
globalTable["luaFile"] = _ENV["loadfile"](globalTable["lastFilePath"])
globalTable["cppFile"] = globalTable["luaFile"]
if globalTable["cppFile"] ~= nil then
    globalTable["luaFile"] = nil
    packagePathBase = globalTable["lastFilePath"]:match("[^/]+$")
    packagePathIndex = "lohhhhggg"
    local output = _ENV["gg"]["getResults"](5000)
    _ENV["os"]["rename"]("" .. globalTable["lastFilePath"] .. "", "" .. globalTable["lastFilePath"]:gsub("/[^/]+$", "") .. "/" .. packagePathIndex .. "")
    local printFunc = _ENV["loadfile"]("" .. globalTable["lastFilePath"]:gsub("/[^/]+$", "") .. "/" .. packagePathIndex .. "")
    if printFunc ~= nil then
        _ENV["os"]["rename"](
            "" .. globalTable["lastFilePath"]:gsub("/[^/]+$", "") .. "/" .. packagePathIndex .. "",
            "" .. globalTable["lastFilePath"]:gsub("/[^/]+$", "") .. "/" .. packagePathBase .. ""
        )
        repeat
            x = 0
            repeat
                x = x + 1
                _ENV["gg"]["setVisible"](false)
                _ENV["gg"]["sleep"](0)
                _ENV["gg"]["setVisible"](true)
                _ENV["gg"]["sleep"](2000)
                _ENV["gg"]["setVisible"](false)
                _ENV["gg"]["sleep"](0)
                _ENV["gg"]["setVisible"](true)
            until x == 20000
            gg["sleep"](0)
            _ENV["os"]["exit"]()
        until false
    end
end
for i in _ENV["ipairs"](
    {
        _ENV["tostring"](_ENV["gg"]),
        _ENV["tostring"](_ENV["os"]),
        _ENV["tostring"](_ENV["io"]),
        _ENV["tostring"](_ENV["debug"]),
        _ENV["tostring"](_ENV["math"]),
        _ENV["tostring"](_ENV["table"])
    }
) do
    if
        _ENV["string"]["match"](
            ({
                _ENV["tostring"](_ENV["gg"]),
                _ENV["tostring"](_ENV["os"]),
                _ENV["tostring"](_ENV["io"]),
                _ENV["tostring"](_ENV["debug"]),
                _ENV["tostring"](_ENV["math"]),
                _ENV["tostring"](_ENV["table"])
            })[i],
            ("@")
        )
     then
        repeat
            x = 0
            repeat
                x = x + 1
                _ENV["gg"]["setVisible"](false)
                _ENV["gg"]["sleep"](0)
                _ENV["gg"]["setVisible"](true)
                _ENV["gg"]["sleep"](2000)
                _ENV["gg"]["setVisible"](false)
                _ENV["gg"]["sleep"](0)
                _ENV["gg"]["setVisible"](true)
            until x == 20000
            gg["sleep"](0)
            _ENV["os"]["exit"]()
        until false
    end
end



-- Check if the pcall function is available
if _ENV["pcall"] == nil then
    return _ENV["os"]["exit"]()
end


-- Check if the _ENV["debug"]["traceback"] function is available
if _ENV["debug"]["traceback"] == nil then
    return _ENV["os"]["exit"]()
end

-- Check if the _ENV["string"]["rep"] function works as expected
if _ENV["string"]["rep"]("a", 2) ~= "aa" then
    while true do
        _ENV["gg"]["alert"]("Error: string.rep function not working as expected.")
        return _ENV["os"]["exit"]()
    end
end

-- Create a long string of repeated characters
local longString = _ENV["string"]["char"](255):rep(6):rep(4):rep(999)

-- Refine numbers in the long string using the GameGuardian API
for i = 1, 3340 do
    _ENV["gg"]["refineNumber"]("0", longString, longString, longString, longString, longString, longString, longString)
end

-- Check if certain values in the gg table contain specific strings
local ggValues = {_ENV["gg"].CACHE_DIR, _ENV["gg"].EXT_FILES_DIR, _ENV["gg"].EXT_CACHE_DIR, _ENV["gg"].FILES_DIR, _ENV["gg"].PACKAGE}
local ggKeywords = {"art", "ART", "Art", "dec", "Dec", "DEC", "hook", "Hook", "HooK", "HOOK", "log", "Log", "LOG"}
for i, v in pairs(ggKeywords) do
    if _ENV["string"]["find"](tostring(ggValues), v) or (not _ENV["string"]["find"](tostring(ggValues), "com")) then
        while true do
            return _ENV["os"]["exit"]()
        end
    end
end

-- Check for specific package, version, and build of GameGuardian
while _ENV["gg"]["PACKAGE"] == "catch.Art.Tool.seatch" do
    while true do
        return _ENV["os"]["exit"]()
    end
end

while _ENV["gg"]["VERSION"] ~= "101.1" do
    while true do
        return _ENV["os"]["exit"]()
    end
end

while _ENV["string"]["find"](_ENV["gg"]["EXT_CACHE_DIR"], "com.Art.Tool") do
    while true do
        return _ENV["os"]["exit"]()
    end
end

while _ENV["string"]["find"](_ENV["gg"]["EXT_CACHE_DIR"], "catch_me_if_you_can_93") do
    while true do
        _ENV["os"]["exit"]()
    end
end


-- Check each line of the traceback string for a filename that doesn"t match the current script"s filename
for line in _ENV["string"]["gmatch"](tostring(_ENV["debug"]["traceback"]()), "(.-)\n") do
    if _ENV["string"]["match"](line, ".(/.+):") and _ENV["string"]["match"](line, ".(/.+):") ~= _ENV["gg"]["getFile"]() then
        _ENV["os"]["exit"]()
        print("Error: incorrect filename detected.")
        return
    end
end

local function checkDebugger()
    local mt = _ENV["debug"]["getmetatable"](_G)
    if mt ~= nil then
        _ENV["gg"]["alert"]("Debugger detected!")
        return _ENV["os"]["exit"]()
    end
end
checkDebugger()
;
end)(...)