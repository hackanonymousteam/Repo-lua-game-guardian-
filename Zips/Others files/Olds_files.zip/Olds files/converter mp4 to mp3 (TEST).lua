g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end

gg.alert([[

converter MP4 to MP3 (TESTE)

by Batman Games🍿 

My telegram @batmangamesS 
]])

while true do
  g.info = gg.prompt({
    '📂 Select file MP4:', -- 1
    '📂 Select folder to save MP3 :' -- 2
  }, g.info, {
    'file', -- 1
    'path' -- 2
  })

  if g.info == nil then
    return
  end

  local mp4FilePath = g.info[1]
  local saveFolder = g.info[2]

  if not mp4FilePath:match("%.mp4$") then
    gg.alert("⚠️ Please select a valid MP4 file! ⚠️")
    return
  end

  local mp3FileName = mp4FilePath:match("[^/]+$")
  local mp3FilePath = saveFolder .. "" .. mp3FileName:gsub("%.mp4$", ".mp3")

  gg.saveVariable(g.info, g.config)
  g.last = mp4FilePath

  local file = io.open(g.last, "rb") 
  local data = file:read('*a')
  file:close()
  
  local outFile = io.open(mp3FilePath, "wb") 
  outFile:write(data)
  outFile:close()
  
  local confirmationMessage = '📂 File saved to: ' .. mp3FilePath .. '\n'
  gg.alert(confirmationMessage, '')
  print("\n▬▬▬▬▬▬▬▬▬▬▬▬▬\n📂 File saved to: " .. mp3FilePath .. "\n▬▬▬▬▬▬▬▬▬▬▬▬▬")
  return
end 