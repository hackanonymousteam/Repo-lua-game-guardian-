.class public Lcom/up/activities/wifi;
.super Ljava/lang/Object;
.source "wifi.java"


# instance fields
.field private activity:Landroid/app/Activity;


# direct methods
.method constructor <init>(Landroid/app/Activity;)V
    .registers 9

    .prologue
    .line 14
    move-object v0, p0

    move-object v1, p1

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 15
    move-object v5, v1

    move-object v3, v5

    .line 16
    move-object v5, v0

    move-object v6, v3

    check-cast v6, Landroid/app/Activity;

    iput-object v6, v5, Lcom/up/activities/wifi;->activity:Landroid/app/Activity;

    return-void
.end method

.method public static isWifiConnected(Landroid/content/Context;)Z
    .registers 8

    .prologue
    .line 21
    move-object v0, p0

    move-object v5, v0

    const-string v6, "connectivity"

    invoke-virtual {v5, v6}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/net/ConnectivityManager;

    move-object v2, v5

    .line 22
    move-object v5, v2

    if-eqz v5, :cond_22

    .line 23
    move-object v5, v2

    invoke-virtual {v5}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object v5

    move-object v3, v5

    .line 24
    move-object v5, v3

    if-eqz v5, :cond_22

    move-object v5, v3

    invoke-virtual {v5}, Landroid/net/NetworkInfo;->getType()I

    move-result v5

    const/4 v6, 0x1

    if-ne v5, v6, :cond_22

    .line 25
    const/4 v5, 0x1

    move v0, v5

    .line 28
    :goto_21
    return v0

    :cond_22
    const/4 v5, 0x0

    move v0, v5

    goto :goto_21
.end method
