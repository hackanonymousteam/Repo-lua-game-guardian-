.class final Landroid/ext/Script$isWifiConnected;
.super Landroid/ext/Script$ApiFunction;
.source "Script.java"


# instance fields
.field final synthetic this$0:Landroid/ext/Script;


# direct methods
.method constructor <init>(Landroid/ext/Script;)V
    .registers 2

    .prologue
    .line 3811
    iput-object p1, p0, Landroid/ext/Script$isWifiConnected;->this$0:Landroid/ext/Script;

    invoke-direct {p0}, Landroid/ext/Script$ApiFunction;-><init>()V

    return-void
.end method


# virtual methods
.method a()Ljava/lang/String;
    .registers 2

    .prologue
    .line 3813
    const-string v0, "gg.isWifiConnected() -> boolean"

    return-object v0
.end method

.method public d(Lluaj/ap;)Lluaj/ap;
    .registers 3
    .param p1, "L"  # Lluaj/ap;

    .prologue
    .line 3817
    invoke-static {}, Landroid/ext/Tools;->e()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/up/activities/wifi;->isWifiConnected(Landroid/content/Context;)Z

    move-result v0

    .line 3818
    .local v0, "isConnected":Z
    if-eqz v0, :cond_d

    .line 3819
    sget-object v0, Lluaj/LuaValue;->v:Lluaj/LuaBoolean;

    return-object v0

    .line 3821
    :cond_d
    sget-object v0, Lluaj/LuaValue;->w:Lluaj/LuaBoolean;

    return-object v0
.end method

.method protected m_()I
    .registers 2

    .prologue
    .line 3812
    const/4 v0, 0x1

    return v0
.end method
