A = gg.isWifiConnected()
if A == false then
    gg.alert("WiFi off...")
    os.exit()
else
    gg.alert("WiFi on...")
end