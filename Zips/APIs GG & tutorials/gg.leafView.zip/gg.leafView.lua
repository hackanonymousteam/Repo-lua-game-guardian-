

Link = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYU7deExXhqXvLUUWbZwFpWmAECIogFcHB_778mWpUuw&s=10"
Name = "/sdcard/Photo_For_Test.png"
ggg = gg.makeRequest(Link).content
if ggg == nil then
os.exit() end
io.open(Name, "w"):write(ggg)

gg.setVisible(false)
gg.leafView(Name, 10000)
