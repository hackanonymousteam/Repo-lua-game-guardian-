.class public Lcom/web/activities/web;
.super Landroid/widget/RelativeLayout;
.source "web.java"


# instance fields
.field private webView:Landroid/webkit/WebView;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 7

    .prologue
    .line 17
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    move-object v4, v1

    invoke-direct {v3, v4}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;)V

    .line 18
    move-object v3, v0

    move-object v4, v1

    invoke-direct {v3, v4}, Lcom/web/activities/web;->init(Landroid/content/Context;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 10

    .prologue
    .line 22
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    move-object v5, v1

    move-object v6, v2

    invoke-direct {v4, v5, v6}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 23
    move-object v4, v0

    move-object v5, v1

    invoke-direct {v4, v5}, Lcom/web/activities/web;->init(Landroid/content/Context;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 13

    .prologue
    .line 27
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move-object v5, v0

    move-object v6, v1

    move-object v7, v2

    move v8, v3

    invoke-direct {v5, v6, v7, v8}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 28
    move-object v5, v0

    move-object v6, v1

    invoke-direct {v5, v6}, Lcom/web/activities/web;->init(Landroid/content/Context;)V

    return-void
.end method

.method private init(Landroid/content/Context;)V
    .registers 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")V"
        }
    .end annotation

    .prologue
    .line 33
    move-object v0, p0

    move-object v1, p1

    move-object v6, v0

    const/4 v7, 0x0

    invoke-virtual {v6, v7}, Lcom/web/activities/web;->setBackgroundColor(I)V

    .line 35
    move-object v6, v0

    new-instance v7, Landroid/webkit/WebView;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    move-object v9, v1

    invoke-direct {v8, v9}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V

    iput-object v7, v6, Lcom/web/activities/web;->webView:Landroid/webkit/WebView;

    .line 37
    new-instance v6, Landroid/widget/RelativeLayout$LayoutParams;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    const/4 v8, -0x1

    const/4 v9, -0x1

    invoke-direct {v7, v8, v9}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    move-object v3, v6

    .line 42
    move-object v6, v0

    iget-object v6, v6, Lcom/web/activities/web;->webView:Landroid/webkit/WebView;

    move-object v7, v3

    invoke-virtual {v6, v7}, Landroid/webkit/WebView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 44
    move-object v6, v0

    iget-object v6, v6, Lcom/web/activities/web;->webView:Landroid/webkit/WebView;

    const/4 v7, 0x0

    invoke-virtual {v6, v7}, Landroid/webkit/WebView;->setBackgroundColor(I)V

    .line 46
    move-object v6, v0

    iget-object v6, v6, Lcom/web/activities/web;->webView:Landroid/webkit/WebView;

    const/4 v7, 0x1

    const/4 v8, 0x0

    check-cast v8, Landroid/graphics/Paint;

    invoke-virtual {v6, v7, v8}, Landroid/webkit/WebView;->setLayerType(ILandroid/graphics/Paint;)V

    .line 48
    move-object v6, v0

    iget-object v6, v6, Lcom/web/activities/web;->webView:Landroid/webkit/WebView;

    invoke-virtual {v6}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v6

    move-object v4, v6

    .line 49
    move-object v6, v4

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    .line 50
    move-object v6, v4

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V

    .line 51
    move-object v6, v4

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/webkit/WebSettings;->setAllowFileAccess(Z)V

    .line 52
    move-object v6, v4

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/webkit/WebSettings;->setAllowContentAccess(Z)V

    .line 54
    move-object v6, v0

    move-object v7, v0

    iget-object v7, v7, Lcom/web/activities/web;->webView:Landroid/webkit/WebView;

    invoke-virtual {v6, v7}, Lcom/web/activities/web;->addView(Landroid/view/View;)V

    .line 56
    move-object v6, v0

    iget-object v6, v6, Lcom/web/activities/web;->webView:Landroid/webkit/WebView;

    const-string v7, "file:///android_asset/main.html"

    invoke-virtual {v6, v7}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public getWebView()Landroid/webkit/WebView;
    .registers 4

    .prologue
    .line 60
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lcom/web/activities/web;->webView:Landroid/webkit/WebView;

    move-object v0, v2

    return-object v0
.end method
