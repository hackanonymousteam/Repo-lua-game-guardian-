
local log = gg.prompt({
    "❦ REGION_ANONYMOUS",
    "❦ REGION_ASHMEM",
    "❦ REGION_BAD"
    
}, {}, {"checkbox", "checkbox", "checkbox"})

if log == nil then return end

if log[1] then
 gg.alert("REGION_ANONYMOUS: ON") 
else 
gg.alert("REGION_ANONYMOUS: OFF") 
end

if log[2] then 
gg.alert("REGION_ASHMEM: ON") 
else 
gg.alert("REGION_ASHMEM: OFF") 

end
if log[3] then 
gg.alert("REGION_BAD: ON") 
else
 gg.alert("REGION_BAD: OFF") 

end
 