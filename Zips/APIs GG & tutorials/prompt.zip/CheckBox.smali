.class public Landroid/fix/CheckBox;
.super Landroid/widget/CheckBox;
.source "src"


# instance fields
.field private mCheckedDrawable:Landroid/graphics/drawable/Drawable;

.field private mUncheckedDrawable:Landroid/graphics/drawable/Drawable;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    .prologue
    .line 30
    invoke-direct {p0, p1}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;)V

    .line 31
    invoke-direct {p0, p1}, Landroid/fix/CheckBox;->init(Landroid/content/Context;)V

    .line 32
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3

    .prologue
    .line 26
    invoke-direct {p0, p1, p2}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 27
    invoke-direct {p0, p1}, Landroid/fix/CheckBox;->init(Landroid/content/Context;)V

    .line 28
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4

    .prologue
    .line 22
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 23
    invoke-direct {p0, p1}, Landroid/fix/CheckBox;->init(Landroid/content/Context;)V

    .line 24
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .registers 5

    .prologue
    .line 18
    invoke-direct {p0, p1, p2, p3, p4}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    .line 19
    invoke-direct {p0, p1}, Landroid/fix/CheckBox;->init(Landroid/content/Context;)V

    .line 20
    return-void
.end method

.method private init(Landroid/content/Context;)V
    .registers 4

    .prologue
    .line 35
    const v0, 0x7f020074

    invoke-virtual {p1, v0}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iput-object v0, p0, Landroid/fix/CheckBox;->mCheckedDrawable:Landroid/graphics/drawable/Drawable;

    .line 36
    const v0, 0x7f020075

    invoke-virtual {p1, v0}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iput-object v0, p0, Landroid/fix/CheckBox;->mUncheckedDrawable:Landroid/graphics/drawable/Drawable;

    .line 38
    invoke-virtual {p0}, Landroid/fix/CheckBox;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_1e

    iget-object v0, p0, Landroid/fix/CheckBox;->mCheckedDrawable:Landroid/graphics/drawable/Drawable;

    :goto_1a
    invoke-virtual {p0, v0}, Landroid/fix/CheckBox;->setButtonDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 39
    return-void

    .line 38
    :cond_1e
    iget-object v0, p0, Landroid/fix/CheckBox;->mUncheckedDrawable:Landroid/graphics/drawable/Drawable;

    goto :goto_1a
.end method

.method private updateDrawable()V
    .registers 2

    .prologue
    .line 43
    invoke-virtual {p0}, Landroid/fix/CheckBox;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_c

    iget-object v0, p0, Landroid/fix/CheckBox;->mCheckedDrawable:Landroid/graphics/drawable/Drawable;

    :goto_8
    invoke-virtual {p0, v0}, Landroid/fix/CheckBox;->setButtonDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 44
    return-void

    .line 43
    :cond_c
    iget-object v0, p0, Landroid/fix/CheckBox;->mUncheckedDrawable:Landroid/graphics/drawable/Drawable;

    goto :goto_8
.end method


# virtual methods
.method protected drawableStateChanged()V
    .registers 2

    .prologue
    .line 45
    :try_start_0
    invoke-super {p0}, Landroid/widget/CheckBox;->drawableStateChanged()V
    :try_end_3
    .catch Ljava/lang/ArrayIndexOutOfBoundsException; {:try_start_0 .. :try_end_3} :catch_4

    .line 49
    :goto_3
    return-void

    .line 46
    :catch_4
    move-exception v0

    .line 47
    invoke-static {v0}, Landroid/ext/la;->a(Ljava/lang/Throwable;)I

    goto :goto_3
.end method

.method public getSecClipboardEnabled()Z
    .registers 2

    .prologue
    .line 188
    const/4 v0, 0x0

    return v0
.end method

.method public invalidateDrawable(Landroid/graphics/drawable/Drawable;)V
    .registers 3

    .prologue
    .line 64
    :try_start_0
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->invalidateDrawable(Landroid/graphics/drawable/Drawable;)V
    :try_end_3
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_3} :catch_4

    .line 68
    :goto_3
    return-void

    .line 65
    :catch_4
    move-exception v0

    .line 66
    invoke-static {v0}, Landroid/ext/la;->a(Ljava/lang/Throwable;)I

    goto :goto_3
.end method

.method public onDragEvent(Landroid/view/DragEvent;)Z
    .registers 3

    .prologue
    .line 140
    :try_start_0
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onDragEvent(Landroid/view/DragEvent;)Z
    :try_end_3
    .catch Ljava/lang/ClassCastException; {:try_start_0 .. :try_end_3} :catch_5

    move-result v0

    .line 144
    :goto_4
    return v0

    .line 141
    :catch_5
    move-exception v0

    .line 142
    invoke-static {v0}, Landroid/ext/la;->a(Ljava/lang/Throwable;)I

    .line 144
    const/4 v0, 0x0

    goto :goto_4
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 3

    .prologue
    .line 129
    :try_start_0
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onDraw(Landroid/graphics/Canvas;)V
    :try_end_3
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_3} :catch_4
    .catch Ljava/lang/ArrayIndexOutOfBoundsException; {:try_start_0 .. :try_end_3} :catch_9

    .line 135
    :goto_3
    return-void

    .line 130
    :catch_4
    move-exception v0

    .line 131
    invoke-static {v0}, Landroid/ext/la;->a(Ljava/lang/Throwable;)I

    goto :goto_3

    .line 132
    :catch_9
    move-exception v0

    .line 133
    invoke-static {v0}, Landroid/ext/la;->a(Ljava/lang/Throwable;)I

    goto :goto_3
.end method

.method public onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .registers 3
    .annotation build Landroid/annotation/TargetApi;
        value = 0xe
    .end annotation

    .prologue
    .line 92
    :try_start_0
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    :try_end_3
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_3} :catch_4

    .line 96
    :goto_3
    return-void

    .line 93
    :catch_4
    move-exception v0

    .line 94
    invoke-static {v0}, Landroid/ext/la;->a(Ljava/lang/Throwable;)I

    goto :goto_3
.end method

.method public onKeyShortcut(ILandroid/view/KeyEvent;)Z
    .registers 4

    .prologue
    .line 160
    :try_start_0
    invoke-super {p0, p1, p2}, Landroid/widget/CheckBox;->onKeyShortcut(ILandroid/view/KeyEvent;)Z
    :try_end_3
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_3} :catch_5

    move-result v0

    .line 164
    :goto_4
    return v0

    .line 161
    :catch_5
    move-exception v0

    .line 162
    invoke-static {v0}, Landroid/ext/la;->a(Ljava/lang/Throwable;)I

    .line 164
    const/4 v0, 0x0

    goto :goto_4
.end method

.method protected onMeasure(II)V
    .registers 6

    .prologue
    .line 150
    :try_start_0
    invoke-super {p0, p1, p2}, Landroid/widget/CheckBox;->onMeasure(II)V
    :try_end_3
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_3} :catch_4

    .line 155
    :goto_3
    return-void

    .line 151
    :catch_4
    move-exception v0

    .line 152
    invoke-static {v0}, Landroid/ext/la;->a(Ljava/lang/Throwable;)I

    .line 153
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    const/4 v2, 0x0

    invoke-static {v1, v0, v2}, Landroid/ext/ho;->a(Ljava/lang/Thread;Ljava/lang/Throwable;Z)Ljava/lang/String;

    goto :goto_3
.end method

.method public onTextContextMenuItem(I)Z
    .registers 3

    .prologue
    .line 170
    :try_start_0
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onTextContextMenuItem(I)Z
    :try_end_3
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_3} :catch_5

    move-result v0

    .line 174
    :goto_4
    return v0

    .line 171
    :catch_5
    move-exception v0

    .line 172
    invoke-static {v0}, Landroid/ext/la;->a(Ljava/lang/Throwable;)I

    .line 174
    const/4 v0, 0x0

    goto :goto_4
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 3

    .prologue
    .line 54
    :try_start_0
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onTouchEvent(Landroid/view/MotionEvent;)Z
    :try_end_3
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_3} :catch_5

    move-result v0

    .line 58
    :goto_4
    return v0

    .line 55
    :catch_5
    move-exception v0

    .line 56
    invoke-static {v0}, Landroid/ext/la;->a(Ljava/lang/Throwable;)I

    .line 58
    const/4 v0, 0x0

    goto :goto_4
.end method

.method public onWindowFocusChanged(Z)V
    .registers 3

    .prologue
    .line 180
    :try_start_0
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onWindowFocusChanged(Z)V
    :try_end_3
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_3} :catch_4

    .line 184
    :goto_3
    return-void

    .line 181
    :catch_4
    move-exception v0

    .line 182
    invoke-static {v0}, Landroid/ext/la;->a(Ljava/lang/Throwable;)I

    goto :goto_3
.end method

.method public performLongClick()Z
    .registers 2

    .prologue
    .line 119
    :try_start_0
    invoke-super {p0}, Landroid/widget/CheckBox;->performLongClick()Z
    :try_end_3
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_3} :catch_5

    move-result v0

    .line 123
    :goto_4
    return v0

    .line 120
    :catch_5
    move-exception v0

    .line 121
    invoke-static {v0}, Landroid/ext/la;->a(Ljava/lang/Throwable;)I

    .line 123
    const/4 v0, 0x0

    goto :goto_4
.end method

.method public playSoundEffect(I)V
    .registers 3

    .prologue
    .line 101
    :try_start_0
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->playSoundEffect(I)V
    :try_end_3
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_3} :catch_4

    .line 105
    :goto_3
    return-void

    .line 102
    :catch_4
    move-exception v0

    .line 103
    invoke-static {v0}, Landroid/ext/la;->a(Ljava/lang/Throwable;)I

    goto :goto_3
.end method

.method public refreshDrawableState()V
    .registers 2

    .prologue
    .line 82
    :try_start_0
    invoke-super {p0}, Landroid/widget/CheckBox;->refreshDrawableState()V
    :try_end_3
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_3} :catch_4

    .line 86
    :goto_3
    return-void

    .line 83
    :catch_4
    move-exception v0

    .line 84
    invoke-static {v0}, Landroid/ext/la;->a(Ljava/lang/Throwable;)I

    goto :goto_3
.end method

.method public sendAccessibilityEvent(I)V
    .registers 3

    .prologue
    .line 110
    :try_start_0
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->sendAccessibilityEvent(I)V
    :try_end_3
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_3} :catch_4

    .line 114
    :goto_3
    return-void

    .line 111
    :catch_4
    move-exception v0

    .line 112
    invoke-static {v0}, Landroid/ext/la;->a(Ljava/lang/Throwable;)I

    goto :goto_3
.end method

.method public setChecked(Z)V
    .registers 2

    .prologue
    .line 48
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 49
    invoke-direct {p0}, Landroid/fix/CheckBox;->updateDrawable()V

    .line 50
    return-void
.end method

.method public setCompoundDrawables(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    .registers 6

    .prologue
    .line 73
    :try_start_0
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/CheckBox;->setCompoundDrawables(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    :try_end_3
    .catch Ljava/lang/StringIndexOutOfBoundsException; {:try_start_0 .. :try_end_3} :catch_4

    .line 77
    :goto_3
    return-void

    .line 74
    :catch_4
    move-exception v0

    .line 75
    invoke-static {v0}, Landroid/ext/la;->a(Ljava/lang/Throwable;)I

    goto :goto_3
.end method

.method public setText(Ljava/lang/CharSequence;Landroid/widget/TextView$BufferType;)V
    .registers 4

    .prologue
    .line 36
    :try_start_0
    invoke-super {p0, p1, p2}, Landroid/widget/CheckBox;->setText(Ljava/lang/CharSequence;Landroid/widget/TextView$BufferType;)V
    :try_end_3
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_3} :catch_4

    .line 40
    :goto_3
    return-void

    .line 37
    :catch_4
    move-exception v0

    .line 38
    invoke-static {v0}, Landroid/ext/la;->a(Ljava/lang/Throwable;)I

    goto :goto_3
.end method
