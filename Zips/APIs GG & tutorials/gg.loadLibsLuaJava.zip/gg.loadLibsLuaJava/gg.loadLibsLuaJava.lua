 a = gg.loadLibsLuaJava("return 'test'")
 gg.alert(a)

