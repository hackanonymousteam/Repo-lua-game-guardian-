package com.custom.gg.activities;

import android.app.Activity;
import android.os.Bundle;
import com.custom.gg.R;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//setContentView(R.layout.activity_main);
	}
	
}
