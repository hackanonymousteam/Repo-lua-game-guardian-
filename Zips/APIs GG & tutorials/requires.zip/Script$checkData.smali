.class final Landroid/ext/Script$checkData;
.super Landroid/ext/Script$ApiFunction;
.source "Script.java"


# instance fields
.field final synthetic this$0:Landroid/ext/Script;


# direct methods
.method constructor <init>(Landroid/ext/Script;)V
    .registers 2
    .param p1, "this$0"    # Landroid/ext/Script;

    .line 3811
    iput-object p1, p0, Landroid/ext/Script$checkData;->this$0:Landroid/ext/Script;

    invoke-direct {p0}, Landroid/ext/Script$ApiFunction;-><init>()V

    return-void
.end method


# virtual methods
.method a()Ljava/lang/String;
    .registers 2

    .line 3813
    const-string v0, "gg.checkData(int dayOfMonth) -> boolean|exit"

    return-object v0
.end method

.method public d(Lluaj/ap;)Lluaj/ap;
    .registers 5
    .param p1, "args"    # Lluaj/ap;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/ext/Script$OsExit;
        }
    .end annotation

    .line 3817
    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Lluaj/ap;->y(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    .line 3819
    .local v0, "inputDay":I
    new-instance v1, Ljava/util/Date;

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    invoke-virtual {v1}, Ljava/util/Date;->getDate()I

    move-result v1

    .line 3821
    .local v1, "currentDay":I
    if-ne v1, v0, :cond_17

    .line 3822
    sget-object v2, Lluaj/LuaValue;->v:Lluaj/LuaBoolean;

    return-object v2

    .line 3824
    :cond_17
    new-instance v2, Landroid/ext/Script$OsExit;

    const/4 v3, 0x0

    invoke-direct {v2, v3}, Landroid/ext/Script$OsExit;-><init>(I)V

    throw v2
.end method

.method protected m_()I
    .registers 2

    .line 3812
    const/4 v0, 0x1

    return v0
.end method