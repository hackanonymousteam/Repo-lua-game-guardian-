
add this code in script.smali



    .line 603
    const-string v1, "checkData"

    new-instance v2, Landroid/ext/Script$checkData;

    invoke-direct {v2}, Landroid/ext/Script$checkData;-><init>()V

    invoke-virtual {v3, v1, v2}, Lluaj/LuaTable;->b(Ljava/lang/String;Lluaj/LuaValue;)V

    .line 604
    const-string v1, "checkHour"

    new-instance v2, Landroid/ext/Script$checkHour;

    invoke-direct {v2}, Landroid/ext/Script$checkHour;-><init>()V

    invoke-virtual {v3, v1, v2}, Lluaj/LuaTable;->b(Ljava/lang/String;Lluaj/LuaValue;)V

    .line 605
    const-string v1, "checkMonth"

    new-instance v2, Landroid/ext/Script$checkMonth;

    invoke-direct {v2}, Landroid/ext/Script$checkMonth;-><init>()V

    invoke-virtual {v3, v1, v2}, Lluaj/LuaTable;->b(Ljava/lang/String;Lluaj/LuaValue;)V

    .line 607
    const-string v1, "requireArm"

    new-instance v2, Landroid/ext/Script$requireArm;

    invoke-direct {v2}, Landroid/ext/Script$requireArm;-><init>()V

    invoke-virtual {v3, v1, v2}, Lluaj/LuaTable;->b(Ljava/lang/String;Lluaj/LuaValue;)V

    .line 608
    const-string v1, "requireVirtualSpaceName"

    new-instance v2, Landroid/ext/Script$requireVirtualSpaceName;

    invoke-direct {v2}, Landroid/ext/Script$requireVirtualSpaceName;-><init>()V

    invoke-virtual {v3, v1, v2}, Lluaj/LuaTable;->b(Ljava/lang/String;Lluaj/LuaValue;)V

    .line 609
    const-string v1, "requireVirtualSpace"

    new-instance v2, Landroid/ext/Script$requireVirtualSpace;

    invoke-direct {v2}, Landroid/ext/Script$requireVirtualSpace;-><init>()V

    invoke-virtual {v3, v1, v2}, Lluaj/LuaTable;->b(Ljava/lang/String;Lluaj/LuaValue;)V

