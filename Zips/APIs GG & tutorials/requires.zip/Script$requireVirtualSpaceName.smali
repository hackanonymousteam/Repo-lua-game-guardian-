.class final Landroid/ext/Script$requireVirtualSpaceName;
.super Landroid/ext/Script$ApiFunction;
.source "Script.java"


# instance fields
.field final synthetic this$0:Landroid/ext/Script;


# direct methods
.method constructor <init>(Landroid/ext/Script;)V
    .registers 2

    .prologue
    .line 3811
    iput-object p1, p0, Landroid/ext/Script$requireVirtualSpaceName;->this$0:Landroid/ext/Script;

    invoke-direct {p0}, Landroid/ext/Script$ApiFunction;-><init>()V

    return-void
.end method


# virtual methods
.method a()Ljava/lang/String;
    .registers 2

    .prologue
    .line 3813
    const-string v0, "gg.requireVirtualSpaceName(string name) -> boolean|exit"

    return-object v0
.end method

.method public d(Lluaj/ap;)Lluaj/ap;
    .registers 5

    .prologue
    const/4 v2, 0x1

    .line 2442
    invoke-virtual {p1, v2}, Lluaj/ap;->y(I)Ljava/lang/String;

    move-result-object v1

    .line 2443
    sget-object v0, Landroid/ext/Config;->F:Ljava/lang/String;

    .line 2444
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_10

    .line 2445
    sget-object v0, Lluaj/LuaValue;->v:Lluaj/LuaBoolean;

    return-object v0

    .line 2447
    :cond_10
    new-instance v0, Landroid/ext/Script$OsExit;

    const/16 v1, 0x0

    invoke-direct {v0, v1}, Landroid/ext/Script$OsExit;-><init>(I)V

    throw v0
.end method

.method protected m_()I
    .registers 2

    .prologue
    .line 3812
    const/4 v0, 0x1

    return v0
.end method
