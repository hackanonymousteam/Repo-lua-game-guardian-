
#include <jni.h>

extern "C" {

JNIEXPORT jstring JNICALL
Java_Batman_modmenu_FloatingMenu_F1(JNIEnv *env, jobject clazz) {
    return env->NewStringUTF("Z2cuYWxlcnQoInRlc3QgZG9uZSBmdW5jdGlvbiB3b3JraW5nIik=");
}

//code lua in base 64 okkkk
}

extern "C" {

JNIEXPORT jstring JNICALL
Java_Batman_modmenu_FloatingMenu_F1off(JNIEnv *env, jobject clazz) {
    return env->NewStringUTF("Z2cuYWxlcnQoIiBmdW5jdGlvbiBvZmYgIik=");
}

}

extern "C" {

JNIEXPORT jstring JNICALL
Java_Batman_modmenu_FloatingMenu_F2(JNIEnv *env, jobject clazz) {
    return env->NewStringUTF("Z2cuYWxlcnQoIiBmdW5jdGlvbiBvbiAiKQ==");
}

}

extern "C" {

JNIEXPORT jstring JNICALL
Java_Batman_modmenu_FloatingMenu_F2off(JNIEnv *env, jobject clazz) {
    return env->NewStringUTF("Z2cuYWxlcnQoIiBmdW5jdGlvbiBvZmYgIik=");
}

}


extern "C" {

JNIEXPORT jstring JNICALL
Java_Batman_modmenu_FloatingMenu_F3(JNIEnv *env, jobject clazz) {
    return env->NewStringUTF("Z2cuYWxlcnQoIiBmdW5jdGlvbiBvbiAiKQ==");
}

}

extern "C" {

JNIEXPORT jstring JNICALL
Java_Batman_modmenu_FloatingMenu_F3off(JNIEnv *env, jobject clazz) {
    return env->NewStringUTF("Z2cuYWxlcnQoIiBmdW5jdGlvbiBvZmYgIik=");
}

}

extern "C" {

JNIEXPORT jstring JNICALL
Java_Batman_modmenu_FloatingMenu_F4(JNIEnv *env, jobject clazz) {
    return env->NewStringUTF("Z2cuYWxlcnQoIiBmdW5jdGlvbiBvbiAiKQ==");
}

}

extern "C" {

JNIEXPORT jstring JNICALL
Java_Batman_modmenu_FloatingMenu_F4off(JNIEnv *env, jobject clazz) {
    return env->NewStringUTF("Z2cuYWxlcnQoIiBmdW5jdGlvbiBvZmYgIik=");
}

}
extern "C" {

JNIEXPORT jstring JNICALL
Java_Batman_modmenu_FloatingMenu_F5(JNIEnv *env, jobject clazz) {
    return env->NewStringUTF("Z2cuYWxlcnQoIiBmdW5jdGlvbiBvbiAiKQ==");
}

}

extern "C" {

JNIEXPORT jstring JNICALL
Java_Batman_modmenu_FloatingMenu_F5off(JNIEnv *env, jobject clazz) {
    return env->NewStringUTF("Z2cuYWxlcnQoIiBmdW5jdGlvbiBvZmYgIik=");
}

}


extern "C" {

JNIEXPORT jstring JNICALL
Java_Batman_modmenu_FloatingMenu_F6(JNIEnv *env, jobject clazz) {
    return env->NewStringUTF("Z2cuYWxlcnQoIiBmdW5jdGlvbiBvbiAiKQ==");
}

}

extern "C" {

JNIEXPORT jstring JNICALL
Java_Batman_modmenu_FloatingMenu_F6off(JNIEnv *env, jobject clazz) {
    return env->NewStringUTF("Z2cuYWxlcnQoIiBmdW5jdGlvbiBvZmYgIik=");
}

}


extern "C" {

JNIEXPORT jstring JNICALL
Java_Batman_modmenu_FloatingMenu_F7(JNIEnv *env, jobject clazz) {
    return env->NewStringUTF("Z2cuYWxlcnQoIiBmdW5jdGlvbiBvbiAiKQ==");
}

}

extern "C" {

JNIEXPORT jstring JNICALL
Java_Batman_modmenu_FloatingMenu_F7off(JNIEnv *env, jobject clazz) {
    return env->NewStringUTF("Z2cuYWxlcnQoIiBmdW5jdGlvbiBvZmYgIik=");
}

}
