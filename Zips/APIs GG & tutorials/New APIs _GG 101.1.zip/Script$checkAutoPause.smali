.class final Landroid/ext/Script$checkAutoPause;
.super Landroid/ext/Script$ApiFunction;
.source "Script.java"


# instance fields
.field final synthetic d:Landroid/ext/Script;


# direct methods
.method constructor <init>(Landroid/ext/Script;)V
    .registers 2

    .prologue
    .line 3811
    iput-object p1, p0, Landroid/ext/Script$checkAutoPause;->d:Landroid/ext/Script;

    invoke-direct {p0}, Landroid/ext/Script$ApiFunction;-><init>()V

    return-void
.end method


# virtual methods
.method a()Ljava/lang/String;
    .registers 2

    .prologue
    .line 3813
    const-string v0, "gg.checkAutoPause() -> nil"

    return-object v0
.end method

.method public d(Lluaj/ap;)Lluaj/ap;
    .registers 2

    sget-object p0, Landroid/ext/MainService;->instance:Landroid/ext/MainService;

    if-eqz p0, :cond_7

    invoke-virtual {p0}, Landroid/ext/MainService;->v()V

    :cond_7
    sget-object p0, Lluaj/LuaValue;->u:Lluaj/LuaValue;

    return-object p0
.end method

.method protected m_()I
    .registers 2

    .prologue
    .line 3812
    const/4 v0, 0x0

    return v0
.end method
