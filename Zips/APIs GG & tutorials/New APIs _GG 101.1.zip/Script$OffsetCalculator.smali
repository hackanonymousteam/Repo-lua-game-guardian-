# classes.dex

.class final Landroid/ext/Script$OffsetCalculator;
.super Landroid/ext/Script$ApiFunction;
.source "Script.java"


# instance fields
.field final synthetic d:Landroid/ext/Script;


# direct methods
.method constructor <init>(Landroid/ext/Script;)V
    .registers 2

    .prologue
    .line 3811
    iput-object p1, p0, Landroid/ext/Script$OffsetCalculator;->d:Landroid/ext/Script;

    invoke-direct {p0}, Landroid/ext/Script$ApiFunction;-><init>()V

    return-void
.end method


# virtual methods
.method a()Ljava/lang/String;
    .registers 2

    .prologue
    .line 3813
    const-string v0, "gg.OffsetCalculator() -> nil"

    return-object v0
.end method

.method public d(Lluaj/ap;)Lluaj/ap;
    .registers 4

    .prologue
    .line 3816
    
    
new-instance v0, Landroid/ext/OffsetCalculator;

    invoke-direct {v0}, Landroid/ext/OffsetCalculator;-><init>()V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/ext/OffsetCalculator;->a(Ljava/lang/String;)V
    
    .line 3817
    sget-object v0, Lluaj/LuaValue;->u:Lluaj/LuaValue;

    return-object v0
.end method

.method protected m_()I
    .registers 2

    .prologue
    .line 3812
    const/4 v0, 0x0

    return v0
.end method
