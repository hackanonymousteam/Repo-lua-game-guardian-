# classes.dex

.class final Landroid/ext/Script$clearSelection;
.super Landroid/ext/Script$ApiFunction;
.source "Script.java"


# instance fields
.field final synthetic d:Landroid/ext/Script;


# direct methods
.method constructor <init>(Landroid/ext/Script;)V
    .registers 2

    .prologue
    .line 3811
    iput-object p1, p0, Landroid/ext/Script$clearSelection;->d:Landroid/ext/Script;

    invoke-direct {p0}, Landroid/ext/Script$ApiFunction;-><init>()V

    return-void
.end method


# virtual methods
.method a()Ljava/lang/String;
    .registers 2

    .prologue
    .line 3813
    const-string v0, "gg.clearSelection() -> nil"

    return-object v0
.end method

.method public d(Lluaj/ap;)Lluaj/ap;
    .registers 4

    .prologue
    .line 3816
    
    
    sget-object v1, Landroid/ext/MainService;->instance:Landroid/ext/MainService;

    const/16 p0, 0x0

    invoke-virtual {v1, p0}, Landroid/ext/MainService;->d(I)V

    .line 3817
    sget-object v0, Lluaj/LuaValue;->u:Lluaj/LuaValue;

    return-object v0
.end method

.method protected m_()I
    .registers 2

    .prologue
    .line 3812
    const/4 v0, 0x0

    return v0
.end method
