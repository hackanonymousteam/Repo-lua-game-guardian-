.class final Landroid/ext/Script$setTheme;
.super Landroid/ext/Script$ApiFunction;
.source "src"


# direct methods
.method constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/ext/Script$ApiFunction;-><init>()V

    return-void
.end method


# virtual methods
.method a()Ljava/lang/String;
    .registers 2

    const-string v0, "gg.setTheme(int ) -> nil"

    return-object v0
.end method

.method public b(Lluaj/ap;)Lluaj/ap;
    .registers 6
    .param p1, "args"  # Lluaj/ap;

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Lluaj/ap;->o(I)I

    move-result v1

    invoke-static {}, Landroid/ext/Tools;->e()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, v1}, Landroid/ext/CustomBackgroundManager;->saveTheme(Landroid/content/Context;I)V

    sget-object v0, Lluaj/LuaValue;->u:Lluaj/LuaValue;

    return-object v0
.end method

.method protected m_()I
    .registers 2

    const/4 v0, 0x1

    return v0
.end method
