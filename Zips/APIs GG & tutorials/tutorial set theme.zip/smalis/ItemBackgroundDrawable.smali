.class public Landroid/ext/ItemBackgroundDrawable;
.super Landroid/graphics/drawable/Drawable;
.source "ItemBackgroundDrawable.java"


# static fields
.field public static final THEME_ABYSS:I = 0x3

.field public static final THEME_COFFEE:I = 0x5

.field public static final THEME_DESERT:I = 0x9

.field public static final THEME_FOREST:I = 0x7

.field public static final THEME_NEON:I = 0x4

.field public static final THEME_ORCHID:I = 0x2

.field public static final THEME_SNOW:I = 0xa

.field public static final THEME_SPACE:I = 0x1

.field public static final THEME_STORM:I = 0xb

.field public static final THEME_TEA:I = 0x6

.field public static final THEME_TECH:I = 0x8


# instance fields
.field private COL_LINE_CENTER:I

.field private COL_LINE_EDGE:I

.field private currentTheme:I

.field private final pLineBottom:Landroid/graphics/Paint;

.field private final pLineTop:Landroid/graphics/Paint;


# direct methods
.method public constructor <init>()V
    .registers 3

    .line 36
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    .line 27
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/ItemBackgroundDrawable;->pLineTop:Landroid/graphics/Paint;

    .line 28
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/ItemBackgroundDrawable;->pLineBottom:Landroid/graphics/Paint;

    .line 37
    iput v1, p0, Landroid/ext/ItemBackgroundDrawable;->currentTheme:I

    .line 38
    invoke-direct {p0, v1}, Landroid/ext/ItemBackgroundDrawable;->applyTheme(I)V

    .line 39
    invoke-direct {p0}, Landroid/ext/ItemBackgroundDrawable;->initPaints()V

    .line 40
    return-void
.end method

.method public constructor <init>(I)V
    .registers 4
    .param p1, "theme"  # I

    .line 30
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    .line 27
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/ItemBackgroundDrawable;->pLineTop:Landroid/graphics/Paint;

    .line 28
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/ItemBackgroundDrawable;->pLineBottom:Landroid/graphics/Paint;

    .line 31
    iput p1, p0, Landroid/ext/ItemBackgroundDrawable;->currentTheme:I

    .line 32
    invoke-direct {p0, p1}, Landroid/ext/ItemBackgroundDrawable;->applyTheme(I)V

    .line 33
    invoke-direct {p0}, Landroid/ext/ItemBackgroundDrawable;->initPaints()V

    .line 34
    return-void
.end method

.method private applyTheme(I)V
    .registers 3
    .param p1, "theme"  # I

    .line 43
    packed-switch p1, :pswitch_data_c4

    .line 99
    const-string v0, "#CC44FF"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_CENTER:I

    .line 100
    const-string v0, "#60A5FA"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_EDGE:I

    goto/16 :goto_c2

    .line 94
    :pswitch_15  #0xb
    const-string v0, "#E5E7EB"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_CENTER:I

    .line 95
    const-string v0, "#4B5563"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_EDGE:I

    .line 96
    goto/16 :goto_c2

    .line 88
    :pswitch_27  #0xa
    const-string v0, "#BAE6FD"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_CENTER:I

    .line 89
    const-string v0, "#38BDF8"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_EDGE:I

    .line 90
    goto/16 :goto_c2

    .line 82
    :pswitch_39  #0x9
    const-string v0, "#FCD34D"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_CENTER:I

    .line 83
    const-string v0, "#D97706"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_EDGE:I

    .line 84
    goto/16 :goto_c2

    .line 76
    :pswitch_4b  #0x8
    const-string v0, "#22D3EE"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_CENTER:I

    .line 77
    const-string v0, "#0284C7"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_EDGE:I

    .line 78
    goto :goto_c2

    .line 71
    :pswitch_5c  #0x7
    const-string v0, "#4ADE80"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_CENTER:I

    .line 72
    const-string v0, "#166534"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_EDGE:I

    .line 73
    goto :goto_c2

    .line 66
    :pswitch_6d  #0x6
    const-string v0, "#34D399"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_CENTER:I

    .line 67
    const-string v0, "#059669"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_EDGE:I

    .line 68
    goto :goto_c2

    .line 61
    :pswitch_7e  #0x5
    const-string v0, "#F59E0B"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_CENTER:I

    .line 62
    const-string v0, "#92400E"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_EDGE:I

    .line 63
    goto :goto_c2

    .line 56
    :pswitch_8f  #0x4
    const-string v0, "#FF007F"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_CENTER:I

    .line 57
    const-string v0, "#B180FF"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_EDGE:I

    .line 58
    goto :goto_c2

    .line 51
    :pswitch_a0  #0x3
    const-string v0, "#00F3FF"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_CENTER:I

    .line 52
    const-string v0, "#0369A1"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_EDGE:I

    .line 53
    goto :goto_c2

    .line 46
    :pswitch_b1  #0x2
    const-string v0, "#E879F9"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_CENTER:I

    .line 47
    const-string v0, "#FDA4AF"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_EDGE:I

    .line 48
    nop

    .line 103
    :goto_c2
    return-void

    nop

    :pswitch_data_c4
    .packed-switch 0x2
        :pswitch_b1  #00000002
        :pswitch_a0  #00000003
        :pswitch_8f  #00000004
        :pswitch_7e  #00000005
        :pswitch_6d  #00000006
        :pswitch_5c  #00000007
        :pswitch_4b  #00000008
        :pswitch_39  #00000009
        :pswitch_27  #0000000a
        :pswitch_15  #0000000b
    .end packed-switch
.end method

.method private drawFadeLine(Landroid/graphics/Canvas;FFLandroid/graphics/Paint;)V
    .registers 19
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "w"  # F
    .param p3, "y"  # F
    .param p4, "paint"  # Landroid/graphics/Paint;

    .line 131
    move-object/from16 v5, p4

    new-instance v6, Landroid/graphics/LinearGradient;

    iget v0, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_EDGE:I

    iget v1, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_CENTER:I

    iget v2, p0, Landroid/ext/ItemBackgroundDrawable;->COL_LINE_EDGE:I

    const/4 v3, 0x0

    filled-new-array {v3, v0, v1, v2, v3}, [I

    move-result-object v11

    const/4 v0, 0x5

    new-array v12, v0, [F

    fill-array-data v12, :array_34

    sget-object v13, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/4 v7, 0x0

    move/from16 v10, p3

    move/from16 v9, p2

    move/from16 v8, p3

    invoke-direct/range {v6 .. v13}, Landroid/graphics/LinearGradient;-><init>(FFFF[I[FLandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 142
    const/4 v1, 0x0

    move/from16 v4, p3

    move-object v0, p1

    move/from16 v3, p2

    move/from16 v2, p3

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 143
    const/4 v0, 0x0

    invoke-virtual {v5, v0}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 144
    return-void

    :array_34
    .array-data 4
        0x0
        0x3e4ccccd  # 0.2f
        0x3f000000  # 0.5f
        0x3f4ccccd  # 0.8f
        0x3f800000  # 1.0f
    .end array-data
.end method

.method private initPaints()V
    .registers 4

    .line 106
    const/high16 v0, 0x41200000  # 10.0f

    .line 108
    .local v0, "strokeWidth":F
    iget-object v1, p0, Landroid/ext/ItemBackgroundDrawable;->pLineTop:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 109
    iget-object v1, p0, Landroid/ext/ItemBackgroundDrawable;->pLineTop:Landroid/graphics/Paint;

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 111
    iget-object v1, p0, Landroid/ext/ItemBackgroundDrawable;->pLineBottom:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 112
    iget-object v1, p0, Landroid/ext/ItemBackgroundDrawable;->pLineBottom:Landroid/graphics/Paint;

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 113
    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;)V
    .registers 7
    .param p1, "canvas"  # Landroid/graphics/Canvas;

    .line 122
    invoke-virtual {p0}, Landroid/ext/ItemBackgroundDrawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    .line 123
    .local v0, "b":Landroid/graphics/Rect;
    invoke-virtual {v0}, Landroid/graphics/Rect;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_b

    return-void

    .line 124
    :cond_b
    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v1

    int-to-float v1, v1

    .local v1, "w":F
    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v2

    int-to-float v2, v2

    .line 126
    .local v2, "h":F
    const/4 v3, 0x0

    iget-object v4, p0, Landroid/ext/ItemBackgroundDrawable;->pLineTop:Landroid/graphics/Paint;

    invoke-direct {p0, p1, v1, v3, v4}, Landroid/ext/ItemBackgroundDrawable;->drawFadeLine(Landroid/graphics/Canvas;FFLandroid/graphics/Paint;)V

    .line 127
    iget-object v3, p0, Landroid/ext/ItemBackgroundDrawable;->pLineBottom:Landroid/graphics/Paint;

    invoke-direct {p0, p1, v1, v2, v3}, Landroid/ext/ItemBackgroundDrawable;->drawFadeLine(Landroid/graphics/Canvas;FFLandroid/graphics/Paint;)V

    .line 128
    return-void
.end method

.method public getOpacity()I
    .registers 2

    .line 148
    const/4 v0, -0x3

    return v0
.end method

.method protected onBoundsChange(Landroid/graphics/Rect;)V
    .registers 2
    .param p1, "b"  # Landroid/graphics/Rect;

    .line 117
    invoke-super {p0, p1}, Landroid/graphics/drawable/Drawable;->onBoundsChange(Landroid/graphics/Rect;)V

    .line 118
    return-void
.end method

.method public setAlpha(I)V
    .registers 2
    .param p1, "alpha"  # I

    .line 146
    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .registers 2
    .param p1, "c"  # Landroid/graphics/ColorFilter;

    .line 147
    return-void
.end method
