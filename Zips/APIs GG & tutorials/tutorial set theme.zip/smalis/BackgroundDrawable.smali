.class public Landroid/ext/BackgroundDrawable;
.super Landroid/graphics/drawable/Drawable;
.source "BackgroundDrawable.java"


# static fields
.field private static final CORNER_OUTER:F = 36.0f

.field private static final KEY_THEME:Ljava/lang/String; = "ui_theme"

.field private static final NOTCH_H:F = 42.0f

.field private static final NOTCH_W:F = 62.0f

.field private static final N_PARTICLES:I = 0xa0

.field private static final N_STARS:I = 0xc8

.field private static final PREFS_NAME:Ljava/lang/String; = "dvb_prefs"

.field public static final THEME_ABYSS:I = 0x3

.field public static final THEME_COFFEE:I = 0x5

.field public static final THEME_DESERT:I = 0x9

.field public static final THEME_FOREST:I = 0x7

.field public static final THEME_NEON:I = 0x4

.field public static final THEME_ORCHID:I = 0x2

.field public static final THEME_SNOW:I = 0xa

.field public static final THEME_SPACE:I = 0x1

.field public static final THEME_STORM:I = 0xb

.field public static final THEME_TEA:I = 0x6

.field public static final THEME_TECH:I = 0x8


# instance fields
.field private COL_ACCENT_1:I

.field private COL_ACCENT_2:I

.field private COL_BG_BOTTOM:I

.field private COL_BG_MID:I

.field private COL_BG_TOP:I

.field private COL_CORNER_DOT:I

.field private COL_GLOW_IN:I

.field private COL_GLOW_OUT:I

.field private COL_INNER_RIM:I

.field private COL_LED_BAR:I

.field private COL_MAIN_GRAD_1:I

.field private COL_MAIN_GRAD_2:I

.field private COL_MAIN_GRAD_3:I

.field private final blurCorner:Landroid/graphics/BlurMaskFilter;

.field private final blurGlowIn:Landroid/graphics/BlurMaskFilter;

.field private final blurGlowOut:Landroid/graphics/BlurMaskFilter;

.field private final blurLed:Landroid/graphics/BlurMaskFilter;

.field private final blurSoft:Landroid/graphics/BlurMaskFilter;

.field private final blurStarNear:Landroid/graphics/BlurMaskFilter;

.field private final blurVignette:Landroid/graphics/BlurMaskFilter;

.field private currentTheme:I

.field private final pBg:Landroid/graphics/Paint;

.field private final pCornerDot:Landroid/graphics/Paint;

.field private final pFx:Landroid/graphics/Paint;

.field private final pGlowIn:Landroid/graphics/Paint;

.field private final pGlowOut:Landroid/graphics/Paint;

.field private final pInnerRim:Landroid/graphics/Paint;

.field private final pLedBar:Landroid/graphics/Paint;

.field private final pMainBorder:Landroid/graphics/Paint;

.field private final pPart:Landroid/graphics/Paint;

.field private final pScan:Landroid/graphics/Paint;

.field private final pStar:Landroid/graphics/Paint;

.field private final pVignette:Landroid/graphics/Paint;

.field private final pZone:Landroid/graphics/Paint;

.field private particlesReady:Z

.field private ptA:[I

.field private ptExtra:[F

.field private ptR:[F

.field private ptX:[F

.field private ptY:[F

.field private sA:[I

.field private sLayer:[I

.field private sR:[F

.field private sX:[F

.field private sY:[F

.field private starsReady:Z


# direct methods
.method public constructor <init>()V
    .registers 4

    .line 84
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    .line 41
    new-instance v0, Landroid/graphics/BlurMaskFilter;

    const/high16 v1, 0x40200000  # 2.5f

    sget-object v2, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v0, v1, v2}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->blurStarNear:Landroid/graphics/BlurMaskFilter;

    .line 42
    new-instance v0, Landroid/graphics/BlurMaskFilter;

    const/high16 v1, 0x42a00000  # 80.0f

    sget-object v2, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v0, v1, v2}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->blurVignette:Landroid/graphics/BlurMaskFilter;

    .line 43
    new-instance v0, Landroid/graphics/BlurMaskFilter;

    const/high16 v1, 0x42000000  # 32.0f

    sget-object v2, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v0, v1, v2}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->blurGlowOut:Landroid/graphics/BlurMaskFilter;

    .line 44
    new-instance v0, Landroid/graphics/BlurMaskFilter;

    const/high16 v1, 0x41600000  # 14.0f

    sget-object v2, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v0, v1, v2}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->blurGlowIn:Landroid/graphics/BlurMaskFilter;

    .line 45
    new-instance v0, Landroid/graphics/BlurMaskFilter;

    const/high16 v1, 0x41200000  # 10.0f

    sget-object v2, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v0, v1, v2}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->blurCorner:Landroid/graphics/BlurMaskFilter;

    .line 46
    new-instance v0, Landroid/graphics/BlurMaskFilter;

    const/high16 v1, 0x41000000  # 8.0f

    sget-object v2, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v0, v1, v2}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->blurLed:Landroid/graphics/BlurMaskFilter;

    .line 47
    new-instance v0, Landroid/graphics/BlurMaskFilter;

    const/high16 v1, 0x40c00000  # 6.0f

    sget-object v2, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v0, v1, v2}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->blurSoft:Landroid/graphics/BlurMaskFilter;

    .line 49
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pBg:Landroid/graphics/Paint;

    .line 50
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pZone:Landroid/graphics/Paint;

    .line 51
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    .line 52
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    .line 53
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    .line 54
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pScan:Landroid/graphics/Paint;

    .line 55
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pVignette:Landroid/graphics/Paint;

    .line 56
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pGlowOut:Landroid/graphics/Paint;

    .line 57
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pGlowIn:Landroid/graphics/Paint;

    .line 58
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pMainBorder:Landroid/graphics/Paint;

    .line 59
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pInnerRim:Landroid/graphics/Paint;

    .line 60
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pCornerDot:Landroid/graphics/Paint;

    .line 61
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pLedBar:Landroid/graphics/Paint;

    .line 65
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/ext/BackgroundDrawable;->starsReady:Z

    .line 69
    iput-boolean v0, p0, Landroid/ext/BackgroundDrawable;->particlesReady:Z

    .line 85
    iput v1, p0, Landroid/ext/BackgroundDrawable;->currentTheme:I

    .line 86
    invoke-direct {p0, v1}, Landroid/ext/BackgroundDrawable;->applyTheme(I)V

    .line 87
    invoke-direct {p0}, Landroid/ext/BackgroundDrawable;->initPaints()V

    .line 88
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 5
    .param p1, "context"  # Landroid/content/Context;

    .line 71
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    .line 41
    new-instance v0, Landroid/graphics/BlurMaskFilter;

    const/high16 v1, 0x40200000  # 2.5f

    sget-object v2, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v0, v1, v2}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->blurStarNear:Landroid/graphics/BlurMaskFilter;

    .line 42
    new-instance v0, Landroid/graphics/BlurMaskFilter;

    const/high16 v1, 0x42a00000  # 80.0f

    sget-object v2, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v0, v1, v2}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->blurVignette:Landroid/graphics/BlurMaskFilter;

    .line 43
    new-instance v0, Landroid/graphics/BlurMaskFilter;

    const/high16 v1, 0x42000000  # 32.0f

    sget-object v2, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v0, v1, v2}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->blurGlowOut:Landroid/graphics/BlurMaskFilter;

    .line 44
    new-instance v0, Landroid/graphics/BlurMaskFilter;

    const/high16 v1, 0x41600000  # 14.0f

    sget-object v2, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v0, v1, v2}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->blurGlowIn:Landroid/graphics/BlurMaskFilter;

    .line 45
    new-instance v0, Landroid/graphics/BlurMaskFilter;

    const/high16 v1, 0x41200000  # 10.0f

    sget-object v2, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v0, v1, v2}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->blurCorner:Landroid/graphics/BlurMaskFilter;

    .line 46
    new-instance v0, Landroid/graphics/BlurMaskFilter;

    const/high16 v1, 0x41000000  # 8.0f

    sget-object v2, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v0, v1, v2}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->blurLed:Landroid/graphics/BlurMaskFilter;

    .line 47
    new-instance v0, Landroid/graphics/BlurMaskFilter;

    const/high16 v1, 0x40c00000  # 6.0f

    sget-object v2, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v0, v1, v2}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->blurSoft:Landroid/graphics/BlurMaskFilter;

    .line 49
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pBg:Landroid/graphics/Paint;

    .line 50
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pZone:Landroid/graphics/Paint;

    .line 51
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    .line 52
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    .line 53
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    .line 54
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pScan:Landroid/graphics/Paint;

    .line 55
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pVignette:Landroid/graphics/Paint;

    .line 56
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pGlowOut:Landroid/graphics/Paint;

    .line 57
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pGlowIn:Landroid/graphics/Paint;

    .line 58
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pMainBorder:Landroid/graphics/Paint;

    .line 59
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pInnerRim:Landroid/graphics/Paint;

    .line 60
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pCornerDot:Landroid/graphics/Paint;

    .line 61
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pLedBar:Landroid/graphics/Paint;

    .line 65
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/ext/BackgroundDrawable;->starsReady:Z

    .line 69
    iput-boolean v0, p0, Landroid/ext/BackgroundDrawable;->particlesReady:Z

    .line 72
    const-string v2, "dvb_prefs"

    invoke-virtual {p1, v2, v0}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 73
    .local v0, "prefs":Landroid/content/SharedPreferences;
    const-string v2, "ui_theme"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->currentTheme:I

    .line 74
    iget v1, p0, Landroid/ext/BackgroundDrawable;->currentTheme:I

    invoke-direct {p0, v1}, Landroid/ext/BackgroundDrawable;->applyTheme(I)V

    .line 75
    invoke-direct {p0}, Landroid/ext/BackgroundDrawable;->initPaints()V

    .line 76
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;I)V
    .registers 6
    .param p1, "context"  # Landroid/content/Context;
    .param p2, "theme"  # I

    .line 78
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    .line 41
    new-instance v0, Landroid/graphics/BlurMaskFilter;

    const/high16 v1, 0x40200000  # 2.5f

    sget-object v2, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v0, v1, v2}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->blurStarNear:Landroid/graphics/BlurMaskFilter;

    .line 42
    new-instance v0, Landroid/graphics/BlurMaskFilter;

    const/high16 v1, 0x42a00000  # 80.0f

    sget-object v2, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v0, v1, v2}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->blurVignette:Landroid/graphics/BlurMaskFilter;

    .line 43
    new-instance v0, Landroid/graphics/BlurMaskFilter;

    const/high16 v1, 0x42000000  # 32.0f

    sget-object v2, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v0, v1, v2}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->blurGlowOut:Landroid/graphics/BlurMaskFilter;

    .line 44
    new-instance v0, Landroid/graphics/BlurMaskFilter;

    const/high16 v1, 0x41600000  # 14.0f

    sget-object v2, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v0, v1, v2}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->blurGlowIn:Landroid/graphics/BlurMaskFilter;

    .line 45
    new-instance v0, Landroid/graphics/BlurMaskFilter;

    const/high16 v1, 0x41200000  # 10.0f

    sget-object v2, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v0, v1, v2}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->blurCorner:Landroid/graphics/BlurMaskFilter;

    .line 46
    new-instance v0, Landroid/graphics/BlurMaskFilter;

    const/high16 v1, 0x41000000  # 8.0f

    sget-object v2, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v0, v1, v2}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->blurLed:Landroid/graphics/BlurMaskFilter;

    .line 47
    new-instance v0, Landroid/graphics/BlurMaskFilter;

    const/high16 v1, 0x40c00000  # 6.0f

    sget-object v2, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v0, v1, v2}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->blurSoft:Landroid/graphics/BlurMaskFilter;

    .line 49
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pBg:Landroid/graphics/Paint;

    .line 50
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pZone:Landroid/graphics/Paint;

    .line 51
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    .line 52
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    .line 53
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    .line 54
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pScan:Landroid/graphics/Paint;

    .line 55
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pVignette:Landroid/graphics/Paint;

    .line 56
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pGlowOut:Landroid/graphics/Paint;

    .line 57
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pGlowIn:Landroid/graphics/Paint;

    .line 58
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pMainBorder:Landroid/graphics/Paint;

    .line 59
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pInnerRim:Landroid/graphics/Paint;

    .line 60
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pCornerDot:Landroid/graphics/Paint;

    .line 61
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Landroid/ext/BackgroundDrawable;->pLedBar:Landroid/graphics/Paint;

    .line 65
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/ext/BackgroundDrawable;->starsReady:Z

    .line 69
    iput-boolean v0, p0, Landroid/ext/BackgroundDrawable;->particlesReady:Z

    .line 79
    iput p2, p0, Landroid/ext/BackgroundDrawable;->currentTheme:I

    .line 80
    invoke-direct {p0, p2}, Landroid/ext/BackgroundDrawable;->applyTheme(I)V

    .line 81
    invoke-direct {p0}, Landroid/ext/BackgroundDrawable;->initPaints()V

    .line 82
    return-void
.end method

.method private applyTheme(I)V
    .registers 12
    .param p1, "theme"  # I

    .line 94
    const-string v0, "#FEF3C7"

    const-string v1, "#F59E0B"

    const-string v2, "#F0ABFC"

    const-string v3, "#D97706"

    const-string v4, "#E0F2FE"

    const-string v5, "#BAE6FD"

    const-string v6, "#FDE68A"

    const-string v7, "#7DD3FC"

    const-string v8, "#38BDF8"

    const-string v9, "#FDE047"

    packed-switch p1, :pswitch_data_446

    .line 258
    const-string v0, "#1A0035"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_TOP:I

    .line 259
    const-string v0, "#2D0060"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_MID:I

    .line 260
    const-string v0, "#080010"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_BOTTOM:I

    .line 261
    const-string v0, "#001B4A"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_1:I

    .line 262
    const-string v0, "#3A0066"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_2:I

    .line 263
    const-string v0, "#6D28D9"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_OUT:I

    .line 264
    const-string v0, "#2563EB"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_IN:I

    .line 265
    const-string v0, "#C084FC"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_1:I

    .line 266
    const-string v0, "#60A5FA"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_2:I

    .line 267
    const-string v0, "#A855F7"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_3:I

    .line 268
    const-string v0, "#E9D5FF"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_INNER_RIM:I

    .line 269
    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_CORNER_DOT:I

    .line 270
    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_LED_BAR:I

    goto/16 :goto_445

    .line 242
    :pswitch_7d  #0xb
    const-string v0, "#1A1A1A"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_TOP:I

    .line 243
    const-string v0, "#2D2D2D"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_MID:I

    .line 244
    const-string v0, "#0A0A0A"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_BOTTOM:I

    .line 245
    const-string v0, "#374151"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_1:I

    .line 246
    const-string v0, "#4B5563"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_2:I

    .line 247
    const-string v0, "#6B7280"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_OUT:I

    .line 248
    const-string v1, "#9CA3AF"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_IN:I

    .line 249
    const-string v2, "#D1D5DB"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    iput v3, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_1:I

    .line 250
    const-string v3, "#E5E7EB"

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    iput v3, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_2:I

    .line 251
    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_3:I

    .line 252
    const-string v1, "#F3F4F6"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_INNER_RIM:I

    .line 253
    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_CORNER_DOT:I

    .line 254
    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_LED_BAR:I

    .line 255
    goto/16 :goto_445

    .line 226
    :pswitch_e1  #0xa
    const-string v0, "#0F172A"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_TOP:I

    .line 227
    const-string v0, "#1E293B"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_MID:I

    .line 228
    const-string v0, "#020617"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_BOTTOM:I

    .line 229
    const-string v0, "#1E3A5F"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_1:I

    .line 230
    const-string v0, "#334155"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_2:I

    .line 231
    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_OUT:I

    .line 232
    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_IN:I

    .line 233
    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_1:I

    .line 234
    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_2:I

    .line 235
    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_3:I

    .line 236
    const-string v0, "#F0F9FF"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_INNER_RIM:I

    .line 237
    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_CORNER_DOT:I

    .line 238
    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_LED_BAR:I

    .line 239
    goto/16 :goto_445

    .line 210
    :pswitch_13d  #0x9
    const-string v2, "#2D1B00"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Landroid/ext/BackgroundDrawable;->COL_BG_TOP:I

    .line 211
    const-string v2, "#4A2C1A"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Landroid/ext/BackgroundDrawable;->COL_BG_MID:I

    .line 212
    const-string v2, "#1A0F00"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Landroid/ext/BackgroundDrawable;->COL_BG_BOTTOM:I

    .line 213
    const-string v2, "#6B3D00"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_1:I

    .line 214
    const-string v2, "#8B5A2B"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_2:I

    .line 215
    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_OUT:I

    .line 216
    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_IN:I

    .line 217
    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_1:I

    .line 218
    const-string v1, "#FBBF24"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_2:I

    .line 219
    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_3:I

    .line 220
    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_INNER_RIM:I

    .line 221
    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_CORNER_DOT:I

    .line 222
    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_LED_BAR:I

    .line 223
    goto/16 :goto_445

    .line 194
    :pswitch_199  #0x8
    const-string v0, "#000814"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_TOP:I

    .line 195
    const-string v0, "#001529"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_MID:I

    .line 196
    const-string v0, "#00060F"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_BOTTOM:I

    .line 197
    const-string v0, "#00204A"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_1:I

    .line 198
    const-string v0, "#003D6B"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_2:I

    .line 199
    const-string v0, "#0284C7"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_OUT:I

    .line 200
    const-string v0, "#22D3EE"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_IN:I

    .line 201
    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_1:I

    .line 202
    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_2:I

    .line 203
    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_3:I

    .line 204
    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_INNER_RIM:I

    .line 205
    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_CORNER_DOT:I

    .line 206
    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_LED_BAR:I

    .line 207
    goto/16 :goto_445

    .line 178
    :pswitch_1f7  #0x7
    const-string v0, "#071500"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_TOP:I

    .line 179
    const-string v0, "#112400"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_MID:I

    .line 180
    const-string v0, "#030800"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_BOTTOM:I

    .line 181
    const-string v0, "#1A3800"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_1:I

    .line 182
    const-string v0, "#2A5500"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_2:I

    .line 183
    const-string v0, "#166534"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_OUT:I

    .line 184
    const-string v0, "#4ADE80"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_IN:I

    .line 185
    const-string v1, "#86EFAC"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_1:I

    .line 186
    const-string v2, "#D9F99D"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_2:I

    .line 187
    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_3:I

    .line 188
    const-string v0, "#F0FDF4"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_INNER_RIM:I

    .line 189
    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_CORNER_DOT:I

    .line 190
    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_LED_BAR:I

    .line 191
    goto/16 :goto_445

    .line 162
    :pswitch_25b  #0x6
    const-string v0, "#1C0500"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_TOP:I

    .line 163
    const-string v0, "#2E0A00"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_MID:I

    .line 164
    const-string v0, "#0F0200"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_BOTTOM:I

    .line 165
    const-string v0, "#4A1500"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_1:I

    .line 166
    const-string v0, "#6B2100"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_2:I

    .line 167
    const-string v0, "#9A3412"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_OUT:I

    .line 168
    const-string v0, "#EA580C"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_IN:I

    .line 169
    const-string v0, "#FDBA74"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_1:I

    .line 170
    const-string v1, "#FB923C"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_2:I

    .line 171
    const-string v1, "#C2410C"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_3:I

    .line 172
    const-string v1, "#FFF7ED"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_INNER_RIM:I

    .line 173
    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_CORNER_DOT:I

    .line 174
    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_LED_BAR:I

    .line 175
    goto/16 :goto_445

    .line 145
    :pswitch_2c1  #0x5
    const-string v2, "#1A0A00"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Landroid/ext/BackgroundDrawable;->COL_BG_TOP:I

    .line 146
    const-string v2, "#2E1200"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Landroid/ext/BackgroundDrawable;->COL_BG_MID:I

    .line 147
    const-string v2, "#090300"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Landroid/ext/BackgroundDrawable;->COL_BG_BOTTOM:I

    .line 148
    const-string v2, "#3D1900"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_1:I

    .line 149
    const-string v2, "#5C2A00"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_2:I

    .line 150
    const-string v2, "#92400E"

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_OUT:I

    .line 151
    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_IN:I

    .line 152
    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_1:I

    .line 153
    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_2:I

    .line 154
    const-string v1, "#B45309"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_3:I

    .line 155
    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_INNER_RIM:I

    .line 156
    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_CORNER_DOT:I

    .line 157
    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_LED_BAR:I

    .line 158
    goto/16 :goto_445

    .line 129
    :pswitch_31f  #0x4
    const-string v0, "#0A0516"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_TOP:I

    .line 130
    const-string v0, "#0F0A24"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_MID:I

    .line 131
    const-string v0, "#05020A"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_BOTTOM:I

    .line 132
    const-string v0, "#1E0B36"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_1:I

    .line 133
    const-string v0, "#051E24"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_2:I

    .line 134
    const-string v0, "#FF007F"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_OUT:I

    .line 135
    const-string v0, "#00F3FF"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_IN:I

    .line 136
    const-string v1, "#FF80BF"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_1:I

    .line 137
    const-string v1, "#80F3FF"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_2:I

    .line 138
    const-string v1, "#B180FF"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_3:I

    .line 139
    const-string v1, "#20FFFFFF"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_INNER_RIM:I

    .line 140
    const-string v1, "#39FF14"

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_CORNER_DOT:I

    .line 141
    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_LED_BAR:I

    .line 142
    goto/16 :goto_445

    .line 113
    :pswitch_387  #0x3
    const-string v0, "#000D1A"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_TOP:I

    .line 114
    const-string v0, "#002244"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_MID:I

    .line 115
    const-string v0, "#001833"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_BOTTOM:I

    .line 116
    const-string v0, "#003875"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_1:I

    .line 117
    const-string v0, "#0057A8"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_2:I

    .line 118
    const-string v0, "#0369A1"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_OUT:I

    .line 119
    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_IN:I

    .line 120
    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_1:I

    .line 121
    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_2:I

    .line 122
    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_3:I

    .line 123
    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_INNER_RIM:I

    .line 124
    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_CORNER_DOT:I

    .line 125
    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_LED_BAR:I

    .line 126
    goto :goto_445

    .line 97
    :pswitch_3e2  #0x2
    const-string v0, "#150010"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_TOP:I

    .line 98
    const-string v0, "#280020"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_MID:I

    .line 99
    const-string v0, "#080005"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_BG_BOTTOM:I

    .line 100
    const-string v0, "#3D0030"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_1:I

    .line 101
    const-string v0, "#550040"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_2:I

    .line 102
    const-string v0, "#9333EA"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_OUT:I

    .line 103
    const-string v0, "#F43F5E"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_IN:I

    .line 104
    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_1:I

    .line 105
    const-string v0, "#FDA4AF"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_2:I

    .line 106
    const-string v0, "#E879F9"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_3:I

    .line 107
    const-string v0, "#FDF4FF"

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_INNER_RIM:I

    .line 108
    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    iput v1, p0, Landroid/ext/BackgroundDrawable;->COL_CORNER_DOT:I

    .line 109
    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Landroid/ext/BackgroundDrawable;->COL_LED_BAR:I

    .line 110
    nop

    .line 273
    :goto_445
    return-void

    :pswitch_data_446
    .packed-switch 0x2
        :pswitch_3e2  #00000002
        :pswitch_387  #00000003
        :pswitch_31f  #00000004
        :pswitch_2c1  #00000005
        :pswitch_25b  #00000006
        :pswitch_1f7  #00000007
        :pswitch_199  #00000008
        :pswitch_13d  #00000009
        :pswitch_e1  #0000000a
        :pswitch_7d  #0000000b
    .end packed-switch
.end method

.method private buildFramePath(FFF)Landroid/graphics/Path;
    .registers 19
    .param p1, "w"  # F
    .param p2, "h"  # F
    .param p3, "inset"  # F

    .line 1196
    const/high16 v0, 0x42100000  # 36.0f

    sub-float v0, v0, p3

    .line 1197
    .local v0, "r":F
    const v1, 0x3f19999a  # 0.6f

    mul-float v1, v1, p3

    const/high16 v2, 0x42780000  # 62.0f

    sub-float/2addr v2, v1

    .line 1198
    .local v2, "nW":F
    const/high16 v1, 0x3f000000  # 0.5f

    mul-float v1, v1, p3

    const/high16 v3, 0x42280000  # 42.0f

    sub-float/2addr v3, v1

    .line 1199
    .local v3, "nH":F
    move/from16 v5, p3

    .local v5, "l":F
    move/from16 v1, p3

    .line 1200
    .local v1, "t":F
    sub-float v9, p1, p3

    .local v9, "ri":F
    sub-float v8, p2, p3

    .line 1202
    .local v8, "bo":F
    new-instance v4, Landroid/graphics/Path;

    invoke-direct {v4}, Landroid/graphics/Path;-><init>()V

    .line 1203
    .local v4, "p":Landroid/graphics/Path;
    add-float v6, v5, v0

    invoke-virtual {v4, v6, v1}, Landroid/graphics/Path;->moveTo(FF)V

    .line 1204
    sub-float v6, v9, v2

    invoke-virtual {v4, v6, v1}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1205
    add-float v6, v1, v3

    invoke-virtual {v4, v9, v6}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1206
    sub-float v6, v8, v0

    invoke-virtual {v4, v9, v6}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1207
    const/high16 v14, 0x40000000  # 2.0f

    mul-float v6, v0, v14

    sub-float v7, v9, v6

    mul-float v6, v0, v14

    sub-float v6, v8, v6

    const/high16 v12, 0x42b40000  # 90.0f

    const/4 v13, 0x0

    const/4 v11, 0x0

    move v10, v8

    move v8, v6

    move-object v6, v4

    .end local v4  # "p":Landroid/graphics/Path;
    .end local v8  # "bo":F
    .local v6, "p":Landroid/graphics/Path;
    .local v10, "bo":F
    invoke-virtual/range {v6 .. v13}, Landroid/graphics/Path;->arcTo(FFFFFFZ)V

    .line 1208
    move v12, v9

    move v8, v10

    .end local v6  # "p":Landroid/graphics/Path;
    .end local v9  # "ri":F
    .end local v10  # "bo":F
    .restart local v4  # "p":Landroid/graphics/Path;
    .restart local v8  # "bo":F
    .local v12, "ri":F
    add-float v6, v5, v0

    invoke-virtual {v4, v6, v8}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1209
    mul-float v6, v0, v14

    sub-float v6, v8, v6

    mul-float v7, v0, v14

    add-float/2addr v7, v5

    const/high16 v10, 0x42b40000  # 90.0f

    const/4 v11, 0x0

    const/high16 v9, 0x42b40000  # 90.0f

    invoke-virtual/range {v4 .. v11}, Landroid/graphics/Path;->arcTo(FFFFFFZ)V

    .line 1210
    move v13, v8

    .end local v8  # "bo":F
    .local v13, "bo":F
    add-float v6, v1, v0

    invoke-virtual {v4, v5, v6}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1211
    mul-float v6, v0, v14

    add-float v7, v5, v6

    mul-float v14, v14, v0

    add-float v8, v1, v14

    const/high16 v9, 0x43340000  # 180.0f

    move v6, v1

    .end local v1  # "t":F
    .local v6, "t":F
    invoke-virtual/range {v4 .. v11}, Landroid/graphics/Path;->arcTo(FFFFFFZ)V

    .line 1212
    invoke-virtual {v4}, Landroid/graphics/Path;->close()V

    .line 1213
    return-object v4
.end method

.method private buildParticles(FF)V
    .registers 11
    .param p1, "w"  # F
    .param p2, "h"  # F

    .line 1275
    const/16 v0, 0xa0

    new-array v1, v0, [F

    iput-object v1, p0, Landroid/ext/BackgroundDrawable;->ptX:[F

    new-array v1, v0, [F

    iput-object v1, p0, Landroid/ext/BackgroundDrawable;->ptY:[F

    .line 1276
    new-array v1, v0, [F

    iput-object v1, p0, Landroid/ext/BackgroundDrawable;->ptR:[F

    new-array v1, v0, [I

    iput-object v1, p0, Landroid/ext/BackgroundDrawable;->ptA:[I

    .line 1277
    new-array v1, v0, [F

    iput-object v1, p0, Landroid/ext/BackgroundDrawable;->ptExtra:[F

    .line 1278
    const-wide/32 v1, 0x1a2b3c4d

    .line 1279
    .local v1, "seed":J
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_1a
    if-ge v3, v0, :cond_9e

    .line 1280
    invoke-direct {p0, v1, v2}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v1

    iget-object v4, p0, Landroid/ext/BackgroundDrawable;->ptX:[F

    invoke-direct {p0, v1, v2}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v5

    mul-float v5, v5, p1

    aput v5, v4, v3

    .line 1281
    invoke-direct {p0, v1, v2}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v1

    iget-object v4, p0, Landroid/ext/BackgroundDrawable;->ptY:[F

    invoke-direct {p0, v1, v2}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v5

    mul-float v5, v5, p2

    aput v5, v4, v3

    .line 1282
    invoke-direct {p0, v1, v2}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v1

    invoke-direct {p0, v1, v2}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v4

    .line 1283
    .local v4, "r":F
    invoke-direct {p0, v1, v2}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v1

    iget-object v5, p0, Landroid/ext/BackgroundDrawable;->ptExtra:[F

    invoke-direct {p0, v1, v2}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v6

    aput v6, v5, v3

    .line 1284
    const/16 v5, 0x41

    if-ge v3, v5, :cond_69

    .line 1285
    iget-object v5, p0, Landroid/ext/BackgroundDrawable;->ptR:[F

    const v6, 0x3f333333  # 0.7f

    mul-float v6, v6, v4

    const v7, 0x3e4ccccd  # 0.2f

    add-float/2addr v6, v7

    aput v6, v5, v3

    iget-object v5, p0, Landroid/ext/BackgroundDrawable;->ptA:[I

    const/high16 v6, 0x428c0000  # 70.0f

    mul-float v6, v6, v4

    float-to-int v6, v6

    add-int/lit8 v6, v6, 0x32

    aput v6, v5, v3

    goto :goto_9a

    .line 1286
    :cond_69
    const/16 v5, 0x73

    const v6, 0x3f8ccccd  # 1.1f

    if-ge v3, v5, :cond_86

    .line 1287
    iget-object v5, p0, Landroid/ext/BackgroundDrawable;->ptR:[F

    mul-float v6, v6, v4

    const v7, 0x3f19999a  # 0.6f

    add-float/2addr v6, v7

    aput v6, v5, v3

    iget-object v5, p0, Landroid/ext/BackgroundDrawable;->ptA:[I

    const/high16 v6, 0x42b40000  # 90.0f

    mul-float v6, v6, v4

    float-to-int v6, v6

    add-int/lit8 v6, v6, 0x64

    aput v6, v5, v3

    goto :goto_9a

    .line 1289
    :cond_86
    iget-object v5, p0, Landroid/ext/BackgroundDrawable;->ptR:[F

    const/high16 v7, 0x3fc00000  # 1.5f

    mul-float v7, v7, v4

    add-float/2addr v7, v6

    aput v7, v5, v3

    iget-object v5, p0, Landroid/ext/BackgroundDrawable;->ptA:[I

    const/high16 v6, 0x42700000  # 60.0f

    mul-float v6, v6, v4

    float-to-int v6, v6

    add-int/lit16 v6, v6, 0xaa

    aput v6, v5, v3

    .line 1279
    .end local v4  # "r":F
    :goto_9a
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_1a

    .line 1292
    .end local v3  # "i":I
    :cond_9e
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/ext/BackgroundDrawable;->particlesReady:Z

    .line 1293
    return-void
.end method

.method private buildStars(FF)V
    .registers 12
    .param p1, "w"  # F
    .param p2, "h"  # F

    .line 1256
    const/16 v0, 0xc8

    new-array v1, v0, [F

    iput-object v1, p0, Landroid/ext/BackgroundDrawable;->sX:[F

    new-array v1, v0, [F

    iput-object v1, p0, Landroid/ext/BackgroundDrawable;->sY:[F

    .line 1257
    new-array v1, v0, [F

    iput-object v1, p0, Landroid/ext/BackgroundDrawable;->sR:[F

    new-array v1, v0, [I

    iput-object v1, p0, Landroid/ext/BackgroundDrawable;->sA:[I

    new-array v1, v0, [I

    iput-object v1, p0, Landroid/ext/BackgroundDrawable;->sLayer:[I

    .line 1258
    const-wide/32 v1, 0x1a2b3c4d

    .line 1259
    .local v1, "seed":J
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_1a
    const/4 v4, 0x1

    if-ge v3, v0, :cond_a0

    .line 1260
    invoke-direct {p0, v1, v2}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v1

    iget-object v5, p0, Landroid/ext/BackgroundDrawable;->sX:[F

    invoke-direct {p0, v1, v2}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v6

    mul-float v6, v6, p1

    aput v6, v5, v3

    .line 1261
    invoke-direct {p0, v1, v2}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v1

    iget-object v5, p0, Landroid/ext/BackgroundDrawable;->sY:[F

    invoke-direct {p0, v1, v2}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v6

    mul-float v6, v6, p2

    aput v6, v5, v3

    .line 1262
    invoke-direct {p0, v1, v2}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v1

    invoke-direct {p0, v1, v2}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v5

    .line 1263
    .local v5, "r":F
    const/16 v6, 0x64

    if-ge v3, v6, :cond_63

    .line 1264
    iget-object v4, p0, Landroid/ext/BackgroundDrawable;->sLayer:[I

    const/4 v6, 0x0

    aput v6, v4, v3

    iget-object v4, p0, Landroid/ext/BackgroundDrawable;->sR:[F

    const v6, 0x3f333333  # 0.7f

    mul-float v6, v6, v5

    const v7, 0x3e4ccccd  # 0.2f

    add-float/2addr v6, v7

    aput v6, v4, v3

    iget-object v4, p0, Landroid/ext/BackgroundDrawable;->sA:[I

    const/high16 v6, 0x428c0000  # 70.0f

    mul-float v6, v6, v5

    float-to-int v6, v6

    add-int/lit8 v6, v6, 0x32

    aput v6, v4, v3

    goto :goto_9c

    .line 1265
    :cond_63
    const/16 v7, 0xa5

    const v8, 0x3f8ccccd  # 1.1f

    if-ge v3, v7, :cond_83

    .line 1266
    iget-object v7, p0, Landroid/ext/BackgroundDrawable;->sLayer:[I

    aput v4, v7, v3

    iget-object v4, p0, Landroid/ext/BackgroundDrawable;->sR:[F

    mul-float v8, v8, v5

    const v7, 0x3f19999a  # 0.6f

    add-float/2addr v8, v7

    aput v8, v4, v3

    iget-object v4, p0, Landroid/ext/BackgroundDrawable;->sA:[I

    const/high16 v7, 0x42b40000  # 90.0f

    mul-float v7, v7, v5

    float-to-int v7, v7

    add-int/2addr v7, v6

    aput v7, v4, v3

    goto :goto_9c

    .line 1268
    :cond_83
    iget-object v4, p0, Landroid/ext/BackgroundDrawable;->sLayer:[I

    const/4 v6, 0x2

    aput v6, v4, v3

    iget-object v4, p0, Landroid/ext/BackgroundDrawable;->sR:[F

    const/high16 v6, 0x3fc00000  # 1.5f

    mul-float v6, v6, v5

    add-float/2addr v6, v8

    aput v6, v4, v3

    iget-object v4, p0, Landroid/ext/BackgroundDrawable;->sA:[I

    const/high16 v6, 0x42700000  # 60.0f

    mul-float v6, v6, v5

    float-to-int v6, v6

    add-int/lit16 v6, v6, 0xaa

    aput v6, v4, v3

    .line 1259
    .end local v5  # "r":F
    :goto_9c
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_1a

    .line 1271
    .end local v3  # "i":I
    :cond_a0
    iput-boolean v4, p0, Landroid/ext/BackgroundDrawable;->starsReady:Z

    .line 1272
    return-void
.end method

.method private drawAbyssBg(Landroid/graphics/Canvas;FF)V
    .registers 30
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "w"  # F
    .param p3, "h"  # F

    .line 443
    move-object/from16 v0, p0

    move/from16 v7, p3

    iget-object v1, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 444
    iget-object v1, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v8, Landroid/graphics/RadialGradient;

    const/high16 v2, 0x3f000000  # 0.5f

    mul-float v9, p2, v2

    neg-float v2, v7

    const v15, 0x3da3d70a  # 0.08f

    mul-float v10, v2, v15

    const v2, 0x3f051eb8  # 0.52f

    mul-float v11, v7, v2

    .line 446
    const/16 v2, 0x48

    const/16 v3, 0x38

    const/16 v4, 0x82

    const/16 v5, 0xf8

    invoke-static {v2, v3, v4, v5}, Landroid/graphics/Color;->argb(IIII)I

    move-result v2

    const/16 v4, 0x14

    const/16 v6, 0x46

    const/4 v12, 0x0

    invoke-static {v12, v12, v4, v6}, Landroid/graphics/Color;->argb(IIII)I

    move-result v4

    filled-new-array {v2, v4}, [I

    move-result-object v2

    const/4 v4, 0x2

    new-array v13, v4, [F

    fill-array-data v13, :array_31a

    sget-object v14, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    move-object v12, v2

    const/4 v2, 0x0

    invoke-direct/range {v8 .. v14}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 444
    invoke-virtual {v1, v8}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 448
    const v1, 0x3f266666  # 0.65f

    mul-float v1, v1, v7

    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/4 v8, 0x0

    const/4 v2, 0x0

    const/16 v9, 0x38

    const/4 v3, 0x0

    move/from16 v4, p2

    move v5, v1

    const/16 v8, 0xf8

    const/4 v10, 0x0

    const/4 v11, 0x2

    move-object/from16 v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 450
    move v12, v4

    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v16, Landroid/graphics/RadialGradient;

    const v13, 0x3e4ccccd  # 0.2f

    mul-float v17, v12, v13

    const v3, 0x3ed70a3d  # 0.42f

    mul-float v18, v7, v3

    const v4, 0x3ecccccd  # 0.4f

    mul-float v19, v12, v4

    .line 452
    const/16 v5, 0x37

    const/16 v6, 0x64

    const/16 v14, 0xdc

    invoke-static {v5, v10, v6, v14}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    const/16 v14, 0x50

    const v23, 0x3ed70a3d  # 0.42f

    const/16 v3, 0x1e

    invoke-static {v10, v10, v3, v14}, Landroid/graphics/Color;->argb(IIII)I

    move-result v14

    filled-new-array {v5, v14}, [I

    move-result-object v20

    new-array v5, v11, [F

    fill-array-data v5, :array_322

    sget-object v22, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    move-object/from16 v21, v5

    invoke-direct/range {v16 .. v22}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 450
    move-object/from16 v5, v16

    invoke-virtual {v2, v5}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 454
    mul-float v2, v12, v13

    mul-float v5, v7, v23

    mul-float v4, v4, v12

    iget-object v14, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v5, v4, v14}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 456
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v16, Landroid/graphics/RadialGradient;

    const v14, 0x3f4ccccd  # 0.8f

    mul-float v17, v12, v14

    const v23, 0x3f1eb852  # 0.62f

    mul-float v18, v7, v23

    const v4, 0x3eae147b  # 0.34f

    mul-float v19, v12, v4

    .line 458
    const/16 v5, 0x2d

    const v24, 0x3f4ccccd  # 0.8f

    const/16 v14, 0xa0

    const v25, 0x3eae147b  # 0.34f

    const/16 v4, 0xf0

    invoke-static {v5, v3, v14, v4}, Landroid/graphics/Color;->argb(IIII)I

    move-result v3

    const/16 v4, 0x32

    invoke-static {v10, v10, v4, v6}, Landroid/graphics/Color;->argb(IIII)I

    move-result v4

    filled-new-array {v3, v4}, [I

    move-result-object v20

    new-array v3, v11, [F

    fill-array-data v3, :array_32a

    sget-object v22, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    move-object/from16 v21, v3

    invoke-direct/range {v16 .. v22}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 456
    move-object/from16 v3, v16

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 460
    mul-float v2, v12, v24

    mul-float v3, v7, v23

    mul-float v4, v12, v25

    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v3, v4, v5}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 461
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/4 v10, 0x0

    invoke-virtual {v2, v10}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 463
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 464
    const-wide v2, 0xabcd1234L

    .line 465
    .local v2, "seed":J
    const/4 v4, 0x0

    move v11, v4

    .local v11, "i":I
    :goto_105
    const/16 v4, 0x10

    if-ge v11, v4, :cond_1a6

    .line 466
    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v2

    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v4

    mul-float v4, v4, v12

    .line 467
    .local v4, "cx":F
    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v2

    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v5

    mul-float v5, v5, v7

    const v6, 0x3ec28f5c  # 0.38f

    mul-float v5, v5, v6

    .line 468
    .local v5, "cy":F
    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v2

    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v6

    mul-float v6, v6, v12

    const v16, 0x3dcccccd  # 0.1f

    mul-float v6, v6, v16

    const v16, 0x3d23d70a  # 0.04f

    mul-float v16, v16, v12

    add-float v16, v6, v16

    .line 469
    .local v16, "len":F
    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v2

    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v6

    const/high16 v17, 0x41e00000  # 28.0f

    mul-float v6, v6, v17

    const/high16 v17, 0x41600000  # 14.0f

    sub-float v6, v6, v17

    .line 470
    .local v6, "ang":F
    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v2

    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v17

    const/high16 v18, 0x41d00000  # 26.0f

    const v19, 0x3da3d70a  # 0.08f

    mul-float v15, v17, v18

    float-to-int v15, v15

    add-int/lit8 v15, v15, 0x12

    .line 471
    .local v15, "alp":I
    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v2

    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v17

    const v18, 0x3fb33333  # 1.4f

    mul-float v17, v17, v18

    add-float v10, v17, v24

    .line 472
    .local v10, "sw":F
    iget-object v14, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/16 v8, 0xd2

    const/16 v9, 0xfc

    const/16 v13, 0x7d

    invoke-static {v15, v13, v8, v9}, Landroid/graphics/Color;->argb(IIII)I

    move-result v8

    invoke-virtual {v14, v8}, Landroid/graphics/Paint;->setColor(I)V

    .line 473
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v8, v10}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 474
    invoke-virtual {v1}, Landroid/graphics/Canvas;->save()I

    .line 475
    invoke-virtual {v1, v6, v4, v5}, Landroid/graphics/Canvas;->rotate(FFF)V

    .line 476
    move-wide v8, v2

    .end local v2  # "seed":J
    .local v8, "seed":J
    sub-float v2, v4, v16

    move v3, v4

    .end local v4  # "cx":F
    .local v3, "cx":F
    add-float v4, v3, v16

    move v13, v6

    .end local v6  # "ang":F
    .local v13, "ang":F
    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    move v14, v3

    move v3, v5

    .end local v5  # "cy":F
    .local v3, "cy":F
    .local v14, "cx":F
    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 477
    invoke-virtual {v1}, Landroid/graphics/Canvas;->restore()V

    .line 465
    .end local v3  # "cy":F
    .end local v10  # "sw":F
    .end local v13  # "ang":F
    .end local v14  # "cx":F
    .end local v15  # "alp":I
    .end local v16  # "len":F
    add-int/lit8 v11, v11, 0x1

    move-wide v2, v8

    const/16 v8, 0xf8

    const/16 v9, 0x38

    const/4 v10, 0x0

    const v13, 0x3e4ccccd  # 0.2f

    const/16 v14, 0xa0

    const v15, 0x3da3d70a  # 0.08f

    goto/16 :goto_105

    .end local v8  # "seed":J
    .restart local v2  # "seed":J
    :cond_1a6
    const v19, 0x3da3d70a  # 0.08f

    .line 480
    .end local v11  # "i":I
    new-instance v4, Landroid/graphics/Path;

    invoke-direct {v4}, Landroid/graphics/Path;-><init>()V

    .line 481
    .local v4, "wave":Landroid/graphics/Path;
    const/4 v5, 0x0

    .local v5, "i":I
    :goto_1af
    const/16 v6, 0xa

    if-ge v5, v6, :cond_23c

    .line 482
    int-to-float v6, v5

    mul-float v6, v6, v19

    const v10, 0x3e0f5c29  # 0.14f

    add-float/2addr v6, v10

    mul-float v6, v6, v7

    .line 483
    .local v6, "y":F
    const v10, 0x3c9374bc  # 0.018f

    mul-float v10, v10, v12

    int-to-float v11, v5

    const v13, 0x3db851ec  # 0.09f

    mul-float v11, v11, v13

    const v13, 0x3f8ccccd  # 1.1f

    sub-float/2addr v13, v11

    const v11, 0x3e4ccccd  # 0.2f

    invoke-static {v11, v13}, Ljava/lang/Math;->max(FF)F

    move-result v13

    mul-float v10, v10, v13

    .line 484
    .local v10, "amp":F
    invoke-virtual {v4}, Landroid/graphics/Path;->reset()V

    .line 485
    const/4 v11, 0x0

    invoke-virtual {v4, v11, v6}, Landroid/graphics/Path;->moveTo(FF)V

    .line 486
    const/4 v11, 0x0

    .local v11, "x":I
    :goto_1dc
    float-to-int v13, v12

    if-gt v11, v13, :cond_203

    .line 487
    int-to-double v13, v11

    const-wide v15, 0x3f926e978d4fdf3bL  # 0.018

    mul-double v13, v13, v15

    const v15, 0x3fe66666  # 1.8f

    int-to-double v8, v5

    const-wide v24, 0x3fe4cccccccccccdL  # 0.65

    mul-double v8, v8, v24

    add-double/2addr v13, v8

    invoke-static {v13, v14}, Ljava/lang/Math;->sin(D)D

    move-result-wide v8

    double-to-float v8, v8

    mul-float v8, v8, v10

    .line 488
    .local v8, "offset":F
    int-to-float v9, v11

    add-float v13, v6, v8

    invoke-virtual {v4, v9, v13}, Landroid/graphics/Path;->lineTo(FF)V

    .line 486
    .end local v8  # "offset":F
    add-int/lit8 v11, v11, 0x12

    goto :goto_1dc

    :cond_203
    const v15, 0x3fe66666  # 1.8f

    .line 490
    .end local v11  # "x":I
    mul-int/lit8 v8, v5, 0x3

    rsub-int/lit8 v8, v8, 0x26

    const/16 v9, 0x8

    invoke-static {v9, v8}, Ljava/lang/Math;->max(II)I

    move-result v8

    .line 491
    .local v8, "wa":I
    iget-object v9, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/16 v11, 0xbd

    const/16 v13, 0x38

    const/16 v14, 0xf8

    invoke-static {v8, v13, v11, v14}, Landroid/graphics/Color;->argb(IIII)I

    move-result v11

    invoke-virtual {v9, v11}, Landroid/graphics/Paint;->setColor(I)V

    .line 492
    iget-object v9, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    int-to-float v11, v5

    const v13, 0x3df5c28f  # 0.12f

    mul-float v11, v11, v13

    sub-float v11, v15, v11

    const v13, 0x3f19999a  # 0.6f

    invoke-static {v13, v11}, Ljava/lang/Math;->max(FF)F

    move-result v11

    invoke-virtual {v9, v11}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 493
    iget-object v9, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v4, v9}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 481
    .end local v6  # "y":F
    .end local v8  # "wa":I
    .end local v10  # "amp":F
    add-int/lit8 v5, v5, 0x1

    goto/16 :goto_1af

    :cond_23c
    const v15, 0x3fe66666  # 1.8f

    .line 496
    .end local v5  # "i":I
    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v6, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 497
    const/4 v5, 0x0

    .restart local v5  # "i":I
    :goto_247
    const/16 v6, 0xa0

    if-ge v5, v6, :cond_2c6

    .line 498
    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->ptX:[F

    aget v6, v6, v5

    .local v6, "cx":F
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->ptY:[F

    aget v8, v8, v5

    .line 499
    .local v8, "cy":F
    iget-object v9, v0, Landroid/ext/BackgroundDrawable;->ptR:[F

    aget v9, v9, v5

    const v10, 0x400ccccd  # 2.2f

    mul-float v9, v9, v10

    add-float/2addr v9, v15

    .line 500
    .local v9, "r":F
    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->ptA:[I

    aget v10, v10, v5

    int-to-float v10, v10

    const v11, 0x3ee66666  # 0.45f

    mul-float v10, v10, v11

    float-to-int v10, v10

    .line 501
    .local v10, "a":I
    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    div-int/lit8 v13, v10, 0x5

    move-wide/from16 v24, v2

    const/16 v2, 0xf8

    const/16 v14, 0xbd

    const/16 v15, 0x38

    .end local v2  # "seed":J
    .local v24, "seed":J
    invoke-static {v13, v15, v14, v2}, Landroid/graphics/Color;->argb(IIII)I

    move-result v3

    invoke-virtual {v11, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 502
    const v2, 0x3fd9999a  # 1.7f

    mul-float v2, v2, v9

    iget-object v3, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v6, v8, v2, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 503
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    div-int/lit8 v3, v10, 0x2

    const/16 v11, 0xe6

    const/16 v13, 0xfd

    const/16 v14, 0xba

    invoke-static {v3, v14, v11, v13}, Landroid/graphics/Color;->argb(IIII)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 504
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v6, v8, v9, v2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 505
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/16 v3, 0xff

    invoke-static {v10, v3, v3, v3}, Landroid/graphics/Color;->argb(IIII)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 506
    const v2, 0x3e8f5c29  # 0.28f

    mul-float v2, v2, v9

    sub-float v2, v6, v2

    const v3, 0x3e8f5c29  # 0.28f

    mul-float v3, v3, v9

    sub-float v3, v8, v3

    const v22, 0x3e4ccccd  # 0.2f

    mul-float v13, v9, v22

    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v3, v13, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 497
    .end local v6  # "cx":F
    .end local v8  # "cy":F
    .end local v9  # "r":F
    .end local v10  # "a":I
    add-int/lit8 v5, v5, 0x1

    move-wide/from16 v2, v24

    const v15, 0x3fe66666  # 1.8f

    goto :goto_247

    .end local v24  # "seed":J
    .restart local v2  # "seed":J
    :cond_2c6
    move-wide/from16 v24, v2

    .line 509
    .end local v2  # "seed":J
    .end local v5  # "i":I
    .restart local v24  # "seed":J
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 510
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_2d0
    const/16 v6, 0xa0

    if-ge v2, v6, :cond_30b

    .line 511
    iget-object v3, v0, Landroid/ext/BackgroundDrawable;->ptA:[I

    aget v3, v3, v2

    int-to-float v3, v3

    mul-float v3, v3, v23

    float-to-int v3, v3

    .line 512
    .local v3, "a":I
    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    const/16 v8, 0xf8

    const/16 v9, 0x38

    const/16 v14, 0xbd

    invoke-static {v3, v9, v14, v8}, Landroid/graphics/Color;->argb(IIII)I

    move-result v10

    invoke-virtual {v5, v10}, Landroid/graphics/Paint;->setColor(I)V

    .line 513
    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->blurSoft:Landroid/graphics/BlurMaskFilter;

    invoke-virtual {v5, v10}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 514
    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->ptX:[F

    aget v5, v5, v2

    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->ptY:[F

    aget v10, v10, v2

    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->ptR:[F

    aget v11, v11, v2

    const v13, 0x3f59999a  # 0.85f

    mul-float v11, v11, v13

    iget-object v13, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    invoke-virtual {v1, v5, v10, v11, v13}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 510
    .end local v3  # "a":I
    add-int/lit8 v2, v2, 0x2

    goto :goto_2d0

    .line 516
    .end local v2  # "i":I
    :cond_30b
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 517
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 518
    return-void

    nop

    :array_31a
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data

    :array_322
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data

    :array_32a
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data
.end method

.method private drawBg(Landroid/graphics/Canvas;FF)V
    .registers 20
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "w"  # F
    .param p3, "h"  # F

    .line 1158
    move-object/from16 v0, p0

    iget-object v1, v0, Landroid/ext/BackgroundDrawable;->pBg:Landroid/graphics/Paint;

    new-instance v2, Landroid/graphics/LinearGradient;

    const/high16 v3, 0x3f000000  # 0.5f

    const/high16 v4, 0x3f000000  # 0.5f

    mul-float v3, p2, v4

    mul-float v5, p2, v4

    iget v4, v0, Landroid/ext/BackgroundDrawable;->COL_BG_TOP:I

    iget v6, v0, Landroid/ext/BackgroundDrawable;->COL_BG_MID:I

    iget v7, v0, Landroid/ext/BackgroundDrawable;->COL_BG_BOTTOM:I

    filled-new-array {v4, v6, v7}, [I

    move-result-object v7

    const/4 v4, 0x3

    new-array v8, v4, [F

    fill-array-data v8, :array_3e

    sget-object v9, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/4 v4, 0x0

    move/from16 v6, p3

    invoke-direct/range {v2 .. v9}, Landroid/graphics/LinearGradient;-><init>(FFFF[I[FLandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 1163
    const/4 v12, 0x0

    iget-object v15, v0, Landroid/ext/BackgroundDrawable;->pBg:Landroid/graphics/Paint;

    const/4 v11, 0x0

    move-object/from16 v10, p1

    move/from16 v13, p2

    move/from16 v14, p3

    invoke-virtual/range {v10 .. v15}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 1164
    iget-object v1, v0, Landroid/ext/BackgroundDrawable;->pBg:Landroid/graphics/Paint;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 1165
    return-void

    nop

    :array_3e
    .array-data 4
        0x0
        0x3ee66666  # 0.45f
        0x3f800000  # 1.0f
    .end array-data
.end method

.method private drawCoffeeBg(Landroid/graphics/Canvas;FF)V
    .registers 29
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "w"  # F
    .param p3, "h"  # F

    .line 608
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 609
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v3, Landroid/graphics/RadialGradient;

    const/high16 v10, 0x3f000000  # 0.5f

    mul-float v4, p2, v10

    const v11, 0x3f2e147b  # 0.68f

    mul-float v5, p3, v11

    const v12, 0x3f051eb8  # 0.52f

    mul-float v6, p2, v12

    .line 611
    const/16 v7, 0x55

    const/16 v8, 0x92

    const/16 v9, 0x40

    const/16 v13, 0xe

    invoke-static {v7, v8, v9, v13}, Landroid/graphics/Color;->argb(IIII)I

    move-result v7

    const/4 v14, 0x0

    const/16 v15, 0x1e

    const/16 v8, 0xa

    invoke-static {v14, v15, v8, v14}, Landroid/graphics/Color;->argb(IIII)I

    move-result v9

    filled-new-array {v7, v9}, [I

    move-result-object v7

    const/4 v9, 0x2

    const/16 v16, 0xa

    new-array v8, v9, [F

    fill-array-data v8, :array_2a8

    const/16 v17, 0x2

    sget-object v9, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/16 v11, 0xa

    const/4 v12, 0x2

    const v16, 0x3f051eb8  # 0.52f

    const v18, 0x3f2e147b  # 0.68f

    invoke-direct/range {v3 .. v9}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 609
    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 613
    mul-float v2, p2, v10

    mul-float v3, p3, v18

    mul-float v4, p2, v16

    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v3, v4, v5}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 615
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v3, Landroid/graphics/RadialGradient;

    const v16, 0x3e8f5c29  # 0.28f

    mul-float v4, p2, v16

    mul-float v5, p3, v16

    const v17, 0x3eb851ec  # 0.36f

    mul-float v6, p2, v17

    .line 617
    const/16 v7, 0x41

    const/16 v8, 0xb4

    const/16 v9, 0x64

    const/16 v19, 0xe

    const/16 v13, 0x14

    invoke-static {v7, v8, v9, v13}, Landroid/graphics/Color;->argb(IIII)I

    move-result v7

    invoke-static {v14, v15, v11, v14}, Landroid/graphics/Color;->argb(IIII)I

    move-result v9

    filled-new-array {v7, v9}, [I

    move-result-object v7

    new-array v9, v12, [F

    fill-array-data v9, :array_2b0

    move-object v8, v9

    const/16 v11, 0xb4

    sget-object v9, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v3 .. v9}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 615
    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 619
    mul-float v2, p2, v16

    mul-float v3, p3, v16

    mul-float v4, p2, v17

    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v3, v4, v5}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 620
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 623
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 624
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_ab
    const/4 v4, 0x7

    if-ge v2, v4, :cond_f0

    .line 625
    int-to-float v4, v2

    const v5, 0x3d6d9168  # 0.058f

    mul-float v4, v4, v5

    const v5, 0x3d8f5c29  # 0.07f

    add-float/2addr v4, v5

    mul-float v4, v4, p2

    .line 626
    .local v4, "r":F
    mul-int/lit8 v5, v2, 0x5

    rsub-int/lit8 v5, v5, 0x26

    invoke-static {v14, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    .line 627
    .local v5, "a":I
    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/16 v7, 0x8c

    const/16 v8, 0x3c

    const/16 v9, 0xd2

    invoke-static {v5, v9, v7, v8}, Landroid/graphics/Color;->argb(IIII)I

    move-result v7

    invoke-virtual {v6, v7}, Landroid/graphics/Paint;->setColor(I)V

    .line 628
    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    int-to-float v7, v2

    const v8, 0x3e19999a  # 0.15f

    mul-float v7, v7, v8

    const v8, 0x3fb33333  # 1.4f

    sub-float/2addr v8, v7

    invoke-static {v10, v8}, Ljava/lang/Math;->max(FF)F

    move-result v7

    invoke-virtual {v6, v7}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 629
    mul-float v6, p2, v10

    mul-float v7, p3, v18

    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v6, v7, v4, v8}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 624
    .end local v4  # "r":F
    .end local v5  # "a":I
    add-int/lit8 v2, v2, 0x1

    goto :goto_ab

    .line 633
    .end local v2  # "i":I
    :cond_f0
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 634
    const-wide v4, 0xc0ffee01L

    .line 635
    .local v4, "seed":J
    const/4 v2, 0x0

    .restart local v2  # "i":I
    :goto_fd
    const/16 v6, 0x8

    const v8, 0x3f99999a  # 1.2f

    const v9, 0x3e6147ae  # 0.22f

    if-ge v2, v6, :cond_1c8

    .line 636
    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v4

    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v6

    const v10, 0x3f0f5c29  # 0.56f

    mul-float v6, v6, v10

    add-float/2addr v6, v9

    mul-float v6, v6, p2

    .line 637
    .local v6, "cx":F
    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v4

    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v9

    const v10, 0x3c9374bc  # 0.018f

    mul-float v9, v9, v10

    const v10, 0x3c449ba6  # 0.012f

    add-float/2addr v9, v10

    mul-float v9, v9, p2

    .line 638
    .local v9, "amp":F
    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v4

    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v10

    const/high16 v12, 0x41a00000  # 20.0f

    mul-float v10, v10, v12

    float-to-int v10, v10

    add-int/lit8 v10, v10, 0xe

    .line 639
    .local v10, "alp":I
    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v4

    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v12

    const v13, 0x3f4ccccd  # 0.8f

    mul-float v12, v12, v13

    add-float/2addr v12, v8

    .line 640
    .local v12, "sw":F
    const v8, 0x3f0ccccd  # 0.55f

    mul-float v8, v8, p3

    .line 641
    .local v8, "startY":F
    const v13, 0x3dcccccd  # 0.1f

    mul-float v13, v13, p3

    .line 642
    .local v13, "endY":F
    new-instance v14, Landroid/graphics/Path;

    invoke-direct {v14}, Landroid/graphics/Path;-><init>()V

    .line 643
    .local v14, "steam":Landroid/graphics/Path;
    invoke-virtual {v14, v6, v8}, Landroid/graphics/Path;->moveTo(FF)V

    .line 644
    const/4 v15, 0x1

    .local v15, "s":I
    :goto_15a
    const/16 v3, 0xc

    if-gt v15, v3, :cond_1a2

    .line 645
    int-to-float v3, v15

    const/high16 v18, 0x41400000  # 12.0f

    div-float v3, v3, v18

    .line 646
    .local v3, "t":F
    sub-float v18, v13, v8

    mul-float v18, v18, v3

    add-float v11, v8, v18

    .line 647
    .local v11, "y":F
    move/from16 v20, v8

    .end local v8  # "startY":F
    .local v20, "startY":F
    float-to-double v7, v3

    const-wide v21, 0x400921fb54442d18L  # Math.PI

    mul-double v7, v7, v21

    const-wide/high16 v21, 0x4004000000000000L  # 2.5

    mul-double v7, v7, v21

    move-wide/from16 v21, v4

    move v5, v3

    .end local v3  # "t":F
    .end local v4  # "seed":J
    .local v5, "t":F
    .local v21, "seed":J
    int-to-double v3, v2

    const-wide v23, 0x3feb333333333333L  # 0.85

    mul-double v3, v3, v23

    add-double/2addr v7, v3

    invoke-static {v7, v8}, Ljava/lang/Math;->sin(D)D

    move-result-wide v3

    double-to-float v3, v3

    mul-float v3, v3, v9

    const v4, 0x3ee66666  # 0.45f

    mul-float v4, v4, v5

    const/high16 v7, 0x3f800000  # 1.0f

    sub-float/2addr v7, v4

    mul-float v3, v3, v7

    add-float/2addr v3, v6

    .line 648
    .local v3, "x":F
    invoke-virtual {v14, v3, v11}, Landroid/graphics/Path;->lineTo(FF)V

    .line 644
    .end local v3  # "x":F
    .end local v5  # "t":F
    .end local v11  # "y":F
    add-int/lit8 v15, v15, 0x1

    move/from16 v8, v20

    move-wide/from16 v4, v21

    const/4 v3, 0x0

    const/16 v11, 0xb4

    goto :goto_15a

    .end local v20  # "startY":F
    .end local v21  # "seed":J
    .restart local v4  # "seed":J
    .restart local v8  # "startY":F
    :cond_1a2
    move-wide/from16 v21, v4

    move/from16 v20, v8

    .line 650
    .end local v4  # "seed":J
    .end local v8  # "startY":F
    .end local v15  # "s":I
    .restart local v20  # "startY":F
    .restart local v21  # "seed":J
    iget-object v3, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/16 v4, 0xe4

    const/16 v5, 0xc4

    const/16 v7, 0xff

    invoke-static {v10, v7, v4, v5}, Landroid/graphics/Color;->argb(IIII)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 651
    iget-object v3, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v3, v12}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 652
    iget-object v3, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v14, v3}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 635
    .end local v6  # "cx":F
    .end local v9  # "amp":F
    .end local v10  # "alp":I
    .end local v12  # "sw":F
    .end local v13  # "endY":F
    .end local v14  # "steam":Landroid/graphics/Path;
    .end local v20  # "startY":F
    add-int/lit8 v2, v2, 0x1

    move-wide/from16 v4, v21

    const/4 v3, 0x0

    const/16 v11, 0xb4

    goto/16 :goto_fd

    .line 656
    .end local v2  # "i":I
    .end local v21  # "seed":J
    .restart local v4  # "seed":J
    :cond_1c8
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 657
    const/4 v2, 0x0

    .restart local v2  # "i":I
    :goto_1d0
    const/16 v3, 0xa0

    if-ge v2, v3, :cond_255

    .line 658
    iget-object v3, v0, Landroid/ext/BackgroundDrawable;->ptX:[F

    aget v3, v3, v2

    .line 659
    .local v3, "cx":F
    const v6, 0x3f147ae1  # 0.58f

    mul-float v6, v6, p3

    iget-object v7, v0, Landroid/ext/BackgroundDrawable;->ptY:[F

    aget v7, v7, v2

    div-float v7, v7, p3

    mul-float v7, v7, p3

    const v10, 0x3eb33333  # 0.35f

    mul-float v7, v7, v10

    add-float/2addr v6, v7

    .line 660
    .local v6, "cy":F
    iget-object v7, v0, Landroid/ext/BackgroundDrawable;->ptR:[F

    aget v7, v7, v2

    const/high16 v10, 0x40000000  # 2.0f

    mul-float v7, v7, v10

    add-float/2addr v7, v8

    .line 661
    .local v7, "r":F
    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->ptA:[I

    aget v10, v10, v2

    int-to-float v10, v10

    const v11, 0x3ec28f5c  # 0.38f

    mul-float v10, v10, v11

    float-to-int v10, v10

    .line 662
    .local v10, "a":I
    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    div-int/lit8 v12, v10, 0x5

    const/16 v13, 0x82

    const/16 v14, 0x46

    const/16 v15, 0xc8

    invoke-static {v12, v15, v13, v14}, Landroid/graphics/Color;->argb(IIII)I

    move-result v12

    invoke-virtual {v11, v12}, Landroid/graphics/Paint;->setColor(I)V

    .line 663
    const v11, 0x3fd9999a  # 1.7f

    mul-float v11, v11, v7

    iget-object v12, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v3, v6, v11, v12}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 664
    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    div-int/lit8 v12, v10, 0x2

    const/16 v13, 0xeb

    const/16 v14, 0x6e

    const/16 v15, 0xb4

    invoke-static {v12, v13, v15, v14}, Landroid/graphics/Color;->argb(IIII)I

    move-result v12

    invoke-virtual {v11, v12}, Landroid/graphics/Paint;->setColor(I)V

    .line 665
    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v3, v6, v7, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 666
    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/16 v12, 0xf0

    const/16 v13, 0xd7

    const/16 v14, 0xff

    invoke-static {v10, v14, v12, v13}, Landroid/graphics/Color;->argb(IIII)I

    move-result v12

    invoke-virtual {v11, v12}, Landroid/graphics/Paint;->setColor(I)V

    .line 667
    mul-float v11, v7, v16

    sub-float v11, v3, v11

    mul-float v12, v7, v16

    sub-float v12, v6, v12

    mul-float v13, v7, v9

    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v11, v12, v13, v8}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 657
    .end local v3  # "cx":F
    .end local v6  # "cy":F
    .end local v7  # "r":F
    .end local v10  # "a":I
    add-int/lit8 v2, v2, 0x1

    const v8, 0x3f99999a  # 1.2f

    goto/16 :goto_1d0

    .line 671
    .end local v2  # "i":I
    :cond_255
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    sget-object v6, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v6}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 672
    const/4 v2, 0x0

    .restart local v2  # "i":I
    :goto_25d
    if-ge v2, v3, :cond_299

    .line 673
    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->ptA:[I

    aget v6, v6, v2

    int-to-float v6, v6

    const v7, 0x3ef5c28f  # 0.48f

    mul-float v6, v6, v7

    float-to-int v6, v6

    .line 674
    .local v6, "a":I
    iget-object v7, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    const/16 v8, 0x9b

    const/16 v9, 0x4b

    const/16 v10, 0xda

    invoke-static {v6, v10, v8, v9}, Landroid/graphics/Color;->argb(IIII)I

    move-result v8

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setColor(I)V

    .line 675
    iget-object v7, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->blurSoft:Landroid/graphics/BlurMaskFilter;

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 676
    iget-object v7, v0, Landroid/ext/BackgroundDrawable;->ptX:[F

    aget v7, v7, v2

    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->ptY:[F

    aget v8, v8, v2

    iget-object v9, v0, Landroid/ext/BackgroundDrawable;->ptR:[F

    aget v9, v9, v2

    const v10, 0x3f3851ec  # 0.72f

    mul-float v9, v9, v10

    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    invoke-virtual {v1, v7, v8, v9, v10}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 672
    .end local v6  # "a":I
    add-int/lit8 v2, v2, 0x2

    goto :goto_25d

    .line 678
    .end local v2  # "i":I
    :cond_299
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 679
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 680
    return-void

    nop

    :array_2a8
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data

    :array_2b0
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data
.end method

.method private drawDesertBg(Landroid/graphics/Canvas;FF)V
    .registers 21
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "w"  # F
    .param p3, "h"  # F

    .line 1025
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1026
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v3, Landroid/graphics/RadialGradient;

    const/high16 v10, 0x3f000000  # 0.5f

    mul-float v4, p2, v10

    const v11, 0x3f0ccccd  # 0.55f

    mul-float v5, p3, v11

    mul-float v6, p2, v11

    .line 1028
    const/16 v7, 0x4b

    const/16 v8, 0xd9

    const/16 v9, 0x77

    const/4 v12, 0x6

    invoke-static {v7, v8, v9, v12}, Landroid/graphics/Color;->argb(IIII)I

    move-result v7

    const/16 v8, 0x2d

    const/16 v9, 0x14

    const/4 v12, 0x0

    invoke-static {v12, v8, v9, v12}, Landroid/graphics/Color;->argb(IIII)I

    move-result v8

    filled-new-array {v7, v8}, [I

    move-result-object v7

    const/4 v13, 0x2

    new-array v8, v13, [F

    fill-array-data v8, :array_154

    sget-object v9, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v3 .. v9}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 1026
    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 1030
    mul-float v2, p2, v10

    mul-float v3, p3, v11

    mul-float v11, v11, p2

    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v3, v11, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1032
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v3, Landroid/graphics/RadialGradient;

    const v11, 0x3e6147ae  # 0.22f

    mul-float v4, p2, v11

    const v14, 0x3e99999a  # 0.3f

    mul-float v5, p3, v14

    const v15, 0x3ea3d70a  # 0.32f

    mul-float v6, p2, v15

    .line 1034
    const/16 v7, 0x37

    const/16 v8, 0xfb

    const/16 v9, 0xbf

    const/high16 v16, 0x3f000000  # 0.5f

    const/16 v10, 0x24

    invoke-static {v7, v8, v9, v10}, Landroid/graphics/Color;->argb(IIII)I

    move-result v7

    const/16 v8, 0x3c

    const/16 v9, 0x1e

    invoke-static {v12, v8, v9, v12}, Landroid/graphics/Color;->argb(IIII)I

    move-result v8

    filled-new-array {v7, v8}, [I

    move-result-object v7

    new-array v8, v13, [F

    fill-array-data v8, :array_15c

    sget-object v9, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/16 v12, 0xfb

    const/16 v13, 0xbf

    invoke-direct/range {v3 .. v9}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 1032
    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 1036
    mul-float v11, v11, p2

    mul-float v14, v14, p3

    mul-float v15, v15, p2

    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v11, v14, v15, v2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1037
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 1039
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1040
    const-wide v4, 0xde5e7701L

    .line 1041
    .local v4, "seed":J
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_a7
    const/16 v6, 0xc

    const v7, 0x3f333333  # 0.7f

    if-ge v2, v6, :cond_10c

    .line 1042
    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v4

    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v6

    mul-float v6, v6, v7

    const v7, 0x3e19999a  # 0.15f

    add-float/2addr v6, v7

    mul-float v6, v6, p2

    .line 1043
    .local v6, "cx":F
    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v4

    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v7

    const v8, 0x3f19999a  # 0.6f

    mul-float v7, v7, v8

    const v8, 0x3e4ccccd  # 0.2f

    add-float/2addr v7, v8

    mul-float v7, v7, p3

    .line 1044
    .local v7, "cy":F
    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v4

    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v8

    const v9, 0x3da3d70a  # 0.08f

    mul-float v8, v8, v9

    const v9, 0x3ca3d70a  # 0.02f

    add-float/2addr v8, v9

    mul-float v8, v8, p2

    .line 1045
    .local v8, "r":F
    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v4

    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v9

    const/high16 v11, 0x41c80000  # 25.0f

    mul-float v9, v9, v11

    float-to-int v9, v9

    add-int/lit8 v9, v9, 0xf

    .line 1046
    .local v9, "alp":I
    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-static {v9, v12, v13, v10}, Landroid/graphics/Color;->argb(IIII)I

    move-result v14

    invoke-virtual {v11, v14}, Landroid/graphics/Paint;->setColor(I)V

    .line 1047
    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const v14, 0x3f99999a  # 1.2f

    invoke-virtual {v11, v14}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1048
    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v6, v7, v8, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1041
    .end local v6  # "cx":F
    .end local v7  # "cy":F
    .end local v8  # "r":F
    .end local v9  # "alp":I
    add-int/lit8 v2, v2, 0x1

    goto :goto_a7

    .line 1051
    .end local v2  # "i":I
    :cond_10c
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    sget-object v6, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v6}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1052
    const/4 v2, 0x0

    .restart local v2  # "i":I
    :goto_114
    const/16 v6, 0xa0

    if-ge v2, v6, :cond_146

    .line 1053
    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->ptA:[I

    aget v6, v6, v2

    int-to-float v6, v6

    mul-float v6, v6, v16

    float-to-int v6, v6

    .line 1054
    .local v6, "a":I
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    invoke-static {v6, v12, v13, v10}, Landroid/graphics/Color;->argb(IIII)I

    move-result v9

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setColor(I)V

    .line 1055
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    iget-object v9, v0, Landroid/ext/BackgroundDrawable;->blurSoft:Landroid/graphics/BlurMaskFilter;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 1056
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->ptX:[F

    aget v8, v8, v2

    iget-object v9, v0, Landroid/ext/BackgroundDrawable;->ptY:[F

    aget v9, v9, v2

    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->ptR:[F

    aget v11, v11, v2

    mul-float v11, v11, v7

    iget-object v14, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    invoke-virtual {v1, v8, v9, v11, v14}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1052
    .end local v6  # "a":I
    add-int/lit8 v2, v2, 0x2

    goto :goto_114

    .line 1058
    .end local v2  # "i":I
    :cond_146
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 1059
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1060
    return-void

    nop

    :array_154
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data

    :array_15c
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data
.end method

.method private drawForestBg(Landroid/graphics/Canvas;FF)V
    .registers 30
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "w"  # F
    .param p3, "h"  # F

    .line 790
    move-object/from16 v0, p0

    iget-object v1, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 791
    const-wide v1, 0xf03e5701L

    .line 792
    .local v1, "seed":J
    const/4 v3, 0x0

    move v7, v3

    .local v7, "i":I
    :goto_10
    const/4 v3, 0x7

    const/16 v4, 0xe6

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-ge v7, v3, :cond_95

    .line 793
    invoke-direct {v0, v1, v2}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v1

    invoke-direct {v0, v1, v2}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v3

    const v8, 0x3f428f5c  # 0.76f

    mul-float v3, v3, v8

    const v8, 0x3df5c28f  # 0.12f

    add-float/2addr v3, v8

    mul-float v9, p2, v3

    .line 794
    .local v9, "cx":F
    invoke-direct {v0, v1, v2}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v1

    invoke-direct {v0, v1, v2}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v3

    const v8, 0x3d6147ae  # 0.055f

    mul-float v3, v3, v8

    const v8, 0x3d0f5c29  # 0.035f

    add-float/2addr v3, v8

    mul-float v16, p2, v3

    .line 795
    .local v16, "wR":F
    invoke-direct {v0, v1, v2}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v1

    invoke-direct {v0, v1, v2}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v3

    const/high16 v8, 0x41900000  # 18.0f

    mul-float v3, v3, v8

    float-to-int v3, v3

    add-int/lit8 v3, v3, 0xe

    .line 796
    .local v3, "alp":I
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    move-object v10, v8

    new-instance v8, Landroid/graphics/LinearGradient;

    const v17, 0x3f47ae14  # 0.78f

    mul-float v12, p3, v17

    .line 798
    const/16 v11, 0x78

    const/16 v13, 0x50

    invoke-static {v3, v11, v4, v13}, Landroid/graphics/Color;->argb(IIII)I

    move-result v4

    const/16 v11, 0x14

    const/16 v13, 0x3c

    invoke-static {v6, v11, v13, v6}, Landroid/graphics/Color;->argb(IIII)I

    move-result v6

    filled-new-array {v4, v6}, [I

    move-result-object v13

    new-array v14, v5, [F

    fill-array-data v14, :array_29a

    sget-object v15, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    move-object v4, v10

    const/4 v10, 0x0

    move v11, v9

    invoke-direct/range {v8 .. v15}, Landroid/graphics/LinearGradient;-><init>(FFFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 796
    invoke-virtual {v4, v8}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 800
    move-wide v4, v1

    .end local v1  # "seed":J
    .local v4, "seed":J
    sub-float v2, v9, v16

    move-wide v5, v4

    .end local v4  # "seed":J
    .local v5, "seed":J
    add-float v4, v9, v16

    mul-float v17, v17, p3

    move-wide v10, v5

    .end local v5  # "seed":J
    .local v10, "seed":J
    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    move v1, v3

    .end local v3  # "alp":I
    .local v1, "alp":I
    const/4 v3, 0x0

    move v8, v1

    move/from16 v5, v17

    move-object/from16 v1, p1

    .end local v1  # "alp":I
    .local v8, "alp":I
    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 792
    move-object v3, v1

    .end local v8  # "alp":I
    .end local v9  # "cx":F
    .end local v16  # "wR":F
    add-int/lit8 v7, v7, 0x1

    move-wide v1, v10

    goto/16 :goto_10

    .end local v10  # "seed":J
    .local v1, "seed":J
    :cond_95
    move-object/from16 v3, p1

    .line 802
    .end local v7  # "i":I
    iget-object v7, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/4 v8, 0x0

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 805
    iget-object v7, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v9, Landroid/graphics/RadialGradient;

    const v16, 0x3ea3d70a  # 0.32f

    mul-float v10, p2, v16

    const v17, 0x3ec28f5c  # 0.38f

    mul-float v11, p3, v17

    const v18, 0x3eeb851f  # 0.46f

    mul-float v12, p2, v18

    .line 807
    const/16 v13, 0x41

    const/16 v14, 0x16

    const/16 v15, 0x65

    const/16 v4, 0x34

    invoke-static {v13, v14, v15, v4}, Landroid/graphics/Color;->argb(IIII)I

    move-result v4

    const/4 v13, 0x4

    const/16 v14, 0x12

    invoke-static {v6, v13, v14, v6}, Landroid/graphics/Color;->argb(IIII)I

    move-result v15

    filled-new-array {v4, v15}, [I

    move-result-object v4

    const/16 v15, 0x12

    new-array v14, v5, [F

    fill-array-data v14, :array_2a2

    const/16 v20, 0x12

    sget-object v15, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    move-object v13, v4

    const/16 v4, 0x12

    const/4 v8, 0x4

    invoke-direct/range {v9 .. v15}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 805
    invoke-virtual {v7, v9}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 809
    mul-float v7, p2, v16

    mul-float v9, p3, v17

    mul-float v10, p2, v18

    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v3, v7, v9, v10, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 811
    iget-object v7, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v9, Landroid/graphics/RadialGradient;

    const v16, 0x3f3851ec  # 0.72f

    mul-float v10, p2, v16

    const v18, 0x3f266666  # 0.65f

    mul-float v11, p3, v18

    mul-float v12, p2, v17

    .line 813
    const/16 v13, 0x37

    const/16 v14, 0x2d

    const/16 v15, 0x9b

    const/16 v5, 0x32

    invoke-static {v13, v14, v15, v5}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    invoke-static {v6, v8, v4, v6}, Landroid/graphics/Color;->argb(IIII)I

    move-result v4

    filled-new-array {v5, v4}, [I

    move-result-object v13

    const/4 v4, 0x2

    new-array v14, v4, [F

    fill-array-data v14, :array_2aa

    sget-object v15, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v9 .. v15}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 811
    invoke-virtual {v7, v9}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 815
    mul-float v4, p2, v16

    mul-float v5, p3, v18

    mul-float v7, p2, v17

    iget-object v9, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v3, v4, v5, v7, v9}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 816
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 819
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 820
    const/4 v4, 0x5

    new-array v4, v4, [[I

    const/16 v5, 0x4a

    const/16 v7, 0xde

    const/16 v9, 0x80

    filled-new-array {v5, v7, v9}, [I

    move-result-object v10

    aput-object v10, v4, v6

    const/16 v10, 0x86

    const/16 v11, 0xef

    const/16 v12, 0xac

    filled-new-array {v10, v11, v12}, [I

    move-result-object v13

    const/4 v14, 0x1

    aput-object v13, v4, v14

    const/16 v13, 0xf9

    const/16 v15, 0x9d

    const/16 v16, 0x0

    const/16 v6, 0xd9

    filled-new-array {v6, v13, v15}, [I

    move-result-object v6

    const/16 v21, 0x2

    aput-object v6, v4, v21

    const/16 v6, 0xe7

    const/16 v13, 0xb7

    const/16 v15, 0x6e

    filled-new-array {v15, v6, v13}, [I

    move-result-object v6

    const/4 v13, 0x3

    aput-object v6, v4, v13

    const/16 v6, 0xa3

    const/16 v13, 0x35

    const/16 v15, 0xe6

    filled-new-array {v6, v15, v13}, [I

    move-result-object v6

    aput-object v6, v4, v8

    .line 821
    .local v4, "leafCols":[[I
    const/4 v6, 0x0

    .local v6, "i":I
    :goto_177
    const/16 v8, 0xa0

    if-ge v6, v8, :cond_1ee

    .line 822
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->ptX:[F

    aget v8, v8, v6

    .local v8, "cx":F
    iget-object v13, v0, Landroid/ext/BackgroundDrawable;->ptY:[F

    aget v13, v13, v6

    .line 823
    .local v13, "cy":F
    iget-object v15, v0, Landroid/ext/BackgroundDrawable;->ptR:[F

    aget v15, v15, v6

    const/high16 v17, 0x40d00000  # 6.5f

    mul-float v15, v15, v17

    const/high16 v17, 0x40200000  # 2.5f

    add-float v15, v15, v17

    .line 824
    .local v15, "rW":F
    const v17, 0x3eb851ec  # 0.36f

    mul-float v17, v17, v15

    .line 825
    .local v17, "rH":F
    const/16 v19, 0x1

    iget-object v14, v0, Landroid/ext/BackgroundDrawable;->ptExtra:[F

    aget v14, v14, v6

    const/high16 v22, 0x43b40000  # 360.0f

    mul-float v14, v14, v22

    .line 826
    .local v14, "ang":F
    array-length v10, v4

    rem-int v10, v6, v10

    aget-object v10, v4, v10

    .line 827
    .local v10, "lc":[I
    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->ptA:[I

    aget v11, v11, v6

    int-to-float v11, v11

    const v23, 0x3e99999a  # 0.3f

    mul-float v11, v11, v23

    float-to-int v11, v11

    .line 828
    .local v11, "a":I
    iget-object v12, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    aget v5, v10, v16

    aget v7, v10, v19

    const/16 v21, 0x2

    aget v9, v10, v21

    invoke-static {v11, v5, v7, v9}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    invoke-virtual {v12, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 829
    invoke-virtual {v3}, Landroid/graphics/Canvas;->save()I

    .line 830
    invoke-virtual {v3, v14, v8, v13}, Landroid/graphics/Canvas;->rotate(FFF)V

    .line 831
    new-instance v5, Landroid/graphics/RectF;

    sub-float v7, v8, v15

    sub-float v9, v13, v17

    add-float v12, v8, v15

    move-wide/from16 v24, v1

    .end local v1  # "seed":J
    .local v24, "seed":J
    add-float v1, v13, v17

    invoke-direct {v5, v7, v9, v12, v1}, Landroid/graphics/RectF;-><init>(FFFF)V

    iget-object v1, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v3, v5, v1}, Landroid/graphics/Canvas;->drawOval(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 832
    invoke-virtual {v3}, Landroid/graphics/Canvas;->restore()V

    .line 821
    .end local v8  # "cx":F
    .end local v10  # "lc":[I
    .end local v11  # "a":I
    .end local v13  # "cy":F
    .end local v14  # "ang":F
    .end local v15  # "rW":F
    .end local v17  # "rH":F
    add-int/lit8 v6, v6, 0x1

    move-wide/from16 v1, v24

    const/16 v5, 0x4a

    const/16 v7, 0xde

    const/16 v9, 0x80

    const/16 v10, 0x86

    const/16 v11, 0xef

    const/16 v12, 0xac

    const/4 v14, 0x1

    goto :goto_177

    .end local v24  # "seed":J
    .restart local v1  # "seed":J
    :cond_1ee
    move-wide/from16 v24, v1

    .line 836
    .end local v1  # "seed":J
    .end local v6  # "i":I
    .restart local v24  # "seed":J
    iget-object v1, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 837
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_1f8
    const/16 v2, 0xa0

    if-ge v1, v2, :cond_250

    .line 838
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->ptA:[I

    aget v2, v2, v1

    int-to-float v2, v2

    const v5, 0x3f147ae1  # 0.58f

    mul-float v2, v2, v5

    float-to-int v2, v2

    .line 839
    .local v2, "a":I
    rem-int/lit8 v5, v1, 0x4

    if-nez v5, :cond_21b

    .line 840
    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    const/16 v6, 0x80

    const/16 v7, 0xde

    const/16 v8, 0x4a

    invoke-static {v2, v8, v7, v6}, Landroid/graphics/Color;->argb(IIII)I

    move-result v9

    invoke-virtual {v5, v9}, Landroid/graphics/Paint;->setColor(I)V

    goto :goto_230

    .line 842
    :cond_21b
    const/16 v6, 0x80

    const/16 v7, 0xde

    const/16 v8, 0x4a

    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    const/16 v9, 0xff

    const/16 v10, 0x5a

    const/16 v11, 0xc8

    invoke-static {v2, v11, v9, v10}, Landroid/graphics/Color;->argb(IIII)I

    move-result v9

    invoke-virtual {v5, v9}, Landroid/graphics/Paint;->setColor(I)V

    .line 844
    :goto_230
    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    iget-object v9, v0, Landroid/ext/BackgroundDrawable;->blurSoft:Landroid/graphics/BlurMaskFilter;

    invoke-virtual {v5, v9}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 845
    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->ptX:[F

    aget v5, v5, v1

    iget-object v9, v0, Landroid/ext/BackgroundDrawable;->ptY:[F

    aget v9, v9, v1

    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->ptR:[F

    aget v10, v10, v1

    const v11, 0x3f6147ae  # 0.88f

    mul-float v10, v10, v11

    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    invoke-virtual {v3, v5, v9, v10, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 837
    .end local v2  # "a":I
    add-int/lit8 v1, v1, 0x2

    goto :goto_1f8

    .line 847
    .end local v1  # "i":I
    :cond_250
    iget-object v1, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    const/4 v5, 0x0

    invoke-virtual {v1, v5}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 850
    const/4 v1, 0x0

    .restart local v1  # "i":I
    :goto_257
    const/16 v2, 0xc8

    if-ge v1, v2, :cond_291

    .line 851
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->sA:[I

    aget v2, v2, v1

    int-to-float v2, v2

    const v5, 0x3e6147ae  # 0.22f

    mul-float v2, v2, v5

    float-to-int v2, v2

    .line 852
    .restart local v2  # "a":I
    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    const/16 v6, 0xac

    const/16 v7, 0xef

    const/16 v8, 0x86

    invoke-static {v2, v8, v7, v6}, Landroid/graphics/Color;->argb(IIII)I

    move-result v9

    invoke-virtual {v5, v9}, Landroid/graphics/Paint;->setColor(I)V

    .line 853
    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    const/4 v9, 0x0

    invoke-virtual {v5, v9}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 854
    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->sX:[F

    aget v5, v5, v1

    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->sY:[F

    aget v10, v10, v1

    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->sR:[F

    aget v11, v11, v1

    mul-float v11, v11, v18

    iget-object v12, v0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    invoke-virtual {v3, v5, v10, v11, v12}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 850
    .end local v2  # "a":I
    add-int/lit8 v1, v1, 0x3

    goto :goto_257

    .line 856
    .end local v1  # "i":I
    :cond_291
    iget-object v1, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 857
    return-void

    nop

    :array_29a
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data

    :array_2a2
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data

    :array_2aa
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data
.end method

.method private drawLedBars(Landroid/graphics/Canvas;FF)V
    .registers 15
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "w"  # F
    .param p3, "h"  # F

    .line 1239
    const/high16 v0, 0x40600000  # 3.5f

    .local v0, "barH":F
    const/high16 v1, 0x3e800000  # 0.25f

    mul-float v1, v1, p2

    .line 1240
    .local v1, "barW":F
    const v2, 0x41bccccd  # 23.6f

    .line 1241
    .local v2, "yTop":F
    const/high16 v3, 0x40000000  # 2.0f

    sub-float v3, p3, v3

    const v4, 0x41accccd  # 21.6f

    sub-float/2addr v3, v4

    .line 1243
    .local v3, "yBot":F
    new-instance v4, Landroid/graphics/RectF;

    const/high16 v5, 0x3f000000  # 0.5f

    mul-float v6, p2, v5

    mul-float v7, v1, v5

    sub-float/2addr v6, v7

    mul-float v7, v0, v5

    sub-float v7, v2, v7

    mul-float v8, p2, v5

    mul-float v9, v1, v5

    add-float/2addr v8, v9

    mul-float v9, v0, v5

    add-float/2addr v9, v2

    invoke-direct {v4, v6, v7, v8, v9}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 1245
    .local v4, "bar1":Landroid/graphics/RectF;
    iget-object v6, p0, Landroid/ext/BackgroundDrawable;->pLedBar:Landroid/graphics/Paint;

    invoke-virtual {p1, v4, v0, v0, v6}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1247
    new-instance v6, Landroid/graphics/RectF;

    mul-float v7, p2, v5

    mul-float v8, v1, v5

    sub-float/2addr v7, v8

    mul-float v8, v0, v5

    sub-float v8, v3, v8

    mul-float v9, p2, v5

    mul-float v10, v1, v5

    add-float/2addr v9, v10

    mul-float v5, v5, v0

    add-float/2addr v5, v3

    invoke-direct {v6, v7, v8, v9, v5}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 1249
    .local v6, "bar2":Landroid/graphics/RectF;
    iget-object v5, p0, Landroid/ext/BackgroundDrawable;->pLedBar:Landroid/graphics/Paint;

    invoke-virtual {p1, v6, v0, v0, v5}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1250
    return-void
.end method

.method private drawNeonBg(Landroid/graphics/Canvas;FF)V
    .registers 25
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "w"  # F
    .param p3, "h"  # F

    .line 524
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 526
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v3, Landroid/graphics/RadialGradient;

    const v10, 0x3e19999a  # 0.15f

    mul-float v4, p2, v10

    const v11, 0x3e4ccccd  # 0.2f

    mul-float v5, p3, v11

    const v12, 0x3ee66666  # 0.45f

    mul-float v6, p2, v12

    .line 528
    const/16 v7, 0x46

    const/16 v8, 0x7c

    const/16 v9, 0x3a

    const/16 v13, 0xed

    invoke-static {v7, v8, v9, v13}, Landroid/graphics/Color;->argb(IIII)I

    move-result v7

    const/4 v13, 0x0

    const/4 v14, 0x6

    const/16 v15, 0x10

    invoke-static {v13, v14, v13, v15}, Landroid/graphics/Color;->argb(IIII)I

    move-result v8

    filled-new-array {v7, v8}, [I

    move-result-object v7

    const/4 v8, 0x2

    const/4 v9, 0x2

    new-array v8, v9, [F

    fill-array-data v8, :array_31e

    const/16 v16, 0x2

    sget-object v9, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/4 v10, 0x2

    const v17, 0x3e19999a  # 0.15f

    invoke-direct/range {v3 .. v9}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 526
    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 530
    mul-float v2, p2, v17

    mul-float v11, v11, p3

    mul-float v12, v12, p2

    iget-object v3, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v11, v12, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 532
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v3, Landroid/graphics/RadialGradient;

    const v11, 0x3f59999a  # 0.85f

    mul-float v4, p2, v11

    const v12, 0x3e6147ae  # 0.22f

    mul-float v5, p3, v12

    const v16, 0x3ecccccd  # 0.4f

    mul-float v6, p2, v16

    .line 534
    const/16 v7, 0x41

    const/16 v8, 0xb6

    const/16 v9, 0xd4

    invoke-static {v7, v14, v8, v9}, Landroid/graphics/Color;->argb(IIII)I

    move-result v7

    const/16 v8, 0x1a

    const/16 v9, 0xd

    invoke-static {v13, v13, v9, v8}, Landroid/graphics/Color;->argb(IIII)I

    move-result v8

    filled-new-array {v7, v8}, [I

    move-result-object v7

    new-array v8, v10, [F

    fill-array-data v8, :array_326

    const/16 v17, 0xd

    sget-object v9, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/16 v11, 0xd

    const v18, 0x3f59999a  # 0.85f

    invoke-direct/range {v3 .. v9}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 532
    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 536
    mul-float v2, p2, v18

    mul-float v12, v12, p3

    mul-float v3, p2, v16

    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v12, v3, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 538
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v3, Landroid/graphics/RadialGradient;

    const v12, 0x3e3851ec  # 0.18f

    mul-float v4, p2, v12

    const v16, 0x3f47ae14  # 0.78f

    mul-float v5, p3, v16

    const v17, 0x3ec28f5c  # 0.38f

    mul-float v6, p2, v17

    .line 540
    const/16 v7, 0x3c

    const/16 v8, 0xec

    const/16 v9, 0x48

    const v18, 0x3e3851ec  # 0.18f

    const/16 v12, 0x99

    invoke-static {v7, v8, v9, v12}, Landroid/graphics/Color;->argb(IIII)I

    move-result v7

    invoke-static {v13, v14, v13, v15}, Landroid/graphics/Color;->argb(IIII)I

    move-result v8

    filled-new-array {v7, v8}, [I

    move-result-object v7

    new-array v8, v10, [F

    fill-array-data v8, :array_32e

    sget-object v9, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v3 .. v9}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 538
    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 542
    mul-float v12, p2, v18

    mul-float v2, p3, v16

    mul-float v3, p2, v17

    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v12, v2, v3, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 544
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v3, Landroid/graphics/RadialGradient;

    const v12, 0x3f51eb85  # 0.82f

    mul-float v4, p2, v12

    const v14, 0x3f4ccccd  # 0.8f

    mul-float v5, p3, v14

    const v15, 0x3eb851ec  # 0.36f

    mul-float v6, p2, v15

    .line 546
    const/16 v7, 0x37

    const/16 v8, 0x39

    const/16 v9, 0xff

    const v16, 0x3f51eb85  # 0.82f

    const/16 v12, 0x14

    invoke-static {v7, v8, v9, v12}, Landroid/graphics/Color;->argb(IIII)I

    move-result v7

    invoke-static {v13, v13, v11, v13}, Landroid/graphics/Color;->argb(IIII)I

    move-result v8

    filled-new-array {v7, v8}, [I

    move-result-object v7

    new-array v8, v10, [F

    fill-array-data v8, :array_336

    const/16 v11, 0xff

    sget-object v9, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v3 .. v9}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 544
    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 548
    mul-float v12, p2, v16

    mul-float v14, v14, p3

    mul-float v15, v15, p2

    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v12, v14, v15, v2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 549
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/4 v7, 0x0

    invoke-virtual {v2, v7}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 551
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 552
    const-wide/32 v2, 0x4e301c4a

    .line 553
    .local v2, "seed":J
    const/4 v4, 0x5

    new-array v4, v4, [[I

    const/16 v5, 0xab

    const/16 v6, 0xfc

    const/16 v8, 0xf0

    filled-new-array {v8, v5, v6}, [I

    move-result-object v5

    aput-object v5, v4, v13

    const/16 v5, 0xe8

    const/16 v6, 0xf9

    const/16 v8, 0x67

    filled-new-array {v8, v5, v6}, [I

    move-result-object v5

    const/4 v8, 0x1

    aput-object v5, v4, v8

    const/16 v5, 0x8b

    const/16 v6, 0xfa

    const/16 v9, 0xa7

    filled-new-array {v9, v5, v6}, [I

    move-result-object v5

    aput-object v5, v4, v10

    const/16 v5, 0x39

    const/16 v6, 0x14

    filled-new-array {v5, v11, v6}, [I

    move-result-object v5

    const/4 v6, 0x3

    aput-object v5, v4, v6

    const/16 v5, 0xcc

    const/16 v6, 0x15

    const/16 v9, 0xfa

    filled-new-array {v9, v5, v6}, [I

    move-result-object v5

    const/4 v6, 0x4

    aput-object v5, v4, v6

    move-object v9, v4

    .line 556
    .local v9, "neonCols":[[I
    const/4 v4, 0x0

    move v12, v4

    .local v12, "i":I
    :goto_177
    const/16 v4, 0x16

    if-ge v12, v4, :cond_231

    .line 557
    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v2

    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v4

    mul-float v4, v4, p3

    .line 558
    .local v4, "y":F
    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v2

    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v5

    mul-float v5, v5, p2

    const v6, 0x3e99999a  # 0.3f

    mul-float v5, v5, v6

    .line 559
    .local v5, "x1":F
    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v2

    const v6, 0x3f333333  # 0.7f

    mul-float v6, v6, p2

    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v14

    mul-float v14, v14, p2

    const v15, 0x3e99999a  # 0.3f

    mul-float v14, v14, v15

    add-float/2addr v6, v14

    .line 560
    .local v6, "x2":F
    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v2

    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v14

    array-length v15, v9

    int-to-float v15, v15

    mul-float v14, v14, v15

    float-to-int v14, v14

    .line 561
    .local v14, "ci":I
    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v2

    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v15

    const/high16 v16, 0x41b00000  # 22.0f

    mul-float v15, v15, v16

    float-to-int v15, v15

    add-int/lit8 v15, v15, 0xc

    .line 562
    .local v15, "alp":I
    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v2

    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v16

    const v17, 0x3f99999a  # 1.2f

    mul-float v16, v16, v17

    const/high16 v17, 0x3f000000  # 0.5f

    const/16 v18, 0x1

    add-float v8, v16, v17

    .line 563
    .local v8, "sw":F
    const/16 v16, 0x2

    array-length v10, v9

    rem-int v10, v14, v10

    aget-object v10, v9, v10

    .line 564
    .local v10, "c":[I
    const/16 v17, 0x0

    iget-object v13, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    aget v11, v10, v17

    aget v7, v10, v18

    aget v1, v10, v16

    invoke-static {v15, v11, v7, v1}, Landroid/graphics/Color;->argb(IIII)I

    move-result v1

    invoke-virtual {v13, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 565
    iget-object v1, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v8}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 566
    move-wide v1, v2

    move v3, v4

    move v4, v6

    .end local v2  # "seed":J
    .end local v6  # "x2":F
    .local v1, "seed":J
    .local v3, "y":F
    .local v4, "x2":F
    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    move-wide/from16 v19, v1

    move v2, v5

    .end local v1  # "seed":J
    .end local v5  # "x1":F
    .local v2, "x1":F
    .local v19, "seed":J
    move v5, v3

    move-object/from16 v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 567
    iget-object v1, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    div-int/lit8 v5, v15, 0x3

    aget v6, v10, v17

    aget v7, v10, v18

    aget v11, v10, v16

    invoke-static {v5, v6, v7, v11}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    invoke-virtual {v1, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 568
    iget-object v1, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/high16 v5, 0x40800000  # 4.0f

    mul-float v5, v5, v8

    invoke-virtual {v1, v5}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 569
    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    move v5, v3

    move-object/from16 v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 556
    .end local v2  # "x1":F
    .end local v3  # "y":F
    .end local v4  # "x2":F
    .end local v8  # "sw":F
    .end local v10  # "c":[I
    .end local v14  # "ci":I
    .end local v15  # "alp":I
    add-int/lit8 v12, v12, 0x1

    move-wide/from16 v2, v19

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/4 v10, 0x2

    const/16 v11, 0xff

    const/4 v13, 0x0

    goto/16 :goto_177

    .end local v19  # "seed":J
    .local v2, "seed":J
    :cond_231
    const/16 v16, 0x2

    const/16 v17, 0x0

    const/16 v18, 0x1

    .line 572
    .end local v12  # "i":I
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 573
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_23f
    const/16 v5, 0xa0

    if-ge v4, v5, :cond_281

    .line 574
    array-length v5, v9

    rem-int v5, v4, v5

    .line 575
    .local v5, "ci":I
    aget-object v6, v9, v5

    .line 576
    .local v6, "c":[I
    iget-object v7, v0, Landroid/ext/BackgroundDrawable;->ptA:[I

    aget v7, v7, v4

    int-to-float v7, v7

    const v8, 0x3f0ccccd  # 0.55f

    mul-float v7, v7, v8

    float-to-int v7, v7

    .line 577
    .local v7, "a":I
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    aget v10, v6, v17

    aget v11, v6, v18

    aget v12, v6, v16

    invoke-static {v7, v10, v11, v12}, Landroid/graphics/Color;->argb(IIII)I

    move-result v10

    invoke-virtual {v8, v10}, Landroid/graphics/Paint;->setColor(I)V

    .line 578
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->blurSoft:Landroid/graphics/BlurMaskFilter;

    invoke-virtual {v8, v10}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 579
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->ptX:[F

    aget v8, v8, v4

    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->ptY:[F

    aget v10, v10, v4

    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->ptR:[F

    aget v11, v11, v4

    const/high16 v12, 0x3f400000  # 0.75f

    mul-float v11, v11, v12

    iget-object v12, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    invoke-virtual {v1, v8, v10, v11, v12}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 573
    .end local v5  # "ci":I
    .end local v6  # "c":[I
    .end local v7  # "a":I
    add-int/lit8 v4, v4, 0x1

    goto :goto_23f

    .line 581
    .end local v4  # "i":I
    :cond_281
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 583
    const/4 v4, 0x0

    .restart local v4  # "i":I
    :goto_288
    const/16 v5, 0xc8

    if-ge v4, v5, :cond_30f

    .line 584
    array-length v5, v9

    rem-int v5, v4, v5

    .line 585
    .restart local v5  # "ci":I
    aget-object v6, v9, v5

    .line 586
    .restart local v6  # "c":[I
    iget-object v7, v0, Landroid/ext/BackgroundDrawable;->sA:[I

    aget v7, v7, v4

    int-to-double v7, v7

    int-to-double v10, v4

    const-wide v12, 0x3ff4cccccccccccdL  # 1.3

    mul-double v10, v10, v12

    .line 587
    invoke-static {v10, v11}, Ljava/lang/Math;->sin(D)D

    move-result-wide v10

    const-wide/high16 v12, 0x3ff0000000000000L  # 1.0

    add-double/2addr v10, v12

    const-wide/high16 v12, 0x3fe0000000000000L  # 0.5

    mul-double v10, v10, v12

    const-wide/high16 v12, 0x4000000000000000L  # 2.0

    div-double/2addr v10, v12

    const-wide/high16 v12, 0x3fd0000000000000L  # 0.25

    add-double/2addr v10, v12

    mul-double v7, v7, v10

    double-to-int v7, v7

    .line 586
    const/16 v11, 0xff

    invoke-static {v11, v7}, Ljava/lang/Math;->min(II)I

    move-result v7

    const/4 v8, 0x0

    invoke-static {v8, v7}, Ljava/lang/Math;->max(II)I

    move-result v7

    .line 589
    .local v7, "alpha":I
    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->sLayer:[I

    aget v10, v10, v4

    const/4 v12, 0x2

    if-ne v10, v12, :cond_2df

    .line 590
    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    aget v13, v6, v8

    aget v8, v6, v18

    aget v14, v6, v12

    invoke-static {v7, v13, v8, v14}, Landroid/graphics/Color;->argb(IIII)I

    move-result v8

    invoke-virtual {v10, v8}, Landroid/graphics/Paint;->setColor(I)V

    .line 591
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->blurStarNear:Landroid/graphics/BlurMaskFilter;

    invoke-virtual {v8, v10}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    const/16 v16, 0x2

    const/16 v17, 0x0

    goto :goto_2fa

    .line 593
    :cond_2df
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    div-int/lit8 v10, v7, 0x2

    const/16 v17, 0x0

    aget v12, v6, v17

    aget v13, v6, v18

    const/16 v16, 0x2

    aget v14, v6, v16

    invoke-static {v10, v12, v13, v14}, Landroid/graphics/Color;->argb(IIII)I

    move-result v10

    invoke-virtual {v8, v10}, Landroid/graphics/Paint;->setColor(I)V

    .line 594
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    const/4 v10, 0x0

    invoke-virtual {v8, v10}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 596
    :goto_2fa
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->sX:[F

    aget v8, v8, v4

    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->sY:[F

    aget v10, v10, v4

    iget-object v12, v0, Landroid/ext/BackgroundDrawable;->sR:[F

    aget v12, v12, v4

    iget-object v13, v0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    invoke-virtual {v1, v8, v10, v12, v13}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 583
    .end local v5  # "ci":I
    .end local v6  # "c":[I
    .end local v7  # "alpha":I
    add-int/lit8 v4, v4, 0x1

    goto/16 :goto_288

    .line 598
    .end local v4  # "i":I
    :cond_30f
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 599
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 600
    return-void

    nop

    :array_31e
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data

    :array_326
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data

    :array_32e
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data

    :array_336
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data
.end method

.method private drawOrchidBg(Landroid/graphics/Canvas;FF)V
    .registers 25
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "w"  # F
    .param p3, "h"  # F

    .line 396
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 397
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v3, Landroid/graphics/RadialGradient;

    const v10, 0x3e8f5c29  # 0.28f

    mul-float v4, p2, v10

    const v11, 0x3ec28f5c  # 0.38f

    mul-float v5, p3, v11

    const v12, 0x3ed70a3d  # 0.42f

    mul-float v6, p2, v12

    .line 398
    const/16 v7, 0x41

    const/16 v8, 0x93

    const/16 v9, 0x33

    const/16 v13, 0xea

    invoke-static {v7, v8, v9, v13}, Landroid/graphics/Color;->argb(IIII)I

    move-result v7

    const/4 v14, 0x0

    invoke-static {v14, v8, v9, v13}, Landroid/graphics/Color;->argb(IIII)I

    move-result v8

    filled-new-array {v7, v8}, [I

    move-result-object v7

    const/4 v13, 0x2

    new-array v8, v13, [F

    fill-array-data v8, :array_1ae

    sget-object v9, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v3 .. v9}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 397
    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 400
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/16 v3, 0xff

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 401
    mul-float v10, v10, p2

    mul-float v2, p3, v11

    mul-float v4, p2, v12

    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v10, v2, v4, v5}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 403
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v4, Landroid/graphics/RadialGradient;

    const v15, 0x3f3851ec  # 0.72f

    mul-float v5, p2, v15

    const v16, 0x3f1eb852  # 0.62f

    mul-float v6, p3, v16

    mul-float v7, p2, v11

    .line 404
    const/16 v8, 0x37

    const/16 v9, 0xf4

    const/16 v10, 0x3f

    const v17, 0x3ec28f5c  # 0.38f

    const/16 v11, 0x5e

    invoke-static {v8, v9, v10, v11}, Landroid/graphics/Color;->argb(IIII)I

    move-result v8

    invoke-static {v14, v9, v10, v11}, Landroid/graphics/Color;->argb(IIII)I

    move-result v9

    filled-new-array {v8, v9}, [I

    move-result-object v8

    new-array v9, v13, [F

    fill-array-data v9, :array_1b6

    sget-object v10, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v4 .. v10}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 403
    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 406
    mul-float v15, v15, p2

    mul-float v2, p3, v16

    mul-float v11, p2, v17

    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v15, v2, v11, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 407
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/4 v4, 0x0

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 409
    const/4 v2, 0x3

    new-array v2, v2, [[I

    const/16 v5, 0xf0

    const/16 v6, 0xab

    const/16 v7, 0xfc

    filled-new-array {v5, v6, v7}, [I

    move-result-object v8

    aput-object v8, v2, v14

    const/16 v8, 0xa4

    const/16 v9, 0xaf

    const/16 v10, 0xfd

    filled-new-array {v10, v8, v9}, [I

    move-result-object v8

    const/4 v9, 0x1

    aput-object v8, v2, v9

    const/16 v8, 0x79

    const/16 v10, 0xf9

    const/16 v11, 0xe8

    filled-new-array {v11, v8, v10}, [I

    move-result-object v8

    aput-object v8, v2, v13

    .line 410
    .local v2, "petalColors":[[I
    const/4 v8, 0x0

    .local v8, "i":I
    :goto_c1
    const/16 v10, 0xa0

    if-ge v8, v10, :cond_130

    .line 411
    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->ptX:[F

    aget v10, v10, v8

    .local v10, "cx":F
    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->ptY:[F

    aget v11, v11, v8

    .line 412
    .local v11, "cy":F
    iget-object v15, v0, Landroid/ext/BackgroundDrawable;->ptR:[F

    aget v15, v15, v8

    const/high16 v16, 0x40e00000  # 7.0f

    mul-float v15, v15, v16

    const/high16 v16, 0x40800000  # 4.0f

    add-float v15, v15, v16

    .line 413
    .local v15, "rW":F
    mul-float v16, v15, v12

    .line 414
    .local v16, "rH":F
    const/16 v17, 0x1

    iget-object v9, v0, Landroid/ext/BackgroundDrawable;->ptExtra:[F

    aget v9, v9, v8

    const/high16 v18, 0x43b40000  # 360.0f

    mul-float v9, v9, v18

    .line 415
    .local v9, "ang":F
    rem-int/lit8 v18, v8, 0x3

    aget-object v18, v2, v18

    .line 416
    .local v18, "pc":[I
    iget-object v12, v0, Landroid/ext/BackgroundDrawable;->ptA:[I

    aget v12, v12, v8

    int-to-float v12, v12

    const v19, 0x3ecccccd  # 0.4f

    mul-float v12, v12, v19

    float-to-int v12, v12

    .line 417
    .local v12, "a":I
    const/16 v19, 0x2

    iget-object v13, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/16 v20, 0x0

    aget v14, v18, v20

    aget v3, v18, v17

    aget v4, v18, v19

    invoke-static {v12, v14, v3, v4}, Landroid/graphics/Color;->argb(IIII)I

    move-result v3

    invoke-virtual {v13, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 418
    invoke-virtual {v1}, Landroid/graphics/Canvas;->save()I

    .line 419
    invoke-virtual {v1, v9, v10, v11}, Landroid/graphics/Canvas;->rotate(FFF)V

    .line 420
    new-instance v3, Landroid/graphics/RectF;

    sub-float v4, v10, v15

    sub-float v13, v11, v16

    add-float v14, v10, v15

    add-float v5, v11, v16

    invoke-direct {v3, v4, v13, v14, v5}, Landroid/graphics/RectF;-><init>(FFFF)V

    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v3, v4}, Landroid/graphics/Canvas;->drawOval(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 421
    invoke-virtual {v1}, Landroid/graphics/Canvas;->restore()V

    .line 410
    .end local v9  # "ang":F
    .end local v10  # "cx":F
    .end local v11  # "cy":F
    .end local v12  # "a":I
    .end local v15  # "rW":F
    .end local v16  # "rH":F
    .end local v18  # "pc":[I
    add-int/lit8 v8, v8, 0x1

    const/16 v3, 0xff

    const/4 v4, 0x0

    const/16 v5, 0xf0

    const/4 v9, 0x1

    const v12, 0x3ed70a3d  # 0.42f

    const/4 v13, 0x2

    const/4 v14, 0x0

    goto :goto_c1

    .line 424
    .end local v8  # "i":I
    :cond_130
    const/4 v3, 0x0

    .local v3, "i":I
    :goto_131
    const/16 v4, 0xa0

    if-ge v3, v4, :cond_16a

    .line 425
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->ptA:[I

    aget v5, v5, v3

    int-to-float v5, v5

    const v8, 0x3f59999a  # 0.85f

    mul-float v5, v5, v8

    float-to-int v5, v5

    const/16 v8, 0xf0

    invoke-static {v5, v8, v6, v7}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 426
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->blurSoft:Landroid/graphics/BlurMaskFilter;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 427
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->ptX:[F

    aget v4, v4, v3

    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->ptY:[F

    aget v5, v5, v3

    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->ptR:[F

    aget v8, v8, v3

    const/high16 v9, 0x3f000000  # 0.5f

    mul-float v8, v8, v9

    iget-object v9, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    invoke-virtual {v1, v4, v5, v8, v9}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 424
    add-int/lit8 v3, v3, 0x3

    goto :goto_131

    .line 429
    .end local v3  # "i":I
    :cond_16a
    iget-object v3, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    const/4 v4, 0x0

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 431
    const/4 v3, 0x0

    .restart local v3  # "i":I
    :goto_171
    const/16 v4, 0xc8

    if-ge v3, v4, :cond_1ac

    .line 432
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->sA:[I

    aget v4, v4, v3

    int-to-float v4, v4

    const v5, 0x3e99999a  # 0.3f

    mul-float v4, v4, v5

    float-to-int v4, v4

    .line 433
    .local v4, "alpha":I
    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    const/16 v6, 0xff

    const/16 v8, 0xf0

    invoke-static {v4, v6, v8, v6}, Landroid/graphics/Color;->argb(IIII)I

    move-result v7

    invoke-virtual {v5, v7}, Landroid/graphics/Paint;->setColor(I)V

    .line 434
    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    const/4 v7, 0x0

    invoke-virtual {v5, v7}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 435
    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->sX:[F

    aget v5, v5, v3

    iget-object v9, v0, Landroid/ext/BackgroundDrawable;->sY:[F

    aget v9, v9, v3

    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->sR:[F

    aget v10, v10, v3

    const v11, 0x3f19999a  # 0.6f

    mul-float v10, v10, v11

    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    invoke-virtual {v1, v5, v9, v10, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 431
    .end local v4  # "alpha":I
    add-int/lit8 v3, v3, 0x2

    goto :goto_171

    .line 437
    .end local v3  # "i":I
    :cond_1ac
    return-void

    nop

    :array_1ae
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data

    :array_1b6
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data
.end method

.method private drawOuterFrame(Landroid/graphics/Canvas;Landroid/graphics/Path;Landroid/graphics/Path;FF)V
    .registers 15
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "outerPath"  # Landroid/graphics/Path;
    .param p3, "innerPath"  # Landroid/graphics/Path;
    .param p4, "w"  # F
    .param p5, "h"  # F

    .line 1217
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pGlowOut:Landroid/graphics/Paint;

    invoke-virtual {p1, p2, v0}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 1218
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pGlowIn:Landroid/graphics/Paint;

    invoke-virtual {p1, p2, v0}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 1220
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pMainBorder:Landroid/graphics/Paint;

    new-instance v1, Landroid/graphics/LinearGradient;

    const/high16 v2, 0x3f000000  # 0.5f

    mul-float v3, p5, v2

    mul-float v5, p5, v2

    iget v2, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_2:I

    iget v4, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_1:I

    iget v6, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_3:I

    iget v7, p0, Landroid/ext/BackgroundDrawable;->COL_MAIN_GRAD_2:I

    filled-new-array {v2, v4, v6, v7}, [I

    move-result-object v6

    const/4 v2, 0x4

    new-array v7, v2, [F

    fill-array-data v7, :array_66

    sget-object v8, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/4 v2, 0x0

    move v4, p4

    .end local p4  # "w":F
    .local v4, "w":F
    invoke-direct/range {v1 .. v8}, Landroid/graphics/LinearGradient;-><init>(FFFF[I[FLandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 1225
    iget-object p4, p0, Landroid/ext/BackgroundDrawable;->pMainBorder:Landroid/graphics/Paint;

    invoke-virtual {p1, p2, p4}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 1226
    iget-object p4, p0, Landroid/ext/BackgroundDrawable;->pMainBorder:Landroid/graphics/Paint;

    const/4 v0, 0x0

    invoke-virtual {p4, v0}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 1228
    iget-object p4, p0, Landroid/ext/BackgroundDrawable;->pInnerRim:Landroid/graphics/Paint;

    invoke-virtual {p1, p3, p4}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 1229
    invoke-direct {p0, p1, v4, p5}, Landroid/ext/BackgroundDrawable;->drawLedBars(Landroid/graphics/Canvas;FF)V

    .line 1231
    const p4, 0x404ccccd  # 3.2f

    .line 1232
    .local p4, "dotR":F
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pCornerDot:Landroid/graphics/Paint;

    const/high16 v1, 0x40600000  # 3.5f

    invoke-virtual {p1, v1, v1, p4, v0}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1233
    sub-float v0, v4, v1

    iget-object v2, p0, Landroid/ext/BackgroundDrawable;->pCornerDot:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, p4, v2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1234
    sub-float v0, p5, v1

    iget-object v2, p0, Landroid/ext/BackgroundDrawable;->pCornerDot:Landroid/graphics/Paint;

    invoke-virtual {p1, v1, v0, p4, v2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1235
    sub-float v0, v4, v1

    sub-float v1, p5, v1

    iget-object v2, p0, Landroid/ext/BackgroundDrawable;->pCornerDot:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, p4, v2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1236
    return-void

    nop

    :array_66
    .array-data 4
        0x0
        0x3e99999a  # 0.3f
        0x3f333333  # 0.7f
        0x3f800000  # 1.0f
    .end array-data
.end method

.method private drawScanLines(Landroid/graphics/Canvas;FF)V
    .registers 11
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "w"  # F
    .param p3, "h"  # F

    .line 1171
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pScan:Landroid/graphics/Paint;

    iget v1, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_OUT:I

    .line 1172
    invoke-static {v1}, Landroid/graphics/Color;->red(I)I

    move-result v1

    iget v2, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_OUT:I

    .line 1173
    invoke-static {v2}, Landroid/graphics/Color;->green(I)I

    move-result v2

    iget v3, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_OUT:I

    .line 1174
    invoke-static {v3}, Landroid/graphics/Color;->blue(I)I

    move-result v3

    .line 1171
    const/16 v4, 0xa

    invoke-static {v4, v1, v2, v3}, Landroid/graphics/Color;->argb(IIII)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 1175
    const/4 v0, 0x0

    move v3, v0

    .local v3, "y":F
    :goto_1f
    cmpg-float v0, v3, p3

    if-gez v0, :cond_31

    .line 1176
    const/4 v2, 0x0

    iget-object v6, p0, Landroid/ext/BackgroundDrawable;->pScan:Landroid/graphics/Paint;

    move v5, v3

    move-object v1, p1

    move v4, p2

    .end local p1  # "canvas":Landroid/graphics/Canvas;
    .end local p2  # "w":F
    .local v1, "canvas":Landroid/graphics/Canvas;
    .local v4, "w":F
    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1175
    const/high16 p1, 0x40a00000  # 5.0f

    add-float/2addr v3, p1

    move-object p1, v1

    goto :goto_1f

    .line 1177
    .end local v1  # "canvas":Landroid/graphics/Canvas;
    .end local v3  # "y":F
    .end local v4  # "w":F
    .restart local p1  # "canvas":Landroid/graphics/Canvas;
    .restart local p2  # "w":F
    :cond_31
    return-void
.end method

.method private drawSnowBg(Landroid/graphics/Canvas;FF)V
    .registers 23
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "w"  # F
    .param p3, "h"  # F

    .line 1066
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1067
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v3, Landroid/graphics/RadialGradient;

    const/high16 v10, 0x3f000000  # 0.5f

    mul-float v4, p2, v10

    const v11, 0x3ee66666  # 0.45f

    mul-float v5, p3, v11

    const v12, 0x3f0ccccd  # 0.55f

    mul-float v6, p2, v12

    .line 1069
    const/16 v7, 0x46

    const/16 v8, 0x38

    const/16 v9, 0xbd

    const/16 v13, 0xf8

    invoke-static {v7, v8, v9, v13}, Landroid/graphics/Color;->argb(IIII)I

    move-result v7

    const/4 v13, 0x0

    const/16 v14, 0xf

    const/16 v15, 0x17

    const/16 v8, 0x2a

    invoke-static {v13, v14, v15, v8}, Landroid/graphics/Color;->argb(IIII)I

    move-result v9

    filled-new-array {v7, v9}, [I

    move-result-object v7

    const/4 v9, 0x2

    const/16 v16, 0x2a

    new-array v8, v9, [F

    fill-array-data v8, :array_152

    const/16 v17, 0x2

    sget-object v9, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/16 v10, 0x2a

    const/4 v11, 0x2

    const v16, 0x3ee66666  # 0.45f

    const/high16 v18, 0x3f000000  # 0.5f

    invoke-direct/range {v3 .. v9}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 1067
    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 1071
    mul-float v2, p2, v18

    mul-float v3, p3, v16

    mul-float v12, v12, p2

    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v3, v12, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1073
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v3, Landroid/graphics/RadialGradient;

    const v12, 0x3f47ae14  # 0.78f

    mul-float v4, p2, v12

    const v16, 0x3f3851ec  # 0.72f

    mul-float v5, p3, v16

    const v17, 0x3e8f5c29  # 0.28f

    mul-float v6, p2, v17

    .line 1075
    const/16 v7, 0x32

    const/16 v8, 0xba

    const/16 v9, 0xe6

    const v18, 0x3f47ae14  # 0.78f

    const/16 v12, 0xfd

    invoke-static {v7, v8, v9, v12}, Landroid/graphics/Color;->argb(IIII)I

    move-result v7

    invoke-static {v13, v14, v15, v10}, Landroid/graphics/Color;->argb(IIII)I

    move-result v10

    filled-new-array {v7, v10}, [I

    move-result-object v7

    new-array v10, v11, [F

    fill-array-data v10, :array_15a

    const/16 v11, 0xe6

    sget-object v9, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    move-object v8, v10

    const/16 v10, 0xba

    invoke-direct/range {v3 .. v9}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 1073
    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 1077
    mul-float v2, p2, v18

    mul-float v3, p3, v16

    mul-float v4, p2, v17

    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v3, v4, v5}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1078
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 1081
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1082
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_b2
    const/16 v4, 0xa0

    const v5, 0x3ecccccd  # 0.4f

    const/16 v6, 0xff

    if-ge v2, v4, :cond_107

    .line 1083
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->ptX:[F

    aget v4, v4, v2

    .local v4, "cx":F
    iget-object v7, v0, Landroid/ext/BackgroundDrawable;->ptY:[F

    aget v7, v7, v2

    .line 1084
    .local v7, "cy":F
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->ptR:[F

    aget v8, v8, v2

    const/high16 v9, 0x40400000  # 3.0f

    mul-float v8, v8, v9

    const/high16 v9, 0x3fc00000  # 1.5f

    add-float/2addr v8, v9

    .line 1085
    .local v8, "r":F
    iget-object v9, v0, Landroid/ext/BackgroundDrawable;->ptA:[I

    aget v9, v9, v2

    int-to-float v9, v9

    const v13, 0x3eb33333  # 0.35f

    mul-float v9, v9, v13

    float-to-int v9, v9

    .line 1086
    .local v9, "a":I
    iget-object v13, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-static {v9, v10, v11, v12}, Landroid/graphics/Color;->argb(IIII)I

    move-result v14

    invoke-virtual {v13, v14}, Landroid/graphics/Paint;->setColor(I)V

    .line 1087
    iget-object v13, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v4, v7, v8, v13}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1088
    iget-object v13, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    div-int/lit8 v14, v9, 0x2

    invoke-static {v14, v6, v6, v6}, Landroid/graphics/Color;->argb(IIII)I

    move-result v6

    invoke-virtual {v13, v6}, Landroid/graphics/Paint;->setColor(I)V

    .line 1089
    const v6, 0x3e99999a  # 0.3f

    mul-float v13, v8, v6

    sub-float v13, v4, v13

    mul-float v6, v6, v8

    sub-float v6, v7, v6

    mul-float v5, v5, v8

    iget-object v14, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v13, v6, v5, v14}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1082
    .end local v4  # "cx":F
    .end local v7  # "cy":F
    .end local v8  # "r":F
    .end local v9  # "a":I
    add-int/lit8 v2, v2, 0x3

    goto :goto_b2

    .line 1092
    .end local v2  # "i":I
    :cond_107
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1093
    const/4 v2, 0x0

    .restart local v2  # "i":I
    :goto_10f
    const/16 v4, 0xc8

    if-ge v2, v4, :cond_144

    .line 1094
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->sA:[I

    aget v4, v4, v2

    int-to-float v4, v4

    mul-float v4, v4, v5

    float-to-int v4, v4

    .line 1095
    .local v4, "a":I
    iget-object v7, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    invoke-static {v4, v6, v6, v6}, Landroid/graphics/Color;->argb(IIII)I

    move-result v8

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setColor(I)V

    .line 1096
    iget-object v7, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->blurSoft:Landroid/graphics/BlurMaskFilter;

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 1097
    iget-object v7, v0, Landroid/ext/BackgroundDrawable;->sX:[F

    aget v7, v7, v2

    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->sY:[F

    aget v8, v8, v2

    iget-object v9, v0, Landroid/ext/BackgroundDrawable;->sR:[F

    aget v9, v9, v2

    const v10, 0x3f4ccccd  # 0.8f

    mul-float v9, v9, v10

    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    invoke-virtual {v1, v7, v8, v9, v10}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1093
    .end local v4  # "a":I
    add-int/lit8 v2, v2, 0x2

    goto :goto_10f

    .line 1099
    .end local v2  # "i":I
    :cond_144
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 1100
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1101
    return-void

    nop

    :array_152
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data

    :array_15a
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data
.end method

.method private drawSpaceBg(Landroid/graphics/Canvas;FF)V
    .registers 17
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "w"  # F
    .param p3, "h"  # F

    .line 358
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pZone:Landroid/graphics/Paint;

    new-instance v1, Landroid/graphics/RadialGradient;

    const v8, 0x3df5c28f  # 0.12f

    mul-float v2, p2, v8

    const v9, 0x3e99999a  # 0.3f

    mul-float v3, p3, v9

    const v10, 0x3ec28f5c  # 0.38f

    mul-float v4, p2, v10

    .line 360
    const/16 v5, 0x5a

    const/4 v11, 0x0

    const/16 v6, 0x1e

    const/16 v7, 0x50

    invoke-static {v5, v11, v6, v7}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    iget v6, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_1:I

    filled-new-array {v5, v6, v11}, [I

    move-result-object v5

    const/4 v12, 0x3

    new-array v6, v12, [F

    fill-array-data v6, :array_10c

    sget-object v7, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v1 .. v7}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 358
    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 363
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pZone:Landroid/graphics/Paint;

    const/16 v1, 0x6e

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 364
    mul-float v8, v8, p2

    mul-float v9, v9, p3

    mul-float v10, v10, p2

    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pZone:Landroid/graphics/Paint;

    invoke-virtual {p1, v8, v9, v10, v0}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 366
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pZone:Landroid/graphics/Paint;

    new-instance v1, Landroid/graphics/RadialGradient;

    const v8, 0x3f3851ec  # 0.72f

    mul-float v2, p2, v8

    const v9, 0x3f147ae1  # 0.58f

    mul-float v3, p3, v9

    const v10, 0x3ea3d70a  # 0.32f

    mul-float v4, p2, v10

    .line 368
    const/16 v5, 0x64

    const/16 v6, 0x3c

    invoke-static {v5, v6, v11, v5}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    iget v6, p0, Landroid/ext/BackgroundDrawable;->COL_ACCENT_2:I

    filled-new-array {v5, v6, v11}, [I

    move-result-object v5

    new-array v6, v12, [F

    fill-array-data v6, :array_116

    sget-object v7, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v1 .. v7}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 366
    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 371
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pZone:Landroid/graphics/Paint;

    const/16 v1, 0x55

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 372
    mul-float v8, v8, p2

    mul-float v9, v9, p3

    mul-float v10, v10, p2

    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pZone:Landroid/graphics/Paint;

    invoke-virtual {p1, v8, v9, v10, v0}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 373
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pZone:Landroid/graphics/Paint;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 374
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pZone:Landroid/graphics/Paint;

    const/16 v2, 0xff

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 376
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_92
    const/16 v3, 0xc8

    if-ge v0, v3, :cond_106

    .line 377
    iget-object v3, p0, Landroid/ext/BackgroundDrawable;->sA:[I

    aget v3, v3, v0

    int-to-double v3, v3

    int-to-double v5, v0

    const-wide v7, 0x3fef0a3d70a3d70aL  # 0.97

    mul-double v5, v5, v7

    const-wide/16 v7, 0x0

    add-double/2addr v5, v7

    .line 378
    invoke-static {v5, v6}, Ljava/lang/Math;->sin(D)D

    move-result-wide v5

    const-wide/high16 v7, 0x3ff0000000000000L  # 1.0

    add-double/2addr v5, v7

    const-wide v7, 0x3fe4cccccccccccdL  # 0.65

    mul-double v5, v5, v7

    const-wide/high16 v7, 0x4000000000000000L  # 2.0

    div-double/2addr v5, v7

    const-wide v7, 0x3fd6666666666666L  # 0.35

    add-double/2addr v5, v7

    mul-double v3, v3, v5

    double-to-int v3, v3

    .line 377
    invoke-static {v2, v3}, Ljava/lang/Math;->min(II)I

    move-result v3

    invoke-static {v11, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    .line 380
    .local v3, "alpha":I
    iget-object v4, p0, Landroid/ext/BackgroundDrawable;->sLayer:[I

    aget v4, v4, v0

    const/4 v5, 0x2

    if-ne v4, v5, :cond_e4

    .line 381
    iget-object v4, p0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    const/16 v5, 0xdc

    const/16 v6, 0xbe

    invoke-static {v3, v5, v6, v2}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 382
    iget-object v4, p0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    iget-object v5, p0, Landroid/ext/BackgroundDrawable;->blurStarNear:Landroid/graphics/BlurMaskFilter;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    goto :goto_f2

    .line 384
    :cond_e4
    iget-object v4, p0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    invoke-static {v3, v2, v2, v2}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 385
    iget-object v4, p0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    invoke-virtual {v4, v1}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 387
    :goto_f2
    iget-object v4, p0, Landroid/ext/BackgroundDrawable;->sX:[F

    aget v4, v4, v0

    iget-object v5, p0, Landroid/ext/BackgroundDrawable;->sY:[F

    aget v5, v5, v0

    iget-object v6, p0, Landroid/ext/BackgroundDrawable;->sR:[F

    aget v6, v6, v0

    iget-object v7, p0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    invoke-virtual {p1, v4, v5, v6, v7}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 376
    .end local v3  # "alpha":I
    add-int/lit8 v0, v0, 0x1

    goto :goto_92

    .line 389
    .end local v0  # "i":I
    :cond_106
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 390
    return-void

    :array_10c
    .array-data 4
        0x0
        0x3ee66666  # 0.45f
        0x3f800000  # 1.0f
    .end array-data

    :array_116
    .array-data 4
        0x0
        0x3ecccccd  # 0.4f
        0x3f800000  # 1.0f
    .end array-data
.end method

.method private drawStormBg(Landroid/graphics/Canvas;FF)V
    .registers 23
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "w"  # F
    .param p3, "h"  # F

    .line 1107
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1108
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v3, Landroid/graphics/RadialGradient;

    const/high16 v10, 0x3f000000  # 0.5f

    mul-float v4, p2, v10

    mul-float v5, p3, v10

    const v11, 0x3f19999a  # 0.6f

    mul-float v6, p2, v11

    .line 1110
    const/16 v7, 0x3c

    const/16 v8, 0x4b

    const/16 v9, 0x55

    const/16 v12, 0x63

    invoke-static {v7, v8, v9, v12}, Landroid/graphics/Color;->argb(IIII)I

    move-result v7

    const/4 v12, 0x0

    const/16 v13, 0x1a

    invoke-static {v12, v13, v13, v13}, Landroid/graphics/Color;->argb(IIII)I

    move-result v8

    filled-new-array {v7, v8}, [I

    move-result-object v7

    const/4 v14, 0x2

    new-array v8, v14, [F

    fill-array-data v8, :array_17c

    sget-object v9, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v3 .. v9}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 1108
    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 1112
    mul-float v2, p2, v10

    mul-float v3, p3, v10

    mul-float v4, p2, v11

    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v3, v4, v5}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1114
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v3, Landroid/graphics/RadialGradient;

    const v15, 0x3e99999a  # 0.3f

    mul-float v4, p2, v15

    const/high16 v16, 0x3e800000  # 0.25f

    mul-float v5, p3, v16

    const v17, 0x3eb33333  # 0.35f

    mul-float v6, p2, v17

    .line 1116
    const/16 v7, 0x32

    const/16 v8, 0x6b

    const/16 v9, 0x72

    const/high16 v18, 0x3f000000  # 0.5f

    const/16 v10, 0x80

    invoke-static {v7, v8, v9, v10}, Landroid/graphics/Color;->argb(IIII)I

    move-result v7

    invoke-static {v12, v13, v13, v13}, Landroid/graphics/Color;->argb(IIII)I

    move-result v8

    filled-new-array {v7, v8}, [I

    move-result-object v7

    new-array v8, v14, [F

    fill-array-data v8, :array_184

    sget-object v9, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v3 .. v9}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 1114
    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 1118
    mul-float v2, p2, v15

    mul-float v3, p3, v16

    mul-float v4, p2, v17

    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v3, v4, v5}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1119
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 1122
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1123
    const-wide/32 v4, 0x5700c101

    .line 1124
    .local v4, "seed":J
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_9b
    const/4 v6, 0x5

    if-ge v2, v6, :cond_128

    .line 1125
    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v4

    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v6

    mul-float v6, v6, v11

    const v7, 0x3e4ccccd  # 0.2f

    add-float/2addr v6, v7

    mul-float v6, v6, p2

    .line 1126
    .local v6, "x1":F
    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v4

    const v7, 0x3dcccccd  # 0.1f

    mul-float v7, v7, p3

    .line 1127
    .local v7, "y1":F
    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v4

    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v8

    mul-float v8, v8, v18

    add-float/2addr v8, v15

    mul-float v8, v8, p3

    .line 1128
    .local v8, "y2":F
    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v4

    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v9

    const/high16 v10, 0x41900000  # 18.0f

    mul-float v9, v9, v10

    float-to-int v9, v9

    add-int/lit8 v9, v9, 0x8

    .line 1130
    .local v9, "alp":I
    new-instance v10, Landroid/graphics/Path;

    invoke-direct {v10}, Landroid/graphics/Path;-><init>()V

    .line 1131
    .local v10, "bolt":Landroid/graphics/Path;
    invoke-virtual {v10, v6, v7}, Landroid/graphics/Path;->moveTo(FF)V

    .line 1132
    move v12, v6

    .line 1133
    .local v12, "cx":F
    move v13, v7

    .local v13, "y":F
    :goto_dd
    cmpg-float v14, v13, v8

    if-gez v14, :cond_104

    .line 1134
    move/from16 v16, v12

    .end local v12  # "cx":F
    .local v16, "cx":F
    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v11

    invoke-direct {v0, v11, v12}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v11

    sub-float v11, v11, v18

    mul-float v11, v11, p2

    const v12, 0x3da3d70a  # 0.08f

    mul-float v11, v11, v12

    add-float v12, v16, v11

    .line 1135
    .end local v16  # "cx":F
    .restart local v12  # "cx":F
    invoke-virtual {v10, v12, v13}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1136
    invoke-direct {v0, v4, v5}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v4

    .line 1133
    const/high16 v11, 0x41a00000  # 20.0f

    add-float/2addr v13, v11

    const v11, 0x3f19999a  # 0.6f

    goto :goto_dd

    :cond_104
    move/from16 v16, v12

    .line 1138
    .end local v12  # "cx":F
    .end local v13  # "y":F
    .restart local v16  # "cx":F
    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/16 v12, 0xe7

    const/16 v13, 0xeb

    const/16 v14, 0xe5

    invoke-static {v9, v14, v12, v13}, Landroid/graphics/Color;->argb(IIII)I

    move-result v12

    invoke-virtual {v11, v12}, Landroid/graphics/Paint;->setColor(I)V

    .line 1139
    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/high16 v12, 0x3fc00000  # 1.5f

    invoke-virtual {v11, v12}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1140
    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v10, v11}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 1124
    .end local v6  # "x1":F
    .end local v7  # "y1":F
    .end local v8  # "y2":F
    .end local v9  # "alp":I
    .end local v10  # "bolt":Landroid/graphics/Path;
    .end local v16  # "cx":F
    add-int/lit8 v2, v2, 0x1

    const v11, 0x3f19999a  # 0.6f

    goto/16 :goto_9b

    .line 1143
    .end local v2  # "i":I
    :cond_128
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    sget-object v6, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v6}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1144
    const/4 v2, 0x0

    .restart local v2  # "i":I
    :goto_130
    const/16 v6, 0xa0

    if-ge v2, v6, :cond_16e

    .line 1145
    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->ptA:[I

    aget v6, v6, v2

    int-to-float v6, v6

    const v7, 0x3ee66666  # 0.45f

    mul-float v6, v6, v7

    float-to-int v6, v6

    .line 1146
    .local v6, "a":I
    iget-object v7, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    const/16 v8, 0xa3

    const/16 v9, 0xaf

    const/16 v10, 0x9c

    invoke-static {v6, v10, v8, v9}, Landroid/graphics/Color;->argb(IIII)I

    move-result v8

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setColor(I)V

    .line 1147
    iget-object v7, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->blurSoft:Landroid/graphics/BlurMaskFilter;

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 1148
    iget-object v7, v0, Landroid/ext/BackgroundDrawable;->ptX:[F

    aget v7, v7, v2

    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->ptY:[F

    aget v8, v8, v2

    iget-object v9, v0, Landroid/ext/BackgroundDrawable;->ptR:[F

    aget v9, v9, v2

    const v10, 0x3f666666  # 0.9f

    mul-float v9, v9, v10

    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    invoke-virtual {v1, v7, v8, v9, v10}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1144
    .end local v6  # "a":I
    add-int/lit8 v2, v2, 0x2

    goto :goto_130

    .line 1150
    .end local v2  # "i":I
    :cond_16e
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 1151
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1152
    return-void

    nop

    :array_17c
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data

    :array_184
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data
.end method

.method private drawTeaBg(Landroid/graphics/Canvas;FF)V
    .registers 34
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "w"  # F
    .param p3, "h"  # F

    .line 688
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 689
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v3, Landroid/graphics/RadialGradient;

    const/high16 v10, 0x3f000000  # 0.5f

    mul-float v4, p2, v10

    const v11, 0x3f0ccccd  # 0.55f

    mul-float v5, p3, v11

    mul-float v6, p2, v11

    .line 691
    const/16 v7, 0x4b

    const/16 v8, 0x9a

    const/16 v9, 0x34

    const/16 v12, 0x12

    invoke-static {v7, v8, v9, v12}, Landroid/graphics/Color;->argb(IIII)I

    move-result v7

    const/16 v8, 0x1c

    const/4 v9, 0x6

    const/4 v12, 0x0

    invoke-static {v12, v8, v9, v12}, Landroid/graphics/Color;->argb(IIII)I

    move-result v8

    filled-new-array {v7, v8}, [I

    move-result-object v7

    const/4 v13, 0x2

    new-array v8, v13, [F

    fill-array-data v8, :array_38e

    sget-object v9, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v3 .. v9}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 689
    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 693
    mul-float v2, p2, v10

    mul-float v3, p3, v11

    mul-float v4, p2, v11

    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v3, v4, v5}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 695
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v3, Landroid/graphics/RadialGradient;

    const v14, 0x3e6147ae  # 0.22f

    mul-float v4, p2, v14

    const v15, 0x3e99999a  # 0.3f

    mul-float v5, p3, v15

    const v16, 0x3ea3d70a  # 0.32f

    mul-float v6, p2, v16

    .line 697
    const/16 v7, 0x37

    const/16 v8, 0xc8

    const/16 v9, 0x5a

    const v17, 0x3f0ccccd  # 0.55f

    const/16 v11, 0x1e

    invoke-static {v7, v8, v9, v11}, Landroid/graphics/Color;->argb(IIII)I

    move-result v7

    const v18, 0x3e6147ae  # 0.22f

    const/16 v14, 0x8

    invoke-static {v12, v11, v14, v12}, Landroid/graphics/Color;->argb(IIII)I

    move-result v8

    filled-new-array {v7, v8}, [I

    move-result-object v7

    new-array v8, v13, [F

    fill-array-data v8, :array_396

    const/16 v20, 0x5a

    sget-object v9, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/16 v15, 0xc8

    const v21, 0x3e99999a  # 0.3f

    invoke-direct/range {v3 .. v9}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 695
    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 699
    mul-float v2, p2, v18

    mul-float v3, p3, v21

    mul-float v4, p2, v16

    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v3, v4, v5}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 701
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v3, Landroid/graphics/RadialGradient;

    const v16, 0x3f47ae14  # 0.78f

    mul-float v4, p2, v16

    const v18, 0x3f3851ec  # 0.72f

    mul-float v5, p3, v18

    const v19, 0x3e8f5c29  # 0.28f

    mul-float v6, p2, v19

    .line 703
    const/16 v7, 0x30

    const/16 v8, 0xea

    const/16 v9, 0x58

    const/16 v15, 0xc

    invoke-static {v7, v8, v9, v15}, Landroid/graphics/Color;->argb(IIII)I

    move-result v7

    const/16 v8, 0x14

    const/4 v9, 0x5

    invoke-static {v12, v8, v9, v12}, Landroid/graphics/Color;->argb(IIII)I

    move-result v8

    filled-new-array {v7, v8}, [I

    move-result-object v7

    new-array v8, v13, [F

    fill-array-data v8, :array_39e

    sget-object v9, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v3 .. v9}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 701
    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 705
    mul-float v2, p2, v16

    mul-float v3, p3, v18

    mul-float v4, p2, v19

    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v3, v4, v5}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 706
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/4 v7, 0x0

    invoke-virtual {v2, v7}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 709
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 710
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_e9
    const/16 v3, 0x32

    const v4, 0x3d75c28f  # 0.06f

    if-ge v2, v14, :cond_12d

    .line 711
    int-to-float v5, v2

    const v6, 0x3d54fdf4  # 0.052f

    mul-float v5, v5, v6

    add-float/2addr v5, v4

    mul-float v5, v5, p2

    .line 712
    .local v5, "r":F
    mul-int/lit8 v4, v2, 0x4

    rsub-int/lit8 v4, v4, 0x24

    invoke-static {v12, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    .line 713
    .local v4, "a":I
    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/16 v8, 0xd2

    const/16 v9, 0x6e

    invoke-static {v4, v8, v9, v3}, Landroid/graphics/Color;->argb(IIII)I

    move-result v3

    invoke-virtual {v6, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 714
    iget-object v3, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    int-to-float v6, v2

    const v8, 0x3e051eb8  # 0.13f

    mul-float v6, v6, v8

    const v8, 0x3fa66666  # 1.3f

    sub-float/2addr v8, v6

    invoke-static {v10, v8}, Ljava/lang/Math;->max(FF)F

    move-result v6

    invoke-virtual {v3, v6}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 715
    mul-float v3, p2, v10

    mul-float v6, p3, v17

    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v3, v6, v5, v8}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 710
    .end local v4  # "a":I
    .end local v5  # "r":F
    add-int/lit8 v2, v2, 0x1

    goto :goto_e9

    .line 719
    .end local v2  # "i":I
    :cond_12d
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 720
    const-wide/32 v5, 0x74ea5501

    .line 721
    .local v5, "seed":J
    const/4 v2, 0x0

    move-wide v8, v5

    .end local v5  # "seed":J
    .restart local v2  # "i":I
    .local v8, "seed":J
    :goto_139
    const/4 v5, 0x7

    if-ge v2, v5, :cond_217

    .line 722
    invoke-direct {v0, v8, v9}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v5

    .end local v8  # "seed":J
    .restart local v5  # "seed":J
    invoke-direct {v0, v5, v6}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v8

    mul-float v8, v8, v10

    const/high16 v9, 0x3e800000  # 0.25f

    add-float/2addr v8, v9

    mul-float v8, v8, p2

    .line 723
    .local v8, "cx":F
    invoke-direct {v0, v5, v6}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v5

    invoke-direct {v0, v5, v6}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v9

    const v14, 0x3c656042  # 0.014f

    mul-float v9, v9, v14

    const v14, 0x3c343958  # 0.011f

    add-float/2addr v9, v14

    mul-float v9, v9, p2

    .line 724
    .local v9, "amp":F
    invoke-direct {v0, v5, v6}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v5

    invoke-direct {v0, v5, v6}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v14

    const/high16 v15, 0x41800000  # 16.0f

    mul-float v14, v14, v15

    float-to-int v14, v14

    add-int/lit8 v14, v14, 0xd

    .line 725
    .local v14, "alp":I
    invoke-direct {v0, v5, v6}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v5

    invoke-direct {v0, v5, v6}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v15

    const v16, 0x3f333333  # 0.7f

    mul-float v15, v15, v16

    const v16, 0x3f8ccccd  # 1.1f

    add-float v15, v15, v16

    .line 726
    .local v15, "sw":F
    const v16, 0x3ef5c28f  # 0.48f

    const v17, 0x3d75c28f  # 0.06f

    mul-float v4, p3, v16

    .line 727
    .local v4, "startY":F
    mul-float v16, p3, v17

    .line 728
    .local v16, "endY":F
    new-instance v18, Landroid/graphics/Path;

    invoke-direct/range {v18 .. v18}, Landroid/graphics/Path;-><init>()V

    move-object/from16 v19, v18

    .line 729
    .local v19, "steam":Landroid/graphics/Path;
    move-object/from16 v12, v19

    const/16 v18, 0x0

    .end local v19  # "steam":Landroid/graphics/Path;
    .local v12, "steam":Landroid/graphics/Path;
    invoke-virtual {v12, v8, v4}, Landroid/graphics/Path;->moveTo(FF)V

    .line 730
    const/16 v19, 0x1

    move/from16 v13, v19

    const/16 v22, 0x2

    .local v13, "s":I
    :goto_19d
    const/16 v7, 0xa

    if-gt v13, v7, :cond_1eb

    .line 731
    int-to-float v7, v13

    const/high16 v23, 0x41200000  # 10.0f

    div-float v7, v7, v23

    .line 732
    .local v7, "t":F
    sub-float v23, v16, v4

    mul-float v23, v23, v7

    add-float v10, v4, v23

    .line 733
    .local v10, "y":F
    move/from16 v25, v4

    .end local v4  # "startY":F
    .local v25, "startY":F
    float-to-double v3, v7

    const-wide v26, 0x400921fb54442d18L  # Math.PI

    mul-double v3, v3, v26

    const-wide v26, 0x400199999999999aL  # 2.2

    mul-double v3, v3, v26

    move-object/from16 v27, v12

    .end local v12  # "steam":Landroid/graphics/Path;
    .local v27, "steam":Landroid/graphics/Path;
    int-to-double v11, v2

    const-wide v28, 0x3ff0cccccccccccdL  # 1.05

    mul-double v11, v11, v28

    add-double/2addr v3, v11

    invoke-static {v3, v4}, Ljava/lang/Math;->sin(D)D

    move-result-wide v3

    double-to-float v3, v3

    mul-float v3, v3, v9

    const v4, 0x3eb33333  # 0.35f

    mul-float v4, v4, v7

    const/high16 v11, 0x3f800000  # 1.0f

    sub-float/2addr v11, v4

    mul-float v3, v3, v11

    add-float/2addr v3, v8

    .line 734
    .local v3, "x":F
    move-object/from16 v12, v27

    .end local v27  # "steam":Landroid/graphics/Path;
    .restart local v12  # "steam":Landroid/graphics/Path;
    invoke-virtual {v12, v3, v10}, Landroid/graphics/Path;->lineTo(FF)V

    .line 730
    .end local v3  # "x":F
    .end local v7  # "t":F
    .end local v10  # "y":F
    add-int/lit8 v13, v13, 0x1

    move/from16 v4, v25

    const/16 v3, 0x32

    const/4 v7, 0x0

    const/high16 v10, 0x3f000000  # 0.5f

    const/16 v11, 0x1e

    goto :goto_19d

    .end local v25  # "startY":F
    .restart local v4  # "startY":F
    :cond_1eb
    move/from16 v25, v4

    .line 736
    .end local v4  # "startY":F
    .end local v13  # "s":I
    .restart local v25  # "startY":F
    iget-object v3, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/16 v4, 0xdc

    const/16 v7, 0xbe

    const/16 v10, 0xff

    invoke-static {v14, v10, v4, v7}, Landroid/graphics/Color;->argb(IIII)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 737
    iget-object v3, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v3, v15}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 738
    iget-object v3, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v12, v3}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 721
    .end local v8  # "cx":F
    .end local v9  # "amp":F
    .end local v12  # "steam":Landroid/graphics/Path;
    .end local v14  # "alp":I
    .end local v15  # "sw":F
    .end local v16  # "endY":F
    .end local v25  # "startY":F
    add-int/lit8 v2, v2, 0x1

    const/16 v3, 0x32

    const v4, 0x3d75c28f  # 0.06f

    const/4 v7, 0x0

    const/high16 v10, 0x3f000000  # 0.5f

    const/16 v11, 0x1e

    const/4 v12, 0x0

    const/4 v13, 0x2

    move-wide v8, v5

    goto/16 :goto_139

    .end local v5  # "seed":J
    .local v8, "seed":J
    :cond_217
    const/16 v18, 0x0

    const/16 v22, 0x2

    .line 742
    .end local v2  # "i":I
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 743
    const/4 v2, 0x4

    new-array v2, v2, [[I

    const/16 v3, 0xb4

    const/16 v4, 0x50

    const/16 v5, 0x1e

    filled-new-array {v3, v4, v5}, [I

    move-result-object v3

    aput-object v3, v2, v18

    const/16 v3, 0x64

    const/16 v4, 0x28

    const/16 v15, 0xc8

    filled-new-array {v15, v3, v4}, [I

    move-result-object v3

    const/4 v7, 0x1

    aput-object v3, v2, v7

    const/16 v3, 0xdc

    const/16 v4, 0x78

    const/16 v5, 0x32

    filled-new-array {v3, v4, v5}, [I

    move-result-object v3

    aput-object v3, v2, v22

    const/16 v3, 0x3c

    const/16 v4, 0x19

    const/16 v10, 0xa0

    filled-new-array {v10, v3, v4}, [I

    move-result-object v3

    const/4 v4, 0x3

    aput-object v3, v2, v4

    move-object v11, v2

    .line 744
    .local v11, "leafCols":[[I
    const/4 v2, 0x0

    move v12, v2

    .local v12, "i":I
    :goto_25a
    if-ge v12, v10, :cond_2fc

    .line 745
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->ptX:[F

    aget v13, v2, v12

    .local v13, "cx":F
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->ptY:[F

    aget v3, v2, v12

    .line 746
    .local v3, "cy":F
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->ptR:[F

    aget v2, v2, v12

    const/high16 v4, 0x40a00000  # 5.0f

    mul-float v2, v2, v4

    const v4, 0x40333333  # 2.8f

    add-float v14, v2, v4

    .line 747
    .local v14, "rW":F
    mul-float v15, v14, v21

    .line 748
    .local v15, "rH":F
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->ptExtra:[F

    aget v2, v2, v12

    const/high16 v4, 0x43340000  # 180.0f

    mul-float v2, v2, v4

    const/high16 v4, 0x42b40000  # 90.0f

    sub-float/2addr v2, v4

    .line 749
    .local v2, "ang":F
    array-length v4, v11

    rem-int v4, v12, v4

    aget-object v16, v11, v4

    .line 750
    .local v16, "lc":[I
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->ptA:[I

    aget v4, v4, v12

    int-to-float v4, v4

    const v5, 0x3eae147b  # 0.34f

    mul-float v4, v4, v5

    float-to-int v4, v4

    .line 751
    .local v4, "a":I
    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    aget v6, v16, v18

    const/16 v17, 0x1

    aget v7, v16, v17

    aget v10, v16, v22

    invoke-static {v4, v6, v7, v10}, Landroid/graphics/Color;->argb(IIII)I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setColor(I)V

    .line 752
    invoke-virtual {v1}, Landroid/graphics/Canvas;->save()I

    .line 753
    invoke-virtual {v1, v2, v13, v3}, Landroid/graphics/Canvas;->rotate(FFF)V

    .line 754
    new-instance v5, Landroid/graphics/RectF;

    sub-float v6, v13, v14

    sub-float v7, v3, v15

    add-float v10, v13, v14

    move/from16 v25, v2

    .end local v2  # "ang":F
    .local v25, "ang":F
    add-float v2, v3, v15

    invoke-direct {v5, v6, v7, v10, v2}, Landroid/graphics/RectF;-><init>(FFFF)V

    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v5, v2}, Landroid/graphics/Canvas;->drawOval(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 756
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    div-int/lit8 v5, v4, 0x2

    const/16 v6, 0xf0

    const/16 v7, 0xa0

    const/16 v10, 0x5a

    invoke-static {v5, v6, v7, v10}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    invoke-virtual {v2, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 757
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 758
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/high16 v5, 0x3f000000  # 0.5f

    invoke-virtual {v2, v5}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 759
    const/high16 v2, 0x3f400000  # 0.75f

    mul-float v2, v2, v14

    sub-float v2, v13, v2

    const/high16 v5, 0x3f400000  # 0.75f

    mul-float v5, v5, v14

    add-float/2addr v5, v13

    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    move v7, v4

    move v4, v5

    .end local v4  # "a":I
    .local v7, "a":I
    move v5, v3

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 760
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 761
    invoke-virtual {v1}, Landroid/graphics/Canvas;->restore()V

    .line 744
    .end local v3  # "cy":F
    .end local v7  # "a":I
    .end local v13  # "cx":F
    .end local v14  # "rW":F
    .end local v15  # "rH":F
    .end local v16  # "lc":[I
    .end local v25  # "ang":F
    add-int/lit8 v12, v12, 0x1

    const/4 v7, 0x1

    const/16 v10, 0xa0

    goto/16 :goto_25a

    .line 765
    .end local v12  # "i":I
    :cond_2fc
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 766
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_304
    const/16 v7, 0xa0

    if-ge v2, v7, :cond_341

    .line 767
    iget-object v3, v0, Landroid/ext/BackgroundDrawable;->ptA:[I

    aget v3, v3, v2

    int-to-float v3, v3

    const/high16 v24, 0x3f000000  # 0.5f

    mul-float v3, v3, v24

    float-to-int v3, v3

    .line 768
    .local v3, "a":I
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    const/16 v5, 0x92

    const/16 v6, 0x3c

    const/16 v10, 0xfb

    invoke-static {v3, v10, v5, v6}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 769
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->blurSoft:Landroid/graphics/BlurMaskFilter;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 770
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->ptX:[F

    aget v4, v4, v2

    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->ptY:[F

    aget v5, v5, v2

    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->ptR:[F

    aget v6, v6, v2

    const v10, 0x3f333333  # 0.7f

    mul-float v6, v6, v10

    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    invoke-virtual {v1, v4, v5, v6, v10}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 766
    .end local v3  # "a":I
    add-int/lit8 v2, v2, 0x2

    goto :goto_304

    .line 772
    .end local v2  # "i":I
    :cond_341
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 775
    const/4 v2, 0x0

    .restart local v2  # "i":I
    :goto_348
    const/16 v15, 0xc8

    if-ge v2, v15, :cond_385

    .line 776
    iget-object v3, v0, Landroid/ext/BackgroundDrawable;->sA:[I

    aget v3, v3, v2

    int-to-float v3, v3

    const v4, 0x3e75c28f  # 0.24f

    mul-float v3, v3, v4

    float-to-int v3, v3

    .line 777
    .restart local v3  # "a":I
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    const/16 v5, 0xba

    const/16 v6, 0x74

    const/16 v7, 0xfd

    invoke-static {v3, v7, v5, v6}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 778
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 779
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->sX:[F

    aget v4, v4, v2

    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->sY:[F

    aget v6, v6, v2

    iget-object v7, v0, Landroid/ext/BackgroundDrawable;->sR:[F

    aget v7, v7, v2

    const v10, 0x3f19999a  # 0.6f

    mul-float v7, v7, v10

    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->pStar:Landroid/graphics/Paint;

    invoke-virtual {v1, v4, v6, v7, v10}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 775
    .end local v3  # "a":I
    add-int/lit8 v2, v2, 0x3

    goto :goto_348

    .line 781
    .end local v2  # "i":I
    :cond_385
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 782
    return-void

    nop

    :array_38e
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data

    :array_396
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data

    :array_39e
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data
.end method

.method private drawTechBg(Landroid/graphics/Canvas;FF)V
    .registers 32
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "w"  # F
    .param p3, "h"  # F

    .line 865
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v7, p2

    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 866
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v8, Landroid/graphics/RadialGradient;

    const/high16 v15, 0x3f000000  # 0.5f

    mul-float v9, v7, v15

    mul-float v10, p3, v15

    const v3, 0x3f0f5c29  # 0.56f

    mul-float v11, v7, v3

    .line 868
    const/16 v3, 0x3e

    const/4 v4, 0x2

    const/16 v5, 0x84

    const/16 v6, 0xc7

    invoke-static {v3, v4, v5, v6}, Landroid/graphics/Color;->argb(IIII)I

    move-result v3

    const/16 v5, 0x8

    const/16 v6, 0x14

    const/4 v12, 0x0

    invoke-static {v12, v12, v5, v6}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    filled-new-array {v3, v5}, [I

    move-result-object v3

    new-array v13, v4, [F

    fill-array-data v13, :array_5be

    sget-object v14, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    move-object v12, v3

    const/4 v3, 0x0

    invoke-direct/range {v8 .. v14}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 866
    invoke-virtual {v2, v8}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 870
    mul-float v2, v7, v15

    mul-float v5, p3, v15

    const v6, 0x3f0f5c29  # 0.56f

    mul-float v6, v6, v7

    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v5, v6, v8}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 872
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v8, Landroid/graphics/RadialGradient;

    const v16, 0x3e3851ec  # 0.18f

    mul-float v9, v7, v16

    const v5, 0x3e6147ae  # 0.22f

    mul-float v10, p3, v5

    const v17, 0x3e99999a  # 0.3f

    mul-float v11, v7, v17

    .line 874
    const/16 v6, 0x30

    const/16 v12, 0x22

    const/16 v13, 0xd3

    const/16 v14, 0xee

    invoke-static {v6, v12, v13, v14}, Landroid/graphics/Color;->argb(IIII)I

    move-result v6

    const v18, 0x3e6147ae  # 0.22f

    const/16 v5, 0xa

    const/16 v12, 0x19

    invoke-static {v3, v3, v5, v12}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    filled-new-array {v6, v5}, [I

    move-result-object v12

    const/16 v5, 0xd3

    new-array v13, v4, [F

    fill-array-data v13, :array_5c6

    const/16 v6, 0xee

    sget-object v14, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/16 v5, 0x22

    const/16 v6, 0xd3

    const/16 v15, 0xee

    const/high16 v19, 0x3f000000  # 0.5f

    invoke-direct/range {v8 .. v14}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 872
    invoke-virtual {v2, v8}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 876
    mul-float v2, v7, v16

    mul-float v8, p3, v18

    mul-float v9, v7, v17

    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v8, v9, v10}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 878
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    new-instance v8, Landroid/graphics/RadialGradient;

    const v20, 0x3f51eb85  # 0.82f

    mul-float v9, v7, v20

    const v21, 0x3f47ae14  # 0.78f

    mul-float v10, p3, v21

    const v11, 0x3e8f5c29  # 0.28f

    mul-float v11, v11, v7

    .line 880
    const/16 v12, 0x28

    const/16 v13, 0xe

    const/16 v14, 0xa5

    const/16 v5, 0xe9

    invoke-static {v12, v13, v14, v5}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    const/16 v12, 0x8

    const/16 v13, 0x14

    invoke-static {v3, v3, v12, v13}, Landroid/graphics/Color;->argb(IIII)I

    move-result v12

    filled-new-array {v5, v12}, [I

    move-result-object v12

    new-array v13, v4, [F

    fill-array-data v13, :array_5ce

    sget-object v14, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v8 .. v14}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    .line 878
    invoke-virtual {v2, v8}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 882
    mul-float v2, v7, v20

    mul-float v5, p3, v21

    const v8, 0x3e8f5c29  # 0.28f

    mul-float v8, v8, v7

    iget-object v9, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v5, v8, v9}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 883
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/4 v5, 0x0

    invoke-virtual {v2, v5}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 886
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 887
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_f7
    const/16 v5, 0xe

    const/4 v8, 0x4

    if-ge v2, v5, :cond_137

    .line 888
    int-to-float v5, v2

    const v9, 0x3d851eb8  # 0.065f

    mul-float v5, v5, v9

    const v9, 0x3d3851ec  # 0.045f

    add-float/2addr v5, v9

    mul-float v5, v5, v7

    .line 889
    .local v5, "r":F
    mul-int/lit8 v9, v2, 0x3

    rsub-int/lit8 v9, v9, 0x2d

    invoke-static {v8, v9}, Ljava/lang/Math;->max(II)I

    move-result v8

    .line 890
    .local v8, "a":I
    iget-object v9, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/16 v10, 0x22

    invoke-static {v8, v10, v6, v15}, Landroid/graphics/Color;->argb(IIII)I

    move-result v11

    invoke-virtual {v9, v11}, Landroid/graphics/Paint;->setColor(I)V

    .line 891
    iget-object v9, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    rem-int/lit8 v11, v2, 0x3

    if-nez v11, :cond_125

    const v11, 0x3fb33333  # 1.4f

    goto :goto_128

    :cond_125
    const v11, 0x3f333333  # 0.7f

    :goto_128
    invoke-virtual {v9, v11}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 892
    mul-float v9, v7, v19

    mul-float v11, p3, v19

    iget-object v12, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v9, v11, v5, v12}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 887
    .end local v5  # "r":F
    .end local v8  # "a":I
    add-int/lit8 v2, v2, 0x1

    goto :goto_f7

    :cond_137
    const/16 v10, 0x22

    .line 896
    .end local v2  # "i":I
    mul-float v2, v7, v16

    mul-float v5, p3, v18

    const v9, 0x3dcccccd  # 0.1f

    mul-float v9, v9, v7

    const/4 v11, 0x3

    new-array v12, v11, [F

    aput v2, v12, v3

    const/4 v13, 0x1

    aput v5, v12, v13

    aput v9, v12, v4

    mul-float v2, v7, v20

    mul-float v5, p3, v18

    const v9, 0x3da3d70a  # 0.08f

    mul-float v9, v9, v7

    new-array v14, v11, [F

    aput v2, v14, v3

    aput v5, v14, v13

    aput v9, v14, v4

    mul-float v2, v7, v16

    mul-float v5, p3, v21

    const v9, 0x3db851ec  # 0.09f

    mul-float v9, v9, v7

    const/16 v18, 0x0

    new-array v3, v11, [F

    aput v2, v3, v18

    aput v5, v3, v13

    aput v9, v3, v4

    mul-float v2, v7, v20

    mul-float v21, v21, p3

    const v5, 0x3d8f5c29  # 0.07f

    mul-float v5, v5, v7

    new-array v9, v11, [F

    aput v2, v9, v18

    aput v21, v9, v13

    aput v5, v9, v4

    mul-float v2, v7, v19

    const v5, 0x3df5c28f  # 0.12f

    mul-float v5, v5, p3

    const v20, 0x3d75c28f  # 0.06f

    mul-float v20, v20, v7

    const/16 v21, 0x2

    new-array v4, v11, [F

    aput v2, v4, v18

    aput v5, v4, v13

    aput v20, v4, v21

    mul-float v2, v7, v19

    const v5, 0x3f6147ae  # 0.88f

    mul-float v5, v5, p3

    const v20, 0x3d75c28f  # 0.06f

    mul-float v20, v20, v7

    const/16 v22, 0x4

    new-array v8, v11, [F

    aput v2, v8, v18

    aput v5, v8, v13

    aput v20, v8, v21

    const/4 v2, 0x6

    new-array v2, v2, [[F

    aput-object v12, v2, v18

    aput-object v14, v2, v13

    aput-object v3, v2, v21

    aput-object v9, v2, v11

    aput-object v4, v2, v22

    const/4 v3, 0x5

    aput-object v8, v2, v3

    move-object v8, v2

    .line 904
    .local v8, "miniCores":[[F
    array-length v2, v8

    const/4 v12, 0x0

    :goto_1c0
    const/16 v9, 0xf8

    const/16 v14, 0xbd

    const/16 v3, 0x38

    if-ge v12, v2, :cond_23c

    aget-object v20, v8, v12

    .line 905
    .local v20, "core":[F
    aget v10, v20, v18

    const/16 v23, 0x1

    .local v10, "cx":F
    aget v13, v20, v23

    .local v13, "cy":F
    aget v24, v20, v21

    .line 906
    .local v24, "maxR":F
    const/16 v25, 0x0

    move/from16 v15, v25

    .local v15, "i":I
    :goto_1d6
    const/4 v4, 0x5

    if-ge v15, v4, :cond_20b

    .line 907
    int-to-float v4, v15

    const v26, 0x3e4ccccd  # 0.2f

    mul-float v4, v4, v26

    add-float v4, v4, v26

    mul-float v4, v4, v24

    .line 908
    .local v4, "r":F
    mul-int/lit8 v26, v15, 0x6

    rsub-int/lit8 v5, v26, 0x23

    invoke-static {v11, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    .line 909
    .local v5, "a":I
    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-static {v5, v3, v14, v9}, Landroid/graphics/Color;->argb(IIII)I

    move-result v6

    invoke-virtual {v11, v6}, Landroid/graphics/Paint;->setColor(I)V

    .line 910
    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    if-nez v15, :cond_1fb

    const/high16 v11, 0x3f800000  # 1.0f

    goto :goto_1fd

    :cond_1fb
    const/high16 v11, 0x3f000000  # 0.5f

    :goto_1fd
    invoke-virtual {v6, v11}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 911
    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v10, v13, v4, v6}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 906
    .end local v4  # "r":F
    .end local v5  # "a":I
    add-int/lit8 v15, v15, 0x1

    const/16 v6, 0xd3

    const/4 v11, 0x3

    goto :goto_1d6

    .line 914
    .end local v15  # "i":I
    :cond_20b
    iget-object v3, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 915
    iget-object v3, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/16 v4, 0x46

    const/16 v5, 0xfc

    const/16 v6, 0x7d

    const/16 v11, 0xd3

    invoke-static {v4, v6, v11, v5}, Landroid/graphics/Color;->argb(IIII)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 916
    const/high16 v3, 0x40200000  # 2.5f

    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v10, v13, v3, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 917
    iget-object v3, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 904
    .end local v10  # "cx":F
    .end local v13  # "cy":F
    .end local v20  # "core":[F
    .end local v24  # "maxR":F
    add-int/lit8 v12, v12, 0x1

    const/16 v6, 0xd3

    const/16 v10, 0x22

    const/4 v11, 0x3

    const/4 v13, 0x1

    const/16 v15, 0xee

    goto :goto_1c0

    .line 921
    :cond_23c
    const/16 v5, 0xfc

    const/16 v6, 0x7d

    const/16 v11, 0xd3

    const/16 v23, 0x1

    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 922
    const-wide/32 v12, 0x7ec31ca1

    .line 923
    .local v12, "seed":J
    const/4 v2, 0x0

    move v10, v2

    .local v10, "i":I
    :goto_250
    const/16 v2, 0x20

    if-ge v10, v2, :cond_39f

    .line 924
    invoke-direct {v0, v12, v13}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v12

    invoke-direct {v0, v12, v13}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v2

    mul-float v2, v2, v7

    .line 925
    .local v2, "x1":F
    invoke-direct {v0, v12, v13}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v12

    invoke-direct {v0, v12, v13}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v4

    mul-float v4, v4, p3

    .line 926
    .local v4, "y1":F
    invoke-direct {v0, v12, v13}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v12

    invoke-direct {v0, v12, v13}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v15

    mul-float v15, v15, v16

    const v20, 0x3d23d70a  # 0.04f

    add-float v15, v15, v20

    mul-float v15, v15, v7

    .line 927
    .local v15, "len":F
    invoke-direct {v0, v12, v13}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v12

    invoke-direct {v0, v12, v13}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v20

    cmpl-float v20, v20, v19

    if-lez v20, :cond_288

    const/16 v20, 0x1

    goto :goto_28a

    :cond_288
    const/16 v20, 0x0

    .line 928
    .local v20, "horiz":Z
    :goto_28a
    invoke-direct {v0, v12, v13}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v12

    invoke-direct {v0, v12, v13}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v21

    const/high16 v24, 0x41c00000  # 24.0f

    mul-float v5, v21, v24

    float-to-int v5, v5

    add-int/lit8 v5, v5, 0xc

    .line 929
    .local v5, "alp":I
    invoke-direct {v0, v12, v13}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v12

    invoke-direct {v0, v12, v13}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v21

    const v24, 0x3f666666  # 0.9f

    mul-float v21, v21, v24

    add-float v11, v21, v19

    .line 930
    .local v11, "sw":F
    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-static {v5, v3, v14, v9}, Landroid/graphics/Color;->argb(IIII)I

    move-result v1

    invoke-virtual {v6, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 931
    iget-object v1, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v11}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 932
    const/16 v1, 0xff

    if-eqz v20, :cond_322

    .line 933
    move v3, v4

    const/16 v6, 0x38

    .end local v4  # "y1":F
    .local v3, "y1":F
    add-float v4, v2, v15

    const/16 v21, 0x38

    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    move/from16 v24, v5

    .end local v5  # "alp":I
    .local v24, "alp":I
    move v5, v3

    move-object/from16 v1, p1

    const/16 v9, 0xff

    const/16 v21, 0x0

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 934
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 935
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    add-int/lit8 v5, v24, 0x19

    invoke-static {v9, v5}, Ljava/lang/Math;->min(II)I

    move-result v5

    const/16 v6, 0xf8

    const/16 v9, 0x38

    invoke-static {v5, v9, v14, v6}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 936
    add-float v4, v2, v15

    const v5, 0x400ccccd  # 2.2f

    mul-float v5, v5, v11

    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v4, v3, v5, v6}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 938
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    add-int/lit8 v5, v24, 0x28

    const/16 v6, 0xff

    invoke-static {v6, v5}, Ljava/lang/Math;->min(II)I

    move-result v5

    const/16 v6, 0xfc

    const/16 v9, 0x7d

    const/16 v14, 0xd3

    invoke-static {v5, v9, v14, v6}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 939
    add-float v4, v2, v15

    const v5, 0x3f666666  # 0.9f

    mul-float v5, v5, v11

    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v4, v3, v5, v6}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 940
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    move-object/from16 v27, v8

    goto :goto_38b

    .line 942
    .end local v3  # "y1":F
    .end local v24  # "alp":I
    .restart local v4  # "y1":F
    .restart local v5  # "alp":I
    :cond_322
    move-object/from16 v1, p1

    move v3, v4

    move/from16 v24, v5

    const/16 v9, 0x7d

    const/16 v14, 0xd3

    const/16 v21, 0x0

    .end local v4  # "y1":F
    .end local v5  # "alp":I
    .restart local v3  # "y1":F
    .restart local v24  # "alp":I
    add-float v5, v3, v15

    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    move v4, v2

    move-object/from16 v27, v8

    const/16 v8, 0xfc

    .end local v8  # "miniCores":[[F
    .local v27, "miniCores":[[F
    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 943
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 944
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    add-int/lit8 v5, v24, 0x19

    const/16 v6, 0xff

    invoke-static {v6, v5}, Ljava/lang/Math;->min(II)I

    move-result v5

    const/16 v6, 0xf8

    const/16 v8, 0xbd

    const/16 v9, 0x38

    invoke-static {v5, v9, v8, v6}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 945
    add-float v4, v3, v15

    const v5, 0x400ccccd  # 2.2f

    mul-float v5, v5, v11

    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v4, v5, v6}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 946
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    add-int/lit8 v5, v24, 0x28

    const/16 v6, 0xff

    invoke-static {v6, v5}, Ljava/lang/Math;->min(II)I

    move-result v5

    const/16 v6, 0xfc

    const/16 v9, 0x7d

    invoke-static {v5, v9, v14, v6}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 947
    add-float v4, v3, v15

    const v5, 0x3f666666  # 0.9f

    mul-float v5, v5, v11

    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v4, v5, v6}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 948
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 923
    .end local v2  # "x1":F
    .end local v3  # "y1":F
    .end local v11  # "sw":F
    .end local v15  # "len":F
    .end local v20  # "horiz":Z
    .end local v24  # "alp":I
    :goto_38b
    add-int/lit8 v10, v10, 0x1

    move-object/from16 v8, v27

    const/16 v3, 0x38

    const/16 v5, 0xfc

    const/16 v6, 0x7d

    const/16 v9, 0xf8

    const/16 v11, 0xd3

    const/16 v14, 0xbd

    const/16 v18, 0x0

    goto/16 :goto_250

    .end local v27  # "miniCores":[[F
    .restart local v8  # "miniCores":[[F
    :cond_39f
    move-object/from16 v27, v8

    const/16 v14, 0xd3

    .line 953
    .end local v8  # "miniCores":[[F
    .end local v10  # "i":I
    .restart local v27  # "miniCores":[[F
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 954
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_3ab
    const/16 v3, 0xa0

    if-ge v2, v3, :cond_42f

    .line 955
    iget-object v3, v0, Landroid/ext/BackgroundDrawable;->ptX:[F

    aget v3, v3, v2

    .local v3, "cx":F
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->ptY:[F

    aget v4, v4, v2

    .line 956
    .local v4, "cy":F
    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->ptR:[F

    aget v5, v5, v2

    const v6, 0x40266666  # 2.6f

    mul-float v5, v5, v6

    const/high16 v6, 0x40000000  # 2.0f

    add-float/2addr v5, v6

    .line 957
    .local v5, "r1":F
    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->ptA:[I

    aget v6, v6, v2

    int-to-float v6, v6

    const v8, 0x3ed70a3d  # 0.42f

    mul-float v6, v6, v8

    float-to-int v6, v6

    .line 958
    .local v6, "a":I
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    div-int/lit8 v9, v6, 0x3

    const/16 v10, 0x22

    const/16 v15, 0xee

    invoke-static {v9, v10, v14, v15}, Landroid/graphics/Color;->argb(IIII)I

    move-result v9

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setColor(I)V

    .line 959
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const v9, 0x400ccccd  # 2.2f

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 960
    const v8, 0x3fe66666  # 1.8f

    mul-float v8, v8, v5

    iget-object v9, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v3, v4, v8, v9}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 961
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    div-int/lit8 v9, v6, 0x2

    const/16 v15, 0xee

    invoke-static {v9, v10, v14, v15}, Landroid/graphics/Color;->argb(IIII)I

    move-result v9

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setColor(I)V

    .line 962
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const v9, 0x3f8ccccd  # 1.1f

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 963
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v3, v4, v5, v8}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 964
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 965
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/16 v9, 0xfc

    const/16 v11, 0x7d

    invoke-static {v6, v11, v14, v9}, Landroid/graphics/Color;->argb(IIII)I

    move-result v15

    invoke-virtual {v8, v15}, Landroid/graphics/Paint;->setColor(I)V

    .line 966
    mul-float v8, v5, v17

    iget-object v9, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v3, v4, v8, v9}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 967
    iget-object v8, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 954
    .end local v3  # "cx":F
    .end local v4  # "cy":F
    .end local v5  # "r1":F
    .end local v6  # "a":I
    add-int/lit8 v2, v2, 0x4

    goto/16 :goto_3ab

    :cond_42f
    const/16 v10, 0x22

    .line 971
    .end local v2  # "i":I
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 972
    const v2, 0x3d8f5c29  # 0.07f

    mul-float v2, v2, v7

    .line 973
    .local v2, "gridStep":F
    move v3, v2

    .local v3, "gx":F
    :goto_43e
    mul-float v15, v2, v19

    sub-float v4, v7, v15

    const/4 v5, 0x0

    cmpg-float v4, v3, v4

    if-gez v4, :cond_4b0

    .line 974
    move v4, v2

    .local v4, "gy":F
    :goto_448
    mul-float v15, v2, v19

    sub-float v6, p3, v15

    cmpg-float v6, v4, v6

    if-gez v6, :cond_4a1

    .line 975
    mul-float v6, v7, v19

    sub-float v6, v3, v6

    div-float/2addr v6, v7

    .line 976
    .local v6, "dx":F
    mul-float v15, p3, v19

    sub-float v8, v4, v15

    div-float v8, v8, p3

    .line 977
    .local v8, "dy":F
    mul-float v9, v6, v6

    mul-float v11, v8, v8

    add-float/2addr v9, v11

    float-to-double v10, v9

    invoke-static {v10, v11}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v9

    double-to-float v9, v9

    .line 978
    .local v9, "dist":F
    const/high16 v10, 0x41f00000  # 30.0f

    mul-float v10, v10, v9

    const/high16 v11, 0x41b00000  # 22.0f

    sub-float/2addr v11, v10

    invoke-static {v5, v11}, Ljava/lang/Math;->max(FF)F

    move-result v10

    float-to-int v10, v10

    .line 979
    .local v10, "a":I
    const/4 v11, 0x3

    if-le v10, v11, :cond_48f

    .line 980
    iget-object v15, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    move/from16 v17, v2

    const/16 v5, 0xbd

    const/16 v11, 0xf8

    const/16 v14, 0x38

    .end local v2  # "gridStep":F
    .local v17, "gridStep":F
    invoke-static {v10, v14, v5, v11}, Landroid/graphics/Color;->argb(IIII)I

    move-result v2

    invoke-virtual {v15, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 981
    const v2, 0x3f99999a  # 1.2f

    iget-object v15, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v3, v4, v2, v15}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    goto :goto_497

    .line 979
    .end local v17  # "gridStep":F
    .restart local v2  # "gridStep":F
    :cond_48f
    move/from16 v17, v2

    const/16 v5, 0xbd

    const/16 v11, 0xf8

    const/16 v14, 0x38

    .line 974
    .end local v2  # "gridStep":F
    .end local v6  # "dx":F
    .end local v8  # "dy":F
    .end local v9  # "dist":F
    .end local v10  # "a":I
    .restart local v17  # "gridStep":F
    :goto_497
    add-float v4, v4, v17

    move/from16 v2, v17

    const/4 v5, 0x0

    const/16 v10, 0x22

    const/16 v14, 0xd3

    goto :goto_448

    .end local v17  # "gridStep":F
    .restart local v2  # "gridStep":F
    :cond_4a1
    move/from16 v17, v2

    const/16 v5, 0xbd

    const/16 v11, 0xf8

    const/16 v14, 0x38

    .line 973
    .end local v2  # "gridStep":F
    .end local v4  # "gy":F
    .restart local v17  # "gridStep":F
    add-float v3, v3, v17

    const/16 v10, 0x22

    const/16 v14, 0xd3

    goto :goto_43e

    .end local v17  # "gridStep":F
    .restart local v2  # "gridStep":F
    :cond_4b0
    move/from16 v17, v2

    .line 987
    .end local v2  # "gridStep":F
    .end local v3  # "gx":F
    .restart local v17  # "gridStep":F
    iget-object v2, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 988
    const-wide/32 v2, 0xc1101

    .line 989
    .end local v12  # "seed":J
    .local v2, "seed":J
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_4bd
    const/4 v5, 0x6

    if-ge v4, v5, :cond_54e

    .line 990
    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v2

    int-to-float v5, v4

    const v6, 0x3e0f5c29  # 0.14f

    mul-float v5, v5, v6

    const v6, 0x3e19999a  # 0.15f

    add-float/2addr v5, v6

    mul-float v5, v5, p3

    .line 991
    .local v5, "y":F
    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v2

    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v6

    const v8, 0x3c449ba6  # 0.012f

    mul-float v6, v6, v8

    const v8, 0x3c03126f  # 0.008f

    add-float/2addr v6, v8

    mul-float v6, v6, v7

    .line 992
    .local v6, "amp":F
    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v2

    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v8

    const/high16 v9, 0x41600000  # 14.0f

    mul-float v8, v8, v9

    float-to-int v8, v8

    add-int/lit8 v8, v8, 0xa

    .line 993
    .local v8, "alp":I
    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->lcg(J)J

    move-result-wide v2

    invoke-direct {v0, v2, v3}, Landroid/ext/BackgroundDrawable;->rnd(J)F

    move-result v9

    const v10, 0x3f19999a  # 0.6f

    mul-float v9, v9, v10

    add-float/2addr v9, v10

    .line 994
    .local v9, "sw":F
    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    const/16 v11, 0x22

    const/16 v14, 0xd3

    const/16 v15, 0xee

    invoke-static {v8, v11, v14, v15}, Landroid/graphics/Color;->argb(IIII)I

    move-result v12

    invoke-virtual {v10, v12}, Landroid/graphics/Paint;->setColor(I)V

    .line 995
    iget-object v10, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v10, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 996
    new-instance v10, Landroid/graphics/Path;

    invoke-direct {v10}, Landroid/graphics/Path;-><init>()V

    .line 997
    .local v10, "wave":Landroid/graphics/Path;
    const/4 v11, 0x0

    invoke-virtual {v10, v11, v5}, Landroid/graphics/Path;->moveTo(FF)V

    .line 998
    const/4 v12, 0x0

    .local v12, "x":I
    :goto_51e
    float-to-int v13, v7

    if-gt v12, v13, :cond_544

    .line 999
    int-to-double v13, v12

    const-wide v15, 0x3f96872b020c49baL  # 0.022

    mul-double v13, v13, v15

    move v15, v12

    .end local v12  # "x":I
    .local v15, "x":I
    int-to-double v11, v4

    const-wide v18, 0x3ff4cccccccccccdL  # 1.3

    mul-double v11, v11, v18

    add-double/2addr v13, v11

    invoke-static {v13, v14}, Ljava/lang/Math;->sin(D)D

    move-result-wide v11

    double-to-float v11, v11

    mul-float v11, v11, v6

    .line 1000
    .local v11, "offset":F
    int-to-float v12, v15

    add-float v13, v5, v11

    invoke-virtual {v10, v12, v13}, Landroid/graphics/Path;->lineTo(FF)V

    .line 998
    .end local v11  # "offset":F
    add-int/lit8 v12, v15, 0xe

    const/4 v11, 0x0

    .end local v15  # "x":I
    .restart local v12  # "x":I
    goto :goto_51e

    :cond_544
    move v15, v12

    .line 1002
    .end local v12  # "x":I
    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    invoke-virtual {v1, v10, v11}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 989
    .end local v5  # "y":F
    .end local v6  # "amp":F
    .end local v8  # "alp":I
    .end local v9  # "sw":F
    .end local v10  # "wave":Landroid/graphics/Path;
    add-int/lit8 v4, v4, 0x1

    goto/16 :goto_4bd

    .line 1006
    .end local v4  # "i":I
    :cond_54e
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1007
    const/4 v4, 0x0

    .restart local v4  # "i":I
    :goto_556
    const/16 v5, 0xa0

    if-ge v4, v5, :cond_5af

    .line 1008
    iget-object v5, v0, Landroid/ext/BackgroundDrawable;->ptA:[I

    aget v5, v5, v4

    int-to-float v5, v5

    const v6, 0x3f0ccccd  # 0.55f

    mul-float v5, v5, v6

    float-to-int v5, v5

    .line 1009
    .local v5, "a":I
    rem-int/lit8 v6, v4, 0x4

    if-nez v6, :cond_57d

    .line 1010
    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    const/16 v10, 0x22

    const/16 v14, 0xd3

    const/16 v15, 0xee

    invoke-static {v5, v10, v14, v15}, Landroid/graphics/Color;->argb(IIII)I

    move-result v8

    invoke-virtual {v6, v8}, Landroid/graphics/Paint;->setColor(I)V

    const/16 v8, 0xfc

    const/16 v9, 0x7d

    goto :goto_590

    .line 1012
    :cond_57d
    const/16 v10, 0x22

    const/16 v14, 0xd3

    const/16 v15, 0xee

    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    const/16 v8, 0xfc

    const/16 v9, 0x7d

    invoke-static {v5, v9, v14, v8}, Landroid/graphics/Color;->argb(IIII)I

    move-result v11

    invoke-virtual {v6, v11}, Landroid/graphics/Paint;->setColor(I)V

    .line 1014
    :goto_590
    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->blurSoft:Landroid/graphics/BlurMaskFilter;

    invoke-virtual {v6, v11}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 1015
    iget-object v6, v0, Landroid/ext/BackgroundDrawable;->ptX:[F

    aget v6, v6, v4

    iget-object v11, v0, Landroid/ext/BackgroundDrawable;->ptY:[F

    aget v11, v11, v4

    iget-object v12, v0, Landroid/ext/BackgroundDrawable;->ptR:[F

    aget v12, v12, v4

    const/high16 v13, 0x3f400000  # 0.75f

    mul-float v12, v12, v13

    iget-object v13, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    invoke-virtual {v1, v6, v11, v12, v13}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1007
    .end local v5  # "a":I
    add-int/lit8 v4, v4, 0x2

    goto :goto_556

    .line 1017
    .end local v4  # "i":I
    :cond_5af
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pPart:Landroid/graphics/Paint;

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 1018
    iget-object v4, v0, Landroid/ext/BackgroundDrawable;->pFx:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1019
    return-void

    nop

    :array_5be
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data

    :array_5c6
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data

    :array_5ce
    .array-data 4
        0x0
        0x3f800000  # 1.0f
    .end array-data
.end method

.method private drawVignette(Landroid/graphics/Canvas;FF)V
    .registers 10
    .param p1, "canvas"  # Landroid/graphics/Canvas;
    .param p2, "w"  # F
    .param p3, "h"  # F

    .line 1183
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pVignette:Landroid/graphics/Paint;

    iget v1, p0, Landroid/ext/BackgroundDrawable;->COL_BG_BOTTOM:I

    .line 1184
    invoke-static {v1}, Landroid/graphics/Color;->red(I)I

    move-result v1

    iget v2, p0, Landroid/ext/BackgroundDrawable;->COL_BG_BOTTOM:I

    .line 1185
    invoke-static {v2}, Landroid/graphics/Color;->green(I)I

    move-result v2

    iget v3, p0, Landroid/ext/BackgroundDrawable;->COL_BG_BOTTOM:I

    .line 1186
    invoke-static {v3}, Landroid/graphics/Color;->blue(I)I

    move-result v3

    .line 1183
    const/16 v4, 0x5a

    invoke-static {v4, v1, v2, v3}, Landroid/graphics/Color;->argb(IIII)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 1187
    neg-float v0, p2

    const v1, 0x3dcccccd  # 0.1f

    mul-float v0, v0, v1

    const/high16 v1, 0x3f000000  # 0.5f

    mul-float v2, p3, v1

    mul-float v3, p2, v1

    iget-object v4, p0, Landroid/ext/BackgroundDrawable;->pVignette:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v2, v3, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1188
    const v0, 0x3f8ccccd  # 1.1f

    mul-float v2, p2, v0

    mul-float v3, p3, v1

    mul-float v4, p2, v1

    iget-object v5, p0, Landroid/ext/BackgroundDrawable;->pVignette:Landroid/graphics/Paint;

    invoke-virtual {p1, v2, v3, v4, v5}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1189
    mul-float v2, p2, v1

    mul-float v0, v0, p3

    mul-float v1, v1, p3

    iget-object v3, p0, Landroid/ext/BackgroundDrawable;->pVignette:Landroid/graphics/Paint;

    invoke-virtual {p1, v2, v0, v1, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1190
    return-void
.end method

.method private initPaints()V
    .registers 3

    .line 279
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pVignette:Landroid/graphics/Paint;

    iget-object v1, p0, Landroid/ext/BackgroundDrawable;->blurVignette:Landroid/graphics/BlurMaskFilter;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 280
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pScan:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 281
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pScan:Landroid/graphics/Paint;

    const/high16 v1, 0x3f000000  # 0.5f

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 283
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pGlowOut:Landroid/graphics/Paint;

    iget v1, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_OUT:I

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 284
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pGlowOut:Landroid/graphics/Paint;

    iget-object v1, p0, Landroid/ext/BackgroundDrawable;->blurGlowOut:Landroid/graphics/BlurMaskFilter;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 285
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pGlowOut:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 286
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pGlowOut:Landroid/graphics/Paint;

    const/high16 v1, 0x41e00000  # 28.0f

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 288
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pGlowIn:Landroid/graphics/Paint;

    iget v1, p0, Landroid/ext/BackgroundDrawable;->COL_GLOW_IN:I

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 289
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pGlowIn:Landroid/graphics/Paint;

    iget-object v1, p0, Landroid/ext/BackgroundDrawable;->blurGlowIn:Landroid/graphics/BlurMaskFilter;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 290
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pGlowIn:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 291
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pGlowIn:Landroid/graphics/Paint;

    const/high16 v1, 0x41200000  # 10.0f

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 293
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pMainBorder:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 294
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pMainBorder:Landroid/graphics/Paint;

    const/high16 v1, 0x40600000  # 3.5f

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 295
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pMainBorder:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    .line 297
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pInnerRim:Landroid/graphics/Paint;

    iget v1, p0, Landroid/ext/BackgroundDrawable;->COL_INNER_RIM:I

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 298
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pInnerRim:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 299
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pInnerRim:Landroid/graphics/Paint;

    const/high16 v1, 0x3fc00000  # 1.5f

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 300
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pInnerRim:Landroid/graphics/Paint;

    const/16 v1, 0xc8

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 302
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pCornerDot:Landroid/graphics/Paint;

    iget v1, p0, Landroid/ext/BackgroundDrawable;->COL_CORNER_DOT:I

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 303
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pCornerDot:Landroid/graphics/Paint;

    iget-object v1, p0, Landroid/ext/BackgroundDrawable;->blurCorner:Landroid/graphics/BlurMaskFilter;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 305
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pLedBar:Landroid/graphics/Paint;

    iget v1, p0, Landroid/ext/BackgroundDrawable;->COL_LED_BAR:I

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 306
    iget-object v0, p0, Landroid/ext/BackgroundDrawable;->pLedBar:Landroid/graphics/Paint;

    iget-object v1, p0, Landroid/ext/BackgroundDrawable;->blurLed:Landroid/graphics/BlurMaskFilter;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    .line 307
    return-void
.end method

.method private lcg(J)J
    .registers 7
    .param p1, "j"  # J

    .line 1295
    const-wide v0, 0x5deece66dL

    mul-long v0, v0, p1

    const-wide/16 v2, 0xb

    add-long/2addr v0, v2

    const-wide v2, 0xffffffffffffL

    and-long/2addr v0, v2

    return-wide v0
.end method

.method private rnd(J)F
    .registers 7
    .param p1, "j"  # J

    .line 1296
    const/16 v0, 0x10

    shr-long v0, p1, v0

    const-wide/32 v2, 0xffff

    and-long/2addr v0, v2

    long-to-float v0, v0

    const v1, 0x477fff00  # 65535.0f

    div-float/2addr v0, v1

    return v0
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;)V
    .registers 10
    .param p1, "canvas"  # Landroid/graphics/Canvas;

    .line 321
    invoke-virtual {p0}, Landroid/ext/BackgroundDrawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    .line 322
    .local v0, "b":Landroid/graphics/Rect;
    invoke-virtual {v0}, Landroid/graphics/Rect;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_b

    return-void

    .line 323
    :cond_b
    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v1

    int-to-float v6, v1

    .local v6, "w":F
    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v1

    int-to-float v7, v1

    .line 324
    .local v7, "h":F
    iget-boolean v1, p0, Landroid/ext/BackgroundDrawable;->starsReady:Z

    if-nez v1, :cond_1c

    invoke-direct {p0, v6, v7}, Landroid/ext/BackgroundDrawable;->buildStars(FF)V

    .line 325
    :cond_1c
    iget-boolean v1, p0, Landroid/ext/BackgroundDrawable;->particlesReady:Z

    if-nez v1, :cond_23

    invoke-direct {p0, v6, v7}, Landroid/ext/BackgroundDrawable;->buildParticles(FF)V

    .line 327
    :cond_23
    const/high16 v1, 0x40000000  # 2.0f

    invoke-direct {p0, v6, v7, v1}, Landroid/ext/BackgroundDrawable;->buildFramePath(FFF)Landroid/graphics/Path;

    move-result-object v4

    .line 328
    .local v4, "outerPath":Landroid/graphics/Path;
    const/high16 v1, 0x41200000  # 10.0f

    invoke-direct {p0, v6, v7, v1}, Landroid/ext/BackgroundDrawable;->buildFramePath(FFF)Landroid/graphics/Path;

    move-result-object v5

    .line 330
    .local v5, "innerPath":Landroid/graphics/Path;
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 331
    invoke-virtual {p1, v4}, Landroid/graphics/Canvas;->clipPath(Landroid/graphics/Path;)Z

    .line 333
    invoke-direct {p0, p1, v6, v7}, Landroid/ext/BackgroundDrawable;->drawBg(Landroid/graphics/Canvas;FF)V

    .line 335
    iget v1, p0, Landroid/ext/BackgroundDrawable;->currentTheme:I

    const/4 v2, 0x2

    if-ne v1, v2, :cond_41

    invoke-direct {p0, p1, v6, v7}, Landroid/ext/BackgroundDrawable;->drawOrchidBg(Landroid/graphics/Canvas;FF)V

    goto :goto_99

    .line 336
    :cond_41
    iget v1, p0, Landroid/ext/BackgroundDrawable;->currentTheme:I

    const/4 v2, 0x3

    if-ne v1, v2, :cond_4a

    invoke-direct {p0, p1, v6, v7}, Landroid/ext/BackgroundDrawable;->drawAbyssBg(Landroid/graphics/Canvas;FF)V

    goto :goto_99

    .line 337
    :cond_4a
    iget v1, p0, Landroid/ext/BackgroundDrawable;->currentTheme:I

    const/4 v2, 0x4

    if-ne v1, v2, :cond_53

    invoke-direct {p0, p1, v6, v7}, Landroid/ext/BackgroundDrawable;->drawNeonBg(Landroid/graphics/Canvas;FF)V

    goto :goto_99

    .line 338
    :cond_53
    iget v1, p0, Landroid/ext/BackgroundDrawable;->currentTheme:I

    const/4 v2, 0x5

    if-ne v1, v2, :cond_5c

    invoke-direct {p0, p1, v6, v7}, Landroid/ext/BackgroundDrawable;->drawCoffeeBg(Landroid/graphics/Canvas;FF)V

    goto :goto_99

    .line 339
    :cond_5c
    iget v1, p0, Landroid/ext/BackgroundDrawable;->currentTheme:I

    const/4 v2, 0x6

    if-ne v1, v2, :cond_65

    invoke-direct {p0, p1, v6, v7}, Landroid/ext/BackgroundDrawable;->drawTeaBg(Landroid/graphics/Canvas;FF)V

    goto :goto_99

    .line 340
    :cond_65
    iget v1, p0, Landroid/ext/BackgroundDrawable;->currentTheme:I

    const/4 v2, 0x7

    if-ne v1, v2, :cond_6e

    invoke-direct {p0, p1, v6, v7}, Landroid/ext/BackgroundDrawable;->drawForestBg(Landroid/graphics/Canvas;FF)V

    goto :goto_99

    .line 341
    :cond_6e
    iget v1, p0, Landroid/ext/BackgroundDrawable;->currentTheme:I

    const/16 v2, 0x8

    if-ne v1, v2, :cond_78

    invoke-direct {p0, p1, v6, v7}, Landroid/ext/BackgroundDrawable;->drawTechBg(Landroid/graphics/Canvas;FF)V

    goto :goto_99

    .line 342
    :cond_78
    iget v1, p0, Landroid/ext/BackgroundDrawable;->currentTheme:I

    const/16 v2, 0x9

    if-ne v1, v2, :cond_82

    invoke-direct {p0, p1, v6, v7}, Landroid/ext/BackgroundDrawable;->drawDesertBg(Landroid/graphics/Canvas;FF)V

    goto :goto_99

    .line 343
    :cond_82
    iget v1, p0, Landroid/ext/BackgroundDrawable;->currentTheme:I

    const/16 v2, 0xa

    if-ne v1, v2, :cond_8c

    invoke-direct {p0, p1, v6, v7}, Landroid/ext/BackgroundDrawable;->drawSnowBg(Landroid/graphics/Canvas;FF)V

    goto :goto_99

    .line 344
    :cond_8c
    iget v1, p0, Landroid/ext/BackgroundDrawable;->currentTheme:I

    const/16 v2, 0xb

    if-ne v1, v2, :cond_96

    invoke-direct {p0, p1, v6, v7}, Landroid/ext/BackgroundDrawable;->drawStormBg(Landroid/graphics/Canvas;FF)V

    goto :goto_99

    .line 345
    :cond_96
    invoke-direct {p0, p1, v6, v7}, Landroid/ext/BackgroundDrawable;->drawSpaceBg(Landroid/graphics/Canvas;FF)V

    .line 347
    :goto_99
    invoke-direct {p0, p1, v6, v7}, Landroid/ext/BackgroundDrawable;->drawScanLines(Landroid/graphics/Canvas;FF)V

    .line 348
    invoke-direct {p0, p1, v6, v7}, Landroid/ext/BackgroundDrawable;->drawVignette(Landroid/graphics/Canvas;FF)V

    .line 350
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    .line 351
    move-object v2, p0

    move-object v3, p1

    .end local p1  # "canvas":Landroid/graphics/Canvas;
    .local v3, "canvas":Landroid/graphics/Canvas;
    invoke-direct/range {v2 .. v7}, Landroid/ext/BackgroundDrawable;->drawOuterFrame(Landroid/graphics/Canvas;Landroid/graphics/Path;Landroid/graphics/Path;FF)V

    .line 352
    return-void
.end method

.method public getOpacity()I
    .registers 2

    .line 1300
    const/4 v0, -0x3

    return v0
.end method

.method protected onBoundsChange(Landroid/graphics/Rect;)V
    .registers 3
    .param p1, "b"  # Landroid/graphics/Rect;

    .line 314
    invoke-super {p0, p1}, Landroid/graphics/drawable/Drawable;->onBoundsChange(Landroid/graphics/Rect;)V

    .line 315
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/ext/BackgroundDrawable;->starsReady:Z

    .line 316
    iput-boolean v0, p0, Landroid/ext/BackgroundDrawable;->particlesReady:Z

    .line 317
    return-void
.end method

.method public setAlpha(I)V
    .registers 2
    .param p1, "alpha"  # I

    .line 1298
    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .registers 2
    .param p1, "c"  # Landroid/graphics/ColorFilter;

    .line 1299
    return-void
.end method
