
gg.setTheme(6)

--Space THEME_SPACE 1
--Orchid THEME_ORCHID 2
--Abyss THEME_ABYSS 3
--Neon THEME_NEON 4
--Coffee THEME_COFFEE 5
--Tea THEME_TEA 6
--Forest THEME_FOREST 7
--Tech THEME_TECH 8
--Desert THEME_DESERT 9
--Snow THEME_SNOW 10
--Storm THEME_STORM 11

HOME = 1

function HOME()
multi = gg.multiChoice({
"🛡️BYPPAS LOBBY ",
"👽 NO RECOIL",
"🎯 AIM XILEN + MB SAFE",
"🔱 AIM LOCK",
"📡 ANTENA ",
"🔫 BALAS CORTAS",
"🔫 BALAS MEDIA ",
"📉 DESLIZAMIENTO LONGO",
"🪽 VOLAR",
"🪽 Exit",

},nil,'Name Package : com.netease.newspike \nVersion : 1.0\nArm : arm64-v8a\nVersion : SILVA021RJ VIP 🇧🇷🦌')

if multi == nil then else
if multi[1] == true then ch1() end
if multi[2] == true then ch2() end
if multi[3] == true then ch3() end
if multi[4] == true then ch4() end
if multi[5] == true then ch5() end
if multi[6] == true then ch7() end
if multi[7] == true then ch8() end
if multi[8] == true then ch9() end
if multi[9] == true then ch10() end
if multi[10] == true then ch11() end



end
HOMEDM = -1
end

function ch1()
gg.toast("☑️ BYPPAS ACTIVADO")
end 

function ch2()
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("1.03499996662", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.refineNumber("1.03499996662", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.getResults(1000, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("0", gg.TYPE_FLOAT)
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("1.505", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.refineNumber("1.505", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.getResults(1000, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll("1.035.0", gg.TYPE_FLOAT)
gg.clearResults()
gg.toast("☑️NO RECOIL ACTIVADO")
gg.clearResults()				
end 

function ch3()

					end
					



function ch4()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("1.0F;4.59177481e-39F:17", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.getResults(10)
gg.editAll("1.003", gg.TYPE_FLOAT)
gg.clearResults()
gg.toast("☑️AIMBOT ACTIVADO")
gg.setVisible(false)
end



function ch5()
gg.clearResults()
  gg.setRanges(4) 
  while true do
    gg.searchNumber("1.35216355324", 16, false, 536870912, 0, -1, 0)
    gg.setVisible(false)
    gg.processResume()
    gg.refineNumber("1.35216355324", 16, false, 536870912, 0, -1, 0)
    gg.setVisible(false)
    local results = gg.getResults(1000)
    for i, result in ipairs(results) do
      gg.editAll("-12345678", 16)
      gg.setVisible(false)
    end   
    gg.searchNumber("0.58781325817", 16, false, 536870912, 0, -1, 0)
    gg.setVisible(false)
    gg.processResume()
    gg.refineNumber("0.58781325817", 16, false, 536870912, 0, -1, 0)
    gg.setVisible(false)
    results = gg.getResults(1000)
    for i, result in ipairs(results) do
      gg.editAll("-1111111111111111", 16)
      gg.setVisible(false)
    end
    gg.sleep(1000)
end
end


function ch6()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("1.0F;4.59177481e-39F:17", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.getResults(10)
gg.editAll("1.003", gg.TYPE_FLOAT)
gg.clearResults()
gg.toast("☑️ BALAS CORTO ACTIVADO")
gg.setVisible(false)
end

function ch7()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("1.0F;4.59177481e-39F:17", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.getResults(10)
gg.editAll("1.009", gg.TYPE_FLOAT)
gg.clearResults()
gg.toast("☑️ BALAS MEDIAS ACTIVADO")
gg.setVisible(false)
end

function ch8()
gg.clearResults()
  gg.setRanges(gg.REGION_C_ALLOC)
  gg.searchNumber("0.20000000298;0.25", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.sleep("1000")
  gg.refineNumber("0.25", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
  gg.sleep("1000")
  gg.refineNumber("0.25", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1, 0)
  revert = gg.getResults(1000, nil, nil, nil, nil, nil, nil, nil, nil)
  revert = gg.getResults(1999, nil, nil, nil, nil, nil, nil, nil, nil)
  gg.editAll("-40", gg.TYPE_FLOAT)
  gg.clearResults()
  gg.toast("☑️DESLIZAR LEJOS ACTIVADO")
  end


function ch9()
gg.alert("☑️ ACTIVADO")
end

function ch10()
gg.alert("☑️ ACTIVADO")
end

function ch11()
gg.alert("☑️ exiting")
os.exit()
end


while true do 
  if gg.isVisible(false) then 
   HOMEDM = 1
    gg.setVisible(false) 
  end 
  if HOMEDM == 1 then HOME() end 
 end
 