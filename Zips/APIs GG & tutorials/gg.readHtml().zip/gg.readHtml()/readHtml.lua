g = {}
caminho_arquivo = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = { caminho_arquivo, caminho_arquivo:gsub("/[^/]+$", "") }
end

while true do
  g.info = gg.prompt({
    'Select script html :', -- 1
    
  }, g.info, {
    'file', -- 1
   
  })

  gg.saveVariable(g.info, g.config)
  caminho_arquivo = g.info[1]
  if loadfile(caminho_arquivo) == nil then
  else
    g.out = caminho_arquivo:match("[^/]+$")
    
  end

  local file = io.open(caminho_arquivo, "r")
  local DATA = file:read('*a')
  file:close()
    
 gg.readHtml(DATA)

  return
  end