


local code = [[


#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

void main()
{
    int loan_amount = 0;
    int interest_rate = 0;
    printf("enter loan amount:");
    scanf("%d", &loan_amount);
    printf("enter interest rate %:");
    scanf("%d", &interest_rate);

    int x = loan_amount;

    for ( int i = 1; i <= 30; i++ )
    {
         x = x + ( x * interest_rate )/100;
         printf("after %d year, due = %d\n", i, x);
         sleep(500);
     }
}

]]

local c = gg.compiler_c(code)

print(c)

