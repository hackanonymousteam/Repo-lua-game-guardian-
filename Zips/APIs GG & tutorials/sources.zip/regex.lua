local x = [=[

local regex = require("regex")

local texto = "Batman 123 Android"

local numero = regex.match(texto, "[0-9]+")

local palavra = regex.match(texto, "Batman")

return
    "numero=" .. tostring(numero) ..
    "\npalavra=" .. tostring(palavra)

]=]

local A = gg.loadLibsLuaJava(x)

gg.alert(tostring(A))