local x = [=[

local yaml = require("yaml")

local texto = yaml.dump({
    nome = "Batman",
    idade = 25,
    admin = true,
    itens = {
        "lua",
        "jni",
        "luv"
    }
})

return texto

]=]




local A = gg.loadLibsLuaJava(x)

print(tostring(A))