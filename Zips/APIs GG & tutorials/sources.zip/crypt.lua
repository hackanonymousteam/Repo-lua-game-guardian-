local x = [=[

local crypt = require("crypt")

local results = {}

-- 1. RANDOMKEY
local rk = crypt.randomkey()
results[#results+1] = "=== 1. RANDOMKEY ==="
results[#results+1] = "Key: " .. crypt.hexencode(rk)
results[#results+1] = "Size: " .. #rk .. " bytes"
results[#results+1] = ""

-- 2. HASHKEY
results[#results+1] = "=== 2. HASHKEY ==="
local hkTests = {"my_password", "another_pass", "batman123", "Batman123"}
for _, s in ipairs(hkTests) do
    local hk = crypt.hashkey(s)
    results[#results+1] = "hashkey('" .. s .. "') = " .. crypt.hexencode(hk)
end
results[#results+1] = ""

-- 3. HEXENCODE / HEXDECODE
results[#results+1] = "=== 3. HEXENCODE / HEXDECODE ==="
local hexOrig = "Hello Crypt!"
local hexEnc = crypt.hexencode(hexOrig)
local hexDec = crypt.hexdecode(hexEnc)
results[#results+1] = "Original: " .. hexOrig
results[#results+1] = "Hex: " .. hexEnc
results[#results+1] = "Decoded: " .. hexDec
results[#results+1] = "Match: " .. tostring(hexOrig == hexDec)
results[#results+1] = ""

-- 4. BASE64ENCODE / BASE64DECODE
results[#results+1] = "=== 4. BASE64ENCODE / BASE64DECODE ==="
local b64Tests = {"Batman", "Hello World!", "123456", "abc", "a", "ab", "abcd"}
for _, txt in ipairs(b64Tests) do
    local ok, enc = pcall(crypt.base64encode, txt)
    if ok then
        local ok2, dec = pcall(crypt.base64decode, enc)
        if ok2 then
            results[#results+1] = "'" .. txt .. "' -> '" .. enc .. "' -> '" .. dec .. "' OK=" .. tostring(txt == dec)
        else
            results[#results+1] = "'" .. txt .. "' -> '" .. enc .. "' -> ERROR: " .. tostring(dec)
        end
    else
        results[#results+1] = "'" .. txt .. "' -> ERROR: " .. tostring(enc)
    end
end
results[#results+1] = ""

-- 5. DESENCODE / DESDECODE
results[#results+1] = "=== 5. DESENCODE / DESDECODE ==="
local desKey = crypt.randomkey()
results[#results+1] = "DES Key: " .. crypt.hexencode(desKey)

local msg1 = "Secret message here!"
local enc1 = crypt.desencode(desKey, msg1)
local dec1 = crypt.desdecode(desKey, enc1)
results[#results+1] = "With custom key:"
results[#results+1] = "  Original: " .. msg1
results[#results+1] = "  Encrypted(hex): " .. crypt.hexencode(enc1)
results[#results+1] = "  Decrypted: " .. dec1
results[#results+1] = "  Match: " .. tostring(msg1 == dec1)

local msg2 = "Default key test"
local enc2 = crypt.desencode(msg2)
local dec2 = crypt.desdecode(enc2)
results[#results+1] = "With default key:"
results[#results+1] = "  Original: " .. msg2
results[#results+1] = "  Encrypted(hex): " .. crypt.hexencode(enc2)
results[#results+1] = "  Decrypted: " .. dec2
results[#results+1] = "  Match: " .. tostring(msg2 == dec2)
results[#results+1] = ""

-- 6. DESDUMP / DESLOAD
results[#results+1] = "=== 6. DESDUMP / DESLOAD ==="
local luaCode = "return 42 + 27"
local dumpKey = crypt.randomkey()
local okDump, dumped = pcall(crypt.desdump, dumpKey, luaCode)
if okDump then
    results[#results+1] = "Original: " .. luaCode
    results[#results+1] = "Dump(base64): " .. dumped
    local okLoad, loaded = pcall(crypt.desload, dumpKey, dumped)
    if okLoad then
        results[#results+1] = "Loaded result: " .. tostring(loaded)
    else
        results[#results+1] = "Load ERROR: " .. tostring(loaded)
    end
else
    results[#results+1] = "Dump ERROR: " .. tostring(dumped)
end
results[#results+1] = ""

-- 7. HMAC64
results[#results+1] = "=== 7. HMAC64 ==="
local x64 = crypt.randomkey()
local y64 = crypt.randomkey()
local hmac64 = crypt.hmac64(x64, y64)
results[#results+1] = "X: " .. crypt.hexencode(x64)
results[#results+1] = "Y: " .. crypt.hexencode(y64)
results[#results+1] = "HMAC64: " .. crypt.hexencode(hmac64)
results[#results+1] = ""

-- 8. HMAC_HASH
results[#results+1] = "=== 8. HMAC_HASH ==="
local hhKey = crypt.randomkey()
local hhMsg = "data to authenticate"
local hhResult = crypt.hmac_hash(hhKey, hhMsg)
results[#results+1] = "Key: " .. crypt.hexencode(hhKey)
results[#results+1] = "Message: " .. hhMsg
results[#results+1] = "HMAC_HASH: " .. crypt.hexencode(hhResult)
results[#results+1] = ""

-- 9. SHA1
results[#results+1] = "=== 9. SHA1 ==="
local shaTests = {"", "abc", "The quick brown fox jumps over the lazy dog", "test"}
for _, txt in ipairs(shaTests) do
    local ok, h = pcall(crypt.sha1, txt)
    if ok then
        local display = #txt > 25 and txt:sub(1,25).."..." or txt
        results[#results+1] = "SHA1('" .. display .. "') = " .. crypt.hexencode(h)
    else
        results[#results+1] = "SHA1('" .. txt:sub(1,20) .. "') = ERROR: " .. tostring(h)
    end
end
results[#results+1] = ""

-- 10. HMAC_SHA1
results[#results+1] = "=== 10. HMAC_SHA1 ==="
local hsKey = "secret_key"
local hsMsg = "important message"
local okHs, hsResult = pcall(crypt.hmac_sha1, hsKey, hsMsg)
if okHs then
    results[#results+1] = "Key: " .. hsKey
    results[#results+1] = "Message: " .. hsMsg
    results[#results+1] = "HMAC_SHA1: " .. crypt.hexencode(hsResult)
else
    results[#results+1] = "HMAC_SHA1 ERROR: " .. tostring(hsResult)
end
results[#results+1] = ""

-- 11. DHEXCHANGE / DHSECRET
results[#results+1] = "=== 11. DHEXCHANGE / DHSECRET ==="
local alicePriv = crypt.randomkey()
local alicePub = crypt.dhexchange(alicePriv)
local bobPriv = crypt.randomkey()
local bobPub = crypt.dhexchange(bobPriv)
local aliceSecret = crypt.dhsecret(alicePriv, bobPub)
local bobSecret = crypt.dhsecret(bobPriv, alicePub)
results[#results+1] = "Alice private: " .. crypt.hexencode(alicePriv)
results[#results+1] = "Alice public:  " .. crypt.hexencode(alicePub)
results[#results+1] = "Bob private:   " .. crypt.hexencode(bobPriv)
results[#results+1] = "Bob public:    " .. crypt.hexencode(bobPub)
results[#results+1] = "Alice secret:  " .. crypt.hexencode(aliceSecret)
results[#results+1] = "Bob secret:    " .. crypt.hexencode(bobSecret)
results[#results+1] = "Match: " .. tostring(aliceSecret == bobSecret)
results[#results+1] = ""

-- 12. FULL FLOW TEST
results[#results+1] = "=== 12. FULL FLOW TEST ==="
local password = "SuperSecret123!"
local originalData = "user=Batman&level=99&active=true&skills=Flight,Combat,Detective"
local flowKey = crypt.hashkey(password)
local flowEnc = crypt.desencode(flowKey, originalData)
local flowB64 = crypt.base64encode(flowEnc)
local flowDecB64 = crypt.base64decode(flowB64)
local flowDec = crypt.desdecode(flowKey, flowDecB64)
results[#results+1] = "Password: " .. password
results[#results+1] = "Key(hex): " .. crypt.hexencode(flowKey)
results[#results+1] = "Original: " .. originalData
results[#results+1] = "Encrypted(b64): " .. flowB64
results[#results+1] = "Decrypted: " .. flowDec
results[#results+1] = "Match: " .. tostring(originalData == flowDec)
results[#results+1] = ""

return table.concat(results, "\n")

]=]

local result = gg.loadLibsLuaJava(x)
gg.alert(result)