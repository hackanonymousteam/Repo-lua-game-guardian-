local x = [=[
local uv = require("luv")

local HOST = "127.0.0.1"
local PORT = 8080

local requestCount = 0
local startTime = os.time()

local function parseRequest(data)
    local request = {}
    local lines = {}
    
    for line in (data .. "\r\n"):gmatch("(.-)\r\n") do
        table.insert(lines, line)
    end
    
    if #lines > 0 then
        local method, path, version = lines[1]:match("^(%w+)%s+(.-)%s+(HTTP/.+)$")
        request.method = method or "GET"
        request.path = path or "/"
        request.version = version or "HTTP/1.1"
    end
    
    request.headers = {}
    for i = 2, #lines do
        if lines[i] == "" then break end
        local key, value = lines[i]:match("^([^:]+):%s*(.+)$")
        if key then
            request.headers[key:lower()] = value
        end
    end
    
    local bodyStart = data:find("\r\n\r\n", 1, true)
    if bodyStart then
        request.body = data:sub(bodyStart + 4)
    end
    
    return request
end

local function jsonEncode(obj)
    if type(obj) == "string" then
        return '"' .. obj:gsub('"', '\\"'):gsub("\n", "\\n") .. '"'
    elseif type(obj) == "number" then
        return tostring(obj)
    elseif type(obj) == "boolean" then
        return obj and "true" or "false"
    elseif type(obj) == "table" then
        local isArray = true
        local maxKey = 0
        for k in pairs(obj) do
            if type(k) ~= "number" or k < 1 or k ~= math.floor(k) then
                isArray = false
                break
            end
            if k > maxKey then maxKey = k end
        end
        if maxKey ~= #obj then isArray = false end
        
        local parts = {}
        if isArray then
            for i = 1, #obj do
                table.insert(parts, jsonEncode(obj[i]))
            end
            return "[" .. table.concat(parts, ",") .. "]"
        else
            for k, v in pairs(obj) do
                table.insert(parts, jsonEncode(tostring(k)) .. ":" .. jsonEncode(v))
            end
            return "{" .. table.concat(parts, ",") .. "}"
        end
    elseif obj == nil then
        return "null"
    else
        return '"' .. tostring(obj):gsub('"', '\\"') .. '"'
    end
end

local function handleRequest(method, path, request)
    requestCount = requestCount + 1
    
    if path == "/" and method == "GET" then
        local uptime = os.difftime(os.time(), startTime)
        return 200, {
            status = true,
            message = "HTTP Server with LUV (libuv)",
            version = "1.0.0",
            uptime_seconds = uptime,
            requests_total = requestCount,
            timestamp = os.date("%Y-%m-%d %H:%M:%S"),
            endpoints = {
                "/api/status",
                "/api/echo",
                "/api/time",
                "/api/headers",
                "/api/info"
            }
        }
    
    elseif path == "/api/status" and method == "GET" then
        local uptime = os.difftime(os.time(), startTime)
        local mem = uv.get_total_memory()
        local rss = uv.resident_set_memory()
        
        return 200, {
            status = "online",
            uptime_seconds = uptime,
            memory_total_mb = math.floor(mem / (1024 * 1024)),
            memory_rss_mb = math.floor(rss / (1024 * 1024)),
            requests_served = requestCount,
            pid = uv.getpid()
        }
    
    elseif path == "/api/time" and method == "GET" then
        return 200, {
            date = os.date("%Y-%m-%d"),
            time = os.date("%H:%M:%S"),
            timestamp = os.time(),
            timezone = os.date("%Z"),
            weekday = os.date("%A")
        }
    
    elseif path:match("^/api/echo") and method == "GET" then
        local msg = path:match("msg=([^&]+)") or "No message"
        msg = msg:gsub("%+", " "):gsub("%%(%x%x)", function(h) return string.char(tonumber(h, 16)) end)
        return 200, {
            echo = msg,
            length = #msg,
            reversed = msg:reverse(),
            upper = msg:upper(),
            lower = msg:lower()
        }
    
    elseif path == "/api/headers" then
        return 200, {
            method = method,
            path = path,
            headers = request.headers or {},
            client_info = {
                user_agent = request.headers and request.headers["user-agent"] or "unknown",
                host = request.headers and request.headers["host"] or "unknown",
                accept = request.headers and request.headers["accept"] or "unknown"
            }
        }
    
    elseif path == "/api/info" and method == "GET" then
        local cpu = uv.cpu_info()
        local loadavg = uv.loadavg()
        local totalMem = uv.get_total_memory()
        local freeMem = uv.get_free_memory()
        
        return 200, {
            system = {
                version = uv.version_string(),
                pid = uv.getpid(),
                cwd = uv.cwd(),
                uptime_system = uv.uptime(),
                memory = {
                    total_mb = math.floor(totalMem / (1024 * 1024)),
                    free_mb = math.floor(freeMem / (1024 * 1024)),
                    used_percent = math.floor((totalMem - freeMem) / totalMem * 100)
                },
                cpu = {
                    model = cpu and cpu[1] and cpu[1].model or "N/A",
                    cores = cpu and #cpu or 0,
                    speed_mhz = cpu and cpu[1] and cpu[1].speed or 0
                },
                loadavg = {
                    min_1 = loadavg and loadavg[1] or 0,
                    min_5 = loadavg and loadavg[2] or 0,
                    min_15 = loadavg and loadavg[3] or 0
                }
            }
        }
    
    elseif path == "/api/echo" and method == "POST" then
        local bodyData = request.body or "{}"
        return 200, {
            received = true,
            method = "POST",
            body_size = #bodyData,
            body_preview = bodyData:sub(1, 200)
        }
    
    else
        return 404, {
            status = false,
            error = "Route not found",
            path = path,
            method = method,
            available_endpoints = {
                "GET /",
                "GET /api/status",
                "GET /api/time", 
                "GET /api/echo?msg=text",
                "ANY /api/headers",
                "GET /api/info",
                "POST /api/echo"
            }
        }
    end
end

local server = uv.new_tcp()

local ok, err = pcall(function()
    uv.tcp_bind(server, HOST, PORT)
end)

if not ok then
    print("Error on bind: " .. tostring(err))
    print("Trying alternative port...")
    
    for altPort = 8081, 8090 do
        local ok2 = pcall(function()
            uv.tcp_bind(server, HOST, altPort)
        end)
        if ok2 then
            PORT = altPort
            print("Using alternative port: " .. PORT)
            break
        end
    end
end

uv.listen(server, 128, function(err)
    if err then
        print("Error on listen: " .. tostring(err))
        return
    end
    
    local client = uv.new_tcp()
    uv.accept(server, client)
    
    uv.read_start(client, function(err2, data)
        if err2 then
            pcall(function() uv.close(client) end)
            return
        end
        
        if data then
            local request = parseRequest(data)
            local method = request.method or "GET"
            local path = request.path or "/"
            
            print(string.format("%s %s", method, path))
            
            local statusCode, responseData = handleRequest(method, path, request)
            
            local body = jsonEncode(responseData)
            
            local statusMessages = {
                [200] = "OK",
                [201] = "Created", 
                [400] = "Bad Request",
                [404] = "Not Found",
                [500] = "Internal Server Error"
            }
            
            local statusText = statusMessages[statusCode] or "OK"
            
            local response = string.format(
                "HTTP/1.1 %d %s\r\n" ..
                "Content-Type: application/json; charset=utf-8\r\n" ..
                "Content-Length: %d\r\n" ..
                "Server: Luv-HTTP/1.0\r\n" ..
                "Access-Control-Allow-Origin: *\r\n" ..
                "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n" ..
                "Access-Control-Allow-Headers: Content-Type\r\n" ..
                "X-Request-Count: %d\r\n" ..
                "Connection: close\r\n" ..
                "\r\n" ..
                "%s",
                statusCode,
                statusText,
                #body,
                requestCount,
                body
            )
            
            uv.write(client, response, function(err3)
                if err3 then
                    print("Error sending: " .. tostring(err3))
                end
                pcall(function() uv.close(client) end)
            end)
        else
            pcall(function() uv.close(client) end)
        end
    end)
end)

print(string.rep("=", 50))
print("HTTP SERVER - LUV (libuv)")
print(string.rep("=", 50))
print("Host: " .. HOST)
print("Port: " .. PORT)
print(string.rep("=", 50))
print("Endpoints:")
print("  - http://" .. HOST .. ":" .. PORT .. "/")
print("  - http://" .. HOST .. ":" .. PORT .. "/api/status")
print("  - http://" .. HOST .. ":" .. PORT .. "/api/time")
print("  - http://" .. HOST .. ":" .. PORT .. "/api/echo?msg=Hi")
print("  - http://" .. HOST .. ":" .. PORT .. "/api/headers")
print("  - http://" .. HOST .. ":" .. PORT .. "/api/info")
print(string.rep("=", 50))
print("Server started successfully!")
print("")

while true do
    uv.run("nowait")
    luajava.yield(10)
end
]=]

while true do
    local ok, err = pcall(function()
        gg.loadLibsLuaJava(x)
    end)
end