local x = [=[
local luajava = require("luajava")

local ActivityThread = luajava.bindClass("android.app.ActivityThread")
local FrameLayout = luajava.bindClass("android.widget.FrameLayout")
local SurfaceView = luajava.bindClass("android.view.SurfaceView")
local Color = luajava.bindClass("android.graphics.Color")
local Gravity = luajava.bindClass("android.view.Gravity")
local LayoutParams = luajava.bindClass("android.view.WindowManager$LayoutParams")
local PixelFormat = luajava.bindClass("android.graphics.PixelFormat")
local Paint = luajava.bindClass("android.graphics.Paint")
local Path = luajava.bindClass("android.graphics.Path")
local Handler = luajava.bindClass("android.os.Handler")
local Looper = luajava.bindClass("android.os.Looper")

local context = ActivityThread.currentApplication()
if not context then
    return
end

local wm = context.getSystemService("window")
local handler = Handler(Looper.getMainLooper())

local mainLayout = FrameLayout(context)
mainLayout.setBackgroundColor(Color.parseColor("#0a0a0a"))

local titleLabel = luajava.bindClass("android.widget.TextView")(context)
titleLabel.setTextColor(Color.WHITE)
titleLabel.setTextSize(16)
titleLabel.setGravity(Gravity.CENTER)
titleLabel.setPadding(0, 40, 0, 10)
titleLabel.setBackgroundColor(Color.argb(180, 0, 0, 0))
titleLabel.setText("OpenGL Visual Demo - Starting...")

local titleParams = FrameLayout.LayoutParams(
    FrameLayout.LayoutParams.MATCH_PARENT,
    FrameLayout.LayoutParams.WRAP_CONTENT,
    Gravity.TOP
)
titleLabel.setLayoutParams(titleParams)

local surfaceView = SurfaceView(context)
surfaceView.setLayoutParams(FrameLayout.LayoutParams(
    FrameLayout.LayoutParams.MATCH_PARENT,
    FrameLayout.LayoutParams.MATCH_PARENT
))
surfaceView.setZOrderOnTop(false)

mainLayout.addView(surfaceView)
mainLayout.addView(titleLabel)

local currentDemo = 0
local totalDemos = 16
local screenW, screenH = 0, 0
local demoRunning = true

local demoNames = {
    "1. glPointSize - Point Size",
    "2. glLineWidth - Line Width",
    "3. glBegin(GL_LINES) - Lines",
    "4. glBegin(GL_LINE_STRIP) - Line Strip",
    "5. glBegin(GL_LINE_LOOP) - Line Loop",
    "6. glBegin(GL_TRIANGLES) - Triangles",
    "7. glBegin(GL_TRIANGLE_STRIP) - Triangle Strip",
    "8. glBegin(GL_TRIANGLE_FAN) - Triangle Fan",
    "9. glBegin(GL_QUADS) - Quads",
    "10. glTranslate - Translation",
    "11. glRotate - Rotation",
    "12. glScale - Scaling",
    "13. glPushMatrix/glPopMatrix",
    "14. glColor - RGBA Colors",
    "15. glBlendFunc - Transparency",
    "16. ALL TOGETHER - Final Demo",
}

local function drawDemo(demoNum, frameCount)
    local holder = surfaceView.getHolder()
    local canvas = holder.lockCanvas()
    
    if not canvas then
        return
    end
    
    canvas.drawColor(Color.parseColor("#0a0a0a"))
    
    screenW = canvas.getWidth()
    screenH = canvas.getHeight()
    local cx = screenW / 2
    local cy = screenH / 2
    
    handler.post(
        luajava.createProxy("java.lang.Runnable", {
            run = function()
                if demoNum <= totalDemos then
                    local progress = string.rep("█", demoNum) .. string.rep("░", totalDemos - demoNum)
                    titleLabel.setText(demoNames[demoNum] .. "\n" .. progress .. " " .. demoNum .. "/" .. totalDemos)
                end
            end
        })
    )
    
    local angle = frameCount * 2
    
    local function drawText(text, x, y, color, size)
        local paint = Paint()
        paint.setColor(color)
        paint.setTextSize(size or 18)
        paint.setAntiAlias(true)
        paint.setFakeBoldText(false)
        canvas.drawText(text, x, y, paint)
    end
    
    if demoNum == 1 then
        local paint = Paint()
        paint.setAntiAlias(true)
        paint.setStyle(Paint.Style.FILL)
        
        local sizes = {5, 10, 15, 20, 25, 30}
        local colors = {Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.CYAN, Color.MAGENTA}
        
        for i = 1, #sizes do
            paint.setColor(colors[i])
            paint.setStrokeWidth(sizes[i])
            local x = 100 + (i - 1) * (screenW - 200) / (#sizes - 1)
            canvas.drawPoint(x, cy, paint)
        end
        
        drawText("PointSize: " .. table.concat(sizes, ", "), 50, 80, Color.WHITE, 20)
        
    elseif demoNum == 2 then
        local paint = Paint()
        paint.setAntiAlias(true)
        paint.setStyle(Paint.Style.STROKE)
        paint.setColor(Color.WHITE)
        
        for i = 1, 8 do
            paint.setStrokeWidth(i * 3)
            local alpha = 255 - (i - 1) * 25
            paint.setAlpha(alpha)
            local y = 200 + i * 60
            canvas.drawLine(100, y, screenW - 100, y, paint)
        end
        
        drawText("LineWidth: 3 to 24 pixels", 50, 80, Color.WHITE, 20)
        
    elseif demoNum == 3 then
        local paint = Paint()
        paint.setAntiAlias(true)
        paint.setStyle(Paint.Style.STROKE)
        paint.setStrokeWidth(3)
        
        local colors = {Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW}
        for i = 1, 10 do
            paint.setColor(colors[(i % 4) + 1])
            local x = 80 + i * (screenW - 160) / 10
            canvas.drawLine(x, 150, x, screenH - 100, paint)
        end
        
        drawText("GL_LINES: Independent lines", 50, 80, Color.WHITE, 20)
        
    elseif demoNum == 4 then
        local path = Path()
        path.moveTo(80, screenH - 150)
        
        for i = 0, 20 do
            local x = 80 + i * (screenW - 160) / 20
            local y = screenH - 150 - math.sin(i * 0.5 + math.rad(angle)) * 200
            path.lineTo(x, y)
        end
        
        local paint = Paint()
        paint.setAntiAlias(true)
        paint.setStyle(Paint.Style.STROKE)
        paint.setStrokeWidth(4)
        paint.setColor(Color.CYAN)
        canvas.drawPath(path, paint)
        
        drawText("GL_LINE_STRIP: Continuous line (wave)", 50, 80, Color.WHITE, 20)
        drawText("Connects points in sequence", 50, 115, Color.GRAY, 18)
        
    elseif demoNum == 5 then
        local path = Path()
        local sides = 8
        local radius = 200
        
        for i = 0, sides do
            local a = math.rad(i * 360 / sides + angle)
            local x = cx + radius * math.cos(a)
            local y = cy + radius * math.sin(a)
            if i == 0 then
                path.moveTo(x, y)
            else
                path.lineTo(x, y)
            end
        end
        path.close()
        
        local paint = Paint()
        paint.setAntiAlias(true)
        paint.setStyle(Paint.Style.STROKE)
        paint.setStrokeWidth(5)
        paint.setColor(Color.parseColor("#ff9800"))
        canvas.drawPath(path, paint)
        
        local vertexPaint = Paint()
        vertexPaint.setColor(Color.RED)
        vertexPaint.setStrokeWidth(10)
        for i = 0, sides - 1 do
            local a = math.rad(i * 360 / sides + angle)
            local x = cx + radius * math.cos(a)
            local y = cy + radius * math.sin(a)
            canvas.drawPoint(x, y, vertexPaint)
        end
        
        drawText("GL_LINE_LOOP: Closed polygon (octagon)", 50, 80, Color.WHITE, 20)
        
    elseif demoNum == 6 then
        local paint = Paint()
        paint.setAntiAlias(true)
        paint.setStyle(Paint.Style.FILL)
        
        paint.setColor(Color.RED)
        local path = Path()
        path.moveTo(cx, cy - 250)
        path.lineTo(cx - 200, cy + 150)
        path.lineTo(cx + 200, cy + 150)
        path.close()
        canvas.drawPath(path, paint)
        
        local strokePaint = Paint()
        strokePaint.setAntiAlias(true)
        strokePaint.setStyle(Paint.Style.STROKE)
        strokePaint.setStrokeWidth(4)
        strokePaint.setColor(Color.WHITE)
        canvas.drawPath(path, strokePaint)
        
        drawText("GL_TRIANGLES: Triangle with 3 vertices", 50, 80, Color.WHITE, 20)
        drawText("Each triangle = 3 independent vertices", 50, 115, Color.GRAY, 18)
        
    elseif demoNum == 7 then
        local paint = Paint()
        paint.setAntiAlias(true)
        paint.setStyle(Paint.Style.FILL)
        
        local colors = {Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.CYAN, Color.MAGENTA}
        
        for i = 0, 5 do
            local x1 = 100 + i * (screenW - 200) / 5
            local x2 = 100 + (i + 1) * (screenW - 200) / 5
            
            local path = Path()
            path.moveTo(x1, cy - 200)
            path.lineTo(x1, cy + 200)
            path.lineTo(x2, cy - 200 + (i % 2) * 100)
            path.close()
            
            paint.setColor(colors[i + 1])
            canvas.drawPath(path, paint)
        end
        
        drawText("GL_TRIANGLE_STRIP: Triangle strip", 50, 80, Color.WHITE, 20)
        drawText("Shares vertices between adjacent triangles", 50, 115, Color.GRAY, 18)
        
    elseif demoNum == 8 then
        local paint = Paint()
        paint.setAntiAlias(true)
        paint.setStyle(Paint.Style.FILL)
        
        local segments = 12
        local colors = {
            Color.RED, Color.parseColor("#ff9800"), Color.YELLOW,
            Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA
        }
        
        for i = 0, segments - 1 do
            local path = Path()
            local a1 = math.rad(i * 360 / segments + angle)
            local a2 = math.rad((i + 1) * 360 / segments + angle)
            local r = 200
            
            path.moveTo(cx, cy)
            path.lineTo(cx + r * math.cos(a1), cy + r * math.sin(a1))
            path.lineTo(cx + r * math.cos(a2), cy + r * math.sin(a2))
            path.close()
            
            paint.setColor(colors[(i % #colors) + 1])
            canvas.drawPath(path, paint)
        end
        
        drawText("GL_TRIANGLE_FAN: Triangle fan", 50, 80, Color.WHITE, 20)
        drawText("All share the center vertex", 50, 115, Color.GRAY, 18)
        
    elseif demoNum == 9 then
        local paint = Paint()
        paint.setAntiAlias(true)
        paint.setStyle(Paint.Style.FILL)
        
        local colors = {Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW}
        
        for i = 1, 4 do
            local row = math.floor((i - 1) / 2)
            local col = (i - 1) % 2
            
            local left = cx - 200 + col * 220
            local top = cy - 200 + row * 220
            
            paint.setColor(colors[i])
            canvas.drawRect(left, top, left + 180, top + 180, paint)
            
            local borderPaint = Paint()
            borderPaint.setStyle(Paint.Style.STROKE)
            borderPaint.setStrokeWidth(3)
            borderPaint.setColor(Color.WHITE)
            canvas.drawRect(left, top, left + 180, top + 180, borderPaint)
        end
        
        drawText("GL_QUADS: 4 quads", 50, 80, Color.WHITE, 20)
        drawText("Each quad = 4 vertices", 50, 115, Color.GRAY, 18)
        
    elseif demoNum == 10 then
        local paint = Paint()
        paint.setAntiAlias(true)
        paint.setStyle(Paint.Style.FILL)
        
        local positions = {
            {cx - 250, cy - 200, Color.RED, "(-2, 1.5)"},
            {cx + 50, cy - 100, Color.GREEN, "(0.5, 1)"},
            {cx - 150, cy + 100, Color.BLUE, "(-1, -1)"},
            {cx + 200, cy + 150, Color.YELLOW, "(2, -1.5)"},
        }
        
        for _, p in ipairs(positions) do
            paint.setColor(p[3])
            paint.setAlpha(200)
            canvas.drawRect(p[1] - 40, p[2] - 40, p[1] + 40, p[2] + 40, paint)
            
            drawText(p[4], p[1] - 30, p[2] - 55, Color.WHITE, 14)
        end
        
        drawText("glTranslate(x, y, z): Translation", 50, 80, Color.WHITE, 20)
        drawText("Moves objects to different positions", 50, 115, Color.GRAY, 18)
        
    elseif demoNum == 11 then
        local paint = Paint()
        paint.setAntiAlias(true)
        paint.setStyle(Paint.Style.FILL)
        
        local numCubes = 8
        for i = 0, numCubes - 1 do
            local a = math.rad(i * 360 / numCubes + angle)
            local r = 180
            local x = cx + r * math.cos(a)
            local y = cy + r * math.sin(a)
            
            local color = Color.argb(255, 
                255 - i * 30,
                i * 30,
                128 + i * 15
            )
            paint.setColor(color)
            canvas.drawRect(x - 25, y - 25, x + 25, y + 25, paint)
        end
        
        paint.setColor(Color.WHITE)
        canvas.drawCircle(cx, cy, 12, paint)
        
        drawText("glRotate(angle, x, y, z): Rotation", 50, 80, Color.WHITE, 20)
        drawText("Rotates objects around an axis", 50, 115, Color.GRAY, 18)
        
    elseif demoNum == 12 then
        local paint = Paint()
        paint.setAntiAlias(true)
        paint.setStyle(Paint.Style.FILL)
        
        paint.setColor(Color.RED)
        paint.setAlpha(180)
        canvas.drawRect(cx - 120, cy - 60, cx - 20, cy + 60, paint)
        drawText("1x", cx - 100, cy - 80, Color.WHITE, 16)
        
        paint.setColor(Color.GREEN)
        paint.setAlpha(180)
        canvas.drawRect(cx + 20, cy - 100, cx + 200, cy + 100, paint)
        drawText("2x X", cx + 80, cy - 120, Color.WHITE, 16)
        
        paint.setColor(Color.BLUE)
        paint.setAlpha(180)
        canvas.drawRect(cx - 250, cy + 150, cx - 180, cy + 350, paint)
        drawText("2x Y", cx - 240, cy + 130, Color.WHITE, 16)
        
        drawText("glScale(x, y, z): Scaling", 50, 80, Color.WHITE, 20)
        drawText("Increases/decreases objects on axes", 50, 115, Color.GRAY, 18)
        
    elseif demoNum == 13 then
        local paint = Paint()
        paint.setAntiAlias(true)
        paint.setStyle(Paint.Style.FILL)
        
        paint.setColor(Color.argb(100, 255, 0, 0))
        canvas.drawRect(cx - 150, cy - 150, cx + 150, cy + 150, paint)
        drawText("Push 1 (World)", cx - 50, cy - 170, Color.RED, 16)
        
        paint.setColor(Color.argb(100, 0, 255, 0))
        canvas.drawRect(cx - 80, cy - 80, cx + 80, cy + 80, paint)
        drawText("Push 2 (Object)", cx - 55, cy - 100, Color.GREEN, 14)
        
        paint.setColor(Color.argb(150, 0, 0, 255))
        canvas.drawRect(cx - 30, cy - 30, cx + 30, cy + 30, paint)
        drawText("Push 3", cx - 25, cy - 50, Color.BLUE, 12)
        
        drawText("glPushMatrix() / glPopMatrix()", 50, 80, Color.WHITE, 20)
        drawText("Saves and restores transformation states", 50, 115, Color.GRAY, 18)
        
    elseif demoNum == 14 then
        local paint = Paint()
        paint.setAntiAlias(true)
        paint.setStyle(Paint.Style.FILL)
        
        local colorInfo = {
            {"R: Red", Color.RED, cx - 300, cy - 200},
            {"G: Green", Color.GREEN, cx + 100, cy - 200},
            {"B: Blue", Color.BLUE, cx - 300, cy + 50},
            {"A: Alpha (50%)", Color.argb(128, 255, 255, 255), cx + 100, cy + 50},
        }
        
        for _, info in ipairs(colorInfo) do
            paint.setColor(info[2])
            canvas.drawRect(info[3], info[4], info[3] + 180, info[4] + 130, paint)
            drawText(info[1], info[3] + 10, info[4] + 70, Color.WHITE, 14)
        end
        
        drawText("glColor(r, g, b, a): RGBA System", 50, 80, Color.WHITE, 20)
        drawText("Each channel from 0.0 to 1.0 (0-255)", 50, 115, Color.GRAY, 18)
        
    elseif demoNum == 15 then
        local paint = Paint()
        paint.setAntiAlias(true)
        paint.setStyle(Paint.Style.FILL)
        
        local circleInfo = {
            {cx - 80, cy, 120, Color.argb(150, 255, 0, 0)},
            {cx + 80, cy - 60, 120, Color.argb(150, 0, 255, 0)},
            {cx, cy + 80, 120, Color.argb(150, 0, 0, 255)},
        }
        
        for _, c in ipairs(circleInfo) do
            paint.setColor(c[4])
            canvas.drawCircle(c[1], c[2], c[3], paint)
        end
        
        drawText("glBlendFunc: Blend Modes", 50, 80, Color.WHITE, 20)
        drawText("GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA", 50, 115, Color.GRAY, 18)
        drawText("Overlapping translucent circles", 50, 145, Color.GRAY, 16)
        
    elseif demoNum == 16 then
        local gridPaint = Paint()
        gridPaint.setColor(Color.parseColor("#1a1a2e"))
        gridPaint.setStrokeWidth(1)
        for i = 0, screenW, 40 do
            canvas.drawLine(i, 0, i, screenH, gridPaint)
        end
        for i = 0, screenH, 40 do
            canvas.drawLine(0, i, screenW, i, gridPaint)
        end
        
        local circlePaint = Paint()
        circlePaint.setStyle(Paint.Style.STROKE)
        circlePaint.setStrokeWidth(3)
        circlePaint.setColor(Color.CYAN)
        circlePaint.setAntiAlias(true)
        canvas.drawCircle(cx, cy, 120, circlePaint)
        
        local cubePaint = Paint()
        cubePaint.setAntiAlias(true)
        cubePaint.setStyle(Paint.Style.FILL)
        
        for i = 0, 7 do
            local a = math.rad(i * 45 + angle)
            local r = 180
            local x = cx + r * math.cos(a)
            local y = cy + r * math.sin(a)
            
            local color = Color.argb(200,
                255 - i * 30,
                50 + i * 25,
                100 + i * 20
            )
            cubePaint.setColor(color)
            canvas.drawRect(x - 20, y - 20, x + 20, y + 20, cubePaint)
        end
        
        for i = 1, 6 do
            local r = i * 20
            local alpha = 255 - i * 35
            circlePaint.setColor(Color.argb(alpha, 255, 255, 255))
            circlePaint.setStrokeWidth(2)
            canvas.drawCircle(cx, cy, r, circlePaint)
        end
        
        local triPath = Path()
        triPath.moveTo(cx, cy - 50)
        triPath.lineTo(cx - 45, cy + 40)
        triPath.lineTo(cx + 45, cy + 40)
        triPath.close()
        
        local triPaint = Paint()
        triPaint.setStyle(Paint.Style.FILL)
        triPaint.setColor(Color.argb(150, 255, 255, 0))
        triPaint.setAntiAlias(true)
        canvas.drawPath(triPath, triPaint)
        
        drawText("FINAL DEMO - All concepts", 50, screenH - 120, Color.WHITE, 22)
        drawText("Rotation + Translation + Colors + Alpha + Primitives", 50, screenH - 85, Color.GRAY, 16)
    end
    
    local barY = screenH - 40
    local barPaint = Paint()
    barPaint.setColor(Color.parseColor("#333333"))
    barPaint.setStyle(Paint.Style.FILL)
    canvas.drawRect(30, barY, screenW - 30, barY + 8, barPaint)
    
    local progressPaint = Paint()
    progressPaint.setColor(Color.parseColor("#00bcd4"))
    progressPaint.setStyle(Paint.Style.FILL)
    local progressW = (screenW - 60) * (demoNum / totalDemos)
    canvas.drawRect(30, barY, 30 + progressW, barY + 8, progressPaint)
    
    local progText = Paint()
    progText.setColor(Color.WHITE)
    progText.setTextSize(16)
    progText.setAntiAlias(true)
    canvas.drawText(demoNum .. "/" .. totalDemos, screenW - 80, barY - 5, progText)
    
    holder.unlockCanvasAndPost(canvas)
end

local frameCount = 0
local demoStartTime = os.clock()
local demoDuration = 4.0

local function animationLoop()
    if not demoRunning then
        return
    end
    
    local elapsed = os.clock() - demoStartTime
    local newDemo = math.floor(elapsed / demoDuration) + 1
    
    if newDemo ~= currentDemo then
        currentDemo = newDemo
        
        if currentDemo > totalDemos then
            demoRunning = false
            handler.postDelayed(
                luajava.createProxy("java.lang.Runnable", {
                    run = function()
                        pcall(function() wm.removeView(mainLayout) end)
                    end
                }),
                2000
            )
            
            local holder = surfaceView.getHolder()
            local canvas = holder.lockCanvas()
            if canvas then
                canvas.drawColor(Color.parseColor("#0a0a0a"))
                local paint = Paint()
                paint.setColor(Color.WHITE)
                paint.setTextSize(40)
                paint.setAntiAlias(true)
                paint.setFakeBoldText(true)
                paint.setTextAlign(Paint.Align.CENTER)
                canvas.drawText("DEMO COMPLETED!", screenW / 2, screenH / 2, paint)
                paint.setTextSize(22)
                paint.setColor(Color.GRAY)
                canvas.drawText("Closing...", screenW / 2, screenH / 2 + 50, paint)
                holder.unlockCanvasAndPost(canvas)
            end
            return
        end
    end
    
    if currentDemo <= totalDemos then
        drawDemo(currentDemo, frameCount)
        frameCount = frameCount + 1
    end
    
    handler.postDelayed(
        luajava.createProxy("java.lang.Runnable", {
            run = function()
                animationLoop()
            end
        }),
        33
    )
end

local params = LayoutParams()
params.width = LayoutParams.MATCH_PARENT
params.height = LayoutParams.MATCH_PARENT
params.gravity = Gravity.CENTER
params.format = PixelFormat.RGBA_8888
params.type = LayoutParams.TYPE_APPLICATION_OVERLAY
params.flags = LayoutParams.FLAG_LAYOUT_IN_SCREEN

wm.addView(mainLayout, params)

handler.postDelayed(
    luajava.createProxy("java.lang.Runnable", {
        run = function()
            demoStartTime = os.clock()
            animationLoop()
        end
    }),
    300
)

local totalTime = totalDemos * demoDuration + 8
handler.postDelayed(
    luajava.createProxy("java.lang.Runnable", {
        run = function()
            pcall(function() wm.removeView(mainLayout) end)
        end
    }),
    totalTime * 1000
)

while demoRunning do
    luajava.yield(100)
end
]=]

local A = gg.loadLibsLuaJava(x)