local x = [=[

local gl = require("gl")

gl.glClearColor(
    1.0,
    0.0,
    0.0,
    1.0
)

gl.glClear(
    gl.GL_COLOR_BUFFER_BIT
)

return "framebuffer cleared"

]=]

local A = gg.loadLibsLuaJava(x)

gg.alert(tostring(A))