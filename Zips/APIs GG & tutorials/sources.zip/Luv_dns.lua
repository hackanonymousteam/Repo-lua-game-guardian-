local x = [[

local uv = require("luv")

local resultado = "waiting"

uv.getaddrinfo(
    "example.com",
    nil,
    {},
    function(err, res)

        if err then
            resultado = err
            return
        end

        if res and res[1] then
            resultado = res[1].addr
        end
    end
)

uv.run()

return resultado

]]

local A = gg.loadLibsLuaJava(x)

gg.alert(tostring(A))