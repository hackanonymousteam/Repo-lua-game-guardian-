local x = [=[

-- PURE LUA MD5 IMPLEMENTATION
-- Based on RFC 1321

local function leftrotate(x, n)
    return ((x << n) | (x >> (32 - n))) & 0xFFFFFFFF
end

local function md5(input)
    -- Constants (sine table)
    local K = {
        0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee,
        0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501,
        0x698098d8, 0x8b44f7af, 0xffff5bb1, 0x895cd7be,
        0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821,
        0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa,
        0xd62f105d, 0x02441453, 0xd8a1e681, 0xe7d3fbc8,
        0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed,
        0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a,
        0xfffa3942, 0x8771f681, 0x6d9d6122, 0xfde5380c,
        0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70,
        0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05,
        0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665,
        0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039,
        0x655b59c3, 0x8f0ccc92, 0xffeff47d, 0x85845dd1,
        0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1,
        0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391
    }
    
    -- Shift amounts per round
    local S = {
        7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
        5,  9, 14, 20, 5,  9, 14, 20, 5,  9, 14, 20, 5,  9, 14, 20,
        4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23,
        6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21
    }
    
    -- Initial values
    local a0 = 0x67452301
    local b0 = 0xEFCDAB89
    local c0 = 0x98BADCFE
    local d0 = 0x10325476
    
    -- Convert string to bytes
    local bytes = {}
    for i = 1, #input do
        bytes[i] = string.byte(input, i)
    end
    
    -- Padding
    local msgLen = #bytes
    bytes[msgLen + 1] = 0x80
    
    -- Pad to 448 mod 512
    local padLen = 64 - ((msgLen + 1) % 64)
    if padLen < 8 then padLen = padLen + 64 end
    for i = 1, padLen - 8 do
        bytes[msgLen + 1 + i] = 0
    end
    
    -- Append length in bits (64-bit little-endian)
    local bitLen = msgLen * 8
    local pos = msgLen + 1 + padLen - 8
    for i = 0, 7 do
        bytes[pos + i + 1] = (bitLen >> (i * 8)) & 0xFF
    end
    
    -- Process each 512-bit chunk
    for chunkStart = 1, #bytes, 64 do
        local M = {}
        for i = 0, 15 do
            local offset = chunkStart + i * 4
            M[i] = bytes[offset] 
                | (bytes[offset + 1] << 8) 
                | (bytes[offset + 2] << 16) 
                | (bytes[offset + 3] << 24)
        end
        
        local A = a0
        local B = b0
        local C = c0
        local D = d0
        
        for i = 0, 63 do
            local F, g
            
            if i <= 15 then
                F = (B & C) | ((~B) & D)
                g = i
            elseif i <= 31 then
                F = (D & B) | ((~D) & C)
                g = (5 * i + 1) % 16
            elseif i <= 47 then
                F = B ~ C ~ D
                g = (3 * i + 5) % 16
            else
                F = C ~ (B | (~D))
                g = (7 * i) % 16
            end
            
            F = (F + A + K[i + 1] + M[g]) & 0xFFFFFFFF
            A = D
            D = C
            C = B
            B = (B + leftrotate(F, S[i + 1])) & 0xFFFFFFFF
        end
        
        a0 = (a0 + A) & 0xFFFFFFFF
        b0 = (b0 + B) & 0xFFFFFFFF
        c0 = (c0 + C) & 0xFFFFFFFF
        d0 = (d0 + D) & 0xFFFFFFFF
    end
    
    -- Output as hex string
    local function toLittleEndianHex(v)
        local result = ""
        for i = 0, 3 do
            local byte = (v >> (i * 8)) & 0xFF
            result = result .. string.format("%02x", byte)
        end
        return result
    end
    
    return toLittleEndianHex(a0) .. toLittleEndianHex(b0) .. toLittleEndianHex(c0) .. toLittleEndianHex(d0)
end

-- ============================================
-- DEMO
-- ============================================

local results = {}

results[#results+1] = "=== PURE LUA MD5 DEMO ==="
results[#results+1] = ""

-- 1. Empty string
results[#results+1] = "1. MD5('')"
results[#results+1] = md5("")
results[#results+1] = "expected: d41d8cd98f00b204e9800998ecf8427e"
results[#results+1] = ""

-- 2. Simple string
results[#results+1] = "2. MD5('hello')"
results[#results+1] = md5("hello")
results[#results+1] = "expected: 5d41402abc4b2a76b9719d911017c592"
results[#results+1] = ""

-- 3. Classic test
results[#results+1] = "3. MD5('The quick brown fox jumps over the lazy dog')"
results[#results+1] = md5("The quick brown fox jumps over the lazy dog")
results[#results+1] = "expected: 9e107d9d372bb6826bd81d3542a419d6"
results[#results+1] = ""

-- 4. Similar strings
results[#results+1] = "4. Similar strings:"
results[#results+1] = "MD5('abc') = " .. md5("abc")
results[#results+1] = "MD5('abd') = " .. md5("abd")
results[#results+1] = "MD5('abc ') = " .. md5("abc ")
results[#results+1] = ""

-- 5. Case sensitivity
results[#results+1] = "5. Case sensitivity:"
results[#results+1] = "MD5('Batman') = " .. md5("Batman")
results[#results+1] = "MD5('batman') = " .. md5("batman")
results[#results+1] = "MD5('BATMAN') = " .. md5("BATMAN")
results[#results+1] = ""

-- 6. Numbers
results[#results+1] = "6. Numbers:"
results[#results+1] = "MD5('123456') = " .. md5("123456")
results[#results+1] = "MD5('1234567') = " .. md5("1234567")
results[#results+1] = ""

-- 7. Long text
results[#results+1] = "7. Long text:"
local long = string.rep("A", 1000)
results[#results+1] = "MD5('A'x1000) = " .. md5(long)
results[#results+1] = ""

-- 8. Avalanche effect
results[#results+1] = "8. Avalanche effect:"
results[#results+1] = "MD5('aaaa') = " .. md5("aaaa")
results[#results+1] = "MD5('aaab') = " .. md5("aaab")
results[#results+1] = ""

-- 9. Hash password example
results[#results+1] = "9. Password hashing:"
local passwords = {"admin123", "Admin123", "admin123!", "batman", "superman"}
for _, pwd in ipairs(passwords) do
    results[#results+1] = "MD5('" .. pwd .. "') = " .. md5(pwd)
end
results[#results+1] = ""

-- 10. Binary data (string with null bytes)
results[#results+1] = "10. Binary-like data:"
results[#results+1] = "MD5('test\\0data') = " .. md5("test\0data")
results[#results+1] = ""

return table.concat(results, "\n")

]=]

local ok, result = pcall(function()
    return gg.loadLibsLuaJava(x)
end)

if ok then
    gg.alert(result)
else
    gg.alert("Error: " .. tostring(result))
end