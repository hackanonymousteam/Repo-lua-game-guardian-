local x = [=[

local sensor = require("sensor")
local luajava = require("luajava")

local results = {}

-- 1. CREATE SENSOR OBJECT
results[#results+1] = "=== 1. CREATE SENSOR OBJECT ==="
local s = sensor.new()
results[#results+1] = "Sensor created: " .. tostring(s)
results[#results+1] = ""

-- 2. GET SENSOR LIST
results[#results+1] = "=== 2. SENSOR LIST ==="
local slist = s:getSensorList()
results[#results+1] = "Total sensors: " .. #slist

for i = 1, #slist do
    local info = slist[i]
    results[#results+1] = ""
    results[#results+1] = "Sensor #" .. i .. ":"
    results[#results+1] = "  name: " .. tostring(info.name)
    results[#results+1] = "  vendor: " .. tostring(info.vendor)
    results[#results+1] = "  type: " .. tostring(info.type)
    results[#results+1] = "  resolution: " .. tostring(info.resolution)
    results[#results+1] = "  minDelay: " .. tostring(info.minDelay)
end
results[#results+1] = ""

-- 3. GET DEFAULT SENSORS
results[#results+1] = "=== 3. DEFAULT SENSORS ==="

local defaultAccel = s:getDefaultSensor(sensor.TYPE_ACCELEROMETER)
results[#results+1] = "Default Accelerometer: " .. tostring(defaultAccel or "N/A")

local defaultGyro = s:getDefaultSensor(sensor.TYPE_GYROSCOPE)
results[#results+1] = "Default Gyroscope: " .. tostring(defaultGyro or "N/A")

local defaultMag = s:getDefaultSensor(sensor.TYPE_MAGNETIC_FIELD)
results[#results+1] = "Default Magnetic: " .. tostring(defaultMag or "N/A")

local defaultLight = s:getDefaultSensor(sensor.TYPE_LIGHT)
results[#results+1] = "Default Light: " .. tostring(defaultLight or "N/A")

local defaultProx = s:getDefaultSensor(sensor.TYPE_PROXIMITY)
results[#results+1] = "Default Proximity: " .. tostring(defaultProx or "N/A")
results[#results+1] = ""

-- 4. GET MIN DELAY FOR EACH SENSOR
results[#results+1] = "=== 4. MIN DELAYS ==="
for i = 1, #slist do
    local delay = s:getMinDelay(i)
    results[#results+1] = "Sensor " .. i .. " minDelay: " .. delay .. " us"
end
results[#results+1] = ""

-- 5. ENABLE SENSORS
results[#results+1] = "=== 5. ENABLE SENSORS ==="
for i = 1, #slist do
    local ret = s:enableSensor(i)
    results[#results+1] = "Enable sensor " .. i .. ": " .. tostring(ret)
end
results[#results+1] = ""

-- 6. SET EVENT RATES
results[#results+1] = "=== 6. SET EVENT RATES ==="
local accelIdx = s:getDefaultSensor(sensor.TYPE_ACCELEROMETER)
if accelIdx then
    local ret = s:setEventRate(accelIdx, 250000)
    results[#results+1] = "Accelerometer rate (250ms): " .. tostring(ret)
end

local gyroIdx = s:getDefaultSensor(sensor.TYPE_GYROSCOPE)
if gyroIdx then
    local ret = s:setEventRate(gyroIdx, 250000)
    results[#results+1] = "Gyroscope rate (250ms): " .. tostring(ret)
end

local magIdx = s:getDefaultSensor(sensor.TYPE_MAGNETIC_FIELD)
if magIdx then
    local ret = s:setEventRate(magIdx, 250000)
    results[#results+1] = "Magnetic rate (250ms): " .. tostring(ret)
end

local proxIdx = s:getDefaultSensor(sensor.TYPE_PROXIMITY)
if proxIdx then
    local ret = s:setEventRate(proxIdx, 1000000)
    results[#results+1] = "Proximity rate (1s): " .. tostring(ret)
end
results[#results+1] = ""

-- 7. POLL EVENTS (using luajava.yield for sleep)
results[#results+1] = "=== 7. POLLING EVENTS ==="
results[#results+1] = "Collecting for 3 seconds..."

local svalues = {}
local startTime = os.clock()

while os.clock() - startTime < 3 do
    local hasEvents = s:hasEvents()
    if hasEvents then
        local events = s:getEvents()
        if events then
            for i = 1, #events do
                local evt = events[i]
                if not svalues[evt.sensor] then
                    svalues[evt.sensor] = {}
                end
                svalues[evt.sensor][#svalues[evt.sensor] + 1] = evt
            end
        end
    end
  
end
results[#results+1] = "Done collecting"
results[#results+1] = ""

-- 8. SHOW COLLECTED VALUES
results[#results+1] = "=== 8. COLLECTED VALUES ==="
for sensorId, events in pairs(svalues) do
    results[#results+1] = "Sensor " .. sensorId .. " (" .. #events .. " events):"
    
    -- Show latest event
    local latest = events[#events]
    results[#results+1] = "  type: " .. tostring(latest.type)
    results[#results+1] = "  timestamp: " .. tostring(latest.timestamp)
    
    -- Show data values
    if latest[1] then
        results[#results+1] = "  values: [" .. tostring(latest[1]) .. ", " .. tostring(latest[2]) .. ", " .. tostring(latest[3]) .. "]"
    end
end
results[#results+1] = ""

-- 9. DISABLE SENSORS
results[#results+1] = "=== 9. DISABLE SENSORS ==="
for i = 1, #slist do
    local ret = s:disableSensor(i)
    results[#results+1] = "Disable sensor " .. i .. ": " .. tostring(ret)
end
results[#results+1] = ""

-- 10. SENSOR TYPE CONSTANTS
results[#results+1] = "=== 10. SENSOR TYPE CONSTANTS ==="
results[#results+1] = "TYPE_ACCELEROMETER = " .. tostring(sensor.TYPE_ACCELEROMETER)
results[#results+1] = "TYPE_MAGNETIC_FIELD = " .. tostring(sensor.TYPE_MAGNETIC_FIELD)
results[#results+1] = "TYPE_GYROSCOPE = " .. tostring(sensor.TYPE_GYROSCOPE)
results[#results+1] = "TYPE_LIGHT = " .. tostring(sensor.TYPE_LIGHT)
results[#results+1] = "TYPE_PROXIMITY = " .. tostring(sensor.TYPE_PROXIMITY)
results[#results+1] = ""

results[#results+1] = "=== DONE ==="

return table.concat(results, "\n")

]=]

local ok, result = pcall(function()
    return gg.loadLibsLuaJava(x)
end)

if ok then
    gg.alert(result)
else
    gg.alert("Error: " .. tostring(result))
end