local x = [=[

local bson = require("bson")

local doc = bson.encode({
    name = "Batman",
    age = 25,
    balance = 9999999999,
    admin = true,
    level = 99
})

doc:makeindex()

doc.age = 30
doc.level = 100
doc.admin = false
doc.balance = 8888888888

local decode = bson.decode(doc)

local updated_doc = bson.encode({
    name = "Bruce Wayne",
    age = 30,
    balance = 8888888888,
    admin = false,
    level = 100
})

local final_decode = bson.decode(updated_doc)

local result = "=== MODIFIED FIELDS (via index) ===\n"
result = result .. "name=" .. tostring(decode.name) .. " (original, not modified)\n"
result = result .. "age=" .. tostring(decode.age) .. " (modified: 30)\n"
result = result .. "level=" .. tostring(decode.level) .. " (modified: 100)\n"
result = result .. "admin=" .. tostring(decode.admin) .. " (modified: false)\n"
result = result .. "balance=" .. tostring(decode.balance) .. " (modified: 8888888888)\n"

result = result .. "\n=== RECREATED DOCUMENT WITH MODIFIED STRING ===\n"
result = result .. "name=" .. tostring(final_decode.name) .. "\n"
result = result .. "age=" .. tostring(final_decode.age) .. "\n"
result = result .. "level=" .. tostring(final_decode.level) .. "\n"
result = result .. "admin=" .. tostring(final_decode.admin) .. "\n"
result = result .. "balance=" .. tostring(final_decode.balance) .. "\n"

return result

]=]

local A = gg.loadLibsLuaJava(x)

gg.alert(tostring(A))