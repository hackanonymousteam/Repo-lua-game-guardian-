local x = [=[

local jni = require("jni")

local StringClass = jni.FindClass(
    "java/lang/String"
)

return tostring(StringClass)

]=]

local A = gg.loadLibsLuaJava(x)

gg.alert(tostring(A))