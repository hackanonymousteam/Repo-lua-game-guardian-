local x = [=[
local luajava = require("luajava")
local cjson = require("cjson")

local results = {}
local function addResult(section, content)
    table.insert(results, {section = section, content = content})
end

local function addSeparator(title)
    addResult("━", title)
end

addSeparator("1. LIBRARY INFORMATION")
addResult("INFO", "Name: " .. tostring(cjson._NAME))
addResult("INFO", "Version: " .. tostring(cjson._VERSION))
addResult("INFO", "cjson.null: " .. tostring(cjson.null))

addSeparator("2. ENCODE: Lua Types to JSON")

local str = "Hello World!"
addResult("ENCODE", 'String: "' .. str .. '" -> ' .. cjson.encode(str))

local num = 42
addResult("ENCODE", "Integer: " .. num .. " -> " .. cjson.encode(num))

local dec = 3.14159
addResult("ENCODE", "Decimal: " .. dec .. " -> " .. cjson.encode(dec))

addResult("ENCODE", "Boolean true: " .. cjson.encode(true))
addResult("ENCODE", "Boolean false: " .. cjson.encode(false))
addResult("ENCODE", "nil -> " .. cjson.encode(nil))
addResult("ENCODE", "cjson.null -> " .. cjson.encode(cjson.null))

addSeparator("3. ENCODE: Tables to JSON")

local arr = {"Batman", "Superman", "Flash", "Aquaman"}
addResult("ARRAY", cjson.encode(arr))

local obj = {name = "Bruce Wayne", age = 35, hero = true}
addResult("OBJECT", cjson.encode(obj))

local heroes = {
    {name = "Batman", power = "Intelligence", level = 95},
    {name = "Superman", power = "Super strength", level = 99},
    {name = "Flash", power = "Speed", level = 92},
}
addResult("ARRAY-OBJ", cjson.encode(heroes))

addSeparator("4. ENCODE: Nested Structures")

local complex = {
    status = true,
    user = {
        name = "Bruce Wayne",
        email = "bruce@wayne.com",
        address = {
            street = "Wayne Manor",
            number = 1007,
            city = "Gotham"
        },
        skills = {"Martial arts", "Detective", "Technology"}
    },
    metadata = {
        version = "1.0.0",
        timestamp = os.time(),
        active = true
    }
}
addResult("COMPLEX", cjson.encode(complex))

addSeparator("5. ENCODE: Special Numbers")

cjson.encode_invalid_numbers("null")
addResult("CONFIG", "encode_invalid_numbers = 'null'")

local nan = 0/0
addResult("NAN", "NaN -> " .. cjson.encode(nan))

local inf = 1/0
addResult("INF", "Infinity -> " .. cjson.encode(inf))

local negInf = -1/0
addResult("NEG-INF", "-Infinity -> " .. cjson.encode(negInf))

addSeparator("6. DECODE: JSON to Lua")

local jsonStr = '{"name":"Joker","age":40,"villain":true}'
local decoded = cjson.decode(jsonStr)
addResult("DECODE", "JSON: " .. jsonStr)
addResult("RESULT", string.format("name=%s, age=%s, villain=%s", 
    tostring(decoded.name), 
    tostring(decoded.age), 
    tostring(decoded.villain)))

local jsonArr = '["Red","Green","Blue","Yellow"]'
local colors = cjson.decode(jsonArr)
addResult("DECODE", "JSON: " .. jsonArr)
addResult("RESULT", "Array with " .. #colors .. " items: " .. table.concat(colors, ", "))

addSeparator("7. DECODE: JSON null to cjson.null")

local jsonNull = '{"name":"Batman","partner":null}'
local decodedNull = cjson.decode(jsonNull)
addResult("DECODE", "JSON: " .. jsonNull)
addResult("RESULT", "partner is cjson.null? " .. tostring(decodedNull.partner == cjson.null))
addResult("RESULT", "partner is nil? " .. tostring(decodedNull.partner == nil))

addSeparator("8. ENCODE CONFIGURATIONS")

cjson.encode_sparse_array(true, 2, 10)
addResult("CONFIG", "encode_sparse_array: convert=true, ratio=2, safe=10")

local sparse = {[1] = "a", [3] = "c", [100] = "z"}
addResult("SPARSE", cjson.encode(sparse))

local currentDepth = cjson.encode_max_depth(5)
addResult("CONFIG", "encode_max_depth: " .. currentDepth .. " -> 5")

local precision = cjson.encode_number_precision(6)
addResult("CONFIG", "encode_number_precision: " .. precision .. " -> 6")
addResult("PRECISION", "PI with 6 digits: " .. cjson.encode(math.pi))

cjson.encode_keep_buffer(true)
addResult("CONFIG", "encode_keep_buffer: true (reuses buffer)")

addSeparator("9. DECODE CONFIGURATIONS")

local decodeDepth = cjson.decode_max_depth(100)
addResult("CONFIG", "decode_max_depth: " .. decodeDepth .. " -> 100")

cjson.decode_invalid_numbers(false)
addResult("CONFIG", "decode_invalid_numbers: false (rejects NaN/Inf)")

addSeparator("10. PRETTY PRINT (Manual)")

local function prettyPrint(tbl, indent)
    indent = indent or 0
    local prefix = string.rep("  ", indent)
    
    if type(tbl) == "table" then
        for k, v in pairs(tbl) do
            if type(v) == "table" then
                addResult("PRETTY", prefix .. tostring(k) .. ": {")
                prettyPrint(v, indent + 1)
                addResult("PRETTY", prefix .. "}")
            else
                addResult("PRETTY", prefix .. tostring(k) .. ": " .. tostring(v))
            end
        end
    end
end

local sampleData = cjson.decode([[
{
    "game": "GameGuardian",
    "version": "101.0",
    "features": {
        "search": true,
        "script": true,
        "speed": true
    },
    "limits": {
        "max_results": 1000,
        "max_scripts": 50
    }
}
]])
prettyPrint(sampleData)

addSeparator("11. JSON VALIDATION")

local function isValidJSON(str)
    local ok, result = pcall(cjson.decode, str)
    if ok then
        addResult("VALID", "OK JSON valid: " .. str:sub(1, 50) .. "...")
        return true
    else
        addResult("INVALID", "X JSON invalid: " .. tostring(result))
        return false
    end
end

isValidJSON('{"name":"Bruce","age":35}')
isValidJSON('{"name":"Bruce",age:35}')
isValidJSON('[1, 2, 3, 4]')
isValidJSON('[1, 2, 3,')
isValidJSON('true')
isValidJSON('"just a string"')
isValidJSON('42')

addSeparator("12. SPECIAL CHARACTERS")

local charTests = {
    'Line 1\nLine 2\nLine 3',
    'Tab:\tHere',
    'Quotes: "inside quotes"',
    'Slash: C:\\Users\\Batman',
    'Unicode: Cafe \\u2615',
    'Control: \r\n'
}

for i, str in ipairs(charTests) do
    local encoded = cjson.encode(str)
    local displayStr = str:gsub("\n", "\\n"):gsub("\t", "\\t"):gsub("\r", "\\r")
    addResult("ESCAPE", "Original: " .. displayStr)
    addResult("ESCAPE", "Encoded:  " .. encoded)
end

addSeparator("13. QUICK BENCHMARK")

local iterations = 1000
local testTable = {
    id = 12345,
    name = "Batman",
    city = "Gotham",
    active = true,
    level = 99,
    tags = {"hero", "detective", "billionaire"},
    stats = {
        strength = 85,
        intelligence = 98,
        speed = 75,
        combat = 100
    }
}

local startTime = os.clock()
for i = 1, iterations do
    cjson.encode(testTable)
end
local encodeTime = os.clock() - startTime
addResult("BENCH", string.format("Encode: %d iterations in %.4f seconds", iterations, encodeTime))

local jsonTestStr = cjson.encode(testTable)
local startTime2 = os.clock()
for i = 1, iterations do
    cjson.decode(jsonTestStr)
end
local decodeTime = os.clock() - startTime2
addResult("BENCH", string.format("Decode: %d iterations in %.4f seconds", iterations, decodeTime))

addSeparator("14. REAL USE CASES")

local config = {
    theme = "dark",
    fontSize = 14,
    autoSave = true,
    shortcuts = {
        search = "Ctrl+F",
        replace = "Ctrl+H",
        save = "Ctrl+S"
    }
}
local configJson = cjson.encode(config)
addResult("CONFIG", "Config JSON: " .. configJson)
addResult("CONFIG", "Size: " .. #configJson .. " bytes")

local loadedConfig = cjson.decode(configJson)
addResult("CONFIG", "Loaded theme: " .. loadedConfig.theme)

local apiResponse = {
    status = 200,
    ok = true,
    data = {
        users = {
            {id = 1, name = "Bruce"},
            {id = 2, name = "Clark"},
            {id = 3, name = "Diana"}
        },
        total = 3
    }
}
addResult("API", "Response: " .. cjson.encode(apiResponse))

addSeparator("15. TYPE COMPARISON")

local comparisons = {
    {"Lua nil", nil, "JSON null", cjson.null},
    {"Lua true", true, "JSON true", true},
    {"Lua false", false, "JSON false", false},
    {"0 (number)", 0, '"0" (string)', "0"},
    {"empty array", {}, "[]", "[]"},
}

for _, comp in ipairs(comparisons) do
    addResult("COMP", string.format("%s != %s  (encode: %s)", 
        comp[1], comp[3], cjson.encode(comp[2])))
end

addSeparator("DEMONSTRATION COMPLETED")

local summary = {
    modules_tested = {
        "encode", "decode",
        "encode_sparse_array", "encode_max_depth",
        "decode_max_depth", "encode_number_precision",
        "encode_keep_buffer", "encode_invalid_numbers",
        "decode_invalid_numbers"
    },
    encode_types = {"string", "number", "boolean", "nil", "table"},
    decode_types = {"string", "number", "boolean", "null", "object", "array"},
    configurations = 8,
    examples = 15
}
addResult("SUMMARY", cjson.encode(summary))

local output = {}
for _, entry in ipairs(results) do
    if entry.section == "━" then
        table.insert(output, "\n" .. string.rep("=", 50))
        table.insert(output, entry.content)
        table.insert(output, string.rep("=", 50))
    else
        table.insert(output, string.format("[%s] %s", entry.section, entry.content))
    end
end

return table.concat(output, "\n")
]=]

local A = gg.loadLibsLuaJava(x)
print(A)