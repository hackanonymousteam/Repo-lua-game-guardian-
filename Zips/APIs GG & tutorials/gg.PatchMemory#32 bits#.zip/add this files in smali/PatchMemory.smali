# classes.dex

.class public Lcom/hello/simplejni/PatchMemory;
.super Ljava/lang/Object;
.source "PatchMemory.java"


# static fields
.field private static hexPatch:Lcom/hello/simplejni/HexPatch;


# direct methods
.method public constructor <init>()V
    .registers 4

    .prologue
    .line 122
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static apply(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
    .registers 25

    .prologue
    .line 23
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move-object v12, v1

    :try_start_b
    invoke-static {v12}, Lcom/hello/simplejni/PatchMemory;->init(Landroid/content/Context;)V

    .line 25
    move-object v12, v1

    move-object v13, v2

    invoke-static {v12, v13}, Lcom/hello/simplejni/PatchMemory;->getFirstPidByName(Landroid/content/Context;Ljava/lang/String;)I

    move-result v12

    move v7, v12

    .line 26
    move v12, v7

    const/4 v13, 0x0

    if-gt v12, v13, :cond_1c

    const/4 v12, -0x1

    move v1, v12

    .line 44
    :goto_1b
    return v1

    .line 28
    :cond_1c
    move-object v12, v3

    invoke-static {v12}, Lcom/hello/simplejni/PatchMemory;->isValidLib(Ljava/lang/String;)Z

    move-result v12

    if-nez v12, :cond_26

    const/4 v12, -0x2

    move v1, v12

    goto :goto_1b

    .line 30
    :cond_26
    move-object v12, v4

    invoke-static {v12}, Lcom/hello/simplejni/PatchMemory;->validateOffset(Ljava/lang/String;)Z

    move-result v12

    if-nez v12, :cond_30

    const/4 v12, -0x3

    move v1, v12

    goto :goto_1b

    .line 32
    :cond_30
    move-object v12, v5

    invoke-static {v12}, Lcom/hello/simplejni/PatchMemory;->validateHex(Ljava/lang/String;)Z

    move-result v12

    if-nez v12, :cond_3a

    const/4 v12, -0x4

    move v1, v12

    goto :goto_1b

    .line 34
    :cond_3a
    move v12, v7

    move-object v13, v3

    invoke-static {v12, v13}, Lcom/hello/simplejni/PatchMemory;->isLibraryInProcess(ILjava/lang/String;)Z

    move-result v12

    if-nez v12, :cond_45

    const/4 v12, -0x5

    move v1, v12

    goto :goto_1b

    .line 36
    :cond_45
    sget-object v12, Lcom/hello/simplejni/PatchMemory;->hexPatch:Lcom/hello/simplejni/HexPatch;

    move v13, v7

    invoke-virtual {v12, v13}, Lcom/hello/simplejni/HexPatch;->setTargetPid(I)V

    .line 38
    move-object v12, v4

    invoke-static {v12}, Lcom/hello/simplejni/PatchMemory;->parseOffset(Ljava/lang/String;)J

    move-result-wide v12

    move-wide v8, v12

    .line 39
    move-object v12, v5

    invoke-static {v12}, Lcom/hello/simplejni/HexPatch;->hexStringToBytes(Ljava/lang/String;)[B

    move-result-object v12

    move-object v10, v12

    .line 41
    sget-object v12, Lcom/hello/simplejni/PatchMemory;->hexPatch:Lcom/hello/simplejni/HexPatch;

    move-object v13, v3

    const/4 v14, 0x1

    new-array v14, v14, [J

    move-object/from16 v19, v14

    move-object/from16 v14, v19

    move-object/from16 v15, v19

    const/16 v16, 0x0

    move-wide/from16 v17, v8

    aput-wide v17, v15, v16

    move-object v15, v10

    invoke-virtual {v12, v13, v14, v15}, Lcom/hello/simplejni/HexPatch;->applyPatch(Ljava/lang/String;[J[B)I
    :try_end_6d
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_6d} :catch_70

    move-result v12

    move v1, v12

    goto :goto_1b

    :catch_70
    move-exception v12

    move-object v7, v12

    .line 44
    const/16 v12, -0x63

    move v1, v12

    goto :goto_1b
.end method

.method private static getFirstPidByName(Landroid/content/Context;Ljava/lang/String;)I
    .registers 13

    .prologue
    .line 51
    move-object v0, p0

    move-object v1, p1

    move-object v9, v0

    const-string v10, "activity"

    invoke-virtual {v9, v10}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Landroid/app/ActivityManager;

    move-object v3, v9

    .line 52
    move-object v9, v3

    if-nez v9, :cond_12

    const/4 v9, -0x1

    move v0, v9

    .line 63
    :goto_11
    return v0

    .line 54
    :cond_12
    move-object v9, v3

    invoke-virtual {v9}, Landroid/app/ActivityManager;->getRunningAppProcesses()Ljava/util/List;

    move-result-object v9

    move-object v4, v9

    .line 55
    move-object v9, v4

    if-nez v9, :cond_1e

    const/4 v9, -0x1

    move v0, v9

    goto :goto_11

    .line 57
    :cond_1e
    move-object v9, v4

    check-cast v9, Ljava/util/Collection;

    invoke-interface {v9}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v9

    move-object v5, v9

    .line 59
    :cond_26
    move-object v9, v5

    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-nez v9, :cond_30

    .line 63
    const/4 v9, -0x1

    move v0, v9

    goto :goto_11

    .line 57
    :cond_30
    move-object v9, v5

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Landroid/app/ActivityManager$RunningAppProcessInfo;

    move-object v7, v9

    .line 58
    move-object v9, v7

    iget-object v9, v9, Landroid/app/ActivityManager$RunningAppProcessInfo;->processName:Ljava/lang/String;

    if-eqz v9, :cond_26

    move-object v9, v7

    iget-object v9, v9, Landroid/app/ActivityManager$RunningAppProcessInfo;->processName:Ljava/lang/String;

    move-object v10, v1

    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_26

    .line 59
    move-object v9, v7

    iget v9, v9, Landroid/app/ActivityManager$RunningAppProcessInfo;->pid:I

    move v0, v9

    goto :goto_11
.end method

.method public static init(Landroid/content/Context;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")V"
        }
    .end annotation

    .prologue
    .line 14
    move-object v0, p0

    sget-object v3, Lcom/hello/simplejni/PatchMemory;->hexPatch:Lcom/hello/simplejni/HexPatch;

    if-nez v3, :cond_16

    .line 15
    new-instance v3, Lcom/hello/simplejni/HexPatch;

    move-object v6, v3

    move-object v3, v6

    move-object v4, v6

    move-object v5, v0

    invoke-direct {v4, v5}, Lcom/hello/simplejni/HexPatch;-><init>(Landroid/content/Context;)V

    sput-object v3, Lcom/hello/simplejni/PatchMemory;->hexPatch:Lcom/hello/simplejni/HexPatch;

    .line 16
    sget-object v3, Lcom/hello/simplejni/PatchMemory;->hexPatch:Lcom/hello/simplejni/HexPatch;

    invoke-virtual {v3}, Lcom/hello/simplejni/HexPatch;->initialize()Z

    move-result v3

    :cond_16
    return-void
.end method

.method private static isLibraryInProcess(ILjava/lang/String;)Z
    .registers 18

    .prologue
    .line 102
    move/from16 v0, p0

    move-object/from16 v1, p1

    :try_start_4
    new-instance v6, Ljava/io/BufferedReader;

    move-object v15, v6

    move-object v6, v15

    move-object v7, v15

    new-instance v8, Ljava/io/InputStreamReader;

    move-object v15, v8

    move-object v8, v15

    move-object v9, v15

    new-instance v10, Ljava/io/FileInputStream;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    new-instance v12, Ljava/lang/StringBuffer;

    move-object v15, v12

    move-object v12, v15

    move-object v13, v15

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v13, Ljava/lang/StringBuffer;

    move-object v15, v13

    move-object v13, v15

    move-object v14, v15

    invoke-direct {v14}, Ljava/lang/StringBuffer;-><init>()V

    const-string v14, "/proc/"

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    move v14, v0

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    const-string v13, "/maps"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v12}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    invoke-direct {v9, v10}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v7, v8}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    move-object v3, v6

    .line 109
    :cond_4a
    move-object v6, v3

    invoke-virtual {v6}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v6

    move-object v15, v6

    move-object v6, v15

    move-object v7, v15

    move-object v4, v7

    if-nez v6, :cond_5c

    .line 116
    move-object v6, v3

    invoke-virtual {v6}, Ljava/io/BufferedReader;->close()V

    .line 121
    const/4 v6, 0x0

    move v0, v6

    :goto_5b
    return v0

    .line 110
    :cond_5c
    move-object v6, v4

    move-object v7, v1

    invoke-virtual {v6, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-eqz v6, :cond_4a

    .line 111
    move-object v6, v3

    invoke-virtual {v6}, Ljava/io/BufferedReader;->close()V
    :try_end_68
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_68} :catch_6b

    .line 112
    const/4 v6, 0x1

    move v0, v6

    goto :goto_5b

    .line 116
    :catch_6b
    move-exception v6

    move-object v3, v6

    .line 118
    const/4 v6, 0x0

    move v0, v6

    goto :goto_5b
.end method

.method private static isValidLib(Ljava/lang/String;)Z
    .registers 6

    .prologue
    .line 69
    move-object v0, p0

    move-object v3, v0

    if-eqz v3, :cond_15

    move-object v3, v0

    const-string v4, ".so"

    invoke-virtual {v3, v4}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_15

    move-object v3, v0

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v4, 0x3

    if-gt v3, v4, :cond_18

    :cond_15
    const/4 v3, 0x0

    :goto_16
    move v0, v3

    return v0

    :cond_18
    const/4 v3, 0x1

    goto :goto_16
.end method

.method private static parseOffset(Ljava/lang/String;)J
    .registers 7

    .prologue
    .line 95
    move-object v0, p0

    move-object v3, v0

    const-string v4, "0x"

    const-string v5, ""

    invoke-virtual {v3, v4, v5}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "0X"

    const-string v5, ""

    invoke-virtual {v3, v4, v5}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0x10

    invoke-static {v3, v4}, Ljava/lang/Long;->parseLong(Ljava/lang/String;I)J

    move-result-wide v3

    move-wide v0, v3

    return-wide v0
.end method

.method private static validateHex(Ljava/lang/String;)Z
    .registers 8

    .prologue
    .line 83
    move-object v0, p0

    move-object v4, v0

    if-nez v4, :cond_7

    const/4 v4, 0x0

    move v0, v4

    .line 91
    :goto_6
    return v0

    .line 85
    :cond_7
    move-object v4, v0

    const-string v5, " "

    const-string v6, ""

    invoke-virtual {v4, v5, v6}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    move-object v2, v4

    .line 87
    move-object v4, v2

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v5, 0x0

    if-ne v4, v5, :cond_20

    const/4 v4, 0x0

    move v0, v4

    goto :goto_6

    .line 89
    :cond_20
    move-object v4, v2

    const-string v5, "[0-9a-fA-F]+"

    invoke-virtual {v4, v5}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_2c

    const/4 v4, 0x0

    move v0, v4

    goto :goto_6

    .line 91
    :cond_2c
    move-object v4, v2

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v5, 0x2

    rem-int/lit8 v4, v4, 0x2

    const/4 v5, 0x0

    if-eq v4, v5, :cond_3a

    const/4 v4, 0x0

    :goto_38
    move v0, v4

    goto :goto_6

    :cond_3a
    const/4 v4, 0x1

    goto :goto_38
.end method

.method private static validateOffset(Ljava/lang/String;)Z
    .registers 8

    .prologue
    .line 73
    move-object v0, p0

    move-object v4, v0

    if-nez v4, :cond_7

    const/4 v4, 0x0

    move v0, v4

    .line 79
    :goto_6
    return v0

    .line 75
    :cond_7
    move-object v4, v0

    const-string v5, "0x"

    const-string v6, ""

    invoke-virtual {v4, v5, v6}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "0X"

    const-string v6, ""

    invoke-virtual {v4, v5, v6}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    move-object v2, v4

    .line 77
    move-object v4, v2

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v5, 0x0

    if-ne v4, v5, :cond_28

    const/4 v4, 0x0

    move v0, v4

    goto :goto_6

    .line 79
    :cond_28
    move-object v4, v2

    const-string v5, "[0-9a-fA-F]+"

    invoke-virtual {v4, v5}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v4

    move v0, v4

    goto :goto_6
.end method
