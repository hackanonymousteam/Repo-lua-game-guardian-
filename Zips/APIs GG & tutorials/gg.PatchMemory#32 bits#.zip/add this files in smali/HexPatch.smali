# classes.dex

.class public Lcom/hello/simplejni/HexPatch;
.super Ljava/lang/Object;
.source "HexPatch.java"


# instance fields
.field private context:Landroid/content/Context;

.field private targetPid:I


# direct methods
.method static final constructor <clinit>()V
    .registers 3

    .prologue
    .line 14
    const-string v2, "hexpatcher"

    invoke-static {v2}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 7

    .prologue
    .line 25
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 26
    move-object v3, v0

    move-object v4, v1

    invoke-virtual {v4}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    iput-object v4, v3, Lcom/hello/simplejni/HexPatch;->context:Landroid/content/Context;

    return-void
.end method

.method public static bytesToHexString([B)Ljava/lang/String;
    .registers 18

    .prologue
    .line 77
    move-object/from16 v0, p0

    new-instance v7, Ljava/lang/StringBuilder;

    move-object v15, v7

    move-object v7, v15

    move-object v8, v15

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    move-object v2, v7

    .line 78
    move-object v7, v0

    move-object v3, v7

    const/4 v7, 0x0

    move v4, v7

    .line 79
    :goto_f
    move v7, v4

    move-object v8, v3

    array-length v8, v8

    if-lt v7, v8, :cond_1f

    .line 81
    move-object v7, v2

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    move-object v0, v7

    return-object v0

    .line 78
    :cond_1f
    move-object v7, v3

    move v8, v4

    aget-byte v7, v7, v8

    move v5, v7

    .line 79
    move-object v7, v2

    const-string v8, "%02X "

    const/4 v9, 0x1

    new-array v9, v9, [Ljava/lang/Object;

    move-object v15, v9

    move-object v9, v15

    move-object v10, v15

    const/4 v11, 0x0

    move v12, v5

    new-instance v13, Ljava/lang/Byte;

    move v15, v12

    move-object/from16 v16, v13

    move-object/from16 v12, v16

    move v13, v15

    move-object/from16 v14, v16

    move v15, v13

    move-object/from16 v16, v14

    move-object/from16 v13, v16

    move v14, v15

    invoke-direct {v13, v14}, Ljava/lang/Byte;-><init>(B)V

    aput-object v12, v10, v11

    invoke-static {v8, v9}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    add-int/lit8 v4, v4, 0x1

    goto :goto_f
.end method

.method public static hexStringToBytes(Ljava/lang/String;)[B
    .registers 13

    .prologue
    .line 64
    move-object v0, p0

    move-object v5, v0

    const-string v6, "\\s"

    const-string v7, ""

    invoke-virtual {v5, v6, v7}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    move-object v0, v5

    .line 65
    move-object v5, v0

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v5

    const/4 v6, 0x2

    rem-int/lit8 v5, v5, 0x2

    const/4 v6, 0x0

    if-eq v5, v6, :cond_21

    .line 66
    new-instance v5, Ljava/lang/IllegalArgumentException;

    move-object v11, v5

    move-object v5, v11

    move-object v6, v11

    const-string v7, "String hex inválida"

    invoke-direct {v6, v7}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v5

    .line 69
    :cond_21
    move-object v5, v0

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v5

    const/4 v6, 0x2

    div-int/lit8 v5, v5, 0x2

    new-array v5, v5, [B

    move-object v2, v5

    .line 70
    const/4 v5, 0x0

    move v3, v5

    :goto_2e
    move v5, v3

    move-object v6, v2

    array-length v6, v6

    if-lt v5, v6, :cond_36

    .line 73
    move-object v5, v2

    move-object v0, v5

    return-object v0

    .line 71
    :cond_36
    move-object v5, v2

    move v6, v3

    move-object v7, v0

    move v8, v3

    const/4 v9, 0x2

    mul-int/lit8 v8, v8, 0x2

    move v9, v3

    const/4 v10, 0x2

    mul-int/lit8 v9, v9, 0x2

    const/4 v10, 0x2

    add-int/lit8 v9, v9, 0x2

    invoke-virtual {v7, v8, v9}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v7

    const/16 v8, 0x10

    invoke-static {v7, v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v7

    int-to-byte v7, v7

    aput-byte v7, v5, v6

    .line 70
    add-int/lit8 v3, v3, 0x1

    goto :goto_2e
.end method


# virtual methods
.method public native applyPatch(ILjava/lang/String;[J[BI)I
.end method

.method public applyPatch(Ljava/lang/String;[J[B)I
    .registers 16

    .prologue
    .line 49
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v5, v0

    iget v5, v5, Lcom/hello/simplejni/HexPatch;->targetPid:I

    const/4 v6, 0x0

    if-gt v5, v6, :cond_15

    .line 50
    new-instance v5, Ljava/lang/IllegalStateException;

    move-object v11, v5

    move-object v5, v11

    move-object v6, v11

    const-string v7, "Target PID not set"

    invoke-direct {v6, v7}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v5

    .line 52
    :cond_15
    move-object v5, v0

    move-object v6, v0

    iget v6, v6, Lcom/hello/simplejni/HexPatch;->targetPid:I

    move-object v7, v1

    move-object v8, v2

    move-object v9, v3

    move-object v10, v3

    array-length v10, v10

    invoke-virtual/range {v5 .. v10}, Lcom/hello/simplejni/HexPatch;->applyPatch(ILjava/lang/String;[J[BI)I

    move-result v5

    move v0, v5

    return v0
.end method

.method public native findPattern(ILjava/lang/String;[BI)[J
.end method

.method public findPattern(Ljava/lang/String;[B)[J
    .registers 13

    .prologue
    .line 42
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    iget v4, v4, Lcom/hello/simplejni/HexPatch;->targetPid:I

    const/4 v5, 0x0

    if-gt v4, v5, :cond_14

    .line 43
    new-instance v4, Ljava/lang/IllegalStateException;

    move-object v9, v4

    move-object v4, v9

    move-object v5, v9

    const-string v6, "Target PID not set"

    invoke-direct {v5, v6}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v4

    .line 45
    :cond_14
    move-object v4, v0

    move-object v5, v0

    iget v5, v5, Lcom/hello/simplejni/HexPatch;->targetPid:I

    move-object v6, v1

    move-object v7, v2

    move-object v8, v2

    array-length v8, v8

    invoke-virtual {v4, v5, v6, v7, v8}, Lcom/hello/simplejni/HexPatch;->findPattern(ILjava/lang/String;[BI)[J

    move-result-object v4

    move-object v0, v4

    return-object v0
.end method

.method public getTargetPid()I
    .registers 4

    .prologue
    .line 38
    move-object v0, p0

    move-object v2, v0

    iget v2, v2, Lcom/hello/simplejni/HexPatch;->targetPid:I

    move v0, v2

    return v0
.end method

.method public initialize()Z
    .registers 4

    .prologue
    .line 30
    move-object v0, p0

    const/4 v2, 0x1

    move v0, v2

    return v0
.end method

.method public setTargetPid(I)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .prologue
    .line 34
    move-object v0, p0

    move v1, p1

    move-object v3, v0

    move v4, v1

    iput v4, v3, Lcom/hello/simplejni/HexPatch;->targetPid:I

    return-void
.end method

.method public native verifyPatch(ILjava/lang/String;[J[BI)I
.end method

.method public verifyPatch(Ljava/lang/String;[J[B)I
    .registers 16

    .prologue
    .line 56
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v5, v0

    iget v5, v5, Lcom/hello/simplejni/HexPatch;->targetPid:I

    const/4 v6, 0x0

    if-gt v5, v6, :cond_15

    .line 57
    new-instance v5, Ljava/lang/IllegalStateException;

    move-object v11, v5

    move-object v5, v11

    move-object v6, v11

    const-string v7, "Target PID not set"

    invoke-direct {v6, v7}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v5

    .line 59
    :cond_15
    move-object v5, v0

    move-object v6, v0

    iget v6, v6, Lcom/hello/simplejni/HexPatch;->targetPid:I

    move-object v7, v1

    move-object v8, v2

    move-object v9, v3

    move-object v10, v3

    array-length v10, v10

    invoke-virtual/range {v5 .. v10}, Lcom/hello/simplejni/HexPatch;->verifyPatch(ILjava/lang/String;[J[BI)I

    move-result v5

    move v0, v5

    return v0
.end method
