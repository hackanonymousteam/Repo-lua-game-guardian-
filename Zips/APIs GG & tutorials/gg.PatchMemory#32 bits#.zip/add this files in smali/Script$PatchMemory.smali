# classes.dex

.class public Landroid/ext/Script$PatchMemory;
.super Landroid/ext/Script$ApiFunction;
.source "Script.java"


# instance fields
.field final synthetic this$0:Landroid/ext/Script;


# direct methods
.method constructor <init>(Landroid/ext/Script;)V
    .registers 2

    .prologue
    iput-object p1, p0, Landroid/ext/Script$PatchMemory;->this$0:Landroid/ext/Script;

    invoke-direct {p0}, Landroid/ext/Script$ApiFunction;-><init>()V

    return-void
.end method


# virtual methods
.method final a()Ljava/lang/String;
    .registers 2

    .prologue
    const-string v0, "gg.PatchMemory(process, libname, offset, hex) -> nil"

    return-object v0
.end method



.method public d(Lluaj/ap;)Lluaj/ap;
    .registers 7

    .prologue

    const/4 v0, 0x1
    invoke-virtual {p1, v0}, Lluaj/ap;->r(I)Ljava/lang/String;
    move-result-object v0

    const/4 v1, 0x2
    invoke-virtual {p1, v1}, Lluaj/ap;->r(I)Ljava/lang/String;
    move-result-object v1

    const/4 v2, 0x3
    invoke-virtual {p1, v2}, Lluaj/ap;->r(I)Ljava/lang/String;
    move-result-object v2

    const/4 v3, 0x4
    invoke-virtual {p1, v3}, Lluaj/ap;->r(I)Ljava/lang/String;
    move-result-object v3

    invoke-static {}, Landroid/ext/Tools;->e()Landroid/content/Context;
    move-result-object v4

    invoke-static {v4, v0, v1, v2, v3}, Lcom/hello/simplejni/PatchMemory;->apply(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
    move-result v0

        sget-object v0, Lluaj/LuaValue;->u:Lluaj/LuaValue;
    return-object v0
.end method


.method protected m_()I
    .registers 2

    .prologue
    const/4 v0, 0x5

    return v0
.end method
