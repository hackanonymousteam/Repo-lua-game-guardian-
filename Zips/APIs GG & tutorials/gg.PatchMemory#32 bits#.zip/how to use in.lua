
gg.PatchMemory("com.shooting.commandomissiongame.counterattack.fpscommando.gungames", "libunity.so", "0x2D1228", "0000A040")