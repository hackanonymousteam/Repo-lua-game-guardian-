# classes.dex

.class Lcom/lib/activities/Loading$CircularLoadingView;
.super Landroid/view/View;
.source "Loading.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/lib/activities/Loading;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2a
    name = "CircularLoadingView"
.end annotation


# instance fields
.field private mAnimatedValue:F

.field private mMaxRadius:F

.field private mPaintCenter:Landroid/graphics/Paint;

.field private mPaintRound:Landroid/graphics/Paint;

.field private mProgerssRotateAnim:Landroid/view/animation/RotateAnimation;

.field private mStartAngle:I

.field private mWidth:F


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 7

    .prologue
    .line 165
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    move-object v4, v1

    invoke-direct {v3, v4}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 166
    move-object v3, v0

    const/4 v4, 0x0

    iput v4, v3, Lcom/lib/activities/Loading$CircularLoadingView;->mWidth:F

    .line 167
    move-object v3, v0

    const/4 v4, 0x0

    iput v4, v3, Lcom/lib/activities/Loading$CircularLoadingView;->mAnimatedValue:F

    .line 168
    move-object v3, v0

    const/4 v4, 0x0

    iput v4, v3, Lcom/lib/activities/Loading$CircularLoadingView;->mStartAngle:I

    .line 169
    move-object v3, v0

    const/4 v4, 0x4

    int-to-float v4, v4

    iput v4, v3, Lcom/lib/activities/Loading$CircularLoadingView;->mMaxRadius:F

    .line 170
    move-object v3, v0

    invoke-direct {v3}, Lcom/lib/activities/Loading$CircularLoadingView;->initPaint()V

    return-void
.end method

.method private initPaint()V
    .registers 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 202
    move-object v0, p0

    move-object v2, v0

    new-instance v3, Landroid/graphics/Paint;

    move-object v11, v3

    move-object v3, v11

    move-object v4, v11

    invoke-direct {v4}, Landroid/graphics/Paint;-><init>()V

    iput-object v3, v2, Lcom/lib/activities/Loading$CircularLoadingView;->mPaintCenter:Landroid/graphics/Paint;

    .line 203
    move-object v2, v0

    iget-object v2, v2, Lcom/lib/activities/Loading$CircularLoadingView;->mPaintCenter:Landroid/graphics/Paint;

    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 204
    move-object v2, v0

    iget-object v2, v2, Lcom/lib/activities/Loading$CircularLoadingView;->mPaintCenter:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 205
    move-object v2, v0

    iget-object v2, v2, Lcom/lib/activities/Loading$CircularLoadingView;->mPaintCenter:Landroid/graphics/Paint;

    const/4 v3, -0x1

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 207
    move-object v2, v0

    new-instance v3, Landroid/graphics/Paint;

    move-object v11, v3

    move-object v3, v11

    move-object v4, v11

    invoke-direct {v4}, Landroid/graphics/Paint;-><init>()V

    iput-object v3, v2, Lcom/lib/activities/Loading$CircularLoadingView;->mPaintRound:Landroid/graphics/Paint;

    .line 208
    move-object v2, v0

    iget-object v2, v2, Lcom/lib/activities/Loading$CircularLoadingView;->mPaintRound:Landroid/graphics/Paint;

    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 209
    move-object v2, v0

    iget-object v2, v2, Lcom/lib/activities/Loading$CircularLoadingView;->mPaintRound:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 210
    move-object v2, v0

    iget-object v2, v2, Lcom/lib/activities/Loading$CircularLoadingView;->mPaintRound:Landroid/graphics/Paint;

    const/4 v3, -0x1

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 212
    move-object v2, v0

    new-instance v3, Landroid/view/animation/RotateAnimation;

    move-object v11, v3

    move-object v3, v11

    move-object v4, v11

    const/4 v5, 0x0

    const/high16 v6, 0x43b40000  # 360.0f

    const/4 v7, 0x1

    const/high16 v8, 0x3f000000  # 0.5f

    const/4 v9, 0x1

    const/high16 v10, 0x3f000000  # 0.5f

    invoke-direct/range {v4 .. v10}, Landroid/view/animation/RotateAnimation;-><init>(FFIFIF)V

    iput-object v3, v2, Lcom/lib/activities/Loading$CircularLoadingView;->mProgerssRotateAnim:Landroid/view/animation/RotateAnimation;

    .line 215
    move-object v2, v0

    iget-object v2, v2, Lcom/lib/activities/Loading$CircularLoadingView;->mProgerssRotateAnim:Landroid/view/animation/RotateAnimation;

    const/4 v3, -0x1

    invoke-virtual {v2, v3}, Landroid/view/animation/RotateAnimation;->setRepeatCount(I)V

    .line 216
    move-object v2, v0

    iget-object v2, v2, Lcom/lib/activities/Loading$CircularLoadingView;->mProgerssRotateAnim:Landroid/view/animation/RotateAnimation;

    new-instance v3, Landroid/view/animation/LinearInterpolator;

    move-object v11, v3

    move-object v3, v11

    move-object v4, v11

    invoke-direct {v4}, Landroid/view/animation/LinearInterpolator;-><init>()V

    invoke-virtual {v2, v3}, Landroid/view/animation/RotateAnimation;->setInterpolator(Landroid/view/animation/Interpolator;)V

    .line 217
    move-object v2, v0

    iget-object v2, v2, Lcom/lib/activities/Loading$CircularLoadingView;->mProgerssRotateAnim:Landroid/view/animation/RotateAnimation;

    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Landroid/view/animation/RotateAnimation;->setFillAfter(Z)V

    return-void
.end method


# virtual methods
.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/Canvas;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 186
    move-object v0, p0

    move-object/from16 v1, p1

    move-object v9, v0

    move-object v10, v1

    invoke-super {v9, v10}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    .line 189
    const/4 v9, 0x0

    move v3, v9

    :goto_a
    move v9, v3

    const/16 v10, 0x9

    if-lt v9, v10, :cond_30

    .line 197
    move-object v9, v1

    move-object v10, v0

    iget v10, v10, Lcom/lib/activities/Loading$CircularLoadingView;->mWidth:F

    const/high16 v11, 0x40000000  # 2.0f

    div-float/2addr v10, v11

    move-object v11, v0

    iget v11, v11, Lcom/lib/activities/Loading$CircularLoadingView;->mWidth:F

    const/high16 v12, 0x40000000  # 2.0f

    div-float/2addr v11, v12

    move-object v12, v0

    iget v12, v12, Lcom/lib/activities/Loading$CircularLoadingView;->mWidth:F

    const/high16 v13, 0x40000000  # 2.0f

    div-float/2addr v12, v13

    move-object v13, v0

    iget v13, v13, Lcom/lib/activities/Loading$CircularLoadingView;->mMaxRadius:F

    const/4 v14, 0x6

    int-to-float v14, v14

    mul-float/2addr v13, v14

    sub-float/2addr v12, v13

    move-object v13, v0

    iget-object v13, v13, Lcom/lib/activities/Loading$CircularLoadingView;->mPaintCenter:Landroid/graphics/Paint;

    invoke-virtual {v9, v10, v11, v12, v13}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    return-void

    .line 190
    :cond_30
    move-object v9, v0

    iget v9, v9, Lcom/lib/activities/Loading$CircularLoadingView;->mStartAngle:I

    int-to-float v9, v9

    const/high16 v10, 0x42340000  # 45.0f

    move v11, v3

    int-to-float v11, v11

    mul-float/2addr v10, v11

    add-float/2addr v9, v10

    float-to-double v9, v9

    invoke-static {v9, v10}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v9

    move-wide v4, v9

    .line 191
    move-object v9, v0

    iget v9, v9, Lcom/lib/activities/Loading$CircularLoadingView;->mWidth:F

    const/high16 v10, 0x40000000  # 2.0f

    div-float/2addr v9, v10

    move-object v10, v0

    iget v10, v10, Lcom/lib/activities/Loading$CircularLoadingView;->mWidth:F

    const/high16 v11, 0x40000000  # 2.0f

    div-float/2addr v10, v11

    move-object v11, v0

    iget v11, v11, Lcom/lib/activities/Loading$CircularLoadingView;->mMaxRadius:F

    sub-float/2addr v10, v11

    float-to-double v10, v10

    move-wide v12, v4

    invoke-static {v12, v13}, Ljava/lang/Math;->cos(D)D

    move-result-wide v12

    mul-double/2addr v10, v12

    double-to-float v10, v10

    sub-float/2addr v9, v10

    move v6, v9

    .line 192
    move-object v9, v0

    iget v9, v9, Lcom/lib/activities/Loading$CircularLoadingView;->mWidth:F

    const/high16 v10, 0x40000000  # 2.0f

    div-float/2addr v9, v10

    move-object v10, v0

    iget v10, v10, Lcom/lib/activities/Loading$CircularLoadingView;->mWidth:F

    const/high16 v11, 0x40000000  # 2.0f

    div-float/2addr v10, v11

    move-object v11, v0

    iget v11, v11, Lcom/lib/activities/Loading$CircularLoadingView;->mMaxRadius:F

    sub-float/2addr v10, v11

    float-to-double v10, v10

    move-wide v12, v4

    invoke-static {v12, v13}, Ljava/lang/Math;->sin(D)D

    move-result-wide v12

    mul-double/2addr v10, v12

    double-to-float v10, v10

    sub-float/2addr v9, v10

    move v7, v9

    .line 193
    move-object v9, v1

    move v10, v6

    move v11, v7

    move-object v12, v0

    iget v12, v12, Lcom/lib/activities/Loading$CircularLoadingView;->mMaxRadius:F

    move-object v13, v0

    iget-object v13, v13, Lcom/lib/activities/Loading$CircularLoadingView;->mPaintRound:Landroid/graphics/Paint;

    invoke-virtual {v9, v10, v11, v12, v13}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 189
    add-int/lit8 v3, v3, 0x1

    goto :goto_a
.end method

.method protected onMeasure(II)V
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 175
    move-object v0, p0

    move v1, p1

    move v2, p2

    move-object v4, v0

    move v5, v1

    move v6, v2

    invoke-super {v4, v5, v6}, Landroid/view/View;->onMeasure(II)V

    .line 176
    move-object v4, v0

    invoke-virtual {v4}, Lcom/lib/activities/Loading$CircularLoadingView;->getMeasuredWidth()I

    move-result v4

    move-object v5, v0

    invoke-virtual {v5}, Lcom/lib/activities/Loading$CircularLoadingView;->getHeight()I

    move-result v5

    if-le v4, v5, :cond_28

    .line 177
    move-object v4, v0

    move-object v5, v0

    invoke-virtual {v5}, Lcom/lib/activities/Loading$CircularLoadingView;->getMeasuredHeight()I

    move-result v5

    int-to-float v5, v5

    iput v5, v4, Lcom/lib/activities/Loading$CircularLoadingView;->mWidth:F

    .line 181
    :goto_1e
    move-object v4, v0

    move-object v5, v0

    iget v5, v5, Lcom/lib/activities/Loading$CircularLoadingView;->mWidth:F

    const/high16 v6, 0x41f00000  # 30.0f

    div-float/2addr v5, v6

    iput v5, v4, Lcom/lib/activities/Loading$CircularLoadingView;->mMaxRadius:F

    return-void

    .line 179
    :cond_28
    move-object v4, v0

    move-object v5, v0

    invoke-virtual {v5}, Lcom/lib/activities/Loading$CircularLoadingView;->getMeasuredWidth()I

    move-result v5

    int-to-float v5, v5

    iput v5, v4, Lcom/lib/activities/Loading$CircularLoadingView;->mWidth:F

    goto :goto_1e
.end method

.method public setViewColor(I)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .prologue
    .line 221
    move-object v0, p0

    move v1, p1

    move-object v3, v0

    iget-object v3, v3, Lcom/lib/activities/Loading$CircularLoadingView;->mPaintCenter:Landroid/graphics/Paint;

    move v4, v1

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 222
    move-object v3, v0

    iget-object v3, v3, Lcom/lib/activities/Loading$CircularLoadingView;->mPaintRound:Landroid/graphics/Paint;

    move v4, v1

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 223
    move-object v3, v0

    invoke-virtual {v3}, Lcom/lib/activities/Loading$CircularLoadingView;->postInvalidate()V

    return-void
.end method

.method public startAnim(I)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .prologue
    .line 227
    move-object v0, p0

    move v1, p1

    move-object v3, v0

    invoke-virtual {v3}, Lcom/lib/activities/Loading$CircularLoadingView;->stopAnim()V

    .line 228
    move-object v3, v0

    iget-object v3, v3, Lcom/lib/activities/Loading$CircularLoadingView;->mProgerssRotateAnim:Landroid/view/animation/RotateAnimation;

    move v4, v1

    int-to-long v4, v4

    invoke-virtual {v3, v4, v5}, Landroid/view/animation/RotateAnimation;->setDuration(J)V

    .line 229
    move-object v3, v0

    move-object v4, v0

    iget-object v4, v4, Lcom/lib/activities/Loading$CircularLoadingView;->mProgerssRotateAnim:Landroid/view/animation/RotateAnimation;

    invoke-virtual {v3, v4}, Lcom/lib/activities/Loading$CircularLoadingView;->startAnimation(Landroid/view/animation/Animation;)V

    return-void
.end method

.method public stopAnim()V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 233
    move-object v0, p0

    move-object v2, v0

    invoke-virtual {v2}, Lcom/lib/activities/Loading$CircularLoadingView;->clearAnimation()V

    return-void
.end method
