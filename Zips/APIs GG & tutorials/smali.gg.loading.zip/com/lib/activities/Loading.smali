# classes.dex

.class public Lcom/lib/activities/Loading;
.super Ljava/lang/Object;
.source "Loading.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/lib/activities/Loading$CircularLoadingView;,
        Lcom/lib/activities/Loading$100000000;
    }
.end annotation


# static fields
.field private static autoHideHandler:Landroid/os/Handler;

.field private static container:Landroid/widget/FrameLayout;

.field private static loadingView:Lcom/lib/activities/Loading$CircularLoadingView;

.field private static textView:Landroid/widget/TextView;


# direct methods
.method public constructor <init>()V
    .registers 4

    .prologue
    .line 235
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static addToWindow(Landroid/content/Context;)V
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")V"
        }
    .end annotation

    .prologue
    .line 76
    move-object v0, p0

    move-object v5, v0

    :try_start_2
    const-string v6, "window"

    invoke-virtual {v5, v6}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/view/WindowManager;

    move-object v2, v5

    .line 77
    move-object v5, v2

    if-eqz v5, :cond_34

    .line 79
    new-instance v5, Landroid/view/WindowManager$LayoutParams;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    invoke-direct {v6}, Landroid/view/WindowManager$LayoutParams;-><init>()V

    move-object v3, v5

    .line 80
    move-object v5, v3

    const/16 v6, 0x7f6

    iput v6, v5, Landroid/view/WindowManager$LayoutParams;->type:I

    .line 81
    move-object v5, v3

    const/4 v6, -0x1

    iput v6, v5, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 82
    move-object v5, v3

    const/4 v6, -0x1

    iput v6, v5, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 83
    move-object v5, v3

    const/16 v6, 0x118

    iput v6, v5, Landroid/view/WindowManager$LayoutParams;->flags:I

    .line 86
    move-object v5, v3

    const/4 v6, -0x3

    iput v6, v5, Landroid/view/WindowManager$LayoutParams;->format:I

    .line 89
    move-object v5, v2

    sget-object v6, Lcom/lib/activities/Loading;->container:Landroid/widget/FrameLayout;

    move-object v7, v3

    invoke-interface {v5, v6, v7}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_34
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_34} :catch_35

    .line 92
    :cond_34
    :goto_34
    return-void

    .line 89
    :catch_35
    move-exception v5

    move-object v2, v5

    .line 92
    move-object v5, v2

    invoke-virtual {v5}, Ljava/lang/Exception;->printStackTrace()V

    goto :goto_34
.end method

.method private static dpToPx(Landroid/content/Context;I)I
    .registers 9

    .prologue
    .line 150
    move-object v0, p0

    move v1, p1

    move-object v5, v0

    invoke-virtual {v5}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v5

    iget v5, v5, Landroid/util/DisplayMetrics;->density:F

    move v3, v5

    .line 151
    move v5, v1

    int-to-float v5, v5

    move v6, v3

    mul-float/2addr v5, v6

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    move v0, v5

    return v0
.end method

.method public static hide()V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 98
    sget-object v3, Lcom/lib/activities/Loading;->autoHideHandler:Landroid/os/Handler;

    if-eqz v3, :cond_11

    .line 99
    sget-object v3, Lcom/lib/activities/Loading;->autoHideHandler:Landroid/os/Handler;

    const/4 v4, 0x0

    check-cast v4, Ljava/lang/Object;

    invoke-virtual {v3, v4}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 100
    const/4 v3, 0x0

    check-cast v3, Landroid/os/Handler;

    sput-object v3, Lcom/lib/activities/Loading;->autoHideHandler:Landroid/os/Handler;

    .line 103
    :cond_11
    sget-object v3, Lcom/lib/activities/Loading;->container:Landroid/widget/FrameLayout;

    if-eqz v3, :cond_45

    .line 104
    sget-object v3, Lcom/lib/activities/Loading;->loadingView:Lcom/lib/activities/Loading$CircularLoadingView;

    if-eqz v3, :cond_1e

    .line 105
    sget-object v3, Lcom/lib/activities/Loading;->loadingView:Lcom/lib/activities/Loading$CircularLoadingView;

    invoke-virtual {v3}, Lcom/lib/activities/Loading$CircularLoadingView;->stopAnim()V

    .line 110
    :cond_1e
    :try_start_1e
    sget-object v3, Lcom/lib/activities/Loading;->container:Landroid/widget/FrameLayout;

    invoke-virtual {v3}, Landroid/widget/FrameLayout;->getContext()Landroid/content/Context;

    move-result-object v3

    const-string v4, "window"

    invoke-virtual {v3, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/view/WindowManager;

    move-object v1, v3

    .line 111
    move-object v3, v1

    if-eqz v3, :cond_36

    .line 112
    move-object v3, v1

    sget-object v4, Lcom/lib/activities/Loading;->container:Landroid/widget/FrameLayout;

    invoke-interface {v3, v4}, Landroid/view/WindowManager;->removeView(Landroid/view/View;)V
    :try_end_36
    .catch Ljava/lang/Exception; {:try_start_1e .. :try_end_36} :catch_46

    .line 118
    :cond_36
    :goto_36
    const/4 v3, 0x0

    check-cast v3, Lcom/lib/activities/Loading$CircularLoadingView;

    sput-object v3, Lcom/lib/activities/Loading;->loadingView:Lcom/lib/activities/Loading$CircularLoadingView;

    .line 119
    const/4 v3, 0x0

    check-cast v3, Landroid/widget/TextView;

    sput-object v3, Lcom/lib/activities/Loading;->textView:Landroid/widget/TextView;

    .line 120
    const/4 v3, 0x0

    check-cast v3, Landroid/widget/FrameLayout;

    sput-object v3, Lcom/lib/activities/Loading;->container:Landroid/widget/FrameLayout;

    :cond_45
    return-void

    .line 112
    :catch_46
    move-exception v3

    move-object v1, v3

    .line 115
    move-object v3, v1

    invoke-virtual {v3}, Ljava/lang/Exception;->printStackTrace()V

    goto :goto_36
.end method

.method private static scheduleAutoHide(I)V
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .prologue
    .line 137
    move v1, p0

    sget-object v4, Lcom/lib/activities/Loading;->autoHideHandler:Landroid/os/Handler;

    if-nez v4, :cond_13

    .line 138
    new-instance v4, Landroid/os/Handler;

    move-object v8, v4

    move-object v4, v8

    move-object v5, v8

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v6

    invoke-direct {v5, v6}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v4, Lcom/lib/activities/Loading;->autoHideHandler:Landroid/os/Handler;

    .line 141
    :cond_13
    sget-object v4, Lcom/lib/activities/Loading;->autoHideHandler:Landroid/os/Handler;

    new-instance v5, Lcom/lib/activities/Loading$100000000;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    invoke-direct {v6}, Lcom/lib/activities/Loading$100000000;-><init>()V

    move v6, v1

    int-to-long v6, v6

    invoke-virtual {v4, v5, v6, v7}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v4

    return-void
.end method

.method public static setColor(Ljava/lang/String;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 131
    move-object v0, p0

    sget-object v3, Lcom/lib/activities/Loading;->loadingView:Lcom/lib/activities/Loading$CircularLoadingView;

    if-eqz v3, :cond_f

    .line 132
    sget-object v3, Lcom/lib/activities/Loading;->loadingView:Lcom/lib/activities/Loading$CircularLoadingView;

    move-object v4, v0

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v3, v4}, Lcom/lib/activities/Loading$CircularLoadingView;->setViewColor(I)V

    :cond_f
    return-void
.end method

.method public static setText(Ljava/lang/String;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 125
    move-object v0, p0

    sget-object v3, Lcom/lib/activities/Loading;->textView:Landroid/widget/TextView;

    if-eqz v3, :cond_b

    .line 126
    sget-object v3, Lcom/lib/activities/Loading;->textView:Landroid/widget/TextView;

    move-object v4, v0

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_b
    return-void
.end method

.method public static show(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 20
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 26
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    invoke-static {}, Lcom/lib/activities/Loading;->hide()V

    .line 29
    new-instance v10, Landroid/widget/FrameLayout;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    sput-object v10, Lcom/lib/activities/Loading;->container:Landroid/widget/FrameLayout;

    .line 30
    sget-object v10, Lcom/lib/activities/Loading;->container:Landroid/widget/FrameLayout;

    new-instance v11, Landroid/view/ViewGroup$LayoutParams;

    move-object v15, v11

    move-object v11, v15

    move-object v12, v15

    const/4 v13, -0x1

    const/4 v14, -0x1

    invoke-direct {v12, v13, v14}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {v10, v11}, Landroid/widget/FrameLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 34
    sget-object v10, Lcom/lib/activities/Loading;->container:Landroid/widget/FrameLayout;

    const-string v11, "#80000000"

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-virtual {v10, v11}, Landroid/widget/FrameLayout;->setBackgroundColor(I)V

    .line 37
    new-instance v10, Lcom/lib/activities/Loading$CircularLoadingView;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    move-object v12, v0

    invoke-direct {v11, v12}, Lcom/lib/activities/Loading$CircularLoadingView;-><init>(Landroid/content/Context;)V

    sput-object v10, Lcom/lib/activities/Loading;->loadingView:Lcom/lib/activities/Loading$CircularLoadingView;

    .line 38
    move-object v10, v0

    const/16 v11, 0x64

    invoke-static {v10, v11}, Lcom/lib/activities/Loading;->dpToPx(Landroid/content/Context;I)I

    move-result v10

    move v5, v10

    .line 39
    new-instance v10, Landroid/widget/FrameLayout$LayoutParams;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    move v12, v5

    move v13, v5

    invoke-direct {v11, v12, v13}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    move-object v6, v10

    .line 40
    move-object v10, v6

    const/16 v11, 0x11

    iput v11, v10, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 41
    sget-object v10, Lcom/lib/activities/Loading;->loadingView:Lcom/lib/activities/Loading$CircularLoadingView;

    move-object v11, v6

    invoke-virtual {v10, v11}, Lcom/lib/activities/Loading$CircularLoadingView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 42
    sget-object v10, Lcom/lib/activities/Loading;->loadingView:Lcom/lib/activities/Loading$CircularLoadingView;

    move-object v11, v1

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-virtual {v10, v11}, Lcom/lib/activities/Loading$CircularLoadingView;->setViewColor(I)V

    .line 45
    new-instance v10, Landroid/widget/TextView;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    sput-object v10, Lcom/lib/activities/Loading;->textView:Landroid/widget/TextView;

    .line 46
    new-instance v10, Landroid/widget/FrameLayout$LayoutParams;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    const/4 v12, -0x2

    const/4 v13, -0x2

    invoke-direct {v11, v12, v13}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    move-object v7, v10

    .line 50
    move-object v10, v7

    const/16 v11, 0x11

    iput v11, v10, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 51
    move-object v10, v7

    move v11, v5

    const/4 v12, 0x2

    div-int/lit8 v11, v11, 0x2

    move-object v12, v0

    const/16 v13, 0x14

    invoke-static {v12, v13}, Lcom/lib/activities/Loading;->dpToPx(Landroid/content/Context;I)I

    move-result v12

    add-int/2addr v11, v12

    iput v11, v10, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 52
    sget-object v10, Lcom/lib/activities/Loading;->textView:Landroid/widget/TextView;

    move-object v11, v7

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 53
    sget-object v10, Lcom/lib/activities/Loading;->textView:Landroid/widget/TextView;

    move-object v11, v2

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 54
    sget-object v10, Lcom/lib/activities/Loading;->textView:Landroid/widget/TextView;

    const/4 v11, -0x1

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 55
    sget-object v10, Lcom/lib/activities/Loading;->textView:Landroid/widget/TextView;

    const/16 v11, 0x10

    int-to-float v11, v11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextSize(F)V

    .line 56
    sget-object v10, Lcom/lib/activities/Loading;->textView:Landroid/widget/TextView;

    sget-object v11, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 59
    sget-object v10, Lcom/lib/activities/Loading;->container:Landroid/widget/FrameLayout;

    sget-object v11, Lcom/lib/activities/Loading;->loadingView:Lcom/lib/activities/Loading$CircularLoadingView;

    invoke-virtual {v10, v11}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    .line 60
    sget-object v10, Lcom/lib/activities/Loading;->container:Landroid/widget/FrameLayout;

    sget-object v11, Lcom/lib/activities/Loading;->textView:Landroid/widget/TextView;

    invoke-virtual {v10, v11}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    .line 63
    move-object v10, v0

    invoke-static {v10}, Lcom/lib/activities/Loading;->addToWindow(Landroid/content/Context;)V

    .line 66
    move-object v10, v3

    invoke-static {v10}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v10

    move v8, v10

    .line 67
    sget-object v10, Lcom/lib/activities/Loading;->loadingView:Lcom/lib/activities/Loading$CircularLoadingView;

    move v11, v8

    invoke-virtual {v10, v11}, Lcom/lib/activities/Loading$CircularLoadingView;->startAnim(I)V

    .line 70
    move v10, v8

    invoke-static {v10}, Lcom/lib/activities/Loading;->scheduleAutoHide(I)V

    return-void
.end method
