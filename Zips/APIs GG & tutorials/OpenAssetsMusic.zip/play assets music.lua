

gg.OpenAssetsMusic("music.mp3")

--gg.OpenAssetsMusic("name your music in assets")