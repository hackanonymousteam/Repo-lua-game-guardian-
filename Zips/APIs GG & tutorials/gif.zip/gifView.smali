.class public Landroid/fix/gifView;
.super Landroid/fix/ImageView;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/fix/gifView$gifView$1;
    }
.end annotation


# instance fields
.field private attrs:Landroid/util/AttributeSet;

.field private gifImageHeight:I

.field private gifImageWidth:I

.field private gifMovie:Landroid/graphics/Movie;

.field private mMovieStart:J


# direct methods
.method static final constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 7

    .prologue
    .line 25
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    move-object v4, v1

    invoke-direct {v3, v4}, Landroid/fix/ImageView;-><init>(Landroid/content/Context;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 10

    .prologue
    .line 29
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    move-object v5, v1

    move-object v6, v2

    invoke-direct {v4, v5, v6}, Landroid/fix/ImageView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 30
    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Landroid/fix/gifView;->attrs:Landroid/util/AttributeSet;

    .line 31
    move-object v4, v0

    invoke-direct {v4}, Landroid/fix/gifView;->loadGifImage()V

    return-void
.end method

.method private loadGifImage()V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 38
    move-object v0, p0

    move-object v2, v0

    invoke-static {}, Landroid/ext/Tools;->e()Landroid/content/Context;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const v4, 0x88888888

    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->openRawResource(I)Ljava/io/InputStream;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/Movie;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Movie;

    move-result-object v3

    iput-object v3, v2, Landroid/fix/gifView;->gifMovie:Landroid/graphics/Movie;

    .line 39
    move-object v2, v0

    iget-object v2, v2, Landroid/fix/gifView;->gifMovie:Landroid/graphics/Movie;

    if-eqz v2, :cond_26

    .line 40
    move-object v2, v0

    const/16 v3, 0x8e

    iput v3, v2, Landroid/fix/gifView;->gifImageWidth:I

    .line 41
    move-object v2, v0

    const/16 v3, 0xc2

    iput v3, v2, Landroid/fix/gifView;->gifImageHeight:I

    :cond_26
    return-void
.end method

.method private showGifImage(Landroid/graphics/Canvas;)Z
    .registers 15

    .prologue
    .line 46
    move-object v1, p0

    move-object v2, p1

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v8

    move-wide v4, v8

    .line 47
    move-object v8, v1

    iget-wide v8, v8, Landroid/fix/gifView;->mMovieStart:J

    const-wide/16 v10, 0x0

    cmp-long v8, v8, v10

    if-nez v8, :cond_14

    .line 48
    move-object v8, v1

    move-wide v9, v4

    iput-wide v9, v8, Landroid/fix/gifView;->mMovieStart:J

    .line 50
    :cond_14
    move-object v8, v1

    iget-object v8, v8, Landroid/fix/gifView;->gifMovie:Landroid/graphics/Movie;

    invoke-virtual {v8}, Landroid/graphics/Movie;->duration()I

    move-result v8

    move v6, v8

    .line 51
    move v8, v6

    const/4 v9, 0x0

    if-ne v8, v9, :cond_23

    .line 52
    const/16 v8, 0xc8

    move v6, v8

    .line 54
    :cond_23
    move-object v8, v1

    iget-object v8, v8, Landroid/fix/gifView;->gifMovie:Landroid/graphics/Movie;

    move-wide v9, v4

    move-object v11, v1

    iget-wide v11, v11, Landroid/fix/gifView;->mMovieStart:J

    sub-long/2addr v9, v11

    move v11, v6

    int-to-long v11, v11

    rem-long/2addr v9, v11

    long-to-int v9, v9

    invoke-virtual {v8, v9}, Landroid/graphics/Movie;->setTime(I)Z

    move-result v8

    .line 55
    move-object v8, v2

    const/high16 v9, 0x3f000000  # 0.5f

    const/high16 v10, 0x3f000000  # 0.5f

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Canvas;->scale(FF)V

    .line 56
    move-object v8, v1

    iget-object v8, v8, Landroid/fix/gifView;->gifMovie:Landroid/graphics/Movie;

    move-object v9, v2

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-virtual {v8, v9, v10, v11}, Landroid/graphics/Movie;->draw(Landroid/graphics/Canvas;FF)V

    .line 57
    move-wide v8, v4

    move-object v10, v1

    iget-wide v10, v10, Landroid/fix/gifView;->mMovieStart:J

    sub-long/2addr v8, v10

    move v10, v6

    int-to-long v10, v10

    cmp-long v8, v8, v10

    if-gez v8, :cond_52

    .line 58
    const/4 v8, 0x0

    move v1, v8

    .line 61
    :goto_51
    return v1

    .line 60
    :cond_52
    move-object v8, v1

    const-wide/16 v9, 0x0

    iput-wide v9, v8, Landroid/fix/gifView;->mMovieStart:J

    .line 61
    const/4 v8, 0x1

    move v1, v8

    goto :goto_51
.end method


# virtual methods
.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/Canvas;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 66
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Landroid/fix/gifView;->gifMovie:Landroid/graphics/Movie;

    if-nez v3, :cond_d

    .line 67
    move-object v3, v0

    move-object v4, v1

    invoke-super {v3, v4}, Landroid/fix/ImageView;->onDraw(Landroid/graphics/Canvas;)V

    .line 71
    :goto_c
    return-void

    .line 70
    :cond_d
    move-object v3, v0

    move-object v4, v1

    invoke-direct {v3, v4}, Landroid/fix/gifView;->showGifImage(Landroid/graphics/Canvas;)Z

    move-result v3

    .line 71
    move-object v3, v0

    invoke-virtual {v3}, Landroid/fix/gifView;->invalidate()V

    goto :goto_c
.end method

.method protected onMeasure(II)V
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 76
    move-object v0, p0

    move v1, p1

    move v2, p2

    move-object v4, v0

    move v5, v1

    move v6, v2

    invoke-super {v4, v5, v6}, Landroid/fix/ImageView;->onMeasure(II)V

    .line 77
    move-object v4, v0

    iget-object v4, v4, Landroid/fix/gifView;->gifMovie:Landroid/graphics/Movie;

    if-eqz v4, :cond_18

    .line 78
    move-object v4, v0

    move-object v5, v0

    iget v5, v5, Landroid/fix/gifView;->gifImageWidth:I

    move-object v6, v0

    iget v6, v6, Landroid/fix/gifView;->gifImageHeight:I

    invoke-virtual {v4, v5, v6}, Landroid/fix/gifView;->setMeasuredDimension(II)V

    :cond_18
    return-void
.end method
