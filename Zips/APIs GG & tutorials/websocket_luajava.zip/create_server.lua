local Class = luajava.bindClass
local new = luajava.new

print("=== STARTING LOCAL WEBSOCKET SERVER ===")
print()

local ServerSocket = Class("java.net.ServerSocket")
local InputStreamReader = Class("java.io.InputStreamReader")
local BufferedReader = Class("java.io.BufferedReader")
local PrintWriter = Class("java.io.PrintWriter")
local BufferedOutputStream = Class("java.io.BufferedOutputStream")
local Thread = Class("java.lang.Thread")

function readBytes(inputStream, count)
    local arr = {}
    for i = 1, count do
        local b = inputStream:read()
        if b == -1 then return nil end
        arr[i] = b
    end
    return arr
end

function receiveFrame(socket)
    local inputStream = socket:getInputStream()

    local b1 = inputStream:read()
    if b1 == -1 then return nil end

    local b2 = inputStream:read()
    if b2 == -1 then return nil end

    local opcode = b1 & 0x0F
    local masked = (b2 & 0x80) ~= 0
    local payloadLen = b2 & 0x7F

    if payloadLen == 126 then
        local ext = readBytes(inputStream, 2)
        if not ext then return nil end
        payloadLen = (ext[1] << 8) | ext[2]
    elseif payloadLen == 127 then
        return nil
    end

    local mask
    if masked then
        mask = readBytes(inputStream, 4)
        if not mask then return nil end
    end

    local payload = readBytes(inputStream, payloadLen)
    if not payload then return nil end

    if masked then
        for i = 1, payloadLen do
            payload[i] = payload[i] ~ mask[((i - 1) % 4) + 1]
        end
    end

    return opcode, payload
end

function sendFrame(socket, opcode, payloadBytes)
    local outputStream = socket:getOutputStream()
    local len = #payloadBytes

    local headerSize = 2
    if len >= 126 then headerSize = 4 end

    local frame = luajava.newInstance("byte[" .. (headerSize + len) .. "]")

    frame[0] = 0x80 | opcode

    if len < 126 then
        frame[1] = len
        for i = 1, len do
            frame[i + 1] = payloadBytes[i]
        end
    else
        frame[1] = 126
        frame[2] = (len >> 8) & 0xFF
        frame[3] = len & 0xFF
        for i = 1, len do
            frame[i + 3] = payloadBytes[i]
        end
    end

    outputStream:write(frame)
    outputStream:flush()
end

function sendText(socket, text)
    local bytes = text:getBytes("UTF-8")
    local arr = {}
    for i = 0, #bytes - 1 do
        arr[i + 1] = bytes[i]
    end
    sendFrame(socket, 0x1, arr)
end

function sendPong(socket, payload)
    sendFrame(socket, 0xA, payload)
end

function sendClose(socket)
    sendFrame(socket, 0x8, {})
end

function handleClient(socket)
    local ok, err = pcall(function()
        local inputStream = socket:getInputStream()
        local outputStream = socket:getOutputStream()
        local reader = new(BufferedReader, new(InputStreamReader, inputStream))
        local writer = new(PrintWriter, new(BufferedOutputStream, outputStream), true)

        local key = ""
        while true do
            local line = reader:readLine()
            if not line or line == "" then break end
            if line:find("Sec%-WebSocket%-Key:") then
                key = line:match("Sec%-WebSocket%-Key:%s*(.+)")
            end
        end

        if key == "" then
            socket:close()
            return
        end

        local sha1 = Class("java.security.MessageDigest"):getInstance("SHA-1")
        local magic = key .. "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
        local hash = sha1:digest(magic:getBytes("ISO-8859-1"))
        local Base64 = Class("java.util.Base64")
        local accept = Base64:getEncoder():encodeToString(hash)

        local response =
            "HTTP/1.1 101 Switching Protocols\r\n" ..
            "Upgrade: websocket\r\n" ..
            "Connection: Upgrade\r\n" ..
            "Sec-WebSocket-Accept: " .. accept .. "\r\n\r\n"

        writer:print(response)
        writer:flush()

        while true do
            local opcode, payload = receiveFrame(socket)
            if not opcode then break end

            if opcode == 0x1 then
                local bytes = luajava.newInstance("byte[" .. #payload .. "]")
                for i = 1, #payload do
                    bytes[i - 1] = payload[i]
                end
                local msg = new(Class("java.lang.String"), bytes, "UTF-8")
                sendText(socket, "Echo: " .. msg)

            elseif opcode == 0x9 then
                sendPong(socket, payload)

            elseif opcode == 0x8 then
                sendClose(socket)
                break
            end
        end

        socket:close()
    end)

    if not ok then
        pcall(socket.close, socket)
    end
end
--[[
function startServer(port)
    local server = new(ServerSocket, port)

    local runnable = luajava.createProxy("java.lang.Runnable", {
        run = function()
            while true do
                local client = server:accept()
                local t = new(Thread, luajava.createProxy("java.lang.Runnable", {
                    run = function()
                        handleClient(client)
                    end
                }))
                t:start()
            end
        end
    })

    new(Thread, runnable):start()
    return server
end
]]


function startServer(port, durationMs)
    local server = new(ServerSocket, port)
    local running = true

    local runnable = luajava.createProxy("java.lang.Runnable", {
        run = function()
            while running do
                local ok, client = pcall(server.accept, server)
                if ok and client then
                    local t = new(Thread, luajava.createProxy("java.lang.Runnable", {
                        run = function()
                            handleClient(client)
                        end
                    }))
                    t:start()
                else
                    break
                end
            end
        end
    })

    local thread = new(Thread, runnable)
    thread:start()

    local timer = new(Thread, luajava.createProxy("java.lang.Runnable", {
        run = function()
            gg.sleep(durationMs)
            running = false
            pcall(server.close, server)
        end
    }))
    timer:start()

    return server
end
--local server = startServer(8081)
--print("Server running on ws://localhost:8081/")

local server = startServer(8083, 4000)
print("Server running  4s")