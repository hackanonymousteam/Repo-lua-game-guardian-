local Class = luajava.bindClass
local new = luajava.new

print("=== WEBSOCKET TEST - MULTIPLE SERVERS ===")

local Socket = Class("java.net.Socket")
local PrintWriter = Class("java.io.PrintWriter")
local BufferedReader = Class("java.io.BufferedReader")
local InputStreamReader = Class("java.io.InputStreamReader")
local DataInputStream = Class("java.io.DataInputStream")
local String = Class("java.lang.String")

function base64_encode(data)
    local chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    local result = {}
    for i = 1, #data, 3 do
        local b1, b2, b3 = string.byte(data, i, i + 2)
        b2 = b2 or 0
        b3 = b3 or 0
        local n = b1 * 65536 + b2 * 256 + b3
        table.insert(result, string.sub(chars, math.floor(n/262144)%64 + 1, math.floor(n/262144)%64 + 1))
        table.insert(result, string.sub(chars, math.floor(n/4096)%64 + 1, math.floor(n/4096)%64 + 1))
        if i + 1 > #data then
            table.insert(result, '==')
            break
        elseif i + 2 > #data then
            table.insert(result, string.sub(chars, math.floor(n/64)%64 + 1, math.floor(n/64)%64 + 1) .. '=')
            break
        else
            table.insert(result, string.sub(chars, math.floor(n/64)%64 + 1, math.floor(n/64)%64 + 1))
            table.insert(result, string.sub(chars, n%64 + 1, n%64 + 1))
        end
    end
    return table.concat(result)
end

function randomKey()
    local bytes = ""
    for i = 1, 16 do
        bytes = bytes .. string.char(math.random(0, 255))
    end
    return base64_encode(bytes)
end

function testWebSocket(host, port, path)
    print("\n--- Testing " .. host .. ":" .. port .. path .. " ---")
    
    local success, err = pcall(function()
        local socket = new(Socket, host, port)
        socket:setSoTimeout(5000)
        print("v Connected")
        
        local output = socket:getOutputStream()
        local input = socket:getInputStream()
        local writer = new(PrintWriter, output, true)
        local reader = new(BufferedReader, new(InputStreamReader, input))
        
        local key = randomKey()
        writer:print("GET " .. path .. " HTTP/1.1")
        writer:print("Host: " .. host)
        writer:print("Upgrade: websocket")
        writer:print("Connection: Upgrade")
        writer:print("Sec-WebSocket-Key: " .. key)
        writer:print("Sec-WebSocket-Version: 13")
        writer:print("")
        writer:flush()
        
        print("Response:")
        for i = 1, 30 do
            local line = reader:readLine()
            if line == nil then break end
            print("  " .. line)
            if line:find("101") then
                print("v HANDSHAKE OK!")
                
                local msg = "Hello!"
                local frame = luajava.newArray("byte", 6 + #msg)
                frame[1] = 0x81
                frame[2] = 0x80 | #msg
                for j = 1, 4 do frame[j+2] = math.random(0,255) end
                local mask = {frame[3], frame[4], frame[5], frame[6]}
                for j = 1, #msg do frame[j+6] = string.byte(msg, j) ~ mask[((j-1)%4)+1] end
                
                output:write(frame)
                output:flush()
                print("Sent: " .. msg)
                
                gg.sleep(500)
                local dis = new(DataInputStream, input)
                local b1 = dis:readByte()
                local b2 = dis:readByte()
                local len = b2 & 0x7F
                local resp = ""
                for j = 1, len do resp = resp .. string.char(dis:readByte()) end
                print("Received: " .. resp)
            end
            if line == "" then break end
        end
        
        socket:close()
    end)
    
    if not success then
        print("x Error: " .. tostring(err))
    end
end

testWebSocket("echo.websocket.org", 80, "/")
gg.sleep(1000)

testWebSocket("ws.ifelse.io", 80, "/")

print("\n=== END ===")


local Class = luajava.bindClass
local new = luajava.new

print("=== SIMPLE HTTP TEST ===")

local Socket = Class("java.net.Socket")
local PrintWriter = Class("java.io.PrintWriter")
local BufferedReader = Class("java.io.BufferedReader")
local InputStreamReader = Class("java.io.InputStreamReader")

local socket = new(Socket, "httpbin.org", 80)
socket:setSoTimeout(5000)
print("v Connected to httpbin.org")

local output = socket:getOutputStream()
local input = socket:getInputStream()
local writer = new(PrintWriter, output, true)
local reader = new(BufferedReader, new(InputStreamReader, input))

writer:print("GET /get HTTP/1.1")
writer:print("Host: httpbin.org")
writer:print("Connection: close")
writer:print("")
writer:flush()

print("\nHTTP Response:")
for i = 1, 50 do
    local line = reader:readLine()
    if line == nil then break end
    print(line)
end

socket:close()
print("\nv HTTP test completed!")