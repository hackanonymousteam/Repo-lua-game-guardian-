local Class = luajava.bindClass
local new = luajava.new
local astable = luajava.astable
local methods = luajava.methods

print("=== JAVA.NET.SOCKET COMPLETE FUNCTIONAL TEST ===")
print()

local Socket = Class("java.net.Socket")
local InetSocketAddress = Class("java.net.InetSocketAddress")
local InetAddress = Class("java.net.InetAddress")

print("1. CREATING SOCKET (CONSTRUCTORS):")
local socket = nil
local serverSocket = nil

local success1, err1 = pcall(function()
    socket = new(Socket)
    print("v Socket created (not connected): " .. tostring(socket))
    return true
end)

if not success1 then
    print("x Error creating socket:", err1)
    return
end
print()

print("2. CHECKING INITIAL STATE:")
local success2, err2 = pcall(function()
    print("isBound():", socket:isBound())
    print("isClosed():", socket:isClosed())
    print("isConnected():", socket:isConnected())
    print("isInputShutdown():", socket:isInputShutdown())
    print("isOutputShutdown():", socket:isOutputShutdown())
    return true
end)

if not success2 then
    print("x Error:", err2)
end
print()

print("3. TESTING ADDRESS GETTERS (without connection):")
local success3, err3 = pcall(function()
    local localAddr = socket:getLocalAddress()
    print("getLocalAddress():", tostring(localAddr))
    
    local localPort = socket:getLocalPort()
    print("getLocalPort():", tostring(localPort))
    
    local localSocketAddr = socket:getLocalSocketAddress()
    print("getLocalSocketAddress():", tostring(localSocketAddr))
    
    local port = socket:getPort()
    print("getPort():", tostring(port))
    
    local remoteAddr = socket:getRemoteSocketAddress()
    print("getRemoteSocketAddress():", tostring(remoteAddr))
    
    return true
end)

if not success3 then
    print("x Error:", err3)
end
print()

print("4. TESTING SOCKET OPTIONS (GETTERS):")
local success4, err4 = pcall(function()
    print("getKeepAlive():", socket:getKeepAlive())
    print("getOOBInline():", socket:getOOBInline())
    print("getReceiveBufferSize():", socket:getReceiveBufferSize())
    print("getReuseAddress():", socket:getReuseAddress())
    print("getSendBufferSize():", socket:getSendBufferSize())
    print("getSoLinger():", socket:getSoLinger())
    print("getSoTimeout():", socket:getSoTimeout())
    print("getTcpNoDelay():", socket:getTcpNoDelay())
    print("getTrafficClass():", socket:getTrafficClass())
    return true
end)

if not success4 then
    print("x Error:", err4)
end
print()

print("5. TESTING OPTION SETTERS:")
local success5, err5 = pcall(function()
    socket:setKeepAlive(true)
    print("v setKeepAlive(true) -> getKeepAlive():", socket:getKeepAlive())
    
    socket:setOOBInline(true)
    print("v setOOBInline(true) -> getOOBInline():", socket:getOOBInline())
    
    socket:setReuseAddress(true)
    print("v setReuseAddress(true) -> getReuseAddress():", socket:getReuseAddress())
    
    socket:setSoLinger(true, 10)
    print("v setSoLinger(true, 10) -> getSoLinger():", socket:getSoLinger())
    
    socket:setSoTimeout(5000)
    print("v setSoTimeout(5000) -> getSoTimeout():", socket:getSoTimeout())
    
    socket:setTcpNoDelay(true)
    print("v setTcpNoDelay(true) -> getTcpNoDelay():", socket:getTcpNoDelay())
    
    socket:setTrafficClass(0x10)
    print("v setTrafficClass(0x10) -> getTrafficClass():", socket:getTrafficClass())
    
    return true
end)

if not success5 then
    print("x Error:", err5)
end
print()

print("6. TESTING setPerformancePreferences:")
local success6, err6 = pcall(function()
    socket:setPerformancePreferences(1, 0, 2)
    print("v setPerformancePreferences(1, 0, 2) executed")
    return true
end)

if not success6 then
    print("x Error:", err6)
end
print()

print("7. TESTING OBJECT METHODS:")
local success7, err7 = pcall(function()
    print("toString():", socket:toString())
    print("hashCode():", tostring(socket:hashCode()))
    
    print("equals(self):", socket:equals(socket))
    
    return true
end)

if not success7 then
    print("x Error:", err7)
end
print()

print("8. CLOSING SOCKET:")
local success8, err8 = pcall(function()
    print("isClosed() before:", socket:isClosed())
    
    socket:close()
    print("v Socket closed")
    
    print("isClosed() after:", socket:isClosed())
    print("isConnected() after:", socket:isConnected())
    print("isBound() after:", socket:isBound())
    
    return true
end)

if not success8 then
    print("x Error:", err8)
end
print()