.class Lcom/codes/activities/FloatingButton$100000000;
.super Ljava/lang/Object;
.source "FloatingButton.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/codes/activities/FloatingButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# instance fields
.field private final this$0:Lcom/codes/activities/FloatingButton;


# direct methods
.method constructor <init>(Lcom/codes/activities/FloatingButton;)V
    .registers 7

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lcom/codes/activities/FloatingButton$100000000;->this$0:Lcom/codes/activities/FloatingButton;

    return-void
.end method

.method static access$0(Lcom/codes/activities/FloatingButton$100000000;)Lcom/codes/activities/FloatingButton;
    .registers 5

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lcom/codes/activities/FloatingButton$100000000;->this$0:Lcom/codes/activities/FloatingButton;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 60
    move-object v0, p0

    move-object v1, p1

    move-object v6, v0

    iget-object v6, v6, Lcom/codes/activities/FloatingButton$100000000;->this$0:Lcom/codes/activities/FloatingButton;

    invoke-virtual {v6}, Lcom/codes/activities/FloatingButton;->getContext()Landroid/content/Context;

    move-result-object v6

    move-object v3, v6

    .line 62
    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v7, 0x17

    if-lt v6, v7, :cond_4e

    .line 63
    move-object v6, v3

    invoke-static {v6}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v6

    if-nez v6, :cond_4e

    .line 64
    new-instance v6, Landroid/content/Intent;

    move-object v11, v6

    move-object v6, v11

    move-object v7, v11

    const-string v8, "android.settings.action.MANAGE_OVERLAY_PERMISSION"

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v11, v9

    move-object v9, v11

    move-object v10, v11

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    const-string v10, "package:"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    move-object v10, v3

    invoke-virtual {v10}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v9

    invoke-direct {v7, v8, v9}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    move-object v4, v6

    .line 68
    move-object v6, v4

    const/high16 v7, 0x10000000

    invoke-virtual {v6, v7}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v6

    .line 69
    move-object v6, v3

    move-object v7, v4

    invoke-virtual {v6, v7}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 77
    :goto_4d
    return-void

    .line 74
    :cond_4e
    move-object v6, v0

    iget-object v6, v6, Lcom/codes/activities/FloatingButton$100000000;->this$0:Lcom/codes/activities/FloatingButton;

    invoke-static {v6}, Lcom/codes/activities/FloatingButton;->access$L1000004(Lcom/codes/activities/FloatingButton;)Z

    move-result v6

    if-nez v6, :cond_5e

    .line 75
    move-object v6, v0

    iget-object v6, v6, Lcom/codes/activities/FloatingButton$100000000;->this$0:Lcom/codes/activities/FloatingButton;

    invoke-static {v6}, Lcom/codes/activities/FloatingButton;->access$1000017(Lcom/codes/activities/FloatingButton;)V

    .line 77
    :goto_5d
    goto :goto_4d

    :cond_5e
    move-object v6, v0

    iget-object v6, v6, Lcom/codes/activities/FloatingButton$100000000;->this$0:Lcom/codes/activities/FloatingButton;

    invoke-static {v6}, Lcom/codes/activities/FloatingButton;->access$1000018(Lcom/codes/activities/FloatingButton;)V

    goto :goto_5d
.end method
