.class Lcom/codes/activities/FloatingButton$100000001;
.super Ljava/lang/Object;
.source "FloatingButton.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/codes/activities/FloatingButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000001"
.end annotation


# instance fields
.field private initialTouchX:F

.field private initialTouchY:F

.field private initialX:I

.field private initialY:I

.field private final this$0:Lcom/codes/activities/FloatingButton;


# direct methods
.method constructor <init>(Lcom/codes/activities/FloatingButton;)V
    .registers 7

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lcom/codes/activities/FloatingButton$100000001;->this$0:Lcom/codes/activities/FloatingButton;

    return-void
.end method

.method static access$0(Lcom/codes/activities/FloatingButton$100000001;)Lcom/codes/activities/FloatingButton;
    .registers 5

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lcom/codes/activities/FloatingButton$100000001;->this$0:Lcom/codes/activities/FloatingButton;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .registers 11
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 202
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v2

    invoke-virtual {v4}, Landroid/view/MotionEvent;->getAction()I

    move-result v4

    packed-switch v4, :pswitch_data_82

    .line 219
    :pswitch_b  #0x1
    const/4 v4, 0x0

    move v0, v4

    :goto_d
    return v0

    .line 205
    :pswitch_e  #0x0
    move-object v4, v0

    move-object v5, v0

    iget-object v5, v5, Lcom/codes/activities/FloatingButton$100000001;->this$0:Lcom/codes/activities/FloatingButton;

    invoke-static {v5}, Lcom/codes/activities/FloatingButton;->access$L1000003(Lcom/codes/activities/FloatingButton;)Landroid/view/WindowManager$LayoutParams;

    move-result-object v5

    iget v5, v5, Landroid/view/WindowManager$LayoutParams;->x:I

    iput v5, v4, Lcom/codes/activities/FloatingButton$100000001;->initialX:I

    .line 206
    move-object v4, v0

    move-object v5, v0

    iget-object v5, v5, Lcom/codes/activities/FloatingButton$100000001;->this$0:Lcom/codes/activities/FloatingButton;

    invoke-static {v5}, Lcom/codes/activities/FloatingButton;->access$L1000003(Lcom/codes/activities/FloatingButton;)Landroid/view/WindowManager$LayoutParams;

    move-result-object v5

    iget v5, v5, Landroid/view/WindowManager$LayoutParams;->y:I

    iput v5, v4, Lcom/codes/activities/FloatingButton$100000001;->initialY:I

    .line 207
    move-object v4, v0

    move-object v5, v2

    invoke-virtual {v5}, Landroid/view/MotionEvent;->getRawX()F

    move-result v5

    iput v5, v4, Lcom/codes/activities/FloatingButton$100000001;->initialTouchX:F

    .line 208
    move-object v4, v0

    move-object v5, v2

    invoke-virtual {v5}, Landroid/view/MotionEvent;->getRawY()F

    move-result v5

    iput v5, v4, Lcom/codes/activities/FloatingButton$100000001;->initialTouchY:F

    .line 209
    const/4 v4, 0x1

    move v0, v4

    goto :goto_d

    .line 212
    :pswitch_39  #0x2
    move-object v4, v0

    iget-object v4, v4, Lcom/codes/activities/FloatingButton$100000001;->this$0:Lcom/codes/activities/FloatingButton;

    invoke-static {v4}, Lcom/codes/activities/FloatingButton;->access$L1000003(Lcom/codes/activities/FloatingButton;)Landroid/view/WindowManager$LayoutParams;

    move-result-object v4

    move-object v5, v0

    iget v5, v5, Lcom/codes/activities/FloatingButton$100000001;->initialX:I

    move-object v6, v2

    invoke-virtual {v6}, Landroid/view/MotionEvent;->getRawX()F

    move-result v6

    move-object v7, v0

    iget v7, v7, Lcom/codes/activities/FloatingButton$100000001;->initialTouchX:F

    sub-float/2addr v6, v7

    float-to-int v6, v6

    add-int/2addr v5, v6

    iput v5, v4, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 213
    move-object v4, v0

    iget-object v4, v4, Lcom/codes/activities/FloatingButton$100000001;->this$0:Lcom/codes/activities/FloatingButton;

    invoke-static {v4}, Lcom/codes/activities/FloatingButton;->access$L1000003(Lcom/codes/activities/FloatingButton;)Landroid/view/WindowManager$LayoutParams;

    move-result-object v4

    move-object v5, v0

    iget v5, v5, Lcom/codes/activities/FloatingButton$100000001;->initialY:I

    move-object v6, v2

    invoke-virtual {v6}, Landroid/view/MotionEvent;->getRawY()F

    move-result v6

    move-object v7, v0

    iget v7, v7, Lcom/codes/activities/FloatingButton$100000001;->initialTouchY:F

    sub-float/2addr v6, v7

    float-to-int v6, v6

    add-int/2addr v5, v6

    iput v5, v4, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 215
    move-object v4, v0

    iget-object v4, v4, Lcom/codes/activities/FloatingButton$100000001;->this$0:Lcom/codes/activities/FloatingButton;

    invoke-static {v4}, Lcom/codes/activities/FloatingButton;->access$L1000000(Lcom/codes/activities/FloatingButton;)Landroid/view/WindowManager;

    move-result-object v4

    move-object v5, v0

    iget-object v5, v5, Lcom/codes/activities/FloatingButton$100000001;->this$0:Lcom/codes/activities/FloatingButton;

    invoke-static {v5}, Lcom/codes/activities/FloatingButton;->access$L1000001(Lcom/codes/activities/FloatingButton;)Landroid/widget/LinearLayout;

    move-result-object v5

    move-object v6, v0

    iget-object v6, v6, Lcom/codes/activities/FloatingButton$100000001;->this$0:Lcom/codes/activities/FloatingButton;

    invoke-static {v6}, Lcom/codes/activities/FloatingButton;->access$L1000003(Lcom/codes/activities/FloatingButton;)Landroid/view/WindowManager$LayoutParams;

    move-result-object v6

    invoke-interface {v4, v5, v6}, Landroid/view/WindowManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 216
    const/4 v4, 0x1

    move v0, v4

    goto :goto_d

    .line 202
    :pswitch_data_82
    .packed-switch 0x0
        :pswitch_e  #00000000
        :pswitch_b  #00000001
        :pswitch_39  #00000002
    .end packed-switch
.end method
