.class Lcom/codes/activities/FloatingButton$100000004;
.super Ljava/lang/Object;
.source "FloatingButton.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/codes/activities/FloatingButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000004"
.end annotation


# instance fields
.field private final this$0:Lcom/codes/activities/FloatingButton;

.field private final val$context:Landroid/content/Context;


# direct methods
.method constructor <init>(Lcom/codes/activities/FloatingButton;Landroid/content/Context;)V
    .registers 9

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lcom/codes/activities/FloatingButton$100000004;->this$0:Lcom/codes/activities/FloatingButton;

    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lcom/codes/activities/FloatingButton$100000004;->val$context:Landroid/content/Context;

    return-void
.end method

.method static access$0(Lcom/codes/activities/FloatingButton$100000004;)Lcom/codes/activities/FloatingButton;
    .registers 5

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lcom/codes/activities/FloatingButton$100000004;->this$0:Lcom/codes/activities/FloatingButton;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 269
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lcom/codes/activities/FloatingButton$100000004;->this$0:Lcom/codes/activities/FloatingButton;

    invoke-virtual {v3}, Lcom/codes/activities/FloatingButton;->destroyMenu()V

    .line 270
    move-object v3, v0

    iget-object v3, v3, Lcom/codes/activities/FloatingButton$100000004;->val$context:Landroid/content/Context;

    const-string v4, "Tudo foi destruído"

    const/4 v5, 0x0

    invoke-static {v3, v4, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v3

    invoke-static {}, Landroid/ext/lh;->j()V

    return-void
.end method
