.class public Lcom/codes/activities/FloatingButton;
.super Landroid/widget/Button;
.source "FloatingButton.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/codes/activities/FloatingButton$100000000;,
        Lcom/codes/activities/FloatingButton$100000001;,
        Lcom/codes/activities/FloatingButton$100000002;,
        Lcom/codes/activities/FloatingButton$100000003;,
        Lcom/codes/activities/FloatingButton$100000004;
    }
.end annotation


# instance fields
.field private buttonX:I

.field private buttonY:I

.field private menuExpanded:Z

.field private menuLayout:Landroid/widget/LinearLayout;

.field private params:Landroid/view/WindowManager$LayoutParams;

.field private rootLayout:Landroid/widget/LinearLayout;

.field private windowManager:Landroid/view/WindowManager;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 7

    .prologue
    .line 33
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    move-object v4, v1

    invoke-direct {v3, v4}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 34
    move-object v3, v0

    invoke-direct {v3}, Lcom/codes/activities/FloatingButton;->init()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 10

    .prologue
    .line 38
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    move-object v5, v1

    move-object v6, v2

    invoke-direct {v4, v5, v6}, Landroid/widget/Button;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 39
    move-object v4, v0

    invoke-direct {v4}, Lcom/codes/activities/FloatingButton;->init()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 13

    .prologue
    .line 43
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move-object v5, v0

    move-object v6, v1

    move-object v7, v2

    move v8, v3

    invoke-direct {v5, v6, v7, v8}, Landroid/widget/Button;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 44
    move-object v5, v0

    invoke-direct {v5}, Lcom/codes/activities/FloatingButton;->init()V

    return-void
.end method

.method static synthetic access$1000017(Lcom/codes/activities/FloatingButton;)V
    .registers 5

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lcom/codes/activities/FloatingButton;->expandMenu()V

    return-void
.end method

.method static synthetic access$1000018(Lcom/codes/activities/FloatingButton;)V
    .registers 5

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lcom/codes/activities/FloatingButton;->collapseMenu()V

    return-void
.end method

.method static synthetic access$L1000000(Lcom/codes/activities/FloatingButton;)Landroid/view/WindowManager;
    .registers 5

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lcom/codes/activities/FloatingButton;->windowManager:Landroid/view/WindowManager;

    move-object v0, v3

    return-object v0
.end method

.method static synthetic access$L1000001(Lcom/codes/activities/FloatingButton;)Landroid/widget/LinearLayout;
    .registers 5

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lcom/codes/activities/FloatingButton;->rootLayout:Landroid/widget/LinearLayout;

    move-object v0, v3

    return-object v0
.end method

.method static synthetic access$L1000003(Lcom/codes/activities/FloatingButton;)Landroid/view/WindowManager$LayoutParams;
    .registers 5

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lcom/codes/activities/FloatingButton;->params:Landroid/view/WindowManager$LayoutParams;

    move-object v0, v3

    return-object v0
.end method

.method static synthetic access$L1000004(Lcom/codes/activities/FloatingButton;)Z
    .registers 5

    move-object v0, p0

    move-object v3, v0

    iget-boolean v3, v3, Lcom/codes/activities/FloatingButton;->menuExpanded:Z

    move v0, v3

    return v0
.end method

.method static synthetic access$S1000000(Lcom/codes/activities/FloatingButton;Landroid/view/WindowManager;)V
    .registers 8

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lcom/codes/activities/FloatingButton;->windowManager:Landroid/view/WindowManager;

    return-void
.end method

.method static synthetic access$S1000001(Lcom/codes/activities/FloatingButton;Landroid/widget/LinearLayout;)V
    .registers 8

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lcom/codes/activities/FloatingButton;->rootLayout:Landroid/widget/LinearLayout;

    return-void
.end method

.method static synthetic access$S1000003(Lcom/codes/activities/FloatingButton;Landroid/view/WindowManager$LayoutParams;)V
    .registers 8

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lcom/codes/activities/FloatingButton;->params:Landroid/view/WindowManager$LayoutParams;

    return-void
.end method

.method static synthetic access$S1000004(Lcom/codes/activities/FloatingButton;Z)V
    .registers 8

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    iput-boolean v5, v4, Lcom/codes/activities/FloatingButton;->menuExpanded:Z

    return-void
.end method

.method private collapseMenu()V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 278
    move-object v0, p0

    move-object v4, v0

    iget-object v4, v4, Lcom/codes/activities/FloatingButton;->windowManager:Landroid/view/WindowManager;

    if-eqz v4, :cond_1d

    move-object v4, v0

    iget-object v4, v4, Lcom/codes/activities/FloatingButton;->rootLayout:Landroid/widget/LinearLayout;

    if-eqz v4, :cond_1d

    move-object v4, v0

    iget-boolean v4, v4, Lcom/codes/activities/FloatingButton;->menuExpanded:Z

    if-eqz v4, :cond_1d

    .line 280
    move-object v4, v0

    :try_start_11
    iget-object v4, v4, Lcom/codes/activities/FloatingButton;->windowManager:Landroid/view/WindowManager;

    move-object v5, v0

    iget-object v5, v5, Lcom/codes/activities/FloatingButton;->rootLayout:Landroid/widget/LinearLayout;

    invoke-interface {v4, v5}, Landroid/view/WindowManager;->removeView(Landroid/view/View;)V

    .line 281
    move-object v4, v0

    const/4 v5, 0x0

    iput-boolean v5, v4, Lcom/codes/activities/FloatingButton;->menuExpanded:Z
    :try_end_1d
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_1d} :catch_1e

    .line 283
    :cond_1d
    :goto_1d
    return-void

    .line 281
    :catch_1e
    move-exception v4

    move-object v2, v4

    .line 283
    move-object v4, v2

    invoke-virtual {v4}, Ljava/lang/Exception;->printStackTrace()V

    goto :goto_1d
.end method

.method private expandMenu()V
    .registers 33
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 84
    move-object/from16 v2, p0

    move-object/from16 v22, v2

    invoke-virtual/range {v22 .. v22}, Lcom/codes/activities/FloatingButton;->getContext()Landroid/content/Context;

    move-result-object v22

    move-object/from16 v4, v22

    .line 85
    move-object/from16 v22, v2

    move-object/from16 v23, v4

    const-string v24, "window"

    invoke-virtual/range {v23 .. v24}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v23

    check-cast v23, Landroid/view/WindowManager;

    move-object/from16 v0, v23

    move-object/from16 v1, v22

    iput-object v0, v1, Lcom/codes/activities/FloatingButton;->windowManager:Landroid/view/WindowManager;

    .line 88
    const/16 v22, 0x2

    move/from16 v0, v22

    new-array v0, v0, [I

    move-object/from16 v22, v0

    move-object/from16 v5, v22

    .line 89
    move-object/from16 v22, v2

    move-object/from16 v23, v5

    invoke-virtual/range {v22 .. v23}, Lcom/codes/activities/FloatingButton;->getLocationOnScreen([I)V

    .line 90
    move-object/from16 v22, v2

    move-object/from16 v23, v5

    const/16 v24, 0x0

    aget v23, v23, v24

    move/from16 v0, v23

    move-object/from16 v1, v22

    iput v0, v1, Lcom/codes/activities/FloatingButton;->buttonX:I

    .line 93
    move-object/from16 v22, v2

    invoke-virtual/range {v22 .. v22}, Lcom/codes/activities/FloatingButton;->getHeight()I

    move-result v22

    move/from16 v6, v22

    .line 94
    move-object/from16 v22, v2

    move-object/from16 v23, v5

    const/16 v24, 0x1

    aget v23, v23, v24

    const/16 v24, 0x32

    add-int/lit8 v23, v23, -0x32

    move/from16 v0, v23

    move-object/from16 v1, v22

    iput v0, v1, Lcom/codes/activities/FloatingButton;->buttonY:I

    .line 96
    move-object/from16 v22, v2

    new-instance v23, Landroid/widget/LinearLayout;

    move-object/from16 v31, v23

    move-object/from16 v23, v31

    move-object/from16 v24, v31

    move-object/from16 v25, v4

    invoke-direct/range {v24 .. v25}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v0, v23

    move-object/from16 v1, v22

    iput-object v0, v1, Lcom/codes/activities/FloatingButton;->rootLayout:Landroid/widget/LinearLayout;

    .line 97
    move-object/from16 v22, v2

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/codes/activities/FloatingButton;->rootLayout:Landroid/widget/LinearLayout;

    move-object/from16 v22, v0

    const/16 v23, 0x1

    invoke-virtual/range {v22 .. v23}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 100
    new-instance v22, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v31, v22

    move-object/from16 v22, v31

    move-object/from16 v23, v31

    invoke-direct/range {v23 .. v23}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object/from16 v7, v22

    .line 101
    move-object/from16 v22, v7

    const-string v23, "#EE0A0A0A"

    invoke-static/range {v23 .. v23}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v23

    invoke-virtual/range {v22 .. v23}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 102
    move-object/from16 v22, v7

    const/16 v23, 0x3

    const-string v24, "#8B0000"

    invoke-static/range {v24 .. v24}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v24

    invoke-virtual/range {v22 .. v24}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 103
    move-object/from16 v22, v7

    const/16 v23, 0x14

    move/from16 v0, v23

    int-to-float v0, v0

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 105
    move-object/from16 v22, v2

    new-instance v23, Landroid/widget/LinearLayout;

    move-object/from16 v31, v23

    move-object/from16 v23, v31

    move-object/from16 v24, v31

    move-object/from16 v25, v4

    invoke-direct/range {v24 .. v25}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v0, v23

    move-object/from16 v1, v22

    iput-object v0, v1, Lcom/codes/activities/FloatingButton;->menuLayout:Landroid/widget/LinearLayout;

    .line 106
    move-object/from16 v22, v2

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/codes/activities/FloatingButton;->menuLayout:Landroid/widget/LinearLayout;

    move-object/from16 v22, v0

    const/16 v23, 0x1

    invoke-virtual/range {v22 .. v23}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 107
    move-object/from16 v22, v2

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/codes/activities/FloatingButton;->menuLayout:Landroid/widget/LinearLayout;

    move-object/from16 v22, v0

    move-object/from16 v23, v7

    invoke-virtual/range {v22 .. v23}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 108
    move-object/from16 v22, v2

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/codes/activities/FloatingButton;->menuLayout:Landroid/widget/LinearLayout;

    move-object/from16 v22, v0

    const/16 v23, 0x1e

    const/16 v24, 0x14

    const/16 v25, 0x1e

    const/16 v26, 0x14

    invoke-virtual/range {v22 .. v26}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 111
    new-instance v22, Landroid/widget/TextView;

    move-object/from16 v31, v22

    move-object/from16 v22, v31

    move-object/from16 v23, v31

    move-object/from16 v24, v4

    invoke-direct/range {v23 .. v24}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v8, v22

    .line 112
    move-object/from16 v22, v8

    const-string v23, "MOD MENU️"

    invoke-virtual/range {v22 .. v23}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 113
    move-object/from16 v22, v8

    const-string v23, "#8B0000"

    invoke-static/range {v23 .. v23}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v23

    invoke-virtual/range {v22 .. v23}, Landroid/widget/TextView;->setTextColor(I)V

    .line 114
    move-object/from16 v22, v8

    const/16 v23, 0x10

    move/from16 v0, v23

    int-to-float v0, v0

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Landroid/widget/TextView;->setTextSize(F)V

    .line 115
    move-object/from16 v22, v8

    const/16 v23, 0x0

    check-cast v23, Landroid/graphics/Typeface;

    const/16 v24, 0x1

    invoke-virtual/range {v22 .. v24}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 116
    move-object/from16 v22, v8

    const/16 v23, 0x11

    invoke-virtual/range {v22 .. v23}, Landroid/widget/TextView;->setGravity(I)V

    .line 118
    new-instance v22, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v31, v22

    move-object/from16 v22, v31

    move-object/from16 v23, v31

    const/16 v24, -0x1

    const/16 v25, -0x2

    invoke-direct/range {v23 .. v25}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v9, v22

    .line 122
    move-object/from16 v22, v9

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    const/16 v26, 0xf

    invoke-virtual/range {v22 .. v26}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 123
    move-object/from16 v22, v8

    move-object/from16 v23, v9

    invoke-virtual/range {v22 .. v23}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 126
    new-instance v22, Landroid/view/View;

    move-object/from16 v31, v22

    move-object/from16 v22, v31

    move-object/from16 v23, v31

    move-object/from16 v24, v4

    invoke-direct/range {v23 .. v24}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object/from16 v10, v22

    .line 127
    move-object/from16 v22, v10

    const-string v23, "#8B0000"

    invoke-static/range {v23 .. v23}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v23

    invoke-virtual/range {v22 .. v23}, Landroid/view/View;->setBackgroundColor(I)V

    .line 128
    new-instance v22, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v31, v22

    move-object/from16 v22, v31

    move-object/from16 v23, v31

    const/16 v24, -0x1

    const/16 v25, 0x2

    invoke-direct/range {v23 .. v25}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v11, v22

    .line 132
    move-object/from16 v22, v11

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    const/16 v26, 0xf

    invoke-virtual/range {v22 .. v26}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 133
    move-object/from16 v22, v10

    move-object/from16 v23, v11

    invoke-virtual/range {v22 .. v23}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 136
    new-instance v22, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v31, v22

    move-object/from16 v22, v31

    move-object/from16 v23, v31

    invoke-direct/range {v23 .. v23}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object/from16 v12, v22

    .line 137
    move-object/from16 v22, v12

    const-string v23, "#1A000000"

    invoke-static/range {v23 .. v23}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v23

    invoke-virtual/range {v22 .. v23}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 138
    move-object/from16 v22, v12

    const/16 v23, 0x2

    const-string v24, "#8B0000"

    invoke-static/range {v24 .. v24}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v24

    invoke-virtual/range {v22 .. v24}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 139
    move-object/from16 v22, v12

    const/16 v23, 0x14

    move/from16 v0, v23

    int-to-float v0, v0

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 141
    new-instance v22, Landroid/widget/Button;

    move-object/from16 v31, v22

    move-object/from16 v22, v31

    move-object/from16 v23, v31

    move-object/from16 v24, v4

    invoke-direct/range {v23 .. v24}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object/from16 v13, v22

    .line 142
    move-object/from16 v22, v13

    const-string v23, "execute️"

    invoke-virtual/range {v22 .. v23}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 143
    move-object/from16 v22, v13

    const-string v23, "#8B0000"

    invoke-static/range {v23 .. v23}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v23

    invoke-virtual/range {v22 .. v23}, Landroid/widget/Button;->setTextColor(I)V

    .line 144
    move-object/from16 v22, v13

    const/16 v23, 0xc

    move/from16 v0, v23

    int-to-float v0, v0

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Landroid/widget/Button;->setTextSize(F)V

    .line 145
    move-object/from16 v22, v13

    const/16 v23, 0x0

    check-cast v23, Landroid/graphics/Typeface;

    const/16 v24, 0x1

    invoke-virtual/range {v22 .. v24}, Landroid/widget/Button;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 146
    move-object/from16 v22, v13

    move-object/from16 v23, v12

    invoke-virtual/range {v22 .. v23}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 148
    new-instance v22, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v31, v22

    move-object/from16 v22, v31

    move-object/from16 v23, v31

    const/16 v24, 0xdc

    const/16 v25, 0x4b

    invoke-direct/range {v23 .. v25}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v14, v22

    .line 149
    move-object/from16 v22, v14

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    const/16 v26, 0xc

    invoke-virtual/range {v22 .. v26}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 150
    move-object/from16 v22, v13

    move-object/from16 v23, v14

    invoke-virtual/range {v22 .. v23}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 153
    new-instance v22, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v31, v22

    move-object/from16 v22, v31

    move-object/from16 v23, v31

    invoke-direct/range {v23 .. v23}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object/from16 v15, v22

    .line 154
    move-object/from16 v22, v15

    const-string v23, "#1A000000"

    invoke-static/range {v23 .. v23}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v23

    invoke-virtual/range {v22 .. v23}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 155
    move-object/from16 v22, v15

    const/16 v23, 0x2

    const-string v24, "#8B0000"

    invoke-static/range {v24 .. v24}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v24

    invoke-virtual/range {v22 .. v24}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 156
    move-object/from16 v22, v15

    const/16 v23, 0x14

    move/from16 v0, v23

    int-to-float v0, v0

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 158
    new-instance v22, Landroid/widget/Button;

    move-object/from16 v31, v22

    move-object/from16 v22, v31

    move-object/from16 v23, v31

    move-object/from16 v24, v4

    invoke-direct/range {v23 .. v24}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object/from16 v16, v22

    .line 159
    move-object/from16 v22, v16

    const-string v23, "Minimize"

    invoke-virtual/range {v22 .. v23}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 160
    move-object/from16 v22, v16

    const-string v23, "#8B0000"

    invoke-static/range {v23 .. v23}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v23

    invoke-virtual/range {v22 .. v23}, Landroid/widget/Button;->setTextColor(I)V

    .line 161
    move-object/from16 v22, v16

    const/16 v23, 0xc

    move/from16 v0, v23

    int-to-float v0, v0

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Landroid/widget/Button;->setTextSize(F)V

    .line 162
    move-object/from16 v22, v16

    const/16 v23, 0x0

    check-cast v23, Landroid/graphics/Typeface;

    const/16 v24, 0x1

    invoke-virtual/range {v22 .. v24}, Landroid/widget/Button;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 163
    move-object/from16 v22, v16

    move-object/from16 v23, v15

    invoke-virtual/range {v22 .. v23}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 165
    new-instance v22, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v31, v22

    move-object/from16 v22, v31

    move-object/from16 v23, v31

    const/16 v24, 0xdc

    const/16 v25, 0x4b

    invoke-direct/range {v23 .. v25}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v17, v22

    .line 166
    move-object/from16 v22, v17

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    const/16 v26, 0xc

    invoke-virtual/range {v22 .. v26}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 167
    move-object/from16 v22, v16

    move-object/from16 v23, v17

    invoke-virtual/range {v22 .. v23}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 170
    new-instance v22, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v31, v22

    move-object/from16 v22, v31

    move-object/from16 v23, v31

    invoke-direct/range {v23 .. v23}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object/from16 v18, v22

    .line 171
    move-object/from16 v22, v18

    const-string v23, "#1A000000"

    invoke-static/range {v23 .. v23}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v23

    invoke-virtual/range {v22 .. v23}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 172
    move-object/from16 v22, v18

    const/16 v23, 0x2

    const-string v24, "#8B0000"

    invoke-static/range {v24 .. v24}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v24

    invoke-virtual/range {v22 .. v24}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 173
    move-object/from16 v22, v18

    const/16 v23, 0x14

    move/from16 v0, v23

    int-to-float v0, v0

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 175
    new-instance v22, Landroid/widget/Button;

    move-object/from16 v31, v22

    move-object/from16 v22, v31

    move-object/from16 v23, v31

    move-object/from16 v24, v4

    invoke-direct/range {v23 .. v24}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object/from16 v19, v22

    .line 176
    move-object/from16 v22, v19

    const-string v23, "\ud83d\udc80 Exit \ud83d\udc80"

    invoke-virtual/range {v22 .. v23}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 177
    move-object/from16 v22, v19

    const-string v23, "#8B0000"

    invoke-static/range {v23 .. v23}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v23

    invoke-virtual/range {v22 .. v23}, Landroid/widget/Button;->setTextColor(I)V

    .line 178
    move-object/from16 v22, v19

    const/16 v23, 0xe

    move/from16 v0, v23

    int-to-float v0, v0

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Landroid/widget/Button;->setTextSize(F)V

    .line 179
    move-object/from16 v22, v19

    const/16 v23, 0x0

    check-cast v23, Landroid/graphics/Typeface;

    const/16 v24, 0x1

    invoke-virtual/range {v22 .. v24}, Landroid/widget/Button;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 180
    move-object/from16 v22, v19

    move-object/from16 v23, v18

    invoke-virtual/range {v22 .. v23}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 182
    new-instance v22, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v31, v22

    move-object/from16 v22, v31

    move-object/from16 v23, v31

    const/16 v24, 0xdc

    const/16 v25, 0x4b

    invoke-direct/range {v23 .. v25}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v20, v22

    .line 183
    move-object/from16 v22, v19

    move-object/from16 v23, v20

    invoke-virtual/range {v22 .. v23}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 185
    move-object/from16 v22, v2

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/codes/activities/FloatingButton;->menuLayout:Landroid/widget/LinearLayout;

    move-object/from16 v22, v0

    move-object/from16 v23, v8

    invoke-virtual/range {v22 .. v23}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 186
    move-object/from16 v22, v2

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/codes/activities/FloatingButton;->menuLayout:Landroid/widget/LinearLayout;

    move-object/from16 v22, v0

    move-object/from16 v23, v10

    invoke-virtual/range {v22 .. v23}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 187
    move-object/from16 v22, v2

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/codes/activities/FloatingButton;->menuLayout:Landroid/widget/LinearLayout;

    move-object/from16 v22, v0

    move-object/from16 v23, v13

    invoke-virtual/range {v22 .. v23}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 188
    move-object/from16 v22, v2

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/codes/activities/FloatingButton;->menuLayout:Landroid/widget/LinearLayout;

    move-object/from16 v22, v0

    move-object/from16 v23, v16

    invoke-virtual/range {v22 .. v23}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 189
    move-object/from16 v22, v2

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/codes/activities/FloatingButton;->menuLayout:Landroid/widget/LinearLayout;

    move-object/from16 v22, v0

    move-object/from16 v23, v19

    invoke-virtual/range {v22 .. v23}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 191
    move-object/from16 v22, v2

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/codes/activities/FloatingButton;->rootLayout:Landroid/widget/LinearLayout;

    move-object/from16 v22, v0

    move-object/from16 v23, v2

    move-object/from16 v0, v23

    iget-object v0, v0, Lcom/codes/activities/FloatingButton;->menuLayout:Landroid/widget/LinearLayout;

    move-object/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 192
    move-object/from16 v22, v2

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/codes/activities/FloatingButton;->menuLayout:Landroid/widget/LinearLayout;

    move-object/from16 v22, v0

    new-instance v23, Lcom/codes/activities/FloatingButton$100000001;

    move-object/from16 v31, v23

    move-object/from16 v23, v31

    move-object/from16 v24, v31

    move-object/from16 v25, v2

    invoke-direct/range {v24 .. v25}, Lcom/codes/activities/FloatingButton$100000001;-><init>(Lcom/codes/activities/FloatingButton;)V

    invoke-virtual/range {v22 .. v23}, Landroid/widget/LinearLayout;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 222
    move-object/from16 v22, v2

    new-instance v23, Landroid/view/WindowManager$LayoutParams;

    move-object/from16 v31, v23

    move-object/from16 v23, v31

    move-object/from16 v24, v31

    const/16 v25, -0x2

    const/16 v26, -0x2

    sget v27, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v28, 0x1a

    move/from16 v0, v27

    move/from16 v1, v28

    if-lt v0, v1, :cond_477

    const/16 v27, 0x7f6

    :goto_3c5
    const/16 v28, 0x8

    const/16 v29, -0x3

    invoke-direct/range {v24 .. v29}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    move-object/from16 v0, v23

    move-object/from16 v1, v22

    iput-object v0, v1, Lcom/codes/activities/FloatingButton;->params:Landroid/view/WindowManager$LayoutParams;

    .line 233
    move-object/from16 v22, v2

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/codes/activities/FloatingButton;->params:Landroid/view/WindowManager$LayoutParams;

    move-object/from16 v22, v0

    const v23, 0x800033

    move/from16 v0, v23

    move-object/from16 v1, v22

    iput v0, v1, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 234
    move-object/from16 v22, v2

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/codes/activities/FloatingButton;->params:Landroid/view/WindowManager$LayoutParams;

    move-object/from16 v22, v0

    move-object/from16 v23, v2

    move-object/from16 v0, v23

    iget v0, v0, Lcom/codes/activities/FloatingButton;->buttonX:I

    move/from16 v23, v0

    move/from16 v0, v23

    move-object/from16 v1, v22

    iput v0, v1, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 235
    move-object/from16 v22, v2

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/codes/activities/FloatingButton;->params:Landroid/view/WindowManager$LayoutParams;

    move-object/from16 v22, v0

    move-object/from16 v23, v2

    move-object/from16 v0, v23

    iget v0, v0, Lcom/codes/activities/FloatingButton;->buttonY:I

    move/from16 v23, v0

    move/from16 v24, v6

    add-int v23, v23, v24

    const/16 v24, 0x0

    add-int/lit8 v23, v23, 0x0

    move/from16 v0, v23

    move-object/from16 v1, v22

    iput v0, v1, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 237
    move-object/from16 v22, v2

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/codes/activities/FloatingButton;->windowManager:Landroid/view/WindowManager;

    move-object/from16 v22, v0

    move-object/from16 v23, v2

    move-object/from16 v0, v23

    iget-object v0, v0, Lcom/codes/activities/FloatingButton;->rootLayout:Landroid/widget/LinearLayout;

    move-object/from16 v23, v0

    move-object/from16 v24, v2

    move-object/from16 v0, v24

    iget-object v0, v0, Lcom/codes/activities/FloatingButton;->params:Landroid/view/WindowManager$LayoutParams;

    move-object/from16 v24, v0

    invoke-interface/range {v22 .. v24}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 238
    move-object/from16 v22, v2

    const/16 v23, 0x1

    move/from16 v0, v23

    move-object/from16 v1, v22

    iput-boolean v0, v1, Lcom/codes/activities/FloatingButton;->menuExpanded:Z

    .line 240
    move-object/from16 v22, v13

    new-instance v23, Lcom/codes/activities/FloatingButton$100000002;

    move-object/from16 v31, v23

    move-object/from16 v23, v31

    move-object/from16 v24, v31

    move-object/from16 v25, v2

    invoke-direct/range {v24 .. v25}, Lcom/codes/activities/FloatingButton$100000002;-><init>(Lcom/codes/activities/FloatingButton;)V

    invoke-virtual/range {v22 .. v23}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 258
    move-object/from16 v22, v16

    new-instance v23, Lcom/codes/activities/FloatingButton$100000003;

    move-object/from16 v31, v23

    move-object/from16 v23, v31

    move-object/from16 v24, v31

    move-object/from16 v25, v2

    move-object/from16 v26, v4

    invoke-direct/range {v24 .. v26}, Lcom/codes/activities/FloatingButton$100000003;-><init>(Lcom/codes/activities/FloatingButton;Landroid/content/Context;)V

    invoke-virtual/range {v22 .. v23}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 266
    move-object/from16 v22, v19

    new-instance v23, Lcom/codes/activities/FloatingButton$100000004;

    move-object/from16 v31, v23

    move-object/from16 v23, v31

    move-object/from16 v24, v31

    move-object/from16 v25, v2

    move-object/from16 v26, v4

    invoke-direct/range {v24 .. v26}, Lcom/codes/activities/FloatingButton$100000004;-><init>(Lcom/codes/activities/FloatingButton;Landroid/content/Context;)V

    invoke-virtual/range {v22 .. v23}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void

    .line 222
    :cond_477
    const/16 v27, 0x7d2

    goto/16 :goto_3c5
.end method

.method private init()V
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 48
    move-object v0, p0

    move-object v4, v0

    const-string v5, "open"

    invoke-virtual {v4, v5}, Lcom/codes/activities/FloatingButton;->setText(Ljava/lang/CharSequence;)V

    .line 49
    move-object v4, v0

    const/16 v5, 0xc

    int-to-float v5, v5

    invoke-virtual {v4, v5}, Lcom/codes/activities/FloatingButton;->setTextSize(F)V

    .line 50
    move-object v4, v0

    const/4 v5, 0x0

    check-cast v5, Landroid/graphics/Typeface;

    const/4 v6, 0x1

    invoke-virtual {v4, v5, v6}, Lcom/codes/activities/FloatingButton;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 52
    new-instance v4, Landroid/graphics/drawable/GradientDrawable;

    move-object v8, v4

    move-object v4, v8

    move-object v5, v8

    invoke-direct {v5}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v2, v4

    .line 53
    move-object v4, v2

    const-string v5, "#1A000000"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 54
    move-object v4, v2

    const/4 v5, 0x4

    const-string v6, "#8B0000"

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v4, v5, v6}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 55
    move-object v4, v2

    const/16 v5, 0x28

    int-to-float v5, v5

    invoke-virtual {v4, v5}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 56
    move-object v4, v0

    move-object v5, v2

    invoke-virtual {v4, v5}, Lcom/codes/activities/FloatingButton;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 57
    move-object v4, v0

    new-instance v5, Lcom/codes/activities/FloatingButton$100000000;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    move-object v7, v0

    invoke-direct {v6, v7}, Lcom/codes/activities/FloatingButton$100000000;-><init>(Lcom/codes/activities/FloatingButton;)V

    invoke-virtual {v4, v5}, Lcom/codes/activities/FloatingButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method


# virtual methods
.method public destroyMenu()V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 289
    move-object v0, p0

    move-object v4, v0

    iget-object v4, v4, Lcom/codes/activities/FloatingButton;->windowManager:Landroid/view/WindowManager;

    if-eqz v4, :cond_1d

    move-object v4, v0

    iget-object v4, v4, Lcom/codes/activities/FloatingButton;->rootLayout:Landroid/widget/LinearLayout;

    if-eqz v4, :cond_1d

    move-object v4, v0

    iget-boolean v4, v4, Lcom/codes/activities/FloatingButton;->menuExpanded:Z

    if-eqz v4, :cond_1d

    .line 291
    move-object v4, v0

    :try_start_11
    iget-object v4, v4, Lcom/codes/activities/FloatingButton;->windowManager:Landroid/view/WindowManager;

    move-object v5, v0

    iget-object v5, v5, Lcom/codes/activities/FloatingButton;->rootLayout:Landroid/widget/LinearLayout;

    invoke-interface {v4, v5}, Landroid/view/WindowManager;->removeView(Landroid/view/View;)V

    .line 292
    move-object v4, v0

    const/4 v5, 0x0

    iput-boolean v5, v4, Lcom/codes/activities/FloatingButton;->menuExpanded:Z
    :try_end_1d
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_1d} :catch_1e

    .line 294
    :cond_1d
    :goto_1d
    return-void

    .line 292
    :catch_1e
    move-exception v4

    move-object v2, v4

    .line 294
    move-object v4, v2

    invoke-virtual {v4}, Ljava/lang/Exception;->printStackTrace()V

    goto :goto_1d
.end method
