.class Lcom/codes/activities/FloatingButton$100000002;
.super Ljava/lang/Object;
.source "FloatingButton.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/codes/activities/FloatingButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000002"
.end annotation


# instance fields
.field private final this$0:Lcom/codes/activities/FloatingButton;


# direct methods
.method constructor <init>(Lcom/codes/activities/FloatingButton;)V
    .registers 7

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lcom/codes/activities/FloatingButton$100000002;->this$0:Lcom/codes/activities/FloatingButton;

    return-void
.end method

.method static access$0(Lcom/codes/activities/FloatingButton$100000002;)Lcom/codes/activities/FloatingButton;
    .registers 5

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lcom/codes/activities/FloatingButton$100000002;->this$0:Lcom/codes/activities/FloatingButton;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 244
    new-instance v1, Landroid/ext/hy;

    invoke-direct {v1}, Landroid/ext/hy;-><init>()V

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const-string v10, "gg.alert(\'by batman\')"

    move-object v3, v10

    .line 245
    move-object v10, v3

    move-object v4, v10

    .line 246
    const/4 v10, 0x0

    move v5, v10

    .line 247
    const-string v10, ""

    move-object v6, v10

    .line 249
    new-instance v10, Landroid/ext/Script;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    move-object v12, v4

    move v13, v5

    move-object v14, v6

    invoke-direct {v11, v12, v13, v14}, Landroid/ext/Script;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    move-object v7, v10

    .line 252
    move-object v10, v7

    invoke-virtual {v10}, Landroid/ext/Script;->c_()Landroid/ext/Script;

    move-result-object v10

    move-object v8, v10

    return-void
.end method
