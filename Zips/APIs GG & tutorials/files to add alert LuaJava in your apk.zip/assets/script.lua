local luajava = require("luajava")

local ActivityThread = luajava.bindClass("android.app.ActivityThread")
local LinearLayout = luajava.bindClass("android.widget.LinearLayout")
local Button = luajava.bindClass("android.widget.Button")
local TextView = luajava.bindClass("android.widget.TextView")
local Color = luajava.bindClass("android.graphics.Color")
local Gravity = luajava.bindClass("android.view.Gravity")
local Intent = luajava.bindClass("android.content.Intent")
local Uri = luajava.bindClass("android.net.Uri")
local LayoutParams = luajava.bindClass("android.view.WindowManager$LayoutParams")
local PixelFormat = luajava.bindClass("android.graphics.PixelFormat")
local GradientDrawable = luajava.bindClass("android.graphics.drawable.GradientDrawable")

local context = ActivityThread.currentApplication()
if not context then return end

local wm = context.getSystemService("window")

local mainLayout = LinearLayout(context)
mainLayout.setOrientation(LinearLayout.VERTICAL)
mainLayout.setGravity(Gravity.CENTER)
mainLayout.setPadding(50, 35, 50, 35)

local bgColor = "#1A1A1A" 
local strokeColor = "#FF0000"

local drawable = GradientDrawable()
drawable.setCornerRadius(8)
drawable.setStroke(3, Color.parseColor(strokeColor))
drawable.setColor(Color.parseColor(bgColor))

mainLayout.setBackgroundDrawable(drawable)

local scrollView = luajava.bindClass("android.widget.ScrollView")(context)
scrollView.addView(mainLayout)
scrollView.setBackgroundColor(Color.parseColor("#0A0A0A"))

local title = TextView(context)
title.setText("🩸 BATMAN  MOD🩸")
title.setTextColor(Color.parseColor("#FF0000"))
title.setTextSize(20)
title.setGravity(Gravity.CENTER)
title.setPadding(0, 10, 0, 5)
mainLayout.addView(title)

local subtitle = TextView(context)
subtitle.setText("created  by @batmangamesS ")
subtitle.setTextColor(Color.parseColor("#B22222"))
subtitle.setTextSize(14)
subtitle.setGravity(Gravity.CENTER)
subtitle.setPadding(0, 0, 0, 15)
mainLayout.addView(subtitle)

local subtitle2 = TextView(context)
subtitle2.setText("")
subtitle2.setTextColor(Color.parseColor("#B22222"))
subtitle2.setTextSize(14)
subtitle2.setGravity(Gravity.CENTER)
subtitle2.setPadding(0, 0, 0, 15)
mainLayout.addView(subtitle2)

local buttonsLayout = LinearLayout(context)
buttonsLayout.setOrientation(LinearLayout.HORIZONTAL)
buttonsLayout.setGravity(Gravity.CENTER)

local function createStrokeButton(text, bgColor, strokeColor)
    local btn = Button(context)
    btn.setText(text)
    btn.setTextColor(Color.parseColor("#FFFFFF"))
    btn.setGravity(Gravity.CENTER)
    btn.setPadding(25, 15, 25, 15)
    btn.setTextSize(13)
    
    local drawable = GradientDrawable()
    drawable.setColor(Color.parseColor(bgColor))
    drawable.setCornerRadius(8)
    drawable.setStroke(3, Color.parseColor(strokeColor))
    btn.setBackground(drawable)
    
    return btn
end

local btnAccess = createStrokeButton("Telegram", "#8B0000", "#FF0000")
local paramsAccess = LinearLayout.LayoutParams(-2, -2)
paramsAccess.setMargins(10, 0, 10, 0)
btnAccess.setLayoutParams(paramsAccess)

btnAccess.setOnClickListener(luajava.createProxy("android.view.View$OnClickListener", {
    onClick = function()
        local intent = Intent(Intent.ACTION_VIEW)
        intent.setData(Uri.parse("https://t.me/batmangamesSS"))
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    end
}))

local btnExit = createStrokeButton("⚰️ EXIT", "#1A0000", "#8B0000")
local paramsExit = LinearLayout.LayoutParams(-2, -2)
paramsExit.setMargins(10, 0, 10, 0)
btnExit.setLayoutParams(paramsExit)

btnExit.setOnClickListener(luajava.createProxy("android.view.View$OnClickListener", {
    onClick = function()
        pcall(function()
            wm.removeView(scrollView)
        end)
    end
}))

buttonsLayout.addView(btnAccess)
buttonsLayout.addView(btnExit)

mainLayout.addView(buttonsLayout)

local params = LayoutParams()
params.width = 500
params.height = -2
params.gravity = Gravity.CENTER
params.format = PixelFormat.RGBA_8888
params.type = LayoutParams.TYPE_APPLICATION_OVERLAY
params.flags = LayoutParams.FLAG_NOT_FOCUSABLE

wm.addView(scrollView, params)