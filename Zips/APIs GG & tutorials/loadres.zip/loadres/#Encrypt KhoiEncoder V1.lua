--#Encryption Khoi Script V4
---Telegram : KhoiScript


local g = {}
g.last = gg.getFile()
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
DATA = loadfile(g.config)
if DATA ~= nil then g.info = DATA() DATA = nil end
if g.info == nil then g.info = {g.last, g.last:gsub("/[^/]+$", "")} end

while true do
g.info = gg.prompt({
'[📁] Fɪʟᴇ :',
'[📁] Pᴀᴛʜ :',
'[🐧] Gay Emoji',
},g.info,{
"file",
"path",
"checkbox",
"checkbox",
})
if g.info == nil then
return
end
gg.saveVariable(g.info, g.config)
g.last = g.info[1]
if loadfile(g.last) == nil then
return gg.alert([[🤡SCRIPT NOT FOUND!🤡️]])
else
g.out = g.last:match("[^/]+$")
g.findn = g.out:match(".lua")
if g.findn == nil then 
g.out = g.out.."_enc.lua"
else
g.out = g.out:gsub("%.lua$","_enc.lua")
end
g.out = g.info[2] .. "/" .. g.out
local DATA = io.input(g.info[1]):read("*a")
local time = os.clock();local rand = math.random

--[[
╭━━━╮╱╱╱╱╱╱╱╱╱╱╭╮
┃╭━━╯╱╱╱╱╱╱╱╱╱╱┃┃
┃╰━━┳━╮╭━━┳━━┳━╯┣━━╮
┃╭━━┫╭╮┫╭━┫╭╮┃╭╮┃┃━┫
┃╰━━┫┃┃┃╰━┫╰╯┃╰╯┃┃━┫
╰━━━┻╯╰┻━━┻━━┻━━┻━━╯
]]
function simple(str) gb = {str:byte(1,-1)} return ''..table.concat(gb,",")..'' end
function ObfuscateFunction(code)
for k,v in pairs(gg) do
code=code:gsub('gg.'..k,'_ENV._G.gg[tostring(tostring(tostring("'..k..'",true),nil),false)]')
end--gg
for k,v in pairs(string) do
code=code:gsub('string.'..k,'_ENV._G.string[tostring(tostring(tostring("'..k..'",true),nil),false)]')
end--string
for k,v in pairs(debug) do
code=code:gsub('debug.'..k,'_ENV._G.debug[tostring(tostring(tostring("'..k..'",true),nil),false)]')
end--debug
for k,v in pairs(io) do
code=code:gsub('io.'..k,'_ENV._G.io[tostring(tostring(tostring("'..k..'",true),nil),false)]')
end--io
for k,v in pairs(os) do
code=code:gsub('os.'..k,'_ENV._G.os[tostring(tostring(tostring("'..k..'",true),nil),false)]')
end--os
for k,v in pairs(math) do
code=code:gsub('math.'..k,'_ENV._G.math[tostring(tostring(tostring("'..k..'",true),nil),false)]')
end--math
for k,v in pairs(table) do
code=code:gsub('table.'..k,'_ENV._G.table[tostring(tostring(tostring("'..k..'",true),nil),false)]')
end--table
local ALL_GG={'print','tostring','tonumber','assert','collectgarbage','dofile','error','getfenv','getmetatable','loadstring','loadfile','next','pcall','rawget','rawequal','xpcall'}
for k,v in ipairs(ALL_GG) do
code=code:gsub(v,'_ENV._G["'..v..'"]')
end--print
return code
end
DATA=ObfuscateFunction(DATA)
function EncodeBit32(text)
local inv256 = {}
for i = 1,string.len(text)  do
local cnome = string.byte(text,i,i)
inv256[i] = "\\"..bit32.bxor(cnome,(300507 + 0xFA + 0x45 + 0xEB + 0x495DB + 0x45 + 0xEB + 0xEA / 0xC23)%256)
end
return table.concat(inv256) end
function bitch(s,a)
local res = ""
for i = 1,#s do
res = res .. string.char((a*s:byte(i)) % 256)
end
return res
end

function encrypt(s)
return bitch(s,3)
end
local H = "qwertyuiopasdfghjklzxcvbnm9QWERTYUIOPASDFGHJKLZXCVBNM"
hex = {}
local HexToDec={--Base16 Chars
   ['A']= 0, ['B'] =1, ['C'] =2, ['D'] =3, ['E'] =4, ['F'] =5, ['G'] =6, ['H'] =7, 
   ['I']=8,  ['J'] =9, ['K']=10, ['L']=11, ['M']=12, ['N']=13, ['O']=14, ['P']=15, 
   ['Q']=16, ['R']=17, ['S']=18, ['T']=19, ['U']=20, ['V']=21, ['W']=22, ['X']=23, 
   ['Y']=24, ['Z']=25, ['a']=26, ['b']=27, ['c']=28, ['d']=29, ['e']=30, ['f']=31, 
   ['g']=32, ['h']=33, ['i']=34, ['j']=35, ['k']=36, ['l']=37, ['m']=38, ['n']=39, 
   ['o']=40, ['p']=41, ['q']=42, ['r']=43, ['s']=44, ['t']=45, ['u']=46, ['v']=47, 
   ['w']=48, ['x']=49, ['y']=50, ['z']=51, ['0']=52, ['1']=53, ['2']=54, ['3']=55, 
   ['4']=56, ['5']=57, ['6']=58, ['7']=59, ['8']=60, ['9']=61, ['-']=62, ['_']=63,
   ['@']=64, ['#']=65, ['+']=66, ['/']=67, ['=']=68, ['^']=69, ['|']=70
}
local DecToHex='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_@#+/=^|'
local function char(S, i)
local B1 = HexToDec[S:sub(i,i)]
local B2 = HexToDec[S:sub(i+1,i+1)]
local C = B1 *35 + B2
return C
end
function base16(S)
local T = {}
local j = 1
local B
for i=1, #S do
B = S:byte(i) / 35 + 1
T[j] = DecToHex:sub(B,B)
B = S:byte(i) % 35 + 1
T[j+1] = DecToHex:sub(B,B)
j = j + 2
end
return table.concat(T)
end
_c = math.random(255,255)
_c1 = math.random(90,90)
local Sx = {}
local Table = {} Keya = {} for i = 1,1000 do
A = math.random(1100,1100) table.insert(Keya,A) end
for i = 1,2 do
Keya[i] = Keya[i] + math.random(1100,1100) 
end
for i in ipairs(Keya) do
C = (Keya[i] + i - _c - (_c1 + i) * (1 + i)) % 256
table.insert(Sx, C)
end
local KY8 = {(Keya[3]+Keya[5]*Keya[7])-Keya[9]+Keya[2]}
local KY9 = {(Keya[5]+Keya[4]-Keya[3])+Keya[8]-Keya[9]}
T = math.random(190, 340) TT = math.random(1, 30)
TTT = math.random(290, 470) NDTKey = {}
for i = 1,50 do G = TT + T - TTT * math.random(9, 540)
table.insert(NDTKey, G) end table.concat(NDTKey,",")
local Key = {(NDTKey[1]-NDTKey[4])+NDTKey[2],NDTKey[9]+NDTKey[18]-NDTKey[6],NDTKey[46]+NDTKey[24],NDTKey[10],NDTKey[31]-NDTKey[14]*NDTKey[19],NDTKey[17]+NDTKey[3]-NDTKey[1],NDTKey[33]*NDTKey[13]+NDTKey[12],NDTKey[9]-NDTKey[23]}
local Ky = {(NDTKey[1]-NDTKey[3])+NDTKey[7],NDTKey[5]+NDTKey[9]-NDTKey[11],NDTKey[4]+NDTKey[19],NDTKey[10],NDTKey[31]-NDTKey[44]*NDTKey[30]}
local Kei = {(NDTKey[6]+NDTKey[5]*NDTKey[27]-NDTKey[16]+NDTKey[22]*NDTKey[44])-NDTKey[2],NDTKey[23]+NDTKey[47]-NDTKey[5]*NDTKey[9]-NDTKey[22],NDTKey[36]+NDTKey[45]-NDTKey[33]*NDTKey[27],NDTKey[37]-NDTKey[49]*NDTKey[44],NDTKey[17]*NDTKey[28]-NDTKey[31],NDTKey[21]+NDTKey[11],NDTKey[24]*NDTKey[50],NDTKey[46]-NDTKey[47]}
DATA=DATA:gsub('gg%.getResults%([^%)]*%)', function(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z)
a=a:gsub("%d+",'_G["tonumber"]("%1")')
return a
end)
local chars = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
local base58 = function(s) local q, r, b
local et = {} local r = 0 local zn = 0 local nt = {}
local dt = {} local bt = {} 
local more = true for i = 1, #s do 
b = string.byte(s, i) if more and b == 0 then
zn = zn + 1 else more = false end nt[i] = b end
if #s == zn then return string.rep('1', zn) end
more = true
while more do local r = 0 more = false for i = 1, #nt do
b = nt[i] + (256 * r) q = b // 58 more = more or q > 0
r = b % 58 dt[i] = q end table.insert(et, 1, string.char(string.byte(chars, r+1)))
nt = {} for i = 1, #dt do nt[i] = dt[i] end dt = {} end
return string.rep('1', zn) .. table.concat(et) 
end
local index_table = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
function to_binary(integer)
    local remaining = tonumber(integer)
    local bin_bits = ''
    for i = 7, 0, -1 do
        local current_power = 2 ^ i
        if remaining >= current_power then
            bin_bits = bin_bits .. '1'
            remaining = remaining - current_power
        else
            bin_bits = bin_bits .. '0'
        end
    end
    return bin_bits
end

function from_binary(bin_bits)
    return tonumber(bin_bits, 2)
end

function base64(to_encode)
    local bit_pattern = ''
    local encoded = ''
    local trailing = ''
    for i = 1, string.len(to_encode) do
        bit_pattern = bit_pattern .. to_binary(string.byte(string.sub(to_encode, i, i)))
    end
    if string.len(bit_pattern) % 3 == 2 then
        trailing = '=='
        bit_pattern = bit_pattern .. '0000000000000000'
    elseif string.len(bit_pattern) % 3 == 1 then
        trailing = '='
        bit_pattern = bit_pattern .. '00000000'
    end
    for i = 1, string.len(bit_pattern), 6 do
        local byte = string.sub(bit_pattern, i, i+5)
        local offset = tonumber(from_binary(byte))
        encoded = encoded .. string.sub(index_table, offset+1, offset+1)
    end
    return string.sub(encoded, 1, -1 - string.len(trailing)) .. trailing
end

function KhoiTommiXiaomi(text)
return "__KhoiEncode('"..EncodeBit32(text).."')"end
function encodevl(c)
return "_KhoiEncode([=[" .. encrypt(c) .. "]=])"
end

function encodegg(c)
return "gg[_KhoiEncode([=[" .. encrypt(c) .. "]=])]("
end

function encodeos(c)
return "os[_KhoiEncode([=[" .. encrypt(c) .. "]=])]("
end

function encodepr(c)
return "print[_KhoiEncode([=[" .. encrypt(c) .. "]=])]("
end

function encodeio(c)
return "io[_KhoiEncode([=[" .. encrypt(c) .. "]=])]("
end

function encodedb(c)
return "debug[_KhoiEncode([=[" .. encrypt(c) .. "]=])]("
end

function encodestr(c)
return "string[_KhoiEncode([=[" .. encrypt(c) .. "]=])]("
end

function encodetos(c)
return "tostring[_KhoiEncode([=[" .. encrypt(c) .. "]=])]("
end
function Base16_1(A0_67)
return 'gg[KhoiEncode_("' .. base16(A0_67) .. '")]('
end
function Base16(A0_67)
return '' .. enc(A0_67) .. ')'
end
function Base16_2(A0_68)
return 'os[KhoiEncode_("' .. base16(A0_68) ..'")]('
end
function Base16_3(A0_69)
return 'string[KhoiEncode_(' .. base16(A0_69) .. ')]('
end
function Base16_4(A0_70)
return 'KhoiEncode_("' .. base16(A0_70) .. '")'
end
function encode2(c)
return 'KhoiEncode__("' .. base58(c) .. '")'
end
function encode64(c)
return 'KhoiEncode___("' .. base64(c) .. '")'
end

--[[
╭━━━╮╱╱╱╱╱╭╮
┃╭━╮┃╱╱╱╱╱┃┃
┃┃╱╰╋━━┳╮╭┫╰━╮
┃┃╭━┫━━┫┃┃┃╭╮┃
┃╰┻━┣━━┃╰╯┃╰╯┃
╰━━━┻━━┻━━┻━━╯
]]
DATA = string.gsub(DATA, "os%.(%a+)%(", encodeos)
DATA = string.gsub(DATA, "print%.(%a+)%(", encodepr)
DATA = string.gsub(DATA, "io%.(%a+)%(", encodeio)
DATA = string.gsub(DATA, "debug%.(%a+)%(", encodedb)
DATA = string.gsub(DATA, "string%.(%a+)%(", encodestr)
DATA = string.gsub(DATA, "tostring%.(%a+)%(", encodetos)
DATA = string.gsub(DATA, "gg%.(%a+)%(", encodegg)
DATA = string.gsub(DATA, "gg%.(prompt)%(", encodegg)
DATA = string.gsub(DATA, "gg%.(multiChoice)%(", encodegg)
DATA = string.gsub(DATA, "gg%.(choice)%(", encodegg)
DATA = string.gsub(DATA, "gg%.(clearResults)%(", encodegg)
DATA = string.gsub(DATA, "gg%.(setRanges)%(", encodegg)
DATA = string.gsub(DATA, "gg%.(SIGN_EQUAL)%(", encodegg)
DATA = string.gsub(DATA, "gg%.(searchNumber)%(", encodegg)
DATA = string.gsub(DATA, "gg%.(refineNumber)%(", encodegg)
DATA = string.gsub(DATA, "gg%.(getResults)%(", encodegg)
DATA = string.gsub(DATA, "gg%.(editAll)%(", encodegg)
DATA = string.gsub(DATA, "gg%.(toast)%(", encodegg)
DATA = string.gsub(DATA, "gg%.(alert)%(", encodegg)
DATA = string.gsub(DATA, "gg%.(getResultCount)%(", encodegg)
DATA = string.gsub(DATA, "gg%.(resultsCount)%(", encodegg)
DATA = string.gsub(DATA, "gg%.(addListItems)%(", encodegg)
DATA = string.gsub(DATA, "gg%.(sleep)%(", encodegg)
DATA = string.gsub(DATA, "gg%.(setValues)%(", encodegg)
DATA = string.gsub(DATA,'%".-(.-)%"', encodevl)
DATA = string.gsub(DATA,'%[%[.-(.-)%]%]',encodevl)
DATA=DATA:gsub('"(.-)"', function(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z)
return encode2(a)
end)
DATA=DATA:gsub('"(.-)"', function(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z)
return encode64(a)
end)

Blocker=([[
gg.toast(string.char(0x45,0x6e,0x63,0x72,0x79,0x70,0x74,0x65,0x64,0x20,0x42,0x79,0x20,0xc6,0x98,0xc9,0xa6,0xcf,0x83,0xce,0xb9,0x20,0x53,0x63,0xca,0x80,0xce,0xb9,0xe1,0xb4,0x98,0xe1,0xb4,0x9b))
gg.clearResults()
local _Error404_ = function(str)
conme =[=[]=] return conme .. string.char(table.unpack(str)) end
gg.toast("Connecting To Server...🐧")
local save = {}
for i = 1, 52000 do table.insert(save, {["address"] = 131 + i,  ["flags"] = 4,  ["values"] = 520}) end
for i = 1, 52000 do table.insert(save, {["address"] = 131 + i,  ["flags"] = 4,  ["values"] = 520}) end
gg.toast("Connecting 5%...")
gg.removeListItems(save)
for i = 1, 6 do gg.addListItems(save) end
gg.removeListItems(save)
local save = {}
for i = 1, 5000 do table.insert(save, {["address"] = 16 + i,  ["flags"] = 4,  ["values"] = 72}) end 
gg.toast("Connecting 10%...")
for i = 1, 5000 do table.insert(save, {["address"] = 16 + i,  ["flags"] = 4,  ["values"] = 72}) end
for i = 1, 5000 do table.insert(save, {["address"] = 16 + i,  ["flags"] = 4,  ["values"] = 72}) end
gg.toast("Connecting 20%...")
local time = os.time()
local clock = os.clock()

for i = 1, 6 do gg.addListItems(save) end

gg.removeListItems(save)
local time = os.time()
local clock = os.clock()

for i = 1, 6 do gg.addListItems(save) end

gg.removeListItems(save)
local time2, clock2, a = os.time(), os.clock(), "Damn log, you're going to get the hell out of here"
if time2 < time then
return gg.alert("Damn log, you're going to get the hell out of here", "")
end 
if time2 > time then
a = "Damn log, you're going to get the hell out of here"
end
if os.difftime(time2, time) > 2 then
return gg.alert(a, "")
end

if clock2 < clock then
return gg.alert("Damn log, you're going to get the hell out of here", "")
end
if clock2 > clock then
a = "Damn log, you're going to get the hell out of here"
end
if os.difftime(clock2, clock) > 2 then
return gg.alert(a, "")
end 
gg.toast("Connecting 30%...")

local _0c = string["rep"](string["char"](0x0),math["random"](97,9987),"Noob ~ Log") .. string["rep"]("๑۞๑,¸¸,ø¤º°°๑۩ [ 懵�,酶陇潞掳掳潞陇酶,赂赂,酶陇潞掳 [馃Х ] 掳潞陇酶,赂赂,酶陇潞掳掳潞陇酶,赂,-*'^'~*-.,_,.-*~ [] ~*-.,_,.-*~'^'*-,T檀y檀p檀e檀 s檀o檀m檀e檀t猥蜂紡猥糕鐗光猥峰姞猥糕鐗涒猥烽€尖檀h檀i檀n檀g檀  ?�    ] ๑۩ ,¸¸,ø¤º°°๑۞๑", math["random"](985,9798))
s = {} for ii = 1,1025 do s[ii] = _0c end 
for iii,iiii in pairs({debug["traceback"],debug["getinfo"],gg["searchNumber"],gg["alert"],gg["editAll"]}) do pcall(iiii, s) end
do
local _1M,_1G
_1M = _ENV['string']['rep']('\n', 1024 * 1024)
_1G = {}
local Pcall=_ENV['pcall']
local Pairs = _ENV['pairs']
local debug_getinfo=_ENV['debug']['getinfo']
local string_match=_ENV['string']['match']
local Tostring=_ENV['tostring']
local math_random=_ENV['math']['random']
for index = 1, 1024 do
_1G[index] = _1M
end
_ENV['\n'] = _1G
for index, value in Pairs({_ENV['string']['find'],string_match, _ENV['string']['dump'],_ENV['gg']['toast'],_ENV['gg']['alert'], _ENV['gg']['bytes'], debug_getinfo, Tostring}) do
Pcall(value, _1G)
end
local Table,xxxx
Table = {Tostring,_ENV['string']['find'], string_match, Pairs}
for index, value in Pairs(Table) do
local txt1 = Tostring(value)
for index=1,math_random(100,200)do Pcall(value,txt1,'@')
end end
for index, value in Pairs({_ENV['table'],_ENV['debug'], _ENV['gg'], _ENV['os'], _ENV['io'], _ENV['bit32'], _ENV['utf8'], _ENV['string'], _ENV['math']}) do
local  index = Tostring(value)
local  xxxx = string_match(index, "@")
while (xxxx) do
end end
for index, value in Pairs({"tostring", "load", "ipairs", "pcall", "assert2", "loadfile","pairs", "error", "tonumber", "xpcall", "assert", "dofile", "print", "type"}) do
local value = _ENV[value]
local index = Tostring(value)
local xxxx = string_match(index, "@")
while (xxxx) do end end
local Info={}
for index=1,math_random(100,200) do
Pcall(function()
Info[index]=debug_getinfo(index+4)
end) end
xxxx=Info[#Info]['istailcall']
while xxxx do end end
gg.toast("Connecting 50%...")
for kk=1,10 do
for i=1,255 do
local char=string.char(i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i)
local char=string.char(i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i)
local char=string.char(i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i)
local char=string.char(i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i)
local char=string.char(i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i)
local char=string.char(i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i)
local char=string.char(i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i,i-1,i,i,i,i,i,i,i)
local char=string.char(99,104,97,114,232,167,163,229,175,134,228,189,160,229,166,136,239,188,159,229,164,169,229,164,169,230,139,191,228,184,170,229,136,171,228,186,186,229,183,165,229,133,183,229,156,168,232,191,153,233,135,140,232,128,128,230,173,166,230,137,172,229,168,129,32,231,156,159,231,156,139,228,184,141,232,181,183,228,189,160,232,191,153,231,167,141,228,186,186)
end end
gg.toast("Connecting 60%...")
local dZvT=string.rep(" ",1048576)
sOaJ={}
for cInW=1,1024 do
sOaJ[cInW]=dZvT
end dZvT=nil
for dLrV, wNjO in pairs({gg.alert,gg.bytes,gg.copyText,gg.searchAddress,gg.searchNumber,gg.toast}) do
pcall(wNjO,sOaJ)
end
gg.toast("Connecting 70%...")
Test = {}
for _FORV_3_ = 1, 999 do
table.insert(Test, {address = 127 + _FORV_3_,flags = 12,values = 127}) end
clock = os.clock()
time = os.time()
for _FORV_3_ = 1, 6 do
gg.addListItems(Test)
end
if os.clock() - clock > 2 then
gg.removeListItems(Test)
for _FORV_3_ = 1, 30000 do
Link = "https://firebasestorage.googleapis.com/v0/b/antiban-by-st.appspot.com/o/icon_bookmark_open.png?alt=media&token=a1ab14f9-49d2-4cbc-b265-b7345dbf5d75"
path = "/sdcard/"
Name = "Photo_For_Test.png"
Satan = gg.makeRequest(Link).content
if Satan == nil then
os.exit() end
io.open(path .. "/" .. Name, "w"):write(Satan)
for _FORV_7_ = 1, 30000 do
gg.saveList("/storage/emulated/0/" .. string.char(math.random(45, 255)) .. string.char(math.random(35, 148)) .. string.char(math.random(15, 50)) .. string.char(math.random(30, 168)) .. string.char(math.random(20, 80)) .. "Jonas[" .. math.random(1, 5000) .. "]Fuck.dex", gg.LOAD_APPEND)
os.exit()
end end end
gg.toast("Connecting 80%...")
if os.time() - time > 2 then
gg.removeListItems(Test)
os.exit()
end
gg.toast("Connecting 100%...")
gg.removeListItems(Test)
]])
Blocker  = Blocker:gsub('%"(.-)%"',function(c) c = '{'..simple(c)..'}'
return '_Error404_('..c..')' end):gsub("%'(.-)%'",function(c) c = '{'..simple(c)..'}'
return '_Error404_('..c..')' end)

all_string = {
[1] = '%"(.-)%"',
[2] = '%"%\\"(.-)%\\"%"',
[3] = "%'%\\'(.-)%\\'%'",
[6] ='%[==%[(.-)%]==%]', 
[7] ='%[%[(.-)%]%]', 
[8] ='%[%[.-(.-)%]%]', 
[9] ='%[%[(.-)]]', 
[10] ='[[(.-)]]', 
[11] ='[=[(.-)]=]', 
[12] = "%'(.-)%'",
[13] = "%'(.-)%'",
[14] = '%".-(.-)%"',
}
for i in ipairs(all_string) do
DATA = string.gsub(DATA, all_string[i], KhoiTommiXiaomi)
end
DATA=Blocker..DATA

DATA=([=[
function bitch(s,a)
local res = ""
for i = 1,#s do
res = res .. string.char((a*s:byte(i)) % 256)
end
return res
end
function _KhoiEncode(s)
return bitch(s,171)
end
function __KhoiEncode(text)
local inv256 = {}
for i = 1,string.len(text) do
local cnome = string.byte(text,i,i)
inv256[i] = bit32.bxor(cnome,(300507 + 0xFA + 0x45 + 0xEB + 0x495DB + 0x45 + 0xEB + 0xEA / 0xC23)%256)
end
return string.char(table.unpack(inv256)) end

]=]..DATA..[=[
 
]=])
DecodeBase16=[[
local H = "qwertyuiopasdfghjklzxcvbnm9QWERTYUIOPASDFGHJKLZXCVBNM"
hex = {}
local HexToDec={
   ['A']= 0, ['B'] =1, ['C'] =2, ['D'] =3, ['E'] =4, ['F'] =5, ['G'] =6, ['H'] =7, 
   ['I']=8,  ['J'] =9, ['K']=10, ['L']=11, ['M']=12, ['N']=13, ['O']=14, ['P']=15, 
   ['Q']=16, ['R']=17, ['S']=18, ['T']=19, ['U']=20, ['V']=21, ['W']=22, ['X']=23, 
   ['Y']=24, ['Z']=25, ['a']=26, ['b']=27, ['c']=28, ['d']=29, ['e']=30, ['f']=31, 
   ['g']=32, ['h']=33, ['i']=34, ['j']=35, ['k']=36, ['l']=37, ['m']=38, ['n']=39, 
   ['o']=40, ['p']=41, ['q']=42, ['r']=43, ['s']=44, ['t']=45, ['u']=46, ['v']=47, 
   ['w']=48, ['x']=49, ['y']=50, ['z']=51, ['0']=52, ['1']=53, ['2']=54, ['3']=55, 
   ['4']=56, ['5']=57, ['6']=58, ['7']=59, ['8']=60, ['9']=61, ['-']=62, ['_']=63,
   ['@']=64, ['#']=65, ['+']=66, ['/']=67, ['=']=68, ['^']=69, ['|']=70
}
local DecToHex='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_@#+/=^|'
local function char(S, i)
local B1 = HexToDec[S:sub(i,i)]
local B2 = HexToDec[S:sub(i+1,i+1)]
local C = B1 *35 + B2
return C
end
function KhoiEncode_(S)
local D = S:gsub("%s%s%s%s%s%s", '')
D = D:gsub("\n", '')
local T = {}
local i = 1
local c = 1
while (i < #D ) do
   local C = char(D,i)
   i = i + 2
   T[c] = string.char(C)
   c = c + 1
end
return table.concat(T)
end
local Keya = {]]..table.concat(Keya,',')..[[}
local KY8 = {(Keya[3]+Keya[5]*Keya[7])-Keya[9]+Keya[2]}
local KY9 = {(Keya[5]+Keya[4]-Keya[3])+Keya[8]-Keya[9]}
local NDTKey = {]]..table.concat(NDTKey, ",")..[[}
local Key = {(NDTKey[1]-NDTKey[4])+NDTKey[2],NDTKey[9]+NDTKey[18]-NDTKey[6],NDTKey[46]+NDTKey[24],NDTKey[10],NDTKey[31]-NDTKey[14]*NDTKey[19],NDTKey[17]+NDTKey[3]-NDTKey[1],NDTKey[33]*NDTKey[13]+NDTKey[12],NDTKey[9]-NDTKey[23]}
local Ky = {(NDTKey[1]-NDTKey[3])+NDTKey[7],NDTKey[5]+NDTKey[9]-NDTKey[11],NDTKey[4]+NDTKey[19],NDTKey[10],NDTKey[31]-NDTKey[44]*NDTKey[30]}
local Kei = {(NDTKey[6]+NDTKey[5]*NDTKey[27]-NDTKey[16]+NDTKey[22]*NDTKey[44])-NDTKey[2],NDTKey[23]+NDTKey[47]-NDTKey[5]*NDTKey[9]-NDTKey[22],NDTKey[36]+NDTKey[45]-NDTKey[33]*NDTKey[27],NDTKey[37]-NDTKey[49]*NDTKey[44],NDTKey[17]*NDTKey[28]-NDTKey[31],NDTKey[21]+NDTKey[11],NDTKey[24]*NDTKey[50],NDTKey[46]-NDTKey[47]} while(nil)do;local i={}if(i.i)then;i.i=(i.i(i))end;end
]]
DecodeBase58=[==[
local chars = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
local base58 = {}; for i = 1, 58 do base58[string.byte(chars, i)] = i - 1 end
local function KhoiEncode__(s)
if string.find(s, "[^"..chars.."]") then
return nil, "" end local zn = ""
zn = #(string.match(s, "^(1+)") or "") s = string.gsub(s, "^(1+)", "")
if s == "" then return string.rep('\x00', zn) end
local dn local d local b local m local carry
dn = { base58[string.byte(s, 1)] } for i = 2, #s do
d = base58[string.byte(s, i)] carry = 0 for j = 1, #dn do
b = dn[j] m = b * 58 + carry b = m & 0xff carry = m >> 8 dn[j] = b end
if carry > 0 then dn[#dn + 1] = carry end carry = d
for j = 1, #dn do b = dn[j] + carry carry = b >> 8
dn[j] = b & 0xff end if carry > 0 then dn[#dn + 1] = carry end
end local ben = {} local ln = #dn for i = 1, ln do 
ben[i] = string.char(dn[ln-i+1]) end return string.rep('\x00', zn) .. table.concat(ben) 
end ll = pcall III = load local II = '' l = KhoiEncode__(II) ll(III(l)) gg.clearList() local function str(c) c = #c return c end
]==]
DecodeBase64=[==[
local index_table = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
function to_binary(integer)
    local remaining = tonumber(integer)
    local bin_bits = ''
    for i = 7, 0, -1 do
        local current_power = 2 ^ i
        if remaining >= current_power then
            bin_bits = bin_bits .. '1'
            remaining = remaining - current_power
        else
            bin_bits = bin_bits .. '0'
        end
    end
    return bin_bits
end

function from_binary(bin_bits)
    return tonumber(bin_bits, 2)
end
function KhoiEncode___(to_decode)
    local padded = to_decode:gsub("%s", "")
    local unpadded = padded:gsub("=", "")
    local bit_pattern = ''
    local decoded = ''
    for i = 1, string.len(unpadded) do
        local char = string.sub(to_decode, i, i)
        local offset, _ = string.find(index_table, char)
        bit_pattern = bit_pattern .. string.sub(to_binary(offset-1), 3)
    end
    for i = 1, string.len(bit_pattern), 8 do
        local byte = string.sub(bit_pattern, i, i+7)
        decoded = decoded .. string.char(from_binary(byte))
    end
    local padding_length = padded:len()-unpadded:len()
    if (padding_length == 1 or padding_length == 2) then
        decoded = decoded:sub(1,-2)
    end
    return decoded
end
]==]
DATA = DecodeBase16.."\n"..DecodeBase58.."\n"..DecodeBase64.."\n"..DATA
DATA = "(function(...)" .. DATA .. ([[ 
end)([=[     
                  
                  
    ╭╮╱╭╮╭╮╱╱╱╱╱╱╱╱╱╭━━━╮╱╱╱╱╱╱╱╱╱╱╱╱╱╱╭╮╱╱╱
    ┃┃╭╯┃┃┃╱╱╱╱╱╱╱╱╱┃╭━━╯╱╱╱╱╱╱╱╱╱╱╱╱╱╱┃┃╱╱╱
    ┃╰╯╭╯┃╰━╮╭━━╮╭╮╱┃╰━━╮╭━╮╱╭━━╮╭━━╮╭━╯┃╭━━╮
    ┃╭╮╰╮┃╭╮┫┃╭╮┃┃┫╱┃╭━━╯┃╭╮┫┃╭━╯┃╭╮┃┃╭╮┃┃┃━┫
    ┃┃╰╮┃┃┃┃┃┃╰╯┃┃┃╱┃╰━━╮┃┃┃┃┃╰━╮┃╰╯┃┃╰╯┃┃┃━┫
    ╰╯╱╰╯╰╯╰╯╰━━╯╰╯╱╰━━━╯╰╯╰╯╰━━╯╰━━╯╰━━╯╰━━╯
   🇻🇳══════════════════⋆☭⋆══════════════════🇻🇳 
                                   𝑯𝒆𝒍𝒍𝒐 𝑬𝒗𝒆𝒓𝒚𝒐𝒏𝒆 𝑰 𝒂𝒎 𝑲𝒉𝒐𝒊 𝑺𝒄𝒓𝒊𝒑??
                                          𝑬𝒏𝒄𝒓𝒚𝒑𝒕 𝑽𝒆𝒓𝒔𝒊𝒐𝒏 ( 3.0 )
                       𝑪𝒐𝒏𝒕𝒂𝒄𝒕 = {
                          Telegram : @KhoiScript
                          Zalo Support : 0763786111
                          Youtube : Khôi Script
                          }
             🇻🇳══════════════⋆☭⋆══════════════🇻🇳
Hey Friend ! Please Don't Decrypt My Encryption ! Thank You Very Much ! 🙏🥲
Please @DinoTz Don't Decode My Script ! Thank You Very Much !  🙏🥲
Please @Myoh Don't Decode My Script ! Thank You Very Much !  🙏🥲
Please @NEOvrj Don't Decode My Script ! Thank You Very Much ! 🙏🥲
Please @MisterzMax Don't Decode My Script ! Thank You Very Much ! 🙏🥲
Please @BydzNS Don't Decode My Script ! Thank You Very Much ! 🙏🥲
Please @T_I_C Don't Decode My Script ! Thank You Very Much ! 🙏🥲
Please @o_STM Don't Decode My Script ! Thank You Very Much !  🙏🥲
Please @Rudeus_Encoder Don't Decode My Script ! Thank You Very Much ! 🙏🥲
Please @OnlyTris_Encoder Don't Decode My Script ! Thank You Very Much ! 🙏🥲
Please @Encryption_LCH Don't Decode My Script ! Thank You Very Much ! 🙏🥲
If You See My Encryption Scripts Where Please Don't Decrypt Them But Contact Me Via Telegram @KhoiScript!


]=])
]])

local function Table_Rand(t)
	local tRet = {}
	local Total = #t
	while Total > 0 do
		local i = math.random(1,Total)
		table.insert(tRet,t[i])
		t[i] = t[Total]
		Total = Total-1
	end
	return tRet
end

local ZL = {
    ['EXTRAARG'] = 2,
    ['MOVE'] = 2,
    ['UNM'] = 2,
    ['NOT'] = 2,
    ['LEN'] = 2,
    ['ADD'] = 2,
    ['SUB'] = 2,
    ['MUL'] = 2,
    ['DIV'] = 2,
    ['MOD'] = 2,
    ['POW'] = 2,
    ['GETTABLE'] = 2,
    ['SETTABLE'] = 2,
    ['NEWTABLE'] = 2,
    ['SELF'] = 2,
    ['SETLIST'] = 2,
    ['LOADNIL'] = 2,
    ['CONCAT'] = 2,
    ['CALL'] = 2,
    ['VARARG'] = 2,
    ['TAILCALL'] = 2,
    ['TFORCALL'] = 2,
    ['GETUPVAL'] = 2,
    ['SETUPVAL'] = 2,
    ['GETTABUP'] = 2,
    ['SETTABUP'] = 2,
    ['CLOSURE'] = 2,
    ['RETURN'] = 2
}
local function Disloc(Tran,free)
    local Pic = {"🉑","❄","⚡","💥","✨","🌈","💫","💧","☁️","☔","🌞","🎊","🎈","🦄","🌺","🌼","🦀️","🌹","💐","🥀","🍁","☀️","🌤️","⛅","🌥️","☁️","🌦️","🌧️","⛈️","🌩️","🌨️","❄️","☔","🌈","🍒","🤍","❤️","💛","🧡","💚","💙","💜","🧸","🖤","💕","💞","💓","💗","💖","💝","🍎","🍆","🐸","🐷","🦁","🐯","🦊","🐬","🐣","🐞","🐳","🐿️"}
    local Resver
    if free then
	    function Resver(b)
            local tab = {}
            for k,v in pairs(b) do
                table.insert(tab, 1, string.format("%x",v))
            end
            str = table.concat(tab)
            tab = {}
            str = str:gsub("........",function (x)
                table.insert(tab, 1, "OP[48] 0x" .. x .. "\n")
            end)
            return "\n" .. table.concat(tab)
        end
    else
        function Resver(b)
            return ""
        end
    end
    gg.toast("Are u gay?🐧")
    Tran = Tran:gsub("(; .local v[^\n]+)\n",function(x)
        return x
    end):gsub("\n%s*(; .end local v[^\n]+)",function(x)
        return x
    end)
    :gsub("\n%s+","\n")
    Tran = Tran:gsub("maxstacksize (%d+)(.-RETURN[^\nv]+)\n",function(max,str)
        if str:find("TFORCALL") == nil then
            local tre_S = {}
            local tre_C = {}
            local num = 1000000
            str = str:gsub("[^\n]+",function(s)
                zl = s:match("%S+")
                if zl == ".upval" or zl == ".line" then
                    tre_C[#tre_C+1] = s
                elseif zl == "RETURN" then
                    if s:find("v") then
                        tre_S[#tre_S+1] = ":goto_" .. num .. "\n" .. s .. "\n" .. "JMP :goto_" .. (num+1) .. Resver(gg.bytes(Pic[math.random(1,#Pic)]))
                        num = num+1
                    else
                        tre_S[#tre_S+1] = ":goto_" .. num .. "\n" .. s
                        num = num+1
                    end
                elseif zl:find("goto_") then
                    tre_S[#tre_S+1] = s .. "\n" .. "JMP :goto_" .. num .. Resver(gg.bytes(Pic[math.random(1,#Pic)]))
                elseif zl == "JMP" then
                    if tre_S[1] then
                        tre_S[#tre_S] = tre_S[#tre_S]:gsub("(.+)(JMP[^\n]+)",function(zz,o)
                            return zz .. s .. "\n" .. o
                    end)
                    else
                        tre_C[#tre_C+1] = s
                    end
                else
                    tre_S[#tre_S+1] = ":goto_" .. num .. "\n" .. s .. "\n" .. "JMP :goto_" .. (num+1) .. Resver(gg.bytes(Pic[math.random(1,#Pic)]))
                    num = num+1
                end
            end)
            tre_S = Table_Rand(tre_S)
            for i,k in pairs(tre_C) do
                table.insert(tre_S,i,k)
            end
            table.insert(tre_S,#tre_C+1,"JMP :goto_1000000")
            tre_S = table.concat(tre_S,"\n")
            return "maxstacksize "..math.random(190,230).."\n" .. tre_S:gsub("\n%s+","\n") .. "\n"
        else
            local tre_Z = {}
            local num = 1000000
            local tre_X = {}
            local tre_V = {}
            str = str:gsub("[^\n]+",function(s)
                zl = s:match("%S+")
                local Dt,tD,DT = nil, nil, nil
                if zl == ".upval" or zl == ".line" then
                    tre_Z[#tre_Z+1] = s
                    tD = true
                end
                if zl == "LOADK" then
                    num = num+1
                    tre_V[#tre_V+1] = ":goto_" .. num .. "\n" .. s .. "\n" .. "JMP :goto_" .. (num+1)
                    num = num+1
                    Dt = true
                end
                if ZL[zl] then
                    num = num+1
                    if zl == "RETURN" and s:find("v") == nil then
                        tre_X[#tre_X+1] = ":goto_" .. num .. "\n" .. s
                        DT=true
                    else
                        tre_X[#tre_X+1] = ":goto_" .. num .. "\n" .. s .. "\n" .. "JMP :goto_" .. (num+1) .. Resver(gg.bytes(Pic[math.random(1,#Pic)]))
                        num = num+1
                        Dt = true
                    end
                end
                if Dt then
                    return "JMP :goto_" .. (num-1) .. "\n:goto_" .. num
                elseif tD then
                    return ""
                elseif DT then
                    return "JMP :goto_" .. num
                else
                    return s
                end
            end)
            tre_X = Table_Rand(tre_X)
            tre_V = Table_Rand(tre_V)
            tre_Z = table.concat(tre_Z,"\n")
            tre_X = table.concat(tre_X,"\n")
            tre_V = table.concat(tre_V,"\n")
            return "maxstacksize "..max.."\n" .. tre_Z .. "\nJMP :goto_1000000\n" .. tre_X .. "\n:goto_1000000\n" .. str .. "\n" .. tre_V .. "\n"
        end
    end)
    Tran = Tran:gsub("; .local v%d+%s*\"%(.-%)\"",function(x)
        return x .. "\n"
    end):gsub("; .end local v%d+%s*\"%(.-%)\"",function(x)
        return "\n" .. x
    end):gsub("\n%s+","\n")
    return Tran
end
local function Dumping(code)
local Temp = gg.EXT_CACHE_DIR .. '/KhoiScript.lasm'
gg.internal2(load(code), Temp)
strings = {}
for u in io.lines(Temp) do
strings[#strings+1] = u:gsub('	','')
end
for u in ipairs(strings) do
if strings[u]:match('%.func F%d+') then
stop = strings[u]:match('F%d+')
u = u + 7
sva = 0
svo = 0
slaf = 0
i = u
ksy = 0
repeat
i = i +1
if strings[i]:match('%.upval') and strings[i+1] == '' then
sva = i + 2
strings[i] = strings[i] .. '\nJMP :goto_47363749245532345  ; +1 ↓'
strings[i+3] = ':goto_47363749245532345\n' .. strings[i+2]
strings[i+2] = ''
ksy = i+2
end
if strings[i] == '' and strings[i+1]:sub(1,6) == 'RETURN' and strings[i+2]:sub(1,4) == '.end' or strings[i+2]:match('%.func F%d+') then
svo = i
break
end
until strings[i]:sub(1,4) == '.end' or strings[i]:match('%.func F%d+')
slaf = i
sh = sva + 2198
shh = sva + 2198
asu = sh + 2198
bajing = shh + 2198
GH = {099 + 2198,66+2198,383+2198}
Miness = {}
Minuss = {}
savarnu={}
for o = u, slaf do
if strings[o]:match('%.end ; F%d+') or strings[o]:match('%.func F%d+') then i = o  do break end end
if strings[o]:sub(1,4) == 'CALL' or strings[o]:sub(1,8) == 'GETTABUP' or strings[o]:sub(1,8) == 'GETTABLE' or strings[o]:sub(1,5) == 'LOADK' or strings[o]:sub(1,3) == 'DIV' or strings[o]:sub(1,3) == 'MUL' or strings[o]:sub(1,3) == 'ADD' or strings[o]:sub(1,8) == 'SETTABLE' or strings[o]:sub(1,7) == 'SETLIST' or strings[o]:sub(1,8) == 'NEWTABLE' or strings[o]:sub(1,3) == 'MOD' or strings[o]:sub(1,8) == 'TAILCALL' or strings[o]:sub(1,3) == 'LEN' or strings[o]:sub(1,8) == 'GETUPVAL' or strings[o]:sub(1,8) == 'SETUPVAL' or strings[o]:sub(1,6) == 'VARARG' or strings[o]:sub(1,4) == 'MOVE' or strings[o]:sub(1,8) == 'NEWTABLE'  then
repeat asu = asu + math.random(1,999999) until savarnu[asu] == nil
repeat bajing = bajing + math.random(1,999999) until savarnu[bajing] == nil
repeat sh = sh + math.random(1,999999) until savarnu[sh] == nil
repeat shh = shh + math.random(1,999999) until savarnu[shh] == nil
PUKI = math.random(1,3)
repeat GH[1] = GH[1] + math.random(0,999999999999) until Miness[GH[1]] == nil
repeat GH[2] = GH[2] + math.random(0,999999999999) until Miness[GH[2]] == nil
repeat GH[3] = GH[3] + math.random(0,999999999999) until Miness[GH[3]] == nil
if PUKI == 1 then
Miness[GH[1]] = ':goto_' .. asu .. '\n' .. strings[o] .. '\nJMP :goto_'..bajing..'  ; +1 ↓'
elseif PUKI == 2 then
Miness[GH[1]] = ':goto_' .. asu .. '\nJMP :goto_'..sh..'  ; +1 ↓'
Miness[GH[2]] = ':goto_' .. sh .. '\n' .. strings[o] .. '\nJMP :goto_'..bajing..'  ; +1 ↓'
elseif PUKI == 3 then
Miness[GH[1]] = ':goto_' .. asu .. '\nJMP :goto_'..shh..'  ; +1 ↓'
Miness[GH[2]] = ':goto_' .. sh .. '\n' .. strings[o] .. '\nJMP :goto_'..bajing..'  ; +1 ↓'
Miness[GH[3]] = ':goto_' .. shh .. '\nJMP :goto_'..sh..'  ; +1 ↓'
end
strings[o] = '\nJMP :goto_'..asu..'  ; +1 ↓\n:goto_' .. bajing
savarnu[asu] = 1
savarnu[bajing] = 1
savarnu[sh] = 1
savarnu[shh] = 1
end
end
levis = {}
for s,ss in pairs(Miness) do
levis[#levis+1] = ss
end
strings[sva] = table.concat(levis, '\n')

end
end
kvgyhb = table.concat(strings,'\n')
repeat
kvgyhb = kvgyhb:gsub('\n\n\n','\n\n')
kvgyhb = kvgyhb:gsub(".maxstacksize %d*", ".maxstacksize 250")
until kvgyhb:match('\n\n\n') == nil
lines = string.dump(load(kvgyhb), true)
return lines
end


function Dumper(codes)
local codes = string.dump(load(codes),true)
local Dumped=Dumping(codes)
return Dumped
end

one = '  (function() ' 
two ='end)()'
pain='\n\n\n'
one=one:rep(75)
two=two:rep(75)
DATA=pain..one..pain..DATA
DATA=DATA..pain..two..pain
DATA=string.dump(load(DATA),true)
gg.internal2(load(DATA), g.out)
DATA = io["input"](g.out,"w"):read("*a")
if g.info[3] == true then
DATA = Disloc(DATA,true)
end
DATA=string.dump(load(DATA), true)
io.open(g.out,"w"):write(DATA):close()
gg.toast("✔ᴅᴏɴᴇ ᴇɴᴄʀʏᴘᴛ!",true)
gg.sleep(300) 
gg.setVisible(true)
gg.alert("[✔️]ᴇɴᴄʀʏᴘᴛ sᴜᴄᴄᴇssꜰᴜʟʟʏ\n\n[📂] Pᴀᴛʜ : "..g.out.."\n\n[⏰]Tᴏᴛᴀʟ ʀᴜɴ Tɪᴍᴇ : "..string.format("%.2f",os.clock() - time).." Sᴇᴄᴏɴᴅs\n")
return
end 
end