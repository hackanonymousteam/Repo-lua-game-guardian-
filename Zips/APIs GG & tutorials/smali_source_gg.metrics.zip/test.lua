
m=gg.metrics()
print("height:"..m.height)
print("width:"..m.width)
print("density:"..m.density)
print("dpi:"..m.densityDpi)
