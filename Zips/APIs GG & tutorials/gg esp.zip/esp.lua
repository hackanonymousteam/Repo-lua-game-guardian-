
function simularPersonagemAndando()
    local tempoTotal = 30000 
    local tempoInicio = os.clock() * 1000
    local tempoDecorrido = 0
    
    local x = 200.5
    local y = 200.3
    local largura = 50.0
    local altura = 200.0
    local distancia = 25.7
    
    
    
    while tempoDecorrido < tempoTotal do
      
        x = x + math.random(-10, 10) 
        y = y + math.random(-8, 8)  
        

        if x < 0 then x = 0 end
        if y < 0 then y = 0 end
        
        
        gg.esp(tostring(x), tostring(y), tostring(largura), tostring(altura), tostring(distancia))
        
       
        gg.sleep(100)  
        
        
        gg.espOff()
        
        gg.sleep(50)  
        
      
        tempoDecorrido = (os.clock() * 1000) - tempoInicio
        
        
        if math.floor(tempoDecorrido / 5000) > math.floor((tempoDecorrido - 100) / 5000) then
            local segundos = math.floor(tempoDecorrido / 1000)
            
        end
    end
    

    gg.espOff()
end

function simularPersonagemAndandoSuave()
    local tempoTotal = 30000
    local tempoInicio = os.clock() * 1000
    local tempoDecorrido = 0
    
   
    local x = 100.5
    local y = 200.3
    local largura = 50.0
    local altura = 100.0
    local distancia = 25.7
    
    
    local dirX = 1
    local dirY = 1
    local velocidade = 0.5
    
    
    
    while tempoDecorrido < tempoTotal do
     
        x = x + (dirX * velocidade)
        y = y + (dirY * velocidade * 0.7)
        
     
        if x > 300 or x < 50 then
            dirX = dirX * -1
        end
        if y > 400 or y < 100 then
            dirY = dirY * -1
        end
        
    
        gg.esp(tostring(x), tostring(y), tostring(largura), tostring(altura), tostring(distancia))
        gg.sleep(150)
        gg.espOff()
        gg.sleep(50)
        
        tempoDecorrido = (os.clock() * 1000) - tempoInicio
    end
    

    gg.espOff()
end


function simularMovimentoCircular()
    local tempoTotal = 30000
    local tempoInicio = os.clock() * 1000
    local tempoDecorrido = 0
    
    local centroX = 300
    local centroY = 300
    local raio = 100
    local angulo = 0
    local largura = 80.0
    local altura = 200.0
    local distancia = 5.7
    
    
    while tempoDecorrido < tempoTotal do
     
        local x = centroX + raio * math.cos(angulo)
        local y = centroY + raio * math.sin(angulo)
        
    
        angulo = angulo + 0.1
        if angulo > 2 * math.pi then
            angulo = 0
        end
        
       
        gg.esp(tostring(x), tostring(y), tostring(largura), tostring(altura), tostring(distancia))
        gg.sleep(100)
        gg.espOff()
        gg.sleep(50)
        
        tempoDecorrido = (os.clock() * 1000) - tempoInicio
    end
    
    
    gg.espOff()
end


-- simularPersonagemAndando()      
--simularPersonagemAndandoSuave() 
 simularMovimentoCircular()      
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 