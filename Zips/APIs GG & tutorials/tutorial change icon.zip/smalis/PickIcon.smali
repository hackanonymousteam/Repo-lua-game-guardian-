.class public Landroid/ext/PickIcon;
.super Ljava/lang/Object;
.source "PickIcon.java"


# static fields
.field private static final BUFFER_SIZE:I = 0x1000
.field private static final ICON_FILE_NAME:Ljava/lang/String; = "icon.png"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static saveImage(Landroid/content/Context;Ljava/lang/String;)Z
    .registers 9
    .param p0, "context"        # Landroid/content/Context;
    .param p1, "sourcePath"     # Ljava/lang/String;

    .prologue
    .line 23
    const/4 v0, 0x0

    .line 25
    .local v0, "success":Z
    :try_start_1
    new-instance v1, Ljava/io/File;

    invoke-direct {v1, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 26
    .local v1, "sourceFile":Ljava/io/File;
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v2

    if-nez v2, :cond_e

    .line 27
    const/4 v2, 0x0

    return v2

    .line 30
    :cond_e
    const/4 v2, 0x0

    invoke-virtual {p0, v2}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v2

    .line 31
    .local v2, "filesDir":Ljava/io/File;
    if-nez v2, :cond_1a

    .line 32
    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v3

    move-object v2, v3

    .line 35
    :cond_1a
    new-instance v3, Ljava/io/File;

    const-string v4, "icon.png"

    invoke-direct {v3, v2, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 38
    .local v3, "destFile":Ljava/io/File;
    new-instance v4, Ljava/io/FileInputStream;

    invoke-direct {v4, v1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 39
    .local v4, "inputStream":Ljava/io/FileInputStream;
    new-instance v5, Ljava/io/FileOutputStream;

    invoke-direct {v5, v3}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 41
    .local v5, "outputStream":Ljava/io/FileOutputStream;
    const/16 v6, 0x1000

    new-array v6, v6, [B

    .line 42
    .local v6, "buffer":[B
    const/4 v7, 0x0

    .line 44
    .local v7, "bytesRead":I
    :goto_31
    invoke-virtual {v4, v6}, Ljava/io/FileInputStream;->read([B)I

    move-result v8

    move v7, v8

    const/4 v8, -0x1

    if-eq v7, v8, :cond_3e

    .line 45
    const/4 v8, 0x0

    invoke-virtual {v5, v6, v8, v7}, Ljava/io/FileOutputStream;->write([BII)V

    goto :goto_31

    .line 48
    :cond_3e
    invoke-virtual {v4}, Ljava/io/FileInputStream;->close()V

    .line 49
    invoke-virtual {v5}, Ljava/io/FileOutputStream;->close()V

    .line 51
    const/4 v8, 0x1
    :try_end_45
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_45} :catch_47

    move v0, v8

    .line 55
    .end local v1    # "sourceFile":Ljava/io/File;
    .end local v2    # "filesDir":Ljava/io/File;
    .end local v3    # "destFile":Ljava/io/File;
    .end local v4    # "inputStream":Ljava/io/FileInputStream;
    .end local v5    # "outputStream":Ljava/io/FileOutputStream;
    .end local v6    # "buffer":[B
    .end local v7    # "bytesRead":I
    :goto_46
    goto :goto_4c

    .line 52
    :catch_47
    move-exception v1

    .line 53
    .local v1, "e":Ljava/io/IOException;
    invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V

    .line 54
    const/4 v0, 0x0

    .line 57
    .end local v1    # "e":Ljava/io/IOException;
    :goto_4c
    return v0
.end method

.method public static getIconPath(Landroid/content/Context;)Ljava/lang/String;
    .registers 4
    .param p0, "context"    # Landroid/content/Context;

    .prologue
    .line 62
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    .line 63
    .local v0, "filesDir":Ljava/io/File;
    if-nez v0, :cond_c

    .line 64
    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v1

    move-object v0, v1

    .line 67
    :cond_c
    new-instance v1, Ljava/io/File;

    const-string v2, "icon.png"

    invoke-direct {v1, v0, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 68
    .local v1, "iconFile":Ljava/io/File;
    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v2

    return-object v2
.end method