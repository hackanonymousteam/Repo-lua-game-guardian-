# classes.dex

.class public Landroid/ext/Script$changeIcon;
.super Landroid/ext/Script$ApiFunction;
.source "Script.java"


# instance fields
.field final synthetic this$0:Landroid/ext/Script;


# direct methods
.method constructor <init>(Landroid/ext/Script;)V
    .registers 2

    .prologue
    iput-object p1, p0, Landroid/ext/Script$changeIcon;->this$0:Landroid/ext/Script;

    invoke-direct {p0}, Landroid/ext/Script$ApiFunction;-><init>()V

    return-void
.end method


# virtual methods
.method final a()Ljava/lang/String;
    .registers 2

    .prologue
    const-string v0, "gg.changeIcon(string file) -> nil"

    return-object v0
.end method

.method public d(Lluaj/ap;)Lluaj/ap;
    .registers 5

    .prologue
    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Lluaj/ap;->r(I)Ljava/lang/String;

    move-result-object v0

    .line 1
    invoke-static {}, Landroid/ext/Tools;->e()Landroid/content/Context;

    move-result-object v1

    .line 2
    invoke-static {v1, v0}, Landroid/ext/PickIcon;->saveImage(Landroid/content/Context;Ljava/lang/String;)Z

    .line 3
    sget-object v0, Lluaj/LuaValue;->u:Lluaj/LuaValue;

    return-object v0
.end method

.method protected m_()I
    .registers 2

    .prologue
    const/4 v0, 0x3

    return v0
.end method