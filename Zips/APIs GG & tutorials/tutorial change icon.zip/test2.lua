local Link = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQkeXASyWdzSCwFRKix4otPRRkMPFaDPgNlBCr-xzXclQ&s=10"
local path = "/sdcard"
local Name = "Photo_For_Test.png"

local req = gg.makeRequest(Link)
if req == nil or req.content == nil then
    os.exit()
end

local file = io.open(path .. "/" .. Name, "wb")
if file then
    file:write(req.content)
    file:close()
end

gg.changeIcon(path .. "/" .. Name)

-- restart gg for apply change icon