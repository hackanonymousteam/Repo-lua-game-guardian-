gg.changeIcon("/storage/emulated/0/tutorial change icon/ic_cellphone_screenshot_black_32dp.png")

gg.alert("restart gg for apply change icon")