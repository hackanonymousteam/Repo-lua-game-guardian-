

w = '<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAMAAADXqc3KAAAAOVBMVEUAAAAAAAAAAAAAAAAAAAAbGxvf399UVFTg4OD5+flJSUkDAwNLS0sAAAAAAAACAgIAAAAAAAD///9TqWE7AAAAEXRSTlMASuJ/48rlv+b5wOi/+XboeO+1XWEAAABoSURBVCjPtdLdCoAgDAXgaWr+6/b+DxtBlsm8SOjcfuw4mAALERJf2RoobajLfgtaIlaQ6Onp5YRWi9fMBAj5qg7G/AXOh+AdAzHlnCIDpQLU8gWmVczjdtzWIncoIqMVe1pEKVa+yAFt6RfoWoo8WgAAAABJRU5ErkJggg=="><title>&#8195;&#8195;Batman Games</title>'



 j = '<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAMAAADXqc3KAAAAOVBMVEUAAAAAAAAAAAAAAAAAAAAbGxvf399UVFTg4OD5+flJSUkDAwNLS0sAAAAAAAACAgIAAAAAAAD///9TqWE7AAAAEXRSTlMASuJ/48rlv+b5wOi/+XboeO+1XWEAAABoSURBVCjPtdLdCoAgDAXgaWr+6/b+DxtBlsm8SOjcfuw4mAALERJf2RoobajLfgtaIlaQ6Onp5YRWi9fMBAj5qg7G/AXOh+AdAzHlnCIDpQLU8gWmVczjdtzWIncoIqMVe1pEKVa+yAFt6RfoWoo8WgAAAABJRU5ErkJggg=="><font color="red">&#8195;&#8195;Text red </font>'
 
 
 k = '<font color="red">&#8195;&#8195;exit </font>'

--gg.choice({w,w,j,k}, nil, "menu")




gg.setVisible(true)

-- script  happy  Zone online

function START3()
menu = gg.choice({w,w,j,k}, nil, "menu")




if menu == 1 then fov() end
if menu == 2 then run() end 
if menu == 3 then re() end
if menu == 4 then exit3() end
XGCK3= -1
end


function fov()
gg.alert("1")
    end



function run()
gg.alert("2")
end


function re()
gg.alert("3")
end


function exit3()
print("⭐ creator : BATMAN GAMES ")
os.exit()
end

  while true do
  if gg.isVisible(true) then
    XGCK1 = 1
    gg.setVisible(false)
    gg.clearResults()
  end
  if XGCK1 == 1 then
    START3()
  end
  XGCK1 = -1
end

