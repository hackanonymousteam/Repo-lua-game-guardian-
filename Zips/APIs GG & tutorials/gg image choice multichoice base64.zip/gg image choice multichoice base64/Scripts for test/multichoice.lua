

w = '<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAMAAADXqc3KAAAAOVBMVEUAAAAAAAAAAAAAAAAAAAAbGxvf399UVFTg4OD5+flJSUkDAwNLS0sAAAAAAAACAgIAAAAAAAD///9TqWE7AAAAEXRSTlMASuJ/48rlv+b5wOi/+XboeO+1XWEAAABoSURBVCjPtdLdCoAgDAXgaWr+6/b+DxtBlsm8SOjcfuw4mAALERJf2RoobajLfgtaIlaQ6Onp5YRWi9fMBAj5qg7G/AXOh+AdAzHlnCIDpQLU8gWmVczjdtzWIncoIqMVe1pEKVa+yAFt6RfoWoo8WgAAAABJRU5ErkJggg=="><title>&#8195;&#8195;Batman Games</title>'



 j = '<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAMAAADXqc3KAAAAOVBMVEUAAAAAAAAAAAAAAAAAAAAbGxvf399UVFTg4OD5+flJSUkDAwNLS0sAAAAAAAACAgIAAAAAAAD///9TqWE7AAAAEXRSTlMASuJ/48rlv+b5wOi/+XboeO+1XWEAAABoSURBVCjPtdLdCoAgDAXgaWr+6/b+DxtBlsm8SOjcfuw4mAALERJf2RoobajLfgtaIlaQ6Onp5YRWi9fMBAj5qg7G/AXOh+AdAzHlnCIDpQLU8gWmVczjdtzWIncoIqMVe1pEKVa+yAFt6RfoWoo8WgAAAABJRU5ErkJggg=="><font color="red">&#8195;&#8195;Text red </font>'
 
 
 k = '<font color="red">&#8195;&#8195;exit </font>'

--gg.choice({w,w,j,k}, nil, "menu")







HOME = 1

function HOME()
multi = gg.multiChoice({
w,w,j,k}, nil, "menu")



if multi == nil then else
if multi[1] == true then ch1() end
if multi[2] == true then ch1off() end
if multi[3] == true then ch2() end
if multi[4] == true then ch6() end

end
HOMEDM = -1
end

function ch1()
gg.alert("1")
gg.setVisible(false)
end

function ch1off()
gg.alert("2")
end

function ch2()
gg.alert("3")	
end 


function ch6()
os.exit()
end

while true do 
  if gg.isVisible(false) then 
   HOMEDM = 1
    gg.setVisible(false) 
--gg.toast("☑️ by batman games")
  end 
  if HOMEDM == 1 then HOME() end 
 end
 
 