.class Landroid/ext/CustomSpanTitle$100000000;
.super Ljava/lang/Object;
.source "CustomSpan.java"

# interfaces
.implements Landroid/text/Html$ImageGetter;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/ext/CustomSpanTitle;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# instance fields
.field private final val$ctx:Landroid/content/Context;

.field private final val$textSizePx:F


# direct methods
.method constructor <init>(FLandroid/content/Context;)V
    .registers 9

    move-object v0, p0

    move v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move v5, v1

    iput v5, v4, Landroid/ext/CustomSpanTitle$100000000;->val$textSizePx:F

    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Landroid/ext/CustomSpanTitle$100000000;->val$ctx:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public getDrawable(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;
    .registers 19
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 30
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v11, v1

    :try_start_5
    const-string v12, "data:image"

    invoke-virtual {v11, v12}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v11

    if-eqz v11, :cond_69

    .line 31
    move-object v11, v1

    move-object v12, v1

    const-string v13, ","

    invoke-virtual {v12, v13}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v12

    const/4 v13, 0x1

    add-int/lit8 v12, v12, 0x1

    invoke-virtual {v11, v12}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v11

    move-object v3, v11

    .line 32
    move-object v11, v3

    const/4 v12, 0x0

    invoke-static {v11, v12}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v11

    move-object v4, v11

    .line 33
    move-object v11, v4

    const/4 v12, 0x0

    move-object v13, v4

    array-length v13, v13

    invoke-static {v11, v12, v13}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    move-result-object v11

    move-object v5, v11

    .line 35
    move-object v11, v5

    invoke-virtual {v11}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v11

    int-to-float v11, v11

    move-object v12, v5

    invoke-virtual {v12}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v12

    int-to-float v12, v12

    div-float/2addr v11, v12

    move v6, v11

    .line 36
    move-object v11, v0

    iget v11, v11, Landroid/ext/CustomSpanTitle$100000000;->val$textSizePx:F

    const v12, 0x3f99999a  # 1.2f

    mul-float/2addr v11, v12

    float-to-int v11, v11

    move v7, v11

    .line 37
    move v11, v7

    int-to-float v11, v11

    move v12, v6

    mul-float/2addr v11, v12

    float-to-int v11, v11

    move v8, v11

    .line 39
    new-instance v11, Landroid/graphics/drawable/BitmapDrawable;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    move-object v13, v0

    iget-object v13, v13, Landroid/ext/CustomSpanTitle$100000000;->val$ctx:Landroid/content/Context;

    invoke-virtual {v13}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v13

    move-object v14, v5

    invoke-direct {v12, v13, v14}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V

    move-object v9, v11

    .line 40
    const/4 v12, 0x0

    move-object v11, v9

    move v14, v8

    neg-int v13, v7

    const/4 v15, 0x0

    invoke-virtual {v11, v12, v13, v14, v15}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V
    :try_end_66
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_66} :catch_6e

    .line 41
    move-object v11, v9

    move-object v0, v11

    .line 46
    :goto_68
    return-object v0

    :cond_69
    :goto_69
    const/4 v11, 0x0

    check-cast v11, Landroid/graphics/drawable/Drawable;

    move-object v0, v11

    goto :goto_68

    .line 41
    :catch_6e
    move-exception v11

    move-object v3, v11

    .line 44
    move-object v11, v3

    invoke-virtual {v11}, Ljava/lang/Exception;->printStackTrace()V

    goto :goto_69
.end method
