.class final Landroid/ext/Script$multiChoice;
.super Landroid/ext/Script$ApiFunction;
.source "src"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;
.implements Landroid/content/DialogInterface$OnDismissListener;
.implements Landroid/content/DialogInterface$OnMultiChoiceClickListener;


# instance fields
.field volatile d:[Z

.field private volatile e:Z


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 2250
    invoke-direct {p0}, Landroid/ext/Script$ApiFunction;-><init>()V

    return-void
.end method

.method private static extractAttributeAsInt(Ljava/lang/String;Ljava/lang/String;I)I
    .registers 16

    .prologue
    .line 115
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    move-object v10, v1

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    const-string v10, "=\'"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    move-object v4, v9

    .line 116
    move-object v9, v0

    move-object v10, v4

    invoke-virtual {v9, v10}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v9

    move v5, v9

    .line 117
    move v9, v5

    const/4 v10, -0x1

    if-ne v9, v10, :cond_45

    .line 118
    new-instance v9, Ljava/lang/StringBuffer;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    move-object v10, v1

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    const-string v10, "=\""

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    move-object v4, v9

    .line 119
    move-object v9, v0

    move-object v10, v4

    invoke-virtual {v9, v10}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v9

    move v5, v9

    .line 121
    :cond_45
    move v9, v5

    const/4 v10, -0x1

    if-eq v9, v10, :cond_7a

    .line 122
    move v9, v5

    move-object v10, v4

    invoke-virtual {v10}, Ljava/lang/String;->length()I

    move-result v10

    add-int/2addr v9, v10

    move v5, v9

    .line 123
    move-object v9, v0

    const-string v10, "\'"

    move v11, v5

    invoke-virtual {v9, v10, v11}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v9

    move v6, v9

    .line 124
    move v9, v6

    const/4 v10, -0x1

    if-ne v9, v10, :cond_67

    .line 125
    move-object v9, v0

    const-string v10, "\""

    move v11, v5

    invoke-virtual {v9, v10, v11}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v9

    move v6, v9

    .line 127
    :cond_67
    move v9, v6

    const/4 v10, -0x1

    if-eq v9, v10, :cond_7a

    .line 129
    move-object v9, v0

    move v10, v5

    move v11, v6

    :try_start_6e
    invoke-virtual {v9, v10, v11}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    :try_end_75
    .catch Ljava/lang/NumberFormatException; {:try_start_6e .. :try_end_75} :catch_78

    move-result v9

    move v0, v9

    .line 135
    :goto_77
    return v0

    .line 129
    :catch_78
    move-exception v9

    move-object v7, v9

    .line 135
    :cond_7a
    move v9, v2

    move v0, v9

    goto :goto_77
.end method

.method public static getSpannableItems([Ljava/lang/CharSequence;)[Ljava/lang/CharSequence;
    .registers 10

    .prologue
    .line 43
    move-object v0, p0

    move-object v5, v0

    array-length v5, v5

    new-array v5, v5, [Ljava/lang/CharSequence;

    move-object v2, v5

    .line 44
    const/4 v5, 0x0

    move v3, v5

    :goto_8
    move v5, v3

    move-object v6, v0

    array-length v6, v6

    if-lt v5, v6, :cond_10

    .line 47
    move-object v5, v2

    move-object v0, v5

    return-object v0

    .line 45
    :cond_10
    move-object v5, v2

    move v6, v3

    move-object v7, v0

    move v8, v3

    aget-object v7, v7, v8

    invoke-static {v7}, Landroid/ext/Script$multiChoice;->getSpannedString(Ljava/lang/CharSequence;)Landroid/text/SpannableString;

    move-result-object v7

    aput-object v7, v5, v6

    .line 44
    add-int/lit8 v3, v3, 0x1

    goto :goto_8
.end method

.method public static getSpannedString(Ljava/lang/CharSequence;)Landroid/text/SpannableString;
    .registers 24

    .prologue
    .line 57
    move-object/from16 v2, p0

    move-object/from16 v17, v2

    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v17

    const-string v18, "<"

    invoke-virtual/range {v17 .. v18}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v17

    if-nez v17, :cond_33

    new-instance v17, Ljava/lang/StringBuilder;

    move-object/from16 v22, v17

    move-object/from16 v17, v22

    move-object/from16 v18, v22

    invoke-direct/range {v18 .. v18}, Ljava/lang/StringBuilder;-><init>()V

    const-string v18, "<img src=\"data:image/png;base64,"

    invoke-virtual/range {v17 .. v18}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v18, v2

    invoke-virtual/range {v17 .. v18}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v17

    const-string v18, "\">"

    invoke-virtual/range {v17 .. v18}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    invoke-virtual/range {v17 .. v17}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    move-object/from16 v2, v17

    .line 58
    :cond_33
    move-object/from16 v17, v2

    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v17

    const/16 v18, 0x3f

    const/16 v19, 0x0

    check-cast v19, Landroid/text/Html$ImageGetter;

    const/16 v20, 0x0

    check-cast v20, Landroid/text/Html$TagHandler;

    invoke-static/range {v17 .. v20}, Landroid/text/Html;->fromHtml(Ljava/lang/String;ILandroid/text/Html$ImageGetter;Landroid/text/Html$TagHandler;)Landroid/text/Spanned;

    move-result-object v17

    move-object/from16 v4, v17

    .line 59
    new-instance v17, Landroid/text/SpannableString;

    move-object/from16 v22, v17

    move-object/from16 v17, v22

    move-object/from16 v18, v22

    move-object/from16 v19, v4

    invoke-direct/range {v18 .. v19}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    move-object/from16 v5, v17

    .line 62
    move-object/from16 v17, v2

    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v17

    const-string v18, "<img"

    invoke-virtual/range {v17 .. v18}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v17

    move/from16 v6, v17

    .line 63
    move-object/from16 v17, v2

    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v17

    const-string v18, ">"

    move/from16 v19, v6

    invoke-virtual/range {v17 .. v19}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v17

    const/16 v18, 0x1

    add-int/lit8 v17, v17, 0x1

    move/from16 v7, v17

    .line 64
    move/from16 v17, v6

    const/16 v18, -0x1

    move/from16 v0, v17

    move/from16 v1, v18

    if-eq v0, v1, :cond_11b

    move/from16 v17, v7

    const/16 v18, -0x1

    move/from16 v0, v17

    move/from16 v1, v18

    if-eq v0, v1, :cond_11b

    .line 66
    move-object/from16 v17, v2

    move/from16 v18, v6

    move/from16 v19, v7

    invoke-interface/range {v17 .. v19}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object v17

    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v17

    move-object/from16 v8, v17

    .line 69
    move-object/from16 v17, v8

    const-string v18, "base64,"

    invoke-virtual/range {v17 .. v18}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v17

    move/from16 v9, v17

    .line 70
    move/from16 v17, v9

    const/16 v18, -0x1

    move/from16 v0, v17

    move/from16 v1, v18

    if-eq v0, v1, :cond_11b

    .line 71
    move-object/from16 v17, v8

    move/from16 v18, v9

    const/16 v19, 0x7

    add-int/lit8 v18, v18, 0x7

    move-object/from16 v19, v8

    const-string v20, "\">"

    invoke-virtual/range {v19 .. v20}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v19

    invoke-virtual/range {v17 .. v19}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v17

    move-object/from16 v10, v17

    .line 74
    move-object/from16 v17, v8

    const-string v18, "width"

    const/16 v19, 0x64

    invoke-static/range {v17 .. v19}, Landroid/ext/Script$multiChoice;->extractAttributeAsInt(Ljava/lang/String;Ljava/lang/String;I)I

    move-result v17

    move/from16 v11, v17

    .line 75
    move-object/from16 v17, v8

    const-string v18, "height"

    const/16 v19, 0x64

    invoke-static/range {v17 .. v19}, Landroid/ext/Script$multiChoice;->extractAttributeAsInt(Ljava/lang/String;Ljava/lang/String;I)I

    move-result v17

    move/from16 v12, v17

    .line 78
    move-object/from16 v17, v10

    const/16 v18, 0x0

    invoke-static/range {v17 .. v18}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v17

    move-object/from16 v13, v17

    .line 81
    move-object/from16 v17, v13

    const/16 v18, 0x0

    move-object/from16 v19, v13

    move-object/from16 v0, v19

    array-length v0, v0

    move/from16 v19, v0

    invoke-static/range {v17 .. v19}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    move-result-object v17

    move-object/from16 v14, v17

    .line 83
    move-object/from16 v17, v14

    if-eqz v17, :cond_11b

    .line 88
    new-instance v17, Landroid/ext/AutoResizeImageSpan;

    move-object/from16 v22, v17

    move-object/from16 v17, v22

    move-object/from16 v18, v22

    move-object/from16 v19, v14

    invoke-direct/range {v18 .. v19}, Landroid/ext/AutoResizeImageSpan;-><init>(Landroid/graphics/Bitmap;)V

    move-object/from16 v16, v17

    .line 91
    move-object/from16 v17, v5

    move-object/from16 v18, v16

    const/16 v19, 0x0

    const/16 v20, 0x1

    const/16 v21, 0x21

    invoke-virtual/range {v17 .. v21}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 96
    :cond_11b
    move-object/from16 v17, v2

    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v17

    const-string v18, "<font"

    invoke-virtual/range {v17 .. v18}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v17

    move/from16 v8, v17

    .line 97
    move-object/from16 v17, v2

    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v17

    const-string v18, ">"

    move/from16 v19, v8

    invoke-virtual/range {v17 .. v19}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v17

    const/16 v18, 0x1

    add-int/lit8 v17, v17, 0x1

    move/from16 v9, v17

    .line 98
    move/from16 v17, v8

    const/16 v18, -0x1

    move/from16 v0, v17

    move/from16 v1, v18

    if-eq v0, v1, :cond_1bb

    move/from16 v17, v9

    const/16 v18, -0x1

    move/from16 v0, v17

    move/from16 v1, v18

    if-eq v0, v1, :cond_1bb

    .line 100
    move-object/from16 v17, v2

    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v17

    move/from16 v18, v8

    move/from16 v19, v9

    invoke-virtual/range {v17 .. v19}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v17

    move-object/from16 v10, v17

    .line 103
    move-object/from16 v17, v10

    const-string v18, "#"

    invoke-virtual/range {v17 .. v18}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v17

    move/from16 v11, v17

    .line 104
    move-object/from16 v17, v10

    const-string v18, "\'"

    move/from16 v19, v11

    invoke-virtual/range {v17 .. v19}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v17

    move/from16 v12, v17

    .line 105
    move/from16 v17, v11

    const/16 v18, -0x1

    move/from16 v0, v17

    move/from16 v1, v18

    if-eq v0, v1, :cond_1bb

    move/from16 v17, v12

    const/16 v18, -0x1

    move/from16 v0, v17

    move/from16 v1, v18

    if-eq v0, v1, :cond_1bb

    .line 106
    move-object/from16 v17, v10

    move/from16 v18, v11

    move/from16 v19, v12

    invoke-virtual/range {v17 .. v19}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v17

    move-object/from16 v13, v17

    .line 107
    move-object/from16 v17, v13

    invoke-static/range {v17 .. v17}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v17

    move/from16 v14, v17

    .line 109
    move-object/from16 v17, v5

    new-instance v18, Landroid/text/style/ForegroundColorSpan;

    move-object/from16 v22, v18

    move-object/from16 v18, v22

    move-object/from16 v19, v22

    move/from16 v20, v14

    invoke-direct/range {v19 .. v20}, Landroid/text/style/ForegroundColorSpan;-><init>(I)V

    const/16 v19, 0x0

    move-object/from16 v20, v5

    invoke-virtual/range {v20 .. v20}, Landroid/text/SpannableString;->length()I

    move-result v20

    const/16 v21, 0x21

    invoke-virtual/range {v17 .. v21}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 113
    :cond_1bb
    move-object/from16 v17, v5

    move-object/from16 v2, v17

    return-object v2
.end method

.method public static myview(Landroid/content/Context;Ljava/lang/String;)Landroid/view/View;
    .registers 14

    .prologue
    .line 29
    move-object v0, p0

    move-object v1, p1

    new-instance v6, Landroid/widget/TextView;

    move-object v11, v6

    move-object v6, v11

    move-object v7, v11

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v3, v6

    .line 30
    move-object v6, v1

    invoke-static {v6}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;

    move-result-object v6

    move-object v4, v6

    .line 31
    move-object v6, v3

    move-object v7, v4

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 32
    move-object v6, v3

    const/16 v7, 0x1e

    const/16 v8, 0x1e

    const/16 v9, 0x1e

    const/16 v10, 0x1e

    invoke-virtual {v6, v7, v8, v9, v10}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 33
    move-object v6, v3

    const/16 v7, 0x14

    int-to-float v7, v7

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextSize(F)V

    .line 34
    move-object v6, v3

    new-instance v7, Landroid/view/ViewGroup$LayoutParams;

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    const/4 v9, -0x1

    const/4 v10, -0x2

    invoke-direct {v8, v9, v10}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 38
    move-object v6, v3

    const/16 v7, 0x11

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setGravity(I)V

    .line 39
    move-object v6, v3

    move-object v0, v6

    return-object v0
.end method


# virtual methods
.method a()Ljava/lang/String;
    .registers 2

    .prologue
    .line 2252
    const-string v0, "gg.multiChoice(table items [, table selection = {} [, string message = nil]]) -> table || nil"

    return-object v0
.end method

.method public b(Lluaj/ap;)Lluaj/ap;
    .registers 14

    .prologue
    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    .line 2258
    invoke-virtual {p1, v1}, Lluaj/ap;->t(I)Lluaj/LuaTable;

    move-result-object v0

    .line 2259
    const/4 v4, 0x2

    invoke-virtual {p1, v4, v3}, Lluaj/ap;->a(ILluaj/LuaTable;)Lluaj/LuaTable;

    move-result-object v4

    .line 2261
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 2262
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 2263
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 2265
    invoke-virtual {v0}, Lluaj/LuaTable;->S()Lluaj/z;

    move-result-object v8

    .line 2266
    :goto_1f
    invoke-virtual {v8}, Lluaj/z;->a()Z

    move-result v0

    if-nez v0, :cond_72

    .line 2274
    invoke-static {v7}, Landroid/ext/Tools;->a(Ljava/util/List;)[Z

    move-result-object v0

    iput-object v0, p0, Landroid/ext/Script$multiChoice;->d:[Z

    .line 2275
    iput-boolean v2, p0, Landroid/ext/Script$multiChoice;->e:Z

    .line 2277
    const/4 v0, 0x3

    const-string v1, ""

    invoke-virtual {p1, v0, v1}, Lluaj/ap;->c(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/ext/qk;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 2278
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_b0

    .line 2279
    new-instance v1, Ljava/lang/StringBuilder;

    const/16 v3, 0xa

    invoke-static {v3}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    move-object v1, v0

    .line 2284
    :goto_52
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v0

    new-array v0, v0, [Ljava/lang/CharSequence;

    invoke-virtual {v6, v0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/CharSequence;

    .line 2286
    monitor-enter p0

    .line 2287
    :try_start_5f
    new-instance v3, Landroid/ext/Script$multiChoice$1;

    invoke-direct {v3, p0, v1, v0}, Landroid/ext/Script$multiChoice$1;-><init>(Landroid/ext/Script$multiChoice;Ljava/lang/String;[Ljava/lang/CharSequence;)V

    invoke-static {v3}, Landroid/ext/rx;->a(Ljava/lang/Runnable;)V

    .line 2302
    invoke-static {p0}, Landroid/ext/Script;->a(Ljava/lang/Object;)V

    .line 2286
    monitor-exit p0
    :try_end_6b
    .catchall {:try_start_5f .. :try_end_6b} :catchall_b2

    .line 2305
    iget-boolean v0, p0, Landroid/ext/Script$multiChoice;->e:Z

    if-nez v0, :cond_b5

    .line 2306
    sget-object v0, Lluaj/LuaValue;->u:Lluaj/LuaValue;

    .line 2316
    :goto_71
    return-object v0

    .line 2267
    :cond_72
    invoke-virtual {v8}, Lluaj/z;->c()Lluaj/LuaValue;

    move-result-object v9

    .line 2268
    invoke-virtual {v8}, Lluaj/z;->d()Lluaj/LuaValue;

    move-result-object v0

    .line 2270
    sget v10, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v11, 0xb

    if-ge v10, v11, :cond_a5

    invoke-virtual {v0}, Lluaj/LuaValue;->y()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/ext/qk;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v10, -0x1

    invoke-static {v0, v10}, Landroid/ext/Tools;->a(Ljava/lang/CharSequence;I)Ljava/lang/CharSequence;

    move-result-object v0

    :goto_8d
    invoke-virtual {v6, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2271
    if-eqz v4, :cond_ae

    invoke-static {v4, v9, v2}, Landroid/ext/Script;->a(Lluaj/LuaTable;Lluaj/LuaValue;Z)Z

    move-result v0

    if-eqz v0, :cond_ae

    move v0, v1

    :goto_99
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v7, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2272
    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_1f

    .line 2270
    :cond_a5
    invoke-virtual {v0}, Lluaj/LuaValue;->y()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/ext/qk;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_8d

    :cond_ae
    move v0, v2

    .line 2271
    goto :goto_99

    :cond_b0
    move-object v1, v3

    .line 2281
    goto :goto_52

    .line 2286
    :catchall_b2
    move-exception v0

    :try_start_b3
    monitor-exit p0
    :try_end_b4
    .catchall {:try_start_b3 .. :try_end_b4} :catchall_b2

    throw v0

    .line 2309
    :cond_b5
    new-instance v1, Lluaj/LuaTable;

    invoke-direct {v1}, Lluaj/LuaTable;-><init>()V

    .line 2310
    :goto_ba
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lt v2, v0, :cond_c2

    move-object v0, v1

    .line 2316
    goto :goto_71

    .line 2311
    :cond_c2
    iget-object v0, p0, Landroid/ext/Script$multiChoice;->d:[Z

    aget-boolean v0, v0, v2

    if-eqz v0, :cond_d3

    .line 2312
    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lluaj/LuaValue;

    sget-object v3, Lluaj/LuaValue;->v:Lluaj/LuaBoolean;

    invoke-virtual {v1, v0, v3}, Lluaj/LuaTable;->c(Lluaj/LuaValue;Lluaj/LuaValue;)V

    .line 2310
    :cond_d3
    add-int/lit8 v2, v2, 0x1

    goto :goto_ba
.end method

.method protected m_()I
    .registers 2

    .prologue
    .line 2251
    const/4 v0, 0x3

    return v0
.end method

.method public onClick(Landroid/content/DialogInterface;I)V
    .registers 4

    .prologue
    .line 2329
    const/4 v0, -0x1

    if-ne p2, v0, :cond_6

    .line 2330
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/ext/Script$multiChoice;->e:Z

    .line 2332
    :cond_6
    return-void
.end method

.method public onClick(Landroid/content/DialogInterface;IZ)V
    .registers 5

    .prologue
    .line 2336
    iget-object v0, p0, Landroid/ext/Script$multiChoice;->d:[Z

    aput-boolean p3, v0, p2

    .line 2337
    return-void
.end method

.method public onDismiss(Landroid/content/DialogInterface;)V
    .registers 4

    .prologue
    .line 2321
    monitor-enter p0

    .line 2322
    :try_start_1
    invoke-virtual {p0}, Ljava/lang/Object;->notify()V

    .line 2321
    monitor-exit p0
    :try_end_5
    .catchall {:try_start_1 .. :try_end_5} :catchall_c

    .line 2324
    sget-object v0, Landroid/ext/MainService;->instance:Landroid/ext/MainService;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/ext/MainService;->b(Z)V

    .line 2325
    return-void

    .line 2321
    :catchall_c
    move-exception v0

    :try_start_d
    monitor-exit p0
    :try_end_e
    .catchall {:try_start_d .. :try_end_e} :catchall_c

    throw v0
.end method
