.class public Landroid/ext/CustomSpanTitle;
.super Ljava/lang/Object;
.source "CustomSpan.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/ext/CustomSpanTitle$100000000;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 4

    .prologue
    .line 59
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static myview(Landroid/content/Context;Ljava/lang/String;)Landroid/view/View;
    .registers 17

    .prologue
    .line 20
    move-object v0, p0

    move-object/from16 v1, p1

    new-instance v8, Landroid/widget/TextView;

    move-object v14, v8

    move-object v8, v14

    move-object v9, v14

    move-object v10, v0

    invoke-direct {v9, v10}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v3, v8

    .line 22
    move-object v8, v3

    const/16 v9, 0x14

    int-to-float v9, v9

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setTextSize(F)V

    .line 23
    move-object v8, v3

    invoke-virtual {v8}, Landroid/widget/TextView;->getTextSize()F

    move-result v8

    move v4, v8

    .line 24
    .line 26
    move-object v8, v1

    const/4 v9, 0x0

    new-instance v10, Landroid/ext/CustomSpanTitle$100000000;

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    move v12, v4

    move-object v13, v0

    invoke-direct {v11, v12, v13}, Landroid/ext/CustomSpanTitle$100000000;-><init>(FLandroid/content/Context;)V

    const/4 v11, 0x0

    check-cast v11, Landroid/text/Html$TagHandler;

    invoke-static {v8, v9, v10, v11}, Landroid/text/Html;->fromHtml(Ljava/lang/String;ILandroid/text/Html$ImageGetter;Landroid/text/Html$TagHandler;)Landroid/text/Spanned;

    move-result-object v8

    move-object v6, v8

    .line 50
    move-object v8, v3

    move-object v9, v6

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 51
    move-object v8, v3

    const/16 v9, 0x1e

    const/16 v10, 0x1e

    const/16 v11, 0x1e

    const/16 v12, 0x1e

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 52
    move-object v8, v3

    const/4 v9, 0x0

    const/high16 v10, 0x3f800000  # 1.0f

    invoke-virtual {v8, v9, v10}, Landroid/widget/TextView;->setLineSpacing(FF)V

    .line 53
    move-object v8, v3

    const/16 v9, 0x11

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setGravity(I)V

    .line 54
    move-object v8, v3

    new-instance v9, Landroid/view/ViewGroup$LayoutParams;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    const/4 v11, -0x1

    const/4 v12, -0x2

    invoke-direct {v10, v11, v12}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 58
    move-object v8, v3

    move-object v0, v8

    return-object v0
.end method
