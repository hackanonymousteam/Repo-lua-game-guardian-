.class public Landroid/ext/AutoResizeImageSpan;
.super Landroid/text/style/DynamicDrawableSpan;
.source "AutoResizeImageSpan.java"


# instance fields
.field private drawable:Landroid/graphics/drawable/Drawable;

.field private sized:Z


# direct methods
.method public constructor <init>(Landroid/graphics/Bitmap;)V
    .registers 6

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Landroid/text/style/DynamicDrawableSpan;-><init>(I)V

    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object v0

    new-instance v1, Landroid/graphics/drawable/BitmapDrawable;

    invoke-direct {v1, v0, p1}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V

    iput-object v1, p0, Landroid/ext/AutoResizeImageSpan;->drawable:Landroid/graphics/drawable/Drawable;

    iget-object v2, p0, Landroid/ext/AutoResizeImageSpan;->drawable:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v0

    iget-object v2, p0, Landroid/ext/AutoResizeImageSpan;->drawable:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v1

    if-gtz v0, :cond_21

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v0

    :cond_21
    if-gtz v1, :cond_27

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v1

    :cond_27
    iget-object v2, p0, Landroid/ext/AutoResizeImageSpan;->drawable:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x0

    invoke-virtual {v2, v3, v3, v0, v1}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/ext/AutoResizeImageSpan;->sized:Z

    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;Ljava/lang/CharSequence;IIFIIILandroid/graphics/Paint;)V
    .registers 16

    iget-object v0, p0, Landroid/ext/AutoResizeImageSpan;->drawable:Landroid/graphics/drawable/Drawable;

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v1

    sub-int v2, p8, p6

    iget-object v3, p0, Landroid/ext/AutoResizeImageSpan;->drawable:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v3}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v3

    invoke-virtual {v3}, Landroid/graphics/Rect;->height()I

    move-result v4

    sub-int v5, v2, v4

    div-int/lit8 v5, v5, 0x2

    add-int/2addr v5, p6

    int-to-float v2, v5

    invoke-virtual {p1, p5, v2}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {p1, v1}, Landroid/graphics/Canvas;->restoreToCount(I)V

    return-void
.end method

.method public getDrawable()Landroid/graphics/drawable/Drawable;
    .registers 2

    iget-object v0, p0, Landroid/ext/AutoResizeImageSpan;->drawable:Landroid/graphics/drawable/Drawable;

    return-object v0
.end method

.method public getSize(Landroid/graphics/Paint;Ljava/lang/CharSequence;IILandroid/graphics/Paint$FontMetricsInt;)I
    .registers 16

    iget-object v0, p0, Landroid/ext/AutoResizeImageSpan;->drawable:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v1

    invoke-virtual {p1}, Landroid/graphics/Paint;->getFontMetricsInt()Landroid/graphics/Paint$FontMetricsInt;

    move-result-object v2

    iget v3, v2, Landroid/graphics/Paint$FontMetricsInt;->descent:I

    iget v4, v2, Landroid/graphics/Paint$FontMetricsInt;->ascent:I

    sub-int v5, v3, v4

    const/16 v9, 0x3c

    if-ge v5, v9, :cond_15

    move v5, v9

    :cond_15
    invoke-virtual {v1}, Landroid/graphics/Rect;->height()I

    move-result v6

    iget-boolean v7, p0, Landroid/ext/AutoResizeImageSpan;->sized:Z

    if-eqz v7, :cond_1f

    if-eq v6, v5, :cond_36

    :cond_1f
    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    move-result v7

    if-lez v6, :cond_36

    int-to-float v8, v5

    int-to-float v9, v6

    div-float v8, v8, v9

    int-to-float v7, v7

    mul-float v7, v7, v8

    float-to-int v7, v7

    iget-object v0, p0, Landroid/ext/AutoResizeImageSpan;->drawable:Landroid/graphics/drawable/Drawable;

    const/4 v9, 0x0

    invoke-virtual {v0, v9, v9, v7, v5}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/ext/AutoResizeImageSpan;->sized:Z

    :cond_36
    iget-object v0, p0, Landroid/ext/AutoResizeImageSpan;->drawable:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v1

    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    move-result v7

    if-eqz p5, :cond_62

    iget-object v0, p0, Landroid/ext/AutoResizeImageSpan;->drawable:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v1

    invoke-virtual {v1}, Landroid/graphics/Rect;->height()I

    move-result v6

    iget v0, v2, Landroid/graphics/Paint$FontMetricsInt;->ascent:I

    iget v1, v2, Landroid/graphics/Paint$FontMetricsInt;->descent:I

    add-int v0, v0, v1

    div-int/lit8 v0, v0, 0x2

    div-int/lit8 v1, v6, 0x2

    sub-int v3, v0, v1

    add-int v4, v3, v6

    iput v3, p5, Landroid/graphics/Paint$FontMetricsInt;->ascent:I

    iput v3, p5, Landroid/graphics/Paint$FontMetricsInt;->top:I

    iput v4, p5, Landroid/graphics/Paint$FontMetricsInt;->descent:I

    iput v4, p5, Landroid/graphics/Paint$FontMetricsInt;->bottom:I

    :cond_62
    return v7
.end method
