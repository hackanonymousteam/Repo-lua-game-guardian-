.class final Landroid/ext/Script$choice;
.super Landroid/ext/Script$ApiFunction;
.source "src"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;
.implements Landroid/content/DialogInterface$OnDismissListener;


# instance fields
.field private volatile d:I


# direct methods
.method constructor <init>()V
    .registers 2

    .prologue
    .line 2121
    invoke-direct {p0}, Landroid/ext/Script$ApiFunction;-><init>()V

    .line 2124
    const/4 v0, 0x0

    iput v0, p0, Landroid/ext/Script$choice;->d:I

    .line 2121
    return-void
.end method

.method private static extractAttributeAsInt(Ljava/lang/String;Ljava/lang/String;I)I
    .registers 16

    .prologue
    .line 115
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    move-object v10, v1

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    const-string v10, "=\'"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    move-object v4, v9

    .line 116
    move-object v9, v0

    move-object v10, v4

    invoke-virtual {v9, v10}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v9

    move v5, v9

    .line 117
    move v9, v5

    const/4 v10, -0x1

    if-ne v9, v10, :cond_45

    .line 118
    new-instance v9, Ljava/lang/StringBuffer;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    move-object v10, v1

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    const-string v10, "=\""

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    move-object v4, v9

    .line 119
    move-object v9, v0

    move-object v10, v4

    invoke-virtual {v9, v10}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v9

    move v5, v9

    .line 121
    :cond_45
    move v9, v5

    const/4 v10, -0x1

    if-eq v9, v10, :cond_7a

    .line 122
    move v9, v5

    move-object v10, v4

    invoke-virtual {v10}, Ljava/lang/String;->length()I

    move-result v10

    add-int/2addr v9, v10

    move v5, v9

    .line 123
    move-object v9, v0

    const-string v10, "\'"

    move v11, v5

    invoke-virtual {v9, v10, v11}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v9

    move v6, v9

    .line 124
    move v9, v6

    const/4 v10, -0x1

    if-ne v9, v10, :cond_67

    .line 125
    move-object v9, v0

    const-string v10, "\""

    move v11, v5

    invoke-virtual {v9, v10, v11}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v9

    move v6, v9

    .line 127
    :cond_67
    move v9, v6

    const/4 v10, -0x1

    if-eq v9, v10, :cond_7a

    .line 129
    move-object v9, v0

    move v10, v5

    move v11, v6

    :try_start_6e
    invoke-virtual {v9, v10, v11}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    :try_end_75
    .catch Ljava/lang/NumberFormatException; {:try_start_6e .. :try_end_75} :catch_78

    move-result v9

    move v0, v9

    .line 135
    :goto_77
    return v0

    .line 129
    :catch_78
    move-exception v9

    move-object v7, v9

    .line 135
    :cond_7a
    move v9, v2

    move v0, v9

    goto :goto_77
.end method

.method public static getSpannableItems([Ljava/lang/CharSequence;)[Ljava/lang/CharSequence;
    .registers 10

    .prologue
    .line 43
    move-object v0, p0

    move-object v5, v0

    array-length v5, v5

    new-array v5, v5, [Ljava/lang/CharSequence;

    move-object v2, v5

    .line 44
    const/4 v5, 0x0

    move v3, v5

    :goto_8
    move v5, v3

    move-object v6, v0

    array-length v6, v6

    if-lt v5, v6, :cond_10

    .line 47
    move-object v5, v2

    move-object v0, v5

    return-object v0

    .line 45
    :cond_10
    move-object v5, v2

    move v6, v3

    move-object v7, v0

    move v8, v3

    aget-object v7, v7, v8

    invoke-static {v7}, Landroid/ext/Script$choice;->getSpannedString(Ljava/lang/CharSequence;)Landroid/text/SpannableString;

    move-result-object v7

    aput-object v7, v5, v6

    .line 44
    add-int/lit8 v3, v3, 0x1

    goto :goto_8
.end method

.method public static getSpannedString(Ljava/lang/CharSequence;)Landroid/text/SpannableString;
    .registers 24

    .prologue
    .line 57
    move-object/from16 v2, p0

    move-object/from16 v17, v2

    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v17

    const-string v18, "<"

    invoke-virtual/range {v17 .. v18}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v17

    if-nez v17, :cond_33

    new-instance v17, Ljava/lang/StringBuilder;

    move-object/from16 v22, v17

    move-object/from16 v17, v22

    move-object/from16 v18, v22

    invoke-direct/range {v18 .. v18}, Ljava/lang/StringBuilder;-><init>()V

    const-string v18, "<img src=\"data:image/png;base64,"

    invoke-virtual/range {v17 .. v18}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    move-object/from16 v18, v2

    invoke-virtual/range {v17 .. v18}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v17

    const-string v18, "\">"

    invoke-virtual/range {v17 .. v18}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v17

    invoke-virtual/range {v17 .. v17}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    move-object/from16 v2, v17

    .line 58
    :cond_33
    move-object/from16 v17, v2

    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v17

    const/16 v18, 0x3f

    const/16 v19, 0x0

    check-cast v19, Landroid/text/Html$ImageGetter;

    const/16 v20, 0x0

    check-cast v20, Landroid/text/Html$TagHandler;

    invoke-static/range {v17 .. v20}, Landroid/text/Html;->fromHtml(Ljava/lang/String;ILandroid/text/Html$ImageGetter;Landroid/text/Html$TagHandler;)Landroid/text/Spanned;

    move-result-object v17

    move-object/from16 v4, v17

    .line 59
    new-instance v17, Landroid/text/SpannableString;

    move-object/from16 v22, v17

    move-object/from16 v17, v22

    move-object/from16 v18, v22

    move-object/from16 v19, v4

    invoke-direct/range {v18 .. v19}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    move-object/from16 v5, v17

    .line 62
    move-object/from16 v17, v2

    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v17

    const-string v18, "<img"

    invoke-virtual/range {v17 .. v18}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v17

    move/from16 v6, v17

    .line 63
    move-object/from16 v17, v2

    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v17

    const-string v18, ">"

    move/from16 v19, v6

    invoke-virtual/range {v17 .. v19}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v17

    const/16 v18, 0x1

    add-int/lit8 v17, v17, 0x1

    move/from16 v7, v17

    .line 64
    move/from16 v17, v6

    const/16 v18, -0x1

    move/from16 v0, v17

    move/from16 v1, v18

    if-eq v0, v1, :cond_11b

    move/from16 v17, v7

    const/16 v18, -0x1

    move/from16 v0, v17

    move/from16 v1, v18

    if-eq v0, v1, :cond_11b

    .line 66
    move-object/from16 v17, v2

    move/from16 v18, v6

    move/from16 v19, v7

    invoke-interface/range {v17 .. v19}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object v17

    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v17

    move-object/from16 v8, v17

    .line 69
    move-object/from16 v17, v8

    const-string v18, "base64,"

    invoke-virtual/range {v17 .. v18}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v17

    move/from16 v9, v17

    .line 70
    move/from16 v17, v9

    const/16 v18, -0x1

    move/from16 v0, v17

    move/from16 v1, v18

    if-eq v0, v1, :cond_11b

    .line 71
    move-object/from16 v17, v8

    move/from16 v18, v9

    const/16 v19, 0x7

    add-int/lit8 v18, v18, 0x7

    move-object/from16 v19, v8

    const-string v20, "\">"

    invoke-virtual/range {v19 .. v20}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v19

    invoke-virtual/range {v17 .. v19}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v17

    move-object/from16 v10, v17

    .line 74
    move-object/from16 v17, v8

    const-string v18, "width"

    const/16 v19, 0x64

    invoke-static/range {v17 .. v19}, Landroid/ext/Script$choice;->extractAttributeAsInt(Ljava/lang/String;Ljava/lang/String;I)I

    move-result v17

    move/from16 v11, v17

    .line 75
    move-object/from16 v17, v8

    const-string v18, "height"

    const/16 v19, 0x64

    invoke-static/range {v17 .. v19}, Landroid/ext/Script$choice;->extractAttributeAsInt(Ljava/lang/String;Ljava/lang/String;I)I

    move-result v17

    move/from16 v12, v17

    .line 78
    move-object/from16 v17, v10

    const/16 v18, 0x0

    invoke-static/range {v17 .. v18}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v17

    move-object/from16 v13, v17

    .line 81
    move-object/from16 v17, v13

    const/16 v18, 0x0

    move-object/from16 v19, v13

    move-object/from16 v0, v19

    array-length v0, v0

    move/from16 v19, v0

    invoke-static/range {v17 .. v19}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    move-result-object v17

    move-object/from16 v14, v17

    .line 83
    move-object/from16 v17, v14

    if-eqz v17, :cond_11b

    .line 88
    new-instance v17, Landroid/ext/AutoResizeImageSpan;

    move-object/from16 v22, v17

    move-object/from16 v17, v22

    move-object/from16 v18, v22

    move-object/from16 v19, v14

    invoke-direct/range {v18 .. v19}, Landroid/ext/AutoResizeImageSpan;-><init>(Landroid/graphics/Bitmap;)V

    move-object/from16 v16, v17

    .line 91
    move-object/from16 v17, v5

    move-object/from16 v18, v16

    const/16 v19, 0x0

    const/16 v20, 0x1

    const/16 v21, 0x21

    invoke-virtual/range {v17 .. v21}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 96
    :cond_11b
    move-object/from16 v17, v2

    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v17

    const-string v18, "<font"

    invoke-virtual/range {v17 .. v18}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v17

    move/from16 v8, v17

    .line 97
    move-object/from16 v17, v2

    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v17

    const-string v18, ">"

    move/from16 v19, v8

    invoke-virtual/range {v17 .. v19}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v17

    const/16 v18, 0x1

    add-int/lit8 v17, v17, 0x1

    move/from16 v9, v17

    .line 98
    move/from16 v17, v8

    const/16 v18, -0x1

    move/from16 v0, v17

    move/from16 v1, v18

    if-eq v0, v1, :cond_1bb

    move/from16 v17, v9

    const/16 v18, -0x1

    move/from16 v0, v17

    move/from16 v1, v18

    if-eq v0, v1, :cond_1bb

    .line 100
    move-object/from16 v17, v2

    invoke-interface/range {v17 .. v17}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v17

    move/from16 v18, v8

    move/from16 v19, v9

    invoke-virtual/range {v17 .. v19}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v17

    move-object/from16 v10, v17

    .line 103
    move-object/from16 v17, v10

    const-string v18, "#"

    invoke-virtual/range {v17 .. v18}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v17

    move/from16 v11, v17

    .line 104
    move-object/from16 v17, v10

    const-string v18, "\'"

    move/from16 v19, v11

    invoke-virtual/range {v17 .. v19}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v17

    move/from16 v12, v17

    .line 105
    move/from16 v17, v11

    const/16 v18, -0x1

    move/from16 v0, v17

    move/from16 v1, v18

    if-eq v0, v1, :cond_1bb

    move/from16 v17, v12

    const/16 v18, -0x1

    move/from16 v0, v17

    move/from16 v1, v18

    if-eq v0, v1, :cond_1bb

    .line 106
    move-object/from16 v17, v10

    move/from16 v18, v11

    move/from16 v19, v12

    invoke-virtual/range {v17 .. v19}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v17

    move-object/from16 v13, v17

    .line 107
    move-object/from16 v17, v13

    invoke-static/range {v17 .. v17}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v17

    move/from16 v14, v17

    .line 109
    move-object/from16 v17, v5

    new-instance v18, Landroid/text/style/ForegroundColorSpan;

    move-object/from16 v22, v18

    move-object/from16 v18, v22

    move-object/from16 v19, v22

    move/from16 v20, v14

    invoke-direct/range {v19 .. v20}, Landroid/text/style/ForegroundColorSpan;-><init>(I)V

    const/16 v19, 0x0

    move-object/from16 v20, v5

    invoke-virtual/range {v20 .. v20}, Landroid/text/SpannableString;->length()I

    move-result v20

    const/16 v21, 0x21

    invoke-virtual/range {v17 .. v21}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 113
    :cond_1bb
    move-object/from16 v17, v5

    move-object/from16 v2, v17

    return-object v2
.end method

.method public static myview(Landroid/content/Context;Ljava/lang/String;)Landroid/view/View;
    .registers 14

    .prologue
    .line 29
    move-object v0, p0

    move-object v1, p1

    new-instance v6, Landroid/widget/TextView;

    move-object v11, v6

    move-object v6, v11

    move-object v7, v11

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v3, v6

    .line 30
    move-object v6, v1

    invoke-static {v6}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;

    move-result-object v6

    move-object v4, v6

    .line 31
    move-object v6, v3

    move-object v7, v4

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 32
    move-object v6, v3

    const/16 v7, 0x1e

    const/16 v8, 0x1e

    const/16 v9, 0x1e

    const/16 v10, 0x1e

    invoke-virtual {v6, v7, v8, v9, v10}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 33
    move-object v6, v3

    const/16 v7, 0x14

    int-to-float v7, v7

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextSize(F)V

    .line 34
    move-object v6, v3

    new-instance v7, Landroid/view/ViewGroup$LayoutParams;

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    const/4 v9, -0x1

    const/4 v10, -0x2

    invoke-direct {v8, v9, v10}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 38
    move-object v6, v3

    const/16 v7, 0x11

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setGravity(I)V

    .line 39
    move-object v6, v3

    move-object v0, v6

    return-object v0
.end method


# virtual methods
.method a()Ljava/lang/String;
    .registers 2

    .prologue
    .line 2123
    const-string v0, "gg.choice(table items [, string selected = nil [, string message = nil]]) -> string || nil"

    return-object v0
.end method

.method public b(Lluaj/ap;)Lluaj/ap;
    .registers 12

    .prologue
    const/4 v0, -0x1

    .line 2128
    const/4 v1, 0x1

    invoke-virtual {p1, v1}, Lluaj/ap;->t(I)Lluaj/LuaTable;

    move-result-object v2

    .line 2129
    const/4 v1, 0x2

    invoke-virtual {p1, v1}, Lluaj/ap;->c(I)Lluaj/LuaValue;

    move-result-object v3

    .line 2131
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 2132
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 2134
    const/4 v1, 0x0

    .line 2138
    invoke-virtual {v2}, Lluaj/LuaTable;->S()Lluaj/z;

    move-result-object v2

    move v5, v0

    .line 2139
    :goto_1b
    invoke-virtual {v2}, Lluaj/z;->a()Z

    move-result v7

    if-nez v7, :cond_68

    .line 2153
    const/4 v1, 0x3

    const-string v2, ""

    invoke-virtual {p1, v1, v2}, Lluaj/ap;->c(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/ext/qk;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 2154
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_88

    .line 2155
    new-instance v2, Ljava/lang/StringBuilder;

    const/16 v7, 0xa

    invoke-static {v7}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    move-result-object v7

    invoke-direct {v2, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 2160
    :goto_45
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v1

    new-array v1, v1, [Ljava/lang/CharSequence;

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [Ljava/lang/CharSequence;

    .line 2162
    iput v0, p0, Landroid/ext/Script$choice;->d:I

    .line 2164
    monitor-enter p0

    .line 2165
    :try_start_54
    new-instance v0, Landroid/ext/Script$choice$1;

    move-object v1, p0

    invoke-direct/range {v0 .. v5}, Landroid/ext/Script$choice$1;-><init>(Landroid/ext/Script$choice;Ljava/lang/String;Lluaj/LuaValue;[Ljava/lang/CharSequence;I)V

    invoke-static {v0}, Landroid/ext/rx;->a(Ljava/lang/Runnable;)V

    .line 2183
    invoke-static {p0}, Landroid/ext/Script;->a(Ljava/lang/Object;)V

    .line 2164
    monitor-exit p0
    :try_end_61
    .catchall {:try_start_54 .. :try_end_61} :catchall_8a

    .line 2186
    iget v0, p0, Landroid/ext/Script$choice;->d:I

    if-gez v0, :cond_8d

    sget-object v0, Lluaj/LuaValue;->u:Lluaj/LuaValue;

    :goto_67
    return-object v0

    .line 2140
    :cond_68
    invoke-virtual {v2}, Lluaj/z;->c()Lluaj/LuaValue;

    move-result-object v7

    .line 2141
    invoke-virtual {v2}, Lluaj/z;->d()Lluaj/LuaValue;

    move-result-object v8

    .line 2143
    invoke-virtual {v7, v3}, Lluaj/LuaValue;->b(Lluaj/LuaValue;)Z

    move-result v9

    if-eqz v9, :cond_77

    move v5, v1

    .line 2147
    :cond_77
    invoke-virtual {v8}, Lluaj/LuaValue;->y()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/ext/qk;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v4, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2148
    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2149
    add-int/lit8 v1, v1, 0x1

    goto :goto_1b

    .line 2157
    :cond_88
    const/4 v2, 0x0

    goto :goto_45

    .line 2164
    :catchall_8a
    move-exception v0

    :try_start_8b
    monitor-exit p0
    :try_end_8c
    .catchall {:try_start_8b .. :try_end_8c} :catchall_8a

    throw v0

    .line 2186
    :cond_8d
    iget v0, p0, Landroid/ext/Script$choice;->d:I

    invoke-virtual {v6, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lluaj/LuaValue;

    goto :goto_67
.end method

.method protected m_()I
    .registers 2

    .prologue
    .line 2122
    const/4 v0, 0x3

    return v0
.end method

.method public onClick(Landroid/content/DialogInterface;I)V
    .registers 3

    .prologue
    .line 2199
    iput p2, p0, Landroid/ext/Script$choice;->d:I

    .line 2200
    invoke-static {p1}, Landroid/ext/Tools;->a(Landroid/content/DialogInterface;)V

    .line 2201
    return-void
.end method

.method public onDismiss(Landroid/content/DialogInterface;)V
    .registers 4

    .prologue
    .line 2191
    monitor-enter p0

    .line 2192
    :try_start_1
    invoke-virtual {p0}, Ljava/lang/Object;->notify()V

    .line 2191
    monitor-exit p0
    :try_end_5
    .catchall {:try_start_1 .. :try_end_5} :catchall_c

    .line 2194
    sget-object v0, Landroid/ext/MainService;->instance:Landroid/ext/MainService;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/ext/MainService;->b(Z)V

    .line 2195
    return-void

    .line 2191
    :catchall_c
    move-exception v0

    :try_start_d
    monitor-exit p0
    :try_end_e
    .catchall {:try_start_d .. :try_end_e} :catchall_c

    throw v0
.end method
