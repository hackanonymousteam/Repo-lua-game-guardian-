


--gg.searchNumber("100;200;300", gg.TYPE_FLOAT)
--gg.refineNumber("100", gg.TYPE_FLOAT)
--gg.getResults(500)

    
   gg.hideSearch()