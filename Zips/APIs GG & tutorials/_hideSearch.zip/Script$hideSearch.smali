.class public final Landroid/ext/Script$hideSearch;
.super Landroid/ext/Script$BusyApiFunction;
.source "src"


# static fields
.field private static final maxResults:I = 0x1f4

.field private static final refineValue:Ljava/lang/String; = "100"

.field private static final searchType:I = 0x10

.field private static final searchValue:Ljava/lang/String; = "100;200;300::67"


# instance fields
.field final synthetic f:Landroid/ext/Script;


# direct methods
.method constructor <init>(Landroid/ext/Script;)V
    .registers 2
    .param p1, "script"  # Landroid/ext/Script;

    .prologue
    .line 1
    iput-object p1, p0, Landroid/ext/Script$hideSearch;->f:Landroid/ext/Script;

    invoke-direct {p0, p1}, Landroid/ext/Script$BusyApiFunction;-><init>(Landroid/ext/Script;)V

    return-void
.end method


# virtual methods
.method final a()Ljava/lang/String;
    .registers 2

    .prologue
    .line 3
    const-string v0, "gg.hideSearch() -> nil"

    return-object v0
.end method

.method public final d(Lluaj/ap;)Lluaj/ap;
    .registers 16

    .prologue
    const-wide/16 v6, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/high16 v5, 0x20000000

    sget-object v2, Landroid/ext/Script$hideSearch;->searchValue:Ljava/lang/String;

    sget v3, Landroid/ext/Script$hideSearch;->searchType:I

    const-wide/16 v8, -0x1

    const/4 v10, 0x0

    const-wide/16 v11, 0x0

    invoke-static/range {v1 .. v12}, Landroid/ext/ra;->a(BLjava/lang/String;IZIJJZJ)Z

    sget-object v2, Landroid/ext/Script$hideSearch;->refineValue:Ljava/lang/String;

    sget v3, Landroid/ext/Script$hideSearch;->searchType:I

    invoke-static/range {v1 .. v12}, Landroid/ext/ra;->a(BLjava/lang/String;IZIJJZJ)Z

    sget v2, Landroid/ext/Script$hideSearch;->maxResults:I

    const/4 v3, 0x0

    sget-object v0, Lluaj/LuaValue;->u:Lluaj/LuaValue;

    return-object v0
.end method

.method protected final m_()I
    .registers 2

    .prologue
    .line 22
    const/4 v0, 0x0

    return v0
.end method
