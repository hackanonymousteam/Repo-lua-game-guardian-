HOME = 1
function HOME()

multi = gg.multiChoice({
      "<font color='#FF0000'>MAGIC BULLET</font>",
      "<font color='#00FF00'>UNDERGROUND ON</font>",
      "<font color='#0000FF'>UNDERGROUND OFF</font>",
      "◖ EXIT ◗"
  })
  if multi == nil then else
if multi[1] == true then speed() end
if multi[2] == true then drone() end
if multi[3] == true then teleport() end
if multi[4] == true then ch6() end
end
HOMEDM = -1
end
  function speed()
  end
  
  function drone()
  end
  
  function teleport()
  end
  
  function ch6()
os.exit()
end

while true do 
  if gg.isVisible(false) then 
   HOMEDM = 1
    gg.setVisible(false) 
gg.toast("☑️ by batman games")
  end 
  if HOMEDM == 1 then HOME() end 
 end
 