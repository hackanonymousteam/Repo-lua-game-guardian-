-- =========================
-- MegatronFog
-- =========================
a = gg.MegatronFogEncode("Batman")
print("MegatronFogEncode:", a)

aa = gg.MegatronFogDecode(a)
print("MegatronFogDecode:", aa)


-- =========================
-- Morse
-- =========================
b = gg.MorseEncode("Batman")
print("MorseEncode:", b)

bb = gg.MorseDecode(b)
print("MorseDecode:", bb)


-- =========================
-- Octal
-- =========================
c = gg.OctalEncode("Batman")
print("OctalEncode:", c)

cc = gg.OctalDecode(c)
print("OctalDecode:", cc)


-- =========================
-- Rot13
-- =========================
d = gg.Rot13Encode("Batman")
print("Rot13Encode:", d)

dd = gg.Rot13Decode(d)
print("Rot13Decode:", dd)


-- =========================
-- SHA-1
-- =========================
e = gg.Sha1Encode("Batman")
print("Sha1Encode:", e)

ee = gg.Sha1Decode(e)
print("Sha1Decode:", ee)


-- =========================
-- SHA-256
-- =========================
f = gg.Sha256Encode("Batman")
print("Sha256Encode:", f)

ff = gg.Sha256Decode(f)
print("Sha256Decode:", ff)


-- =========================
-- SHA-384
-- =========================
g = gg.Sha384Encode("Batman")
print("Sha384Encode:", g)

ggg = gg.Sha384Decode(g)
print("Sha384Decode:", ggg)


-- =========================
-- SHA-512
-- =========================
h = gg.Sha512Encode("Batman")
print("Sha512Encode:", h)

hh = gg.Sha512Decode(h)
print("Sha512Decode:", hh)