.class public Landroid/fix/TabHost;
.super Landroid/widget/TabHost;
.source "src"


# instance fields
.field private mDragStartX:F

.field private mDragStartY:F

.field private mDragTouchAreaHeight:I

.field private mDragging:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    .prologue
    .line 22
    invoke-direct {p0, p1}, Landroid/widget/TabHost;-><init>(Landroid/content/Context;)V

    .line 23
    const/high16 v0, 0x42480000  # 50.0f

    invoke-virtual {p0, v0}, Landroid/fix/TabHost;->setDragTouchAreaHeight(F)V

    .line 24
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 4

    .prologue
    .line 18
    invoke-direct {p0, p1, p2}, Landroid/widget/TabHost;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 19
    const/high16 v0, 0x42480000  # 50.0f

    invoke-virtual {p0, v0}, Landroid/fix/TabHost;->setDragTouchAreaHeight(F)V

    .line 20
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 5

    .prologue
    .line 14
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/TabHost;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 15
    const/high16 v0, 0x42480000  # 50.0f

    invoke-virtual {p0, v0}, Landroid/fix/TabHost;->setDragTouchAreaHeight(F)V

    .line 16
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .registers 6

    .prologue
    .line 10
    invoke-direct {p0, p1, p2, p3, p4}, Landroid/widget/TabHost;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    .line 11
    const/high16 v0, 0x42480000  # 50.0f

    invoke-virtual {p0, v0}, Landroid/fix/TabHost;->setDragTouchAreaHeight(F)V

    .line 12
    return-void
.end method


# virtual methods
.method public onInterceptTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 6

    .prologue
    const/4 v0, 0x1

    .line 55
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v1

    if-nez v1, :cond_21

    .line 56
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    iget v2, p0, Landroid/fix/TabHost;->mDragTouchAreaHeight:I

    int-to-float v2, v2

    cmpg-float v1, v1, v2

    if-gez v1, :cond_21

    .line 57
    iput-boolean v0, p0, Landroid/fix/TabHost;->mDragging:Z

    .line 58
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawX()F

    move-result v1

    iput v1, p0, Landroid/fix/TabHost;->mDragStartX:F

    .line 59
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawY()F

    move-result v1

    iput v1, p0, Landroid/fix/TabHost;->mDragStartY:F

    .line 63
    :goto_20
    return v0

    :cond_21
    const/4 v0, 0x0

    goto :goto_20
.end method

.method protected onMeasure(II)V
    .registers 6

    .prologue
    .line 46
    :try_start_0
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v0

    div-int/lit8 v0, v0, 0x2

    const/high16 v1, 0x40000000  # 2.0f

    invoke-static {v0, v1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v0

    .line 47
    invoke-super {p0, v0, p2}, Landroid/widget/TabHost;->onMeasure(II)V
    :try_end_f
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_f} :catch_10

    .line 52
    :goto_f
    return-void

    .line 48
    :catch_10
    move-exception v0

    .line 49
    invoke-static {v0}, Landroid/ext/la;->a(Ljava/lang/Throwable;)I

    .line 50
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    const/4 v2, 0x0

    invoke-static {v1, v0, v2}, Landroid/ext/ho;->a(Ljava/lang/Thread;Ljava/lang/Throwable;Z)Ljava/lang/String;

    goto :goto_f
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 7

    .prologue
    const/4 v4, 0x0

    .line 68
    iget-boolean v0, p0, Landroid/fix/TabHost;->mDragging:Z

    if-eqz v0, :cond_3c

    .line 69
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    packed-switch v0, :pswitch_data_42

    .line 87
    :goto_c
    const/4 v0, 0x1

    .line 89
    :goto_d
    return v0

    .line 71
    :pswitch_e  #0x2
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawX()F

    move-result v0

    iget v1, p0, Landroid/fix/TabHost;->mDragStartX:F

    sub-float/2addr v0, v1

    .line 72
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawY()F

    move-result v1

    iget v2, p0, Landroid/fix/TabHost;->mDragStartY:F

    sub-float/2addr v1, v2

    .line 73
    invoke-virtual {p0}, Landroid/fix/TabHost;->getX()F

    move-result v2

    add-float/2addr v0, v2

    .line 74
    invoke-virtual {p0}, Landroid/fix/TabHost;->getY()F

    move-result v2

    add-float/2addr v1, v2

    .line 75
    invoke-virtual {p0, v0}, Landroid/fix/TabHost;->setX(F)V

    .line 76
    invoke-virtual {p0, v1}, Landroid/fix/TabHost;->setY(F)V

    .line 77
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawX()F

    move-result v0

    iput v0, p0, Landroid/fix/TabHost;->mDragStartX:F

    .line 78
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawY()F

    move-result v0

    iput v0, p0, Landroid/fix/TabHost;->mDragStartY:F

    goto :goto_c

    .line 81
    :pswitch_39  #0x1, 0x3
    iput-boolean v4, p0, Landroid/fix/TabHost;->mDragging:Z

    goto :goto_c

    .line 89
    :cond_3c
    invoke-super {p0, p1}, Landroid/widget/TabHost;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v0

    goto :goto_d

    nop

    .line 69
    :pswitch_data_42
    .packed-switch 0x1
        :pswitch_39  #00000001
        :pswitch_e  #00000002
        :pswitch_39  #00000003
    .end packed-switch
.end method

.method public playSoundEffect(I)V
    .registers 3

    .prologue
    .line 28
    :try_start_0
    invoke-super {p0, p1}, Landroid/widget/TabHost;->playSoundEffect(I)V
    :try_end_3
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_3} :catch_4

    .line 32
    :goto_3
    return-void

    .line 29
    :catch_4
    move-exception v0

    .line 30
    invoke-static {v0}, Landroid/ext/la;->a(Ljava/lang/Throwable;)I

    goto :goto_3
.end method

.method public sendAccessibilityEvent(I)V
    .registers 3

    .prologue
    .line 37
    :try_start_0
    invoke-super {p0, p1}, Landroid/widget/TabHost;->sendAccessibilityEvent(I)V
    :try_end_3
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_3} :catch_4

    .line 41
    :goto_3
    return-void

    .line 38
    :catch_4
    move-exception v0

    .line 39
    invoke-static {v0}, Landroid/ext/la;->a(Ljava/lang/Throwable;)I

    goto :goto_3
.end method

.method public setDragTouchAreaHeight(F)V
    .registers 4

    .prologue
    .line 93
    invoke-virtual {p0}, Landroid/fix/TabHost;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    .line 94
    mul-float/2addr v0, p1

    float-to-int v0, v0

    iput v0, p0, Landroid/fix/TabHost;->mDragTouchAreaHeight:I

    .line 95
    return-void
.end method
