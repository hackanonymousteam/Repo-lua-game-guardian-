edit res/layout_v21/service_dialog.xml

remove gravity center
adjust layout widht

add android:layout_marginTop="20.0dp"
        