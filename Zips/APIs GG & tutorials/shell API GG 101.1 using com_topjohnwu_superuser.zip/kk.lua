local resultado = gg.executeShell("id")
print(resultado)

local resultado = gg.executeShell("getprop ro.build.version.release")
print("Android version: " .. resultado)

local resultado = gg.executeShell("su -c 'echo root'")
if resultado:find("root") then
    print("Has root!")
end

print("=== System Information ===")

local android = gg.executeShell("getprop ro.build.version.release")
print("Android: " .. android)

local sdk = gg.executeShell("getprop ro.build.version.sdk")
print("SDK: " .. sdk)

local brand = gg.executeShell("getprop ro.product.brand")
print("Brand: " .. brand)

local model = gg.executeShell("getprop ro.product.model")
print("Model: " .. model)

local cpu = gg.executeShell("getprop ro.product.cpu.abi")
print("CPU: " .. cpu)

print("\n=== Installed Apps ===")
local apps = gg.executeShell("pm list packages")
print(apps)

print("=== Memory ===")
local mem = gg.executeShell("cat /proc/meminfo | grep MemFree")
print(mem)