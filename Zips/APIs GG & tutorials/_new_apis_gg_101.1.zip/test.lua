

local seed = "minha_seed_aleatoria"
local secret = "meu_segredo"
local salt = "meu_salt"
local plainText = "Texto que quero criptografar"

local resultado = gg.encryptAes(seed, secret, salt, plainText)

if resultado then
    print("Texto criptografado: " .. resultado)
else
    print("Erro na criptografia")
end

 criptografado = "00GbYVh91EalgFd4TWo9KLnQkdvA6eBu5FNKnnPNH043+eQvq6Myfy/Li5r2N/2C4YFlTWYcWas="


local descriptografado = gg.decryptAes(criptografado, secret, salt, seed)
print("Descriptografado: " .. descriptografado)




print(gg.getApkSignature())