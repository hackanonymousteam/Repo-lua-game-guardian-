package bat.ggg.modmenu;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

public class FloatingModMenuService extends Service {
   
    public View mFloatingView;
    private Button close;
	private CheckBox botao1;
    private LinearLayout mButtonPanel;
    public RelativeLayout mCollapsed;
    public LinearLayout mExpanded;
    private RelativeLayout mRootContainer;
    public WindowManager mWindowManager;
    public WindowManager.LayoutParams params;
    private LinearLayout patches;
    private FrameLayout rootFrame;
    private ImageView startimage;
    private LinearLayout view1;
    private LinearLayout view2;
    private LinearLayout.LayoutParams hr;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        return Service.START_NOT_STICKY;
    }
   @Override
    public void onCreate() {
        super.onCreate();
	   
	   
	   initFloating();
      
	//===========================//
	
	// encrypt your code 
	//your code save in sdcard 
	//generate simple code for(execute)
		//this project simple for execute scripts in sdcard using layout(modmenu
	   String file1 = "night_on.lua";
	    
	   String content1 = "gg.setVisible(true)\n" +
		   "--gg.ssetProcess(\"com.ghisler.android.TotalCommander\")\n" + // set here process game
		   "gg.setRanges(gg.REGION_ANONYMOUS)\n" +
		   "gg.searchNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.refineNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.getResults(100)\n" +
		   "gg.editAll(\"-1\", gg.TYPE_FLOAT)\n" +
		   "gg.clearResults()\n" +
		   "gg.setVisible(false)\n" ;
	   escreverEmArquivo(file1, content1);
	   
	   String file2 = "night_off.lua";
	   String content2 = "gg.setVisible(true)\n" +
		   "--gg.ssetProcess(\"com.ghisler.android.TotalCommander\")\n" + // set here process game
		   "gg.setRanges(gg.REGION_ANONYMOUS)\n" +
		   "gg.searchNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.refineNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.getResults(100)\n" +
		   "gg.editAll(\"-1\", gg.TYPE_FLOAT)\n" +
		   "gg.clearResults()\n" +
		   "gg.setVisible(false)\n";
	   escreverEmArquivo(file2, content2);
	   
	   String file3 = "damage_on.lua";
	   String content3 = "gg.setVisible(true)\n" +
		   "--gg.ssetProcess(\"com.ghisler.android.TotalCommander\")\n" + // set here process game
		   "gg.setRanges(gg.REGION_ANONYMOUS)\n" +
		   "gg.searchNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.refineNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.getResults(100)\n" +
		   "gg.editAll(\"-1\", gg.TYPE_FLOAT)\n" +
		   "gg.clearResults()\n" +
		   "gg.setVisible(false)\n";
	   escreverEmArquivo(file3, content3);

	   String file4 = "damage_off.lua";
	   String content4 = "gg.setVisible(true)\n" +
		   "--gg.ssetProcess(\"com.ghisler.android.TotalCommander\")\n" + // set here process game
		   "gg.setRanges(gg.REGION_ANONYMOUS)\n" +
		   "gg.searchNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.refineNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.getResults(100)\n" +
		   "gg.editAll(\"-1\", gg.TYPE_FLOAT)\n" +
		   "gg.clearResults()\n" +
		   "gg.setVisible(false)\n";
	   escreverEmArquivo(file4, content4);
	   
	   String file5 = "aimbot_on.lua";
	   String content5 = "gg.setVisible(true)\n" +
		   "--gg.ssetProcess(\"com.ghisler.android.TotalCommander\")\n" + // set here process game
		   "gg.setRanges(gg.REGION_ANONYMOUS)\n" +
		   "gg.searchNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.refineNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.getResults(100)\n" +
		   "gg.editAll(\"-1\", gg.TYPE_FLOAT)\n" +
		   "gg.clearResults()\n" +
		   "gg.setVisible(false)\n";
	   escreverEmArquivo(file5, content5);
	   
	   String file6 = "aimbot_off.lua";
	   String content6 = "gg.setVisible(true)\n" +
		   "--gg.ssetProcess(\"com.ghisler.android.TotalCommander\")\n" + // set here process game
		   "gg.setRanges(gg.REGION_ANONYMOUS)\n" +
		   "gg.searchNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.refineNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.getResults(100)\n" +
		   "gg.editAll(\"-1\", gg.TYPE_FLOAT)\n" +
		   "gg.clearResults()\n" +
		   "gg.setVisible(false)\n";
	   escreverEmArquivo(file6, content6);
	   
	   String filespeed0 = "speed0.lua";
	   String speed0 = "gg.setVisible(true)\n" +
		   "--gg.ssetProcess(\"com.ghisler.android.TotalCommander\")\n" + // set here process game
		   "gg.setRanges(gg.REGION_ANONYMOUS)\n" +
		   "gg.searchNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.refineNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.getResults(100)\n" +
		   "gg.editAll(\"-1\", gg.TYPE_FLOAT)\n" +
		   "gg.clearResults()\n" +
		   "gg.setVisible(false)\n";
	   escreverEmArquivo(filespeed0, speed0);
	   	   
	   String filespeed1 = "speed1.lua";
	   String speed1 = "gg.setVisible(true)\n" +
		   "--gg.ssetProcess(\"com.ghisler.android.TotalCommander\")\n" + // set here process game
		   "gg.setRanges(gg.REGION_ANONYMOUS)\n" +
		   "gg.searchNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.refineNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.getResults(100)\n" +
		   "gg.editAll(\"-1\", gg.TYPE_FLOAT)\n" +
		   "gg.clearResults()\n" +
		   "gg.setVisible(false)\n";
	   escreverEmArquivo(filespeed1, speed1);
	   
	   String filespeed2 = "speed2.lua";
	   String speed2 = "gg.setVisible(true)\n" +
		   "--gg.ssetProcess(\"com.ghisler.android.TotalCommander\")\n" + // set here process game
		   "gg.setRanges(gg.REGION_ANONYMOUS)\n" +
		   "gg.searchNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.refineNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.getResults(100)\n" +
		   "gg.editAll(\"-1\", gg.TYPE_FLOAT)\n" +
		   "gg.clearResults()\n" +
		   "gg.setVisible(false)\n";
	   escreverEmArquivo(filespeed2, speed2);
	   
	   String filespeed3= "speed3.lua";
	   String speed3 = "gg.setVisible(true)\n" +
		   "--gg.ssetProcess(\"com.ghisler.android.TotalCommander\")\n" + // set here process game
		   "gg.setRanges(gg.REGION_ANONYMOUS)\n" +
		   "gg.searchNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.refineNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.getResults(100)\n" +
		   "gg.editAll(\"-1\", gg.TYPE_FLOAT)\n" +
		   "gg.clearResults()\n" +
		   "gg.setVisible(false)\n";
	   escreverEmArquivo(filespeed3, speed3);

	   String filespeed4= "speed4.lua";
	   String speed4 = "gg.setVisible(true)\n" +
		   "--gg.ssetProcess(\"com.ghisler.android.TotalCommander\")\n" + // set here process game
		   "gg.setRanges(gg.REGION_ANONYMOUS)\n" +
		   "gg.searchNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.refineNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.getResults(100)\n" +
		   "gg.editAll(\"-1\", gg.TYPE_FLOAT)\n" +
		   "gg.clearResults()\n" +
		   "gg.setVisible(false)\n";
	   escreverEmArquivo(filespeed4, speed4);

	   String filespeed5= "speed5.lua";
	   String speed5 = "gg.setVisible(true)\n" +
		   "--gg.ssetProcess(\"com.ghisler.android.TotalCommander\")\n" + // set here process game
		   "gg.setRanges(gg.REGION_ANONYMOUS)\n" +
		   "gg.searchNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.refineNumber(\"1\", gg.TYPE_FLOAT)\n" +
		   "gg.getResults(100)\n" +
		   "gg.editAll(\"-1\", gg.TYPE_FLOAT)\n" +
		   "gg.clearResults()\n" +
		   "gg.setVisible(false)\n";
	   escreverEmArquivo(filespeed5, speed5);
	   
	}
	public static void escreverEmArquivo2(Context context, String nomeArquivo, String conteudo) {
        FileOutputStream fos = null;
        try {
            // Abre o arquivo no diretório interno do aplicativo
            fos = context.openFileOutput(nomeArquivo, Context.MODE_PRIVATE);

            // Escreve o conteúdo no arquivo
            String conteudoFormatado = conteudo;
            fos.write(conteudoFormatado.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
	
	
	
		public static void escreverEmArquivo(String nomeArquivo, String conteudo) {
		File diretorioExterno = new File("/sdcard/"); 
			File arquivo = new File(diretorioExterno, nomeArquivo);

			FileWriter fileWriter = null;
			try {
					fileWriter = new FileWriter(arquivo); 
				fileWriter.write(conteudo); 
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				if (fileWriter != null) {
					try {
						fileWriter.close(); 
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		
	}
	
    public void initFloating() {
        this.rootFrame = new FrameLayout(this);
        this.mRootContainer = new RelativeLayout(this);
        this.mCollapsed = new RelativeLayout(this);
        this.mExpanded = new LinearLayout(this);
        this.view1 = new LinearLayout(this);
        this.patches = new LinearLayout(this);
        this.view2 = new LinearLayout(this);
        this.mButtonPanel = new LinearLayout(this);

        RelativeLayout relativeLayout = new RelativeLayout(this);
        relativeLayout.setLayoutParams(new RelativeLayout.LayoutParams(-20, -1));
        relativeLayout.setPadding(10, 10, 10, 10);
        relativeLayout.setVerticalGravity(16);

        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(300, -20);
        layoutParams.addRule(11);

		close = new Button(this);
        close.setText("Hide");
        close.setTextColor(Color.parseColor("#FF000000"));
        close.setLayoutParams(layoutParams);
		android.graphics.drawable.GradientDrawable GIGABGI = new android.graphics.drawable.GradientDrawable();
		GIGABGI.setColor(Color.parseColor("#ffffff"));;
		GIGABGI.setStroke(3, Color.parseColor("#000000"));
		close.setBackground(GIGABGI);
		
		relativeLayout.addView(this.close);
       
        rootFrame.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        mRootContainer.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        mCollapsed.setVisibility(View.VISIBLE);
        startimage = new ImageView(getBaseContext());
        startimage.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        int applyDimension = (int) TypedValue.applyDimension(1, (float) 70, getResources().getDisplayMetrics());
        startimage.getLayoutParams().height = applyDimension;
        startimage.getLayoutParams().width = applyDimension;
        startimage.requestLayout();
        startimage.setScaleType(ImageView.ScaleType.FIT_XY);
        
		// icon mod base 64
		byte[] decode = Base64.decode("iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAMAAADDpiTIAAAC3FBMVEUAAABH/0dL/1FK/05L/1FK/09L/09M/09L/1BL/1BM/09M/1BK/1BN/1FL/0tA/1VK/1BL/1BL/09L/09M/1BL/05J/00A/wBL/1FL/09L/09L/1BM/09K/1BL/0tJ/05M/09L/1BH/1JK/05M/1BL/09L/09N/01K/09M/09L/09L/09Q/1BL/09M/1BJ/0lL/1BM/1BM/09M/09L/1BL/09O/05M/09J/1BL/09J/09M/05M/1FL/09M/09M/1BM/1BM/1BM/09L/09L/09L/05M/1BI/05L/09L/09L/09M/09M/1BM/1BM/1BL/1BM/1BM/1FK/0pM/09L/09O/05L/1BN/00A/wBL/1BA/0BM/1BV/1VM/1BN/01L/09A/0BM/09N/01H/05L/1BM/1BL/09M/09E/1VV/1VK/1FL/09J/0lM/09J/05L/09M/09G/09L/1BM/09I/1BL/09M/1BM/1BN/01K/09M/09L/1BJ/01K/05M/09M/09L/1BN/01K/1FI/05L/1BL/1BL/09J/1BM/1BL/09L/1BN/1FL/09M/09D/1FL/1BK/1JL/1BK/09K/1BM/09M/1BO/05L/1BM/09L/05K/1FM/0xN/1Az/zNJ/1JL/05L/09M/09M/09M/09L/1BJ/0lG/0ZM/1BL/1BL/05L/09M/1BM/1BM/09L/1BL/09L/1BL/1BM/09M/09L/1BM/1BM/1BL/09M/09M/09N/01M/1BK/05L/1BM/1BL/09L/1BL/09M/1BM/1BM/05L/1BL/045/1VG/1FL/09M/1BL/09K/1BM/09M/05M/05L/09M/05L/09L/09L/1BK/1BL/1BK/1BM/1BL/1BM/09L/1BM/1BM/1BL/09L/1BL/09M/09K/09L/09L/1A3/0lL/1BM/1BM/0xM/1BK/09L/09L/09M/09M/09L/1BM/09M/1BN/01M/1Bu1+yfAAAA83RSTlMAEixFX3iSq7qjh29WPCIMU53n/s2COAIpdL7661kRO8eWGTS9944ULbX0hRB76Qeq+VrOjLsN2yPuKmgv8WH9/PNN+0dBQy5EpOT1w4av3/Y5GNf4GuAeAbAEvAY2IcII6Aok5sq00Q8DJtUV3jGu4R3w5SCn7O8yN6HtQkiaVJM1TCfqXItJgH5zP2prE3Af42RdSkYXoPJiTxtQBRxYeleoUdkOC9qtTtJ8s4qfsdaPkaKZwLaYl5soQD7MkD3JgdCsct1SCRbBeYgwlHVbuGV3lalgz4mNnJ6mxr86Y8VeccvcDjODJWxnyLfU2NOyfysNm7phAAAYH0lEQVR42u2d+0OUx73GX4nxhlRh0Y1CIIoIJQSFlpuyCqINFyMgiISgwRtKNOIlkKg19YKXaDAiFvWAaYiFHK1NNNbUtGkTkxpMm0tPW5OmbXLUtmkbm6bnvP/AWZYcRYVlZnfmnZl3nudneOe783y+l3n38hoGBEEQBOmhAQMC7rhj4J13Dho0eMiQocOGBQYODwr6GvYFAEB214iRI4NDQsxe5XCEho4aPdqJXbKn7hozZuzYMLNfhQ8devfdEdgvAADZSJH33GPSKGzcuPHYNQAA2UFRURMmmPSKnjgxJga7p7piY79u+qy4uHvj47GHAABSVvc5HKZfSkiIwi4qqkmTJk82/VdiUhL2EgBAymn8N75hMtI3v4n7wwAAUuzwn2AyVHJKCvZUJSUlJppMlZqahl0FAJAaCgw02St9yhTsrL72dxEABAAAdlcB/01uciOA/QUAkMyaOtXkKXQB2f03OSs9PQO7DAAgLet/t1wZQEBj+7sIAAIAALutYfu/CQHsNwCAdKz/mATl1DTTYqEIAADsujz2T3OYlgtdQCL7BfiP4yAAAABy+C/GfgwCAAAA6Dr/YRJE+qMIAAAAIFxJSYLtRxcQa//06aYEwnEQAAAAEf7LYT8GAQAAAMTUf1MioQvom/4oAgAAAOhd/9EFrNXIkdMl9B/HQQAAAKzxPzPTlFQuF35XFgBAnOu/tPZ3KSsKCOia/l8RkAUCAACkZ/1HF+BuvwL+e4oAEAAAEGvNUMN+DAIAAADwsH9GtqmQ0AVY+5+tlP8oAgAAAOhb/9EFmNuvoP84DgIAAKBn+8cgAAAAgN7zHyZBZpqZrbT/KAIAAAD4Y//MRFN5oQv4Yb8N/MdxEAAAAN/8t4f9GAQAAADQdf7DJIj0RxEAAACAWrNm2cx+dAEafetb0dGmDZWVFRnJY78iIu6/PwMAAAC7KMe0raKjg1g3y9zcPM+l8/NnP/BASgoAAADK13/TzooOYodAfPycOTdfvaBA+VYwy57t/4YKC4sYbdXc4uLbL19y990AAAAofP63uf0eBIpYIDBvXmkf1x+mrP2RkdEa+O8pAn4jMK+0tM/rjxsHAACAiv7n55uayN9BoO/6363gYAAAAJSr/9rY7+8kOH9+aWl/189F+tu2CMzPyyO4/uTJZQAAAKD+264LzJ+fR3j9B8vL1bFfQ/99Ow6SpX+3HnqoogIAAADptUBP+30ZBBYuzKO6/sMPVwIAACC5/QuyTI1F0wUWLly0iPb69yxeLLf/o7O09r/rkzyxhFu1ZOlSH66/bFk8AAAAqP/SqqqqnLT++7jC8hUr5LUf/ldXE+3VI4sW+bzGypWrVgEAACCf/7C/qorQ/kfC/Vrn0UfHAwAAIJdWr9be/poasvrvtj/c37XWrF0rmf/r1mnvv9NJlv7+2+/W+vWPAQAAIE/9h/01ZPZPmRLOaMWEJUvksV97/2sJ039KeDizNevq7roLAAAAtH8J7K81COt/OtN1H3/8CQAAADD/qWN/Ouu14zZsEOt/ANJ/I+FWcbDf7PoQUhAAAADC7A/YpL39hP5nZKRziqDk298WZz/8J9yrDJeLWwxhYZs3AwAAYL3/sP/JJ0nrv4trHNnZ3wEAAADzn7z2u3jH4khKstb/2Lo63f3fQrhVWy06KW8DAAAA9V+6+h8VZdVH5RIiIiyyf/t2jH+k6R9l4Sdl58wBAADACv/r67W3f4ts9b9bO3YAAADAvf7DfkL7i4qs/qrM8uVIf/7aSbhVRYWFVoc2fXoKAAAAqP9c7d9JWv8LRYS3i7P98F/e9PfoXgAAAHgpDfbv3i11/XfrKQAAADjZnxaiu/179pBt1d69haL8N7k9zzotBP4TbtXekhJRIYaHGwAAAKD+i63/JeKCfPppXvZr73+D/OlvJifzy38AoDEAsN9sIPQ/J0dg/U/ftw8AAADmWrhwqe72P/MM2Vbt2iU0TD6fCt7f2Ki7/wcItyonLExckI6mJgMAAADm9u+H/QdI279I+x287If/hHt1UGD6O3jVfwCgNwDa2+9wkNb/gwezMf8BAMx/NvOfdGPd9mcLpJRT/8/LYxhlXNzQMWOavvvdjIy5htF8//133LFjz55Dhw9LDcARwq36D7FRHjEAAABgrZaWAlYBuly5ra29P/X66NFt2zZK+kOTxPW/tVVk++dT/5999tFH2QSYl0fwbcXvrVkjHwCk37L8jtAop00zAAAAYF7/C9jU/8LduysrSRacNOm55+KkOv61tZHW/0wbnv8BgNYAsJr/nn/+WZplxw8d6pDE/0wK+zMFUtokcfonJrbRL30sOloG+zNbCeMVab/s9R8AKApAczML+9PTFyzwZfUnnmD4SC1f/W8l9L+tTaT9Dk72p6YyiO77Cxf6GsHatSuF2p+dTZr+bQ6HSPv51H8AoDcAbOyfPbvdnyA6xo4VaP/Bg6T1X+CRhdv8BwC0BmDu3BdYRPef/keSK2pnjx8nC3DgQLH3fyVO/6qqagax1NYK2NawMMLsN5ocqP8AwHbnfxb219RUV7OJx3oEwnJyCO1vEmm/1Of/GsInqJMhYHH65yiQ/rKf/wGAogDEsLG/xsk0Kgu7QJgi9Z/X/AcAtAYgJqbYlK3+W9sFSkjtP3BAbP3nk/7FxRKmv4VFoKRkL2E4B0Te/eFX/wGAzgCwqf+1tU4nHzz5I1Cydy9p/Rdpv4OX/Uz8NziKLwGFhSqkP7fzPwDQGwBG9nP1n2sXKCwsKiILoqEB8x8AsBkAAwacYBHdIfIVI3bt+sEPTg4e/MOmpmdpvjPwIqeNjQ4KIgvgmWdEzv+c3v+POHHC0vSvmDjxppsoL6WliS0CWVmE2W+IzH5+9R8AaA1ARIS19gcEnLr1nxMTG8jj3biRuf9RUSq0f0cbn/a/fDmD6IJJ19uxo/cLvPgieczBTDc2Lm404bpjhLZ/Tg+DBgB6A8Cm/W/cSLretL7fQ6M4QzLsAi4Xaf3fs0dk/W9rk3n+AwCKAsBm/jOJ7Z86ldV9ZFYEuDIyVLCfz/xntFuc/oEM7yQyKQIuF6H9hkj7+dV/AKA1AO3toZbav3s323cT/UcgXef677afhf9Pkq53+jT795P8IyA9fQopumLt59T/AYDWADCyn9j/cTxuKvvTBdz2E/q/c6ct5z8AoDMAbOY/8vqfS/c1fwu6gCL28zr/W5r+ZWWT+b216FsRCA8nbf8i7bdL/QcAkgEwYsQyBsG9/DLpeoMH+3D5M+Sv50c/or14HWn9HzZM7Pt/5Juwmfgvnc6zZxnEtoVwufJXXvFtAX7HwfDwRwivu0WV419OTtjTTwMAAECiH/+YQXTnzpGGluz7IkOHEm/Aq68SXzUh4Sc/IbvoxIlCyz9N/ff8x09/CgAAQP8fa2QR3NmyMqLAFj/8sF/rUHSBJwkvuYj0p2u3CK7/Bk39/+qtzcf6/dvXXmPwq9YvvJBCFFhKys/8XYpiEHiSBIFFixYq0P5NyvZ//UHF309JAQAAwIuWuFx+B+dy7d9PEtiKFUw+bUzTBfpFIM9+9f/mB5WPHVvmNSMZPAAi87XXiAIbsJLRb73XMhsE8vLmMx4ohB//bn9O9c8BAADoS+fOsbgDTBTYqlUvsNsSNoOA2/75DKcJKW7/9/ag8tdfBwAAoDe1tDB4rlVcXARJYONZPW2W3f2AUjXsp5r/Dvb2pOo33ujjz8+cYRDg+fMEgT32GPPH//pbBEpL5ynQ/k3K9t/Hk8pnzgQAAOA2PTJ9uv8Bblq8uN/AlixJSOCwN37dDyidR+g/+58e4FX/W/uy3zTffLO3f3iLRYi/6D+wu+rq+GyP78fBCxdI01+w/eT+9/Oc6rcBAAC4WQEBDELMzOzsL7DY2Mf5bZFvg8CFCxcvqlD/aY5//T2ouPi2d2sBgOYA0H9ushe9805/gT3B4M0mxvcDFLGfav5r7feGzm3369evZxDlL3/pPbCgoDjeG0VbBNzpT/jntaYi6d9K8qD6X/0KAACAniMAkzDffddbYJGRluwV+ecEjffeO9XcTPanhw6J9J/m8//DiS54662A9xkEGRLiNbB9eXnWbFZuLvluRRD+Xa5Q+5OSiF/QBx+QXrQFAACAG2LxTZBf/9praBY+553tb9I7nbUi+z/V8a+N/EFl/wUAAMD/q7OTwUeBzUPeHgbwm99YumsMCXDW1Khy/m9rc5BfeU6Pfxw5kkWstx0te6gsK8vajWNVBJxOkfZTpX9bG9WDKuN6PLsNAGgOwKhRLIINDPRyC9j6vavVrf7TPqh2+/br//vb37II1xusgQK2z/8HVIpNf6q3f314TnVkJAAAAN363e9YBOztqapvCdlC/55RXF0ttv7THP+afHhQ+fHjAAAAdCs5mUXE3h6rMFTQLj7vBwBz5oi9/0se6ZEjvixw6dL1C3z4IYuIt23z9y0qiYpAdXWVKse/Jl/S36333wcAAKBbjY0sgj5ypO8gOzMzhSHgy1mgukqk/1Tnfx/tN82PPrp+jcJCFmF7/TzQ739vCiwClAiUlwu2n9z/Awccvq7z8ccAAAB0K47JR/VOn/YSaGVlqSkSASr7hwxR5fh3wI+F/vAHAAAAunXhAovI//hHr7FGOhwCESDvAoLtp5n/Dvjjv/nAA9cv9Kc/sYj91Cnv4Q4aZMpfBNzpr8rxzz/7b3r3FgBoDgCrm54tLRL3VqIuUKFQ/fd3tR6sMfl5aLf6+0FysenV/3GwouITVY5/Df7/pHOPn44GAJoDcP48m5dw8qTcI7b3QcBtv1D/aY5/LH7SvceP4gMAzQFoaGDzGkpKKiSfsr10AcH208x/bPyKuPG9uE8/ZfU6/lv2Gy19FYHKSpH2mxa3/y6t73FJAKA5AIaxjtELWXP0qOz32nvtApWXLytT/xkteo7Pz18QPZtMtuNgZaVg+y1Pf7eOAwAAcENXWF126dKjJK9DpkGgUnD9pzn+7WG1amJiJwAAADcUw+4FXVXhXbceXUCh+W8PM//N5ORbrv3nP7O6dFaPb53KXwQ6OkTaT5X+DO13p+lVAAAAeorNTwR49Je/tLcr8Nk7TxfoWLZMYAiZmSLav0e3PR65pSWM3dWTk8sUGARqav76V5H2m+axY2LS3zQv37YAANAcAMNg+ij0H5K+sJMnBRqwbp1I+4cPJ6//5xmv/RkAAAC3at/hwwxX+OADYgRMPfU9cvv/9je2S7/1Vq/LPPUU0wG3VYkvYoia/1tbie3fuZP12ePvfwcAAOB2LV68aZOI11iuHQLk2dHlP+vVX321z7X+8Q/GL5McAb3sF5f+phm9ahUAAAC9q6zsHUGlTqMuQGM/+/pvmp97WQ4AaA6AYUSsWSPm1erSBajmvy1bmK/v9aEOXQoIyEcRkCP9OdhvvlFeDgAAgHcdE/Wa7X8/gK7+s1+/vj5GzJ0nDALUxz8O6R8WtnWrAQAAQL8qK2Pz6+EYBHw//nGo/+aVK4SLAwDNAej6qOw1gZMg5j8e87+526BRR2goioCg9Pc81p61hg0zAAAAoFB7e6ioPbDf/QCq+s/DfpPWfg8CHIqAloNApnrpDwAAQHcXwCBg8fFPIvsBgPYAiJ4ENZz/uPhv+CMUAevSf+NGDgF4fYwLAAAABF3gBO4HWFL/edhv+mu/52OCJ04w3xYtBoFM9dMfAACALgJ4IGD/QYDq+Cex/QBAewA8COB+AM/5j4v/BkuhCPBL/9paudMfAAAA0V2gqsrG9Z+H/eY4g70iiotFHZOqq6vUsl9w+o/j4T8A0B0AIyaGAwKEa1er0wWojn8K2Q8AtAfAg4Co3VKlC1DMf04nn/pv8BSKALP0d9bUqJX+AAAACO8CVTaq/zzsN3nbz6sI2GIQyBSe/sHBBgAAAPwJiElNxSDgV/t3Kmw/ANAeAMNobk4VtXuydgG6+Y+L/4aVakYR8DX9q2sUT38AAACEd4EqZes/pxZmtf28ioCSgwDN8Y8Pu8Ei/AcAugPQ1QUwCNC1fy7g5uYaBgAAAGIQKND9fgDd/MfF/7IyQ5xaCgq0LgIU6c/ns825uSLtBwDaA2C0tIjsAlXK1H9OX3ETW//5FQElBgGa4x+frzcJT38AAAC6u4COgwCN/eWc7JfCfwCgOwCiJ0EF5j8e/g+Wxn4PAo2NWhUBivSv4GP/YKdhAAAAII32729kvcdtbbLeD6Co/xUVn/CIYLBTMv+7EGBdBBwOCgQkPf5VfPKJDukPAABAdxdgj4B8gwCN/RWc7JfSfwCgOwA8JkHpugDd/MfFf2nt5zUIyFQEKNK/Uqf2DwAAwPUuECKwC1RJU/8rKy/ziOAlp+T+u5UWEsK8CEgxCGRnU6T/ZR7+v/RStWEAAAAgOwE8EBA/CGQfPCi2/rvtV8J/AKA7AB4E7HY/IDubxn4u/itjP69BQGQRoEl/nds/AAAAUnSBKmH1v6ODz/m/WjH/uxCor7fHcTCbIv07li3jYP8//6me/QBAewCM7ds5IGD9IEBjfwcf+48eNQAAAFATAdXvB1DNf3zqv7L2exBQvAhI0P5Vth8AaA+A4C5QZVn9T0nhYb/i9Z9fEbBkEKA5/qV8+CHSHwAAgD66wKZNCg4CNPan8LB/woSjtvAfAOgOgGEEBDAmgP/9AKr5j0v9nzBpkmEfBShWBIS3/wkT7GQ/ANAeAMFdoIpb/Y+P52G/zeo/vyLAZRCgOf7Ff/EF0h8AAADSLqDCIEBjfzwn+23pPwDQHYAuBNbJfj+Aav7jUv9n29b+Lq1et07qIiC8/c+e3WkYAAAA2JeA1SK7QBXL+s/j/D+70+b+cyoCTAYBmuPfPqQ/AAAAvncBGQcBGvv3/YuP/Vr4DwB0B8AwPvuM9SRoXrlCuvjzfVzhGOkFLl48dYqH/x0dhj5anZUlqggYV6+Ghd3672vefZc4/f/FI/2vXes0DAAAALTRggWMCSC/H2AYW7eu6fGP+fmjRhFXXz7t37ymVf3v1obDh1lv444dxKvPmHHI5TLNd+69dzPN3s8tLuZg/+XLIwwDAAAAQ7suIG4Q8EkXL17g0v41rP8AAACIngR9sf8C5j/WCKhTBDjZf01n+wGA9gC4u0C+El2AT/vXvP53KzI/n3kRYI7APC7pHxoK+wEAFMkDAbb2zyvlYn97O9wHAJAHAYknQbf9XPyH/ZwHAVb+l3JKf7gOACDpuwCf9o/634teZ10ETHPgQH+DWssp/ePhNwCAbtGsWdHRrAeB5/yKqKiojoP9J06g/gMAqA8EWO92cLDPT1u+dCk7m4f/ERFwum8Eopkj8LMpU3wIxOn8OY/p353+sB8AQJZ2gcTE++4rpwzj0y+/5OM/6r+IImCaqdOmETOQlvbvf5tIfwAAAGxzHPSo4PPPCX5+PSJiEJfZv9t++A8AICIEErlYUF9/Oja2z1VjY8eMGcKFPY+KYT+FNpvc9GZDw01LdcTGHj8e+PHH9SZPffHFKrgKACByAjgiYC5devYrLaurM63QylXwn1YzExNNm6i4OAZ+AgCIlgCbIOC2H/4DAMg3BGzgP+z3BwFet+WsUmoq7AcAkO+aMUNpAlKbm+GhvwioWwRSU2E/AIAYdIFsRe2H/wAA0nUShP1aDwJo/wAArrHtApkq+V+A+s9cIzOVQaCgoAV+AQCINQGKIOC2H/4DAIgPAgr4D/t1HgTQ/gEAXNK4C6D+W4DA9OlIfwAAAPRVUpKcCDQ2ov4DAMgiBCT0f/9+OGMdArIVgcZG2A8AIG27AOq/1kUA6Q8A4IeILuBwSGI//AcAkABNmyYBASGwXyQCootASEgaXAAAkK5dICQN/mtcBJD+AAD7L0UXcAiyH/4DAEgKBDD/aa6pVttfXw/7AQAkEQHWIlC/fTv2XN8iUF8P+wEApGsXqEf9BwDYbX0RgP1aDwJo/wAAuyyzAgO5+r8J9V9+BDjavykA+wsAIE27gNt++A8AIF0RgP0qKYn1Q0dTU/H2LwCA1FFUVAJL/8+mpGBPFdP4L79kZf/LL1djPwEApJg6Ox98kIH72ZcuYS8BAKSm/sff74zU1RVhF1XW6tWv+O5+XNxHAwZgDwEApLRGj05O9sH9wokTY2KwezZR5OzZVO6XvPfeeOwaAIBspO1Xrz70UBjBp/7OnGlrW4H9AgCQDTXi7beDly7t3XmHIzR01IYNZdgl22vAgP/NyRl4552DBg0eMuTMsGGBgcODgr6GfQEAEARBEKSX/g/byGNbfapNMgAAAABJRU5ErkJggg==", 0);
        startimage.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
        ((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(10);
		
        this.mExpanded.setVisibility(8);
        this.mExpanded.setBackgroundColor(Color.parseColor("#00B0FF"));
        this.mExpanded.setGravity(17);
        this.mExpanded.setOrientation(1);
        this.mExpanded.setPadding(5, 0, 5, 0);
        this.mExpanded.setLayoutParams(new LinearLayout.LayoutParams(dp(260), -2));
        this.mExpanded.getBackground().setAlpha(250);
        android.graphics.drawable.GradientDrawable DFIABBI = new android.graphics.drawable.GradientDrawable();
        DFIABBI.setColor(Color.parseColor("#00000000"));
        DFIABBI.setCornerRadius(10);
        DFIABBI.setStroke(5, Color.parseColor("#FF00B0FF"));
        this.mExpanded.setBackgroundColor(Color.parseColor("#ff000000"));

        ScrollView scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(190)));
        scrollView.setBackgroundColor(Color.parseColor("WHITE"));
        scrollView.getBackground().setAlpha(250);

        this.patches.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        this.patches.setOrientation(1);

        this.hr = new LinearLayout.LayoutParams(-1, -1);
        this.hr.setMargins(0, 0, 0, 5);
        this.mButtonPanel.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));

        TextView textView = new TextView(this);
        textView.setTextSize(50);
        textView.setText("By Batman Games");
        textView.setTextColor(Color.WHITE);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setTextSize(20.0f);
        textView.setPadding(10, 25, 10, 5);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 17;
        textView.setLayoutParams(layoutParams2);

        TextView textView2 = new TextView(this);
        textView2.setTextSize(50);
        textView2.setText("@batmangamesS");
        textView2.setTextColor(Color.WHITE);
        textView2.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);
        textView2.setTextSize(10.0f);
        textView2.setPadding(10, 5, 10, 10);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams3.gravity = 17;
        textView2.setLayoutParams(layoutParams3);

        new LinearLayout.LayoutParams(-1, dp(25)).topMargin = dp(2);
        rootFrame.addView(mRootContainer);
        mRootContainer.addView(mCollapsed);
        mRootContainer.addView(mExpanded);
        mCollapsed.addView(startimage);
        mExpanded.addView(textView);
        mExpanded.addView(textView2);
        mExpanded.addView(view1);
        mExpanded.addView(scrollView);
        scrollView.addView(patches);
        mExpanded.addView(view2);
        mExpanded.addView(relativeLayout);
        mFloatingView = rootFrame;
		
        if (Build.VERSION.SDK_INT >= 26) {
            params = new WindowManager.LayoutParams(-2, -2, 2038, 8, -3);
        } else {
            params = new WindowManager.LayoutParams(-2, -2, 2002, 8, -3);
        }
        WindowManager.LayoutParams layoutParams4 = params;
        layoutParams4.gravity = 51;
        layoutParams4.x = 0;
        layoutParams4.y = 100;
        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        mWindowManager.addView(mFloatingView, params);
        RelativeLayout relativeLayout2 = mCollapsed;
        LinearLayout linearLayout = mExpanded;
        mFloatingView.setOnTouchListener(onTouchListener());
        startimage.setOnTouchListener(onTouchListener());

        initMenuButton(relativeLayout2, linearLayout);
        
    }

    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = mCollapsed;
            final View expandedView = mExpanded;
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = motionEvent.getRawX();
                        initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - initialTouchY);
                        if (rawX < 10 && rawY < 10 && isViewCollapsed()) {
                             collapsedView.setVisibility(View.GONE);
                            expandedView.setVisibility(View.VISIBLE);
                         
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                         params.x = initialX + ((int) (motionEvent.getRawX() - initialTouchX));
                        params.y = initialY + ((int) (motionEvent.getRawY() - initialTouchY));
                        mWindowManager.updateViewLayout(mFloatingView, params);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }

    private void initMenuButton(final View view2, final View view3) {
        startimage.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    view2.setVisibility(View.GONE);
                    view3.setVisibility(View.VISIBLE);
 
                }
            });
			
		close.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					view2.setVisibility(View.VISIBLE);
					view2.setAlpha(0.95f);
					view3.setVisibility(View.GONE);
					
				}
			});
			
			
		addTextClock("", new InterfaceBtn() {
				@Override
				public void OnWrite() {
					
					}
			});
		night("mode night", new InterfaceBtn() {
				@Override
				public void OnWrite() {
					
					}
			});
			
		damage("Damage hack", new InterfaceBtn() {
				@Override
				public void OnWrite() {
					
					}
			});

		aimbot("aimbot", new InterfaceBtn() {
		@Override
				public void OnWrite() {
					
					
				}
					
				});
			
		addSeekBar("SpeedHack", 0, 5, new InterfaceInt() {
				@Override
				public void OnWrite(int value) {
					switch (value) {
						case 0:
							toastC4F(getApplicationContext(), "value 0", Color.RED, 20, Color.WHITE, 20, 3);
								break;
						case 1:
							toastC4F(getApplicationContext(), "value 1", Color.RED, 20, Color.WHITE, 20, 3);
							break;
						case 2:
							toastC4F(getApplicationContext(), "value 2", Color.RED, 20, Color.WHITE, 20, 3);
							break;
						case 3:
							toastC4F(getApplicationContext(), "value 3", Color.RED, 20, Color.WHITE, 20, 3);
							break;
						case 4:
							toastC4F(getApplicationContext(), "value 4", Color.RED, 20, Color.WHITE, 20, 3);
							break;
						case 5:
							toastC4F(getApplicationContext(), "value 5", Color.RED, 20, Color.WHITE, 20, 3);
							break;
						
					}
				}
			});
	
	exit("Exit", new InterfaceBtn() {
	@Override
	public void OnWrite() {
		view3.setVisibility(View.GONE);
		//onDestroy();
        //System.exit(0);
	}

	});
	
  }
    
	public void night(String feature, final InterfaceBtn interfaceBtn) {
		final CheckBox checkBox = new CheckBox(this);
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
		);
		layoutParams.setMargins(7, 5, 7, 5);
		checkBox.setLayoutParams(layoutParams);
		checkBox.setTextSize(13.0f);
		checkBox.setTextColor(Color.parseColor("BLACK"));
		checkBox.setText(feature); // Define o texto do CheckBox
	checkBox.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					interfaceBtn.OnWrite();
					if (checkBox.isChecked()) {
						toastC4F(getApplicationContext(), "wait activating fuction 1", Color.RED, 20, Color.WHITE, 20, 3);
						
						} else {
							toastC4F(getApplicationContext(), "wait deactivating", Color.RED, 20, Color.WHITE, 20, 3);
						}
				}
			});
patches.addView(checkBox);
	}
			
	public void damage(String feature, final InterfaceBtn interfaceBtn) {
		final CheckBox checkBox = new CheckBox(this);
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
		);
		layoutParams.setMargins(7, 5, 7, 5);
		checkBox.setLayoutParams(layoutParams);
		checkBox.setTextSize(13.0f);
		checkBox.setTextColor(Color.parseColor("BLACK"));
		checkBox.setText(feature); // Define o texto do CheckBox
		checkBox.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					interfaceBtn.OnWrite();
					if (checkBox.isChecked()) {
						toastC4F(getApplicationContext(), "wait activating function 2", Color.RED, 20, Color.WHITE, 20, 3);

					} else {
						toastC4F(getApplicationContext(), "wait deactivating", Color.RED, 20, Color.WHITE, 20, 3);
					}
				}
			});
		patches.addView(checkBox);
	}
	
	public void aimbot(String feature, final InterfaceBtn interfaceBtn) {
		final CheckBox checkBox = new CheckBox(this);
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
		);
		layoutParams.setMargins(7, 5, 7, 5);
		checkBox.setLayoutParams(layoutParams);
		checkBox.setTextSize(13.0f);
		checkBox.setTextColor(Color.parseColor("BLACK"));
		checkBox.setText(feature); // Define o texto do CheckBox
		checkBox.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					interfaceBtn.OnWrite();
					if (checkBox.isChecked()) {
						toastC4F(getApplicationContext(), "wait activating function 3", Color.RED, 20, Color.WHITE, 20, 3);

					} else {
						toastC4F(getApplicationContext(), "wait deactivating", Color.RED, 20, Color.WHITE, 20, 3);
					}
				}
			});
		patches.addView(checkBox);
	}
	
	

	public void exit(String feature, final InterfaceBtn interfaceBtn) {
		final RadioButton radioButton = new RadioButton(this);
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
		);
		layoutParams.setMargins(7, 5, 7, 5);
		radioButton.setLayoutParams(layoutParams);
		radioButton.setTextSize(13.0f);
		radioButton.setTextColor(Color.parseColor("BLACK"));
		radioButton.setText(feature); 
        radioButton.setOnClickListener(new View.OnClickListener() {
				private boolean isSelected = false;

				@Override
				public void onClick(View v) {
					interfaceBtn.OnWrite();
					if (isSelected) {
						radioButton.setChecked(false);
						
						isSelected = false;
					} else {
						radioButton.setChecked(true);
						toastC4F(getApplicationContext(), "exiting...", Color.RED, 20, Color.WHITE, 20, 3);
						
						isSelected = true;
					}
				}
			});
patches.addView(radioButton);
	}
	
	public void addTextClock(String feature, final InterfaceBtn interfaceBtn) {
		final TextClock textClock = new TextClock(this);
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
			LinearLayout.LayoutParams.WRAP_CONTENT
			);
		layoutParams.setMargins(150, 5, 150, 5);
		textClock.setLayoutParams(layoutParams);
		textClock.setFormat12Hour("hh:mm:ss a"); // Formato para 12 horas
		textClock.setFormat24Hour("HH:mm:ss");  // Formato para 24 horas
		textClock.setTextColor(Color.WHITE);
		textClock.setTextSize(20);
		textClock.setBackgroundColor(Color.BLACK);
        textClock.setOnClickListener(new View.OnClickListener() {
        @Override
				public void onClick(View v) {
				interfaceBtn.OnWrite();
					}
				});
patches.addView(textClock);
		}
		
	private void addSeekBar(String str, int progress, int max, InterfaceInt sb) {
		final LinearLayout linearLayout = new LinearLayout(this);
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
		linearLayout.setPadding(20, 20, 20, 20);
		linearLayout.setOrientation(LinearLayout.HORIZONTAL);
		linearLayout.setGravity(Gravity.CENTER_VERTICAL);
		linearLayout.setLayoutParams(layoutParams);
		linearLayout.setBackgroundColor(Color.WHITE);
		final TextView textView = new TextView(this);
		textView.setText(str + ": " + progress);
		textView.setTextSize(16);
		textView.setTextColor(Color.BLACK);
		SeekBar seekBar = new SeekBar(this);
		seekBar.setScaleY(0.5f);  // Diminui a altura do SeekBar
		LinearLayout.LayoutParams seekBarParams = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
		seekBarParams.setMargins(20, 0, 0, 0);
		seekBar.setLayoutParams(seekBarParams);
		seekBar.setMax(max);
		seekBar.setProgress(progress);
		GradientDrawable progressDrawable = new GradientDrawable();
		progressDrawable.setColor(Color.GRAY);  // Cor da barra
		progressDrawable.setCornerRadius(5);  // Arredondamento leve
		progressDrawable.setSize(0, 8);  // Altura bem fina

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
			seekBar.setProgressDrawableTiled(progressDrawable);
		} else {
			seekBar.setProgressDrawable(progressDrawable);
		}
		GradientDrawable thumbDrawable = new GradientDrawable();
		thumbDrawable.setColor(Color.DKGRAY);  // Cor do thumb
		thumbDrawable.setSize(30, 30);  // Thumb pequeno
		thumbDrawable.setShape(GradientDrawable.OVAL);
		seekBar.setThumb(thumbDrawable);
		final String str3 = str;
		final InterfaceInt sb3 = sb;
		final int initialProgress = progress;
		seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onStartTrackingTouch(SeekBar seekBar) {
					linearLayout.setBackgroundColor(Color.LTGRAY);
				}
				@Override
				public void onStopTrackingTouch(SeekBar seekBar) {
					linearLayout.setBackgroundColor(Color.WHITE);
				}
				@Override
				public void onProgressChanged(SeekBar seekBar, int i, boolean fromUser) {
					if (i < initialProgress) {
						seekBar.setProgress(initialProgress);
						sb3.OnWrite(initialProgress);
						textView.setText(str3 + ": " + initialProgress);
					} else {
						sb3.OnWrite(i);
						textView.setText(str3 + ": " + i);
					}
				}
			});

		linearLayout.addView(textView);
		linearLayout.addView(seekBar);
		this.patches.addView(linearLayout);
	}
    boolean delayed;

    public boolean isViewCollapsed() {
        return mFloatingView == null || mCollapsed.getVisibility() == View.VISIBLE;
    }

    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

    public void onDestroy() {
        super.onDestroy();
        View view = mFloatingView;
        if (view != null) {
            mWindowManager.removeView(view);
        }
    }
 
    private interface InterfaceBtn {
        void OnWrite();
    }

    private interface InterfaceInt {
        void OnWrite(int i);
    }
	
	public static void toastC4F(Context c, String msg, int textColor, int textSize, int bgColor, int cornerRadius, int position) {
		Toast c4f = Toast.makeText(c, msg, Toast.LENGTH_LONG);
		View vw = c4f.getView();
		TextView textView = vw.findViewById(android.R.id.message);
		textView.setTextSize(textSize);
		textView.setTextColor(textColor);
		textView.setGravity(Gravity.CENTER);
		GradientDrawable gD = new GradientDrawable();
		gD.setColor(bgColor);
		gD.setCornerRadius(cornerRadius);
		vw.setBackgroundDrawable(gD);
		vw.setPadding(15, 10, 15, 10);
		vw.setElevation(10);

		switch (position) {
			case 1:
				c4f.setGravity(Gravity.TOP, 0, 150);
				break;

			case 2:
				c4f.setGravity(Gravity.CENTER, 0, 0);
				break;

			case 3:
				c4f.setGravity(Gravity.BOTTOM, 0, 150);
				break;
		}
		c4f.show();
	}
	
}
