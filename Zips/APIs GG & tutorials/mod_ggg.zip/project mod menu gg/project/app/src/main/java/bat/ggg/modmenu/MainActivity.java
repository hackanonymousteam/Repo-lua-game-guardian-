package bat.ggg.modmenu;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import android.os.Build;
import android.provider.Settings;
import android.os.Handler;

public class MainActivity extends Activity {

	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       //
	  // setContentView(R.layout.activity_main);
		
			Start(this);
		
    }
	
	public static void Start(final Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            context.startActivity(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION"));
											 
        } else {

              Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
					@Override
					public void run() {
						context.startService(new Intent(context, FloatingModMenuService.class));
					}
				}, 5000);
        }

        }}
