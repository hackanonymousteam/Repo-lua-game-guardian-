.class public Landroid/ext/Art_Toast;
.super Landroid/widget/Toast;
.source "Art_Toast.java"


# static fields
.field private static id:I

.field private static time:I

.field public static tip:Ljava/lang/String;

.field public static toast:Landroid/ext/Art_Toast;


# direct methods
.method static final constructor <clinit>()V
    .registers 3

    const/16 v2, 0x1f4

    sput v2, Landroid/ext/Art_Toast;->time:I

    const v2, 0x7f030008

    sput v2, Landroid/ext/Art_Toast;->id:I

    const-string v2, "文艺制作"

    sput-object v2, Landroid/ext/Art_Toast;->tip:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 7

    .prologue
    .line 16
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    move-object v4, v1

    invoke-direct {v3, v4}, Landroid/widget/Toast;-><init>(Landroid/content/Context;)V

    return-void
.end method

.method private static cancelToast()V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 20
    sget-object v2, Landroid/ext/Art_Toast;->toast:Landroid/ext/Art_Toast;

    if-eqz v2, :cond_9

    .line 21
    sget-object v2, Landroid/ext/Art_Toast;->toast:Landroid/ext/Art_Toast;

    invoke-virtual {v2}, Landroid/ext/Art_Toast;->cancel()V

    :cond_9
    return-void
.end method

.method private static controlWater(Landroid/view/View;I)V
    .registers 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "I)V"
        }
    .end annotation

    .prologue
    .line 34
    move-object v1, p0

    move v2, p1

    move-object v7, v1

    const-string v8, "scaleX"

    const/4 v9, 0x5

    new-array v9, v9, [F

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    const/4 v11, 0x0

    const/4 v12, 0x1

    int-to-float v12, v12

    aput v12, v10, v11

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    const/4 v11, 0x1

    const v12, 0x3f4ccccd  # 0.8f

    aput v12, v10, v11

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    const/4 v11, 0x2

    const v12, 0x3fa66666  # 1.3f

    aput v12, v10, v11

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    const/4 v11, 0x3

    const v12, 0x3f4ccccd  # 0.8f

    aput v12, v10, v11

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    const/4 v11, 0x4

    const v12, 0x3f666666  # 0.9f

    aput v12, v10, v11

    invoke-static {v7, v8, v9}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object v7

    move-object v4, v7

    .line 35
    move-object v7, v4

    move v8, v2

    int-to-long v8, v8

    invoke-virtual {v7, v8, v9}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    move-result-object v7

    .line 36
    move-object v7, v4

    invoke-virtual {v7}, Landroid/animation/ObjectAnimator;->start()V

    .line 37
    move-object v7, v1

    const-string v8, "scaleY"

    const/4 v9, 0x5

    new-array v9, v9, [F

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    const/4 v11, 0x0

    const/4 v12, 0x1

    int-to-float v12, v12

    aput v12, v10, v11

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    const/4 v11, 0x1

    const v12, 0x3f4ccccd  # 0.8f

    aput v12, v10, v11

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    const/4 v11, 0x2

    const v12, 0x3fa66666  # 1.3f

    aput v12, v10, v11

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    const/4 v11, 0x3

    const v12, 0x3f4ccccd  # 0.8f

    aput v12, v10, v11

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    const/4 v11, 0x4

    const v12, 0x3f666666  # 0.9f

    aput v12, v10, v11

    invoke-static {v7, v8, v9}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object v7

    move-object v5, v7

    .line 38
    move-object v7, v5

    move v8, v2

    int-to-long v8, v8

    invoke-virtual {v7, v8, v9}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    move-result-object v7

    .line 39
    move-object v7, v5

    invoke-virtual {v7}, Landroid/animation/ObjectAnimator;->start()V

    return-void
.end method

.method public static initToast(Landroid/content/Context;Ljava/lang/CharSequence;)V
    .registers 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/CharSequence;",
            ")V"
        }
    .end annotation

    .prologue
    .line 43
    move-object v0, p0

    move-object v1, p1

    invoke-static {}, Landroid/ext/Art_Toast;->cancelToast()V

    .line 44
    new-instance v5, Landroid/ext/Art_Toast;

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    move-object v7, v0

    invoke-direct {v6, v7}, Landroid/ext/Art_Toast;-><init>(Landroid/content/Context;)V

    sput-object v5, Landroid/ext/Art_Toast;->toast:Landroid/ext/Art_Toast;

    .line 45
    new-instance v5, Landroid/widget/TextView;

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    move-object v7, v0

    invoke-direct {v6, v7}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v3, v5

    .line 46
    move-object v5, v3

    sget v6, Landroid/ext/Art_Toast;->id:I

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setBackgroundResource(I)V

    .line 47
    move-object v5, v3

    const/4 v6, -0x1

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 48
    move-object v5, v3

    move-object v6, v1

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 49
    move-object v5, v3

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setPivotY(F)V

    .line 50
    move-object v5, v3

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setScaleY(F)V

    .line 51
    sget-object v5, Landroid/ext/Art_Toast;->toast:Landroid/ext/Art_Toast;

    const/16 v6, 0x50

    const/4 v7, 0x0

    const/16 v8, 0x46

    invoke-virtual {v5, v6, v7, v8}, Landroid/ext/Art_Toast;->setGravity(III)V

    .line 52
    sget-object v5, Landroid/ext/Art_Toast;->toast:Landroid/ext/Art_Toast;

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Landroid/ext/Art_Toast;->setDuration(I)V

    .line 53
    sget-object v5, Landroid/ext/Art_Toast;->toast:Landroid/ext/Art_Toast;

    move-object v6, v3

    invoke-virtual {v5, v6}, Landroid/ext/Art_Toast;->setView(Landroid/view/View;)V

    return-void
.end method

.method public static show(Landroid/content/Context;Ljava/lang/CharSequence;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/CharSequence;",
            ")V"
        }
    .end annotation

    .prologue
    .line 57
    move-object v0, p0

    move-object v1, p1

    move-object v4, v1

    if-eqz v4, :cond_1a

    .line 59
    move-object v4, v0

    move-object v5, v1

    invoke-static {v4, v5}, Landroid/ext/Art_Toast;->initToast(Landroid/content/Context;Ljava/lang/CharSequence;)V

    .line 60
    sget-object v4, Landroid/ext/Art_Toast;->toast:Landroid/ext/Art_Toast;

    invoke-virtual {v4}, Landroid/ext/Art_Toast;->getView()Landroid/view/View;

    move-result-object v4

    sget v5, Landroid/ext/Art_Toast;->time:I

    invoke-static {v4, v5}, Landroid/ext/Art_Toast;->controlWater(Landroid/view/View;I)V

    .line 61
    sget-object v4, Landroid/ext/Art_Toast;->toast:Landroid/ext/Art_Toast;

    invoke-virtual {v4}, Landroid/ext/Art_Toast;->show()V

    :cond_1a
    return-void
.end method


# virtual methods
.method public cancel()V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 26
    move-object v0, p0

    move-object v2, v0

    invoke-super {v2}, Landroid/widget/Toast;->cancel()V

    return-void
.end method

.method public show()V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 30
    move-object v0, p0

    move-object v2, v0

    invoke-super {v2}, Landroid/widget/Toast;->show()V

    return-void
.end method
