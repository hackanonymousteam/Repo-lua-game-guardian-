.class Landroid/ext/Tools$11;
.super Ljava/lang/Object;
.source "Tools.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroid/ext/Tools;->showToast(Ljava/lang/String;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private final synthetic val$text:Ljava/lang/String;

.field private final synthetic val$time:I


# direct methods
.method constructor <init>(Ljava/lang/String;I)V
    .registers 3

    .prologue
    .line 629
    iput-object p1, p0, Landroid/ext/Tools$11;->val$text:Ljava/lang/String;

    iput p2, p0, Landroid/ext/Tools$11;->val$time:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    .prologue
    .line 633
    invoke-static {}, Landroid/ext/Tools;->e()Landroid/content/Context;

    move-result-object v2

    iget-object v1, p0, Landroid/ext/Tools$11;->val$text:Ljava/lang/String;

    invoke-static {v2, v1}, Landroid/ext/Art_Toast;->show(Landroid/content/Context;Ljava/lang/CharSequence;)V

    return-void
.end method
