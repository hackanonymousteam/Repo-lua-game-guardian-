.class Landroid/ext/sm;
.super Ljava/lang/Object;
.source "src"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final synthetic a:Ljava/lang/String;

.field private final synthetic b:I


# direct methods
.method constructor <init>(Ljava/lang/String;I)V
    .registers 3

    .prologue
    .line 629
    iput-object p1, p0, Landroid/ext/sm;->a:Ljava/lang/String;

    iput p2, p0, Landroid/ext/sm;->b:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 4

    .prologue
    .line 633
    invoke-static {}, Landroid/ext/sf;->b()Landroid/content/Context;

    move-result-object v1

    iget-object v0, p0, Landroid/ext/sm;->a:Ljava/lang/String;

    invoke-static {v1, v0}, Landroid/ext/Art_Toast;->show(Landroid/content/Context;Ljava/lang/CharSequence;)V

    return-void
.end method
