.class Landroid/ext/Script$alertBatman$1;
.super Ljava/lang/Object;
.source "Script.java"

# interfaces
.implements Ljava/lang/Runnable;
.implements Landroid/ext/AlertBatman$OnSelectionListener;


# instance fields
.field private selectedItems:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic this$0:Landroid/ext/Script$alertBatman;

.field private final val$message:Ljava/lang/String;

.field private final val$selected:Lluaj/LuaValue;

.field private final val$texts:[Ljava/lang/CharSequence;

.field private final val$which:I


# direct methods
.method constructor <init>(Landroid/ext/Script$alertBatman;Ljava/lang/String;Lluaj/LuaValue;[Ljava/lang/CharSequence;I)V
    .registers 7

    .prologue
    .line 2165
    iput-object p1, p0, Landroid/ext/Script$alertBatman$1;->this$0:Landroid/ext/Script$alertBatman;

    iput-object p2, p0, Landroid/ext/Script$alertBatman$1;->val$message:Ljava/lang/String;

    iput-object p3, p0, Landroid/ext/Script$alertBatman$1;->val$selected:Lluaj/LuaValue;

    iput-object p4, p0, Landroid/ext/Script$alertBatman$1;->val$texts:[Ljava/lang/CharSequence;

    iput p5, p0, Landroid/ext/Script$alertBatman$1;->val$which:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2167
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroid/ext/Script$alertBatman$1;->selectedItems:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public onSelection(Ljava/util/List;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List",
            "<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .prologue
    .line 2171
    iput-object p1, p0, Landroid/ext/Script$alertBatman$1;->selectedItems:Ljava/util/List;

    .line 2173
    iget-object v1, p0, Landroid/ext/Script$alertBatman$1;->this$0:Landroid/ext/Script$alertBatman;

    monitor-enter v1

    .line 2174
    :try_start_5
    iget-object v0, p0, Landroid/ext/Script$alertBatman$1;->this$0:Landroid/ext/Script$alertBatman;

    invoke-virtual {v0}, Ljava/lang/Object;->notifyAll()V

    .line 2173
    monitor-exit v1

    .line 2176
    return-void

    .line 2173
    :catchall_c
    move-exception v0

    monitor-exit v1
    :try_end_e
    .catchall {:try_start_5 .. :try_end_e} :catchall_c

    throw v0
.end method

.method public run()V
    .registers 7

    .prologue
    .line 2180
    iget-object v1, p0, Landroid/ext/Script$alertBatman$1;->val$message:Ljava/lang/String;

    .line 2182
    iget-object v2, p0, Landroid/ext/Script$alertBatman$1;->val$texts:[Ljava/lang/CharSequence;

    array-length v3, v2

    .line 2183
    new-array v4, v3, [Ljava/lang/String;

    .line 2184
    const/4 v0, 0x0

    :goto_8
    if-lt v0, v3, :cond_14

    .line 2188
    invoke-static {}, Landroid/ext/Tools;->e()Landroid/content/Context;

    move-result-object v0

    .line 2189
    iget-object v5, p0, Landroid/ext/Script$alertBatman$1;->val$selected:Lluaj/LuaValue;

    invoke-static {v0, v1, v4, p0}, Landroid/ext/AlertBatman;->show(Landroid/content/Context;Ljava/lang/String;[Ljava/lang/String;Landroid/ext/AlertBatman$OnSelectionListener;)V

    .line 2190
    return-void

    .line 2185
    :cond_14
    aget-object v5, v2, v0

    invoke-interface {v5}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v4, v0

    .line 2184
    add-int/lit8 v0, v0, 0x1

    goto :goto_8
.end method
