.class public interface Landroid/ext/AlertBatman$OnSelectionListener;
.super Ljava/lang/Object;
.source "AlertBatman.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/ext/AlertBatman;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x209
    name = "OnSelectionListener"
.end annotation


# virtual methods
.method public abstract onSelection(Ljava/util/List;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List",
            "<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation
.end method
