.class Landroid/ext/AlertBatman$100000002;
.super Ljava/lang/Object;
.source "AlertBatman.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/ext/AlertBatman;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000002"
.end annotation


# instance fields
.field private final val$mainContainer:Landroid/widget/LinearLayout;


# direct methods
.method constructor <init>(Landroid/widget/LinearLayout;)V
    .registers 7

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Landroid/ext/AlertBatman$100000002;->val$mainContainer:Landroid/widget/LinearLayout;

    return-void
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .registers 13
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 175
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v6, v2

    invoke-virtual {v6}, Landroid/view/MotionEvent;->getAction()I

    move-result v6

    const/4 v7, 0x0

    if-ne v6, v7, :cond_47

    .line 176
    new-instance v6, Landroid/graphics/Rect;

    move-object v9, v6

    move-object v6, v9

    move-object v7, v9

    invoke-direct {v7}, Landroid/graphics/Rect;-><init>()V

    move-object v4, v6

    .line 177
    move-object v6, v0

    iget-object v6, v6, Landroid/ext/AlertBatman$100000002;->val$mainContainer:Landroid/widget/LinearLayout;

    move-object v7, v4

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->getGlobalVisibleRect(Landroid/graphics/Rect;)Z

    move-result v6

    .line 178
    move-object v6, v4

    move-object v7, v2

    invoke-virtual {v7}, Landroid/view/MotionEvent;->getRawX()F

    move-result v7

    float-to-int v7, v7

    move-object v8, v2

    invoke-virtual {v8}, Landroid/view/MotionEvent;->getRawY()F

    move-result v8

    float-to-int v8, v8

    invoke-virtual {v6, v7, v8}, Landroid/graphics/Rect;->contains(II)Z

    move-result v6

    if-nez v6, :cond_47

    .line 179
    invoke-static {}, Landroid/ext/AlertBatman;->access$L1000008()Landroid/ext/AlertBatman$OnSelectionListener;

    move-result-object v6

    if-eqz v6, :cond_44

    .line 180
    invoke-static {}, Landroid/ext/AlertBatman;->access$L1000008()Landroid/ext/AlertBatman$OnSelectionListener;

    move-result-object v6

    new-instance v7, Ljava/util/ArrayList;

    move-object v9, v7

    move-object v7, v9

    move-object v8, v9

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v6, v7}, Landroid/ext/AlertBatman$OnSelectionListener;->onSelection(Ljava/util/List;)V

    .line 182
    :cond_44
    invoke-static {}, Landroid/ext/AlertBatman;->access$1000012()V

    .line 185
    :cond_47
    const/4 v6, 0x1

    move v0, v6

    return v0
.end method
