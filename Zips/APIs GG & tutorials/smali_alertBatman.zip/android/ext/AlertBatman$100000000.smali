.class Landroid/ext/AlertBatman$100000000;
.super Ljava/lang/Object;
.source "AlertBatman.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/ext/AlertBatman;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# instance fields
.field private final val$optionsContainer:Landroid/widget/LinearLayout;


# direct methods
.method constructor <init>(Landroid/widget/LinearLayout;)V
    .registers 7

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Landroid/ext/AlertBatman$100000000;->val$optionsContainer:Landroid/widget/LinearLayout;

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 128
    move-object v0, p0

    move-object v1, p1

    const/4 v7, 0x0

    move v3, v7

    :goto_4
    move v7, v3

    move-object v8, v0

    iget-object v8, v8, Landroid/ext/AlertBatman$100000000;->val$optionsContainer:Landroid/widget/LinearLayout;

    invoke-virtual {v8}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v8

    if-lt v7, v8, :cond_23

    .line 136
    invoke-static {}, Landroid/ext/AlertBatman;->access$L1000008()Landroid/ext/AlertBatman$OnSelectionListener;

    move-result-object v7

    if-eqz v7, :cond_1f

    .line 137
    invoke-static {}, Landroid/ext/AlertBatman;->access$L1000008()Landroid/ext/AlertBatman$OnSelectionListener;

    move-result-object v7

    invoke-static {}, Landroid/ext/AlertBatman;->access$L1000007()Ljava/util/List;

    move-result-object v8

    invoke-interface {v7, v8}, Landroid/ext/AlertBatman$OnSelectionListener;->onSelection(Ljava/util/List;)V

    .line 139
    :cond_1f
    invoke-static {}, Landroid/ext/AlertBatman;->access$1000012()V

    return-void

    .line 129
    :cond_23
    move-object v7, v0

    iget-object v7, v7, Landroid/ext/AlertBatman$100000000;->val$optionsContainer:Landroid/widget/LinearLayout;

    move v8, v3

    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v7

    move-object v4, v7

    .line 130
    move-object v7, v4

    instance-of v7, v7, Landroid/widget/CheckBox;

    if-eqz v7, :cond_51

    .line 131
    move-object v7, v4

    check-cast v7, Landroid/widget/CheckBox;

    move-object v5, v7

    .line 132
    invoke-static {}, Landroid/ext/AlertBatman;->access$L1000007()Ljava/util/List;

    move-result-object v7

    move v8, v3

    move-object v9, v5

    invoke-virtual {v9}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v9

    new-instance v10, Ljava/lang/Boolean;

    move v12, v9

    move-object v13, v10

    move-object v9, v13

    move v10, v12

    move-object v11, v13

    move v12, v10

    move-object v13, v11

    move-object v10, v13

    move v11, v12

    invoke-direct {v10, v11}, Ljava/lang/Boolean;-><init>(Z)V

    invoke-interface {v7, v8, v9}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    .line 128
    :cond_51
    add-int/lit8 v3, v3, 0x1

    goto :goto_4
.end method
