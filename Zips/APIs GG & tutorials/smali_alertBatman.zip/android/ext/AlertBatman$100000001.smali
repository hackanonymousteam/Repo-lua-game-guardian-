.class Landroid/ext/AlertBatman$100000001;
.super Ljava/lang/Object;
.source "AlertBatman.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/ext/AlertBatman;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000001"
.end annotation


# direct methods
.method constructor <init>()V
    .registers 4

    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .registers 11
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 154
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v2

    invoke-virtual {v4}, Landroid/view/MotionEvent;->getAction()I

    move-result v4

    packed-switch v4, :pswitch_data_72

    .line 168
    :pswitch_b  #0x1
    const/4 v4, 0x0

    move v0, v4

    :goto_d
    return v0

    .line 156
    :pswitch_e  #0x0
    invoke-static {}, Landroid/ext/AlertBatman;->access$L1000002()Landroid/view/WindowManager$LayoutParams;

    move-result-object v4

    iget v4, v4, Landroid/view/WindowManager$LayoutParams;->x:I

    invoke-static {v4}, Landroid/ext/AlertBatman;->access$S1000003(I)V

    .line 157
    invoke-static {}, Landroid/ext/AlertBatman;->access$L1000002()Landroid/view/WindowManager$LayoutParams;

    move-result-object v4

    iget v4, v4, Landroid/view/WindowManager$LayoutParams;->y:I

    invoke-static {v4}, Landroid/ext/AlertBatman;->access$S1000004(I)V

    .line 158
    move-object v4, v2

    invoke-virtual {v4}, Landroid/view/MotionEvent;->getRawX()F

    move-result v4

    invoke-static {v4}, Landroid/ext/AlertBatman;->access$S1000005(F)V

    .line 159
    move-object v4, v2

    invoke-virtual {v4}, Landroid/view/MotionEvent;->getRawY()F

    move-result v4

    invoke-static {v4}, Landroid/ext/AlertBatman;->access$S1000006(F)V

    .line 160
    const/4 v4, 0x1

    move v0, v4

    goto :goto_d

    .line 163
    :pswitch_33  #0x2
    invoke-static {}, Landroid/ext/AlertBatman;->access$L1000002()Landroid/view/WindowManager$LayoutParams;

    move-result-object v4

    invoke-static {}, Landroid/ext/AlertBatman;->access$L1000003()I

    move-result v5

    move-object v6, v2

    invoke-virtual {v6}, Landroid/view/MotionEvent;->getRawX()F

    move-result v6

    invoke-static {}, Landroid/ext/AlertBatman;->access$L1000005()F

    move-result v7

    sub-float/2addr v6, v7

    float-to-int v6, v6

    add-int/2addr v5, v6

    iput v5, v4, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 164
    invoke-static {}, Landroid/ext/AlertBatman;->access$L1000002()Landroid/view/WindowManager$LayoutParams;

    move-result-object v4

    invoke-static {}, Landroid/ext/AlertBatman;->access$L1000004()I

    move-result v5

    move-object v6, v2

    invoke-virtual {v6}, Landroid/view/MotionEvent;->getRawY()F

    move-result v6

    invoke-static {}, Landroid/ext/AlertBatman;->access$L1000006()F

    move-result v7

    sub-float/2addr v6, v7

    float-to-int v6, v6

    add-int/2addr v5, v6

    iput v5, v4, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 165
    invoke-static {}, Landroid/ext/AlertBatman;->access$L1000000()Landroid/view/WindowManager;

    move-result-object v4

    invoke-static {}, Landroid/ext/AlertBatman;->access$L1000001()Landroid/widget/FrameLayout;

    move-result-object v5

    invoke-static {}, Landroid/ext/AlertBatman;->access$L1000002()Landroid/view/WindowManager$LayoutParams;

    move-result-object v6

    invoke-interface {v4, v5, v6}, Landroid/view/WindowManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 166
    const/4 v4, 0x1

    move v0, v4

    goto :goto_d

    .line 154
    nop

    :pswitch_data_72
    .packed-switch 0x0
        :pswitch_e  #00000000
        :pswitch_b  #00000001
        :pswitch_33  #00000002
    .end packed-switch
.end method
