.class public Landroid/ext/AlertBatman;
.super Ljava/lang/Object;
.source "AlertBatman.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/ext/AlertBatman$OnSelectionListener;,
        Landroid/ext/AlertBatman$100000000;,
        Landroid/ext/AlertBatman$100000001;,
        Landroid/ext/AlertBatman$100000002;
    }
.end annotation


# static fields
.field private static alertLayout:Landroid/widget/FrameLayout;

.field private static initialTouchX:F

.field private static initialTouchY:F

.field private static initialX:I

.field private static initialY:I

.field private static params:Landroid/view/WindowManager$LayoutParams;

.field private static selectedItems:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field private static selectionListener:Landroid/ext/AlertBatman$OnSelectionListener;

.field private static windowManager:Landroid/view/WindowManager;


# direct methods
.method static final constructor <clinit>()V
    .registers 5

    new-instance v2, Ljava/util/ArrayList;

    move-object v4, v2

    move-object v2, v4

    move-object v3, v4

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    sput-object v2, Landroid/ext/AlertBatman;->selectedItems:Ljava/util/List;

    return-void
.end method

.method public constructor <init>()V
    .registers 4

    .prologue
    .line 204
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic access$1000012()V
    .registers 0

    invoke-static {}, Landroid/ext/AlertBatman;->removeAlert()V

    return-void
.end method

.method static synthetic access$L1000000()Landroid/view/WindowManager;
    .registers 3

    sget-object v2, Landroid/ext/AlertBatman;->windowManager:Landroid/view/WindowManager;

    move-object v0, v2

    return-object v0
.end method

.method static synthetic access$L1000001()Landroid/widget/FrameLayout;
    .registers 3

    sget-object v2, Landroid/ext/AlertBatman;->alertLayout:Landroid/widget/FrameLayout;

    move-object v0, v2

    return-object v0
.end method

.method static synthetic access$L1000002()Landroid/view/WindowManager$LayoutParams;
    .registers 3

    sget-object v2, Landroid/ext/AlertBatman;->params:Landroid/view/WindowManager$LayoutParams;

    move-object v0, v2

    return-object v0
.end method

.method static synthetic access$L1000003()I
    .registers 3

    sget v2, Landroid/ext/AlertBatman;->initialX:I

    move v0, v2

    return v0
.end method

.method static synthetic access$L1000004()I
    .registers 3

    sget v2, Landroid/ext/AlertBatman;->initialY:I

    move v0, v2

    return v0
.end method

.method static synthetic access$L1000005()F
    .registers 3

    sget v2, Landroid/ext/AlertBatman;->initialTouchX:F

    move v0, v2

    return v0
.end method

.method static synthetic access$L1000006()F
    .registers 3

    sget v2, Landroid/ext/AlertBatman;->initialTouchY:F

    move v0, v2

    return v0
.end method

.method static synthetic access$L1000007()Ljava/util/List;
    .registers 3

    sget-object v2, Landroid/ext/AlertBatman;->selectedItems:Ljava/util/List;

    move-object v0, v2

    return-object v0
.end method

.method static synthetic access$L1000008()Landroid/ext/AlertBatman$OnSelectionListener;
    .registers 3

    sget-object v2, Landroid/ext/AlertBatman;->selectionListener:Landroid/ext/AlertBatman$OnSelectionListener;

    move-object v0, v2

    return-object v0
.end method

.method static synthetic access$S1000000(Landroid/view/WindowManager;)V
    .registers 5

    move-object v0, p0

    move-object v3, v0

    sput-object v3, Landroid/ext/AlertBatman;->windowManager:Landroid/view/WindowManager;

    return-void
.end method

.method static synthetic access$S1000001(Landroid/widget/FrameLayout;)V
    .registers 5

    move-object v0, p0

    move-object v3, v0

    sput-object v3, Landroid/ext/AlertBatman;->alertLayout:Landroid/widget/FrameLayout;

    return-void
.end method

.method static synthetic access$S1000002(Landroid/view/WindowManager$LayoutParams;)V
    .registers 5

    move-object v0, p0

    move-object v3, v0

    sput-object v3, Landroid/ext/AlertBatman;->params:Landroid/view/WindowManager$LayoutParams;

    return-void
.end method

.method static synthetic access$S1000003(I)V
    .registers 5

    move v0, p0

    move v3, v0

    sput v3, Landroid/ext/AlertBatman;->initialX:I

    return-void
.end method

.method static synthetic access$S1000004(I)V
    .registers 5

    move v0, p0

    move v3, v0

    sput v3, Landroid/ext/AlertBatman;->initialY:I

    return-void
.end method

.method static synthetic access$S1000005(F)V
    .registers 5

    move v0, p0

    move v3, v0

    sput v3, Landroid/ext/AlertBatman;->initialTouchX:F

    return-void
.end method

.method static synthetic access$S1000006(F)V
    .registers 5

    move v0, p0

    move v3, v0

    sput v3, Landroid/ext/AlertBatman;->initialTouchY:F

    return-void
.end method

.method static synthetic access$S1000007(Ljava/util/List;)V
    .registers 5

    move-object v0, p0

    move-object v3, v0

    sput-object v3, Landroid/ext/AlertBatman;->selectedItems:Ljava/util/List;

    return-void
.end method

.method static synthetic access$S1000008(Landroid/ext/AlertBatman$OnSelectionListener;)V
    .registers 5

    move-object v0, p0

    move-object v3, v0

    sput-object v3, Landroid/ext/AlertBatman;->selectionListener:Landroid/ext/AlertBatman$OnSelectionListener;

    return-void
.end method

.method private static dpToPx(Landroid/content/Context;I)I
    .registers 9

    .prologue
    .line 202
    move-object v0, p0

    move v1, p1

    move-object v5, v0

    invoke-virtual {v5}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v5

    iget v5, v5, Landroid/util/DisplayMetrics;->density:F

    move v3, v5

    .line 203
    move v5, v1

    int-to-float v5, v5

    move v6, v3

    mul-float/2addr v5, v6

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    move v0, v5

    return v0
.end method

.method private static removeAlert()V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 191
    sget-object v3, Landroid/ext/AlertBatman;->alertLayout:Landroid/widget/FrameLayout;

    if-eqz v3, :cond_14

    sget-object v3, Landroid/ext/AlertBatman;->windowManager:Landroid/view/WindowManager;

    if-eqz v3, :cond_14

    .line 193
    :try_start_8
    sget-object v3, Landroid/ext/AlertBatman;->windowManager:Landroid/view/WindowManager;

    sget-object v4, Landroid/ext/AlertBatman;->alertLayout:Landroid/widget/FrameLayout;

    invoke-interface {v3, v4}, Landroid/view/WindowManager;->removeView(Landroid/view/View;)V
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_f} :catch_15

    .line 197
    :goto_f
    const/4 v3, 0x0

    check-cast v3, Landroid/widget/FrameLayout;

    sput-object v3, Landroid/ext/AlertBatman;->alertLayout:Landroid/widget/FrameLayout;

    :cond_14
    return-void

    .line 193
    :catch_15
    move-exception v3

    move-object v1, v3

    .line 195
    move-object v3, v1

    invoke-virtual {v3}, Ljava/lang/Exception;->printStackTrace()V

    goto :goto_f
.end method

.method public static show(Landroid/content/Context;Ljava/lang/String;[Ljava/lang/String;Landroid/ext/AlertBatman$OnSelectionListener;)V
    .registers 33
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "[",
            "Ljava/lang/String;",
            "Landroid/ext/AlertBatman$OnSelectionListener;",
            ")V"
        }
    .end annotation

    .prologue
    .line 34
    move-object/from16 v2, p0

    move-object/from16 v3, p1

    move-object/from16 v4, p2

    move-object/from16 v5, p3

    invoke-static {}, Landroid/ext/AlertBatman;->removeAlert()V

    .line 35
    move-object/from16 v20, v5

    sput-object v20, Landroid/ext/AlertBatman;->selectionListener:Landroid/ext/AlertBatman$OnSelectionListener;

    .line 36
    sget-object v20, Landroid/ext/AlertBatman;->selectedItems:Ljava/util/List;

    invoke-interface/range {v20 .. v20}, Ljava/util/List;->clear()V

    .line 39
    const-string v20, "#FF6200EE"

    invoke-static/range {v20 .. v20}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v20

    move/from16 v7, v20

    .line 40
    const/16 v20, -0x1

    move/from16 v8, v20

    .line 41
    const-string v20, "#FF03DAC5"

    invoke-static/range {v20 .. v20}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v20

    move/from16 v9, v20

    .line 43
    move-object/from16 v20, v2

    const-string v21, "window"

    invoke-virtual/range {v20 .. v21}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v20

    check-cast v20, Landroid/view/WindowManager;

    sput-object v20, Landroid/ext/AlertBatman;->windowManager:Landroid/view/WindowManager;

    .line 44
    new-instance v20, Landroid/widget/FrameLayout;

    move-object/from16 v27, v20

    move-object/from16 v20, v27

    move-object/from16 v21, v27

    move-object/from16 v22, v2

    invoke-direct/range {v21 .. v22}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    sput-object v20, Landroid/ext/AlertBatman;->alertLayout:Landroid/widget/FrameLayout;

    .line 46
    new-instance v20, Landroid/view/WindowManager$LayoutParams;

    move-object/from16 v27, v20

    move-object/from16 v20, v27

    move-object/from16 v21, v27

    const/16 v22, -0x2

    const/16 v23, -0x2

    const/16 v24, 0x7f6

    const/16 v25, 0x8

    const/16 v26, -0x3

    invoke-direct/range {v21 .. v26}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    sput-object v20, Landroid/ext/AlertBatman;->params:Landroid/view/WindowManager$LayoutParams;

    .line 53
    sget-object v20, Landroid/ext/AlertBatman;->params:Landroid/view/WindowManager$LayoutParams;

    const v21, 0x800033

    move/from16 v0, v21

    move-object/from16 v1, v20

    iput v0, v1, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 54
    sget-object v20, Landroid/ext/AlertBatman;->params:Landroid/view/WindowManager$LayoutParams;

    const/16 v21, 0x64

    move/from16 v0, v21

    move-object/from16 v1, v20

    iput v0, v1, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 55
    sget-object v20, Landroid/ext/AlertBatman;->params:Landroid/view/WindowManager$LayoutParams;

    const/16 v21, 0x64

    move/from16 v0, v21

    move-object/from16 v1, v20

    iput v0, v1, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 57
    new-instance v20, Landroid/widget/LinearLayout;

    move-object/from16 v27, v20

    move-object/from16 v20, v27

    move-object/from16 v21, v27

    move-object/from16 v22, v2

    invoke-direct/range {v21 .. v22}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v10, v20

    .line 58
    move-object/from16 v20, v10

    const/16 v21, 0x1

    invoke-virtual/range {v20 .. v21}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 59
    move-object/from16 v20, v10

    new-instance v21, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v27, v21

    move-object/from16 v21, v27

    move-object/from16 v22, v27

    move-object/from16 v23, v2

    const/16 v24, 0x118

    invoke-static/range {v23 .. v24}, Landroid/ext/AlertBatman;->dpToPx(Landroid/content/Context;I)I

    move-result v23

    const/16 v24, -0x2

    invoke-direct/range {v22 .. v24}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v20 .. v21}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 63
    move-object/from16 v20, v10

    move/from16 v21, v7

    invoke-virtual/range {v20 .. v21}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 64
    move-object/from16 v20, v10

    move-object/from16 v21, v2

    const/16 v22, 0x10

    invoke-static/range {v21 .. v22}, Landroid/ext/AlertBatman;->dpToPx(Landroid/content/Context;I)I

    move-result v21

    move-object/from16 v22, v2

    const/16 v23, 0x10

    invoke-static/range {v22 .. v23}, Landroid/ext/AlertBatman;->dpToPx(Landroid/content/Context;I)I

    move-result v22

    move-object/from16 v23, v2

    const/16 v24, 0x10

    invoke-static/range {v23 .. v24}, Landroid/ext/AlertBatman;->dpToPx(Landroid/content/Context;I)I

    move-result v23

    move-object/from16 v24, v2

    const/16 v25, 0x10

    invoke-static/range {v24 .. v25}, Landroid/ext/AlertBatman;->dpToPx(Landroid/content/Context;I)I

    move-result v24

    invoke-virtual/range {v20 .. v24}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 66
    move-object/from16 v20, v10

    move-object/from16 v21, v2

    const/16 v22, 0x8

    invoke-static/range {v21 .. v22}, Landroid/ext/AlertBatman;->dpToPx(Landroid/content/Context;I)I

    move-result v21

    move/from16 v0, v21

    int-to-float v0, v0

    move/from16 v21, v0

    invoke-virtual/range {v20 .. v21}, Landroid/widget/LinearLayout;->setElevation(F)V

    .line 68
    new-instance v20, Landroid/widget/TextView;

    move-object/from16 v27, v20

    move-object/from16 v20, v27

    move-object/from16 v21, v27

    move-object/from16 v22, v2

    invoke-direct/range {v21 .. v22}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v11, v20

    .line 69
    move-object/from16 v20, v11

    const-string v21, "Script"

    invoke-virtual/range {v20 .. v21}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 70
    move-object/from16 v20, v11

    move/from16 v21, v8

    invoke-virtual/range {v20 .. v21}, Landroid/widget/TextView;->setTextColor(I)V

    .line 71
    move-object/from16 v20, v11

    const/16 v21, 0x12

    move/from16 v0, v21

    int-to-float v0, v0

    move/from16 v21, v0

    invoke-virtual/range {v20 .. v21}, Landroid/widget/TextView;->setTextSize(F)V

    .line 72
    move-object/from16 v20, v11

    const/16 v21, 0x11

    invoke-virtual/range {v20 .. v21}, Landroid/widget/TextView;->setGravity(I)V

    .line 73
    move-object/from16 v20, v11

    new-instance v21, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v27, v21

    move-object/from16 v21, v27

    move-object/from16 v22, v27

    const/16 v23, -0x1

    const/16 v24, -0x2

    invoke-direct/range {v22 .. v24}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v20 .. v21}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 78
    new-instance v20, Landroid/widget/TextView;

    move-object/from16 v27, v20

    move-object/from16 v20, v27

    move-object/from16 v21, v27

    move-object/from16 v22, v2

    invoke-direct/range {v21 .. v22}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v12, v20

    .line 79
    move-object/from16 v20, v12

    move-object/from16 v21, v3

    invoke-virtual/range {v20 .. v21}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 80
    move-object/from16 v20, v12

    move/from16 v21, v8

    invoke-virtual/range {v20 .. v21}, Landroid/widget/TextView;->setTextColor(I)V

    .line 81
    move-object/from16 v20, v12

    const/16 v21, 0xe

    move/from16 v0, v21

    int-to-float v0, v0

    move/from16 v21, v0

    invoke-virtual/range {v20 .. v21}, Landroid/widget/TextView;->setTextSize(F)V

    .line 82
    move-object/from16 v20, v12

    const/16 v21, 0x11

    invoke-virtual/range {v20 .. v21}, Landroid/widget/TextView;->setGravity(I)V

    .line 83
    move-object/from16 v20, v12

    new-instance v21, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v27, v21

    move-object/from16 v21, v27

    move-object/from16 v22, v27

    const/16 v23, -0x1

    const/16 v24, -0x2

    invoke-direct/range {v22 .. v24}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v20 .. v21}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 87
    move-object/from16 v20, v12

    const/16 v21, 0x0

    move-object/from16 v22, v2

    const/16 v23, 0x8

    invoke-static/range {v22 .. v23}, Landroid/ext/AlertBatman;->dpToPx(Landroid/content/Context;I)I

    move-result v22

    const/16 v23, 0x0

    move-object/from16 v24, v2

    const/16 v25, 0x10

    invoke-static/range {v24 .. v25}, Landroid/ext/AlertBatman;->dpToPx(Landroid/content/Context;I)I

    move-result v24

    invoke-virtual/range {v20 .. v24}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 89
    new-instance v20, Landroid/widget/ScrollView;

    move-object/from16 v27, v20

    move-object/from16 v20, v27

    move-object/from16 v21, v27

    move-object/from16 v22, v2

    invoke-direct/range {v21 .. v22}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    move-object/from16 v13, v20

    .line 90
    move-object/from16 v20, v13

    new-instance v21, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v27, v21

    move-object/from16 v21, v27

    move-object/from16 v22, v27

    const/16 v23, -0x1

    move-object/from16 v24, v2

    const/16 v25, 0xc8

    invoke-static/range {v24 .. v25}, Landroid/ext/AlertBatman;->dpToPx(Landroid/content/Context;I)I

    move-result v24

    invoke-direct/range {v22 .. v24}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v20 .. v21}, Landroid/widget/ScrollView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 95
    new-instance v20, Landroid/widget/LinearLayout;

    move-object/from16 v27, v20

    move-object/from16 v20, v27

    move-object/from16 v21, v27

    move-object/from16 v22, v2

    invoke-direct/range {v21 .. v22}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v14, v20

    .line 96
    move-object/from16 v20, v14

    const/16 v21, 0x1

    invoke-virtual/range {v20 .. v21}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 97
    move-object/from16 v20, v14

    new-instance v21, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v27, v21

    move-object/from16 v21, v27

    move-object/from16 v22, v27

    const/16 v23, -0x1

    const/16 v24, -0x2

    invoke-direct/range {v22 .. v24}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v20 .. v21}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 102
    move-object/from16 v20, v4

    move-object/from16 v15, v20

    const/16 v20, 0x0

    move/from16 v16, v20

    .line 112
    :goto_1e3
    move/from16 v20, v16

    move-object/from16 v21, v15

    move-object/from16 v0, v21

    array-length v0, v0

    move/from16 v21, v0

    move/from16 v0, v20

    move/from16 v1, v21

    if-lt v0, v1, :cond_298

    .line 115
    move-object/from16 v20, v13

    move-object/from16 v21, v14

    invoke-virtual/range {v20 .. v21}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 117
    new-instance v20, Landroid/widget/Button;

    move-object/from16 v27, v20

    move-object/from16 v20, v27

    move-object/from16 v21, v27

    move-object/from16 v22, v2

    invoke-direct/range {v21 .. v22}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object/from16 v17, v20

    .line 118
    move-object/from16 v20, v17

    const-string v21, "CONFIRMAR"

    invoke-virtual/range {v20 .. v21}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 119
    move-object/from16 v20, v17

    const/high16 v21, -0x1000000

    invoke-virtual/range {v20 .. v21}, Landroid/widget/Button;->setTextColor(I)V

    .line 120
    move-object/from16 v20, v17

    move/from16 v21, v9

    invoke-virtual/range {v20 .. v21}, Landroid/widget/Button;->setBackgroundColor(I)V

    .line 121
    move-object/from16 v20, v17

    new-instance v21, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v27, v21

    move-object/from16 v21, v27

    move-object/from16 v22, v27

    const/16 v23, -0x1

    move-object/from16 v24, v2

    const/16 v25, 0x28

    invoke-static/range {v24 .. v25}, Landroid/ext/AlertBatman;->dpToPx(Landroid/content/Context;I)I

    move-result v24

    invoke-direct/range {v22 .. v24}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v20 .. v21}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 125
    move-object/from16 v20, v17

    new-instance v21, Landroid/ext/AlertBatman$100000000;

    move-object/from16 v27, v21

    move-object/from16 v21, v27

    move-object/from16 v22, v27

    move-object/from16 v23, v14

    invoke-direct/range {v22 .. v23}, Landroid/ext/AlertBatman$100000000;-><init>(Landroid/widget/LinearLayout;)V

    invoke-virtual/range {v20 .. v21}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 143
    move-object/from16 v20, v10

    move-object/from16 v21, v11

    invoke-virtual/range {v20 .. v21}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 144
    move-object/from16 v20, v10

    move-object/from16 v21, v12

    invoke-virtual/range {v20 .. v21}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 145
    move-object/from16 v20, v10

    move-object/from16 v21, v13

    invoke-virtual/range {v20 .. v21}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 146
    move-object/from16 v20, v10

    move-object/from16 v21, v17

    invoke-virtual/range {v20 .. v21}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 148
    sget-object v20, Landroid/ext/AlertBatman;->alertLayout:Landroid/widget/FrameLayout;

    move-object/from16 v21, v10

    invoke-virtual/range {v20 .. v21}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    .line 149
    sget-object v20, Landroid/ext/AlertBatman;->windowManager:Landroid/view/WindowManager;

    sget-object v21, Landroid/ext/AlertBatman;->alertLayout:Landroid/widget/FrameLayout;

    sget-object v22, Landroid/ext/AlertBatman;->params:Landroid/view/WindowManager$LayoutParams;

    invoke-interface/range {v20 .. v22}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 151
    move-object/from16 v20, v10

    new-instance v21, Landroid/ext/AlertBatman$100000001;

    move-object/from16 v27, v21

    move-object/from16 v21, v27

    move-object/from16 v22, v27

    invoke-direct/range {v22 .. v22}, Landroid/ext/AlertBatman$100000001;-><init>()V

    invoke-virtual/range {v20 .. v21}, Landroid/widget/LinearLayout;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 172
    sget-object v20, Landroid/ext/AlertBatman;->alertLayout:Landroid/widget/FrameLayout;

    new-instance v21, Landroid/ext/AlertBatman$100000002;

    move-object/from16 v27, v21

    move-object/from16 v21, v27

    move-object/from16 v22, v27

    move-object/from16 v23, v10

    invoke-direct/range {v22 .. v23}, Landroid/ext/AlertBatman$100000002;-><init>(Landroid/widget/LinearLayout;)V

    invoke-virtual/range {v20 .. v21}, Landroid/widget/FrameLayout;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    return-void

    .line 102
    :cond_298
    move-object/from16 v20, v15

    move/from16 v21, v16

    aget-object v20, v20, v21

    move-object/from16 v17, v20

    .line 103
    new-instance v20, Landroid/widget/TextView;

    move-object/from16 v27, v20

    move-object/from16 v20, v27

    move-object/from16 v21, v27

    move-object/from16 v22, v2

    invoke-direct/range {v21 .. v22}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v18, v20

    .line 104
    move-object/from16 v20, v18

    move-object/from16 v21, v17

    invoke-virtual/range {v20 .. v21}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 105
    move-object/from16 v20, v18

    move/from16 v21, v8

    invoke-virtual/range {v20 .. v21}, Landroid/widget/TextView;->setTextColor(I)V

    .line 106
    move-object/from16 v20, v18

    new-instance v21, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v27, v21

    move-object/from16 v21, v27

    move-object/from16 v22, v27

    const/16 v23, -0x1

    const/16 v24, -0x2

    invoke-direct/range {v22 .. v24}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v20 .. v21}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 110
    move-object/from16 v20, v18

    const/16 v21, 0x0

    move-object/from16 v22, v2

    const/16 v23, 0x8

    invoke-static/range {v22 .. v23}, Landroid/ext/AlertBatman;->dpToPx(Landroid/content/Context;I)I

    move-result v22

    const/16 v23, 0x0

    move-object/from16 v24, v2

    const/16 v25, 0x8

    invoke-static/range {v24 .. v25}, Landroid/ext/AlertBatman;->dpToPx(Landroid/content/Context;I)I

    move-result v24

    invoke-virtual/range {v20 .. v24}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 111
    move-object/from16 v20, v14

    move-object/from16 v21, v18

    invoke-virtual/range {v20 .. v21}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 112
    sget-object v20, Landroid/ext/AlertBatman;->selectedItems:Ljava/util/List;

    const/16 v21, 0x0

    new-instance v22, Ljava/lang/Boolean;

    move/from16 v27, v21

    move-object/from16 v28, v22

    move-object/from16 v21, v28

    move/from16 v22, v27

    move-object/from16 v23, v28

    move/from16 v27, v22

    move-object/from16 v28, v23

    move-object/from16 v22, v28

    move/from16 v23, v27

    invoke-direct/range {v22 .. v23}, Ljava/lang/Boolean;-><init>(Z)V

    invoke-interface/range {v20 .. v21}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v20

    add-int/lit8 v16, v16, 0x1

    goto/16 :goto_1e3
.end method
