.class Landroid/ext/Script$switchChoice$1;
.super Ljava/lang/Object;
.source "Script.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/ext/Script$switchChoice$1$1;
    }
.end annotation


# instance fields
.field final synthetic a:Landroid/ext/Script$switchChoice;

.field private final synthetic b:Ljava/lang/String;

.field private final synthetic c:[Ljava/lang/CharSequence;


# direct methods
.method constructor <init>(Landroid/ext/Script$switchChoice;Ljava/lang/String;[Ljava/lang/CharSequence;)V
    .registers 4

    .prologue
    .line 2287
    iput-object p1, p0, Landroid/ext/Script$switchChoice$1;->a:Landroid/ext/Script$switchChoice;

    iput-object p2, p0, Landroid/ext/Script$switchChoice$1;->b:Ljava/lang/String;

    iput-object p3, p0, Landroid/ext/Script$switchChoice$1;->c:[Ljava/lang/CharSequence;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 8

    .prologue
    const/4 v6, 0x0

    .line 2290
    invoke-static {}, Landroid/ext/Tools;->o()Landroid/content/Context;

    move-result-object v0

    .line 2291
    new-instance v1, Landroid/app/AlertDialog$Builder;

    invoke-direct {v1, v0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 2293
    iget-object v2, p0, Landroid/ext/Script$switchChoice$1;->b:Ljava/lang/String;

    invoke-static {v6, v2}, Landroid/ext/Tools;->b(Ljava/lang/String;Ljava/lang/String;)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setCustomTitle(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    .line 2294
    const v2, 0x7f07009d

    invoke-static {v2}, Landroid/ext/qk;->a(I)Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Landroid/ext/Script$switchChoice$1;->a:Landroid/ext/Script$switchChoice;

    invoke-virtual {v1, v2, v3}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    .line 2295
    const v2, 0x7f0700a1

    invoke-static {v2}, Landroid/ext/qk;->a(I)Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Landroid/ext/Script$switchChoice$1;->a:Landroid/ext/Script$switchChoice;

    invoke-virtual {v1, v2, v3}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    .line 2297
    new-instance v2, Landroid/widget/ListView;

    invoke-direct {v2, v0}, Landroid/widget/ListView;-><init>(Landroid/content/Context;)V

    .line 2298
    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Landroid/widget/ListView;->setChoiceMode(I)V

    .line 2299
    new-instance v3, Landroid/ext/Script$switchChoice$1$1;

    iget-object v4, p0, Landroid/ext/Script$switchChoice$1;->c:[Ljava/lang/CharSequence;

    iget-object v5, p0, Landroid/ext/Script$switchChoice$1;->a:Landroid/ext/Script$switchChoice;

    iget-object v5, v5, Landroid/ext/Script$switchChoice;->d:[Z

    invoke-direct {v3, p0, v0, v4, v5}, Landroid/ext/Script$switchChoice$1$1;-><init>(Landroid/ext/Script$switchChoice$1;Landroid/content/Context;[Ljava/lang/CharSequence;[Z)V

    invoke-virtual {v2, v3}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 2300
    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    .line 2302
    invoke-virtual {v1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v0

    .line 2303
    iget-object v1, p0, Landroid/ext/Script$switchChoice$1;->a:Landroid/ext/Script$switchChoice;

    invoke-virtual {v1, v0}, Landroid/ext/Script$switchChoice;->setDialog(Landroid/app/AlertDialog;)V

    .line 2304
    iget-object v1, p0, Landroid/ext/Script$switchChoice$1;->a:Landroid/ext/Script$switchChoice;

    invoke-virtual {v1, v2}, Landroid/ext/Script$switchChoice;->setListView(Landroid/widget/ListView;)V

    .line 2306
    iget-object v1, p0, Landroid/ext/Script$switchChoice$1;->a:Landroid/ext/Script$switchChoice;

    invoke-static {v0, v1}, Landroid/ext/i;->a(Landroid/app/AlertDialog;Landroid/content/DialogInterface$OnDismissListener;)V

    .line 2307
    invoke-static {v0}, Landroid/ext/i;->c(Landroid/app/AlertDialog;)Landroid/app/AlertDialog;

    .line 2308
    sget-object v0, Landroid/ext/MainService;->instance:Landroid/ext/MainService;

    invoke-virtual {v0, v6}, Landroid/ext/MainService;->b(Z)V

    .line 2309
    return-void
.end method
