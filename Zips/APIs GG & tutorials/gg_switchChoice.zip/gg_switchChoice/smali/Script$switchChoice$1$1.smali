.class Landroid/ext/Script$switchChoice$1$1;
.super Landroid/widget/BaseAdapter;
.source "Script.java"


# instance fields
.field final synthetic a:Landroid/ext/Script$switchChoice$1;

.field private final b:Landroid/content/Context;

.field private final c:[Ljava/lang/CharSequence;

.field private final d:[Z


# direct methods
.method constructor <init>(Landroid/ext/Script$switchChoice$1;Landroid/content/Context;[Ljava/lang/CharSequence;[Z)V
    .registers 5

    .prologue
    .line 2312
    iput-object p1, p0, Landroid/ext/Script$switchChoice$1$1;->a:Landroid/ext/Script$switchChoice$1;

    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 2313
    iput-object p2, p0, Landroid/ext/Script$switchChoice$1$1;->b:Landroid/content/Context;

    .line 2314
    iput-object p3, p0, Landroid/ext/Script$switchChoice$1$1;->c:[Ljava/lang/CharSequence;

    .line 2315
    iput-object p4, p0, Landroid/ext/Script$switchChoice$1$1;->d:[Z

    .line 2316
    return-void
.end method


# virtual methods
.method public a(IZ)V
    .registers 4

    .prologue
    .line 2379
    iget-object v0, p0, Landroid/ext/Script$switchChoice$1$1;->d:[Z

    aput-boolean p2, v0, p1

    .line 2380
    return-void
.end method

.method public getCount()I
    .registers 2

    .prologue
    .line 2320
    iget-object v0, p0, Landroid/ext/Script$switchChoice$1$1;->c:[Ljava/lang/CharSequence;

    array-length v0, v0

    return v0
.end method

.method public getItem(I)Ljava/lang/Object;
    .registers 3

    .prologue
    .line 2325
    iget-object v0, p0, Landroid/ext/Script$switchChoice$1$1;->c:[Ljava/lang/CharSequence;

    aget-object v0, v0, p1

    return-object v0
.end method

.method public getItemId(I)J
    .registers 4

    .prologue
    .line 2330
    int-to-long v0, p1

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .registers 12

    .prologue
    const/16 v7, 0x10

    .line 2335
    iget-object v0, p0, Landroid/ext/Script$switchChoice$1$1;->b:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    .line 2336
    iget v1, v0, Landroid/util/DisplayMetrics;->density:F

    .line 2337
    const/high16 v2, 0x41a00000  # 20.0f

    mul-float/2addr v2, v1

    float-to-int v2, v2

    .line 2338
    const/high16 v3, 0x41600000  # 14.0f

    mul-float/2addr v3, v1

    float-to-int v3, v3

    .line 2340
    if-nez p2, :cond_8d

    .line 2341
    new-instance p2, Landroid/widget/LinearLayout;

    iget-object v4, p0, Landroid/ext/Script$switchChoice$1$1;->b:Landroid/content/Context;

    invoke-direct {p2, v4}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 2342
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x1

    const/4 v6, -0x2

    invoke-direct {v4, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p2, v4}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2343
    invoke-virtual {p2, v7}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 2344
    invoke-virtual {p2, v2, v2, v2, v2}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 2346
    new-instance v2, Landroid/widget/TextView;

    iget-object v4, p0, Landroid/ext/Script$switchChoice$1$1;->b:Landroid/content/Context;

    invoke-direct {v2, v4}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2347
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, 0x0

    const/4 v6, -0x2

    invoke-direct {v4, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 2348
    const/high16 v5, 0x3f800000  # 1.0f

    iput v5, v4, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    .line 2349
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2350
    invoke-virtual {v2, v7}, Landroid/widget/TextView;->setGravity(I)V

    .line 2351
    const/high16 v4, 0x41800000  # 16.0f

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextSize(F)V

    .line 2353
    new-instance v4, Landroid/widget/Switch;

    iget-object v5, p0, Landroid/ext/Script$switchChoice$1$1;->b:Landroid/content/Context;

    invoke-direct {v4, v5}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    .line 2354
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x2

    const/4 v7, -0x2

    invoke-direct {v5, v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 2355
    invoke-virtual {v4, v5}, Landroid/widget/Switch;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2357
    invoke-virtual {p2, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2358
    invoke-virtual {p2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2360
    new-instance v5, Landroid/ext/Script$switchChoice$1$1$1;

    invoke-direct {v5}, Landroid/ext/Script$switchChoice$1$1$1;-><init>()V

    .line 2361
    iput-object v2, v5, Landroid/ext/Script$switchChoice$1$1$1;->a:Landroid/widget/TextView;

    .line 2362
    iput-object v4, v5, Landroid/ext/Script$switchChoice$1$1$1;->b:Landroid/widget/Switch;

    .line 2363
    invoke-virtual {p2, v5}, Landroid/widget/LinearLayout;->setTag(Ljava/lang/Object;)V

    move-object v1, v5

    .line 2368
    :goto_70
    iget-object v2, p0, Landroid/ext/Script$switchChoice$1$1;->c:[Ljava/lang/CharSequence;

    aget-object v2, v2, p1

    .line 2369
    iget-object v4, v1, Landroid/ext/Script$switchChoice$1$1$1;->a:Landroid/widget/TextView;

    invoke-virtual {v4, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2371
    iget-object v2, v1, Landroid/ext/Script$switchChoice$1$1$1;->b:Landroid/widget/Switch;

    iget-object v4, p0, Landroid/ext/Script$switchChoice$1$1;->d:[Z

    aget-boolean v4, v4, p1

    invoke-virtual {v2, v4}, Landroid/widget/Switch;->setChecked(Z)V

    .line 2373
    iget-object v1, v1, Landroid/ext/Script$switchChoice$1$1$1;->b:Landroid/widget/Switch;

    new-instance v2, Landroid/ext/Script$switchChoice$1$1$2;

    invoke-direct {v2, p0, p1}, Landroid/ext/Script$switchChoice$1$1$2;-><init>(Landroid/ext/Script$switchChoice$1$1;I)V

    invoke-virtual {v1, v2}, Landroid/widget/Switch;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 2380
    return-object p2

    .line 2365
    :cond_8d
    invoke-virtual {p2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/ext/Script$switchChoice$1$1$1;

    goto :goto_70
.end method
