.class Landroid/ext/Script$switchChoice$1$1$1;
.super Ljava/lang/Object;
.source "Script.java"


# instance fields
.field a:Landroid/widget/TextView;

.field b:Landroid/widget/Switch;


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 2362
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
