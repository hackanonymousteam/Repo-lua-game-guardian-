.class Landroid/ext/Script$switchChoice$1$1$2;
.super Ljava/lang/Object;
.source "Script.java"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# instance fields
.field final synthetic a:Landroid/ext/Script$switchChoice$1$1;

.field private final synthetic b:I


# direct methods
.method constructor <init>(Landroid/ext/Script$switchChoice$1$1;I)V
    .registers 3

    .prologue
    .line 2352
    iput-object p1, p0, Landroid/ext/Script$switchChoice$1$1$2;->a:Landroid/ext/Script$switchChoice$1$1;

    iput p2, p0, Landroid/ext/Script$switchChoice$1$1$2;->b:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .registers 4

    .prologue
    .line 2355
    iget-object v0, p0, Landroid/ext/Script$switchChoice$1$1$2;->a:Landroid/ext/Script$switchChoice$1$1;

    iget p0, p0, Landroid/ext/Script$switchChoice$1$1$2;->b:I

    invoke-virtual {v0, p0, p2}, Landroid/ext/Script$switchChoice$1$1;->a(IZ)V

    .line 2356
    return-void
.end method
