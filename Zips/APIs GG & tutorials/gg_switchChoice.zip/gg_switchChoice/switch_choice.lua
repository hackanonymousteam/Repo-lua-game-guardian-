
gg.setVisible(false)
estado = {
    funcao1 = false,
    funcao2 = false,
    funcao3 = false,
    funcao4 = false
}

while true do
    menu = gg.switchChoice({
        "🔧 Function 1                       " .. (estado.funcao1 and "ON" or "OFF"),
        "⭐ Function 2                       " .. (estado.funcao2 and "ON" or "OFF"),
  "📊 Function 3                         " .. (estado.funcao3 and "ON" or "OFF"),  
  "❓ Function 4                      " .. (estado.funcao4 and "ON" or "OFF"),   "🚪 Exit"
    }, {}, "Menu")

    if not menu then
        break
    else
        if menu[1] then
            estado.funcao1 = not estado.funcao1
            gg.toast("Function 1: " .. (estado.funcao1 and "ON" or "OFF"))
            if estado.funcao1 then
                gg.alert("function 1 ON")
            else
                gg.alert("function 1 OFF")
            end
        else
            if menu[2] then
                estado.funcao2 = not estado.funcao2
                gg.toast("Function 2: " .. (estado.funcao2 and "ON" or "OFF"))
                if estado.funcao2 then
                    gg.alert("function 2 ON")
                else
                    gg.alert("function 2 OFF")
                end
            else
                if menu[3] then
                    estado.funcao3 = not estado.funcao3
                    gg.toast("Function 3: " .. (estado.funcao3 and "ON" or "OFF"))
                    if estado.funcao3 then
                        gg.alert("function 3 ON")
                    else
                        gg.alert("function 3 OFF")
                    end
                else
                    if menu[4] then
                        estado.funcao4 = not estado.funcao4
                        gg.toast("Function 4: " .. (estado.funcao4 and "ON" or "OFF"))
                        if estado.funcao4 then
                            gg.alert(" function 4 ON")
                        else
                            gg.alert("function 4 OFF")
                        end
                    else
                        if menu[5] then
                            gg.toast("Exiting...")
                            os.exit()
                        end
                    end
                end
            end
        end
    end
end