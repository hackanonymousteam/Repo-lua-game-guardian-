gg.setVisible(true)

local TypedValue=luajava.bindClass("android.util.TypedValue")
local Gravity=luajava.bindClass("android.view.Gravity")
local PixelFormat=luajava.bindClass("android.graphics.PixelFormat")
local Color=luajava.bindClass("android.graphics.Color")
local GradientDrawable=luajava.bindClass("android.graphics.drawable.GradientDrawable")
local Typeface=luajava.bindClass("android.graphics.Typeface")
local View=luajava.bindClass("android.view.View")
local MotionEvent=luajava.bindClass("android.view.MotionEvent")
local WindowManager=luajava.bindClass("android.view.WindowManager")
local Context=luajava.bindClass("android.content.Context")
local Build=luajava.bindClass("android.os.Build")
local LinearLayout=luajava.bindClass("android.widget.LinearLayout")
local TextView=luajava.bindClass("android.widget.TextView")
local Button=luajava.bindClass("android.widget.Button")
local ScrollView=luajava.bindClass("android.widget.ScrollView")
local FrameLayout=luajava.bindClass("android.widget.FrameLayout")

local PRIMARY_COLOR=Color.parseColor("#FF4500")
local SECONDARY_COLOR=Color.parseColor("#1E1E1E")
local DARK_BG=Color.parseColor("#121212")
local WHITE=Color.parseColor("#FFFFFF")
local BLACK=Color.parseColor("#000000")
local RED=Color.parseColor("#F44336")
local GREEN=Color.parseColor("#4CAF50")
local BLUE=Color.parseColor("#2196F3")
local PURPLE=Color.parseColor("#9C27B0")
local YELLOW=Color.parseColor("#FFC107")
local GRAY=Color.parseColor("#888888")

local function dp(value)
return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,value,activity.getResources().getDisplayMetrics())
end

local function getShapeBackground(color,radius)
local drawable=GradientDrawable()
drawable.setShape(GradientDrawable.RECTANGLE)
drawable.setColor(color)
drawable.setCornerRadius(dp(radius))
return drawable
end

local function getBorderBackground(bgColor,borderColor,borderWidth,radius)
local drawable=GradientDrawable()
drawable.setShape(GradientDrawable.RECTANGLE)
drawable.setColor(bgColor)
drawable.setStroke(dp(borderWidth),borderColor)
drawable.setCornerRadius(dp(radius))
return drawable
end

function getLayoutType()
if Build.VERSION.SDK_INT>=26 then
return WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
else
return WindowManager.LayoutParams.TYPE_PHONE
end
end

local floatWindow=nil
local windowManager=nil
local mainLayoutParams=nil
local isMenuVisible=false
local lastX,lastY,startX,startY=0,0,0,0
local controlView=nil
local menuView=nil
local contentView=nil
local shouldExit=false
local speedHackPending=false
local menuVisible=-1

function createFloatingButton()
local buttonLayout=LinearLayout(activity)
buttonLayout.setLayoutParams(LinearLayout.LayoutParams(dp(50),dp(50)))
buttonLayout.setBackground(getShapeBackground(PRIMARY_COLOR,25))
buttonLayout.setGravity(Gravity.CENTER)
local buttonText=TextView(activity)
buttonText.setText("⚡")
buttonText.setTextColor(WHITE)
buttonText.setTextSize(TypedValue.COMPLEX_UNIT_SP,24)
buttonText.setGravity(Gravity.CENTER)
buttonLayout.addView(buttonText)
return buttonLayout
end

function createMenuHeader()
local headerLayout=LinearLayout(activity)
headerLayout.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(60)))
headerLayout.setOrientation(LinearLayout.HORIZONTAL)
headerLayout.setGravity(Gravity.CENTER_VERTICAL)
headerLayout.setPadding(dp(15),dp(5),dp(15),dp(5))
headerLayout.setBackground(getShapeBackground(PRIMARY_COLOR,20))
local iconView=TextView(activity)
iconView.setLayoutParams(LinearLayout.LayoutParams(dp(40),dp(40)))
iconView.setText("🎮")
iconView.setTextSize(TypedValue.COMPLEX_UNIT_SP,24)
iconView.setTextColor(WHITE)
iconView.setGravity(Gravity.CENTER)
iconView.setBackground(getShapeBackground(Color.parseColor("#33FFFFFF"),20))
local titleText=TextView(activity)
titleText.setLayoutParams(LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1))
titleText.setText("BATMAN PLUS")
titleText.setTextColor(WHITE)
titleText.setTextSize(TypedValue.COMPLEX_UNIT_SP,18)
titleText.setTypeface(Typeface.DEFAULT_BOLD)
titleText.setGravity(Gravity.CENTER)
titleText.setPadding(dp(10),0,dp(10),0)
local versionText=TextView(activity)
versionText.setText("v2.0")
versionText.setTextColor(Color.parseColor("#33FFFFFF"))
versionText.setTextSize(TypedValue.COMPLEX_UNIT_SP,12)
versionText.setPadding(dp(5),dp(2),dp(5),dp(2))
versionText.setBackground(getShapeBackground(Color.parseColor("#22FFFFFF"),10))
versionText.setGravity(Gravity.CENTER)
local rightLayout=LinearLayout(activity)
rightLayout.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.MATCH_PARENT))
rightLayout.setOrientation(LinearLayout.HORIZONTAL)
rightLayout.setGravity(Gravity.CENTER_VERTICAL)
local closeBtn=TextView(activity)
closeBtn.setText("✕")
closeBtn.setTextColor(WHITE)
closeBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP,18)
closeBtn.setGravity(Gravity.CENTER)
closeBtn.setLayoutParams(LinearLayout.LayoutParams(dp(40),dp(40)))
closeBtn.setBackground(getShapeBackground(Color.parseColor("#33FFFFFF"),20))
closeBtn.setPadding(0,dp(2),0,0)
closeBtn.onClick=function()
hideMenu()
end
rightLayout.addView(versionText)
rightLayout.addView(closeBtn)
headerLayout.addView(iconView)
headerLayout.addView(titleText)
headerLayout.addView(rightLayout)
return headerLayout
end

function createCategoryButton(text,color,icon,callback)
local button=LinearLayout(activity)
button.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(50)))
button.setOrientation(LinearLayout.HORIZONTAL)
button.setGravity(Gravity.CENTER_VERTICAL)
button.setBackground(getBorderBackground(SECONDARY_COLOR,Color.parseColor("#333333"),1,12))
button.setClickable(true)
local iconText=TextView(activity)
iconText.setLayoutParams(LinearLayout.LayoutParams(dp(250),dp(60)))
iconText.setText(icon)
iconText.setTextSize(TypedValue.COMPLEX_UNIT_SP,18)
iconText.setTextColor(color)
iconText.setGravity(Gravity.CENTER)
local textView=TextView(activity)
textView.setLayoutParams(LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1))
textView.setText(text)
textView.setTextColor(WHITE)
textView.setTextSize(TypedValue.COMPLEX_UNIT_SP,14)
textView.setPadding(dp(10),0,0,0)
textView.setTypeface(Typeface.DEFAULT_BOLD)
local arrowText=TextView(activity)
arrowText.setText("›")
arrowText.setTextColor(WHITE)
arrowText.setTextSize(TypedValue.COMPLEX_UNIT_SP,20)
button.addView(iconText)
button.addView(textView)
button.addView(arrowText)
button.setOnTouchListener(View.OnTouchListener{
onTouch=function(v,event)
if event.getAction()==MotionEvent.ACTION_DOWN then
v.setBackground(getBorderBackground(Color.parseColor("#333333"),color,1,12))
iconText.setBackground(getShapeBackground(Color.parseColor("#33FFFFFF"),15))
elseif event.getAction()==MotionEvent.ACTION_UP or event.getAction()==MotionEvent.ACTION_CANCEL then
v.setBackground(getBorderBackground(SECONDARY_COLOR,Color.parseColor("#333333"),1,12))
iconText.setBackground(getShapeBackground(Color.parseColor("#22FFFFFF"),15))
if event.getAction()==MotionEvent.ACTION_UP then
callback()
end
end
return true
end
})
return button
end

function createActionButton(text,icon,bgColor,callback)
local button=LinearLayout(activity)
button.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(45)))
button.setOrientation(LinearLayout.HORIZONTAL)
button.setGravity(Gravity.CENTER_VERTICAL)
button.setPadding(dp(15),0,dp(15),0)
button.setBackground(getBorderBackground(SECONDARY_COLOR,Color.parseColor("#333333"),1,10))
button.setClickable(true)
local iconText=TextView(activity)
iconText.setLayoutParams(LinearLayout.LayoutParams(dp(80),dp(200)))
iconText.setText(icon)
iconText.setTextSize(TypedValue.COMPLEX_UNIT_SP,14)
iconText.setTextColor(bgColor)
iconText.setGravity(Gravity.CENTER)
local textView=TextView(activity)
textView.setLayoutParams(LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1))
textView.setText(text)
textView.setTextColor(WHITE)
textView.setTextSize(TypedValue.COMPLEX_UNIT_SP,13)
textView.setPadding(dp(10),0,0,0)
button.addView(iconText)
button.addView(textView)
button.setOnTouchListener(View.OnTouchListener{
onTouch=function(v,event)
if event.getAction()==MotionEvent.ACTION_DOWN then
v.setBackground(getBorderBackground(bgColor,WHITE,1,10))
elseif event.getAction()==MotionEvent.ACTION_UP or event.getAction()==MotionEvent.ACTION_CANCEL then
v.setBackground(getBorderBackground(SECONDARY_COLOR,Color.parseColor("#333333"),1,10))
textView.setTextColor(WHITE)
iconText.setTextColor(bgColor)
if event.getAction()==MotionEvent.ACTION_UP then
callback()
end
end
return true
end
})
return button
end

function createMenuContent()
local contentLayout=LinearLayout(activity)
contentLayout.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT))
contentLayout.setOrientation(LinearLayout.VERTICAL)
contentLayout.setPadding(dp(12),dp(12),dp(12),dp(12))
local categoryTitle=TextView(activity)
categoryTitle.setText("Category")
categoryTitle.setTextColor(PRIMARY_COLOR)
categoryTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP,12)
categoryTitle.setTypeface(Typeface.DEFAULT_BOLD)
categoryTitle.setPadding(0,dp(5),0,dp(10))
contentLayout.addView(categoryTitle)
local categories={
{"","🚀 SPEED HACK",GREEN,function()
speedHackPending=true
gg.toast("Speed Hack Selected")
hideMenu()
end},
{"","👁️ WALLHACK",BLUE,function()
gg.toast("Wallhack Activated")
hideMenu()
end},
{"","🎯 AIMBOT",RED,function()
gg.toast("Aimbot Activated")
hideMenu()
end},
{"","🛡️ANTI-BAN",PURPLE,function()
gg.toast("Anti-Ban Activated")
hideMenu()
end}
}
for i,cat in ipairs(categories) do
local catButton=createCategoryButton(cat[1],cat[3],cat[2],cat[4])
if i>1 then
local params=catButton.getLayoutParams()
params.topMargin=dp(8)
catButton.setLayoutParams(params)
end
contentLayout.addView(catButton)
end
local separator=View(activity)
separator.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(1)))
separator.setBackgroundColor(Color.parseColor("#333333"))
separator.setPadding(0,dp(15),0,dp(15))
contentLayout.addView(separator)
local actionTitle=TextView(activity)
actionTitle.setText("Actions")
actionTitle.setTextColor(PRIMARY_COLOR)
actionTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP,12)
actionTitle.setTypeface(Typeface.DEFAULT_BOLD)
actionTitle.setPadding(0,dp(5),0,dp(10))
contentLayout.addView(actionTitle)
local actions={
{"","No recoil",BLUE,function()
gg.toast("No Recoil Activated")
hideMenu()
end},
{"","Esp",YELLOW,function()
gg.toast("ESP Activated")
hideMenu()
end},
{"","hide menu",GRAY,function()
hideMenu()
end},
{"","Exit script",RED,function()
closeAlt()
end}
}
for i,act in ipairs(actions) do
local actionButton=createActionButton(act[1],act[2],act[3],act[4])
if i>1 then
local params=actionButton.getLayoutParams()
params.topMargin=dp(6)
actionButton.setLayoutParams(params)
end
contentLayout.addView(actionButton)
end
return contentLayout
end

function setupMenu()
windowManager=activity.getSystemService(Context.WINDOW_SERVICE)
mainLayoutParams=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,getLayoutType(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT)
mainLayoutParams.gravity=Gravity.TOP|Gravity.LEFT
mainLayoutParams.x=dp(50)
mainLayoutParams.y=dp(100)
local mainLayout=LinearLayout(activity)
mainLayout.setLayoutParams(LinearLayout.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT))
mainLayout.setOrientation(LinearLayout.VERTICAL)
controlView=createFloatingButton()
menuView=LinearLayout(activity)
menuView.setLayoutParams(LinearLayout.LayoutParams(dp(260),WindowManager.LayoutParams.WRAP_CONTENT))
menuView.setOrientation(LinearLayout.VERTICAL)
menuView.setBackground(getShapeBackground(DARK_BG,20))
menuView.setVisibility(View.GONE)
local header=createMenuHeader()
menuView.addView(header)
local sep=View(activity)
sep.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(1)))
sep.setBackgroundColor(Color.parseColor("#333333"))
menuView.addView(sep)
local scrollView=ScrollView(activity)
scrollView.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT))
scrollView.setFillViewport(false)
scrollView.setOverScrollMode(View.OVER_SCROLL_NEVER)
contentView=createMenuContent()
scrollView.addView(contentView)
menuView.addView(scrollView)
local motionLayout=LinearLayout(activity)
motionLayout.setLayoutParams(LinearLayout.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT))
motionLayout.setOrientation(LinearLayout.VERTICAL)
motionLayout.addView(controlView)
motionLayout.addView(menuView)
mainLayout.addView(motionLayout)
floatWindow=mainLayout
controlView.setOnTouchListener(View.OnTouchListener{
onTouch=function(v,event)
local action=event.getAction()
if action==MotionEvent.ACTION_DOWN then
startX=event.getRawX()
startY=event.getRawY()
lastX=mainLayoutParams.x
lastY=mainLayoutParams.y
v.setBackground(getShapeBackground(Color.parseColor("#FF6B00"),25))
return true
elseif action==MotionEvent.ACTION_MOVE then
local dx=event.getRawX()-startX
local dy=event.getRawY()-startY
mainLayoutParams.x=lastX+dx
mainLayoutParams.y=lastY+dy
if windowManager and floatWindow then
windowManager.updateViewLayout(floatWindow,mainLayoutParams)
end
return true
elseif action==MotionEvent.ACTION_UP then
v.setBackground(getShapeBackground(PRIMARY_COLOR,25))
local dx=event.getRawX()-startX
local dy=event.getRawY()-startY
if math.abs(dx)<10 and math.abs(dy)<10 then
toggleMenu()
end
return true
end
return false
end
})
end

function toggleMenu()
if menuView then
if menuView.getVisibility()==View.GONE then
menuView.setVisibility(View.VISIBLE)
controlView.setVisibility(View.GONE)
isMenuVisible=true
else
menuView.setVisibility(View.GONE)
controlView.setVisibility(View.VISIBLE)
isMenuVisible=false
end
end
end

function showMenu()
if floatWindow==nil then
setupMenu()
end
if floatWindow~=nil and windowManager~=nil and not isMenuVisible then
activity.runOnUiThread(luajava.createProxy("java.lang.Runnable",{
run=function()
pcall(function()
windowManager.addView(floatWindow,mainLayoutParams)
toggleMenu()
end)
end
}))
end
end

function hideMenu()
if menuView and controlView then
activity.runOnUiThread(luajava.createProxy("java.lang.Runnable",{
run=function()
pcall(function()
menuView.setVisibility(View.GONE)
controlView.setVisibility(View.VISIBLE)
isMenuVisible=false
end)
end
}))
end
end

function closeAlt()
hideMenu()
if floatWindow~=nil and windowManager~=nil then
activity.runOnUiThread(luajava.createProxy("java.lang.Runnable",{
run=function()
pcall(function()
windowManager.removeView(floatWindow)
floatWindow=nil
windowManager=nil
isMenuVisible=false
shouldExit=true
end)
end
}))
else
shouldExit=true
end
gg.sleep(100)
os.exit()
end

function showFunctionMenu()
local success,err=pcall(showMenu)
if not success then
print("ERROR: "..tostring(err))
gg.toast("ERROR OPENING MENU")
end
end

while true do
if shouldExit then
break
end
if gg.isVisible(true) then
menuVisible=1
gg.setVisible(false)
gg.clearResults()
end
if speedHackPending then
speedHackPending=false
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("-0.50344371796;9.99999997e-7;-0.50291442871::9",gg.TYPE_FLOAT)
gg.refineNumber("9.99999997e-7",gg.TYPE_FLOAT)
gg.getResults(100)
gg.editAll("-1",gg.TYPE_FLOAT)
gg.clearResults()
gg.toast("SPEED HACK ACTIVATED")
end
if menuVisible==1 then
showFunctionMenu()
menuVisible=-1
end
gg.sleep(100)
end