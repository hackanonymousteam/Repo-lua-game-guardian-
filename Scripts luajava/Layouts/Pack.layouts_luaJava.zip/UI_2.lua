gg.setVisible(true)

local TypedValue = luajava.bindClass("android.util.TypedValue")
local Gravity = luajava.bindClass("android.view.Gravity")
local PixelFormat = luajava.bindClass("android.graphics.PixelFormat")
local Color = luajava.bindClass("android.graphics.Color")
local GradientDrawable = luajava.bindClass("android.graphics.drawable.GradientDrawable")
local Typeface = luajava.bindClass("android.graphics.Typeface")
local View = luajava.bindClass("android.view.View")
local MotionEvent = luajava.bindClass("android.view.MotionEvent")
local WindowManager = luajava.bindClass("android.view.WindowManager")
local Context = luajava.bindClass("android.content.Context")
local Build = luajava.bindClass("android.os.Build")
local LinearLayout = luajava.bindClass("android.widget.LinearLayout")
local TextView = luajava.bindClass("android.widget.TextView")
local Button = luajava.bindClass("android.widget.Button")
local ScrollView = luajava.bindClass("android.widget.ScrollView")
local FrameLayout = luajava.bindClass("android.widget.FrameLayout")
local RelativeLayout = luajava.bindClass("android.widget.RelativeLayout")
local ImageView = luajava.bindClass("android.widget.ImageView")
local CheckBox = luajava.bindClass("android.widget.CheckBox")
local RadioButton = luajava.bindClass("android.widget.RadioButton")
local TextClock = luajava.bindClass("android.widget.TextClock")
local SeekBar = luajava.bindClass("android.widget.SeekBar")
local AlertDialog = luajava.bindClass("android.app.AlertDialog")
local EditText = luajava.bindClass("android.widget.EditText")
local InputFilter = luajava.bindClass("android.text.InputFilter")
local InputType = luajava.bindClass("android.text.InputType")
local DigitsKeyListener = luajava.bindClass("android.text.method.DigitsKeyListener")

local PRIMARY_COLOR = Color.parseColor("#00B0FF")
local SECONDARY_COLOR = Color.parseColor("#1E1E1E")
local DARK_BG = Color.parseColor("#ff000000")
local WHITE = Color.parseColor("#FFFFFFFF")
local BLACK = Color.parseColor("#FF000000")
local RED = Color.parseColor("#F44336")
local GREEN = Color.parseColor("#4CAF50")
local BLUE = Color.parseColor("#2196F3")
local GRAY = Color.parseColor("#888888")

local function dp(value)
    return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, activity.getResources().getDisplayMetrics())
end

local function getShapeBackground(color, radius)
    local drawable = GradientDrawable()
    drawable.setShape(GradientDrawable.RECTANGLE)
    drawable.setColor(color)
    drawable.setCornerRadius(dp(radius))
    return drawable
end

local function getBorderBackground(bgColor, borderColor, borderWidth, radius)
    local drawable = GradientDrawable()
    drawable.setShape(GradientDrawable.RECTANGLE)
    drawable.setColor(bgColor)
    drawable.setStroke(dp(borderWidth), borderColor)
    drawable.setCornerRadius(dp(radius))
    return drawable
end

function getLayoutType()
    if Build.VERSION.SDK_INT >= 26 then
        return WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    else
        return WindowManager.LayoutParams.TYPE_PHONE
    end
end

local floatWindow = nil
local windowManager = nil
local mainLayoutParams = nil
local isMenuVisible = false
local lastX, lastY, startX, startY = 0, 0, 0, 0
local collapsedView = nil
local expandedView = nil
local patches = nil
local shouldExit = false
local alertDialog = nil
local editTextValue = nil

local featureList = {
    "Category_MAIN",
    "Checkbox_Speed Hack",
    "Checkbox_God Mode",
    "Checkbox_No Recoil",
    "Category_VISUAL",
    "Checkbox_Wallhack",
    "Checkbox_ESP",
    "Checkbox_Aimbot",
    "Checkbox_No Fog",
    "Category_THEME",
    "RadioButton_Dark Theme",
    "RadioButton_Light Theme",
    "RadioButton_Blue Theme",
    "RadioButton_Red Theme",
    "Category_INFO",
    "TextClock_Clock",
}

function processFeatureChange(feature, value)
    local featureName = featureList[feature + 1] or "Unknown"
    
    if featureName == "Checkbox_Speed Hack" then
        if value == 0 then
            gg.toast("⚡ Speed Hack: ENABLED")
            _speedHackPending = true
        else
            gg.toast("⚡ Speed Hack: DISABLED")
        end
    elseif featureName == "Checkbox_God Mode" then
        if value == 0 then
            gg.toast("🛡️ God Mode: ENABLED")
        else
            gg.toast("🛡️ God Mode: DISABLED")
        end
    elseif featureName == "Checkbox_No Recoil" then
        if value == 0 then
            gg.toast("🎯 No Recoil: ENABLED")
        else
            gg.toast("🎯 No Recoil: DISABLED")
        end
    elseif featureName == "Checkbox_Wallhack" then
        if value == 0 then
            gg.toast("👁️ Wallhack: ENABLED")
        else
            gg.toast("👁️ Wallhack: DISABLED")
        end
    elseif featureName == "Checkbox_ESP" then
        if value == 0 then
            gg.toast("📊 ESP: ENABLED")
        else
            gg.toast("📊 ESP: DISABLED")
        end
    elseif featureName == "Checkbox_Aimbot" then
        if value == 0 then
            gg.toast("🎯 Aimbot: ENABLED")
        else
            gg.toast("🎯 Aimbot: DISABLED")
        end
    elseif featureName == "Checkbox_No Fog" then
        if value == 0 then
            gg.toast("🌫️ No Fog: ENABLED")
        else
            gg.toast("🌫️ No Fog: DISABLED")
        end
    elseif featureName == "RadioButton_Dark Theme" then
        gg.toast("🌙 Dark Theme Selected")
    elseif featureName == "RadioButton_Light Theme" then
        gg.toast("☀️ Light Theme Selected")
    elseif featureName == "RadioButton_Blue Theme" then
        gg.toast("💙 Blue Theme Selected")
    elseif featureName == "RadioButton_Red Theme" then
        gg.toast("❤️ Red Theme Selected")
    end
end

function createCollapsedButton()
    local collapsedLayout = RelativeLayout(activity)
    collapsedLayout.setLayoutParams(RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT))
    
    local iconText = TextView(activity)
    iconText.setLayoutParams(RelativeLayout.LayoutParams(dp(50), dp(50)))
    iconText.setText("⚡")
    iconText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30)
    iconText.setTextColor(WHITE)
    iconText.setGravity(Gravity.CENTER)
    iconText.setBackground(getShapeBackground(PRIMARY_COLOR, 25))
    iconText.setAlpha(0.95)
    
    collapsedLayout.addView(iconText)
    
    return collapsedLayout, iconText
end

function createExpandedMenu()
    local expandedLayout = LinearLayout(activity)
    expandedLayout.setLayoutParams(LinearLayout.LayoutParams(dp(260), LinearLayout.LayoutParams.WRAP_CONTENT))
    expandedLayout.setOrientation(LinearLayout.VERTICAL)
    expandedLayout.setGravity(Gravity.CENTER)
    expandedLayout.setPadding(dp(5), 0, dp(5), 0)
    expandedLayout.setBackground(getShapeBackground(DARK_BG, 10))
    expandedLayout.setVisibility(View.GONE)
    
    local background = expandedLayout.getBackground()
    if background then
        background.setAlpha(250)
    end
    
    local titleView = TextView(activity)
    titleView.setText("MOD MENU")
    titleView.setTextColor(WHITE)
    titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20)
    titleView.setTypeface(Typeface.DEFAULT_BOLD)
    titleView.setPadding(dp(10), dp(25), dp(10), dp(5))
    titleView.setGravity(Gravity.CENTER)
    titleView.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    
    local subtitleView = TextView(activity)
    subtitleView.setText("v1.0")
    subtitleView.setTextColor(WHITE)
    subtitleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10)
    subtitleView.setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
    subtitleView.setPadding(dp(10), dp(5), dp(10), dp(10))
    subtitleView.setGravity(Gravity.CENTER)
    subtitleView.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    
    local scrollView = ScrollView(activity)
    scrollView.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(250)))
    
    patches = LinearLayout(activity)
    patches.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    patches.setOrientation(LinearLayout.VERTICAL)
    
    scrollView.addView(patches)
    
    local buttonPanel = RelativeLayout(activity)
    buttonPanel.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    buttonPanel.setPadding(dp(10), dp(10), dp(10), dp(10))
    
    local hideButton = Button(activity)
    hideButton.setText("HIDE")
    hideButton.setTextColor(BLACK)
    hideButton.setLayoutParams(RelativeLayout.LayoutParams(dp(100), dp(40)))
    
    local hideButtonBg = getBorderBackground(WHITE, BLACK, 3, 5)
    hideButton.setBackground(hideButtonBg)
    
    local hideParams = hideButton.getLayoutParams()
    hideButton.setLayoutParams(hideParams)
    
    hideButton.onClick = function()
        if collapsedView and expandedView then
            expandedView.setVisibility(View.GONE)
            collapsedView.setVisibility(View.VISIBLE)
        end
    end
    
    buttonPanel.addView(hideButton)
    
    expandedLayout.addView(titleView)
    expandedLayout.addView(subtitleView)
    
    local space = View(activity)
    space.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(2)))
    expandedLayout.addView(space)
    
    expandedLayout.addView(scrollView)
    expandedLayout.addView(buttonPanel)
    
    return expandedLayout
end

function addCategory(text)
    local categoryView = TextView(activity)
    categoryView.setBackgroundColor(Color.parseColor("#00000000"))
    categoryView.setText(text)
    categoryView.setGravity(Gravity.CENTER)
    categoryView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14)
    categoryView.setTextColor(WHITE)
    categoryView.setTypeface(Typeface.DEFAULT_BOLD)
    categoryView.setPadding(dp(10), dp(5), 0, dp(5))
    categoryView.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    
    patches.addView(categoryView)
end

function addCheckbox(text, featureIndex)
    local checkBox = CheckBox(activity)
    local params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    checkBox.setLayoutParams(params)
    checkBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13)
    checkBox.setTextColor(WHITE)
    checkBox.setText(text)
    
    checkBox.onClick = function()
        if checkBox.isChecked() then
            processFeatureChange(featureIndex, 0)
        else
            processFeatureChange(featureIndex, 1)
        end
    end
    
    patches.addView(checkBox)
end

function addRadioButton(text, featureIndex)
    local radioButton = RadioButton(activity)
    local params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    radioButton.setLayoutParams(params)
    radioButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13)
    radioButton.setText(text)
    
    radioButton.onClick = function()
        processFeatureChange(featureIndex, 0)
    end
    
    patches.addView(radioButton)
end

function addTextClock(text, featureIndex)
    local textClock = TextClock(activity)
    local params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    params.gravity = Gravity.CENTER
    textClock.setLayoutParams(params)
    
    textClock.setFormat12Hour("hh:mm:ss a")
    textClock.setFormat24Hour("HH:mm:ss")
    textClock.setTextColor(WHITE)
    textClock.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18)
    textClock.setBackground(getShapeBackground(BLUE, 10))
    textClock.setPadding(dp(20), dp(8), dp(20), dp(8))
    
    textClock.onClick = function()
        processFeatureChange(featureIndex, 0)
    end
    
    patches.addView(textClock)
end

function createMenuList()
    for i, feature in ipairs(featureList) do
        if feature:find("Category_") then
            addCategory(feature:gsub("Category_", ""))
        elseif feature:find("Checkbox_") then
            addCheckbox(feature:gsub("Checkbox_", ""), i-1)
        elseif feature:find("RadioButton_") then
            addRadioButton(feature:gsub("RadioButton_", ""), i-1)
        elseif feature:find("TextClock_") then
            addTextClock(feature:gsub("TextClock_", ""), i-1)
        end
    end
end

function setupFloatingMenu()
    windowManager = activity.getSystemService(Context.WINDOW_SERVICE)
    
    mainLayoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        getLayoutType(),
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    )
    mainLayoutParams.gravity = Gravity.TOP + Gravity.LEFT
    mainLayoutParams.x = dp(50)
    mainLayoutParams.y = dp(100)
    
    local rootContainer = RelativeLayout(activity)
    rootContainer.setLayoutParams(RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT))
    
    collapsedView, startimage = createCollapsedButton()
    expandedView = createExpandedMenu()
    
    createMenuList()
    
    rootContainer.addView(collapsedView)
    rootContainer.addView(expandedView)
    
    floatWindow = rootContainer
    
    local touchView = collapsedView
    touchView.setOnTouchListener(View.OnTouchListener{
        onTouch = function(v, event)
            local action = event.getAction()
            
            if action == MotionEvent.ACTION_DOWN then
                startX = event.getRawX()
                startY = event.getRawY()
                lastX = mainLayoutParams.x
                lastY = mainLayoutParams.y
                return true
                
            elseif action == MotionEvent.ACTION_MOVE then
                local dx = event.getRawX() - startX
                local dy = event.getRawY() - startY
                mainLayoutParams.x = lastX + dx
                mainLayoutParams.y = lastY + dy
                
                if windowManager and floatWindow then
                    pcall(function()
                        windowManager.updateViewLayout(floatWindow, mainLayoutParams)
                    end)
                end
                return true
                
            elseif action == MotionEvent.ACTION_UP then
                local dx = event.getRawX() - startX
                local dy = event.getRawY() - startY
                
                if math.abs(dx) < 10 and math.abs(dy) < 10 then
                    if collapsedView.getVisibility() == View.VISIBLE then
                        collapsedView.setVisibility(View.GONE)
                        expandedView.setVisibility(View.VISIBLE)
                        gg.toast("Menu opened")
                    end
                end
                return true
            end
            
            return false
        end
    })
    
    expandedView.setOnTouchListener(View.OnTouchListener{
        onTouch = function(v, event)
            local action = event.getAction()
            
            if action == MotionEvent.ACTION_DOWN then
                startX = event.getRawX()
                startY = event.getRawY()
                lastX = mainLayoutParams.x
                lastY = mainLayoutParams.y
                return true
                
            elseif action == MotionEvent.ACTION_MOVE then
                local dx = event.getRawX() - startX
                local dy = event.getRawY() - startY
                mainLayoutParams.x = lastX + dx
                mainLayoutParams.y = lastY + dy
                
                if windowManager and floatWindow then
                    pcall(function()
                        windowManager.updateViewLayout(floatWindow, mainLayoutParams)
                    end)
                end
                return true
            end
            
            return false
        end
    })
end

function showMenu()
    if floatWindow == nil then
        setupFloatingMenu()
    end
    
    if floatWindow and windowManager and not isMenuVisible then
        activity.runOnUiThread(luajava.createProxy("java.lang.Runnable", {
            run = function()
                pcall(function()
                    windowManager.addView(floatWindow, mainLayoutParams)
                    isMenuVisible = true
                    gg.toast("Menu loaded")
                end)
            end
        }))
    end
end

function hideMenu()
    if floatWindow and windowManager and isMenuVisible then
        activity.runOnUiThread(luajava.createProxy("java.lang.Runnable", {
            run = function()
                pcall(function()
                    windowManager.removeView(floatWindow)
                    isMenuVisible = false
                    gg.toast("Menu closed")
                end)
            end
        }))
    end
end

function closeMenu()
    hideMenu()
    shouldExit = true
    gg.sleep(100)
    os.exit()
end

local menuVisible = -1

while true do
    if shouldExit then
        break
    end
    
    if gg.isVisible(true) then
        menuVisible = 1
        gg.setVisible(false)
        gg.clearResults()
    end
    
    if _speedHackPending then
        _speedHackPending = false
        gg.setRanges(gg.REGION_CODE_APP)
        gg.searchNumber("-0.50344371796;9.99999997e-7;-0.50291442871::9", gg.TYPE_FLOAT)
        gg.refineNumber("9.99999997e-7", gg.TYPE_FLOAT)
        gg.getResults(100)
        gg.editAll("-1", gg.TYPE_FLOAT)
        gg.clearResults()
        gg.toast("⚡ SPEED HACK ACTIVATED")
    end
    
    if menuVisible == 1 then
        showMenu()
        menuVisible = -1
    end
    
    gg.sleep(100)
end