
gg.setVisible(false)
local ActivityManager = luajava.bindClass("android.app.ActivityManager")
local AlertDialog = luajava.bindClass("android.app.AlertDialog")
local BitmapFactory = luajava.bindClass("android.graphics.BitmapFactory")
local Canvas = luajava.bindClass("android.graphics.Canvas")
local Color = luajava.bindClass("android.graphics.Color")
local ColorStateList = luajava.bindClass("android.content.res.ColorStateList")
local Context = luajava.bindClass("android.content.Context")
local DigitsKeyListener = luajava.bindClass("android.text.method.DigitsKeyListener")
local GradientDrawable = luajava.bindClass("android.graphics.drawable.GradientDrawable")
local Gravity = luajava.bindClass("android.view.Gravity")
local Html = luajava.bindClass("android.text.Html")
local MotionEvent = luajava.bindClass("android.view.MotionEvent")
local Paint = luajava.bindClass("android.graphics.Paint")
local PixelFormat = luajava.bindClass("android.graphics.PixelFormat")
local PorterDuff = luajava.bindClass("android.graphics.PorterDuff")
local RelativeLayout = luajava.bindClass("android.widget.RelativeLayout")
local RippleDrawable = luajava.bindClass("android.graphics.drawable.RippleDrawable")
local RunningAppProcessInfo = luajava.bindClass("android.app.ActivityManager$RunningAppProcessInfo")
local Typeface = luajava.bindClass("android.graphics.Typeface")
local TypedValue = luajava.bindClass("android.util.TypedValue")
local View = luajava.bindClass("android.view.View")
local ViewGroup = luajava.bindClass("android.view.ViewGroup")
local WindowManager = luajava.bindClass("android.view.WindowManager")
local Build = luajava.bindClass("android.os.Build")
local Handler = luajava.bindClass("android.os.Handler")
local Looper = luajava.bindClass("android.os.Looper")

local Button = luajava.bindClass("android.widget.Button")
local CheckBox = luajava.bindClass("android.widget.CheckBox")
local LinearLayout = luajava.bindClass("android.widget.LinearLayout")
local ScrollView = luajava.bindClass("android.widget.ScrollView")
local TextView = luajava.bindClass("android.widget.TextView")
local Toast = luajava.bindClass("android.widget.Toast")

local PRIMARY_COLOR = Color.parseColor("#FFD600FF")
local WHITE = Color.parseColor("#FFFFFF")
local BLACK = Color.parseColor("#000000")
local RED = Color.parseColor("#FF0000")
local GREEN = Color.parseColor("#4CAF50")
local BLUE = Color.parseColor("#2196F3")
local YELLOW = Color.parseColor("#FFFF9800")
local GRAY = Color.parseColor("#666666")
local CYAN = Color.parseColor("#00BCD4")

local mWindowManager = nil
local mFloatingView = nil
local mRootContainer = nil
local mCollapsed = nil
local mExpanded = nil
local params = nil
local menuContainer = nil
local lastX, lastY, startX, startY = 0, 0, 0, 0
local shouldExit = false
local menuInitialized = false

local function dp(value)
    return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, activity.getResources().getDisplayMetrics())
end

local function getLayoutType()
    if Build.VERSION.SDK_INT >= 26 then
        return 2038
    elseif Build.VERSION.SDK_INT >= 24 then
        return 2002
    else
        return 2003
    end
end

local function getShapeBackground(color, radius, strokeColor, strokeWidth)
    local drawable = GradientDrawable()
    drawable.setShape(GradientDrawable.RECTANGLE)
    drawable.setColor(color)
    drawable.setCornerRadius(dp(radius or 5))
    if strokeColor and strokeWidth then
        drawable.setStroke(dp(strokeWidth), strokeColor)
    end
    return drawable
end

local function Title()
    return "BATMAN"
end

local function IconSize()
    return 50
end

local function addCheckBox(feature, callback)
    local checkBox = CheckBox(activity)
    checkBox.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    checkBox.setText(Html.fromHtml("<font color='WHITE'><b>" .. feature .. "</b></font>"))
    checkBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14)
    checkBox.setTextColor(WHITE)
    checkBox.setPadding(dp(20), dp(10), dp(20), dp(10))
    
    if Build.VERSION.SDK_INT >= 21 then
        checkBox.setButtonTintList(ColorStateList.valueOf(WHITE))
    end
    
    checkBox.setOnCheckedChangeListener(function(buttonView, isChecked)
        callback(isChecked)
    end)
    
    menuContainer.addView(checkBox)
end

local function addButton(feature, callback)
    local button = Button(activity)
    button.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(45)))
    button.setText(feature)
    button.setTextColor(WHITE)
    button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14)
    button.setAllCaps(false)
    
    local gradient = GradientDrawable()
    gradient.setShape(GradientDrawable.RECTANGLE)
    gradient.setColor(BLACK)
    gradient.setStroke(dp(2), CYAN)
    gradient.setCornerRadius(dp(8))
    
    if Build.VERSION.SDK_INT >= 21 then
        local ripple = RippleDrawable(ColorStateList.valueOf(WHITE), gradient, nil)
        button.setBackground(ripple)
    else
        button.setBackground(gradient)
    end
    
    button.setOnClickListener(function()
        callback()
        button.setText(feature .. " ✓")
        button.postDelayed(function()
            button.setText(feature)
        end, 1000)
    end)
    
    menuContainer.addView(button)
end

local function createMenu()
    mWindowManager = activity.getSystemService(Context.WINDOW_SERVICE)
    
    params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        getLayoutType(),
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    )
    params.gravity = Gravity.TOP + Gravity.LEFT
    params.x = dp(50)
    params.y = dp(100)
    
    mRootContainer = RelativeLayout(activity)
    mRootContainer.setLayoutParams(RelativeLayout.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT))
    
    mCollapsed = RelativeLayout(activity)
    mCollapsed.setLayoutParams(RelativeLayout.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT))
    mCollapsed.setVisibility(View.VISIBLE)
    
    local iconView = TextView(activity)
    iconView.setLayoutParams(RelativeLayout.LayoutParams(dp(IconSize()), dp(IconSize())))
    iconView.setText("⚡")
    iconView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30)
    iconView.setTextColor(WHITE)
    iconView.setGravity(Gravity.CENTER)
    iconView.setBackground(getShapeBackground(PRIMARY_COLOR, 25))
    iconView.setClickable(true)
    
    iconView.setOnClickListener(function()
        if mCollapsed.getVisibility() == View.VISIBLE then
            mCollapsed.setVisibility(View.GONE)
            mExpanded.setVisibility(View.VISIBLE)
        end
    end)
    
    mCollapsed.addView(iconView)
    
    mExpanded = LinearLayout(activity)
    mExpanded.setLayoutParams(LinearLayout.LayoutParams(dp(250), dp(400)))
    mExpanded.setOrientation(LinearLayout.VERTICAL)
    mExpanded.setBackground(getShapeBackground(BLACK, 15))
    mExpanded.setAlpha(0.95)
    mExpanded.setVisibility(View.GONE)
    
    local headerLayout = LinearLayout(activity)
    headerLayout.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(50)))
    headerLayout.setOrientation(LinearLayout.HORIZONTAL)
    headerLayout.setGravity(Gravity.CENTER_VERTICAL)
    headerLayout.setPadding(dp(15), dp(10), dp(15), dp(10))
    headerLayout.setBackground(getShapeBackground(PRIMARY_COLOR, 15))
    
    local titleText = TextView(activity)
    titleText.setLayoutParams(LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1))
    titleText.setText(Title())
    titleText.setTextColor(WHITE)
    titleText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16)
    titleText.setTypeface(Typeface.DEFAULT_BOLD)
    titleText.setGravity(Gravity.CENTER)
    
    local closeBtn = TextView(activity)
    closeBtn.setLayoutParams(LinearLayout.LayoutParams(dp(30), dp(30)))
    closeBtn.setText("✕")
    closeBtn.setTextColor(WHITE)
    closeBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16)
    closeBtn.setGravity(Gravity.CENTER)
    closeBtn.setBackground(getShapeBackground(Color.parseColor("#33FFFFFF"), 15))
    closeBtn.setOnClickListener(function()
        mCollapsed.setVisibility(View.VISIBLE)
        mExpanded.setVisibility(View.GONE)
    end)
    
    headerLayout.addView(titleText)
    headerLayout.addView(closeBtn)
    mExpanded.addView(headerLayout)
    
    local scrollView = ScrollView(activity)
    scrollView.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT))
    scrollView.setFillViewport(true)
    
    menuContainer = LinearLayout(activity)
    menuContainer.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    menuContainer.setOrientation(LinearLayout.VERTICAL)
    menuContainer.setPadding(dp(10), dp(10), dp(10), dp(10))
    
    addCheckBox("Aimbot", function(val)
        if val then
        _aimbot = true
            gg.toast("✓ AIMBOT on")
            
        else
            gg.toast("✗ AIMBOT off")
        end
    end)
    
    addCheckBox("Wallhack", function(val)
        if val then
            gg.toast("✓ WALLHACK on")
        else
            gg.toast("✗ WALLHACK off")
        end
    end)
    
    addCheckBox("No Recoil", function(val)
        if val then
            gg.toast("✓ NO RECOIL on")
        else
            gg.toast("✗ NO RECOIL off")
        end
    end)
    
    addCheckBox("ESP", function(val)
        if val then
            gg.toast("✓ ESP on")
        else
            gg.toast("✗ ESP off")
        end
    end)
    
    addCheckBox("Magic Bullet", function(val)
        if val then
            gg.toast("✓ MAGIC BULLET on")
        else
            gg.toast("✗ MAGIC BULLET off")
        end
    end)
    
    addCheckBox("Anti Ban", function(val)
        if val then
            gg.toast("✓ ANTI BAN on")
        else
            gg.toast("✗ ANTI BAN off")
        end
    end)
    
    addCheckBox("Box ESP", function(val)
        if val then
            gg.toast("✓ BOX ESP on")
        else
            gg.toast("✗ BOX ESP off")
        end
    end)
    
    addCheckBox("Line ESP", function(val)
        if val then
            gg.toast("✓ LINE ESP on")
        else
            gg.toast("✗ LINE ESP off")
        end
    end)
    
    addCheckBox("Distance ESP", function(val)
        if val then
            gg.toast("✓ DISTANCE ESP on")
        else
            gg.toast("✗ DISTANCE ESP off")
        end
    end)
    
    addCheckBox("Health ESP", function(val)
        if val then
            gg.toast("✓ HEALTH ESP on")
        else
            gg.toast("✗ HEALTH ESP off")
        end
    end)
    
    addCheckBox("God Mode", function(val)
        if val then
            gg.toast("✓ GOD MODE on")
        else
            gg.toast("✗ GOD MODE off")
        end
    end)
    
    addCheckBox("Unlimited Ammo", function(val)
        if val then
            gg.toast("✓   on")
        else
            gg.toast("✗   off")
        end
    end)
    
    addCheckBox("No Spread", function(val)
        if val then
            gg.toast("✓ NO SPREAD on")
        else
            gg.toast("✗ NO SPREAD off")
        end
    end)
    
    addCheckBox("Rapid Fire", function(val)
        if val then
            gg.toast("✓ RAPID FIRE on")
        else
            gg.toast("✗ RAPID FIRE off")
        end
    end)
    
    addCheckBox("No Grass", function(val)
        if val then
            gg.toast("✓ NO GRASS on")
        else
            gg.toast("✗ NO GRASS off")
        end
    end)
    
    addButton("Kill All", function()
        gg.toast("💀 KILL ALL done")
    end)
    
    addButton("EXIT", function()
            shouldExit = true
            
    end)
    
    scrollView.addView(menuContainer)
    mExpanded.addView(scrollView)
    
    mRootContainer.addView(mCollapsed)
    mRootContainer.addView(mExpanded)
    
    mRootContainer.setOnTouchListener({
        onTouch = function(v, event)
            local action = event.getAction()
            
            if action == MotionEvent.ACTION_DOWN then
                startX = event.getRawX()
                startY = event.getRawY()
                lastX = params.x
                lastY = params.y
                return true
                
            elseif action == MotionEvent.ACTION_MOVE then
                local dx = event.getRawX() - startX
                local dy = event.getRawY() - startY
                params.x = lastX + dx
                params.y = lastY + dy
                mWindowManager.updateViewLayout(mFloatingView, params)
                return true
            end
            return false
        end
    })
    
    mFloatingView = mRootContainer
    mWindowManager.addView(mFloatingView, params)
end

local function initializeMenu()
    if menuInitialized then
        if mFloatingView and mCollapsed then
            activity.runOnUiThread(luajava.createProxy("java.lang.Runnable", {
                run = function()
                    mCollapsed.setVisibility(View.VISIBLE)
                    mExpanded.setVisibility(View.GONE)
                end
            }))
        end
        return
    end
    
    activity.runOnUiThread(luajava.createProxy("java.lang.Runnable", {
        run = function()
            local success, err = pcall(function()
                createMenu()
                menuInitialized = true

            end)
            
            if not success then
                print("ERROR: " .. tostring(err))
            end
        end
    }))
end

local function closeMenu()
    if mFloatingView and mWindowManager then
        activity.runOnUiThread(luajava.createProxy("java.lang.Runnable", {
            run = function()
                pcall(function()
                    mWindowManager.removeView(mFloatingView)
                    mFloatingView = nil
                    mWindowManager = nil
                    menuInitialized = false
                end)
            end
        }))
    end
end

if not menuInitialized then
    initializeMenu()
end

while not shouldExit do
  if _aimbot then
    _aimbot = false
    gg.setVisible(false)
    gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("-0.50344371796;9.99999997e-7;-0.50291442871::9", gg.TYPE_FLOAT)
    gg.refineNumber("9.99999997e-7", gg.TYPE_FLOAT)
    gg.getResults(100)
    gg.editAll("-1", gg.TYPE_FLOAT)
    gg.clearResults()
    gg.toast("⚡ SPEED HACK ACTIVATED")
  end
    gg.sleep(100)
end

  
if shouldExit then
    closeMenu()
    os.exit()
    
end

