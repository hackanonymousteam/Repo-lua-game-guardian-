gg.setVisible(false)

local TypedValue = luajava.bindClass("android.util.TypedValue")
local Gravity = luajava.bindClass("android.view.Gravity")
local PixelFormat = luajava.bindClass("android.graphics.PixelFormat")
local Color = luajava.bindClass("android.graphics.Color")
local GradientDrawable = luajava.bindClass("android.graphics.drawable.GradientDrawable")
local Typeface = luajava.bindClass("android.graphics.Typeface")
local View = luajava.bindClass("android.view.View")
local MotionEvent = luajava.bindClass("android.view.MotionEvent")
local WindowManager = luajava.bindClass("android.view.WindowManager")
local Context = luajava.bindClass("android.content.Context")
local Build = luajava.bindClass("android.os.Build")
local LinearLayout = luajava.bindClass("android.widget.LinearLayout")
local TextView = luajava.bindClass("android.widget.TextView")
local Button = luajava.bindClass("android.widget.Button")
local ScrollView = luajava.bindClass("android.widget.ScrollView")
local FrameLayout = luajava.bindClass("android.widget.FrameLayout")
local RelativeLayout = luajava.bindClass("android.widget.RelativeLayout")
local Switch = luajava.bindClass("android.widget.Switch")
local SeekBar = luajava.bindClass("android.widget.SeekBar")

local RED = Color.parseColor("#FF0000")
local WHITE = Color.parseColor("#FFFFFF")
local BLACK = Color.parseColor("#000000")
local GRAY = Color.parseColor("#1C1C1C")
local MENU_BG = Color.parseColor("#353E45")
local DARK_GRAY = Color.parseColor("#212121")
local GREEN = Color.parseColor("#00FF00")
local ORANGE = Color.parseColor("#FFA500")
local BLUE = Color.parseColor("#0000FF")
local YELLOW = Color.parseColor("#FFFF00")
local PURPLE = Color.parseColor("#800080")
local CYAN = Color.parseColor("#00FFFF")

local mWindowManager = nil
local mFloatingView = nil
local params = nil
local mCollapsed = nil
local mExpanded = nil
local patches = nil
local lastX, lastY, startX, startY = 0, 0, 0, 0
local menuCriado = false

local function dp(value)
    return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, activity.getResources().getDisplayMetrics())
end

local function createRoundedBackground(color, radius)
    local drawable = GradientDrawable()
    drawable.setShape(GradientDrawable.RECTANGLE)
    drawable.setColor(color)
    drawable.setCornerRadius(dp(radius))
    return drawable
end

local function createBorderedBackground(color, radius, borderColor, borderWidth)
    local drawable = GradientDrawable()
    drawable.setShape(GradientDrawable.RECTANGLE)
    drawable.setColor(color)
    drawable.setCornerRadius(dp(radius))
    drawable.setStroke(dp(borderWidth), borderColor)
    return drawable
end

local function getLayoutType()
    if Build.VERSION.SDK_INT >= 26 then
        return WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    else
        return WindowManager.LayoutParams.TYPE_PHONE
    end
end

function addSwitch(text, layout, toastMessage)
    local switchView = Switch(activity)
    switchView.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(45)))
    switchView.setText(text)
    switchView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14)
    switchView.setTextColor(WHITE)
    switchView.setPadding(dp(10), dp(5), dp(10), dp(5))
    switchView.setBackground(createBorderedBackground(Color.TRANSPARENT, 0, Color.parseColor("#66FFFFFF"), 1))
    
    switchView.setOnCheckedChangeListener(luajava.createProxy("android.widget.CompoundButton$OnCheckedChangeListener", {
        onCheckedChanged = function(buttonView, isChecked)
            if isChecked then
                buttonView.getTrackDrawable().setColorFilter(RED, android.graphics.PorterDuff.Mode.SRC_IN)
                buttonView.getThumbDrawable().setColorFilter(RED, android.graphics.PorterDuff.Mode.SRC_IN)
                gg.toast(toastMessage .. " ACTIVATED")
            else
                buttonView.getTrackDrawable().setColorFilter(WHITE, android.graphics.PorterDuff.Mode.SRC_IN)
                buttonView.getThumbDrawable().setColorFilter(WHITE, android.graphics.PorterDuff.Mode.SRC_IN)
                gg.toast(toastMessage .. " DEACTIVATED")
            end
        end
    }))
    
    layout.addView(switchView)
end

function addSeekBar(text, max, layout, toastPrefix)
    local container = LinearLayout(activity)
    container.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    container.setOrientation(LinearLayout.VERTICAL)
    container.setPadding(dp(10), dp(5), dp(10), dp(5))
    
    local label = TextView(activity)
    label.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    label.setText(text .. ": 0")
    label.setTextColor(WHITE)
    label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14)
    
    local seekBar = SeekBar(activity)
    seekBar.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    seekBar.setMax(max)
    seekBar.setProgress(0)
    seekBar.setPadding(dp(5), dp(10), dp(5), dp(10))
    
    local thumbDrawable = GradientDrawable()
    thumbDrawable.setShape(GradientDrawable.OVAL)
    thumbDrawable.setColor(BLACK)
    thumbDrawable.setStroke(dp(2), RED)
    thumbDrawable.setSize(dp(20), dp(20))
    seekBar.setThumb(thumbDrawable)
    
    seekBar.setOnSeekBarChangeListener(luajava.createProxy("android.widget.SeekBar$OnSeekBarChangeListener", {
        onProgressChanged = function(sb, progress, fromUser)
            label.setText(text .. ": " .. progress)
        end,
        onStartTrackingTouch = function(sb) end,
        onStopTrackingTouch = function(sb) 
            gg.toast(toastPrefix .. " set to: " .. sb.getProgress())
        end
    }))
    
    container.addView(label)
    container.addView(seekBar)
    layout.addView(container)
end

function addButtonHide(text, layout, toastMessage, color)
    local btn = Button(activity)
    btn.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(40)))
    btn.setText(text)
    btn.setTextColor(WHITE)
    btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14)
    btn.setBackground(createRoundedBackground(color, 5))
    btn.setPadding(dp(10), dp(5), dp(10), dp(5))
    
    btn.onClick = function()
        gg.toast(toastMessage)
        
mCollapsed.setVisibility(View.VISIBLE)
        mExpanded.setVisibility(View.GONE)
        
    end
    
    layout.addView(btn)
end

function addButtonExit(text, layout, toastMessage, color)
    local btn = Button(activity)
    btn.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(40)))
    btn.setText(text)
    btn.setTextColor(WHITE)
    btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14)
    btn.setBackground(createRoundedBackground(color, 5))
    btn.setPadding(dp(10), dp(5), dp(10), dp(5))
    
    btn.onClick = function()
        gg.toast(toastMessage)
        
if mWindowManager and mFloatingView then
                mWindowManager.removeView(mFloatingView)
        end
        
    end
    
    layout.addView(btn)
end


function addCategory(text, layout, color)
    local category = TextView(activity)
    category.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(35)))
    category.setText(text)
    category.setTextColor(color or RED)
    category.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15)
    category.setTypeface(Typeface.DEFAULT_BOLD)
    category.setGravity(Gravity.CENTER)
    category.setBackground(createRoundedBackground(DARK_GRAY, 5))
    
    local params = category.getLayoutParams()
    params.topMargin = dp(10)
    params.bottomMargin = dp(5)
    category.setLayoutParams(params)
    
    layout.addView(category)
end

function addInfo(text, layout, color)
    local info = TextView(activity)
    info.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    info.setText(text)
    info.setTextColor(color or WHITE)
    info.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12)
    info.setGravity(Gravity.CENTER)
    info.setPadding(dp(5), dp(2), dp(5), dp(2))
    layout.addView(info)
end

function criarMenu()
    local rootLayout = FrameLayout(activity)
    rootLayout.setLayoutParams(FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT))
    
    mCollapsed = RelativeLayout(activity)
    mCollapsed.setLayoutParams(RelativeLayout.LayoutParams(dp(55), dp(55)))
    
    local icon = TextView(activity)
    icon.setLayoutParams(RelativeLayout.LayoutParams(dp(50), dp(50)))
    icon.setText("⚡")
    icon.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30)
    icon.setTextColor(WHITE)
    icon.setGravity(Gravity.CENTER)
    icon.setBackground(createRoundedBackground(RED, 25))
    icon.setAlpha(0.8)
    mCollapsed.addView(icon)
    
    mExpanded = LinearLayout(activity)
    mExpanded.setLayoutParams(LinearLayout.LayoutParams(dp(280), dp(450)))
    mExpanded.setOrientation(LinearLayout.VERTICAL)
    mExpanded.setBackground(createRoundedBackground(MENU_BG, 10))
    mExpanded.setVisibility(View.GONE)
    
    local title = TextView(activity)
    title.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(40)))
    title.setText("⚡ BATMAN MENU ⚡")
    title.setTextColor(WHITE)
    title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18)
    title.setTypeface(Typeface.DEFAULT_BOLD)
    title.setGravity(Gravity.CENTER)
    title.setBackground(createRoundedBackground(RED, 10))
    
    local infoLayout = LinearLayout(activity)
    infoLayout.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    infoLayout.setOrientation(LinearLayout.VERTICAL)
    infoLayout.setPadding(dp(10), dp(5), dp(10), dp(5))
    
    addInfo("User: admin | Pass: 1234", infoLayout, CYAN)
    addInfo("Device: " .. Build.MODEL, infoLayout, ORANGE)
    addInfo("Telegram: @batmangamesS", infoLayout, GREEN)
    
    local separator1 = View(activity)
    separator1.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(2)))
    separator1.setBackgroundColor(GRAY)
    
    local scrollView = ScrollView(activity)
    scrollView.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(300)))
    scrollView.setBackground(createBorderedBackground(Color.TRANSPARENT, 0, WHITE, 1))
    
    patches = LinearLayout(activity)
    patches.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    patches.setOrientation(LinearLayout.VERTICAL)
    patches.setPadding(dp(5), dp(5), dp(5), dp(5))
    
    addCategory("SPEED HACKS", patches, RED)
    addSwitch("Speed Boost 1.5x", patches, "Speed Boost 1.5x")
    addSwitch("Speed Boost 2.0x", patches, "Speed Boost 2.0x")
    addSwitch("Super Speed 3.0x", patches, "Super Speed 3.0x")
    addSeekBar("Speed Value", 300, patches, "Speed")
    
    addCategory("WALLHACKS", patches, BLUE)
    addSwitch("Basic Wallhack", patches, "Basic Wallhack")
    addSwitch("Advanced Wallhack", patches, "Advanced Wallhack")
    addSwitch("Full Brightness", patches, "Full Brightness")
    addSwitch("X-Ray Vision", patches, "X-Ray Vision")
    
    addCategory("AIMBOT", patches, GREEN)
    addSwitch("Aimbot Head", patches, "Aimbot Head")
    addSwitch("Aimbot Body", patches, "Aimbot Body")
    addSwitch("Auto Fire", patches, "Auto Fire")
    addSwitch("No Recoil", patches, "No Recoil")
    addSeekBar("Aim Distance", 500, patches, "Aim Distance")
    addSeekBar("Smoothness", 100, patches, "Smoothness")
    
    addCategory("VISUAL", patches, YELLOW)
    addSwitch("ESP Box", patches, "ESP Box")
    addSwitch("ESP Line", patches, "ESP Line")
    addSwitch("ESP Name", patches, "ESP Name")
    addSwitch("ESP Distance", patches, "ESP Distance")
    addSwitch("Radar Hack", patches, "Radar Hack")
    
    addCategory("MEMORY", patches, PURPLE)
    addSwitch("God Mode", patches, "God Mode")
    addSwitch("Infinite Ammo", patches, "Infinite Ammo")
    addSwitch("No Reload", patches, "No Reload")
    addSwitch("Rapid Fire", patches, "Rapid Fire")
    addSeekBar("Damage Multiplier", 100, patches, "Damage")
    addSeekBar("Magic Bullet", 100, patches, "Magic Bullet")
    
    addCategory("MISC", patches, ORANGE)
    addSwitch("Anti Ban", patches, "Anti Ban")
    addSwitch("Bypass", patches, "Bypass")
    addSwitch("Unlock All", patches, "Unlock All")
    addButtonHide("HIDE", patches, "Memory cleaned successfully!", BLUE)
    addButtonExit("EXIT", patches, "Memory dumped!", PURPLE)
    
    scrollView.addView(patches)
    
    local separator2 = View(activity)
    separator2.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(2)))
    separator2.setBackgroundColor(GRAY)
    


    mExpanded.addView(title)
    mExpanded.addView(infoLayout)
    mExpanded.addView(separator1)
    mExpanded.addView(scrollView)

    rootLayout.addView(mCollapsed)
    rootLayout.addView(mExpanded)
    
    return rootLayout
end

local function createTouchListener()
    return luajava.createProxy("android.view.View$OnTouchListener", {
        onTouch = function(v, event)
            local action = event.getAction()
            
            if action == MotionEvent.ACTION_DOWN then
                startX = event.getRawX()
                startY = event.getRawY()
                lastX = params.x
                lastY = params.y
                return true
                
            elseif action == MotionEvent.ACTION_MOVE then
                local dx = event.getRawX() - startX
                local dy = event.getRawY() - startY
                params.x = lastX + dx
                params.y = lastY + dy
                
                if mWindowManager and mFloatingView then
                    pcall(function()
                        mWindowManager.updateViewLayout(mFloatingView, params)
                    end)
                end
                return true
                
            elseif action == MotionEvent.ACTION_UP then
                local dx = event.getRawX() - startX
                local dy = event.getRawY() - startY
                
                if math.abs(dx) < 10 and math.abs(dy) < 10 and mCollapsed and mCollapsed.getVisibility() == View.VISIBLE then
                    mCollapsed.setVisibility(View.GONE)
                    mExpanded.setVisibility(View.VISIBLE)
                end
                return true
            end
            
            return false
        end
    })
end

function mostrarMenu()
    if not menuCriado then
        mWindowManager = activity.getSystemService(Context.WINDOW_SERVICE)
        
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            getLayoutType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP | Gravity.LEFT
        params.x = dp(50)
        params.y = dp(150)
        
        mFloatingView = criarMenu()
        mFloatingView.setOnTouchListener(createTouchListener())
        
        local success, err = pcall(function()
            mWindowManager.addView(mFloatingView, params)
        end)
        
        if success then
            menuCriado = true
            gg.toast(" Menu loaded successfully!")
        else
            gg.toast("Error loading menu: " .. tostring(err))
        end
    else
        gg.toast("Menu is already visible!")
    end
end

gg.sleep(500)
--mostrarMenu()

activity.runOnUiThread(luajava.createProxy("java.lang.Runnable", {
            run = function()
                mostrarMenu()
            end
        }))

