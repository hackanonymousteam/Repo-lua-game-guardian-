gg.setVisible(false)

local AlertDialog = luajava.bindClass("android.app.AlertDialog")
local Color = luajava.bindClass("android.graphics.Color")
local Gravity = luajava.bindClass("android.view.Gravity")
local Html = luajava.bindClass("android.text.Html")
local MotionEvent = luajava.bindClass("android.view.MotionEvent")
local PixelFormat = luajava.bindClass("android.graphics.PixelFormat")
local RelativeLayout = luajava.bindClass("android.widget.RelativeLayout")
local TypedValue = luajava.bindClass("android.util.TypedValue")
local View = luajava.bindClass("android.view.View")
local WindowManager = luajava.bindClass("android.view.WindowManager")
local Build = luajava.bindClass("android.os.Build")

local Button = luajava.bindClass("android.widget.Button")
local EditText = luajava.bindClass("android.widget.EditText")
local LinearLayout = luajava.bindClass("android.widget.LinearLayout")
local ScrollView = luajava.bindClass("android.widget.ScrollView")
local Switch = luajava.bindClass("android.widget.Switch")
local TextView = luajava.bindClass("android.widget.TextView")
local Toast = luajava.bindClass("android.widget.Toast")

local COR_FUNDO = Color.parseColor("#FF1C2A35")
local COR_TEXTO = Color.parseColor("#FFDEEDF6")
local COR_DESTAQUE = Color.parseColor("#FF00BCD4")
local COR_VERDE = Color.parseColor("#FF4CAF50")
local COR_VERMELHO = Color.parseColor("#FFFF0000")

local mWindowManager, mFloatingView, mCollapsed, mExpanded, patches
local params, startX, startY, lastX, lastY
local shouldExit = false
local menuCriado = false

function dp(valor)
    return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, valor, activity.getResources().getDisplayMetrics())
end

function getLayoutType()
    if Build.VERSION.SDK_INT >= 26 then return 2038
    elseif Build.VERSION.SDK_INT >= 24 then return 2002
    else return 2003 end
end

function criarBackground(cor, raio)
    local drawable = luajava.newInstance("android.graphics.drawable.GradientDrawable")
    drawable.setShape(0)
    drawable.setColor(cor)
    drawable.setCornerRadius(dp(raio or 8))
    drawable.setStroke(dp(2), COR_DESTAQUE)
    return drawable
end

function addCategoria(texto)
    local tv = TextView(activity)
    tv.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(35)))
    tv.setBackgroundColor(Color.parseColor("#FFe90909"))
    tv.setText(" " .. texto)
    tv.setTextColor(Color.WHITE)
    tv.setGravity(Gravity.CENTER_VERTICAL)
    tv.setTypeface(luajava.bindClass("android.graphics.Typeface").DEFAULT_BOLD)
    patches.addView(tv)
end

function addSwitch(texto, callback)
    local sw = Switch(activity)
    sw.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    sw.setText("  " .. texto)
    sw.setTextColor(COR_TEXTO)
    sw.setPadding(dp(10), dp(5), dp(10), dp(5))
    sw.setOnCheckedChangeListener(function(_, isChecked)
        callback(isChecked)
        Toast.makeText(activity, texto .. (isChecked and " ON" or " OFF"), 0):show()
    end)
    patches.addView(sw)
end

function addBotao(texto, callback)
    local btn = Button(activity)
    btn.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(45)))
    btn.setText(texto)
    btn.setTextColor(Color.WHITE)
    btn.setBackground(criarBackground(Color.parseColor("#FF1C262D"), 8))
    btn.setOnClickListener(function()
        callback()
        Toast.makeText(activity, "⚡ " .. texto, 0):show()
    end)
    patches.addView(btn)
end

function addBotaoOnOff(texto, callback)
    local btn = Button(activity)
    btn.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(45)))
    btn.setText(texto .. ": OFF")
    btn.setTextColor(Color.WHITE)
    btn.setBackground(criarBackground(COR_VERMELHO, 8))
    
    local estado = false
    btn.setOnClickListener(function()
        estado = not estado
        if estado then
            btn.setText(texto .. ": ON")
            btn.setBackground(criarBackground(COR_VERDE, 8))
        else
            btn.setText(texto .. ": OFF")
            btn.setBackground(criarBackground(COR_VERMELHO, 8))
        end
        callback(estado)
        Toast.makeText(activity, texto .. (estado and " ON" or " OFF"), 0):show()
    end)
    patches.addView(btn)
end

function criarMenu()
    mWindowManager = activity.getSystemService("window")
    
    params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        getLayoutType(),
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    )
    params.gravity = Gravity.TOP + Gravity.LEFT
    params.x = dp(50)
    params.y = dp(100)
    
    local root = RelativeLayout(activity)
    root.setLayoutParams(RelativeLayout.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT))
    
    mCollapsed = RelativeLayout(activity)
    mCollapsed.setLayoutParams(RelativeLayout.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT))
    mCollapsed.setVisibility(View.VISIBLE)
    
    local icone = TextView(activity)
    icone.setLayoutParams(RelativeLayout.LayoutParams(dp(45), dp(45)))
    icone.setText("⚡")
    icone.setTextSize(24)
    icone.setTextColor(Color.WHITE)
    icone.setGravity(Gravity.CENTER)
    icone.setBackground(criarBackground(COR_FUNDO, 25))
    icone.setOnClickListener(function()
        mCollapsed.setVisibility(View.GONE)
        mExpanded.setVisibility(View.VISIBLE)
    end)
    mCollapsed.addView(icone)
    
    mExpanded = LinearLayout(activity)
    mExpanded.setLayoutParams(LinearLayout.LayoutParams(dp(260), dp(400)))
    mExpanded.setOrientation(LinearLayout.VERTICAL)
    mExpanded.setBackground(criarBackground(COR_FUNDO, 10))
    mExpanded.setVisibility(View.GONE)
    
    local header = LinearLayout(activity)
    header.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(45)))
    header.setOrientation(LinearLayout.HORIZONTAL)
    header.setGravity(Gravity.CENTER_VERTICAL)
    header.setBackgroundColor(Color.BLACK)
    
    local titulo = TextView(activity)
    titulo.setLayoutParams(LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1))
    titulo.setText("⚡ MOD MENU")
    titulo.setTextColor(Color.WHITE)
    titulo.setTextSize(16)
    titulo.setGravity(Gravity.CENTER)
    titulo.setTypeface(luajava.bindClass("android.graphics.Typeface").DEFAULT_BOLD)
    
    local fechar = TextView(activity)
    fechar.setLayoutParams(LinearLayout.LayoutParams(dp(40), dp(40)))
    fechar.setText("✕")
    fechar.setTextColor(Color.WHITE)
    fechar.setTextSize(18)
    fechar.setGravity(Gravity.CENTER)
    fechar.setOnClickListener(function()
        mCollapsed.setVisibility(View.VISIBLE)
        mExpanded.setVisibility(View.GONE)
    end)
    
    header.addView(titulo)
    header.addView(fechar)
    mExpanded.addView(header)
    
    local scroll = ScrollView(activity)
    scroll.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT))
    
    patches = LinearLayout(activity)
    patches.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    patches.setOrientation(LinearLayout.VERTICAL)
    patches.setPadding(dp(5), dp(5), dp(5), dp(5))
    
    addCategoria("🎯 AIMBOT")
    addSwitch("Aimbot",  function(val) _aimbot = true end)
    addBotao("Aimbot Config", function() end)
    
    addCategoria("👁️ VISUAL")
    addSwitch("Wallhack", function(val) end)
    addSwitch("No Grass", function(val) end)
    
    addCategoria("💥 WEAPON")
    addSwitch("No Recoil", function(val) end)
    addSwitch("Magic Bullet", function(val) end)
    addBotaoOnOff("Rapid Fire", function(val) end)
    
    addCategoria("🛡️ DEFESA")
    addSwitch("God Mode", function(val) end)
    addSwitch("Anti Ban", function(val) end)
    
    addCategoria("⚙️ MISC")
    addBotao("Kill All", function() 
        Toast.makeText(activity, "💀 KILL ALL", 0):show()
    end)
    addBotao("EXIT", function() 
        shouldExit = true
    end)
    
    local footer = LinearLayout(activity)
    footer.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(40)))
    footer.setOrientation(LinearLayout.HORIZONTAL)
    footer.setGravity(Gravity.CENTER)
    
    local hide = TextView(activity)
    hide.setLayoutParams(LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1))
    hide.setText("HIDE")
    hide.setTextColor(COR_DESTAQUE)
    hide.setGravity(Gravity.CENTER)
    hide.setOnClickListener(function()
        mCollapsed.setVisibility(View.VISIBLE)
        mExpanded.setVisibility(View.GONE)
    end)
    
    local close = TextView(activity)
    close.setLayoutParams(LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1))
    close.setText("CLOSE")
    close.setTextColor(COR_VERMELHO)
    close.setGravity(Gravity.CENTER)
    close.setOnClickListener(function()
        mCollapsed.setVisibility(View.VISIBLE)
        mExpanded.setVisibility(View.GONE)
    end)
    
    footer.addView(hide)
    footer.addView(close)
    
    scroll.addView(patches)
    mExpanded.addView(scroll)
    mExpanded.addView(footer)
    
    root.setOnTouchListener({
        onTouch = function(_, event)
            local acao = event.getAction()
            if acao == MotionEvent.ACTION_DOWN then
                startX, startY = event.getRawX(), event.getRawY()
                lastX, lastY = params.x, params.y
                return true
            elseif acao == MotionEvent.ACTION_MOVE then
                params.x = lastX + (event.getRawX() - startX)
                params.y = lastY + (event.getRawY() - startY)
                mWindowManager.updateViewLayout(mFloatingView, params)
                return true
            end
            return false
        end
    })
    
    root.addView(mCollapsed)
    root.addView(mExpanded)
    
    mFloatingView = root
    mWindowManager.addView(mFloatingView, params)
    menuCriado = true
    Toast.makeText(activity, "⚡ Menu carregado", 0):show()
end

function fecharMenu()
    if mFloatingView and mWindowManager then
        activity.runOnUiThread({
            run = function()
                pcall(function()
                    mWindowManager.removeView(mFloatingView)
                    mFloatingView = nil
                end)
            end
        })
    end
end

activity.runOnUiThread({
    run = function()
        pcall(criarMenu)
    end
})

while not shouldExit do
 if _aimbot then
    _aimbot = false
    gg.setVisible(false)
    gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("-0.50344371796;9.99999997e-7;-0.50291442871::9", gg.TYPE_FLOAT)
    gg.refineNumber("9.99999997e-7", gg.TYPE_FLOAT)
    gg.getResults(100)
    gg.editAll("-1", gg.TYPE_FLOAT)
    gg.clearResults()
    gg.toast("⚡ SPEED HACK ACTIVATED")
  end
    gg.sleep(1000)
end

fecharMenu()
gg.sleep(500)
os.exit()