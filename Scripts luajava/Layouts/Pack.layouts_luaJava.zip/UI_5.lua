gg.setVisible(false)

local TypedValue=luajava.bindClass("android.util.TypedValue")
local Gravity=luajava.bindClass("android.view.Gravity")
local PixelFormat=luajava.bindClass("android.graphics.PixelFormat")
local Color=luajava.bindClass("android.graphics.Color")
local GradientDrawable=luajava.bindClass("android.graphics.drawable.GradientDrawable")
local View=luajava.bindClass("android.view.View")
local MotionEvent=luajava.bindClass("android.view.MotionEvent")
local WindowManager=luajava.bindClass("android.view.WindowManager")
local Context=luajava.bindClass("android.content.Context")
local Build=luajava.bindClass("android.os.Build")
local LinearLayout=luajava.bindClass("android.widget.LinearLayout")
local TextView=luajava.bindClass("android.widget.TextView")
local Button=luajava.bindClass("android.widget.Button")
local ScrollView=luajava.bindClass("android.widget.ScrollView")
local SeekBar=luajava.bindClass("android.widget.SeekBar")
local Html=luajava.bindClass("android.text.Html")
local Looper=luajava.bindClass("android.os.Looper")

local BLUE=Color.parseColor("#4C7CFF")
local WHITE=Color.parseColor("#FFFFFF")
local BLACK=Color.parseColor("#000000")
local GRAY=Color.parseColor("#C1C1C1")
local GREEN=Color.parseColor("#4CAF50")

local win=nil
local layout=nil
local menuVisivel=false
local ultX,ultY,iniX,iniY=0,0,0,0
local btnFloat=nil
local menuView=nil
local sair=false
local mainView=nil

local function dp(v)
return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,v,activity.getResources().getDisplayMetrics())
end

local function getLayoutType()
return Build.VERSION.SDK_INT>=26 and WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY or WindowManager.LayoutParams.TYPE_PHONE
end

local function criarBotao()
local btn=TextView(activity)
btn.setText("G")
btn.setTextColor(WHITE)
btn.setTextSize(30)
btn.setGravity(Gravity.CENTER)
btn.setLayoutParams(LinearLayout.LayoutParams(dp(50),dp(50)))
return btn
end

local function criarMenu()
local menu=LinearLayout(activity)
menu.setLayoutParams(LinearLayout.LayoutParams(dp(260),dp(200)))
menu.setOrientation(LinearLayout.VERTICAL)
menu.setBackgroundColor(BLACK)
menu.setVisibility(View.GONE)

local titulo=TextView(activity)
titulo.setText(Html.fromHtml("<font color='#C1C1C1'>BATMAN </font><font color='#4C7CFF'>TEAM</font>"))
titulo.setTextColor(WHITE)
titulo.setTextSize(16)
titulo.setGravity(Gravity.CENTER)
titulo.setPadding(0,dp(15),0,dp(15))
menu.addView(titulo)

local scroll=ScrollView(activity)
scroll.setLayoutParams(LinearLayout.LayoutParams(dp(260),dp(250)))

local conteudo=LinearLayout(activity)
conteudo.setOrientation(LinearLayout.VERTICAL)
conteudo.setPadding(dp(10),0,dp(10),0)

local inject=Button(activity)
inject.setText("INJECT")
inject.setTextColor(WHITE)
inject.setBackgroundColor(BLUE)
inject.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(40)))
inject.setOnClickListener(luajava.createProxy("android.view.View$OnClickListener",{
onClick=function()

_aimbot = true
windowManager.removeView(mainView,layout)
                   os.exit()
inject.setVisibility(View.GONE)
local status=TextView(activity)
status.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(40)))
status.setText("STATUS: CONNECTED")
status.setTextColor(GREEN)
status.setGravity(Gravity.CENTER)
conteudo.addView(status)
end
}))
conteudo.addView(inject)

local cats={"AIMBOT"}
for i=1,#cats do
local cat=TextView(activity)
cat.setText(cats[i])
cat.setTextColor(BLUE)
cat.setTextSize(14)
cat.setPadding(0,dp(15),0,dp(5))
conteudo.addView(cat)

for j=1,1 do
local seek=LinearLayout(activity)
seek.setOrientation(LinearLayout.VERTICAL)
seek.setPadding(0,dp(5),0,dp(10))

local txt=TextView(activity)
txt.setText(cats[i].." "..j.." : OFF")
txt.setTextColor(GRAY)
txt.setTextSize(12)

local bar=SeekBar(activity)
bar.setMax(100)
bar.setOnSeekBarChangeListener(luajava.createProxy("android.widget.SeekBar$OnSeekBarChangeListener",{
onProgressChanged=function(s,p,u)
gg.toast(cats[i].." "..j.." : "..p)

_aimbot2 = true


end
}))

seek.addView(txt)
seek.addView(bar)
conteudo.addView(seek)
end
end

scroll.addView(conteudo)
menu.addView(scroll)
return menu
end

local function initUI()
windowManager=activity.getSystemService(Context.WINDOW_SERVICE)
layout=WindowManager.LayoutParams(
WindowManager.LayoutParams.WRAP_CONTENT,
WindowManager.LayoutParams.WRAP_CONTENT,
getLayoutType(),
WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
PixelFormat.TRANSLUCENT
)
layout.gravity=Gravity.TOP|Gravity.LEFT
layout.x=dp(50)
layout.y=dp(100)

mainView=LinearLayout(activity)
mainView.setOrientation(LinearLayout.VERTICAL)

btnFloat=criarBotao()
menuView=criarMenu()

mainView.addView(btnFloat)
mainView.addView(menuView)

btnFloat.setOnTouchListener(luajava.createProxy("android.view.View$OnTouchListener",{
onTouch=function(v,event)
local acao=event.getAction()
if acao==MotionEvent.ACTION_DOWN then
iniX=event.getRawX()
iniY=event.getRawY()
ultX=layout.x
ultY=layout.y
return true
elseif acao==MotionEvent.ACTION_MOVE then
layout.x=ultX+(event.getRawX()-iniX)
layout.y=ultY+(event.getRawY()-iniY)
windowManager.updateViewLayout(mainView,layout)
return true
elseif acao==MotionEvent.ACTION_UP then
if math.abs(event.getRawX()-iniX)<10 and math.abs(event.getRawY()-iniY)<10 then
if menuView.getVisibility()==View.GONE then
menuView.setVisibility(View.VISIBLE)
btnFloat.setVisibility(View.GONE)
else
menuView.setVisibility(View.GONE)
btnFloat.setVisibility(View.VISIBLE)
end
end
return true
end
return false
end
}))
end

activity.runOnUiThread(luajava.createProxy("java.lang.Runnable",{
run=function()
initUI()
windowManager.addView(mainView,layout)
end
}))

local aberto=-1

while not shouldExit do
  if _aimbot then
    _aimbot = false
    gg.setVisible(false)
    gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("-0.50344371796;9.99999997e-7;-0.50291442871::9", gg.TYPE_FLOAT)
    gg.refineNumber("9.99999997e-7", gg.TYPE_FLOAT)
    gg.getResults(100)
    gg.editAll("-1", gg.TYPE_FLOAT)
    gg.clearResults()
    gg.toast("⚡ SPEED HACK ACTIVATED")
  end
  
    if _aimbot2 then
    _aimbot2 = false
    gg.setVisible(false)
    gg.setRanges(gg.REGION_CODE_APP)
    gg.searchNumber("-0.50344371796;9.99999997e-7;-0.50291442871::9", gg.TYPE_FLOAT)
    gg.refineNumber("9.99999997e-7", gg.TYPE_FLOAT)
    gg.getResults(100)
    gg.editAll(j, gg.TYPE_FLOAT)
    gg.clearResults()
    gg.toast("⚡ SPEED HACK 2 ACTIVATED")
  end
    gg.sleep(100)
end

  

