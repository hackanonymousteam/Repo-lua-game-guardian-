<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

$json = file_get_contents('php://input');
$data = json_decode($json, true);

if (!isset($data['hash']) || empty(trim($data['hash']))) {
    echo json_encode(['success' => false, 'message' => 'Hash não recebido']);
    exit;
}

$hash_deletar = trim($data['hash']);

$arquivo_json = 'senhas.json';

if (!file_exists($arquivo_json)) {
    echo json_encode(['success' => false, 'message' => 'Arquivo não existe']);
    exit;
}

$conteudo = file_get_contents($arquivo_json);
$senhas = json_decode($conteudo, true);

if ($senhas === null) $senhas = [];

$novo_array = array_filter($senhas, function($h) use ($hash_deletar) {
    return $h !== $hash_deletar;
});

if (file_put_contents($arquivo_json, json_encode(array_values($novo_array), JSON_PRETTY_PRINT))) {
    echo json_encode(['success' => true, 'message' => 'Hash deletado']);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao deletar']);
}
?>