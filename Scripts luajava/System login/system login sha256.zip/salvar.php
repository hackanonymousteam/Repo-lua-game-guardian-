<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

$json = file_get_contents('php://input');
$data = json_decode($json, true);

if (!isset($data['hash']) || empty(trim($data['hash']))) {
    echo json_encode(['success' => false, 'message' => 'Hash não recebido']);
    exit;
}

$hash = trim($data['hash']);

if (!preg_match('/^[a-f0-9]{64}$/i', $hash)) {
    echo json_encode(['success' => false, 'message' => 'Formato de hash inválido']);
    exit;
}

$arquivo_json = 'senhas.json';

$senhas = [];
if (file_exists($arquivo_json)) {
    $conteudo = file_get_contents($arquivo_json);
    if (!empty($conteudo)) {
        $senhas = json_decode($conteudo, true);
        if ($senhas === null) $senhas = [];
    }
}

if (in_array($hash, $senhas)) {
    echo json_encode(['success' => false, 'message' => 'Esta senha já foi registrada']);
    exit;
}

$senhas[] = $hash;

if (file_put_contents($arquivo_json, json_encode($senhas, JSON_PRETTY_PRINT))) {
    echo json_encode(['success' => true, 'message' => 'Hash registrado', 'hash' => $hash]);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao salvar']);
}
?>