<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$arquivo_json = 'senhas.json';

if (isset($_GET['hash']) && $_GET['hash'] == 'all') {
    if (!file_exists($arquivo_json)) {
        echo json_encode(['success' => true, 'hashes' => []]);
        exit;
    }
    
    $conteudo = file_get_contents($arquivo_json);
    $senhas = json_decode($conteudo, true);
    
    if ($senhas === null) $senhas = [];
    
    echo json_encode(['success' => true, 'hashes' => $senhas]);
    exit;
}

if (!isset($_GET['hash'])) {
    echo json_encode(['success' => false, 'message' => 'Parâmetro "hash" não fornecido']);
    exit;
}

$hash_busca = trim($_GET['hash']);

if (!preg_match('/^[a-f0-9]{64}$/i', $hash_busca)) {
    echo json_encode(['success' => false, 'message' => 'Formato de hash inválido']);
    exit;
}

if (!file_exists($arquivo_json)) {
    echo json_encode(['success' => false, 'found' => false, 'message' => 'Arquivo não encontrado']);
    exit;
}

$conteudo = file_get_contents($arquivo_json);
$senhas = json_decode($conteudo, true);

if ($senhas === null) {
    echo json_encode(['success' => false, 'found' => false, 'message' => 'Erro ao ler arquivo']);
    exit;
}

$encontrado = in_array($hash_busca, $senhas);

echo json_encode(['success' => true, 'found' => $encontrado, 'hash_buscado' => $hash_busca]);
?>