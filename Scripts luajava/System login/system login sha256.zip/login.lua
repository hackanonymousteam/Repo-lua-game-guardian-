function SHA256(str)
  import "java.security.MessageDigest"
  import "android.text.TextUtils"
  import "java.lang.StringBuffer"
  
  local sb = StringBuffer()
  local sha256 = MessageDigest.getInstance("SHA-256")
  local bytes = sha256.digest(String(str).getBytes("UTF-8"))
  local by = luajava.astable(bytes)
  
  for k, n in ipairs(by) do
    import "java.lang.Integer"
    local temp = Integer.toHexString(n & 255)
    
    if #temp == 1 then
      sb.append("0")
    end
    sb.append(temp)
  end
  
  return sb.toString()
end


if luajava == nil then
  gg.alert(" unavaliable please use gameguardian mod (suport luajava)")
os.exit()
else
end

local chat = gg.prompt({'pass'}, {}, {'text'})
if chat == nil then return end

local password = chat[1]
local hash = SHA256(password)

--REPLACE VARIABLE URL USING YOUR SERVER ONLINE 

local url = 'https://YOUR_SERVER_HERE/verificar.php?hash=' .. hash

local request = gg.makeRequest(url)

if request == nil or request.code ~= 200 then
    gg.alert('Erro: internet')
    return
end

local response = request.content

local found = nil
for val in response:gmatch('"found":(.-)[,}]') do
    found = val
    break
end

if found == nil then
    gg.alert('Erro: invalid reply\n' .. response)
    return
end

if found == 'true' then
    gg.alert('👍 login sucess')
    
    --start script here
    else
    gg.alert('invalid login')
    os.exit()
end