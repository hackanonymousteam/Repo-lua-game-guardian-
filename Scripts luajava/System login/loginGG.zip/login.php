<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$data_dir = __DIR__ . '/data/';
if (!is_dir($data_dir)) {
    mkdir($data_dir, 0777, true);
}

$users_file = $data_dir . 'users.json';
$scripts_dir = $data_dir . 'scripts/';
if (!is_dir($scripts_dir)) {
    mkdir($scripts_dir, 0777, true);
}

function loadUsers() {
    global $users_file;
    if (!file_exists($users_file)) {
        file_put_contents($users_file, json_encode([]));
        return [];
    }
    return json_decode(file_get_contents($users_file), true);
}

function saveUsers($users) {
    global $users_file;
    file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));
}

$data_json = $_GET['data'] ?? '';

if (empty($data_json)) {
    echo json_encode(['status' => 'error', 'message' => 'Dados vazios']);
    exit;
}

$data = json_decode(urldecode($data_json), true);

if (!$data) {
    echo json_encode(['status' => 'error', 'message' => 'Dados inválidos']);
    exit;
}

$action = $data['action'] ?? '';
$username = $data['username'] ?? '';
$password = $data['password'] ?? '';
$device_id = $data['device_id'] ?? '';

$users = loadUsers();
$response = [];

switch ($action) {
    case 'user_login':
        $user_found = null;
        $user_index = -1;
        
        foreach ($users as $i => $user) {
            if ($user['username'] === $username) {
                $user_found = $user;
                $user_index = $i;
                break;
            }
        }
        
        if (!$user_found) {
            $response = ['status' => 'not_found', 'message' => 'Usuário não encontrado'];
            break;
        }
        
        // Verificar senha
        if ($user_found['password'] !== $password) {
            $response = ['status' => 'wrong_password'];
            break;
        }
        
     
        $expiry_date = $user_found['expiry_date'];
        $current_date = date('Ymd');
        
        if ($expiry_date < $current_date) {
            $response = ['status' => 'expired', 'expiry_date' => $expiry_date];
            break;
        }
        
       
        if (empty($user_found['device_id'])) {
            // Primeiro login - salvar device
            $user_found['device_id'] = $device_id;
        } else {
            // Verificar se device corresponde
            if ($user_found['device_id'] !== $device_id) {
                $response = [
                    'status' => 'wrong_device',
                    'registered_device' => $user_found['device_id']
                ];
                break;
            }
        }
        
     
        $user_found['last_login'] = date('Y-m-d H:i:s');
        $user_found['login_count'] = ($user_found['login_count'] ?? 0) + 1;
        
        $users[$user_index] = $user_found;
        saveUsers($users);
        
      
        $script_data = '';
        $script_file = $scripts_dir . $username . '.script';
        if (file_exists($script_file)) {
            $script_data = file_get_contents($script_file);
        }
        
        $response = [
            'status' => 'success',
            'username' => $username,
            'expiry' => $expiry_date,
            'script_data' => $script_data
        ];
        break;
        
    default:
        $response = ['status' => 'unknown', 'message' => 'Ação desconhecida'];
}

echo json_encode($response);
?>