<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$data_dir = __DIR__ . '/data/';
$users_file = $data_dir . 'users.json';
$scripts_dir = $data_dir . 'scripts/';

if (!is_dir($scripts_dir)) {
    mkdir($scripts_dir, 0777, true);
}


function loadUsers() {
    global $users_file;
    if (!file_exists($users_file)) {
        file_put_contents($users_file, json_encode([]));
        return [];
    }
    return json_decode(file_get_contents($users_file), true);
}

function saveUsers($users) {
    global $users_file;
    file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));
}

$data_json = $_GET['data'] ?? '';

if (empty($data_json)) {
    echo json_encode(['status' => 'error', 'message' => 'Dados vazios']);
    exit;
}

$data = json_decode(urldecode($data_json), true);

if (!$data) {
    echo json_encode(['status' => 'error', 'message' => 'Dados inválidos']);
    exit;
}

$action = $data['action'] ?? '';
$response = [];

switch ($action) {
    case 'add_user':
        $username = $data['username'] ?? '';
        $password = $data['password'] ?? '';
        $expiry_date = $data['expiry_date'] ?? '';
        $script_data = $data['script_data'] ?? '';
        
        $users = loadUsers();
        
      
        foreach ($users as $user) {
            if ($user['username'] === $username) {
                echo json_encode(['status' => 'error', 'message' => 'Usuário já existe']);
                exit;
            }
        }
        
        
        if (!empty($script_data)) {
            $script_file = $scripts_dir . $username . '.script';
            file_put_contents($script_file, $script_data);
        }
        
        
        $new_user = [
            'username' => $username,
            'password' => $password,
            'expiry_date' => $expiry_date,
            'device_id' => '',
            'has_script' => !empty($script_data),
            'created_at' => date('Y-m-d H:i:s'),
            'last_login' => null,
            'login_count' => 0
        ];
        
        $users[] = $new_user;
        saveUsers($users);
        
        $response = [
            'status' => 'success',
            'message' => 'Usuário criado com sucesso'
        ];
        break;
        
    case 'get_users':
        $users = loadUsers();
        $response = ['users' => $users];
        break;
        
    case 'edit_user':
        $username = $data['username'] ?? '';
        $new_password = $data['new_password'] ?? '';
        $new_expiry_date = $data['new_expiry_date'] ?? '';
        
        $users = loadUsers();
        $updated = false;
        
        foreach ($users as &$user) {
            if ($user['username'] === $username) {
                if (!empty($new_password)) {
                    $user['password'] = $new_password;
                }
                if (!empty($new_expiry_date)) {
                    $user['expiry_date'] = $new_expiry_date;
                }
                $updated = true;
                break;
            }
        }
        
        if ($updated) {
            saveUsers($users);
            $response = ['status' => 'success', 'message' => 'Usuário atualizado'];
        } else {
            $response = ['status' => 'error', 'message' => 'Usuário não encontrado'];
        }
        break;
        
    case 'update_script':
        $username = $data['username'] ?? '';
        $script_data = $data['script_data'] ?? '';
        
        if (empty($script_data)) {
            echo json_encode(['status' => 'error', 'message' => 'Script vazio']);
            exit;
        }
        
       
        $script_file = $scripts_dir . $username . '.script';
        file_put_contents($script_file, $script_data);
        
      
        $users = loadUsers();
        $updated = false;
        
        foreach ($users as &$user) {
            if ($user['username'] === $username) {
                $user['has_script'] = true;
                $updated = true;
                break;
            }
        }
        
        if ($updated) {
            saveUsers($users);
            $response = ['status' => 'success', 'message' => 'Script atualizado'];
        } else {
            $response = ['status' => 'error', 'message' => 'Usuário não encontrado'];
        }
        break;
        
    case 'remove_user':
        $username = $data['username'] ?? '';
        
        $users = loadUsers();
        $new_users = [];
        $removed = false;
        
        foreach ($users as $user) {
            if ($user['username'] !== $username) {
                $new_users[] = $user;
            } else {
                $removed = true;
                
             
                $script_file = $scripts_dir . $username . '.script';
                if (file_exists($script_file)) {
                    unlink($script_file);
                }
            }
        }
        
        if ($removed) {
            saveUsers($new_users);
            $response = ['status' => 'success', 'message' => 'Usuário removido'];
        } else {
            $response = ['status' => 'error', 'message' => 'Usuário não encontrado'];
        }
        break;
        
    case 'get_info':
        $users = loadUsers();
        $total_users = count($users);
        
        $active_users = 0;
        $logins_today = 0;
        $today = date('Y-m-d');
        $current_date = date('Ymd');
        
        foreach ($users as $user) {
            if ($user['expiry_date'] >= $current_date) {
                $active_users++;
            }
            
            if ($user['last_login'] && date('Y-m-d', strtotime($user['last_login'])) === $today) {
                $logins_today++;
            }
        }
        
     
        $space_used = 0;
        if (file_exists($users_file)) {
            $space_used += filesize($users_file);
        }
        
        $script_files = glob($scripts_dir . '*.script');
        foreach ($script_files as $file) {
            $space_used += filesize($file);
        }
        
        $response = [
            'total_users' => $total_users,
            'active_users' => $active_users,
            'logins_today' => $logins_today,
            'space_used' => round($space_used / 1024, 2) . ' KB'
        ];
        break;
        
    default:
        $response = ['status' => 'error', 'message' => 'Ação inválida'];
}

echo json_encode($response);
?>