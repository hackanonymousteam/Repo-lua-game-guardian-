local json = nil
if not pcall(function()
    json = load(gg.makeRequest("https://raw.githubusercontent.com/rxi/json.lua/master/json.lua").content)()
end) then
    json = require("json") or gg.alert("JSON library not available")
    if not json then return end
end

local SERVER_URL = "https://YOUR_SERVER_HERE/"

local function urlencode(str)
    if str then
        str = string.gsub(str, "\n", "\r\n")
        str = string.gsub(str, "([^%w %-%_%.%~])", function(c)
            return string.format("%%%02X", string.byte(c))
        end)
        str = string.gsub(str, " ", "+")
    end
    return str
end

local android_info = gg.AndroidId()
local device_id = android_info.ANDROID_ID

if not device_id or device_id == "" then
    gg.alert("Device ID not found!")
    os.exit()
end

function userLogin()
    local input = gg.prompt({
        "Username:",
        "Password:"
    }, nil, {"text", "text"})
    
    if not input or not input[1] or not input[2] then
        gg.alert("Login cancelled!")
        os.exit()
    end
    
    local username = input[1]
    local password = input[2]
    
    local login_data = {
        action = "user_login",
        username = username,
        password = password,
        device_id = device_id
    }
    
    local json_data = json.encode(login_data)
    local url_encoded = urlencode(json_data)
    
    local response = gg.makeRequest(SERVER_URL .. "login.php?data=" .. url_encoded)
    
    if not response or not response.content then
        gg.alert("Connection error!")
        os.exit()
    end
    
    local result = json.decode(response.content)
    
    if result.status == "success" then
        gg.alert("Login successful!\n\nUser: " .. result.username .. "\nExpires: " .. result.expiry)
        
        if result.script_data and result.script_data ~= "" then
            local success, err = pcall(load(result.script_data))
            if not success then
                gg.alert("Error executing script: " .. err)
            end
        else
            gg.alert("Script not found on server!")
        end
        
    elseif result.status == "wrong_password" then
        gg.alert("Wrong password!")
        os.exit()
        
    elseif result.status == "expired" then
        gg.alert("Access expired on: " .. result.expiry_date)
        os.exit()
        
    elseif result.status == "wrong_device" then
        gg.alert("Device not authorized!")
        os.exit()
        
    else
        gg.alert(result.message or "Unknown error")
        os.exit()
    end
end

gg.alert("LOGIN SYSTEM\nDevice: " .. device_id:sub(1, 8) .. "...")
userLogin()