local json = nil
if not pcall(function()
    json = load(gg.makeRequest("https://raw.githubusercontent.com/rxi/json.lua/master/json.lua").content)()
end) then
    json = require("json") or gg.alert("JSON library not available")
    if not json then return end
end

local SERVER_URL = "https://YOUR_SERVER_HERE/"

local function urlencode(str)
    if str then
        str = string.gsub(str, "\n", "\r\n")
        str = string.gsub(str, "([^%w %-%_%.%~])", function(c)
            return string.format("%%%02X", string.byte(c))
        end)
        str = string.gsub(str, " ", "+")
    end
    return str
end

function sendRequest(action, data)
    data.action = action
    local json_data = json.encode(data)
    local url_encoded = urlencode(json_data)
    local response = gg.makeRequest(SERVER_URL .. "admin.php?data=" .. url_encoded)
    if response and response.content then
        local result = json.decode(response.content)
        return result
    else
        gg.alert("No server response")
    end
    return nil
end

function readScriptFile()
    gg.alert("Select .lua file")
    local file_path = gg.prompt({
        "Path to .lua file:"
    }, nil, {"file"})
    if not file_path or not file_path[1] then
        return nil
    end
    local file = io.open(file_path[1], "r")
    if not file then
        gg.alert("Cannot open file")
        return nil
    end
    local content = file:read("*a")
    file:close()
    content = "-- SCRIPT_LOADED\n-- Generated: " .. os.date("%Y-%m-%d %H:%M:%S") .. "\n\n" .. content
    gg.alert("Script loaded! Size: " .. #content .. " bytes")
    return content
end

function mainMenu()
    while true do
        local choice = gg.choice({
            "ADD USER + SCRIPT",
            "MANAGER USERS",
            --"EDIT USER",
         --   "UPDATE SCRIPT",
            "DELETE USER",
            "SYSTEM INFO",
            "EXIT"
        }, nil, "ADMIN PANEL")
        
        if choice == 1 then createUser()
        elseif choice == 2 then listUsers()
     --   elseif choice == 3 then editUserMenu()
      --  elseif choice == 4 then updateScriptMenu()
        elseif choice == 3 then deleteUserMenu()
        elseif choice == 4 then viewInfo()
        elseif choice == 5 then os.exit()
        end
    end
end

function createUser()
    local current_date = tonumber(os.date("%Y%m%d"))
    local user_input = gg.prompt({
        "Username:",
        "Password:",
        "Expiry date (YYYYMMDD):\nEx: " .. (current_date + 30)
    }, {"", "", tostring(current_date + 30)}, {"text", "text", "text"})
    if not user_input or user_input[1] == "" then
        gg.alert("Fill username!")
        return
    end
    local expiry_date = tonumber(user_input[3])
    if not expiry_date or expiry_date < current_date then
        gg.alert("Invalid expiry date!")
        return
    end
    gg.alert("Now select script for " .. user_input[1])
    local script_content = readScriptFile()
    if not script_content then
        gg.alert("Script required!")
        return
    end
    local user_data = {
        username = user_input[1],
        password = user_input[2],
        expiry_date = tostring(expiry_date),
        script_data = script_content
    }
    local result = sendRequest("add_user", user_data)
    if result then
        gg.alert(result.message .. "\n\nUser: " .. user_input[1] .. "\nExpires: " .. expiry_date)
    end
end

function listUsers()
    local result = sendRequest("get_users", {})
    if result and result.users then
        if #result.users == 0 then
            gg.alert("No users registered!")
            return
        end
        local choices = {}
        for i, user in ipairs(result.users) do
            local device_status = "❌"
            if user.device_id and user.device_id ~= "" then
                device_status = "📱"
            end
            table.insert(choices, user.username .. " | 📅" .. user.expiry_date .. " | " .. device_status)
        end
        local selected = gg.choice(choices, nil, "USERS (" .. #result.users .. ")")
        if selected then
            showUserDetails(result.users[selected])
        end
    end
end

function showUserDetails(user)
    local details = "👤 " .. user.username .. "\n\n"
    details = details .. "📅 Expires: " .. user.expiry_date .. "\n"
    if user.device_id and user.device_id ~= "" then
        details = details .. "📱 Device: " .. user.device_id:sub(1, 8) .. "...\n"
    else
        details = details .. "📱 Device: Not registered\n"
    end
    details = details .. "🔄 Last login: " .. (user.last_login or "Never") .. "\n"
    details = details .. "🔢 Total logins: " .. (user.login_count or 0) .. "\n"
    details = details .. "📝 Script: " .. (user.has_script and "✅" or "❌")
    
    local choice = gg.choice({
        "Edit password/expiry",
        "Update script",
        "Delete user",
        "Back"
    }, nil, details)
    
    if choice == 1 then editUser(user.username)
    elseif choice == 2 then updateScript(user.username)
    elseif choice == 3 then deleteUserConfirm(user.username)
    end
end

function editUserMenu()
    local result = sendRequest("get_users", {})
    if not result or not result.users or #result.users == 0 then
        gg.alert("No users to edit!")
        return
    end
    local choices = {}
    for i, user in ipairs(result.users) do
        table.insert(choices, user.username)
    end
    local selected = gg.choice(choices, nil, "EDIT USER")
    if selected then
        editUser(result.users[selected].username)
    end
end

function editUser(username)
    local current_date = tonumber(os.date("%Y%m%d"))
    local input = gg.prompt({
        "New password (leave empty to keep):",
        "New expiry date (YYYYMMDD, leave empty to keep):\nCurrent: " .. current_date
    }, {"", ""}, {"text", "text"})
    if not input then return end
    local edit_data = {username = username}
    if input[1] ~= "" then 
        edit_data.new_password = input[1]
    end
    if input[2] ~= "" then
        local new_date = tonumber(input[2])
        if new_date and new_date > current_date then
            edit_data.new_expiry_date = tostring(new_date)
        else
            gg.alert("Invalid date!")
            return
        end
    end
    if not edit_data.new_password and not edit_data.new_expiry_date then
        gg.alert("Nothing to change!")
        return
    end
    local result = sendRequest("edit_user", edit_data)
    if result then
        gg.alert(result.message)
    end
end

function updateScriptMenu()
    local result = sendRequest("get_users", {})
    if not result or not result.users or #result.users == 0 then
        gg.alert("No users to update!")
        return
    end
    local choices = {}
    for i, user in ipairs(result.users) do
        table.insert(choices, user.username)
    end
    local selected = gg.choice(choices, nil, "UPDATE SCRIPT")
    if selected then
        updateScript(result.users[selected].username)
    end
end

function updateScript(username)
    gg.alert("UPDATE SCRIPT FOR: " .. username)
    local script_content = readScriptFile()
    if script_content then
        local result = sendRequest("update_script", {
            username = username,
            script_data = script_content
        })
        if result then
            gg.alert(result.message)
        end
    end
end

function deleteUserMenu()
    local result = sendRequest("get_users", {})
    if not result or not result.users or #result.users == 0 then
        gg.alert("No users to delete!")
        return
    end
    local choices = {}
    for i, user in ipairs(result.users) do
        table.insert(choices, user.username)
    end
    local selected = gg.choice(choices, nil, "DELETE USER")
    if selected then
        deleteUserConfirm(result.users[selected].username)
    end
end

function deleteUserConfirm(username)
    local confirm = gg.alert("Delete user " .. username .. "?", "Yes", "No")
    if confirm == 1 then
        local result = sendRequest("remove_user", {username = username})
        if result then
            gg.alert(result.message)
        end
    end
end

function viewInfo()
    local result = sendRequest("get_info", {})
    if result then
        local info = "SYSTEM INFORMATION\n\n"
        info = info .. "👥 Total users: " .. result.total_users .. "\n"
        info = info .. "✅ Active users: " .. result.active_users .. "\n"
        info = info .. "📈 Logins today: " .. result.logins_today .. "\n"
        info = info .. "💾 Space used: " .. result.space_used
        gg.alert(info)
    end
end

gg.alert("ADMINISTRATION PANEL")
mainMenu()