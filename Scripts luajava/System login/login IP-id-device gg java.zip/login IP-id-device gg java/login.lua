function encodeForm(data)
  local encoded = ""
  for k, v in pairs(data) do
    encoded = encoded .. k .. "=" .. v:gsub("([^%w ])", function(c)
      return string.format("%%%02X", string.byte(c))
    end):gsub(" ", "+") .. "&"
  end
  return encoded:sub(1, -2)
end

function getDeviceDetails()
    local build = luajava.bindClass("android.os.Build")
    local version = luajava.bindClass("android.os.Build$VERSION")
    return {
        model = build.MODEL or "Unknown",
        manufacturer = build.MANUFACTURER or "Unknown",
        android_version = version.RELEASE or "Unknown",
        sdk = version.SDK_INT or "Unknown",
        product = build.PRODUCT or "Unknown",
        id = build.ID or "Not Found!"
    }
end


local deviceInfo = getDeviceDetails()
local ip_content = gg.makeRequest("https://ipinfo.io/json").content
local ip = ip_content:match('"ip":%s-"(.-)"') or "0.0.0.0"

local postData = encodeForm({

    ip = ip,
    
    model = deviceInfo.model,
    manufacturer = deviceInfo.manufacturer,
    android_version = deviceInfo.android_version,
    sdk = tostring(deviceInfo.sdk),
    product = deviceInfo.product,
    id = deviceInfo.id
})

local response = gg.makeRequest("https://YOUR_SERVER_HERE/info.php", {
    ["Content-Type"] = "application/x-www-form-urlencoded"
}, postData)

if not response or not response.content then
    gg.alert("Erro in reply.")
    return
end

if response.content:find("erro_login") then
    gg.alert("Erro in login.")
elseif response.content:find("limite_usuarios") then
    gg.alert("Limite de usuários atingido.")
elseif response.content:find("dados_nao_conferem") then
    gg.alert("Dados do dispositivo não conferem.")
elseif response.content:find("erro_script") then
    gg.alert("Erro ao carregar script remoto.")
else
    local ok, func = pcall(load, response.content)
    if ok and func then
        pcall(func)
    else
        gg.alert("Erro execute script.")
    end
end