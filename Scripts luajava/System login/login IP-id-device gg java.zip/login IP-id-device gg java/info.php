<?php


$ip = $_POST['ip'] ?? '0.0.0.0';
$ip = preg_replace('/[^0-9\.]/', '', $ip);
$path = __DIR__ . "/ips/";
$filename = $path . $ip . ".json";

// Criar pasta se não existir
if (!file_exists($path)) {
    mkdir($path, 0755, true);
}

// Limite de 10 IPs
$arquivos = glob($path . "*.json");
if (!file_exists($filename) && count($arquivos) >= 10) {
    echo "limite_usuarios";
    exit;
}

// Dados recebidos
$dados = array(
    "ip" => $ip,

    "model" => $_POST['model'] ?? '',
    "manufacturer" => $_POST['manufacturer'] ?? '',
    "android_version" => $_POST['android_version'] ?? '',
    "sdk" => $_POST['sdk'] ?? '',
    "product" => $_POST['product'] ?? '',
    "id" => $_POST['id'] ?? ''
);

// Verificar ou criar
if (file_exists($filename)) {
    $existente = json_decode(file_get_contents($filename), true);
    if ($existente != $dados) {
        echo "dados_nao_conferem";
        exit;
    }
} else {
    file_put_contents($filename, json_encode($dados, JSON_PRETTY_PRINT));
}

// Tudo ok, retornar script
if (file_exists("script.lua")) {
    header("Content-Type: text/plain");
    readfile("script.lua");
} else {
    echo "erro_script";
}
?>