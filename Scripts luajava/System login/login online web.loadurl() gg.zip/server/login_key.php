<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$input = isset($_GET['q']) ? $_GET['q'] : '';

$keyFile = 'key.json';

if (!file_exists($keyFile)) {
    // arquivo não existe
    echo "erro_login"; // resposta direta para facilitar debug
    exit;
}

$content = file_get_contents($keyFile);
if ($content === false) {
    echo "erro_leitura";
    exit;
}

$data = json_decode($content, true);
if ($data === null) {
    echo "erro_json";
    exit;
}

if (!isset($data['key'])) {
    echo "erro_chave_nao_definida";
    exit;
}

$valid = $data['key'];

// Apaga o arquivo
unlink($keyFile);

if ($input === $valid) {
    // Retorna o conteúdo do arquivo lua script.lua
    if (file_exists('script.lua')) {
        header('Content-Type: text/plain; charset=utf-8');
        readfile('script.lua');
        exit;
    } else {
        echo "erro_arquivo_ok_nao_encontrado";
        exit;
    }
} else {
    // Retorna conteúdo do arquivo erro.lua
    if (file_exists('erro.lua')) {
        header('Content-Type: text/plain; charset=utf-8');
        readfile('erro.lua');
        exit;
    } else {
        echo "erro_arquivo_erro_nao_encontrado";
        exit;
    }
}