<?php
session_start();

function generateKey(){
    $letters='';
    for($i=0;$i<2;$i++){$letters.=chr(rand(65,90));}
    $numbers='';
    for($i=0;$i<2;$i++){$numbers.=rand(0,9);}
    return $letters.$numbers;
}

$key=generateKey();
file_put_contents('key.json',json_encode(['key'=>$key]));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Generated Key</title>
<style>
body{font-family:Arial,Helvetica,sans-serif;display:flex;justify-content:center;align-items:center;height:100vh;background:#f4f4f4;margin:0}
.container{background:#fff;padding:40px;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,.1);text-align:center}
.key{font-size:48px;font-weight:bold;margin-top:20px;color:#333}
</style>
</head>
<body>
<div class="container">
<h1>Your Key</h1>
<div class="key"><?php echo htmlspecialchars($key,ENT_QUOTES,'UTF-8'); ?></div>
</div>
</body>
</html>