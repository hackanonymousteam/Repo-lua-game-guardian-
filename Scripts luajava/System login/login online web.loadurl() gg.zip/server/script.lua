gg.alert(" login done")


HOME = 1

function HOME()
multi = gg.multiChoice({
"speed",
"speed off",
"drone(view)",
"drone(view) off",
"teleport",
"teleport off",
"color map",
"color map off",
"exit script"
})

if multi == nil then else
if multi[1] == true then ch1() end
if multi[2] == true then ch1off() end
if multi[3] == true then ch2() end
if multi[4] == true then ch2off() end
if multi[5] == true then ch3() end
if multi[6] == true then ch3off() end
if multi[7] == true then ch4() end
if multi[8] == true then ch4off() end
if multi[9] == true then ch6() end

end
HOMEDM = -1
end

function ch1()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("-5.03065437e27;-4.87859808e-10;-0.5028963089;0.00999999978::13", gg.TYPE_FLOAT)
gg.refineNumber("0.00999999978", gg.TYPE_FLOAT)
gg.getResults(10)
gg.editAll("5", gg.TYPE_FLOAT)
gg.clearResults()
gg.toast("☑️ active")
gg.setVisible(false)
end

function ch1off()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("-5.03065437e27;-4.87859808e-10;-0.5028963089;5::13", gg.TYPE_FLOAT)
gg.refineNumber("5", gg.TYPE_FLOAT)
gg.getResults(10)
gg.editAll("0.00999999978", gg.TYPE_FLOAT)
gg.clearResults()
gg.toast("☑️ active")
gg.setVisible(false)
end

function ch2()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("-0.11721611023;200;410::9", gg.TYPE_FLOAT)
gg.refineNumber("410", gg.TYPE_FLOAT)
gg.getResults(10)
gg.editAll("820", gg.TYPE_FLOAT)
gg.clearResults()
gg.toast("☑️ active")
gg.setVisible(false)
gg.clearResults()				
end 

function ch2off()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("-0.11721611023;200;820::9", gg.TYPE_FLOAT)
gg.refineNumber("820", gg.TYPE_FLOAT)
gg.getResults(10)
gg.editAll("410", gg.TYPE_FLOAT)
gg.clearResults()
gg.toast("☑️ active")
gg.setVisible(false)
gg.clearResults()				
end 

function ch3()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("-5.11046945e27;-5.10801382e27;-0.10161209852;100::13", gg.TYPE_FLOAT)
gg.refineNumber("100", gg.TYPE_FLOAT)
gg.getResults(10)
gg.editAll("8", gg.TYPE_FLOAT)
gg.clearResults()
gg.toast("☑️ active")
gg.setVisible(false)
gg.clearResults()				
end 

function ch3off()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("-5.11046945e27;-5.10801382e27;-0.10161209852;8::13", gg.TYPE_FLOAT)
gg.refineNumber("8", gg.TYPE_FLOAT)
gg.getResults(10)
gg.editAll("100", gg.TYPE_FLOAT)
gg.clearResults()
gg.toast("☑️ active")
gg.setVisible(false)
gg.clearResults()				
end 
							
function ch4()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("7.06595362e-39;-6.73201239e19;255::9", gg.TYPE_FLOAT)
gg.refineNumber("255", gg.TYPE_FLOAT)
gg.getResults(10)
gg.editAll("40", gg.TYPE_FLOAT)
gg.clearResults()
gg.toast("☑️ active")
gg.setVisible(false)
gg.clearResults()				
end 

function ch4off()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("7.06595362e-39;-6.73201239e19;40::9", gg.TYPE_FLOAT)
gg.refineNumber("40", gg.TYPE_FLOAT)
gg.getResults(10)
gg.editAll("255", gg.TYPE_FLOAT)
gg.clearResults()
gg.toast("☑️ active")
gg.setVisible(false)
gg.clearResults()				
end 

function ch6()
os.exit()
end

while true do 
  if gg.isVisible(false) then 
   HOMEDM = 1
    gg.setVisible(false) 
gg.toast("☑️ by batman games")
  end 
  if HOMEDM == 1 then HOME() end 
 end

