<?php
define('HOST', 'localhost'); //servidor
define('USUARIO', 'Your_user'); // usuario
define('SENHA', 'your_pass');//senha
define('DB', 'your_db_name'); //banco de dados





$conexao = mysqli_connect(HOST, USUARIO, SENHA, DB) or die ('Não foi possível conectar');
?>