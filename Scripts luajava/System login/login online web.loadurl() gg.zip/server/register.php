<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
        integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" type="text/css" href="css/telalogin.css">
</head>

<body>
    <div class="login">
        <div class="image">
            <!-- Logo could go here -->
        </div>

        <!-- Display session messages -->
        <?php if (isset($_SESSION['status_cadastro'])): ?>
            <div>
                <p>Registration completed successfully.</p>
            </div>
            <?php unset($_SESSION['status_cadastro']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['usuario_existe'])): ?>
            <div>
                <p>Username already exists. Please choose another.</p>
            </div>
            <?php unset($_SESSION['usuario_existe']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['email_existe'])): ?>
            <div>
                <p>Email already exists. Please choose another.</p>
            </div>
            <?php unset($_SESSION['email_existe']); ?>
        <?php endif; ?>
        <!-- End session messages -->

        <form action="register2.php" method="POST">
            <div class="row">
                <i class="fas fa-user"></i>
                <input name="nome" type="text" class="input is-large" placeholder="Full Name" style="text-transform: uppercase" required>
            </div>

            <div class="row">
                <i class="fas fa-envelope"></i>
                <input name="email" type="email" class="input is-large" placeholder="Email" required>
            </div>

            <div class="row">
                <i class="fas fa-user-circle"></i>
                <input name="usuario" type="text" class="input is-large" placeholder="Username" required>
            </div>

            <div class="row">
                <i class="fas fa-lock"></i>
                <input name="senha" type="password" class="input is-large" placeholder="Password" required>
            </div>

            <div class="row">
                <button type="submit" class="button is-block is-link is-large is-fullwidth">Register</button>
                <a href="index.php">Login</a>
            </div>
        </form>
    </div>
</body>

</html>