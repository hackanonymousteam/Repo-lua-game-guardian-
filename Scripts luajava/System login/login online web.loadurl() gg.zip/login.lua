web().loadUrl("http://YOUR_SERVER/server/index.php")

gg.sleep(25000)

local chat = gg.prompt({'Enter key'}, {}, {'text'})
if chat == nil then return end

local duck = chat[1]
local response = gg.makeRequest('http://YOUR_SERVER/server/login_key.php?q=' .. duck)

if not response or not response.content then
    gg.alert("Erro.")
    return
end

local ok, func = pcall(load, response.content)
if ok and func then
    pcall(func)
else
    gg.alert("Error execute script")
end