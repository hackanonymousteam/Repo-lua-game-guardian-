<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Método não permitido']);
    exit;
}


$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['error' => 'Dados inválidos']);
    exit;
}


$username = $data['Username'];


$users = json_decode(file_get_contents('users.json'), true) ?: [];


foreach ($users as $user) {
    if ($user['Username'] === $username) {
        echo json_encode(['success' => 'Login bem-sucedido', 'user' => $user]);
        exit;
    }
}

echo json_encode(['error' => 'Usuário não encontrado']);
?>