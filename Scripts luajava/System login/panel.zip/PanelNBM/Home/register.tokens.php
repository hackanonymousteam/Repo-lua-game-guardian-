<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Método não permitido']);
    exit;
}


$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['error' => 'Dados inválidos']);
    exit;
}


$usuario = $data['Usuario'];


$users = json_decode(file_get_contents('users.json'), true) ?: [];

foreach ($users as &$user) {
    if ($user['Username'] === $usuario) {
        $user['Token'] = bin2hex(random_bytes(16));
        break;
    }
}

file_put_contents('users.json', json_encode($users));

echo json_encode(['success' => 'Token registrado com sucesso']);
?>