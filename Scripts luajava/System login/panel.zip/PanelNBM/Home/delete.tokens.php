<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Método não permitido']);
    exit;
}


$token = $_POST['TOKEN'];


$users = json_decode(file_get_contents('users.json'), true) ?: [];


foreach ($users as &$user) {
    if ($user['Token'] === $token) {
        $user['Token'] = '';
        break;
    }
}

file_put_contents('users.json', json_encode($users));

echo json_encode(['success' => 'Token eliminado com sucesso']);
?>