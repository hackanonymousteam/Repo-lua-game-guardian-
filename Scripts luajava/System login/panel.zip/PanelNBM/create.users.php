<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Método não permitido']);
    exit;
}


$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['error' => 'Dados inválidos']);
    exit;
}


$username = $data['Username'];
$expirationDate = $data['ExpirationDate'];
$token = $data['Token'];
$roteiro = $data['Roteiro'];
$body = $data['Body'];
$estado = $data['Estado'];


$users = json_decode(file_get_contents('users.json'), true) ?: [];
$users[] = [
    'Username' => $username,
    'ExpirationDate' => $expirationDate,
    'Token' => $token,
    'Roteiro' => $roteiro,
    'Body' => $body,
    'Estado' => $estado
];
file_put_contents('users.json', json_encode($users));

echo json_encode(['success' => 'Usuário criado com sucesso']);
?>