<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$users = json_decode(file_get_contents('users.json'), true) ?: [];


echo json_encode($users);
?>