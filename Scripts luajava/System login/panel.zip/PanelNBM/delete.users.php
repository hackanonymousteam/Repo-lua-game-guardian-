<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Método não permitido']);
    exit;
}


$usuario = $_POST['Usuario'];
$token = $_POST['TOKEN'];


$users = json_decode(file_get_contents('users.json'), true) ?: [];


foreach ($users as $key => $user) {
    if ($user['Username'] === $usuario && $user['Token'] === $token) {
        unset($users[$key]);
        file_put_contents('users.json', json_encode(array_values($users)));
        echo json_encode(['success' => 'Usuário excluído com sucesso']);
        exit;
    }
}

echo json_encode(['error' => 'Usuário não encontrado']);
?>