<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Método não permitido']);
    exit;
}


$usuario = $_POST['Usuario'];


$users = json_decode(file_get_contents('users.json'), true) ?: [];


foreach ($users as $user) {
    if ($user['Username'] === $usuario) {
        echo json_encode(['success' => 'Usuário encontrado', 'user' => $user]);
        exit;
    }
}

echo json_encode(['error' => 'Usuário não encontrado']);
?>