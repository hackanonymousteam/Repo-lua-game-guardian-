<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');


$diretorio = 'scripts/normal/';


$scripts = [];
if (is_dir($diretorio)) {
    $arquivos = scandir($diretorio);
    foreach ($arquivos as $arquivo) {
        if (pathinfo($arquivo, PATHINFO_EXTENSION) === 'lua') {
            $scripts[] = $arquivo;
        }
    }
}


echo json_encode($scripts);
?>