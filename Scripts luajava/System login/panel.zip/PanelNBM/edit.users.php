<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Authorization: Basic ' . base64_encode('admin:public_html/cPanel'));

$data = $_POST;

$oldUsername = $data['oldUsername'];
$newUsername = $data['newUsername'];
$newExpiration = $data['newExpiration'];
$newToken = $data['newToken'];
$newStatus = $data['newStatus'];
$newRoteiro = $data['newRoteiro'];
$newBody = $data['newBody'];

$users = json_decode(file_get_contents('users.json'), true) ?: [];

foreach ($users as &$user) {
    if ($user['Username'] === $oldUsername) {
        $user['Username'] = $newUsername;
        $user['ExpirationDate'] = $newExpiration;
        $user['Token'] = $newToken;
        $user['Estado'] = $newStatus;
        $user['Roteiro'] = $newRoteiro;
        $user['Body'] = $newBody;
        break;
    }
}

file_put_contents('users.json', json_encode($users));

echo json_encode(['success' => 'User updated successfully']);
?>