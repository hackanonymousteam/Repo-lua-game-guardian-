


local function base64(LuaR)

    local Personagens = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    return ((LuaR:gsub('.', function(x) local r, b = '', x:byte() for i = 8, 1, -1 do r = r .. (b % 2^i - b % 2^(i-1) > 0 and '1' or '0') end return r end) ..'0000'):gsub('%d%d%d?%d?%d?%d?', function(x) if (#x < 6) then return '' end local c = 0 for i = 1, 6 do c = c + (x:sub(i, i) == '1' and 2^(6 - i) or 0) end return Personagens:sub(c + 1, c + 1) end) ..({ '', '==', '=' })[#LuaR % 3 + 1])
    
end
local admin = 'admin'
local key = 'public_html/cPanel'
local Basic = base64(admin ..':'.. key);

local function GerarTOKEN()

    local Personagens = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
    local TOKEN = ''
    for i = 1, 10 do
        local Indice = math.random(1, #Personagens)
        TOKEN = TOKEN ..Personagens:sub(Indice, Indice)
    end
    return TOKEN
    
end

function ConverteremDecimal(text)

    local decimal = ''
    for i = 1, #text do
        decimal = decimal ..string.byte(text:sub(i, i)) ..','
    end
    return decimal:sub(1, -2)
    
end

local function base64_encode(input)

    local characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    local output = ''
    local padding = ''
    if (#input % 3 == 1) then
        padding = '=='
        input = input ..string.char(0, 0)
    elseif (#input % 3 == 2) then
        padding = '='
        input = input ..string.char(0)
    end
    for i = 1, #input, 3 do
        local bytes = {input:byte(i, i + 2)}
        local n = (bytes[1] or 0) * 65536 + (bytes[2] or 0) * 256 + (bytes[3] or 0)
        output = output ..characters:sub((n >> 18) + 1, (n >> 18) + 1)
        output = output ..characters:sub(((n >> 12) & 63) + 1, ((n >> 12) & 63) + 1)
        output = output ..characters:sub(((n >> 6) & 63) + 1, ((n >> 6) & 63) + 1)
        output = output ..characters:sub((n & 63) + 1, (n & 63) + 1)
    end
    return output:sub(1, #output - #padding) ..padding
    
end

local response = gg.makeRequest('https://YOUR_SERVER_HERE/PanelNBM/users.php', {['Authorization'] = 'Basic ' ..Basic})
local files = response.content
if files == nil then
    return gg.alert('🔙', '')
end
local respuesta = gg.makeRequest('https://YOUR_SERVER_HERE/PanelNBM/testers.php', {['Authorization'] = 'Basic ' ..Basic})
local programs = respuesta.content
if programs == nil then
    return gg.alert('🔙', '')
end

local function json_decode(json)

    local result = {}
    for file in json:gmatch('"(.-)"') do
        table.insert(result, file)
    end
    return result
    
end
local Testers = json_decode(programs);
local Scripts = json_decode(files);
    
function A()

    condition = true
    local headers = {
        ['Authorization'] = 'Basic ' ..Basic,
        ['Content-Type'] = condition and 'application/json' or 'application/x-www-form-urlencoded'
    }
    local function Verificacao(Usuario)
        if not Usuario or Usuario:match('^%s*$') then
            return nil
        end
        if not Usuario:match('^[%a%d áéíóúñüÁÉÍÓÚÑÜ]+$') then
            gg.setVisible(false)
            gg.colorAlert([[
            🤖  Sɪsᴛᴇᴍᴀ:]],[[
            #001
            🅴🆁🆁🅾🆁
            ]], '')
            return false
        end
        return true
    end
    function AdicionarDias(D)
        local TA = os.time()
        local DA = TA + (D * 86400)
        return os.date('%d-%m-%Y', DA)
    end
    local DatadeValidade = ''
    local isTester = false
    local showChoice = nil
    local setBody = {
    'Tester',
    'Cliente'
    }
    local choice = gg.choice(
    setBody
    , 2,
    '🤖  Sɪsᴛᴇᴍᴀ:')
    if choice == nil then
        return gg.setVisible(false)
    end
    if choice == 1 then
        isTester = true
        showChoice = Testers
    end
    if choice == 2 then
        showChoice = Scripts
    end
    local ggchoice = gg.choice(
    showChoice
    , 0,
    setBody[choice]
    )
    if not ggchoice then
        return gg.setVisible(false)
    end
    if ggchoice then
        local CriarUsuarios = gg.prompt({
        '▼ Iɴɢʀᴇsᴀʀ Usᴜᴀʀɪᴏ:',
        '',
        '◀ ¡Aɴ̃ᴀᴅɪʀ Fᴇᴄʜᴀ Dᴇ Exᴘɪʀᴀᴄɪᴏ́ɴ Mᴀɴᴜᴀʟ! (Oᴘᴄɪᴏɴᴀʟ)'
        }, {
        [2] = showChoice[ggchoice]
        }, {
        'text',
        'text',
        'checkbox',
        })
        if not CriarUsuarios then
            return gg.setVisible(false)
        end
        if CriarUsuarios[1] == 'NBM' or CriarUsuarios[1] == 'nbm' then
            gg.setVisible(false)
            return gg.colorAlert([[
                        🤖  Sɪsᴛᴇᴍᴀ:]],[[
                        #002
                        🅴🆁🆁🅾🆁
                        ]], '')
        end
        local username = CriarUsuarios[1]
        local VerificarUsuario = Verificacao(username, false)
        if VerificarUsuario == nil then
            gg.setVisible(false)
            return gg.colorAlert([[
                        🤖  Sɪsᴛᴇᴍᴀ:]],[[
                        #003
                        🅴🆁🆁🅾🆁
                        ]], '')
        end
        if not VerificarUsuario then return end
        local function String(str)
            return (str:gsub('.', function(c) return string.format('%02x', string.byte(c)) end))
        end
        local TOKEN = GerarTOKEN()
        local Estado = true
        if CriarUsuarios[3] then
            local DarumDia = gg.prompt({
            '▼ Aɴ̃ᴀᴅᴇ Dɪ́ᴀs Dᴇ Mᴇᴍʙʀᴇsɪ́ᴀ A Esᴛᴇ Usᴜᴀʀɪᴏ:'
            }, {
            30
            }, {
            'number'
            })
            if not DarumDia then
                return gg.setVisible(false)
            end
            if tonumber(DarumDia[1]) == nil then
                gg.setVisible(false)
                return gg.colorAlert([[
                            🤖  Sɪsᴛᴇᴍᴀ:]],[[
                            #004
                            🅴🆁🆁🅾🆁
                            ]], '')
            end
            if tonumber(DarumDia[1]) == 0 then
                gg.setVisible(false)
                return gg.colorAlert([[
                            🤖  Sɪsᴛᴇᴍᴀ:]],[[
                            #005
                            🅴🆁🆁🅾🆁
                            ]], '')
            end
            if tonumber(DarumDia[1]) < 0 then
                gg.setVisible(false)
                return gg.colorAlert([[
                            🤖  Sɪsᴛᴇᴍᴀ:]],[[
                            #006
                            🅴🆁🆁🅾🆁
                            ]], '')
            end
            local DIAS = tonumber(DarumDia[1]) or 0
            local DaroTempo = gg.prompt({
            '▼ Aɴ̃ᴀᴅᴇ Lᴀ Hᴏʀᴀ Mᴀɴᴜᴀʟᴍᴇɴᴛᴇ: [0;23]',
            '▼ Aɴ̃ᴀᴅᴇ Lᴏs Mɪɴᴜᴛᴏs Mᴀɴᴜᴀʟᴍᴇɴᴛᴇ: [0;59]',
            '▼ Aɴ̃ᴀᴅᴇ Lᴏs Sᴇɢᴜɴᴅᴏs Mᴀɴᴜᴀʟᴍᴇɴᴛᴇ: [0;59]',
            '◀ ¡Aɴ̃ᴀᴅɪʀ Eʟ Tɪᴇᴍᴘᴏ Mᴀɴᴜᴀʟᴍᴇɴᴛᴇ! (Qᴜɪᴛᴀ Eʟ Vɪsᴛᴏ Sɪ Qᴜɪᴇʀᴇs Usᴀʀ Eʟ Tɪᴇᴍᴘᴏ Qᴜᴇ Tɪᴇɴᴇs Cᴏɴғɪɢᴜʀᴀᴅᴏ Aᴄᴛᴜᴀʟᴍᴇɴᴛᴇ)'
            }, {
            [1] = os.date('%H'),
            [2] = os.date('%M'),
            [3] = os.date('%S'),
            [4] = true
            }, {
            'number',
            'number',
            'number',
            'checkbox'
            })
            if not DaroTempo then
                return gg.setVisible(false)
            end
            if DaroTempo[4] then
                DarumaHora = 23
                DarumMinuto = 59
                DarumSegunda = 59
            else
                DarumaHora = tonumber(DaroTempo[1]) or 0
                DarumMinuto = tonumber(DaroTempo[2]) or 0
                DarumSegunda = tonumber(DaroTempo[3]) or 0
            end
            local TempoAtual = os.time()
            local DataAtual = os.date('*t', currentTime)
            DataAtual.day = DataAtual.day + DIAS
            DataAtual.hour = DarumaHora
            DataAtual.min = DarumMinuto
            DataAtual.sec = DarumSegunda
            DatadeValidade = os.date('%d-%m-%Y %H:%M:%S', os.time(DataAtual))
            gg.colorAlert([[
            🤖  Sɪsᴛᴇᴍᴀ:]],
            DatadeValidade, '')
        else
            DatadeValidade = AdicionarDias(30) .. ' 23:59:59'
            gg.colorAlert([[
            🤖  Sɪsᴛᴇᴍᴀ:]],
            DatadeValidade, '')
        end
        local json = string.format('{"Username":"%s","ExpirationDate":"%s","Token":"%s","Roteiro":"%s","Body":"%s","Estado":%s}', CriarUsuarios[1], DatadeValidade, TOKEN, CriarUsuarios[2], tostring(isTester), tostring(Estado))
        local CreateUsers = gg.makeRequest('https://YOUR_SERVER_HERE/PanelNBM/create.users.php', headers, json)
        if not CreateUsers or not CreateUsers.content then
            gg.alert('🔙', '')
            gg.setVisible(true)
            return os.exit()
        end
        gg.sleep(100)
        local Login = '{"Usuario":"' ..CriarUsuarios[1].. '"}'
        local Inicio = '{"Username":"' ..CriarUsuarios[1].. '"}'
        pcall(load(gg.makeRequest('https://YOUR_SERVER_HERE/PanelNBM/Home/register.tokens.php', {['Authorization'] = 'Basic ' ..Basic}, Login).content))
        gg.toast([[
        🤖  Sɪsᴛᴇᴍᴀ:
        ✦ Vᴇʀɪғɪᴄᴀɴᴅᴏ Usᴜᴀʀɪᴏ: Eɴᴛʀᴀɴᴅᴏ Aʟ Mᴏᴅᴏ "Vɪsᴛᴀ Pʀᴇᴠɪᴀ 👀"
        ]])
        pcall(load(gg.makeRequest('https://YOUR_SERVER_HERE/PanelNBM/Home/sign.php', {['Authorization'] = 'Basic ' ..Basic}, Inicio).content))
        gg.sleep(100)
        gg.makeRequest('https://YOUR_SERVER_HERE/PanelNBM/Home/delete.tokens.php', {['Authorization'] = 'Basic ' ..Basic, ['Content-Type'] = 'application/x-www-form-urlencoded'}, 'TOKEN=' ..TOKEN)
        gg.sleep(100)
        gg.colorAlert([[
        🤖  Sɪsᴛᴇᴍᴀ:]],[[
        ★ Cᴏʀʀᴇᴄᴛᴏ: Usᴜᴀʀɪᴏ Cʀᴇᴀᴅᴏ Éxɪᴛᴏsᴀᴍᴇɴᴛᴇ
        ]], '')
    end
    
end

function B()
    local url = 'https://YOUR_SERVER_HERE/PanelNBM/cPanel.php'
    local headers = {
        ['Authorization'] = 'Basic ' .. Basic
    }
    local response = gg.makeRequest(url, headers)
    local content = response.content or ''
    
    if not response or not content then
        gg.alert('🔙', '')
        gg.setVisible(true)
        return os.exit()
    end

    -- Função para obter usuários usando gmatch
    local function ObterUsuarios(content)
        local Usuarios = {}
        
        -- Extrai os nomes de usuário diretamente do JSON
        for username in content:gmatch('"Username":"(.-)"') do
            table.insert(Usuarios, username)
        end
        
        return Usuarios
    end

    local Usuarios = ObterUsuarios(content)
    
    if #Usuarios == 0 then
        gg.setVisible(false)
        return gg.colorAlert([[
                    🤖  Sɪsᴛᴇᴍᴀ:]],[[
                    #010
                    🅴🆁🆁🅾🆁
                    ]], '')
    end

    if #Usuarios > 0 then
        gg.toast([[
        🤖  Sɪsᴛᴇᴍᴀ:
        ✦ Aᴠɪsᴏ: Dᴀ Cʟɪᴄ Eɴ "Vᴀʟᴇ" Sɪ Nᴏ Vᴀs A Sᴇʟᴇᴄᴄɪᴏɴᴀʀ Nɪɴɢᴜ́ɴ Usᴜᴀʀɪᴏ
        ]])
        
        local choice = gg.searchChoice(Usuarios, '🤖  Sɪsᴛᴇᴍᴀ:')
        local condition = false
        local select = {}
        
        for i = 1, #Usuarios do
            if choice[i] then
                condition = true
                table.insert(select, Usuarios[i])
                break
            end
        end
        
        
        
        
        if not condition then
            return gg.setVisible(false)
        end
        if choice then
            for _, script in ipairs(select) do
                local response = gg.makeRequest('https://YOUR_SERVER_HERE/PanelNBM/users.json', {['Authorization'] = 'Basic ' ..Basic})
                if not response or not response.content then
                    gg.alert('🔙', '')
                    gg.setVisible(true)
                    return os.exit()
                end
                local content = response.content
                local PesquisarUsuario = script
                local creado, eliminado, actualizaciones = nil, false, {}
                
                
                

local Username, ExpirationDate, Estado, Token, Roteiro, Body = nil, nil, nil, nil, nil, nil
local usuarios = {}

-- Função para extrair os dados do conteúdo JSON
for line in content:gmatch('{.-}') do
    local usuario = {}
    usuario.Username = line:match('"Username":"([%w]+)"')
    usuario.ExpirationDate = line:match('"ExpirationDate":"([%d%-]+ [%d:]+)"')
    usuario.Token = line:match('"Token":"([%w]+)"')
    usuario.Roteiro = line:match('"Roteiro":"([%w%.]+)"')
    usuario.Body = line:match('"Body":"([%w]+)"')
    usuario.Estado = line:match('"Estado":([a-zA-Z]+)')

    -- Converte Estado para booleano
    if usuario.Estado == "true" then
        usuario.Estado = true
    else
        usuario.Estado = false
    end

    -- Adiciona o usuário à lista
    table.insert(usuarios, usuario)
end

-- Busca pelo usuário desejado (modifique PesquisarUsuario conforme necessário)
local PesquisarUsuario = "batman"

-- Encontrar o usuário correspondente
for _, usuario in ipairs(usuarios) do
    if usuario.Username == PesquisarUsuario then
        Username = usuario.Username
        ExpirationDate = usuario.ExpirationDate
        Token = usuario.Token
        Roteiro = usuario.Roteiro
        Body = usuario.Body
        Estado = usuario.Estado
        break
    end
end

-- Exibe o conteúdo
if Body == 'Tester' then
    gg.colorAlert('🤖 Sɪsᴛᴇᴍᴀ:','✦ Aᴠɪsᴏ: Esᴛᴇ Es Eʟ Usᴜᴀʀɪᴏ Dᴇ Uɴ Tᴇsᴛᴇʀ', '')  
end

local choice = gg.choice({
    '✏️',
    '⛔',
    '🔍',
    '🔁'
}, 0 )

if choice == nil then
    return gg.setVisible(false)
end

if choice == 4 then
    gg.setVisible(false)
    return gg.colorAlert('🤖  Sɪsᴛᴇᴍᴀ:', '★ Cᴏʀʀᴇᴄᴛᴏ: ' .. gg.makeRequest('https://YOUR_SERVER_HERE/PanelNBM/Home/delete.tokens.php', {['Authorization'] = 'Basic ' .. Basic, ['Content-Type'] = 'application/x-www-form-urlencoded'}, 'TOKEN=' .. Token).content, '')
end
                if choice == 3 then
                    local url = 'https://YOUR_SERVER_HERE/PanelNBM/verify.users.php'
                    local headers = {
                        ['Authorization'] = 'Basic ' ..Basic,
                        ['Content-Type'] = 'application/x-www-form-urlencoded'
                    }
                    local Usuario = PesquisarUsuario
                    local json = 'Usuario=' ..Usuario
                    local response = gg.makeRequest(url, headers, json)
                    local content = response.content or ''
                    if not content then
                        gg.alert('🔙', '')
                        gg.setVisible(true)
                        return os.exit()
                    else
                        gg.colorAlert('🤖  Sɪsᴛᴇᴍᴀ', '★ Cᴏʀʀᴇᴄᴛᴏ: ' ..content, '')
                    end
                end
                if choice == 2 then
                    local Usuario = PesquisarUsuario
                    local json = 'Usuario=' ..Usuario.. '&TOKEN=' ..Token
                    local headers = {
                        ['Authorization'] = 'Basic ' ..Basic,
                        ['Content-Type'] = 'application/x-www-form-urlencoded'
                    }
                    local url = 'https://YOUR_SERVER_HERE/PanelNBM/delete.users.php'
                    local response = gg.makeRequest(url, headers, json)
                    local content = response.content or ''
                    if not content then
                        gg.alert('🔙', '')
                        gg.setVisible(true)
                        return os.exit()
                    else
                        gg.colorAlert([[
                        🤖  Sɪsᴛᴇᴍᴀ:]],[[
                        ★ Cᴏʀʀᴇᴄᴛᴏ: Usᴜᴀʀɪᴏ Eʟɪᴍɪɴᴀᴅᴏ Éxɪᴛᴏsᴀᴍᴇɴᴛᴇ
                        ]], '')
                    end
                end
                if choice == 1 then
                    local get_Usuario, get_DatadeValidade, get_Estado, get_TOKEN, get_Script, get_Body = Username, ExpirationDate, Estado, Token, Roteiro, Body
                    local detalles = {
                    ExpirationDate,
                    Estado,
                    Roteiro,
                    }
                    local options = {
	                '◀ ¡Eᴅɪᴛᴀʀ Lᴀ Fᴇᴄʜᴀ Dᴇ Exᴘɪʀᴀᴄɪᴏ́ɴ!',
	                '◀ ¡Eᴅɪᴛᴀʀ Eʟ Esᴛᴀᴅᴏ!',
	                '◀ ¡Eᴅɪᴛᴀʀ Eʟ Sᴄʀɪᴘᴛ!'
	                }
                    local choice = gg.choice(
                    options
                    , 0,
                    '✏️'
                    )
                    if not choice then
                        return gg.setVisible(false)
                    end
	                if choice then
	                    if choice == 1 then
	                        local TEMPO = detalles[choice]
	                        local day, month, year, hour, min, sec = TEMPO:match('(%d+)%-(%d+)%-(%d+) (%d+)%:(%d+)%:(%d+)')
                            local Objetivo = os.time({
                                year = tonumber(year),
                                month = tonumber(month),
                                day = tonumber(day),
                                hour = tonumber(hour),
                                min = tonumber(min),
                                sec = tonumber(sec)
                            })
                            local DataAtual = os.date('*t')
                            local TempoAtual = os.time({
	                            year = DataAtual.year,
                                month = DataAtual.month,
                                day = DataAtual.day,
                                hour = 0,
                                min = 0,
                                sec = 0,
	                        })
                            local CalcularDiasRestantes = Objetivo - TempoAtual
                            local result = math.floor(CalcularDiasRestantes / (24 * 60 * 60))
                            gg.toast([[
                            🤖  Sɪsᴛᴇᴍᴀ:
                            ✦ Aᴠɪsᴏ: Pᴜᴇᴅᴇs Qᴜɪᴛᴀʀ O Aᴜᴍᴇɴᴛᴀʀ Dɪ́ᴀs Sᴇɢᴜ́ɴ Tᴜ Eʟᴇᴄᴄɪᴏ́ɴ
                            ]])
	                        local prompt = gg.prompt({
                            string.format('🤖  Sɪsᴛᴇᴍᴀ:' .. '\n' .. '✦ Aᴠɪsᴏ: Esᴛᴇ Usᴜᴀʀɪᴏ Exᴘɪʀᴀ Eɴ %d Dɪ́ᴀs', result)
                            }, nil, {
                            'number'
                            })
                            if not prompt then
                                return gg.setVisible(false)
                            end
                            if tonumber(prompt[1]) < 0 then
                                if tonumber(prompt[1]) * -1 >= result then
                                gg.setVisible(false)
                                return gg.colorAlert([[
                                            🤖  Sɪsᴛᴇᴍᴀ:]],[[
                                            #012
                                            🅴🆁🆁🅾🆁
                                            ]], '')
                                end
                            end
                            if tonumber(prompt[1]) == nil then
                                gg.setVisible(false)
                                return gg.colorAlert([[
                                            🤖  Sɪsᴛᴇᴍᴀ:]],[[
                                            #004
                                            🅴🆁🆁🅾🆁
                                            ]], '')
                            end
                            if prompt then
                                get_DatadeValidade = tonumber(prompt[1])
                                local NovaData = os.time({
                                    year = tonumber(year),
                                    month = tonumber(month),
                                    day = tonumber(day) + get_DatadeValidade,
                                    hour = tonumber(hour),
                                    min = tonumber(min),
                                    sec = tonumber(sec)
                                    })
                                local DarNovaData = os.date('%d-%m-%Y %H:%M:%S', NovaData)
                                get_DatadeValidade = DarNovaData
                            end
	                        elseif choice == 2 then
	                            local alert = gg.alert('✦ Estado = ' .. detalles[choice], 'CAMBIAR A ESTADO INACTIVO', 'VOLVER A ESTADO ACTIVO')
	                            if alert == 0 then
	                                return gg.setVisible(false)
                                elseif alert == 1 then
                                    get_Estado = 'Inactivo'
                                elseif alert == 2 then
                                    get_Estado = 'Activo'
                                end
	                        elseif choice == 3 then
	                            if Body == 'Cliente' then
	                                showChoice = Scripts
	                            else
	                                showChoice = Testers
	                            end
	                             if #showChoice < 2 then
	                                gg.setVisible(false)
                                    return gg.colorAlert([[
                                                🤖  Sɪsᴛᴇᴍᴀ:]],[[
                                                #011
                                                🅴🆁🆁🅾🆁
                                                ]], '')
                                end
	                            for i, value in ipairs(showChoice) do
                                    if value == detalles[choice] then
                                        table.remove(showChoice, i)
                                        break
                                    end
                                end
                                local choice = gg.choice(
                                showChoice
                                , 0,
                                '✦ Script = ' .. get_Script
                                )
                                if choice == nil then
                                    return gg.setVisible(false)
                                elseif choice then
                                    get_Script = showChoice[choice]
                                end
	                        end
	                        local json = string.format('edit=true&oldUsername=%s&newUsername=%s&newExpiration=%s&newToken=%s&newStatus=%s&newRoteiro=%s&newBody=%s',
                            Username,
                            get_Usuario,
                            get_DatadeValidade,
                            get_TOKEN,
                            get_Estado,
                            get_Script,
                            get_Body
                            )
                            local headers = {
                                ['Content-Type'] = 'application/x-www-form-urlencoded',
                                ['Authorization'] = 'Basic ' ..Basic
                            }
                            local phpResponse = gg.makeRequest('https://YOUR_SERVER_HERE/PanelNBM/edit.users.php', headers, json)
                            if phpResponse and phpResponse.content then
                                gg.colorAlert([[
                                🤖  Sɪsᴛᴇᴍᴀ:]],[[
                                ★ Cᴏʀʀᴇᴄᴛᴏ: Usᴜᴀʀɪᴏ Aᴄᴛᴜᴀʟɪᴢᴀᴅᴏ Éxɪᴛᴏsᴀᴍᴇɴᴛᴇ
                                ]], '')
                                gg.setVisible(true)
                                return os.exit()
                            else
                        return end
                    end
                end
            end
        end
    end
end

local MenuAtual = nil
function option1()

    MenuAtual = 'P'
    local choice = {
        'Cʀᴇᴀʀ Usᴜᴀʀɪᴏ',
        'Lɪsᴛᴀ Dᴇ Usᴜᴀʀɪᴏs',
        'ঔৣ͜͡  ➤ Aᴛʀᴀ́s ⭕'
    }
    local localgg = gg.choice(
    choice
    , 0,
    '🤖  Sɪsᴛᴇᴍᴀ:')
    if not localgg then
        gg.setVisible(false)
        return true
    end
    if localgg == 1 then
        A()
    end
    if localgg == 2 then
        B()
    end
    if localgg == 3 then
        return HOME()
    end
    
end

function option3()

    gg.alert('🔚', '')
    gg.setVisible(true)
    return os.exit()
    
end
        
gg.setVisible(false)

function HOME()

    local options = {
        'ঔৣ͜͡  ➤ Pᴀɴᴇʟ  💻',
      
        'ঔৣ͜͡  ➤ Sᴀʟɪʀ ❌'
    }
    MenuAtual = 'HOME'
    local choice = gg.choice(options
    , 1,
    '🤖  Sɪsᴛᴇᴍᴀ:')
    if choice == nil then
        gg.setVisible(false)
        return true
    end
    for i = 1, #options do
        if choice == i then
            local select = 'option' ..i
            _G[select]()
        end
    end
    
end

HOME();

while true do
    if gg.isVisible(true) then
        gg.setVisible(false)
        if MenuAtual == 'HOME' then
            HOME();
        elseif MenuAtual == 'P' then
            option1();
        
        end
    end
end