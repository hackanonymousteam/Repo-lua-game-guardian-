gg.setVisible(false)

if gg.AndroidId() == nil then
    gg.alert("use GG by batman games!")
    return
end

if luajava == nil then
    print("LuaJava NOT Available!")
    return
end

if not activity then
    print("No activity available")
    return
end

local SERVER_URL = "http://0.0.0.0:8081"
local CHECK_URL = SERVER_URL .. "/index.php"
local LICENSE_URL = SERVER_URL .. "/license.php"

local USER_AGENT = 'Mozilla/5.0 (Linux; Android 14; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.6478.114 Mobile Safari/537.36'
local PACKAGE = 'com.game.guardian'

local URL = luajava.bindClass("java.net.URL")
local HttpURLConnection = luajava.bindClass("java.net.HttpURLConnection")
local BufferedReader = luajava.bindClass("java.io.BufferedReader")
local InputStreamReader = luajava.bindClass("java.io.InputStreamReader")
local Color = luajava.bindClass("android.graphics.Color")
local Context = luajava.bindClass("android.content.Context")
local Typeface = luajava.bindClass("android.graphics.Typeface")
local GradientDrawable = luajava.bindClass("android.graphics.drawable.GradientDrawable")
local Build = luajava.bindClass("android.os.Build")
local Handler = luajava.bindClass("android.os.Handler")
local Looper = luajava.bindClass("android.os.Looper")
local TypedValue = luajava.bindClass("android.util.TypedValue")
local Gravity = luajava.bindClass("android.view.Gravity")
local View = luajava.bindClass("android.view.View")
local WindowManager = luajava.bindClass("android.view.WindowManager")
local LayoutParams = luajava.bindClass("android.view.WindowManager$LayoutParams")
local LinearLayout = luajava.bindClass("android.widget.LinearLayout")
local LinLayoutParams = luajava.bindClass("android.widget.LinearLayout$LayoutParams")
local TextView = luajava.bindClass("android.widget.TextView")
local EditText = luajava.bindClass("android.widget.EditText")
local Button = luajava.bindClass("android.widget.Button")
local ScrollView = luajava.bindClass("android.widget.ScrollView")
local FrameLayout = luajava.bindClass("android.widget.FrameLayout")
local Runnable = luajava.bindClass("java.lang.Runnable")
local InputMethodManager = luajava.bindClass("android.view.inputmethod.InputMethodManager")
local ClipboardManager = luajava.bindClass("android.content.ClipboardManager")
local ClipData = luajava.bindClass("android.content.ClipData")

local mainHandler = Handler(Looper.getMainLooper())

local JSON_PATH = "/sdcard/json.lua"
local function ensureJson()
    local f = io.open(JSON_PATH, "r")
    if not f then
        local req = gg.makeRequest("https://raw.githubusercontent.com/rxi/json.lua/master/json.lua")
        if req and req.content then
            local out = io.open(JSON_PATH, "w")
            out:write(req.content)
            out:close()
        end
    else
        f:close()
    end
end
ensureJson()
local json = loadfile(JSON_PATH)()

local AUTH_FILE = "/sdcard/MatrixAuth_v6.json"

local function loadLocalData()
    local f = io.open(AUTH_FILE, "r")
    if f then
        local content = f:read("*all")
        f:close()
        if content and content ~= "" then
            local ok, data = pcall(function() return json.decode(content) end)
            if ok then return data end
        end
    end
    return {}
end

local function saveLocalData(data)
    local f = io.open(AUTH_FILE, "w")
    if f then
        f:write(json.encode(data))
        f:close()
    end
end

local function urlEncode(str)
    return str:gsub("([^%w])", function(c)
        return string.format("%%%02X", string.byte(c))
    end):gsub(" ", "+")
end

local function dp(v)
    return math.floor(TypedValue.applyDimension(1, v, activity.getResources().getDisplayMetrics()))
end

local function getSkin(color, radius, strokeWidth, strokeColor)
    local draw = GradientDrawable()
    draw.setColor(color)
    draw.setCornerRadius(dp(radius))
    if strokeColor then
        draw.setStroke(dp(strokeWidth or 1), strokeColor)
    end
    return draw
end

local function getSavedKey()
    return (loadLocalData()).licenseKey
end

local function saveKey(keyVal)
    local data = loadLocalData()
    data.licenseKey = keyVal
    saveLocalData(data)
end

local function httpRequest(urlString)
    local httpSuccess, httpResult = pcall(function()
        local url = luajava.new(URL, urlString)
        local connection = url:openConnection()
        
        connection:setConnectTimeout(10000)
        connection:setReadTimeout(10000)
        connection:setRequestProperty("User-Agent", "LuaJava-HTTP-Client")
        connection:setRequestProperty("Accept", "text/plain")
        
        connection:connect()
        
        local responseCode = connection:getResponseCode()
        
        if responseCode == 200 then
            local inputStream = connection:getInputStream()
            local reader = luajava.new(BufferedReader, luajava.new(InputStreamReader, inputStream))
            
            local responseBody = {}
            local line = reader:readLine()
            while line do
                table.insert(responseBody, line)
                line = reader:readLine()
            end
            
            connection:disconnect()
            return table.concat(responseBody)
        else
            connection:disconnect()
            return nil
        end
    end)
    
    if httpSuccess then
        return httpResult
    end
    return nil
end

local function sendCheck(check, value)
    local urlString = CHECK_URL .. '?ua=' .. urlEncode(USER_AGENT) .. '&check=' .. check .. '&value=' .. value
    return httpRequest(urlString)
end

local function apiRequest(params)
    local queryParts = {}
    for k, v in pairs(params) do
        table.insert(queryParts, k .. "=" .. urlEncode(tostring(v)))
    end
    local urlString = LICENSE_URL .. "?" .. table.concat(queryParts, "&")
    
    local httpSuccess, httpResult = pcall(function()
        local url = luajava.new(URL, urlString)
        local connection = url:openConnection()
        
        connection:setConnectTimeout(10000)
        connection:setReadTimeout(10000)
        connection:setRequestProperty("User-Agent", "LuaJava-HTTP-Client")
        connection:setRequestProperty("Accept", "application/json")
        
        connection:connect()
        
        local responseCode = connection:getResponseCode()
        
        if responseCode == 200 then
            local inputStream = connection:getInputStream()
            local reader = luajava.new(BufferedReader, luajava.new(InputStreamReader, inputStream))
            
            local responseBody = {}
            local line = reader:readLine()
            while line do
                table.insert(responseBody, line)
                line = reader:readLine()
            end
            
            connection:disconnect()
            return table.concat(responseBody)
        else
            connection:disconnect()
            return nil
        end
    end)
    
    if httpSuccess and httpResult then
        local ok, result = pcall(function() return json.decode(httpResult) end)
        if ok then return result end
    end
    
    return { status = "error", message = "Network error" }
end

local blockedPackages = {
    'com.prabalgaming.logger',
    'any_.body_.can_.fuck_.tencent_',
    'com.rjvsbmhdspmnfbame',
    'com.redwolfgaming.ripgg',
    'com.vrexqfftfsxekm.kl',
    'com.nochqxpucsbldqqx',
    'com.ghueczxrttlhgd',
    'com.yy.qptvrjwerw.ghoex',
    'com.Egypt.yuosseef',
    'com.tssfjipkmrco',
    'com.vip.paidhacksonly.mr.toxin',
    'com.ioyysvgfsrig',
    'com.mrteamz.id',
    'com.jtbodgpqxox',
    'com.ByGGXEZ',
    'com.eidymumcghpfeeeavps',
    'com.mod.iraq',
    'com.dzelttwyuyyes',
    'com.sxqa',
    'com.xyyxgxfn',
    'com.zgb',
    'com.vnpqk',
    'com.mwjvnwesbghkxbjznbwo',
    'com.blackduty.gc',
    'com.s.fyojrme',
    'com.roxmemek',
    'com.fhshwhpvqvruvjtu',
    'com.fireongaming.fog',
    'com.paranoiaworks.unicus.android.sse',
    'com.raincitygaming.ggmod',
    'com.pvt4u',
    'com.nydpvsb.z.r.pkgh',
    'com.gmsm',
    'com.sudsjcqvvcmgutdjeg',
    'com.coolfoolggfuckscript.tm',
    'com.foxcyber.gg',
    'com.hckeam.mjgql',
    'com.i.ii',
    'com.k.kk',
    'com.aero.ss',
    'com.decrypt.tool.by.joker.gg',
    'com.rgkttz.rausqwl',
    'catch.Art.Tool.seatch',
    'com.laallkxhtrnqncw',
    'com.khoiscript.logger',
    'com.kaoygxapp'
}

local function runSecurityChecks()
    gg.toast("Running security checks...")
    
    local encodedUA = urlEncode(USER_AGENT)
    local checkUrlString = CHECK_URL .. '?ua=' .. encodedUA
    local response = httpRequest(checkUrlString)
    
    if response == nil then
        print("Network Error\nCheck your internet connection.")
        return false
    end
    
    if response == 'forbidden' then
        print("Access Blocked\nThis script has been blocked.")
        return false
    elseif response == 'false' then
        print("Invalid User-Agent\nScript tampering detected.")
        return false
    elseif response ~= 'true' then
        print("Unexpected Error: " .. response)
        return false
    end
    
    if luajava == nil then
        sendCheck('luajava', 'false')
        print("LuaJava Required\nUse GameGuardian Mod with LuaJava support.")
        return false
    end
    sendCheck('luajava', 'true')
    
    local EXPECTED_CACHE = '/data/user/0/' .. PACKAGE .. '/cache'
    if gg.CACHE_DIR ~= EXPECTED_CACHE then
        sendCheck('cache_dir', 'false')
        print("Invalid Cache Directory\nPossible tampering detected.")
        return false
    end
    sendCheck('cache_dir', 'true')
    
    local EXPECTED_FILES = '/data/user/0/' .. PACKAGE .. '/files'
    if gg.FILES_DIR ~= EXPECTED_FILES then
        sendCheck('files_dir', 'false')
        print("Invalid Files Directory\nPossible tampering detected.")
        return false
    end
    sendCheck('files_dir', 'true')
    
    local packageOk = true
    for _, pkg in ipairs(blockedPackages) do
        local ec = '/data/user/0/' .. pkg .. '/cache'
        local ef = '/data/user/0/' .. pkg .. '/files'
        if gg.CACHE_DIR == ec or gg.FILES_DIR == ef then
            packageOk = false
            break
        end
    end
    if not packageOk then
        sendCheck('package', 'false')
        print("Blocked Package Detected\nThis script cannot run here.")
        return false
    end
    sendCheck('package', 'true')
    
    if gg.VERSION_INT < 10100 then
        sendCheck('version', 'false')
        print("Update Required\nPlease update GameGuardian to latest version.")
        return false
    end
    sendCheck('version', 'true')
    
    if type(gg.isVPN) == 'function' then
        if gg.isVPN() == true then
            sendCheck('vpn', 'false')
            print("VPN Detected\nPlease disable VPN and restart.")
            return false
        end
        sendCheck('vpn', 'true')
    end
    
    return true
end

local Thread = luajava.bindClass("java.lang.Thread")

local function loginWithKey(keyValue, callback)
    Thread(Runnable({
        run = function()
            local ok, result = pcall(function()
                return apiRequest({
                    action = "login",
                    key = keyValue,
                    device_id = gg.AndroidId(),
                    label = "Device"
                })
            end)

            if not ok or not result then
                result = {
                    status = "error",
                    message = "Network error"
                }
            end

            mainHandler.post(Runnable({
                run = function()
                    callback(result)
                end
            }))
        end
    })).start()
end

local function checkLicense(callback)
    local keyValue = getSavedKey()

    if not keyValue then
        callback({
            status = "no_key",
            message = "No saved key"
        })
        return
    end

    Thread(Runnable({
        run = function()
            local ok, result = pcall(function()
                return apiRequest({
                    action = "check",
                    key = keyValue,
                    device_id = gg.AndroidId()
                })
            end)

            if not ok or not result then
                result = {
                    status = "error",
                    message = "Network error"
                }
            end

            mainHandler.post(Runnable({
                run = function()
                    callback(result)
                end
            }))
        end
    })).start()
end

local UI = {
    BG = Color.parseColor("#0a0a0a"),
    CARD = Color.parseColor("#1a1a2e"),
    ACCENT = Color.parseColor("#e94560"),
    ACCENT2 = Color.parseColor("#0f3460"),
    TEXT = Color.parseColor("#eaeaea"),
    SUCCESS = Color.parseColor("#4ade80"),
    DANGER = Color.parseColor("#ef4444"),
    WARNING = Color.parseColor("#f59e0b"),
    WHITE = Color.parseColor("#FFFFFF"),
}

local WIDTH = 340
local exitApp = false
local menuView = nil
local activeView = nil
local windowManager = nil
local mParams = nil
local loginInput, statusText, infoText

function createLoginScreen()
    local root = FrameLayout(activity)
    root.setLayoutParams(FrameLayout.LayoutParams(dp(WIDTH), -2))
    
    local scroll = ScrollView(activity)
    scroll.setLayoutParams(FrameLayout.LayoutParams(-1, dp(440)))
    
    local main = LinearLayout(activity)
    main.setOrientation(1)
    main.setBackground(getSkin(UI.BG, 20, 2, UI.ACCENT))
    main.setPadding(dp(16), dp(16), dp(16), dp(16))
    
    local topBar = LinearLayout(activity)
    topBar.setOrientation(0)
    topBar.setGravity(Gravity.CENTER_VERTICAL)
    topBar.setPadding(0, 0, 0, dp(12))
    
    local header = LinearLayout(activity)
    header.setOrientation(0)
    header.setGravity(Gravity.CENTER_VERTICAL)
    header.setLayoutParams(LinLayoutParams(0, -2, 1.0))
    
    local logo = TextView(activity)
    logo.setText("SHIELD")
    logo.setTextSize(1, 28)
   -- header.addView(logo)
    
    local titleArea = LinearLayout(activity)
    titleArea.setOrientation(1)
    titleArea.setLayoutParams(LinLayoutParams(0, -2, 1.0))
    
    local title = TextView(activity)
    title.setText("MATRIX SHIELD")
    title.setTextColor(UI.ACCENT)
    title.setTextSize(1, 18)
    title.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD))
    titleArea.addView(title)
    
    local subtitle = TextView(activity)
    subtitle.setText("License System v6.0")
    subtitle.setTextColor(UI.TEXT)
    subtitle.setTextSize(1, 10)
    subtitle.setAlpha(0.5)
    titleArea.addView(subtitle)
    
    header.addView(titleArea)
    topBar.addView(header)
    
    local closeBtn = TextView(activity)
    closeBtn.setText("X")
    closeBtn.setTextSize(1, 18)
    closeBtn.setTextColor(UI.TEXT)
    closeBtn.setBackground(getSkin(UI.ACCENT2, 8))
    closeBtn.setPadding(dp(12), dp(6), dp(12), dp(6))
    closeBtn.setFocusable(true)
    closeBtn.setClickable(true)
closeBtn.setOnClickListener(View.OnClickListener({
    onClick = function()
        closeUI()
        exitApp = true
    end
}))  topBar.addView(closeBtn)
    
    main.addView(topBar)
    
    local sep = View(activity)
    sep.setLayoutParams(LinLayoutParams(-1, dp(1)))
    sep.setBackgroundColor(UI.ACCENT)
    sep.setAlpha(0.3)
    main.addView(sep)
    
    local devSection = LinearLayout(activity)
    devSection.setOrientation(0)
    devSection.setPadding(0, dp(10), 0, dp(10))
    
    local devId = gg.AndroidId()
    local devLabel = TextView(activity)
    devLabel.setText("Device: ")
    devLabel.setTextColor(UI.TEXT)
    devLabel.setTextSize(1, 9)
    devLabel.setAlpha(0.6)
    devSection.addView(devLabel)
  --  main.addView(devSection)
    
    statusText = TextView(activity)
    statusText.setText("")
    statusText.setTextColor(UI.TEXT)
    statusText.setTextSize(1, 12)
    statusText.setGravity(Gravity.CENTER)
    statusText.setPadding(0, dp(8), 0, dp(8))
    main.addView(statusText)
    
    local inputLabel = TextView(activity)
    inputLabel.setText("ENTER LICENSE KEY:")
    inputLabel.setTextColor(UI.ACCENT)
    inputLabel.setTextSize(1, 11)
    inputLabel.setTypeface(Typeface.DEFAULT_BOLD)
    inputLabel.setPadding(0, 0, 0, dp(6))
    main.addView(inputLabel)
    
    local inputRow = LinearLayout(activity)
    inputRow.setOrientation(0)
    inputRow.setLayoutParams(LinLayoutParams(-1, dp(45)))
    
    loginInput = EditText(activity)
    loginInput.setLayoutParams(LinLayoutParams(0, -1, 1.0))
    loginInput.setHint("MX-XXXX-XXXX-XXXX-XXXX")
    loginInput.setHintTextColor(Color.parseColor("#555555"))
    loginInput.setTextColor(UI.TEXT)
    loginInput.setTextSize(1, 13)
    loginInput.setSingleLine(true)
    loginInput.setBackground(getSkin(UI.CARD, 10, 1, UI.ACCENT))
    loginInput.setPadding(dp(12), 0, dp(12), 0)
    
    local savedKey = getSavedKey()
    if savedKey then
        loginInput.setText(savedKey)
    end
    
    inputRow.addView(loginInput)
    
    local pasteBtn = Button(activity)
    pasteBtn.setText("📋")
    pasteBtn.setTextSize(1, 16)
    pasteBtn.setTextColor(UI.WHITE)
    pasteBtn.setBackground(getSkin(UI.ACCENT2, 10))
    local pasteParams = LinLayoutParams(dp(45), -1)
    pasteParams.leftMargin = dp(6)
    pasteBtn.setLayoutParams(pasteParams)
    pasteBtn.setOnClickListener(View.OnClickListener({
        onClick = function()
            pcall(function()
                local clipboard = activity.getSystemService(Context.CLIPBOARD_SERVICE)
                local clip = clipboard.getPrimaryClip()
                if clip and clip.getItemCount() > 0 then
                    local text = clip.getItemAt(0).getText()
                    if text then
                        loginInput.setText(text)
                        loginInput.setSelection(#text)
                        gg.toast("Pasted!")
                    end
                end
            end)
        end
    }))
    inputRow.addView(pasteBtn)
    main.addView(inputRow)
    
    local loginBtn = Button(activity)
    loginBtn.setText("ACTIVATE LICENSE")
    loginBtn.setTextColor(UI.WHITE)
    loginBtn.setTextSize(1, 14)
    loginBtn.setTypeface(Typeface.DEFAULT_BOLD)
    loginBtn.setBackground(getSkin(UI.ACCENT, 12))
    local loginParams = LinLayoutParams(-1, dp(48))
    loginParams.topMargin = dp(12)
    loginParams.bottomMargin = dp(8)
    loginBtn.setLayoutParams(loginParams)
    loginBtn.setOnClickListener(View.OnClickListener({ onClick = function() doLogin() end }))
    main.addView(loginBtn)
    
    local checkBtn = Button(activity)
    checkBtn.setText("CHECK STATUS")
    checkBtn.setTextColor(UI.WHITE)
    checkBtn.setTextSize(1, 12)
    checkBtn.setBackground(getSkin(UI.ACCENT2, 10))
    local checkParams = LinLayoutParams(-1, dp(40))
    checkParams.bottomMargin = dp(12)
    checkBtn.setLayoutParams(checkParams)
    checkBtn.setOnClickListener(View.OnClickListener({ onClick = function() doCheck() end }))
  --  main.addView(checkBtn)
    
    infoText = TextView(activity)
    infoText.setText("Enter your license key above.\nFirst login binds this device to the key.")
    infoText.setTextColor(UI.TEXT)
    infoText.setTextSize(1, 9)
    infoText.setAlpha(0.4)
    infoText.setGravity(Gravity.CENTER)
    main.addView(infoText)
    
    scroll.addView(main)
    root.addView(scroll)
    
    return root
end

function doLogin()
    local keyValue = loginInput.getText().toString():upper():gsub("%s+", "")
    
    if keyValue == "" then
        gg.toast("Please enter a license key")
        return
    end
    
    if not keyValue:match("^MX%-[A-Z0-9]+%-[A-Z0-9]+%-[A-Z0-9]+%-[A-Z0-9]+$") then
        gg.toast("Invalid key format")
        return
    end
    
    updateStatus("Logging in...", UI.WARNING)

    loginWithKey(keyValue, function(result)

        if result.status == "active" then
            saveKey(keyValue)

            updateStatus("LICENSE ACTIVE", UI.SUCCESS)
--

            local expInfo = ""

            if result.expiry and result.expiry > 0 then
                local remaining = result.expiry - (result.serverTime or (os.time() * 1000))
                local days = math.floor(remaining / 86400000)
                expInfo = "\nExpires in " .. days .. " days"
            else
                expInfo = "\nLifetime license"
            end
--starting
gg.toast("starting")
            print(
                "LICENSE ACTIVATED!\n\nKey: " ..
                keyValue ..
                "\nDevices: " ..
                (result.max_devices or 1) ..
                " max" ..
                expInfo
            )
_speedHackPending = true
            exitApp = true

        elseif result.status == "device_limit" then

            updateStatus("DEVICE LIMIT", UI.DANGER)

            print(
                "DEVICE LIMIT REACHED\n\nAllowed: " ..
                tostring(result.max_devices or 1)
            )

        elseif result.status == "device_conflict" then

            updateStatus("DEVICE CONFLICT", UI.DANGER)

            print("Device already linked")

        elseif result.status == "expired" then

            updateStatus("EXPIRED", UI.DANGER)

            print("License expired")

        elseif result.status == "revoked" then

            updateStatus("REVOKED", UI.DANGER)

            print("License revoked")

        elseif result.status == "paused" then

            updateStatus("PAUSED", UI.WARNING)

            print("License paused")

        elseif result.status == "invalid_key" then

            updateStatus("INVALID KEY", UI.DANGER)

            print("Invalid key")

        else

            updateStatus("ERROR", UI.DANGER)

            print(
                "LOGIN FAILED\n\n" ..
                tostring(result.message or result.status or "Unknown")
            )
        end
    end)
end
function doCheck()

    updateStatus("Checking...", UI.WARNING)

    checkLicense(function(result)

        if result.status == "active" then

            updateStatus("LICENSE ACTIVE", UI.SUCCESS)

            local expInfo = ""

            if result.expiry and result.expiry > 0 then
                local remaining = result.expiry - (result.serverTime or (os.time() * 1000))
                local days = math.floor(remaining / 86400000)
                expInfo = " | " .. days .. " days"
            else
                expInfo = " | Lifetime"
            end

            gg.toast("License Active" .. expInfo)

        elseif result.status == "no_key" then

            updateStatus("NO KEY", UI.WARNING)

            gg.toast("No key saved")

        elseif result.status == "not_linked" then

            updateStatus("NOT LINKED", UI.DANGER)

            print("Device not linked")

        elseif result.status == "expired" then

            updateStatus("EXPIRED", UI.DANGER)

            print("License expired")

        else

            updateStatus("ERROR", UI.DANGER)

            print(
                tostring(result.status or result.message or "Unknown")
            )
        end
    end)
end
function updateStatus(text, color)
    if statusText then
        mainHandler.post(Runnable({
            run = function()
                pcall(function()
                    statusText.setText(text)
                    statusText.setTextColor(color or UI.TEXT)
                end)
            end
        }))
    end
end

function showUI()
    windowManager = activity.getSystemService(Context.WINDOW_SERVICE)

    local layoutType = (Build.VERSION.SDK_INT >= 26) and
        LayoutParams.TYPE_APPLICATION_OVERLAY or
        LayoutParams.TYPE_PHONE

    mParams = LayoutParams(dp(WIDTH), -2, layoutType, 0, -3)
    mParams.gravity = Gravity.TOP | Gravity.LEFT
    mParams.x, mParams.y = 50, 150

    menuView = createLoginScreen()

    mainHandler.post(Runnable({
        run = function()
            pcall(function()
                windowManager.addView(menuView, mParams)
                activeView = menuView
            end)
        end
    }))
end

function closeUI()
    mainHandler.post(Runnable({
        run = function()
            pcall(function()
                if activeView and windowManager then
                    windowManager.removeView(activeView)
                    activeView = nil
                end
            end)
        end
    }))
end


    showUI()

XGCK1 = -1
shouldExit = false
_speedHackPending = false

while true do

    if shouldExit then
        break
    end

    if gg.isVisible(true) then
        XGCK1 = 1
        gg.setVisible(false)
        gg.clearResults()
    end

    if _speedHackPending then

        _speedHackPending = false

        gg.setVisible(false)

        gg.sleep(1500)

        closeUI()

        local req =
            gg.makeRequest(
                "https://pastebin.com/raw/your_online_script"
            )

        if not req or not req.content then

            print("Failed loading remote script")

            os.exit()

        end

        local chunk, err =
            load(req.content)

        if not chunk then

            print(
                "LOAD ERROR\n\n" ..
                tostring(err)
            )

            os.exit()

        end

        local ok, runtimeErr =
            pcall(chunk)

        if not ok then

            print(
                "RUNTIME ERROR\n\n" ..
                tostring(runtimeErr)
            )

            os.exit()

        end

        shouldExit = true

    end

    if XGCK1 == 1 then
    end

    XGCK1 = -1

    gg.sleep(100)

end