<?php


header('Content-Type: text/plain');
header('Access-Control-Allow-Origin: *');

$jsonFile = __DIR__ . '/data/checks.json';
$keysFile = __DIR__ . '/data/keys.json';


if (!is_dir(__DIR__ . '/data')) {
    mkdir(__DIR__ . '/data', 0755, true);
}


$defaultData = [
    'ua' => 'Mozilla/5.0 (Linux; Android 14; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.6478.114 Mobile Safari/537.36',
    'blocked' => false,
    'block_reason' => '',
    'checks' => [
        'luajava' => null,
        'package' => null,
        'cache_dir' => null,
        'files_dir' => null,
        'version' => null,
        'vpn' => null,
        'fingerprint' => null,
        'key_valid' => null,
        'time_valid' => null,
        'device_linked' => null
    ]
];


if (!file_exists($jsonFile)) {
    file_put_contents($jsonFile, json_encode($defaultData, JSON_PRETTY_PRINT));
}

$data = json_decode(file_get_contents($jsonFile), true);


if ($data['blocked'] === true) {
    echo 'forbidden';
    exit;
}


if (!isset($_GET['ua'])) {
    echo 'false';
    exit;
}


if ($_GET['ua'] !== $data['ua']) {
    $data['blocked'] = true;
    $data['block_reason'] = 'User-Agent mismatch';
    file_put_contents($jsonFile, json_encode($data, JSON_PRETTY_PRINT));
    echo 'false';
    exit;
}


if (isset($_GET['check']) && isset($_GET['value'])) {
    $check = $_GET['check'];
    $value = $_GET['value'];
    
    if (isset($data['checks'][$check])) {
        if ($value === 'false') {
            $data['blocked'] = true;
            $data['block_reason'] = "Check failed: {$check}";
            file_put_contents($jsonFile, json_encode($data, JSON_PRETTY_PRINT));
            echo 'blocked';
            exit;
        }
        $data['checks'][$check] = $value;
        file_put_contents($jsonFile, json_encode($data, JSON_PRETTY_PRINT));
    }
}
echo 'true';
?>