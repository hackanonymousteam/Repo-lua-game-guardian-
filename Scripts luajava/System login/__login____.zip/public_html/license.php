<?php
error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

define('ADMIN_TOKEN', 'MatrixAdmin2026');
define('DATA_DIR', __DIR__ . '/data');
define('KEYS_FILE', DATA_DIR . '/keys.json');

function ensureDir() {

    if (!is_dir(DATA_DIR)) {
        mkdir(DATA_DIR, 0755, true);
    }
}

function readJson($path) {

    if (!file_exists($path)) {
        return array();
    }

    $content = file_get_contents($path);

    if (!$content) {
        return array();
    }

    $json = json_decode($content, true);

    if (!is_array($json)) {
        return array();
    }

    return $json;
}

function writeJson($path, $data) {

    ensureDir();

    return file_put_contents(
        $path,
        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
        LOCK_EX
    );
}

function nowMs() {
    return round(microtime(true) * 1000);
}

function getKeys() {

    $keys = readJson(KEYS_FILE);

    foreach ($keys as &$k) {

        if (!isset($k['devices']) || !is_array($k['devices'])) {
            $k['devices'] = array();
        }

        if (!isset($k['max_devices'])) {
            $k['max_devices'] = 1;
        }

        if (!isset($k['status'])) {
            $k['status'] = 'active';
        }

        if (!isset($k['created_at'])) {
            $k['created_at'] = 0;
        }

        if (!isset($k['last_used'])) {
            $k['last_used'] = 0;
        }

        if (!isset($k['note'])) {
            $k['note'] = '';
        }

        if (!isset($k['expiry'])) {
            $k['expiry'] = 0;
        }
    }

    return $keys;
}

function saveKeys($keys) {
    return writeJson(KEYS_FILE, array_values($keys));
}

function saveKey($keyData) {

    $keys = getKeys();
    $found = false;

    foreach ($keys as $i => $k) {

        if ($k['key'] === $keyData['key']) {
            $keys[$i] = array_merge($k, $keyData);
            $found = true;
            break;
        }
    }

    if (!$found) {
        $keys[] = $keyData;
    }

    return saveKeys($keys);
}

function findKey($keyVal) {

    $keys = getKeys();

    foreach ($keys as $k) {

        if ($k['key'] === $keyVal) {
            return $k;
        }
    }

    return null;
}

function findKeyByDevice($deviceId) {

    $keys = getKeys();

    foreach ($keys as $k) {

        foreach ($k['devices'] as $dev) {

            if ($dev['device_id'] === $deviceId) {
                return $k;
            }
        }
    }

    return null;
}

function deleteKeyByValue($keyVal) {

    $keys = getKeys();
    $new = array();

    foreach ($keys as $k) {

        if ($k['key'] !== $keyVal) {
            $new[] = $k;
        }
    }

    return saveKeys($new);
}

function isAuthed() {

    $token = '';

    if (isset($_GET['token'])) {
        $token = $_GET['token'];
    }

    if (isset($_POST['token'])) {
        $token = $_POST['token'];
    }

    return $token === ADMIN_TOKEN;
}

function generateKey($segments, $len) {

    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $parts = array();

    for ($s = 0; $s < $segments; $s++) {

        $part = '';

        for ($i = 0; $i < $len; $i++) {
            $part .= $chars[random_int(0, strlen($chars) - 1)];
        }

        $parts[] = $part;
    }

    return 'MX-' . implode('-', $parts);
}

$action = '';

if (isset($_GET['action'])) {
    $action = $_GET['action'];
}

if (isset($_POST['action'])) {
    $action = $_POST['action'];
}

$inputRaw = file_get_contents('php://input');
$input = json_decode($inputRaw, true);

if (!is_array($input)) {
    $input = array();
}

$req = array_merge($_GET, $_POST, $input);

switch ($action) {

    case 'time':

        echo json_encode(array(
            'ok' => true,
            'serverTime' => nowMs(),
            'serverTimeISO' => date('c')
        ));

        break;

    case 'login':

        $keyVal = isset($req['key']) ? $req['key'] : '';
        $devId = isset($req['device_id']) ? $req['device_id'] : '';
        $label = isset($req['label']) ? $req['label'] : 'Unknown Device';

        $time = nowMs();

        if ($keyVal === '' || $devId === '') {

            echo json_encode(array(
                'ok' => false,
                'status' => 'error',
                'message' => 'Key and device_id required'
            ));

            exit;
        }

        $key = findKey($keyVal);

        if (!$key) {

            echo json_encode(array(
                'ok' => false,
                'status' => 'invalid_key',
                'message' => 'Key not found'
            ));

            exit;
        }

        if ($key['status'] === 'revoked' || $key['status'] === 'paused') {

            echo json_encode(array(
                'ok' => false,
                'status' => $key['status']
            ));

            exit;
        }

        if (
            $key['expiry'] > 0 &&
            $time > $key['expiry']
        ) {

            $key['status'] = 'expired';
            saveKey($key);

            echo json_encode(array(
                'ok' => false,
                'status' => 'expired'
            ));

            exit;
        }

        $alreadyLinked = false;

        foreach ($key['devices'] as $dev) {

            if ($dev['device_id'] === $devId) {
                $alreadyLinked = true;
                break;
            }
        }

        if (!$alreadyLinked) {

            $otherKey = findKeyByDevice($devId);

            if ($otherKey && $otherKey['key'] !== $keyVal) {

                echo json_encode(array(
                    'ok' => false,
                    'status' => 'device_conflict',
                    'linked_key' => $otherKey['key']
                ));

                exit;
            }

            if (count($key['devices']) >= $key['max_devices']) {

                echo json_encode(array(
                    'ok' => false,
                    'status' => 'device_limit'
                ));

                exit;
            }

            $key['devices'][] = array(
                'device_id' => $devId,
                'label' => $label,
                'first_login' => $time,
                'last_login' => $time
            );

        } else {

            foreach ($key['devices'] as &$dev) {

                if ($dev['device_id'] === $devId) {
                    $dev['last_login'] = $time;
                    $dev['label'] = $label;
                    break;
                }
            }
        }

        $key['last_used'] = $time;

        saveKey($key);

        echo json_encode(array(
            'ok' => true,
            'status' => 'active',
            'key' => $key['key'],
            'expiry' => $key['expiry'],
            'max_devices' => $key['max_devices'],
            'serverTime' => $time
        ));

        break;

    case 'check':

        $keyVal = isset($req['key']) ? $req['key'] : '';
        $devId = isset($req['device_id']) ? $req['device_id'] : '';

        $time = nowMs();

        if ($keyVal === '' || $devId === '') {

            echo json_encode(array(
                'ok' => false,
                'status' => 'error'
            ));

            exit;
        }

        $key = findKey($keyVal);

        if (!$key) {

            echo json_encode(array(
                'ok' => false,
                'status' => 'invalid_key'
            ));

            exit;
        }

        if ($key['status'] === 'revoked' || $key['status'] === 'paused') {

            echo json_encode(array(
                'ok' => false,
                'status' => $key['status']
            ));

            exit;
        }

        if (
            $key['expiry'] > 0 &&
            $time > $key['expiry']
        ) {

            $key['status'] = 'expired';
            saveKey($key);

            echo json_encode(array(
                'ok' => false,
                'status' => 'expired'
            ));

            exit;
        }

        $linked = false;

        foreach ($key['devices'] as &$dev) {

            if ($dev['device_id'] === $devId) {
                $linked = true;
                $dev['last_login'] = $time;
                break;
            }
        }

        if (!$linked) {

            echo json_encode(array(
                'ok' => false,
                'status' => 'not_linked'
            ));

            exit;
        }

        $key['last_used'] = $time;

        saveKey($key);

        echo json_encode(array(
            'ok' => true,
            'status' => 'active',
            'key' => $key['key'],
            'expiry' => $key['expiry'],
            'serverTime' => $time
        ));

        break;

    case 'keys':

        if (!isAuthed()) {

            echo json_encode(array(
                'ok' => false,
                'error' => 'Unauthorized'
            ));

            exit;
        }

        $keys = getKeys();

        foreach ($keys as &$k) {

            $deviceCount = count($k['devices']);

            $k['device_count'] = $deviceCount;

            if (
                $k['status'] === 'active' &&
                $k['expiry'] > 0 &&
                nowMs() > $k['expiry']
            ) {
                $k['status'] = 'expired';
            }
        }

        echo json_encode(array(
            'ok' => true,
            'keys' => array_values($keys),
            'total' => count($keys)
        ));

        break;

    case 'create_key':

        if (!isAuthed()) {

            echo json_encode(array(
                'ok' => false,
                'error' => 'Unauthorized'
            ));

            exit;
        }

        $maxDev = isset($req['max_devices'])
            ? intval($req['max_devices'])
            : 1;

        $days = isset($req['days'])
            ? intval($req['days'])
            : 30;

        $note = isset($req['note'])
            ? $req['note']
            : '';

        $maxDev = max(1, min(100, $maxDev));

        $time = nowMs();

        $expiry = 0;

        if ($days > 0) {
            $expiry = $time + ($days * 86400000);
        }

        $newKey = generateKey(4, 5);

        saveKey(array(
            'key' => $newKey,
            'status' => 'active',
            'expiry' => $expiry,
            'max_devices' => $maxDev,
            'devices' => array(),
            'note' => $note,
            'created_at' => $time,
            'last_used' => 0
        ));

        echo json_encode(array(
            'ok' => true,
            'key' => $newKey,
            'expiry' => $expiry,
            'max_devices' => $maxDev,
            'days' => $days
        ));

        break;

    case 'update_key':

        if (!isAuthed()) {

            echo json_encode(array(
                'ok' => false,
                'error' => 'Unauthorized'
            ));

            exit;
        }

        $keyVal = isset($req['key']) ? $req['key'] : '';

        if ($keyVal === '') {

            echo json_encode(array(
                'ok' => false,
                'error' => 'Key required'
            ));

            exit;
        }

        $key = findKey($keyVal);

        if (!$key) {

            echo json_encode(array(
                'ok' => false,
                'error' => 'Key not found'
            ));

            exit;
        }

        if (
            isset($req['status']) &&
            (
                $req['status'] === 'active' ||
                $req['status'] === 'paused' ||
                $req['status'] === 'revoked'
            )
        ) {
            $key['status'] = $req['status'];
        }

        if (isset($req['max_devices'])) {

            $key['max_devices'] = max(
                1,
                min(100, intval($req['max_devices']))
            );
        }

        if (isset($req['note'])) {
            $key['note'] = $req['note'];
        }

        if (isset($req['days'])) {

            $days = intval($req['days']);

            if ($days > 0) {
                $key['expiry'] = nowMs() + ($days * 86400000);
            } else {
                $key['expiry'] = 0;
            }
        }

        saveKey($key);

        echo json_encode(array(
            'ok' => true,
            'message' => 'Key updated'
        ));

        break;

    case 'remove_device':

        if (!isAuthed()) {

            echo json_encode(array(
                'ok' => false,
                'error' => 'Unauthorized'
            ));

            exit;
        }

        $keyVal = isset($req['key']) ? $req['key'] : '';
        $devId = isset($req['device_id']) ? $req['device_id'] : '';

        if ($keyVal === '' || $devId === '') {

            echo json_encode(array(
                'ok' => false,
                'error' => 'Missing parameters'
            ));

            exit;
        }

        $key = findKey($keyVal);

        if (!$key) {

            echo json_encode(array(
                'ok' => false,
                'error' => 'Key not found'
            ));

            exit;
        }

        $newDevices = array();

        foreach ($key['devices'] as $d) {

            if ($d['device_id'] !== $devId) {
                $newDevices[] = $d;
            }
        }

        $key['devices'] = array_values($newDevices);

        saveKey($key);

        echo json_encode(array(
            'ok' => true,
            'message' => 'Device removed'
        ));

        break;

    case 'delete_key':

        if (!isAuthed()) {

            echo json_encode(array(
                'ok' => false,
                'error' => 'Unauthorized'
            ));

            exit;
        }

        $keyVal = isset($req['key']) ? $req['key'] : '';

        if ($keyVal === '') {

            echo json_encode(array(
                'ok' => false,
                'error' => 'Key required'
            ));

            exit;
        }

        deleteKeyByValue($keyVal);

        echo json_encode(array(
            'ok' => true,
            'message' => 'Key deleted'
        ));

        break;

    case 'purge':

        if (!isAuthed()) {

            echo json_encode(array(
                'ok' => false,
                'error' => 'Unauthorized'
            ));

            exit;
        }

        saveKeys(array());

        echo json_encode(array(
            'ok' => true,
            'message' => 'All keys deleted'
        ));

        break;

    case 'stats':

        if (!isAuthed()) {

            echo json_encode(array(
                'ok' => false,
                'error' => 'Unauthorized'
            ));

            exit;
        }

        $keys = getKeys();

        $active = 0;
        $expired = 0;
        $paused = 0;
        $revoked = 0;
        $devices = 0;

        $time = nowMs();

        foreach ($keys as $k) {

            $devices += count($k['devices']);

            if ($k['status'] === 'revoked') {
                $revoked++;
            }
            elseif ($k['status'] === 'paused') {
                $paused++;
            }
            elseif (
                $k['expiry'] > 0 &&
                $time > $k['expiry']
            ) {
                $expired++;
            }
            else {
                $active++;
            }
        }

        echo json_encode(array(
            'ok' => true,
            'total_keys' => count($keys),
            'active_keys' => $active,
            'expired_keys' => $expired,
            'paused_keys' => $paused,
            'revoked_keys' => $revoked,
            'total_devices' => $devices
        ));

        break;

    default:

        echo json_encode(array(
            'ok' => false,
            'error' => 'Invalid action'
        ));

        break;
}
?>