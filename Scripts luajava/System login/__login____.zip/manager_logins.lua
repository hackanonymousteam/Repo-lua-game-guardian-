if luajava == nil then
    gg.alert("LuaJava NOT Available!")
    return
end

if not activity then
    gg.alert("No activity available")
    return
end

local LICENSE_URL = "http://0.0.0.0:8081/license.php"
local ADMIN_TOKEN = "MatrixAdmin2026"
local Color = luajava.bindClass("android.graphics.Color")
local Context = luajava.bindClass("android.content.Context")
local Typeface = luajava.bindClass("android.graphics.Typeface")
local GradientDrawable = luajava.bindClass("android.graphics.drawable.GradientDrawable")
local Build = luajava.bindClass("android.os.Build")
local Handler = luajava.bindClass("android.os.Handler")
local Looper = luajava.bindClass("android.os.Looper")
local TypedValue = luajava.bindClass("android.util.TypedValue")
local Gravity = luajava.bindClass("android.view.Gravity")
local View = luajava.bindClass("android.view.View")
local WindowManager = luajava.bindClass("android.view.WindowManager")
local LayoutParams = luajava.bindClass("android.view.WindowManager$LayoutParams")
local LinearLayout = luajava.bindClass("android.widget.LinearLayout")
local LinLayoutParams = luajava.bindClass("android.widget.LinearLayout$LayoutParams")
local TextView = luajava.bindClass("android.widget.TextView")
local EditText = luajava.bindClass("android.widget.EditText")
local Button = luajava.bindClass("android.widget.Button")
local ScrollView = luajava.bindClass("android.widget.ScrollView")
local FrameLayout = luajava.bindClass("android.widget.FrameLayout")
local Runnable = luajava.bindClass("java.lang.Runnable")
local ClipboardManager = luajava.bindClass("android.content.ClipboardManager")
local ClipData = luajava.bindClass("android.content.ClipData")
local InputMethodManager = luajava.bindClass("android.view.inputmethod.InputMethodManager")

local mainHandler = Handler(Looper.getMainLooper())

local JSON_PATH = "/sdcard/json.lua"
local function ensureJson()
    local f = io.open(JSON_PATH, "r")
    if not f then
        local req = gg.makeRequest("https://raw.githubusercontent.com/rxi/json.lua/master/json.lua")
        if req and req.content then
            local out = io.open(JSON_PATH, "w")
            out:write(req.content)
            out:close()
        end
    else f:close() end
end
ensureJson()
local json = loadfile(JSON_PATH)()

local function urlEncode(str)
    return str:gsub("([^%w])", function(c) return string.format("%%%02X", string.byte(c)) end):gsub(" ", "+")
end

local function dp(v)
    return math.floor(TypedValue.applyDimension(1, v, activity.getResources().getDisplayMetrics()))
end

local function getSkin(color, radius, strokeWidth, strokeColor)
    local draw = GradientDrawable()
    draw.setColor(color)
    draw.setCornerRadius(dp(radius))
    if strokeColor then draw.setStroke(dp(strokeWidth or 1), strokeColor) end
    return draw
end
local function getClipboardText()
    local ok, result = pcall(function()

        local clipboard =
            activity.getSystemService(Context.CLIPBOARD_SERVICE)

        if not clipboard then
            return ""
        end

        if not clipboard.hasPrimaryClip() then
            return ""
        end

        local clip = clipboard.getPrimaryClip()

        if not clip then
            return ""
        end

        local item = clip.getItemAt(0)

        if not item then
            return ""
        end

        return tostring(item.getText() or "")

    end)

    if ok then
        return result
    end

    return ""
end
local function copyToClipboard(text)
    if not text or text == "" then
        return
    end

    pcall(function()
        local clipboard = activity.getSystemService(Context.CLIPBOARD_SERVICE)
        local clip = ClipData.newPlainText("text", tostring(text))
        clipboard.setPrimaryClip(clip)
        gg.toast("Copied")
    end)
end

local function showKeyboard(inputField)
    if inputField then
        inputField.requestFocus()
        inputField.post(Runnable({
            run = function()
                local imm = activity.getSystemService(Context.INPUT_METHOD_SERVICE)
                imm.showSoftInput(inputField, InputMethodManager.SHOW_FORCED)
            end
        }))
    end
end

local function apiRequest(params)

    local body = {}

    for k, v in pairs(params) do
        table.insert(body,
            tostring(k) .. "=" .. urlEncode(tostring(v or ""))
        )
    end

    local postData = table.concat(body, "&")

    local req = gg.makeRequest(
        LICENSE_URL,
        nil,
        postData
    )

 --   print(req)

    if not req then
        return {
            ok = false,
            error = "nil request"
        }
    end

    if not req.content then
        return {
            ok = false,
            error = "nil content"
        }
    end

    local ok, result = pcall(function()
        return json.decode(req.content)
    end)

    if not ok then
        return {
            ok = false,
            error = tostring(result)
        }
    end

    return result
end
local function adminRequest(action, extra)
    local params = { action = action, token = ADMIN_TOKEN }
    if extra then
        for k, v in pairs(extra) do params[k] = v end
    end
    return apiRequest(params)
end

local UI = {
    BG = Color.parseColor("#0a0a0a"),
    CARD = Color.parseColor("#16213e"),
    ACCENT = Color.parseColor("#e94560"),
    ACCENT2 = Color.parseColor("#0f3460"),
    TEXT = Color.parseColor("#eaeaea"),
    SUCCESS = Color.parseColor("#4ade80"),
    DANGER = Color.parseColor("#ef4444"),
    WARNING = Color.parseColor("#f59e0b"),
    WHITE = Color.parseColor("#FFFFFF"),
    INPUT_BG = Color.parseColor("#0d1b36"),
}

local WIDTH = 360
local exitApp = false
local menuView = nil
local activeView = nil
local windowManager = nil
local mParams = nil
local keysContainer = nil
local mainContainer = nil

function showCreateKeyScreen()
    if not mainContainer then return end
    
    mainContainer.removeAllViews()
    
    local scroll = ScrollView(activity)
    scroll.setLayoutParams(LinLayoutParams(-1, -1))
    
    local form = LinearLayout(activity)
    form.setOrientation(1)
    form.setPadding(dp(12), dp(12), dp(12), dp(12))
    
    local formTitle = TextView(activity)
    formTitle.setText("CREATE NEW KEY")
    formTitle.setTextColor(UI.ACCENT)
    formTitle.setTextSize(1, 16)
    formTitle.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD))
    formTitle.setPadding(0, 0, 0, dp(16))
    form.addView(formTitle)
    
    local maxDevLabel = createFormLabel("Max logins (1-100):")
    form.addView(maxDevLabel)
    
    local maxDevInput = createFormInput("1", "number")
    form.addView(maxDevInput)
    
    local daysLabel = createFormLabel("Days (0 = lifetime):")
    form.addView(daysLabel)
    
    local daysInput = createFormInput("30", "number")
    form.addView(daysInput)
    
    local noteLabel = createFormLabel("Note (optional):")
    form.addView(noteLabel)
    
    local noteInput = createFormInput("VIP User", "text")
    form.addView(noteInput)
    
    local createStatus = TextView(activity)
    createStatus.setText("")
    createStatus.setTextColor(UI.WARNING)
    createStatus.setTextSize(1, 11)
    createStatus.setGravity(Gravity.CENTER)
    createStatus.setPadding(0, dp(8), 0, dp(8))
    form.addView(createStatus)
    
    local btnRow = LinearLayout(activity)
    btnRow.setOrientation(0)
    btnRow.setPadding(0, dp(8), 0, 0)
    
    local cancelBtn = Button(activity)
    cancelBtn.setText("CANCEL")
    cancelBtn.setTextColor(UI.WHITE)
    cancelBtn.setTextSize(1, 12)
    cancelBtn.setTypeface(Typeface.DEFAULT_BOLD)
    cancelBtn.setBackground(getSkin(UI.ACCENT2, 10))
    local cancelParams = LinLayoutParams(0, dp(44), 1.0)
    cancelParams.rightMargin = dp(6)
    cancelBtn.setLayoutParams(cancelParams)
    cancelBtn.setOnClickListener(View.OnClickListener({ 
        onClick = function() 
            mainContainer.removeAllViews()
            rebuildMainScreen()
            refreshKeys()
        end 
    }))
    btnRow.addView(cancelBtn)
    
    local generateBtn = Button(activity)
    generateBtn.setText("GENERATE KEY")
    generateBtn.setTextColor(UI.WHITE)
    generateBtn.setTextSize(1, 13)
    generateBtn.setTypeface(Typeface.DEFAULT_BOLD)
    generateBtn.setBackground(getSkin(UI.SUCCESS, 10))
    local genParams = LinLayoutParams(0, dp(44), 2.0)
    generateBtn.setLayoutParams(genParams)
    generateBtn.setOnClickListener(View.OnClickListener({
    onClick = function()

        createStatus.setText("Creating key...")
        createStatus.setTextColor(UI.WARNING)

        local Thread = luajava.bindClass("java.lang.Thread")

        Thread(Runnable({
            run = function()

                local maxDev =
                    tonumber(tostring(maxDevInput.getText().toString())) or 1

                local days =
                    tonumber(tostring(daysInput.getText().toString())) or 30

                local note =
                    tostring(noteInput.getText().toString())

                local result = adminRequest("create_key", {
                    max_devices = tostring(maxDev),
                    days = tostring(days),
                    note = note
                })

                mainHandler.post(Runnable({
                    run = function()

                        if result and result.ok then

                            local keyStr = tostring(result.key)

                            copyToClipboard(keyStr)

                            createStatus.setText(
                                "KEY CREATED!\n\n" ..
                                keyStr
                            )

                            createStatus.setTextColor(UI.SUCCESS)

                        else

                            createStatus.setText(
                                "FAILED\n\n" ..
                                tostring(result and result.error)
                            )

                            createStatus.setTextColor(UI.DANGER)
                        end
                    end
                }))
            end
        })).start()
    end
}))
    btnRow.addView(generateBtn)
    
    form.addView(btnRow)
    scroll.addView(form)
    mainContainer.addView(scroll)
    
    showKeyboard(maxDevInput)
end

function showEditKeyScreen(keyData)
    if not mainContainer then return end
    
    mainContainer.removeAllViews()
    
    local scroll = ScrollView(activity)
    scroll.setLayoutParams(LinLayoutParams(-1, -1))
    
    local form = LinearLayout(activity)
    form.setOrientation(1)
    form.setPadding(dp(12), dp(12), dp(12), dp(12))
    
    local formTitle = TextView(activity)
    formTitle.setText("EDIT KEY")
    formTitle.setTextColor(UI.ACCENT)
    formTitle.setTextSize(1, 16)
    formTitle.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD))
    formTitle.setPadding(0, 0, 0, dp(4))
    form.addView(formTitle)
    
    local keyDisplay = TextView(activity)
    keyDisplay.setText(keyData.key)
    keyDisplay.setTextColor(UI.WARNING)
    keyDisplay.setTextSize(1, 10)
    keyDisplay.setPadding(0, 0, 0, dp(12))
    form.addView(keyDisplay)
    
    local statusLabel = createFormLabel("Status (active/paused/revoked):")
    form.addView(statusLabel)
    
    local statusInput = createFormInput(keyData.status or "active", "text")
    form.addView(statusInput)
    
    local maxDevLabel = createFormLabel("Max Devices:")
    form.addView(maxDevLabel)
    
    local maxDevInput = createFormInput(tostring(keyData.max_devices or 1), "number")
    form.addView(maxDevInput)
    
    local daysLabel = createFormLabel("Days from now (0 = lifetime):")
    form.addView(daysLabel)
    
    local remainingDays = ""
    if keyData.expiry and keyData.expiry > 0 then
        local now = os.time() * 1000
        local remaining = keyData.expiry - now
        remainingDays = tostring(math.max(0, math.ceil(remaining / 86400000)))
    else
        remainingDays = "0"
    end
    local daysInput = createFormInput(remainingDays, "number")
    form.addView(daysInput)
    
    local noteLabel = createFormLabel("Note:")
    form.addView(noteLabel)
    
    local noteInput = createFormInput(keyData.note or "", "text")
    form.addView(noteInput)
    
    local editStatus = TextView(activity)
    editStatus.setText("")
    editStatus.setTextColor(UI.WARNING)
    editStatus.setTextSize(1, 11)
    editStatus.setGravity(Gravity.CENTER)
    editStatus.setPadding(0, dp(8), 0, dp(8))
    form.addView(editStatus)
    
    local btnRow = LinearLayout(activity)
    btnRow.setOrientation(0)
    btnRow.setPadding(0, dp(8), 0, 0)
    
    local cancelBtn = Button(activity)
    cancelBtn.setText("CANCEL")
    cancelBtn.setTextColor(UI.WHITE)
    cancelBtn.setTextSize(1, 12)
    cancelBtn.setTypeface(Typeface.DEFAULT_BOLD)
    cancelBtn.setBackground(getSkin(UI.ACCENT2, 10))
    local cancelParams = LinLayoutParams(0, dp(44), 1.0)
    cancelParams.rightMargin = dp(6)
    cancelBtn.setLayoutParams(cancelParams)
    cancelBtn.setOnClickListener(View.OnClickListener({ 
        onClick = function() 
            mainContainer.removeAllViews()
            rebuildMainScreen()
            refreshKeys()
        end 
    }))
    btnRow.addView(cancelBtn)
    
    local saveBtn = Button(activity)
    saveBtn.setText("SAVE CHANGES")
    saveBtn.setTextColor(UI.WHITE)
    saveBtn.setTextSize(1, 13)
    saveBtn.setTypeface(Typeface.DEFAULT_BOLD)
    saveBtn.setBackground(getSkin(Color.parseColor("#3b82f6"), 10))
    local saveParams = LinLayoutParams(0, dp(44), 2.0)
    saveBtn.setLayoutParams(saveParams)
    saveBtn.setOnClickListener(
    View.OnClickListener({
        onClick = function()

            local status =
                tostring(
                    statusInput.getText().toString()
                ):lower()

            local maxDev =
                tonumber(
                    tostring(
                        maxDevInput.getText().toString()
                    )
                ) or 1

            local days =
                tonumber(
                    tostring(
                        daysInput.getText().toString()
                    )
                ) or 0

            local note =
                tostring(
                    noteInput.getText().toString()
                )

            if status ~= "active"
            and status ~= "paused"
            and status ~= "revoked" then

                editStatus.setText(
                    "Invalid status"
                )

                editStatus.setTextColor(
                    UI.DANGER
                )

                return
            end

            maxDev =
                math.max(
                    1,
                    math.min(100, maxDev)
                )

            editStatus.setText(
                "Updating..."
            )

            editStatus.setTextColor(
                UI.WARNING
            )

            local Thread =
                luajava.bindClass(
                    "java.lang.Thread"
                )

            Thread(Runnable({
                run = function()

                    local result =
                        adminRequest(
                            "update_key",
                            {
                                key = tostring(keyData.key),
                                status = status,
                                max_devices = tostring(maxDev),
                                days = tostring(days),
                                note = note
                            }
                        )

                    mainHandler.post(
                        Runnable({
                            run = function()

                                if result and result.ok then

                                    editStatus.setText(
                                        "Updated"
                                    )

                                    editStatus.setTextColor(
                                        UI.SUCCESS
                                    )

                                    mainHandler.postDelayed(
                                        Runnable({
                                            run = function()

                                                mainContainer.removeAllViews()

                                                rebuildMainScreen()

                                                refreshKeys()

                                            end
                                        }),
                                        1000
                                    )

                                else

                                    local err =
                                        tostring(
                                            result and result.error
                                            or "unknown"
                                        )

                                    editStatus.setText(
                                        err
                                    )

                                    editStatus.setTextColor(
                                        UI.DANGER
                                    )

                                end

                            end
                        })
                    )

                end
            })).start()

        end
    })
)
    btnRow.addView(saveBtn)
    
    form.addView(btnRow)
    scroll.addView(form)
    mainContainer.addView(scroll)
end

function showRemoveDeviceScreen(keyValue, devices)
    if not mainContainer then return end
    
    mainContainer.removeAllViews()
    
    local scroll = ScrollView(activity)
    scroll.setLayoutParams(LinLayoutParams(-1, -1))
    
    local container = LinearLayout(activity)
    container.setOrientation(1)
    container.setPadding(dp(12), dp(12), dp(12), dp(12))
    
    local formTitle = TextView(activity)
    formTitle.setText("REMOVE DEVICE")
    formTitle.setTextColor(UI.DANGER)
    formTitle.setTextSize(1, 16)
    formTitle.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD))
    formTitle.setPadding(0, 0, 0, dp(12))
    container.addView(formTitle)
    
    local keyLabel = TextView(activity)
    keyLabel.setText("Key: " .. keyValue)
    keyLabel.setTextColor(UI.TEXT)
    keyLabel.setTextSize(1, 10)
    keyLabel.setAlpha(0.5)
    keyLabel.setPadding(0, 0, 0, dp(12))
    container.addView(keyLabel)
    
    if not devices or #devices == 0 then
        local noDev = TextView(activity)
        noDev.setText("No devices linked to this key")
        noDev.setTextColor(UI.TEXT)
        noDev.setTextSize(1, 12)
        noDev.setGravity(Gravity.CENTER)
        noDev.setPadding(0, dp(20), 0, dp(20))
        container.addView(noDev)
    else
        local devIdLabel = createFormLabel("Device ID to remove:")
        container.addView(devIdLabel)
        
        local devIdInput = createFormInput("", "text")
        devIdInput.setHint("Enter full device ID")
        devIdInput.setHintTextColor(Color.parseColor("#444444"))
        container.addView(devIdInput)
        
        local devListLabel = TextView(activity)
        devListLabel.setText("Linked devices:")
        devListLabel.setTextColor(UI.TEXT)
        devListLabel.setTextSize(1, 10)
        devListLabel.setAlpha(0.6)
        devListLabel.setPadding(0, dp(12), 0, dp(4))
        container.addView(devListLabel)
        
        for _, dev in ipairs(devices) do
            local devItem = TextView(activity)
            devItem.setText("" .. (dev.label or "Unknown") .. "\n  " .. dev.device_id)
            devItem.setTextColor(UI.TEXT)
            devItem.setTextSize(1, 8)
            devItem.setAlpha(0.5)
            devItem.setPadding(dp(8), dp(4), 0, dp(4))
            devItem.setOnClickListener(View.OnClickListener({
                onClick = function()
                    devIdInput.setText(dev.device_id)
                end
            }))
            container.addView(devItem)
        end
        
        local removeStatus = TextView(activity)
        removeStatus.setText("")
        removeStatus.setTextColor(UI.WARNING)
        removeStatus.setTextSize(1, 11)
        removeStatus.setGravity(Gravity.CENTER)
        removeStatus.setPadding(0, dp(8), 0, dp(8))
        container.addView(removeStatus)
        
        local btnRow = LinearLayout(activity)
        btnRow.setOrientation(0)
        btnRow.setPadding(0, dp(8), 0, 0)
        
        local cancelBtn = Button(activity)
        cancelBtn.setText("CANCEL")
        cancelBtn.setTextColor(UI.WHITE)
        cancelBtn.setTextSize(1, 12)
        cancelBtn.setTypeface(Typeface.DEFAULT_BOLD)
        cancelBtn.setBackground(getSkin(UI.ACCENT2, 10))
        local cancelParams = LinLayoutParams(0, dp(44), 1.0)
        cancelParams.rightMargin = dp(6)
        cancelBtn.setLayoutParams(cancelParams)
        cancelBtn.setOnClickListener(View.OnClickListener({ 
            onClick = function() 
                mainContainer.removeAllViews()
                rebuildMainScreen()
                refreshKeys()
            end 
        }))
        btnRow.addView(cancelBtn)
        
        local removeBtn = Button(activity)
        removeBtn.setText("REMOVE DEVICE")
        removeBtn.setTextColor(UI.WHITE)
        removeBtn.setTextSize(1, 13)
        removeBtn.setTypeface(Typeface.DEFAULT_BOLD)
        removeBtn.setBackground(getSkin(UI.DANGER, 10))
        local remParams = LinLayoutParams(0, dp(44), 2.0)
        removeBtn.setLayoutParams(remParams)
        removeBtn.setOnClickListener(View.OnClickListener({ 
            onClick = function()
                local devId = devIdInput.getText().toString():gsub("%s+", "")
                
                if devId == "" then
                    removeStatus.setText("Enter a device ID!")
                    removeStatus.setTextColor(UI.WARNING)
                    return
                end
                
                removeStatus.setText("Removing device...")
                removeStatus.setTextColor(UI.WARNING)
                
                local result = adminRequest("remove_device", {
                    key = keyValue,
                    device_id = devId
                })
                
                if result and result.ok then
                    removeStatus.setText("Device removed!")
                    removeStatus.setTextColor(UI.SUCCESS)
                    
                    Handler():postDelayed(Runnable({
                        run = function()
                            mainContainer.removeAllViews()
                            rebuildMainScreen()
                            refreshKeys()
                        end
                    }), 1500)
                else
                    removeStatus.setText("Failed to remove device")
                    removeStatus.setTextColor(UI.DANGER)
                end
            end 
        }))
        btnRow.addView(removeBtn)
        
        container.addView(btnRow)
    end
    
    local backBtn = Button(activity)
    backBtn.setText("BACK TO LIST")
    backBtn.setTextColor(UI.WHITE)
    backBtn.setTextSize(1, 12)
    backBtn.setBackground(getSkin(UI.ACCENT2, 10))
    local backParams = LinLayoutParams(-1, dp(44))
    backParams.topMargin = dp(12)
    backBtn.setLayoutParams(backParams)
    backBtn.setOnClickListener(View.OnClickListener({ 
        onClick = function() 
            mainContainer.removeAllViews()
            rebuildMainScreen()
            refreshKeys()
        end 
    }))
    container.addView(backBtn)
    
    scroll.addView(container)
    mainContainer.addView(scroll)
end

function createFormLabel(text)
    local label = TextView(activity)
    label.setText(text)
    label.setTextColor(UI.TEXT)
    label.setTextSize(1, 12)
    label.setTypeface(Typeface.DEFAULT_BOLD)
    label.setPadding(0, dp(8), 0, dp(4))
    return label
end

function createFormInput(defaultText, inputType)
    local input = EditText(activity)
    input.setText(defaultText or "")
    input.setTextColor(UI.TEXT)
    input.setTextSize(1, 13)
    input.setBackground(getSkin(UI.INPUT_BG, 8, 1, UI.ACCENT))
    input.setPadding(dp(12), dp(10), dp(12), dp(10))
    input.setSingleLine(true)
    
    if inputType == "number" then
        input.setInputType(2)
    end
    
    local inputParams = LinLayoutParams(-1, dp(44))
    inputParams.bottomMargin = dp(6)
    input.setLayoutParams(inputParams)
    
    return input
end

function createNewKey()
    showCreateKeyScreen()
end

function editKey(keyData)
    showEditKeyScreen(keyData)
end

function removeDeviceFromKey(keyValue, devices)
    showRemoveDeviceScreen(keyValue, devices)
end

function deleteKeyConfirm(keyValue)

    

    local Thread = luajava.bindClass("java.lang.Thread")

    Thread(Runnable({
        run = function()

            local result =
                adminRequest("delete_key", {
                    key = keyValue
                })

            mainHandler.post(Runnable({
                run = function()

                    if result and result.ok then
                        gg.toast("Deleted")
                        refreshKeys()
                    else
                        gg.toast("Delete failed")
                    end

                end
            }))

        end
    })).start()
end

function purgeAllKeys()

    local res = gg.choice({
        "PURGE ALL KEYS",
        "Cancel"
    }, nil, "DELETE EVERYTHING")

    if res ~= 1 then
        return
    end

    local Thread = luajava.bindClass("java.lang.Thread")

    Thread(Runnable({
        run = function()

            local result =
                adminRequest("purge")

            mainHandler.post(Runnable({
                run = function()

                    if result and result.ok then
                        gg.toast("Purged")
                        refreshKeys()
                    else
                        gg.toast("Purge failed")
                    end

                end
            }))

        end
    })).start()
end
function refreshKeys()

    if not keysContainer then
        return
    end

    local Thread = luajava.bindClass("java.lang.Thread")

    Thread(Runnable({
        run = function()

            local result =
                adminRequest("keys")

            mainHandler.post(Runnable({
                run = function()

                    if not result or not result.keys then
                        gg.toast("Load failed")
                        return
                    end

                    keysContainer.removeAllViews()

                    local keys = result.keys

                    if #keys == 0 then

                        local empty = TextView(activity)

                        empty.setText(
                            "No keys yet"
                        )

                        empty.setTextColor(UI.TEXT)
                        empty.setTextSize(1, 13)
                        empty.setGravity(Gravity.CENTER)
                        empty.setPadding(
                            0,
                            dp(40),
                            0,
                            dp(40)
                        )

                        keysContainer.addView(empty)

                        return
                    end

                    for _, key in ipairs(keys) do

                        local card = LinearLayout(activity)

                        card.setOrientation(1)

                        local borderColor = UI.SUCCESS

                        if key.status == "expired" then
                            borderColor = UI.DANGER
                        elseif key.status == "paused" then
                            borderColor = UI.WARNING
                        elseif key.status == "revoked" then
                            borderColor = Color.parseColor("#666666")
                        end

                        card.setBackground(
                            getSkin(UI.CARD, 8, 1, borderColor)
                        )

                        card.setPadding(
                            dp(10),
                            dp(8),
                            dp(10),
                            dp(8)
                        )

                        local cp = LinLayoutParams(-1, -2)

                        cp.bottomMargin = dp(8)

                        card.setLayoutParams(cp)

                        local keyText = TextView(activity)

                        keyText.setText(key.key)

                        keyText.setTextColor(UI.ACCENT)

                        keyText.setTextSize(1, 11)

                        card.addView(keyText)

                        if key.devices then

                            for _, dev in ipairs(key.devices) do

                                local devRow =
                                    TextView(activity)

                                devRow.setText(
                                    dev.device_id
                                )

                                devRow.setTextColor(UI.TEXT)

                                devRow.setTextSize(1, 8)

                                devRow.setPadding(
                                    dp(6),
                                    dp(2),
                                    0,
                                    dp(2)
                                )

                                devRow.setOnClickListener(
                                    View.OnClickListener({
                                        onClick = function()
                                            copyToClipboard(
                                                dev.device_id
                                            )
                                        end
                                    })
                                )

                                card.addView(devRow)

                            end
                        end

                        local actions =
                            LinearLayout(activity)

                        actions.setOrientation(0)

                        local editBtn =
                            createMiniBtn(
                                "EDIT",
                                Color.parseColor("#3b82f6"),
                                function()
                                    editKey(key)
                                end
                            )

                        actions.addView(editBtn)

                        local remBtn =
                            createMiniBtn(
                                "REM",
                                UI.WARNING,
                                function()
                                    removeDeviceFromKey(
                                        key.key,
                                        key.devices
                                    )
                                end
                            )

                       -- actions.addView(remBtn)

                        local delBtn =
                            createMiniBtn(
                                "DEL",
                                UI.DANGER,
                                function()
                                    deleteKeyConfirm(
                                        key.key
                                    )
                                end
                            )

                        actions.addView(delBtn)

                        card.addView(actions)

                        keysContainer.addView(card)

                    end

                end
            }))

        end
    })).start()
end
function createMiniBtn(text, color, onClick)
    local btn = Button(activity)
    btn.setText(text)
    btn.setTextColor(UI.WHITE)
    btn.setTextSize(1, 8)
    btn.setBackground(getSkin(color, 5))
    btn.setPadding(dp(6), dp(4), dp(6), dp(4))
    local bp = LinLayoutParams(-2, dp(26))
    bp.rightMargin = dp(3)
    btn.setLayoutParams(bp)
    btn.setOnClickListener(View.OnClickListener({ onClick = onClick }))
    return btn
end

function rebuildMainScreen()
    local header = LinearLayout(activity)
    header.setOrientation(0)
    header.setGravity(Gravity.CENTER_VERTICAL)
    
    local title = TextView(activity)
    title.setText("MATRIX ADMIN")
    title.setTextColor(UI.ACCENT)
    title.setTextSize(1, 16)
    title.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD))
    title.setLayoutParams(LinLayoutParams(0, -2, 1.0))
    header.addView(title)
    
    local closeBtn = TextView(activity)
    closeBtn.setText("X")
    closeBtn.setTextSize(1, 16)
    closeBtn.setTextColor(UI.TEXT)
    closeBtn.setBackground(getSkin(UI.ACCENT2, 8))
    closeBtn.setPadding(dp(10), dp(4), dp(10), dp(4))
    closeBtn.setFocusable(true)
    closeBtn.setClickable(true)
    closeBtn.setOnClickListener(View.OnClickListener({ onClick = function() exitApp = true end }))
    header.addView(closeBtn)
    mainContainer.addView(header)
    
    local div1 = View(activity)
    local div1Params = LinLayoutParams(-1, dp(1))
    div1Params.topMargin = dp(8)
    div1.setLayoutParams(div1Params)
    div1.setBackgroundColor(UI.ACCENT)
    div1.setAlpha(0.3)
    mainContainer.addView(div1)
    
    local actionBar = LinearLayout(activity)
    actionBar.setOrientation(0)
    actionBar.setPadding(0, dp(8), 0, dp(8))
    
    local createBtn = Button(activity)
    createBtn.setText("NEW KEY")
    createBtn.setTextColor(UI.WHITE)
    createBtn.setTextSize(1, 12)
    createBtn.setTypeface(Typeface.DEFAULT_BOLD)
    createBtn.setBackground(getSkin(UI.SUCCESS, 10))
    local cbParams = LinLayoutParams(0, dp(40), 1.0)
    cbParams.rightMargin = dp(6)
    createBtn.setLayoutParams(cbParams)
    createBtn.setOnClickListener(View.OnClickListener({ onClick = function() createNewKey() end }))
    actionBar.addView(createBtn)
    
    local refreshBtn = Button(activity)
    refreshBtn.setText("REFRESH")
    refreshBtn.setTextColor(UI.WHITE)
    refreshBtn.setTextSize(1, 14)
    refreshBtn.setBackground(getSkin(UI.ACCENT, 10))
    local rbParams = LinLayoutParams(dp(50), dp(40))
    rbParams.rightMargin = dp(6)
    refreshBtn.setLayoutParams(rbParams)
    refreshBtn.setOnClickListener(View.OnClickListener({ onClick = function() refreshKeys() end }))
    actionBar.addView(refreshBtn)
    
    local purgeBtn = Button(activity)
    purgeBtn.setText("PURGE")
    purgeBtn.setTextColor(UI.WHITE)
    purgeBtn.setTextSize(1, 14)
    purgeBtn.setBackground(getSkin(UI.DANGER, 10))
    purgeBtn.setLayoutParams(LinLayoutParams(dp(50), dp(40)))
    purgeBtn.setOnClickListener(View.OnClickListener({ onClick = function() purgeAllKeys() end }))
  --  actionBar.addView(purgeBtn)
    
    mainContainer.addView(actionBar)
    
    local div2 = View(activity)
    div2.setLayoutParams(LinLayoutParams(-1, dp(1)))
    div2.setBackgroundColor(UI.ACCENT)
    div2.setAlpha(0.3)
    mainContainer.addView(div2)
    
    local scroll = ScrollView(activity)
    scroll.setLayoutParams(LinLayoutParams(-1, dp(370)))
    
    keysContainer = LinearLayout(activity)
    keysContainer.setOrientation(1)
    keysContainer.setPadding(0, dp(6), 0, 0)
    scroll.addView(keysContainer)
    mainContainer.addView(scroll)
end

function createManagerScreen()
    local root = FrameLayout(activity)
    root.setLayoutParams(FrameLayout.LayoutParams(dp(WIDTH), dp(500)))
    
    mainContainer = LinearLayout(activity)
    mainContainer.setOrientation(1)
    mainContainer.setBackground(getSkin(UI.BG, 15, 2, UI.ACCENT))
    mainContainer.setPadding(dp(12), dp(12), dp(12), dp(12))
    mainContainer.setLayoutParams(FrameLayout.LayoutParams(-1, -1))
    
    rebuildMainScreen()
    
    root.addView(mainContainer)
    
    refreshKeys()
    
    return root
end

function initUI()
    windowManager = activity.getSystemService(Context.WINDOW_SERVICE)
    
    local layoutType = (Build.VERSION.SDK_INT >= 26) and
        LayoutParams.TYPE_APPLICATION_OVERLAY or
        LayoutParams.TYPE_PHONE
    
    mParams = LayoutParams(dp(WIDTH), dp(500), layoutType, 0, -3)
    mParams.gravity = Gravity.TOP | Gravity.LEFT
    mParams.x, mParams.y = 40, 80
    
    menuView = createManagerScreen()
    
    mainHandler.post(function()
        pcall(function() windowManager.addView(menuView, mParams) end)
        activeView = menuView
    end)
end

function closeUI()
    mainHandler.post(function()
        pcall(function()
            if activeView and windowManager then
                windowManager.removeView(activeView)
            end
        end)
    end)
end

initUI()

while true do
    if exitApp then
        closeUI()
        break
    end
    if gg.isVisible(true) then gg.setVisible(false) end
    gg.sleep(100)
end