local SERVER_URL = "https://batmangamesdev.x10.mx//api.php" --your server here
local SCRIPT_VERSION = "1.0"
gg.setVisible(false)
gg.clearResults()

local json = nil
if not pcall(function()
    json = load(gg.makeRequest("https://raw.githubusercontent.com/rxi/json.lua/master/json.lua").content)()
end) then
    json = require("json") or 
    (function()
        gg.toast("JSON library not available")
        return nil
    end)()
end

if not json then
    gg.alert("error")
    os.exit()
end

local serverData = {
    functions = {},
    messages = {},
    connected = false
}

local function httpRequest(action, params)
    local url = SERVER_URL .. "?action=" .. action
    local postData = ""
    if params then
        local parts = {}
        for k, v in pairs(params) do
            table.insert(parts, k .. "=" .. gg.urldecode(tostring(v)))
        end
        postData = table.concat(parts, "&")
    end
    
    local response = gg.makeRequest(url, {
        ["Content-Type"] = "application/x-www-form-urlencoded",
        ["User-Agent"] = "LuaGG/1.0"
    }, postData)
    
    if not response or response.code ~= 200 then
        return nil
    end
    
    local success, data = pcall(json.decode, response.content)
    if not success then
        return nil
    end
    
    return data
end

local function loadServerData()
    local testData = httpRequest("test", nil)
    if not testData or not testData.success then
        gg.toast("Server offline")
        return false
    end
    
    serverData.connected = true
    gg.toast("Server online")
    
    local funcData = httpRequest("get_available_functions", nil)
    if funcData and funcData.success and funcData.functions then
        serverData.functions = funcData.functions
       -- gg.toast("Loaded " .. #serverData.functions .. " functions")
    end
    
    return true
end

local function createDynamicHTML()
    local functionsHTML = ""
    if #serverData.functions > 0 then
        for i, func in ipairs(serverData.functions) do
            local funcName = func.name or "Unnamed"
            local funcDesc = func.description or "No description"
            local funcId = func.id or ("func_" .. i)
            local funcVersion = func.version or "1.0"
            
            functionsHTML = functionsHTML .. [[
                <div class="function-card">
                    <div class="function-title">
                        ]] .. funcName .. [[
                        <span class="function-version">v]] .. funcVersion .. [[</span>
                    </div>
                    <div class="function-desc">]] .. funcDesc .. [[</div>
                </div>
            ]]
        end
    else
        functionsHTML = [[
            <div style="grid-column: 1 / -1; text-align: center; padding: 30px; color: #aaa;">
                No functions available
            </div>
        ]]
    end
    
    local connectionStatus = serverData.connected and "success" or "error"
    local connectionText = serverData.connected and 
        "Connected - " .. #serverData.functions .. " alerts loaded" or 
        "Server offline"
    
    local HTML_CONTENT = [[
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LuaGG System</title>
    <style>
        body {
            margin: 0;
            padding: 15px;
            background: linear-gradient(135deg, #0f0c29, #302b63);
            color: white;
            font-family: Arial, sans-serif;
            height: 100%;
        }
        .container {
            display: flex;
            flex-direction: column;
            height: 100%;
        }
        .header {
            text-align: center;
            padding: 15px;
            background: rgba(20, 20, 40, 0.9);
            border-radius: 10px;
            margin-bottom: 15px;
            border: 2px solid #6c63ff;
        }
        .logo {
            font-size: 20px;
            color: #6c63ff;
            font-weight: bold;
        }
        .tabs {
            display: flex;
            margin-bottom: 15px;
            background: rgba(0,0,0,0.3);
            border-radius: 8px;
            padding: 5px;
        }
        .tab {
            flex: 1;
            padding: 12px;
            background: transparent;
            border: none;
            color: #aaa;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
        }
        .tab.active {
            background: #6c63ff;
            color: white;
        }
        .content-area {
            flex: 1;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }
        .tab-content {
            display: none;
            flex: 1;
            overflow: hidden;
            flex-direction: column;
        }
        .tab-content.active {
            display: flex;
        }
        .function-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
            overflow-y: auto;
            padding: 10px;
            flex: 1;
        }
        .function-card {
            background: rgba(40, 40, 80, 0.8);
            border-radius: 10px;
            padding: 15px;
            border: 1px solid rgba(108, 99, 255, 0.5);
            transition: transform 0.2s;
        }
        .function-card:hover {
            transform: translateY(-3px);
            border-color: #6c63ff;
        }
        .function-title {
            font-size: 16px;
            color: #a4a1ff;
            margin-bottom: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .function-desc {
            font-size: 13px;
            color: #ccc;
            margin-bottom: 12px;
            min-height: 40px;
        }
        .function-version {
            font-size: 11px;
            color: #6c63ff;
            background: rgba(108, 99, 255, 0.2);
            padding: 2px 8px;
            border-radius: 10px;
        }
        .chat-container {
            flex: 1;
            overflow-y: auto;
            background: rgba(0,0,0,0.2);
            border-radius: 8px;
            padding: 10px;
            margin-bottom: 10px;
        }
        .message {
            background: rgba(108, 99, 255, 0.1);
            border-radius: 8px;
            padding: 10px;
            margin-bottom: 10px;
            border-left: 4px solid #6c63ff;
        }
        .message-header {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #a4a1ff;
            margin-bottom: 5px;
        }
        input, textarea {
            width: 100%;
            padding: 12px;
            margin: 5px 0;
            border-radius: 6px;
            border: 1px solid #6c63ff;
            background: rgba(255,255,255,0.1);
            color: white;
            font-size: 14px;
        }
        button {
            padding: 12px;
            background: #6c63ff;
            color: white;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background: #5a52e0;
        }
        .status-box {
            padding: 12px;
            border-radius: 8px;
            margin: 10px 0;
            text-align: center;
            background: rgba(108, 99, 255, 0.2);
            font-size: 14px;
        }
        .success {
            background: rgba(76, 255, 136, 0.2);
            color: #4dff88;
        }
        .error {
            background: rgba(255, 107, 107, 0.2);
            color: #ff6b6b;
        }
        #loading {
            display: none;
            text-align: center;
            padding: 20px;
            color: #a4a1ff;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="logo">LuaGG Alert v]] .. SCRIPT_VERSION .. [[</div>
            <div style="font-size: 12px; color: #aaa;">Online GG alert notification system</div>
        </div>
        
        <div class="content-area">
            <div id="functions-tab" class="tab-content active">
                <div style="color: #a4a1ff; margin-bottom: 15px; font-size: 16px; font-weight: bold;">
                    Available Alerts
                </div>
                <div class="function-grid" id="functionsGrid">
                    ]] .. functionsHTML .. [[
                </div>
                <div id="loading">
                    Executing function...
                </div>
            </div>
        </div>
        
        <div class="status-box ]] .. connectionStatus .. [[">
            ]] .. connectionText .. [[
        </div>
    </div>
    
    <script>
        function showTab(tabName) {
            document.querySelectorAll('.tab-content').forEach(el => {
                el.classList.remove('active');
            });
            document.querySelectorAll('.tab').forEach(el => {
                el.classList.remove('active');
            });
            
            document.getElementById(tabName + '-tab').classList.add('active');
            event.target.classList.add('active');
            
            if (tabName === 'chat') {
                setTimeout(() => {
                    const chat = document.querySelector('.chat-container');
                    if (chat) chat.scrollTop = chat.scrollHeight;
                }, 100);
            }
        }
        
        function executeLuaFunction(funcId) {
            console.log('Executing function:', funcId);
            
            document.getElementById('loading').style.display = 'block';
            
            window.LuaInterface.executeFunction(funcId);
            
            setTimeout(() => {
                document.getElementById('loading').style.display = 'none';
            }, 2000);
        }
        
        function sendChatMessage() {
            const input = document.getElementById('chatInput');
            const nameInput = document.getElementById('chatName');
            const message = input.value.trim();
            const username = nameInput.value.trim() || 'Anonymous';
            
            if (!message) {
                alert('Enter a message!');
                return;
            }
            
            window.LuaInterface.sendMessage(message, username);
            input.value = '';
        }
        
        console.log('Interface loaded');
    </script>
</body>
</html>
]]
    
    return HTML_CONTENT
end

local function createWebView()
    local htmlContent = createDynamicHTML()
    
    activity.runOnUiThread(luajava.createProxy("java.lang.Runnable", {
        run = function()
            local Context = luajava.bindClass("android.content.Context")
            local WindowManagerLayoutParams = luajava.bindClass("android.view.WindowManager$LayoutParams")
            local Gravity = luajava.bindClass("android.view.Gravity")
            local Build = luajava.bindClass("android.os.Build")
            local Color = luajava.bindClass("android.graphics.Color")
            local FrameLayout = luajava.bindClass("android.widget.FrameLayout")
            local WebView = luajava.bindClass("android.webkit.WebView")
            local WebSettings = luajava.bindClass("android.webkit.WebSettings")
            local WebChromeClient = luajava.bindClass("android.webkit.WebChromeClient")
            local Button = luajava.bindClass("android.widget.Button")
            
            local wm = activity.getSystemService(Context.WINDOW_SERVICE)
            
            local mainLayout = FrameLayout(activity)
            mainLayout.setBackgroundColor(Color.TRANSPARENT)
            
            local webView = WebView(activity)
            
            local webSettings = webView.getSettings()
            webSettings.setJavaScriptEnabled(true)
            webSettings.setDomStorageEnabled(true)
            webSettings.setLoadWithOverviewMode(true)
            webSettings.setUseWideViewPort(true)
            
            if Build.VERSION.SDK_INT >= 19 then
                WebView.setWebContentsDebuggingEnabled(true)
            end
            
            webView.addJavascriptInterface({
                executeFunction = function(funcId)
                    local thread = luajava.newInstance("java.lang.Thread", luajava.createProxy("java.lang.Runnable", {
                        run = function()
                            local code = getFunctionCode(funcId)
                            
                            if code then
                                local success = executeFunctionCode(code)
                                
                                activity.runOnUiThread(luajava.createProxy("java.lang.Runnable", {
                                    run = function()
                                        if success then
                                            webView.loadUrl("javascript:(function(){alert('Function executed successfully!');})()")
                                        else
                                            webView.loadUrl("javascript:(function(){alert('Error executing function');})()")
                                        end
                                    end
                                }))
                            else
                                activity.runOnUiThread(luajava.createProxy("java.lang.Runnable", {
                                    run = function()
                                        webView.loadUrl("javascript:(function(){alert('Function not found');})()")
                                    end
                                }))
                            end
                        end
                    }))
                    
                    thread:start()
                end,
                
                sendMessage = function(message, username)
                    local thread = luajava.newInstance("java.lang.Thread", luajava.createProxy("java.lang.Runnable", {
                        run = function()
                            local success = sendChatMessage(message, username)
                            activity.runOnUiThread(luajava.createProxy("java.lang.Runnable", {
                                run = function()
                                    if success then
                                        webView.loadUrl("javascript:(function(){alert('Message sent!');})()")
                                    else
                                        webView.loadUrl("javascript:(function(){alert('Error sending message');})()")
                                    end
                                end
                            }))
                        end
                    }))
                    thread:start()
                end
            }, "LuaInterface")
            
            webView.loadDataWithBaseURL(
                nil,
                htmlContent,
                "text/html",
                "UTF-8",
                nil
            )
            
            local layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            mainLayout.addView(webView, layoutParams)
            
            local closeBtn = Button(activity)
            closeBtn.setText("x")
            closeBtn.setTextColor(Color.WHITE)
            closeBtn.setBackgroundColor(Color.parseColor("#FF5252"))
            closeBtn.setTextSize(12)
            closeBtn.setOnClickListener(luajava.createProxy("android.view.View$OnClickListener", {
                onClick = function(view)
                    wm.removeView(mainLayout)
                    gg.toast("System closed")
                    os.exit()
                end
            }))
            
            local btnParams = FrameLayout.LayoutParams(
                60, 60,
                Gravity.TOP | Gravity.RIGHT
            )
            btnParams.topMargin = 20
            btnParams.rightMargin = 20
            mainLayout.addView(closeBtn, btnParams)
            
            local lp = WindowManagerLayoutParams()
            
            if Build.VERSION.SDK_INT >= 26 then
                lp.type = 2038
            else
                lp.type = 2002
            end
            
            local display = activity.getWindowManager().getDefaultDisplay()
            local size = luajava.newInstance("android.graphics.Point")
            display.getSize(size)
            
            lp.width = math.floor(size.x * 0.85)
            lp.height = math.floor(size.y * 0.45)
            
            lp.format = 1
            lp.flags = WindowManagerLayoutParams.FLAG_NOT_FOCUSABLE |
                       WindowManagerLayoutParams.FLAG_LAYOUT_IN_SCREEN |
                       WindowManagerLayoutParams.FLAG_DIM_BEHIND
            
            lp.dimAmount = 0.5
            lp.gravity = Gravity.CENTER
            
            wm.addView(mainLayout, lp)
        end
    }))
end

local loaded = loadServerData()

if loaded then
    createWebView()
else
    createWebView()
end

gg.toast("Click X to quit")