<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$action = $_GET['action'] ?? 'test';

$response = ['success' => true];

switch ($action) {
    case 'test':
        $response['message'] = 'API Online';
        break;
        
    case 'get_available_functions':
        $response['functions'] = [
            [
                'id' => 'func_test',
                'name' => 'Test  Alert online by Batman',
                'description' => 'design alert lua java',
                'version' => '1.0'
            ]

        ];
        break;
        
    case 'get_function':
        $funcId = $_POST['func_id'] ?? '';
        

        
    default:
        $response['success'] = false;
        $response['error'] = 'null';
}

echo json_encode($response);