import "android.app.Service"
import "android.content.Intent"
import "android.content.Context"
import "android.os.IBinder"
import "android.os.Environment"
import "java.io.File"
import "java.io.FileInputStream"
import "java.io.FileOutputStream"

local Class = luajava.bindClass
local new = luajava.new
local astable = luajava.astable

print("7. android.app.Service - Working Operations:")

local success, error = pcall(function()
local Service = Class("android.app.Service")
local Intent = Class("android.content.Intent")
local Context = Class("android.content.Context")
local Environment = Class("android.os.Environment")

local context = activity

if not context then
print("   ❌ Could not get context")
return
end

print("   📱 Context obtained successfully")
print("     Package name:", context:getPackageName())

local appContext = context:getApplicationContext()
print("\n   📱 Application Context:")
print("     Package name:", appContext:getPackageName())
print("     Cache dir:", appContext:getCacheDir():getAbsolutePath())
print("     Files dir:", appContext:getFilesDir():getAbsolutePath())

print("\n   📁 Directory Operations:")

local dirs = {
{"Data Dir", context:getDataDir()},
{"Files Dir", context:getFilesDir()},
{"Cache Dir", context:getCacheDir()},
{"Code Cache", context:getCodeCacheDir()},
{"No Backup", context:getNoBackupFilesDir()},
{"Obb Dir", context:getObbDir()},
{"External Cache", context:getExternalCacheDir()},
{"External Files", context:getExternalFilesDir(nil)},
}

for i, dirInfo in ipairs(dirs) do
local name, dir = dirInfo[1], dirInfo[2]
if dir then
print(string.format("     %s:", name))
print(string.format("       Path: %s", dir:getAbsolutePath()))
print(string.format("       Exists: %s", dir:exists() and "✅" or "❌"))
print(string.format("       Can read: %s", dir:canRead() and "✅" or "❌"))
print(string.format("       Can write: %s", dir:canWrite() and "✅" or "❌"))
end
end

local mediaDirs = context:getExternalMediaDirs()
if mediaDirs and #mediaDirs > 0 then
print("\n   📀 External Media Dirs:")
for i, dir in ipairs(astable(mediaDirs)) do
print(string.format("     %d: %s", i, dir:getAbsolutePath()))
end
end

local files = context:fileList()
if files and #files > 0 then
print("\n   📋 Files in app directory:")
for i, file in ipairs(astable(files)) do
print(string.format("     %d. %s", i, file))

local readSuccess, content = pcall(function()
local fis = context:openFileInput(file)
local buffer = luajava.newInstance("byte[]", 1024)
local bytesRead = fis:read(buffer)
fis:close()

if bytesRead > 0 then
local result = {}
for j = 1, bytesRead do
table.insert(result, string.char(buffer[j - 1]))
end
return table.concat(result)
end
return ""
end)

if readSuccess and content and content ~= "" then
print("         Content: " .. content:sub(1, 50) .. (content:len() > 50 and "..." or ""))
end
end
end

print("\n   🔐 Permission Checks:")

local permissions = {
"android.permission.READ_EXTERNAL_STORAGE",
"android.permission.WRITE_EXTERNAL_STORAGE",
"android.permission.INTERNET",
"android.permission.ACCESS_NETWORK_STATE",
}

for i, perm in ipairs(permissions) do
local result = context:checkSelfPermission(perm)
print(string.format("     %s: %s", perm, result == 0 and "✅ Granted" or "❌ Denied"))
end

local callingPerm = context:checkCallingPermission("android.permission.INTERNET")
print("     Calling permission (INTERNET):", callingPerm == 0 and "✅" or "❌")

print("\n   🛠️  System Services:")

local services = {
{"Activity", Context.ACTIVITY_SERVICE},
{"Notification", Context.NOTIFICATION_SERVICE},
{"Alarm", Context.ALARM_SERVICE},
{"Connectivity", Context.CONNECTIVITY_SERVICE},
{"Power", Context.POWER_SERVICE},
{"Download", Context.DOWNLOAD_SERVICE},
}

for i, serviceInfo in ipairs(services) do
local name, serviceKey = serviceInfo[1], serviceInfo[2]
local service = context:getSystemService(serviceKey)
print(string.format("     %s Service: %s", name, service and "✅ Available" or "❌ Not available"))
end

print("\n   ✅ Working operations completed!")
print("   ℹ️  Working features:")
print("      - Context and app info")
print("      - Directory access")
print("      - File listing and reading")
print("      - Permission checking")
print("      - System services check")

print("\n   ⚠️  Non-working features removed:")
print("      - Database operations (openOrCreateDatabase method not coercible)")
print("      - Shared preferences (removed)")
print("      - Service start (removed)")

end)

if not success then
print("   ❌ Error:", error)
end
print()