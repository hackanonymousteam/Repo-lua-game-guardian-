import "android.os.Environment"
import "java.io.File"

local Class = luajava.bindClass
local new = luajava.new
local astable = luajava.astable

print("3. android.os.Environment - System Directories Exploration:")

local envSuccess, envError = pcall(function()
local Environment = Class("android.os.Environment")

print("   📱 System Directories:")
print()

local dirs = {
{"Root", Environment:getRootDirectory()},
{"Data", Environment:getDataDirectory()},
{"Download Cache", Environment:getDownloadCacheDirectory()},
{"External Storage", Environment:getExternalStorageDirectory()},
{"External Storage Public", Environment:getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)},
{"OEM", Environment:getOemDirectory()},
{"Product", Environment:getProductDirectory()},
{"Vendor", Environment:getVendorDirectory()},
{"ODM", Environment:getOdmDirectory()},
{"Storage", Environment:getStorageDirectory()},
{"Expand", Environment:getExpandDirectory()},
}

for i, dirInfo in ipairs(dirs) do
local name, dir = dirInfo[1], dirInfo[2]
if dir then
local path = dir:getAbsolutePath()
local canRead = dir:canRead() and "✅" or "❌"
local canWrite = dir:canWrite() and "✅" or "❌"
local exists = dir:exists() and "✅" or "❌"

print(string.format("   %s:", name))
print(string.format("     Path: %s", path))
print(string.format("     Exists: %s | Read: %s | Write: %s", exists, canRead, canWrite))

if dir:exists() and dir:canRead() then
local files = dir:listFiles()
if files and #files > 0 then
print(string.format("     Content (%d items):", #files))
for j = 1, math.min(3, #files) do
local file = files[j]
local type = file:isDirectory() and "📁" or "📄"
print(string.format("       %s %s", type, file:getName()))
end
if #files > 3 then
print(string.format("       ... (%d more items)", #files - 3))
end
else
print("     Content: empty")
end
end
print()
else
print(string.format("   %s: ❌ Not available", name))
print()
end
end

print("   💾 External Storage States:")
local extState = Environment:getExternalStorageState()
print("     Current state:", extState)

print()
print("   🔍 Checks:")
local isEmulated = Environment:isExternalStorageEmulated()
local isRemovable = Environment:isExternalStorageRemovable()
local isLegacy = Environment:isExternalStorageLegacy()

print("     Storage emulated:", isEmulated and "✅ Yes" or "❌ No")
print("     Storage removable:", isRemovable and "✅ Yes" or "❌ No")
print("     Legacy mode:", isLegacy and "✅ Yes" or "❌ No")

print()
print("   👤 User Data Directories:")

local userId = 0

local userDirs = {
{"User Config", Environment:getUserConfigDirectory(userId)},
{"User System", Environment:getUserSystemDirectory(userId)},
{"Data Misc CE", Environment:getDataMiscCeDirectory()},
{"Data Misc DE", Environment:getDataMiscDeDirectory(userId)},
{"Data System CE", Environment:getDataSystemCeDirectory(userId)},
{"Data System DE", Environment:getDataSystemDeDirectory(userId)},
}

for i, dirInfo in ipairs(userDirs) do
local name, dir = dirInfo[1], dirInfo[2]
if dir then
local path = dir:getAbsolutePath()
print(string.format("     %s: %s", name, path))
else
print(string.format("     %s: ❌ Not available", name))
end
end

print()
print("   📦 Preload Directories:")
local preloadDirs = {
{"Preloads", Environment:getDataPreloadsDirectory()},
{"Preloads Apps", Environment:getDataPreloadsAppsDirectory()},
{"Preloads Demo", Environment:getDataPreloadsDemoDirectory()},
{"Preloads Media", Environment:getDataPreloadsMediaDirectory()},
{"Preloads File Cache", Environment:getDataPreloadsFileCacheDirectory()},
}

for i, dirInfo in ipairs(preloadDirs) do
local name, dir = dirInfo[1], dirInfo[2]
if dir then
local path = dir:getAbsolutePath()
print(string.format("     %s: %s", name, path))
else
print(string.format("     %s: ❌ Not available", name))
end
end

print()
print("   📁 Public Directory Types:")
local publicDirs = {
"DIRECTORY_MUSIC",
"DIRECTORY_PODCASTS",
"DIRECTORY_RINGTONES",
"DIRECTORY_ALARMS",
"DIRECTORY_NOTIFICATIONS",
"DIRECTORY_PICTURES",
"DIRECTORY_MOVIES",
"DIRECTORY_DOWNLOADS",
"DIRECTORY_DCIM",
"DIRECTORY_DOCUMENTS",
"DIRECTORY_AUDIOBOOKS",
}

for i, dirType in ipairs(publicDirs) do
local success, dirPath = pcall(function()
local constant = Environment[dirType]
if constant then
return Environment:getExternalStoragePublicDirectory(constant)
end
return nil
end)

if success and dirPath then
print(string.format("     %s: %s", dirType, dirPath:getAbsolutePath()))
else
print(string.format("     %s: ❌ Not available", dirType))
end
end

end)

if not envSuccess then
print("   ❌ Error accessing Environment:", envError)
end
print()