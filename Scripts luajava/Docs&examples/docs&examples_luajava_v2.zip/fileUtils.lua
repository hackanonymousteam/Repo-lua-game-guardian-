import "android.os.Environment"
import "java.io.File"
import "java.io.FileWriter"
import "java.io.FileReader"
import "java.io.BufferedReader"
import "java.io.FileInputStream"
import "java.io.FileOutputStream"

local Class = luajava.bindClass
local new = luajava.new
local astable = luajava.astable

print("4. File Operations - Working Methods:")

local success, error = pcall(function()
    local Environment = Class("android.os.Environment")
    
    local extStorage = Environment:getExternalStorageDirectory()
    local workDir = new(File, extStorage, "FileUtilsTest")
    
    print("   📁 Working directory:", workDir:getAbsolutePath())
    
    if not workDir:exists() then
        local created = workDir:mkdirs()
        if created then
            print("   ✅ Directory created with mkdirs()")
        else
            print("   ❌ Failed to create directory")
            return
        end
    else
        print("   📁 Directory already exists")
    end
    
    print("\n   ✍️  FileWriter test:")
    local testFile = new(File, workDir, "test.txt")
    
    local writeSuccess, writeError = pcall(function()
        local writer = new(FileWriter, testFile)
        writer:write("Hello world!\n")
        writer:write("This is a test line.\n")
        writer:write("File created on: " .. os.date() .. "\n")
        writer:close()
        print("   ✅ File written successfully:", testFile:getAbsolutePath())
        print("     Size:", testFile:length(), "bytes")
    end)
    
    if not writeSuccess then
        print("   ❌ Error writing file:", writeError)
    end
    
    print("\n   📖 BufferedReader test:")
    local readSuccess, content = pcall(function()
        local reader = new(BufferedReader, new(FileReader, testFile))
        local lines = {}
        local line = reader:readLine()
        while line do
            table.insert(lines, line)
            line = reader:readLine()
        end
        reader:close()
        return lines
    end)
    
    if readSuccess then
        print("   ✅ Content read (" .. #content .. " lines):")
        for i, line in ipairs(content) do
            print("     " .. i .. ": " .. line)
        end
    else
        print("   ❌ Error reading file:", content)
    end
    
    print("\n   📑 Listing directory contents:")
    local files = workDir:listFiles()
    if files and #files > 0 then
        for i, file in ipairs(astable(files)) do
            local type = file:isDirectory() and "📁" or "📄"
            local lastModified = os.date("%c", file:lastModified() / 1000)
            print(string.format("     %d. %s %s", i, type, file:getName()))
            print(string.format("        Size: %d bytes", file:length()))
            print(string.format("        Modified: %s", lastModified))
        end
    else
        print("     Directory is empty")
    end
    
    print("\n   🔒 Permission check:")
    print("     Can read:", testFile:canRead() and "✅" or "❌")
    print("     Can write:", testFile:canWrite() and "✅" or "❌")
    print("     Can execute:", testFile:canExecute() and "✅" or "❌")
    
    print("\n   ✏️  Rename test:")
    local renamedFile = new(File, workDir, "test_renamed.txt")
    local renamed = testFile:renameTo(renamedFile)
    if renamed then
        print("   ✅ File renamed to:", renamedFile:getName())
        renamedFile:renameTo(testFile)
        print("     Renamed back to original")
    else
        print("   ❌ Rename failed")
    end
    
    print("\n   📝 Temporary file test:")
    local tempSuccess, tempFile = pcall(function()
        return File:createTempFile("temp_", ".txt", workDir)
    end)
    
    if tempSuccess then
        print("   ✅ Temporary file created:", tempFile:getName())
        print("     Deleting temporary file...")
        tempFile:delete()
        print("     Exists after delete:", tempFile:exists() and "❌" or "✅ (deleted)")
    else
        print("   ❌ Error creating temp file:", tempFile)
    end
    
    print("\n   📊 Directory statistics:")
    local totalSize = 0
    local fileCount = 0
    local dirFiles = workDir:listFiles()
    
    if dirFiles then
        for i, file in ipairs(astable(dirFiles)) do
            if file:isFile() then
                totalSize = totalSize + file:length()
                fileCount = fileCount + 1
            end
        end
        print("     Total files:", fileCount)
        print("     Total size:", totalSize, "bytes")
        print("     Total size:", string.format("%.2f", totalSize / 1024), "KB")
        print("     Total size:", string.format("%.2f", totalSize / (1024 * 1024)), "MB")
    end
    
    print("\n   🗺️  Path information:")
    print("     Absolute path:", testFile:getAbsolutePath())
    print("     Canonical path:", testFile:getCanonicalPath())
    print("     Parent:", testFile:getParent())
    print("     Name:", testFile:getName())
    
    print("\n   💾 Disk space:")
    print("     Total:", workDir:getTotalSpace() / (1024 * 1024 * 1024), "GB")
    print("     Free:", workDir:getFreeSpace() / (1024 * 1024 * 1024), "GB")
    print("     Usable:", workDir:getUsableSpace() / (1024 * 1024 * 1024), "GB")
    
    print("\n   ✅ All operations completed successfully!")
    print("   📍 Files location:", workDir:getAbsolutePath())
    
end)

if not success then
    print("   ❌ Error:", error)
end
print()