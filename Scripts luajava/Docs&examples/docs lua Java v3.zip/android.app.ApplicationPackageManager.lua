local Class = luajava.bindClass
local new = luajava.new
local astable = luajava.astable

local ActivityThread = Class("android.app.ActivityThread")
local PackageManager = Class("android.content.pm.PackageManager")
local Intent = Class("android.content.Intent")
local ComponentName = Class("android.content.ComponentName")
local UserHandle = Class("android.os.UserHandle")
local PersistableBundle = Class("android.os.PersistableBundle")
local SuspendDialogInfo = Class("android.content.pm.SuspendDialogInfo")
local VolumeInfo = Class("android.os.storage.VolumeInfo")
local ChangedPackages = Class("android.content.pm.ChangedPackages")
local ArtManager = Class("android.content.pm.dex.ArtManager")
local Handler = Class("android.os.Handler")
local Looper = Class("android.os.Looper")

local activityThread = ActivityThread:currentActivityThread()
local context = activityThread:getSystemContext()
local pm = context:getPackageManager()
local packageName = activityThread:getProcessName()
local userId = 0

print("getPackageManager():", tostring(pm))
print("")

print("checkPermission(INTERNET):", pm:checkPermission("android.permission.INTERNET", packageName) == PackageManager.PERMISSION_GRANTED and "GRANTED" or "DENIED")

print("shouldShowRequestPermissionRationale():", pm:shouldShowRequestPermissionRationale("android.permission.INTERNET"))

print("isPermissionRevokedByPolicy():", pm:isPermissionRevokedByPolicy("android.permission.INTERNET", packageName))

local providerAsUser = pm:resolveContentProviderAsUser("settings", 0, userId)
print("resolveContentProviderAsUser():", tostring(providerAsUser))

local defaultIcon = pm:getDefaultActivityIcon()
print("getDefaultActivityIcon():", tostring(defaultIcon))

print("hasSystemFeature(CAMERA):", pm:hasSystemFeature(PackageManager.FEATURE_CAMERA))

print("hasSystemFeature(CAMERA,1):", pm:hasSystemFeature(PackageManager.FEATURE_CAMERA, 1))

local libs = pm:getSystemSharedLibraryNames()
print("getSystemSharedLibraryNames():", #astable(libs), "libraries")

local servicesLib = pm:getServicesSystemSharedLibraryPackageName()
print("getServicesSystemSharedLibraryPackageName():", servicesLib)

local sharedLib = pm:getSharedSystemSharedLibraryPackageName()
print("getSharedSystemSharedLibraryPackageName():", sharedLib)

local permCtrl = pm:getPermissionControllerPackageName()
print("getPermissionControllerPackageName():", permCtrl)

local textClass = pm:getSystemTextClassifierPackageName()
print("getSystemTextClassifierPackageName():", textClass or "N/A")

print("isInstantApp():", pm:isInstantApp())

print("isInstantApp(packageName):", pm:isInstantApp(packageName))

local cookie = pm:getInstantAppCookie()
print("getInstantAppCookie():", #(cookie or {}).." bytes")

local installerComponent = pm:getInstantAppInstallerComponent()
print("getInstantAppInstallerComponent():", tostring(installerComponent))

local installer = pm:getPackageInstaller()
print("getPackageInstaller():", tostring(installer))

print("isPackageAvailable():", pm:isPackageAvailable(packageName))

local primaryVolume = pm:getPrimaryStorageCurrentVolume()
print("getPrimaryStorageCurrentVolume():", tostring(primaryVolume))

local candidateVolumes = pm:getPrimaryStorageCandidateVolumes()
print("getPrimaryStorageCandidateVolumes():", #astable(candidateVolumes), "volumes")

local preferredPkgs = pm:getPreferredPackages(0)
print("getPreferredPackages():", #astable(preferredPkgs), "packages")

pm:addPackageToPreferred(packageName)
print("addPackageToPreferred():", "OK")

pm:removePackageFromPreferred(packageName)
print("removePackageFromPreferred():", "OK")

pm:clearInstantAppCookie()
print("clearInstantAppCookie():", "OK")

local sigCheck = pm:checkSignatures(packageName, "android")
print("checkSignatures(packages):", sigCheck == PackageManager.SIGNATURE_MATCH and "MATCH" or "NO_MATCH")

local uidCheck = pm:checkSignatures(1000, 1000)
print("checkSignatures(UIDs):", uidCheck == PackageManager.SIGNATURE_MATCH and "MATCH" or "NO_MATCH")

print("isPackageSuspended():", pm:isPackageSuspended())

print("isPackageSuspended(packageName):", pm:isPackageSuspended(packageName))

local whitelisted = pm:getWhitelistedRestrictedPermissions(packageName, 0)
print("getWhitelistedRestrictedPermissions():", #astable(whitelisted), "permissions")

local added = pm:addWhitelistedRestrictedPermission(packageName, "android.permission.INTERNET", 0)
print("addWhitelistedRestrictedPermission():", added)

local removed = pm:removeWhitelistedRestrictedPermission(packageName, "android.permission.INTERNET", 0)
print("removeWhitelistedRestrictedPermission():", removed)

local verifStatus = pm:getIntentVerificationStatusAsUser(packageName, userId)
print("getIntentVerificationStatusAsUser():", verifStatus)

local filters = pm:getIntentFilterVerifications(packageName)
print("getIntentFilterVerifications():", #astable(filters), "filters")

local changed = pm:getChangedPackages(0)
print("getChangedPackages():", tostring(changed))

local modules = pm:getInstalledModules(0)
print("getInstalledModules():", #astable(modules), "modules")

local artManager = pm:getArtManager()
print("getArtManager():", tostring(artManager))

print("isMoveStatusFinished():", PackageManager:isMoveStatusFinished(0))

local publicStatus = PackageManager:deleteStatusToPublicStatus(PackageManager.DELETE_SUCCEEDED)
print("deleteStatusToPublicStatus():", publicStatus)

local publicInstallStatus = PackageManager:installStatusToPublicStatus(PackageManager.INSTALL_SUCCEEDED)
print("installStatusToPublicStatus():", publicInstallStatus)

local flagStr = PackageManager:permissionFlagToString(PackageManager.FLAG_PERMISSION_GRANTED_BY_DEFAULT)
print("permissionFlagToString():", flagStr)

pm:flushPackageRestrictionsAsUser(userId)
print("flushPackageRestrictionsAsUser():", "OK")

local userId = pm:getUserId()
print("getUserId():", userId)

print("isSafeMode():", pm:isSafeMode())

print("isDeviceUpgrading():", pm:isDeviceUpgrading())

print("isUpgrade():", pm:isUpgrade())

local approver = pm:getIncidentReportApproverPackageName()
print("getIncidentReportApproverPackageName():", approver)