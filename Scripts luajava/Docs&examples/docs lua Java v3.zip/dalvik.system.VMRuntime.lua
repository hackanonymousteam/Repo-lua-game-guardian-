import "android.ext.*"
import "dalvik.system.*"
import "java.io.*"
import "java.util.*"
import "java.util.function.*"

local Class = luajava.bindClass
local new = luajava.new
local astable = luajava.astable

local VMRuntime = Class("dalvik.system.VMRuntime")

print("=== VMRUNTIME TESTS ===\n")
print("Current package: " .. luajava.bindClass("android.app.ActivityThread"):currentApplication():getPackageName())
print("")

local function testMethod(methodName, func)
    print("▶ " .. methodName)
    local success, result = pcall(func)
    if success then
        if result ~= nil then
            if type(result) == "boolean" then
                print("  ✓ Success: " .. tostring(result))
            elseif type(result) == "number" then
                print("  ✓ Success: " .. result)
            elseif type(result) == "string" then
                print("  ✓ Success: " .. result)
            elseif type(result) == "userdata" then
                if tostring(result):find("VMRuntime") then
                    print("  ✓ Success: VMRuntime instance obtained")
                else
                    print("  ✓ Success: " .. tostring(result))
                end
            else
                print("  ✓ Success: " .. tostring(result))
            end
        else
            print("  ✓ Executed successfully")
        end
    else
        local errMsg = tostring(result)
        if errMsg:find("SecurityException") then
            errMsg = errMsg:match("java%.lang%.SecurityException: [^\n]+") or errMsg
            print("  ✗ [Permission] " .. errMsg)
        elseif errMsg:find("IllegalArgumentException") then
            errMsg = errMsg:match("java%.lang%.IllegalArgumentException: [^\n]+") or errMsg
            print("  ✗ [Argument] " .. errMsg)
        elseif errMsg:find("NullPointerException") then
            print("  ✗ [Null] Requires valid parameters")
        elseif errMsg:find("NoSuchMethodError") then
            print("  ✗ [Method] " .. errMsg)
        else
            print("  ✗ Error: " .. errMsg)
        end
    end
    print("")
end

local runtime = VMRuntime.getRuntime()
print("✓ VMRuntime instance obtained:", tostring(runtime))
print("")

print("1. BASIC INFORMATION")
print("====================")

testMethod("getRuntime (static)", function()
    return VMRuntime.getRuntime()
end)

testMethod("is64Bit", function()
    return "64-bit: " .. tostring(runtime:is64Bit())
end)

testMethod("is64BitAbi", function()
    return "64-bit ABI (arm64-v8a): " .. tostring(VMRuntime.is64BitAbi("arm64-v8a"))
end)

testMethod("is64BitInstructionSet", function()
    return "64-bit instruction set (arm64): " .. tostring(VMRuntime.is64BitInstructionSet("arm64"))
end)

testMethod("getCurrentInstructionSet", function()
    return "Current instruction set: " .. (VMRuntime.getCurrentInstructionSet() or "N/A")
end)

testMethod("getInstructionSet", function()
    return "Instruction set for ABI arm64-v8a: " .. VMRuntime.getInstructionSet("arm64-v8a")
end)

testMethod("vmInstructionSet", function()
    return "VM instruction set: " .. runtime:vmInstructionSet()
end)

testMethod("vmLibrary", function()
    return "VM library: " .. runtime:vmLibrary()
end)

testMethod("vmVersion", function()
    return "VM version: " .. runtime:vmVersion()
end)

print("\n2. VM STATE")
print("============")

testMethod("isBootClassPathOnDisk", function()
    return "Boot classpath on disk: " .. tostring(VMRuntime.isBootClassPathOnDisk("arm"))
end)

testMethod("isCheckJniEnabled", function()
    return "CheckJNI enabled: " .. tostring(runtime:isCheckJniEnabled())
end)

testMethod("isJavaDebuggable", function()
    return "Java debuggable: " .. tostring(runtime:isJavaDebuggable())
end)

testMethod("isNativeDebuggable", function()
    return "Native debuggable: " .. tostring(runtime:isNativeDebuggable())
end)

testMethod("getTargetSdkVersion", function()
    return "Target SDK version: " .. runtime:getTargetSdkVersion()
end)

testMethod("properties", function()
    local props = runtime:properties()
    if props then
        local count = 0
        for _ in pairs(astable(props)) do count = count + 1 end
        return "VM properties: " .. count .. " found"
    end
    return "No properties"
end)

print("\n3. MEMORY MANAGEMENT")
print("====================")

testMethod("getMinimumHeapSize", function()
    return "Minimum heap size: " .. runtime:getMinimumHeapSize() .. " bytes"
end)

testMethod("setMinimumHeapSize", function()
    local current = runtime:getMinimumHeapSize()
    local newSize = runtime:setMinimumHeapSize(current)
    return "Set minimum heap size: " .. newSize
end)

testMethod("getTargetHeapUtilization", function()
    return "Target heap utilization: " .. runtime:getTargetHeapUtilization()
end)

testMethod("setTargetHeapUtilization", function()
    local current = runtime:getTargetHeapUtilization()
    local result = runtime:setTargetHeapUtilization(current)
    return "Set target heap utilization: " .. result
end)

testMethod("getExternalBytesAllocated", function()
    return "External bytes allocated: " .. runtime:getExternalBytesAllocated()
end)

testMethod("trackExternalAllocation", function()
    local result = runtime:trackExternalAllocation(1024)
    return "Track external allocation (1KB): " .. tostring(result)
end)

testMethod("trackExternalFree", function()
    runtime:trackExternalFree(1024)
    return "Track external free (1KB) executed"
end)

testMethod("gcSoftReferences", function()
    runtime:gcSoftReferences()
    return "gcSoftReferences executed"
end)

testMethod("requestConcurrentGC", function()
    runtime:requestConcurrentGC()
    return "requestConcurrentGC executed"
end)

testMethod("requestHeapTrim", function()
    runtime:requestHeapTrim()
    return "requestHeapTrim executed"
end)

testMethod("trimHeap", function()
    runtime:trimHeap()
    return "trimHeap executed"
end)

testMethod("runHeapTasks", function()
    runtime:runHeapTasks()
    return "runHeapTasks executed"
end)

testMethod("startHeapTaskProcessor", function()
    runtime:startHeapTaskProcessor()
    return "startHeapTaskProcessor executed"
end)

testMethod("stopHeapTaskProcessor", function()
    runtime:stopHeapTaskProcessor()
    return "stopHeapTaskProcessor executed"
end)

print("\n4. JIT AND COMPILATION")
print("=======================")

testMethod("preloadDexCaches", function()
    runtime:preloadDexCaches()
    return "preloadDexCaches executed"
end)

print("\n5. FINALIZATION")
print("================")

testMethod("runFinalization", function()
    VMRuntime.runFinalization(1000)
    return "runFinalization(1000) executed"
end)

testMethod("runFinalizationSync", function()
    runtime:runFinalizationSync()
    return "runFinalizationSync executed"
end)

print("\n6. HIDDEN API")
print("==============")

testMethod("setDedupeHiddenApiWarnings", function()
    VMRuntime.setDedupeHiddenApiWarnings(true)
    VMRuntime.setDedupeHiddenApiWarnings(false)
    return "setDedupeHiddenApiWarnings executed"
end)

testMethod("setHiddenApiAccessLogSamplingRate", function()
    runtime:setHiddenApiAccessLogSamplingRate(100)
    return "setHiddenApiAccessLogSamplingRate(100) executed"
end)

testMethod("setNonSdkApiUsageConsumer", function()
    local consumer = luajava.createProxy("java.util.function.Consumer", {
        accept = function(t)
            print("  → Non-SDK API used: " .. tostring(t))
        end
    })
    VMRuntime.setNonSdkApiUsageConsumer(consumer)
    return "setNonSdkApiUsageConsumer executed"
end)

print("\n7. PROCESS")
print("===========")

testMethod("setProcessPackageName", function()
    VMRuntime.setProcessPackageName("com.example.app")
    return "setProcessPackageName executed"
end)

testMethod("registerSensitiveThread", function()
    VMRuntime.registerSensitiveThread()
    return "registerSensitiveThread executed"
end)

testMethod("updateProcessState", function()
    runtime:updateProcessState(0)
    return "updateProcessState executed"
end)

print("\n8. OBJECT METHODS")
print("==================")

testMethod("getClass", function()
    return "Class: " .. runtime:getClass():getName()
end)

testMethod("hashCode", function()
    return "HashCode: " .. runtime:hashCode()
end)

testMethod("toString", function()
    return "toString: " .. runtime:toString()
end)