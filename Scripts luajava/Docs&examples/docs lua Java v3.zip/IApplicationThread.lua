import "android.ext.*"
import "android.app.*"
import "android.os.*"
import "android.content.*"
import "android.content.pm.*"
import "android.net.Uri"
import "android.widget.*"
import "android.view.*"
import "java.io.*"
import "java.util.*"

local Class = luajava.bindClass
local new = luajava.new
local astable = luajava.astable

local ActivityThread = Class("android.app.ActivityThread")
local at = ActivityThread:currentActivityThread()

local appThread = at:getApplicationThread()

print("=== IAPPLICATIONTHREAD TESTS ===\n")
print("Current application: " .. tostring(at:getProcessName()))
print("Package Name: " .. at:currentApplication():getPackageName())

local function testMethod(methodName, func)
    print("▶ " .. methodName)
    local success, result = pcall(func)
    if success then
        if result ~= nil then
            print("  ✓ Success: " .. tostring(result))
        else
            print("  ✓ Executed successfully (no return)")
        end
    else
        local errMsg = tostring(result)
        if errMsg:find("NullPointerException") then
            print("  ℹ Requires valid parameters (non-null binder/token)")
        elseif errMsg:find("SecurityException") then
            errMsg = errMsg:match("java%.lang%.SecurityException: [^\n]+") or errMsg
            print("  ✗ Permission error: " .. errMsg)
        elseif errMsg:find("DeadObjectException") then
            print("  ℹ DeadObjectException - remote object dead")
        else
            print("  ✗ Error: " .. errMsg)
        end
    end
    print("")
end

print("1. BASIC METHODS (NO COMPLEX PARAMETERS)")
print("-----------------------------------------")

testMethod("handleTrustStorageUpdate (no parameters)", function()
    appThread:handleTrustStorageUpdate()
    return "handleTrustStorageUpdate executed"
end)

testMethod("setSchedulingGroup (with integer)", function()
    appThread:setSchedulingGroup(0)
    return "setSchedulingGroup executed"
end)

testMethod("setNetworkBlockSeq (with long)", function()
    appThread:setNetworkBlockSeq(12345)
    return "setNetworkBlockSeq executed"
end)

testMethod("updateTimePrefs (with integer)", function()
    appThread:updateTimePrefs(0)
    return "updateTimePrefs executed"
end)

print("\n=== SYSTEM INFORMATION ===")
print("Process Name: " .. at:getProcessName())
print("ApplicationThread: " .. tostring(appThread))
print("Class: " .. tostring(luajava.bindClass("android.app.IApplicationThread")))