import "android.ext.*"
import "android.app.*"
import "android.os.*"
import "android.content.*"
import "android.content.pm.*"
import "android.util.*"
import "java.io.*"
import "java.security.*"
import "java.util.*"

local Class = luajava.bindClass
local new = luajava.new
local astable = luajava.astable

local PackageParser = Class("android.content.pm.PackageParser")
local FileClass = Class("java.io.File")
local FileInputStream = Class("java.io.FileInputStream")
local DisplayMetrics = Class("android.util.DisplayMetrics")
local ArraySet = Class("android.util.ArraySet")

local context = luajava.bindClass("android.app.ActivityThread"):currentApplication():getApplicationContext()
local packageName = context:getPackageName()

print("=== PACKAGEPARSER TESTS ===\n")
print("Current package: " .. packageName)
print("")

local function testMethod(methodName, func)
    print("▶ " .. methodName)
    local success, result = pcall(func)
    if success then
        if result ~= nil then
            if type(result) == "boolean" then
                print("  ✓ Success: " .. tostring(result))
            elseif type(result) == "number" then
                print("  ✓ Success: " .. result)
            elseif type(result) == "string" then
                print("  ✓ Success: " .. result)
            else
                print("  ✓ Success: " .. tostring(result))
            end
        else
            print("  ✓ Executed successfully")
        end
    else
        local errMsg = tostring(result)
        if errMsg:find("PackageParserException") then
            errMsg = errMsg:match("android%.content%.pm%.PackageParser%$PackageParserException: [^\n]+") or errMsg
            print("  ✗ [Parse Error] " .. errMsg)
        elseif errMsg:find("SecurityException") then
            errMsg = errMsg:match("java%.lang%.SecurityException: [^\n]+") or errMsg
            print("  ✗ [Permission] " .. errMsg)
        elseif errMsg:find("IOException") then
            errMsg = errMsg:match("java%.io%.IOException: [^\n]+") or errMsg
            print("  ✗ [IO Error] " .. errMsg)
        elseif errMsg:find("NullPointerException") then
            print("  ✗ [Null] Requires valid parameters")
        elseif errMsg:find("IllegalArgumentException") then
            errMsg = errMsg:match("java%.lang%.IllegalArgumentException: [^\n]+") or errMsg
            print("  ✗ [Argument] " .. errMsg)
        elseif errMsg:find("Class expected") then
            print("  ✗ [Class] Error creating instance")
        else
            print("  ✗ Error: " .. errMsg)
        end
    end
    print("")
end

print("\n1. STATIC UTILITY METHODS")
print("==========================")

testMethod("isApkFile", function()
    local testFile = new(FileClass, "/sdcard/test.apk")
    return "isApkFile: " .. tostring(PackageParser.isApkFile(testFile))
end)

testMethod("isApkPath", function()
    return "isApkPath(/sdcard/test.apk): " .. tostring(PackageParser.isApkPath("/sdcard/test.apk"))
end)

testMethod("getActivityConfigChanges", function()
    local changes = PackageParser.getActivityConfigChanges(
        ActivityInfo.CONFIG_ORIENTATION,
        ActivityInfo.CONFIG_SCREEN_SIZE
    )
    return "getActivityConfigChanges: " .. changes
end)

testMethod("setCompatibilityModeEnabled", function()
    PackageParser.setCompatibilityModeEnabled(true)
    PackageParser.setCompatibilityModeEnabled(false)
    return "setCompatibilityModeEnabled executed"
end)

print("\n2. APK PARSING")
print("===============")

local function findTestApk()
    local dirs = {"/sdcard", "/sdcard/Download", "/sdcard/APKs"}
    for _, dirPath in ipairs(dirs) do
        local dir = new(FileClass, dirPath)
        if dir:exists() and dir:isDirectory() then
            local files = dir:listFiles()
            if files then
                for _, file in ipairs(luajava.astable(files)) do
                    local name = file:getName()
                    if name:lower():match("%.apk$") then
                        return file
                    end
                end
            end
        end
    end
    return nil
end

local testApk = findTestApk()
if testApk then
    print("Test APK found: " .. testApk:getAbsolutePath())
    print("Size: " .. testApk:length() .. " bytes")
else
    print("⚠ No APK found for parsing tests")
end

testMethod("parsePackageLite (static)", function()
    if not testApk then
        return "⚠ Skipped - no test APK"
    end
    local pkgLite = PackageParser.parsePackageLite(testApk, 0)
    if pkgLite then
        return "✓ PackageLite: " .. pkgLite.packageName
    end
    return "✗ Failed"
end)

testMethod("parseApkLite (with File)", function()
    if not testApk then
        return "⚠ Skipped - no test APK"
    end
    local apkLite = PackageParser.parseApkLite(testApk, 0)
    if apkLite then
        return string.format("✓ ApkLite: %s (version %d)", 
               apkLite.packageName or "N/A", 
               apkLite.versionCode or 0)
    end
    return "✗ Failed"
end)

testMethod("parseApkLite (with FileDescriptor)", function()
    if not testApk then
        return "⚠ Skipped - no test APK"
    end
    local fis = new(FileInputStream, testApk)
    local fd = fis:getFD()
    local apkLite = PackageParser.parseApkLite(fd, testApk:getAbsolutePath(), 0)
    fis:close()
    if apkLite then
        return "✓ ApkLite with FD: " .. (apkLite.packageName or "N/A")
    end
    return "✗ Failed"
end)

print("\n3. GENERATION METHODS")
print("======================")

local parsedPackage = nil
if testApk then
    local parser = new(PackageParser)
    local success, pkg = pcall(function()
        return parser:parsePackage(testApk, 0)
    end)
    if success and pkg then
        parsedPackage = pkg
        print("✓ Base package obtained for generation tests")
    end
end

if parsedPackage then
    local PackageUserState = Class("android.content.pm.PackageUserState")
    local userState = new(PackageUserState())
    
    testMethod("generatePackageInfo", function()
        local packageInfo = PackageParser.generatePackageInfo(parsedPackage, nil, 0, 0, 0, nil, userState)
        return packageInfo and "✓ PackageInfo generated: " .. (packageInfo.packageName or "N/A") or "✗ Failed"
    end)
    
    testMethod("generatePackageInfo (with flags)", function()
        local packageInfo = PackageParser.generatePackageInfo(parsedPackage, nil, 0, 0, 0, nil, userState, 0)
        return packageInfo and "✓ PackageInfo with flags generated" or "✗ Failed"
    end)
    
    if parsedPackage.activities and parsedPackage.activities:size() > 0 then
        local firstActivity = parsedPackage.activities:get(0)
        testMethod("generateActivityInfo", function()
            local activityInfo = PackageParser.generateActivityInfo(firstActivity, 0, userState, 0)
            return activityInfo and "✓ ActivityInfo generated: " .. (activityInfo.name or "N/A") or "✗ Failed"
        end)
    end
    
    if parsedPackage.services and parsedPackage.services:size() > 0 then
        local firstService = parsedPackage.services:get(0)
        testMethod("generateServiceInfo", function()
            local serviceInfo = PackageParser.generateServiceInfo(firstService, 0, userState, 0)
            return serviceInfo and "✓ ServiceInfo generated: " .. (serviceInfo.name or "N/A") or "✗ Failed"
        end)
    end
    
    if parsedPackage.providers and parsedPackage.providers:size() > 0 then
        local firstProvider = parsedPackage.providers:get(0)
        testMethod("generateProviderInfo", function()
            local providerInfo = PackageParser.generateProviderInfo(firstProvider, 0, userState, 0)
            return providerInfo and "✓ ProviderInfo generated: " .. (providerInfo.name or "N/A") or "✗ Failed"
        end)
    end
    
    if parsedPackage.permissions and parsedPackage.permissions:size() > 0 then
        local firstPermission = parsedPackage.permissions:get(0)
        testMethod("generatePermissionInfo", function()
            local permInfo = PackageParser.generatePermissionInfo(firstPermission, 0)
            return permInfo and "✓ PermissionInfo generated" or "✗ Failed"
        end)
    end
    
    if parsedPackage.permissionGroups and parsedPackage.permissionGroups:size() > 0 then
        local firstGroup = parsedPackage.permissionGroups:get(0)
        testMethod("generatePermissionGroupInfo", function()
            local groupInfo = PackageParser.generatePermissionGroupInfo(firstGroup, 0)
            return groupInfo and "✓ PermissionGroupInfo generated" or "✗ Failed"
        end)
    end
    
    if parsedPackage.instrumentation and parsedPackage.instrumentation:size() > 0 then
        local firstInstr = parsedPackage.instrumentation:get(0)
        testMethod("generateInstrumentationInfo", function()
            local instrInfo = PackageParser.generateInstrumentationInfo(firstInstr, 0)
            return instrInfo and "✓ InstrumentationInfo generated" or "✗ Failed"
        end)
    end
    
    if parsedPackage.mSignatures and #astable(parsedPackage.mSignatures) > 0 then
        testMethod("toSigningKeys", function()
            local keys = PackageParser.toSigningKeys(parsedPackage.mSignatures)
            return keys and "✓ Signing keys obtained: " .. keys:size() or "✗ Failed"
        end)
    end
    
    testMethod("toCacheEntryStatic", function()
        local cacheEntry = PackageParser.toCacheEntryStatic(parsedPackage)
        return cacheEntry and "✓ Cache entry generated: " .. #cacheEntry .. " bytes" or "✗ Failed"
    end)
else
    print("⚠ Could not parse APK, skipping generation tests")
end

print("\n4. ADDITIONAL METHODS")
print("======================")

testMethod("parsePublicKey", function()
    local keyString = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE"
    local key = PackageParser.parsePublicKey(keyString)
    return key and "✓ Public key parsed" or "✗ Invalid format"
end)