import "android.ext.*"
import "android.net.*"
import "android.service.watchdog.*"
import "android.os.*"
import "android.content.*"
import "android.app.*"
import "java.io.*"
import "java.util.*"

local Class = luajava.bindClass
local new = luajava.new
local astable = luajava.astable

local IpSecConfig = Class("android.net.IpSecConfig")
local IpSecAlgorithm = Class("android.net.IpSecAlgorithm")
local ExplicitHealthCheckService = Class("android.service.watchdog.ExplicitHealthCheckService")
local Network = Class("android.net.Network")
local Parcel = Class("android.os.Parcel")
local Intent = Class("android.content.Intent")

local context = luajava.bindClass("android.app.ActivityThread"):currentApplication():getApplicationContext()
local packageName = context:getPackageName()

print("=== NETWORK CLASSES TESTS ===\n")
print("Current package: " .. packageName)
print("")

local function testMethod(methodName, func)
    print("▶ " .. methodName)
    local success, result = pcall(func)
    if success then
        if result ~= nil then
            if type(result) == "boolean" then
                print("  ✓ Success: " .. tostring(result))
            elseif type(result) == "number" then
                print("  ✓ Success: " .. result)
            elseif type(result) == "string" then
                print("  ✓ Success: " .. result)
            elseif type(result) == "userdata" then
                print("  ✓ Success: " .. tostring(result))
            else
                print("  ✓ Success: " .. tostring(result))
            end
        else
            print("  ✓ Executed successfully")
        end
    else
        local errMsg = tostring(result)
        if errMsg:find("SecurityException") then
            errMsg = errMsg:match("java%.lang%.SecurityException: [^\n]+") or errMsg
            print("  ✗ [Permission] " .. errMsg)
        elseif errMsg:find("IllegalArgumentException") then
            errMsg = errMsg:match("java%.lang%.IllegalArgumentException: [^\n]+") or errMsg
            print("  ✗ [Argument] " .. errMsg)
        elseif errMsg:find("NullPointerException") then
            print("  ✗ [Null] Requires valid parameters")
        elseif errMsg:find("RemoteException") then
            print("  ✗ [Remote] " .. errMsg)
        elseif errMsg:find("DeadObjectException") then
            print("  ✗ [Dead] Service is not responding")
        else
            print("  ✗ Error: " .. errMsg)
        end
    end
    print("")
end

print("1. IPSECCONFIG CLASS TESTS")
print("===========================")

local ipSecConfig = new(IpSecConfig)
print("✓ IpSecConfig instance created\n")

local MODE_TRANSPORT = 0
local MODE_TUNNEL = 1

testMethod("setMode", function()
    ipSecConfig:setMode(MODE_TRANSPORT)
    return "Mode set to TRANSPORT"
end)

testMethod("setSourceAddress", function()
    ipSecConfig:setSourceAddress("192.168.1.100")
    return "Source address set"
end)

testMethod("setDestinationAddress", function()
    ipSecConfig:setDestinationAddress("8.8.8.8")
    return "Destination address set"
end)

testMethod("setSpiResourceId", function()
    ipSecConfig:setSpiResourceId(12345)
    return "SPI resource ID set"
end)

testMethod("setEncapType", function()
    ipSecConfig:setEncapType(1)
    return "Encap type set to ESPINUDP"
end)

testMethod("setEncapSocketResourceId", function()
    ipSecConfig:setEncapSocketResourceId(67890)
    return "Encap socket resource ID set"
end)

testMethod("setEncapRemotePort", function()
    ipSecConfig:setEncapRemotePort(4500)
    return "Encap remote port set to 4500"
end)

testMethod("setNattKeepaliveInterval", function()
    ipSecConfig:setNattKeepaliveInterval(20)
    return "NAT-T keepalive interval set"
end)

testMethod("setMarkValue", function()
    ipSecConfig:setMarkValue(100)
    return "Mark value set"
end)

testMethod("setMarkMask", function()
    ipSecConfig:setMarkMask(255)
    return "Mark mask set"
end)

testMethod("getMode", function()
    return "Mode: " .. ipSecConfig:getMode()
end)

testMethod("getSourceAddress", function()
    return "Source address: " .. ipSecConfig:getSourceAddress()
end)

testMethod("getSpiResourceId", function()
    return "SPI resource ID: " .. ipSecConfig:getSpiResourceId()
end)

testMethod("getEncryption", function()
    local enc = ipSecConfig:getEncryption()
    return enc and "Encryption: " .. enc:getName() or "None"
end)

testMethod("getAuthentication", function()
    local auth = ipSecConfig:getAuthentication()
    return auth and "Authentication: " .. auth:getName() or "None"
end)

testMethod("getEncapType", function()
    local encapTypes = {[0]="NONE", [1]="ESPINUDP", [2]="ESPINUDP_NON_IKE"}
    return "Encap type: " .. (encapTypes[ipSecConfig:getEncapType()] or "Unknown")
end)

testMethod("getEncapRemotePort", function()
    return "Encap remote port: " .. ipSecConfig:getEncapRemotePort()
end)

testMethod("getNattKeepaliveInterval", function()
    return "NAT-T keepalive interval: " .. ipSecConfig:getNattKeepaliveInterval()
end)

testMethod("getMarkValue", function()
    return "Mark value: " .. ipSecConfig:getMarkValue()
end)

testMethod("getMarkMask", function()
    return "Mark mask: " .. ipSecConfig:getMarkMask()
end)

testMethod("getNetwork", function()
    return "Network: " .. tostring(ipSecConfig:getNetwork())
end)

testMethod("hashCode", function()
    return "HashCode: " .. ipSecConfig:hashCode()
end)

testMethod("toString", function()
    return "toString: " .. ipSecConfig:toString()
end)