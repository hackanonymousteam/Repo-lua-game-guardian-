import "android.ext.*"
import "android.location.*"
import "android.os.*"
import "android.content.*"
import "java.io.*"
import "java.util.*"

local Class = luajava.bindClass
local new = luajava.new
local astable = luajava.astable

local Country = Class("android.location.Country")
local CountryDetector = Class("android.location.CountryDetector")
local Geofence = Class("android.location.Geofence")
local Parcel = Class("android.os.Parcel")
local LocationManager = Class("android.location.LocationManager")

local context = luajava.bindClass("android.app.ActivityThread"):currentApplication():getApplicationContext()
local packageName = context:getPackageName()

print("=== LOCATION CLASSES TESTS ===\n")
print("Current package: " .. packageName)
print("")

local function testMethod(methodName, func)
    print("▶ " .. methodName)
    local success, result = pcall(func)
    if success then
        if result ~= nil then
            if type(result) == "boolean" then
                print("  ✓ Success: " .. tostring(result))
            elseif type(result) == "number" then
                print("  ✓ Success: " .. result)
            elseif type(result) == "string" then
                print("  ✓ Success: " .. result)
            elseif type(result) == "userdata" then
                if tostring(result):find("Country") then
                    print("  ✓ Success: Country object created")
                elseif tostring(result):find("Geofence") then
                    print("  ✓ Success: Geofence object created")
                else
                    print("  ✓ Success: " .. tostring(result))
                end
            else
                print("  ✓ Success: " .. tostring(result))
            end
        else
            print("  ✓ Executed successfully")
        end
    else
        local errMsg = tostring(result)
        if errMsg:find("SecurityException") then
            errMsg = errMsg:match("java%.lang%.SecurityException: [^\n]+") or errMsg
            print("  ✗ [Permission] " .. errMsg)
        elseif errMsg:find("IllegalArgumentException") then
            errMsg = errMsg:match("java%.lang%.IllegalArgumentException: [^\n]+") or errMsg
            print("  ✗ [Argument] " .. errMsg)
        elseif errMsg:find("NullPointerException") then
            print("  ✗ [Null] Requires valid parameters")
        elseif errMsg:find("LocationManager") then
            print("  ✗ [Service] Location service not available")
        elseif errMsg:find("attempt to call a nil value") then
            print("  ✗ [Method] Method not available in this Android version")
        else
            print("  ✗ Error: " .. errMsg)
        end
    end
    print("")
end

print("1. COUNTRY CLASS TESTS")
print("=======================")

local countryBR = new(Country, "BR", 0)
local countryUS = new(Country, "US", 1)

print("✓ Country instances created:")
print("  • BR: " .. tostring(countryBR))
print("  • US: " .. tostring(countryUS))
print("")

testMethod("Country.getCountryIso", function()
    return "Country code: " .. countryBR:getCountryIso()
end)

testMethod("Country.getSource", function()
    return "Source: " .. countryBR:getSource()
end)

testMethod("Country.hashCode", function()
    return "BR HashCode: " .. countryBR:hashCode()
end)

testMethod("Country.equals (same country)", function()
    local countryBR2 = new(Country, "BR", 0)
    return "BR equals BR2: " .. tostring(countryBR:equals(countryBR2))
end)

testMethod("Country.equals (different country)", function()
    return "BR equals US: " .. tostring(countryBR:equals(countryUS))
end)

testMethod("Country.toString", function()
    return "toString: " .. countryBR:toString()
end)

testMethod("Country.writeToParcel (skipped - requires native Parcel)", function()
    return "ℹ writeToParcel method requires native Parcel - skipped"
end)

testMethod("Country.CREATOR.newArray", function()
    local array = Country.CREATOR:newArray(5)
    return array and "✓ Country array created: size " .. #astable(array) or "✗ Failed"
end)

print("\n2. COUNTRYDETECTOR CLASS TESTS")
print("================================")

print("⚠ CountryDetector not available - system service requires special permissions")
print("  Reason: @hide service not accessible to normal apps\n")

print("3. GEOFENCE CLASS TESTS")
print("========================")

testMethod("Geofence.createCircle", function()
    local geofence = Geofence.createCircle(0.0, 0.0, 50.0)
    return geofence and "✓ Circular geofence created" or "✗ Failed"
end)