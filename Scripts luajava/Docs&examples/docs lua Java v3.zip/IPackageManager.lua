import "android.ext.*"
import "android.app.*"
import "android.os.*"
import "android.content.*"
import "android.content.pm.*"
import "android.net.Uri"
import "android.widget.*"
import "android.view.*"
import "java.io.*"
import "java.util.*"
import "java.util.ArrayList"

local Class = luajava.bindClass
local new = luajava.new
local astable = luajava.astable

local PackageManagerService = luajava.bindClass("android.app.ActivityThread"):getPackageManager()

local context = luajava.bindClass("android.app.ActivityThread"):currentApplication():getApplicationContext()
local packageName = context:getPackageName()

local ComponentName = Class("android.content.ComponentName")
local Intent = Class("android.content.Intent")
local UriClass = Class("android.net.Uri")
local ArrayListClass = Class("java.util.ArrayList")
local UserHandle = Class("android.os.UserHandle")

local userId = 0
local myUid = luajava.bindClass("android.os.Process"):myUid()

print("=== IPACKAGEMANAGER TESTS ===\n")
print("Current package: " .. packageName)

local function testMethod(methodName, func)
    print("▶ " .. methodName)
    local success, result = pcall(func)
    if success then
        if result ~= nil then
            if type(result) == "boolean" then
                print("  ✓ Success: " .. tostring(result))
            elseif type(result) == "string" then
                print("  ✓ Success: " .. result)
            else
                print("  ✓ Success: " .. tostring(result))
            end
        else
            print("  ✓ Executed successfully")
        end
    else
        local errMsg = tostring(result)
        if errMsg:find("SecurityException") then
            errMsg = errMsg:match("java%.lang%.SecurityException: [^\n]+") or errMsg
            print("  ✗ [Permission] " .. errMsg)
        elseif errMsg:find("IllegalArgumentException") then
            errMsg = errMsg:match("java%.lang%.IllegalArgumentException: [^\n]+") or errMsg
            if errMsg:find("Unknown package") then
                print("  ✗ Package not found: " .. packageName)
            else
                print("  ✗ Error: " .. errMsg)
            end
        elseif errMsg:find("NullPointerException") then
            print("  ✗ Requires valid parameters")
        else
            print("  ✗ Error: " .. errMsg)
        end
    end
    print("")
end

print("\n1. PACKAGE INFORMATION")
print("======================")

testMethod("getApplicationInfo", function()
    local info = PackageManagerService:getApplicationInfo(packageName, 0, userId)
    return info and "Package: " .. info.packageName .. ", UID: " .. info.uid or "Not found"
end)

testMethod("getApplicationIcon", function()
    local icon = PackageManagerService:getApplicationIcon(packageName, 0, userId)
    return icon and "Icon obtained" or "Icon not found"
end)

testMethod("getActivityInfo", function()
    local info = PackageManagerService:getActivityInfo(ComponentName.new(packageName, packageName .. ".MainActivity"), 0, userId)
    return info and "Activity: " .. info.name or "Activity not found"
end)

testMethod("getServiceInfo", function()
    local info = PackageManagerService:getServiceInfo(ComponentName.new(packageName, packageName .. ".MainService"), 0, userId)
    return info and "Service: " .. info.name or "Service not found"
end)

testMethod("getProviderInfo", function()
    local info = PackageManagerService:getProviderInfo(ComponentName.new(packageName, packageName .. ".MainProvider"), 0, userId)
    return info and "Provider: " .. info.name or "Provider not found"
end)

testMethod("getReceiverInfo", function()
    local info = PackageManagerService:getReceiverInfo(ComponentName.new(packageName, packageName .. ".MainReceiver"), 0, userId)
    return info and "Receiver: " .. info.name or "Receiver not found"
end)

testMethod("getPackagesForUid", function()
    local packages = PackageManagerService:getPackagesForUid(myUid)
    if packages and #astable(packages) > 0 then
        return "Packages: " .. table.concat(astable(packages), ", ")
    end
    return "No packages for this UID"
end)

testMethod("getNameForUid", function()
    local name = PackageManagerService:getNameForUid(myUid)
    return name or "Name not found"
end)

testMethod("getFlagsForUid", function()
    local flags = PackageManagerService:getFlagsForUid(myUid)
    return "Flags: " .. flags
end)

testMethod("getPrivateFlagsForUid", function()
    local flags = PackageManagerService:getPrivateFlagsForUid(myUid)
    return "Private flags: " .. flags
end)

testMethod("isUidPrivileged", function()
    return "Privileged? " .. tostring(PackageManagerService:isUidPrivileged(myUid))
end)

testMethod("checkPermission", function()
    local result = PackageManagerService:checkPermission("android.permission.INTERNET", packageName, userId)
    return result == 0 and "✓ Granted" or "✗ Denied"
end)

testMethod("checkUidPermission", function()
    local result = PackageManagerService:checkUidPermission("android.permission.INTERNET", myUid)
    return result == 0 and "✓ Granted" or "✗ Denied"
end)

testMethod("checkSignatures", function()
    local result = PackageManagerService:checkSignatures(packageName, "android")
    return "Result: " .. result
end)

testMethod("checkUidSignatures", function()
    local result = PackageManagerService:checkUidSignatures(myUid, 1000)
    return "Result: " .. result
end)

print("\n2. INSTALLED APPLICATIONS")
print("==========================")

testMethod("getInstalledApplications", function()
    local slice = PackageManagerService:getInstalledApplications(0, userId)
    if slice then
        local list = slice:getList()
        local count = 0
        for _ in pairs(astable(list)) do count = count + 1 end
        return "Total applications: " .. count
    end
    return "Error"
end)

testMethod("getInstalledPackages", function()
    local slice = PackageManagerService:getInstalledPackages(0, userId)
    if slice then
        local list = slice:getList()
        local count = 0
        for _ in pairs(astable(list)) do count = count + 1 end
        return "Total packages: " .. count
    end
    return "Error"
end)

testMethod("getAllPackages", function()
    local packages = PackageManagerService:getAllPackages()
    if packages then
        local count = 0
        for _ in pairs(astable(packages)) do count = count + 1 end
        return "Total: " .. count
    end
    return "Error"
end)

testMethod("getPersistentApplications", function()
    local slice = PackageManagerService:getPersistentApplications(0)
    if slice then
        local list = slice:getList()
        local count = 0
        for _ in pairs(astable(list)) do count = count + 1 end
        return "Persistent: " .. count
    end
    return "Error"
end)

testMethod("getPreferredPackages", function()
    local slice = PackageManagerService:getPreferredPackages(0, userId)
    if slice then
        local list = slice:getList()
        local count = 0
        for _ in pairs(astable(list)) do count = count + 1 end
        return "Preferred packages: " .. count
    end
    return "Error"
end)

print("\n3. INTENT RESOLUTION")
print("=====================")

testMethod("resolveIntent", function()
    local intent = Intent.new(Intent.ACTION_MAIN)
    intent:addCategory(Intent.CATEGORY_HOME)
    local info = PackageManagerService:resolveIntent(intent, intent:getType(), 0, userId)
    return info and "Resolved: " .. (info.activityInfo and info.activityInfo.name or "N/A") or "Not resolved"
end)

testMethod("queryIntentActivities", function()
    local intent = Intent.new(Intent.ACTION_MAIN)
    intent:addCategory(Intent.CATEGORY_LAUNCHER)
    local slice = PackageManagerService:queryIntentActivities(intent, intent:getType(), 0, userId)
    if slice then
        local list = slice:getList()
        local count = 0
        for _ in pairs(astable(list)) do count = count + 1 end
        return "Activities: " .. count
    end
    return "Error"
end)

testMethod("queryIntentServices", function()
    local intent = Intent.new(Intent.ACTION_VIEW)
    local slice = PackageManagerService:queryIntentServices(intent, intent:getType(), 0, userId)
    if slice then
        local list = slice:getList()
        local count = 0
        for _ in pairs(astable(list)) do count = count + 1 end
        return "Services: " .. count
    end
    return "Error"
end)

testMethod("queryIntentReceivers", function()
    local intent = Intent.new(Intent.ACTION_BOOT_COMPLETED)
    local slice = PackageManagerService:queryIntentReceivers(intent, intent:getType(), 0, userId)
    if slice then
        local list = slice:getList()
        local count = 0
        for _ in pairs(astable(list)) do count = count + 1 end
        return "Receivers: " .. count
    end
    return "Error"
end)

testMethod("queryIntentContentProviders", function()
    local intent = Intent.new(Intent.ACTION_VIEW, UriClass.parse("content://"))
    local slice = PackageManagerService:queryIntentContentProviders(intent, intent:getType(), 0, userId)
    if slice then
        local list = slice:getList()
        local count = 0
        for _ in pairs(astable(list)) do count = count + 1 end
        return "Providers: " .. count
    end
    return "Error"
end)

testMethod("resolveContentProvider", function()
    local info = PackageManagerService:resolveContentProvider("settings", 0, userId)
    return info and "Provider: " .. info.name or "Provider not found"
end)

testMethod("resolveService", function()
    local intent = Intent.new("android.intent.action.DIAL")
    local info = PackageManagerService:resolveService(intent, intent:getType(), 0, userId)
    return info and "Service resolved: " .. (info.serviceInfo and info.serviceInfo.name or "N/A") or "Service not found"
end)

print("\n4. PERMISSIONS")
print("===============")

testMethod("getPermissionInfo", function()
    local info = PackageManagerService:getPermissionInfo("android.permission.INTERNET", 0)
    return info and "Permission: " .. info.name or "Permission not found"
end)

testMethod("getPermissionGroupInfo", function()
    local info = PackageManagerService:getPermissionGroupInfo("android.permission-group.MESSAGES", 0)
    return info and info.name or "Group not found"
end)

testMethod("getAllPermissionGroups", function()
    local slice = PackageManagerService:getAllPermissionGroups(0, userId)
    if slice then
        local list = slice:getList()
        local count = 0
        for _ in pairs(astable(list)) do count = count + 1 end
        return "Permission groups: " .. count
    end
    return "Error"
end)

testMethod("getAppOpPermissionPackages", function()
    local packages = PackageManagerService:getAppOpPermissionPackages("android.permission.CAMERA")
    if packages then
        local count = 0
        for _ in pairs(astable(packages)) do count = count + 1 end
        return "Apps: " .. count
    end
    return "No apps"
end)

testMethod("isPermissionRevokedByPolicy", function()
    return "Revoked? " .. tostring(PackageManagerService:isPermissionRevokedByPolicy("android.permission.INTERNET", packageName, userId))
end)

testMethod("shouldShowRequestPermissionRationale", function()
    return "Show rationale? " .. tostring(PackageManagerService:shouldShowRequestPermissionRationale("android.permission.INTERNET", packageName, userId))
end)

print("\n5. APPLICATION STATE")
print("=====================")

testMethod("isPackageAvailable", function()
    return "Available? " .. tostring(PackageManagerService:isPackageAvailable(packageName, userId))
end)

testMethod("getBlockUninstallForUser", function()
    local blocked = PackageManagerService:getBlockUninstallForUser(packageName, userId)
    return "Blocked? " .. tostring(blocked)
end)

testMethod("isPackageSuspendedForUser", function()
    local suspended = PackageManagerService:isPackageSuspendedForUser(packageName, userId)
    return "Suspended? " .. tostring(suspended)
end)

testMethod("getPackageUid", function()
    local uid = PackageManagerService:getPackageUid(packageName, 0, userId)
    return "UID: " .. uid
end)

testMethod("getApplicationHiddenSettingAsUser", function()
    local hidden = PackageManagerService:getApplicationHiddenSettingAsUser(packageName, userId)
    return "Hidden? " .. tostring(hidden)
end)

print("\n6. INSTALLATION")
print("===============")

testMethod("getInstallLocation", function()
    local location = PackageManagerService:getInstallLocation()
    return "Install location: " .. location
end)

testMethod("getInstallReason", function()
    local reason = PackageManagerService:getInstallReason(packageName, userId)
    return "Install reason: " .. reason
end)

testMethod("getPackageInstaller", function()
    local installer = PackageManagerService:getPackageInstaller()
    return installer and "✓ Obtained" or "✗ Failed"
end)

testMethod("getMoveStatus", function()
    local status = PackageManagerService:getMoveStatus(0)
    return "Move status: " .. status
end)

print("\n7. SYSTEM FEATURES")
print("==================")

testMethod("hasSystemFeature", function()
    return "Camera: " .. tostring(PackageManagerService:hasSystemFeature("android.hardware.camera", 0))
end)

testMethod("getSystemAvailableFeatures", function()
    local slice = PackageManagerService:getSystemAvailableFeatures()
    if slice then
        local list = slice:getList()
        local count = 0
        for _ in pairs(astable(list)) do count = count + 1 end
        return "Total features: " .. count
    end
    return "Error"
end)

testMethod("getSystemSharedLibraryNames", function()
    local libs = PackageManagerService:getSystemSharedLibraryNames()
    if libs and #astable(libs) > 0 then
        return "Shared libs: " .. #astable(libs)
    end
    return "No shared libraries"
end)

testMethod("getServicesSystemSharedLibraryPackageName", function()
    local lib = PackageManagerService:getServicesSystemSharedLibraryPackageName()
    return lib or "N/A"
end)

testMethod("getSharedSystemSharedLibraryPackageName", function()
    local lib = PackageManagerService:getSharedSystemSharedLibraryPackageName()
    return lib or "N/A"
end)

print("\n8. PACKAGE NAMES")
print("=================")

testMethod("getPermissionControllerPackageName", function()
    local name = PackageManagerService:getPermissionControllerPackageName()
    return name or "N/A"
end)

testMethod("getSystemTextClassifierPackageName", function()
    local name = PackageManagerService:getSystemTextClassifierPackageName()
    return name or "N/A"
end)

testMethod("getServicesSystemSharedLibraryPackageName", function()
    local name = PackageManagerService:getServicesSystemSharedLibraryPackageName()
    return name or "N/A"
end)

testMethod("getSharedSystemSharedLibraryPackageName", function()
    local name = PackageManagerService:getSharedSystemSharedLibraryPackageName()
    return name or "N/A"
end)

print("\n9. INSTANT APPS")
print("=================")

testMethod("isInstantApp", function()
    return "Is instant? " .. tostring(PackageManagerService:isInstantApp(packageName, userId))
end)

testMethod("getInstantAppCookie", function()
    local cookie = PackageManagerService:getInstantAppCookie(packageName, userId)
    return cookie and "Cookie size: " .. #cookie .. " bytes" or "No cookie"
end)

testMethod("getInstantAppInstallerComponent", function()
    local component = PackageManagerService:getInstantAppInstallerComponent()
    return component and component:flattenToString() or "N/A"
end)

testMethod("getInstantAppResolverComponent", function()
    local component = PackageManagerService:getInstantAppResolverComponent()
    return component and component:flattenToString() or "N/A"
end)

testMethod("getInstantAppResolverSettingsComponent", function()
    local component = PackageManagerService:getInstantAppResolverSettingsComponent()
    return component and component:flattenToString() or "N/A"
end)

print("\n10. CERTIFICATES")
print("=================")

testMethod("hasSigningCertificate", function()
    return "Has cert? " .. tostring(PackageManagerService:hasSigningCertificate(packageName, {}, 0))
end)

testMethod("hasUidSigningCertificate", function()
    return "UID has cert? " .. tostring(PackageManagerService:hasUidSigningCertificate(myUid, {}, 0))
end)

print("\n11. SYSTEM STATE")
print("=================")

testMethod("isFirstBoot", function()
    return "First boot? " .. tostring(PackageManagerService:isFirstBoot())
end)

testMethod("isDeviceUpgrading", function()
    return "Device upgrading? " .. tostring(PackageManagerService:isDeviceUpgrading())
end)

testMethod("isSafeMode", function()
    return "Safe mode? " .. tostring(PackageManagerService:isSafeMode())
end)

testMethod("isStorageLow", function()
    return "Storage low? " .. tostring(PackageManagerService:isStorageLow())
end)

testMethod("hasSystemUidErrors", function()
    return "UID errors? " .. tostring(PackageManagerService:hasSystemUidErrors())
end)

print("\n12. MANAGEMENT (READ-ONLY)")
print("===========================")

testMethod("getChangedPackages", function()
    local changed = PackageManagerService:getChangedPackages(0, userId)
    if changed then
        local packages = changed:getPackageNames()
        return "Packages changed: " .. packages:size()
    end
    return "No changes"
end)

testMethod("getArtManager", function()
    local manager = PackageManagerService:getArtManager()
    return manager and "✓ Obtained" or "✗ Failed"
end)

testMethod("getUidForSharedUser", function()
    local uid = PackageManagerService:getUidForSharedUser("android.uid.system")
    return "Shared user UID: " .. uid
end)

print("\n13. DEX/OPTIMIZATION")
print("=====================")

testMethod("notifyPackageUse", function()
    PackageManagerService:notifyPackageUse(packageName, 1)
    return "✓ Executed"
end)

testMethod("getPackageSizeInfo", function()
    local success, result = pcall(function()
        PackageManagerService:getPackageSizeInfo(packageName, userId, nil)
    end)
    return success and "✓ Executed" or "✗ Failed"
end)