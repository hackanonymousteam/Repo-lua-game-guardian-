import "android.ext.*"
import "android.app.*"
import "android.os.*"
import "android.content.*"
import "android.net.Uri"
import "android.widget.*"
import "android.view.*"
import "java.io.*"
import "java.util.*"

local Class = luajava.bindClass
local new = luajava.new
local astable = luajava.astable

local ActivityManagerNative = Class("android.app.ActivityManagerNative")
local am = ActivityManagerNative:getDefault()

local Process = Class("android.os.Process")
local UserHandle = Class("android.os.UserHandle")

local function testMethod(methodName, func)
    print("▶ " .. methodName)
    local success, result = pcall(func)
    if success then
        if result ~= nil then
            print("  ✓ " .. tostring(result))
        else
            print("  ✓ (success)")
        end
    else
        print("  ✗ Error: " .. tostring(result))
    end
    print("")
end

testMethod("getConfiguration", function()
    return "Current configuration: " .. tostring(am:getConfiguration())
end)

testMethod("getLockTaskModeState", function()
    return "LockTaskModeState: " .. am:getLockTaskModeState()
end)

testMethod("isInLockTaskMode", function()
    return "In lock task mode? " .. tostring(am:isInLockTaskMode())
end)

testMethod("isUserAMonkey", function()
    return "Is monkey? " .. tostring(am:isUserAMonkey())
end)

testMethod("getRunningAppProcesses", function()
    local processes = am:getRunningAppProcesses()
    if processes then
        local count = 0
        for _ in pairs(astable(processes)) do 
            count = count + 1 
        end
        return "Running processes: " .. count
    end
    return "No processes found"
end)

testMethod("getRunningExternalApplications", function()
    local apps = am:getRunningExternalApplications()
    if apps then
        local count = 0
        for _ in pairs(astable(apps)) do 
            count = count + 1 
        end
        return "External applications: " .. count
    end
    return "No external apps"
end)

testMethod("getProcessesInErrorState", function()
    local errors = am:getProcessesInErrorState()
    return errors and "Processes in error state found" or "No processes in error state"
end)

testMethod("getMemoryTrimLevel", function()
    return "Memory trim level: " .. am:getMemoryTrimLevel()
end)

testMethod("getProcessLimit", function()
    return "Process limit: " .. am:getProcessLimit()
end)

print("\n1. PERMISSION CHECKS")
print("-------------------")

testMethod("checkPermission", function()
    local result = am:checkPermission("android.permission.INTERNET", Process.myUid(), Process.myPid())
    return "INTERNET permission: " .. (result == 0 and "✓ granted" or "✗ denied")
end)

print("\n2. TASKS")
print("--------")

testMethod("getTasks", function()
    local tasks = am:getTasks(10)
    if tasks then
        local count = 0
        for _ in pairs(astable(tasks)) do 
            count = count + 1 
        end
        return "Current tasks: " .. count
    end
    return "No tasks found"
end)

testMethod("getRecentTasks", function()
    local recentTasks = am:getRecentTasks(5, 0, UserHandle.myUserId())
    if recentTasks then
        local tasks = recentTasks:getList()
        local count = 0
        for _ in pairs(astable(tasks)) do 
            count = count + 1 
        end
        return "Recent tasks: " .. count
    end
    return "No recent tasks found"
end)

print("\n3. SERVICES")
print("----------")

testMethod("getServices", function()
    local services = am:getServices(10, 0)
    if services then
        local count = 0
        for _ in pairs(astable(services)) do 
            count = count + 1 
        end
        return "Running services: " .. count
    end
    return "No services found"
end)

print("CONTENT PROVIDERS")
print("-------------------")

testMethod("openContentUri", function()
    local success, result = pcall(function()
        return am:openContentUri("content://settings/secure")
    end)
    return success and "✓ Content URI can be opened" or "✗ Failed to open Content URI"
end)

testMethod("isTopActivityImmersive", function()
    return "Top activity immersive? " .. tostring(am:isTopActivityImmersive())
end)

print(" MISSING PERMISSIONS")
print("----------------------")

local missingPermissions = {
    "android.permission.INTERACT_ACROSS_USERS",
    "android.permission.MANAGE_ACTIVITY_STACKS",
    "android.permission.PACKAGE_USAGE_STATS",
    "android.permission.SET_PROCESS_LIMIT",
    "android.permission.INTERACT_ACROSS_USERS_FULL"
}

for _, perm in ipairs(missingPermissions) do
    local result = pcall(function()
        return am:checkPermission(perm, Process.myUid(), Process.myPid())
    end)
    print("  ✗ " .. perm)
end