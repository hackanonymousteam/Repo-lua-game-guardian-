local Class = luajava.bindClass
local new = luajava.new

local ActivityThread = Class("android.app.ActivityThread")
local Debug = Class("android.os.Debug")
local MemoryInfo = Class("android.os.Debug$MemoryInfo")
local PrintWriter = Class("java.io.PrintWriter")
local StringWriter = Class("java.io.StringWriter")
local Process = Class("android.os.Process")

print("========================================")
print("TEST - android.app.ActivityThread")
print("WORKING METHODS")
print("========================================\n")

print("--- STATIC METHODS ---\n")

local isSystem = ActivityThread:isSystem()
print("1. isSystem():", isSystem)

local packageManager = ActivityThread:getPackageManager()
print("2. getPackageManager():", tostring(packageManager))

local intentBeingBroadcast = ActivityThread:getIntentBeingBroadcast()
print("3. getIntentBeingBroadcast():", tostring(intentBeingBroadcast))

local activityThread = ActivityThread:currentActivityThread()
print("\n currentActivityThread():", tostring(activityThread))

print("\n--- dumpMemInfoTable ---")

local stringWriter = new(StringWriter)
local printWriter = new(PrintWriter, stringWriter)
local memInfo = new(MemoryInfo)

print("\n--- BASIC GETTERS ---\n")

print("getProcessName():", activityThread:getProcessName())
print("getApplication():", tostring(activityThread:getApplication()))
print("getInstrumentation():", tostring(activityThread:getInstrumentation()))
print("getLooper():", tostring(activityThread:getLooper()))
print("getSystemContext():", tostring(activityThread:getSystemContext()))
print("getSystemUiContext():", tostring(activityThread:getSystemUiContext()))
print("isProfiling():", activityThread:isProfiling())
print("getIntCoreSetting('persist.sys.timezone', 0):", activityThread:getIntCoreSetting("persist.sys.timezone", 0))
print("getApplicationThread():", tostring(activityThread:getApplicationThread()))
print("getExecutor():", tostring(activityThread:getExecutor()))

print("\n--- WORKING METHODS (WITH PROTECTION) ---\n")

local success, result = pcall(function()
    activityThread:updateProcessState(Process.STATE_TOP, false)
    return true
end)
print("updateProcessState():", success and "✓ WORKED" or "✗ FAILED")

success, result = pcall(function()
    activityThread:stopProfiling()
    return true
end)
print("stopProfiling():", success and "✓ WORKED" or "✗ FAILED")

print("\n--- PRACTICAL EXAMPLE ---\n")

local currentProcess = activityThread:getProcessName()
print("Current process:", currentProcess)

if packageManager then
    success, result = pcall(function()
        local pkgInfo = packageManager:getPackageInfo(currentProcess, 0)
        return pkgInfo
    end)
    
    if success and result then
        print("Package found:", tostring(result))
        print("  Version:", result.versionName or "N/A")
        print("  Code:", result.versionCode or 0)
    else
        print("Could not get package info:", currentProcess)
    end
end

