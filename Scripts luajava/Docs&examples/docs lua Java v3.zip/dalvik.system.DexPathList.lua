import "android.ext.*"
import "dalvik.system.*"
import "java.io.*"
import "java.nio.*"
import "java.util.*"

local Class = luajava.bindClass
local new = luajava.new
local astable = luajava.astable

local DexPathList = Class("dalvik.system.DexPathList")
local BaseDexClassLoader = Class("dalvik.system.BaseDexClassLoader")
local FileClass = Class("java.io.File")
local ByteBuffer = Class("java.nio.ByteBuffer")
local ArrayList = Class("java.util.ArrayList")

local context = luajava.bindClass("android.app.ActivityThread"):currentApplication():getApplicationContext()
local packageName = context:getPackageName()

print("=== DEXPATHLIST TESTS ===\n")
print("Current package: " .. packageName)
print("")

local function testMethod(methodName, func)
    print("▶ " .. methodName)
    local success, result = pcall(func)
    if success then
        if result ~= nil then
            if type(result) == "boolean" then
                print("  ✓ Success: " .. tostring(result))
            elseif type(result) == "number" then
                print("  ✓ Success: " .. result)
            elseif type(result) == "string" then
                print("  ✓ Success: " .. result)
            elseif type(result) == "userdata" then
                if tostring(result):find("Element") then
                    print("  ✓ Success: Element[] obtained")
                else
                    print("  ✓ Success: " .. tostring(result))
                end
            else
                print("  ✓ Success: " .. tostring(result))
            end
        else
            print("  ✓ Executed successfully")
        end
    else
        local errMsg = tostring(result)
        if errMsg:find("SecurityException") then
            errMsg = errMsg:match("java%.lang%.SecurityException: [^\n]+") or errMsg
            print("  ✗ [Permission] " .. errMsg)
        elseif errMsg:find("IllegalArgumentException") then
            errMsg = errMsg:match("java%.lang%.IllegalArgumentException: [^\n]+") or errMsg
            print("  ✗ [Argument] " .. errMsg)
        elseif errMsg:find("NullPointerException") then
            print("  ✗ [Null] Requires valid parameters")
        elseif errMsg:find("NoSuchFieldError") then
            print("  ✗ [Field] " .. errMsg)
        else
            print("  ✗ Error: " .. errMsg)
        end
    end
    print("")
end

testMethod("makeInMemoryDexElements", function()
    local buffers = { ByteBuffer.allocate(1024) }
    local suppressed = new(ArrayList)
    
    local elements = DexPathList.makeInMemoryDexElements(buffers, suppressed)
    
    if elements then
        return "✓ In-memory elements created: " .. #astable(elements)
    end
    return "✗ Failed to create in-memory elements"
end)

local classLoader = context:getClassLoader()
print("ClassLoader: " .. tostring(classLoader))
print("Type: " .. classLoader:getClass():getName())

if classLoader:getClass():getName():find("BaseDexClassLoader") then
    print("✓ Is a BaseDexClassLoader (contains DexPathList)")
    
    local pathListField = pcall(function()
        return classLoader:getClass():getDeclaredField("pathList")
    end)
    
    if pathListField then
        print("  → pathList field found")
    else
        print("  → pathList field not directly accessible")
    end
end