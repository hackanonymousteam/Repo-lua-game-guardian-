import "android.ext.*"
import "android.net.*"
import "android.os.*"
import "android.content.*"
import "android.util.*"
import "java.io.*"
import "java.util.*"

local Class = luajava.bindClass
local new = luajava.new
local astable = luajava.astable

local NetworkAgent = Class("android.net.NetworkAgent")
local NetworkPolicyManager = Class("android.net.NetworkPolicyManager")
local NetworkScoreManager = Class("android.net.NetworkScoreManager")
local NetworkStats = Class("android.net.NetworkStats")
local NetworkStatsHistory = Class("android.net.NetworkStatsHistory")
local NetworkTemplate = Class("android.net.NetworkTemplate")
local NetworkIdentity = Class("android.net.NetworkIdentity")
local NetworkCapabilities = Class("android.net.NetworkCapabilities")
local LinkProperties = Class("android.net.LinkProperties")
local NetworkInfo = Class("android.net.NetworkInfo")
local Parcel = Class("android.os.Parcel")
local Handler = Class("android.os.Handler")
local Looper = Class("android.os.Looper")
local Random = Class("java.util.Random")

local context = luajava.bindClass("android.app.ActivityThread"):currentApplication():getApplicationContext()
local packageName = context:getPackageName()

print("=== NETWORK CLASSES TESTS ===\n")
print("Current package: " .. packageName)
print("")

local function testMethod(methodName, func)
    print("▶ " .. methodName)
    local success, result = pcall(func)
    if success then
        if result ~= nil then
            if type(result) == "boolean" then
                print("  ✓ Success: " .. tostring(result))
            elseif type(result) == "number" then
                print("  ✓ Success: " .. result)
            elseif type(result) == "string" then
                print("  ✓ Success: " .. result)
            elseif type(result) == "userdata" then
                print("  ✓ Success: " .. tostring(result))
            else
                print("  ✓ Success: " .. tostring(result))
            end
        else
            print("  ✓ Executed successfully")
        end
    else
        local errMsg = tostring(result)
        if errMsg:find("SecurityException") then
            errMsg = errMsg:match("java%.lang%.SecurityException: [^\n]+") or errMsg
            print("  ✗ [Permission] " .. errMsg)
        elseif errMsg:find("IllegalArgumentException") then
            errMsg = errMsg:match("java%.lang%.IllegalArgumentException: [^\n]+") or errMsg
            print("  ✗ [Argument] " .. errMsg)
        elseif errMsg:find("NullPointerException") then
            print("  ✗ [Null] Requires valid parameters")
        elseif errMsg:find("NoSuchMethodError") then
            print("  ✗ [Method] " .. errMsg)
        elseif errMsg:find("attempt to call a nil value") then
            print("  ✗ [Method] Method not available")
        else
            print("  ✗ Error: " .. errMsg)
        end
    end
    print("")
end

print("1. NETWORKAGENT CLASS TESTS (HANDLER METHODS)")
print("==============================================")

testMethod("Handler.getMain", function()
    return "Main Handler: " .. tostring(Handler.getMain())
end)

testMethod("Handler.getLooper", function()
    local handler = Handler.getMain()
    return "Looper: " .. tostring(handler:getLooper())
end)

testMethod("Handler.hasCallbacks (skipped)", function()
    return "ℹ hasCallbacks method requires valid Runnable"
end)

testMethod("Handler.hasMessages (skipped)", function()
    return "ℹ hasMessages method requires valid Message"
end)

print("\n2. NETWORKFACTORY CLASS TESTS (HANDLER METHODS)")
print("=================================================")

testMethod("Handler.getMain (repeated)", function()
    return "Main Handler: " .. tostring(Handler.getMain())
end)

print("\n3. NETWORKPOLICYMANAGER CLASS TESTS (STATIC METHODS)")
print("======================================================")

testMethod("isProcStateAllowedWhileIdleOrPowerSaveMode", function()
    return "Allowed while idle: " .. tostring(NetworkPolicyManager.isProcStateAllowedWhileIdleOrPowerSaveMode(2))
end)

testMethod("isProcStateAllowedWhileOnRestrictBackground", function()
    return "Allowed on restrict background: " .. tostring(NetworkPolicyManager.isProcStateAllowedWhileOnRestrictBackground(2))
end)

testMethod("resolveNetworkId (string)", function()
    return "Network ID: " .. NetworkPolicyManager.resolveNetworkId("test_network")
end)

testMethod("uidPoliciesToString", function()
    return "UID policies string: " .. NetworkPolicyManager.uidPoliciesToString(3)
end)

testMethod("uidRulesToString", function()
    return "UID rules string: " .. NetworkPolicyManager.uidRulesToString(3)
end)

print("\n4. NETWORKSCOREMANAGER CLASS TESTS")
print("====================================")

print("⚠ NetworkScoreManager requires SCORE_NETWORKS permission - skipping tests\n")

print("6. NETWORKSTATS CLASS TESTS")
print("============================")

local networkStats = new(NetworkStats, 1000, 10)
print("✓ NetworkStats instance created\n")

testMethod("NetworkStats.size", function()
    return "Size: " .. networkStats:size()
end)

testMethod("NetworkStats.getElapsedRealtime", function()
    return "Elapsed realtime: " .. networkStats:getElapsedRealtime()
end)

testMethod("NetworkStats.getUniqueIfaces", function()
    local ifaces = networkStats:getUniqueIfaces()
    return ifaces and "Interfaces: " .. #astable(ifaces) or "No interfaces"
end)

testMethod("NetworkStats.getUniqueUids", function()
    local uids = networkStats:getUniqueUids()
    return uids and "UIDs: " .. #astable(uids) or "No UIDs"
end)

testMethod("NetworkStats.defaultNetworkToString", function()
    return "Default network: " .. NetworkStats.defaultNetworkToString(0)
end)

testMethod("NetworkStats.meteredToString", function()
    return "Metered string: " .. NetworkStats.meteredToString(0)
end)

testMethod("NetworkStats.roamingToString", function()
    return "Roaming string: " .. NetworkStats.roamingToString(0)
end)

testMethod("NetworkStats.setToString", function()
    return "Set string: " .. NetworkStats.setToString(0)
end)

testMethod("NetworkStats.tagToString", function()
    return "Tag string: " .. NetworkStats.tagToString(0)
end)

print("\n5. NETWORKSTATSHISTORY CLASS TESTS")
print("====================================")

local history = new(NetworkStatsHistory, 1000)
print("✓ NetworkStatsHistory instance created\n")

testMethod("NetworkStatsHistory.size", function()
    return "Size: " .. history:size()
end)

testMethod("NetworkStatsHistory.getStart", function()
    return "Start: " .. history:getStart()
end)

testMethod("NetworkStatsHistory.getEnd", function()
    return "End: " .. history:getEnd()
end)

testMethod("NetworkStatsHistory.getTotalBytes", function()
    return "Total bytes: " .. history:getTotalBytes()
end)

testMethod("NetworkStatsHistory.intersects", function()
    return "Intersects: " .. tostring(history:intersects(0, 1000))
end)

testMethod("NetworkStatsHistory.randomLong (skipped)", function()
    return "ℹ randomLong method requires java.util.Random"
end)

print("\n6. NETWORKTEMPLATE CLASS TESTS")
print("===============================")

local template = NetworkTemplate.buildTemplateMobileAll("12345")
print("✓ NetworkTemplate instance created\n")

testMethod("NetworkTemplate.getMatchRule", function()
    return "Match rule: " .. template:getMatchRule()
end)

testMethod("NetworkTemplate.getSubscriberId", function()
    return "Subscriber ID: " .. (template:getSubscriberId() or "N/A")
end)

testMethod("NetworkTemplate.getNetworkId", function()
    return "Network ID: " .. (template:getNetworkId() or "N/A")
end)

testMethod("NetworkTemplate.isMatchRuleMobile", function()
    return "Is mobile: " .. tostring(template:isMatchRuleMobile())
end)

testMethod("NetworkTemplate.isPersistable", function()
    return "Is persistable: " .. tostring(template:isPersistable())
end)

testMethod("NetworkTemplate.forceAllNetworkTypes", function()
    NetworkTemplate.forceAllNetworkTypes()
    return "forceAllNetworkTypes executed"
end)

testMethod("NetworkTemplate.equals", function()
    local template2 = NetworkTemplate.buildTemplateMobileAll("12345")
    return "Templates equal: " .. tostring(template:equals(template2))
end)

testMethod("NetworkTemplate.hashCode", function()
    return "HashCode: " .. template:hashCode()
end)

testMethod("NetworkTemplate.toString", function()
    return "toString: " .. template:toString()
end)