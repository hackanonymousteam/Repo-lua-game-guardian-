import "android.ext.*"
import "android.os.*"
import "android.content.*"
import "android.graphics.*"
import "android.util.*"
import "java.io.*"
import "java.util.*"

local Class = luajava.bindClass
local new = luajava.new
local astable = luajava.astable

local ServiceManager = Class("android.os.ServiceManager")
local IUserManager = Class("android.os.IUserManager")
local RemoteCallback = Class("android.os.RemoteCallback")
local SystemProperties = Class("android.os.SystemProperties")
local Parcel = Class("android.os.Parcel")
local Bundle = Class("android.os.Bundle")
local PersistableBundle = Class("android.os.PersistableBundle")
local UserHandle = Class("android.os.UserHandle")
local Process = Class("android.os.Process")

local context = luajava.bindClass("android.app.ActivityThread"):currentApplication():getApplicationContext()
local packageName = context:getPackageName()
local userId = UserHandle.myUserId()

print("=== ANDROID.OS CLASSES TESTS ===\n")
print("Current package: " .. packageName)
print("User ID: " .. userId)
print("")

local function testMethod(methodName, func)
    print("▶ " .. methodName)
    local success, result = pcall(func)
    if success then
        if result ~= nil then
            if type(result) == "boolean" then
                print("  ✓ Success: " .. tostring(result))
            elseif type(result) == "number" then
                print("  ✓ Success: " .. result)
            elseif type(result) == "string" then
                print("  ✓ Success: " .. result)
            elseif type(result) == "userdata" then
                if tostring(result):find("UserInfo") then
                    print("  ✓ Success: UserInfo obtained")
                elseif tostring(result):find("Bundle") then
                    print("  ✓ Success: Bundle obtained")
                else
                    print("  ✓ Success: " .. tostring(result))
                end
            else
                print("  ✓ Success: " .. tostring(result))
            end
        else
            print("  ✓ Executed successfully")
        end
    else
        local errMsg = tostring(result)
        if errMsg:find("SecurityException") then
            errMsg = errMsg:match("java%.lang%.SecurityException: [^\n]+") or errMsg
            print("  ✗ [Permission] " .. errMsg)
        elseif errMsg:find("IllegalArgumentException") then
            errMsg = errMsg:match("java%.lang%.IllegalArgumentException: [^\n]+") or errMsg
            print("  ✗ [Argument] " .. errMsg)
        elseif errMsg:find("NullPointerException") then
            print("  ✗ [Null] Requires valid parameters")
        elseif errMsg:find("RemoteException") then
            print("  ✗ [Remote] " .. errMsg)
        elseif errMsg:find("DeadObjectException") then
            print("  ✗ [Dead] Service is not responding")
        else
            print("  ✗ Error: " .. errMsg)
        end
    end
    print("")
end

print("1. SERVICEMANAGER CLASS TESTS")
print("==============================")

testMethod("ServiceManager.listServices", function()
    local services = ServiceManager.listServices()
    if services then
        local serviceList = {}
        for i, service in ipairs(astable(services)) do
            table.insert(serviceList, service)
            if i <= 5 then
                print("    " .. i .. ". " .. service)
            end
        end
        return "Total services: " .. #serviceList
    end
    return "No services found"
end)

print("\n4. SYSTEMPROPERTIES CLASS TESTS")
print("=================================")

local propertiesToTest = {
    "ro.build.version.sdk",
    "ro.build.version.release",
    "ro.product.model",
    "ro.product.manufacturer",
    "ro.product.brand",
    "ro.product.device",
    "ro.build.fingerprint",
    "persist.sys.timezone",
    "ro.carrier",
    "ro.boot.mode"
}

for _, prop in ipairs(propertiesToTest) do
    testMethod("SystemProperties.get('" .. prop .. "')", function()
        local value = SystemProperties.get(prop, "not found")
        return prop .. " = " .. value
    end)
end

testMethod("SystemProperties.reportSyspropChanged", function()
    SystemProperties.reportSyspropChanged()
    return "reportSyspropChanged executed"
end)