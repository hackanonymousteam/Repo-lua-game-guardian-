g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)

if g.data ~= nil then
    g.info = g.data()
    g.data = nil
end

if g.info == nil then
    g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end

local function randomVarName()
    local letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    local length = math.random(3, 6)  
    local name = "v"
    for i = 1, length do
        local idx = math.random(1, #letters)  
        name = name .. letters:sub(idx, idx)
    end
    return name .. math.random(10, 99) 
end

local function safeRandomNumber()
    return math.random(1000, 9999)
end

local function safeRandomDivisor()
    local n = 0
    while n == 0 do
        n = math.random(1, 999)
    end
    return n
end

local function randomNumber()
    local operators = {"+", "-", "*"}
    if math.random(1, 2) == 1 then
        return safeRandomNumber() - safeRandomNumber()
    else
        local a = safeRandomNumber()
        local b = safeRandomNumber()
        local op = operators[math.random(1, #operators)]
        return "(" .. a .. op .. b .. ")"
    end
end

local function randomSmallNumber()
    return math.random(0, 255)
end

local function randomExpression()
    local exprs = {
        function() return tostring(randomNumber()) end,
        function() return "(" .. randomNumber() .. " + " .. randomNumber() .. ")" end,
        function() return "(" .. randomNumber() .. " - " .. randomNumber() .. ")" end,
        function() return "(" .. randomNumber() .. " * " .. randomNumber() .. ")" end,
        function() return "(0 - " .. randomNumber() .. ")" end,
    }
    return exprs[math.random(1, #exprs)]()
end

function generateEncodedString(code)
    local encoded = {}
    for i = 1, #code do
        local byte = string.byte(code, i)
        byte = (byte + 50) % 256
        encoded[i] = string.format("%02x", byte)
    end
    return table.concat(encoded)
end

function generateLoader(originalCode)
    local vars = setmetatable({}, {
        __index = function(t, k)
            local v = randomVarName()
            rawset(t, k, v)
            return v
        end
    })
    
    local loader = {}
    local function add(line)
        table.insert(loader, line)
    end
    
    add("local " .. vars[0] .. "=tonumber;    ")
    add("local " .. vars[1] .. "=string.byte;local " .. vars[2] .. "=string.char;local ")
    add(vars[3] .. "=string.sub;local " .. vars[4] .. "=string.gsub;local " .. vars[5] .. "=string.rep;local ")
    add(vars[6] .. "=table.concat;local " .. vars[7] .. "=table.insert;local " .. vars[8] .. "=math.ldexp;local " .. vars[9] .. "=    ")
    add("getfenv or function() return _ENV;end ;local " .. vars[10] .. "=setmetatable;local " .. vars[11] .. "=pcall ")
    add(";local " .. vars[12] .. "=select;local " .. vars[13] .. "=unpack or table.unpack ;local " .. vars[14] .. "=tonumber;local      ")
    add("function " .. vars[15] .. "(" .. vars[16] .. ")")
    add("local " .. vars[17] .. "=" .. vars[3] .. "(" .. vars[16] .. ",4)")
    add("local " .. vars[18] .. "=" .. vars[4] .. "(" .. vars[17] .. ", \"%x%x\", function(" .. vars[19] .. ")")
    add("local " .. vars[20] .. "=" .. vars[0] .. "(" .. vars[19] .. ",16)")
    add("local " .. vars[21] .. "= (" .. vars[20] .. " - 50) % 256")
    add("return " .. vars[2] .. "(" .. vars[21] .. ")")
    add("end)")
    add("return " .. vars[18])
    add("end")
    add("local function " .. vars[22] .. "(" .. vars[23] .. "," .. vars[24] .. "," .. vars[25] .. ") if " .. vars[25] .. " then local " .. vars[26] .. "=" .. randomExpression() .. ";local " .. vars[27] .. ";while true   ")
    add("do if (" .. vars[26] .. "==" .. randomExpression() .. ") then local " .. vars[28] .. "=0;while true do if (" .. vars[28] .. "==" .. randomExpression() .. ") then " .. vars[27] .. "=(" .. vars[23] .. "/((" .. randomSmallNumber() .. ")^ ")
    add("(" .. vars[24] .. "-" .. randomSmallNumber() .. ")))%(2^(((" .. vars[25] .. "-" .. randomSmallNumber() .. ") -(" .. vars[24] .. "-(" .. randomSmallNumber() .. "))) + " .. randomSmallNumber() .. ")) ;return " .. vars[27] .. "-(" .. vars[27] .. "%1) ;end end end end   ")
    add("else local " .. vars[29] .. "=" .. randomExpression() .. ";local " .. vars[30] .. ";while true do if (" .. vars[29] .. "==" .. randomExpression() .. ") then " .. vars[30] .. "=" .. randomSmallNumber() .. "^(" .. vars[24] .. "-" .. randomSmallNumber() .. ") ;return (((" .. vars[23] .. "%(" .. vars[30] .. "+" .. vars[30] .. "))>=" .. vars[30] .. ") and (" .. randomSmallNumber() .. ")) or (" .. randomSmallNumber() .. ") ;end end end end ")
    add("local function " .. vars[31] .. "() local " .. vars[32] .. "=0;local " .. vars[33] .. ";while true do local " .. vars[34] .. "=" .. randomExpression() .. ";while true do if (0==" .. vars[34] .. ") then if (" .. vars[32] .. "==0) then " .. vars[33] .. "=" .. vars[1] .. " ")
    add("(" .. vars[18] .. "," .. vars[35] .. "," .. vars[35] .. ");" .. vars[35] .. "=" .. vars[35] .. " + 1 ;" .. vars[32] .. "=1;end if ((" .. randomSmallNumber() .. ")==" .. vars[32] .. ") then return " .. vars[33] .. ";end break;end end end end ")
    add("local function " .. vars[36] .. "() local " .. vars[37] .. "=" .. randomExpression() .. ";local " .. vars[38] .. ";local " .. vars[39] .. ";while true do local " .. vars[40] .. "=0;while true do if (" .. vars[40] .. "==0) then if (" .. vars[37] .. "==" .. randomSmallNumber() .. ") then return (" .. vars[39] .. " * " .. randomSmallNumber() .. ") + " .. vars[38] .. " ;end if (" .. vars[37] .. "==" .. randomExpression() .. ") then " .. vars[38] .. "," .. vars[39] .. "=" .. vars[1] .. "(" .. vars[18] .. "," .. vars[35] .. "," .. vars[35] .. " + 2 );" .. vars[35] .. "=" .. vars[35] .. " + ")
    add("(" .. randomSmallNumber() .. ") ;" .. vars[37] .. "=1;end break;end end end end ")
    add("local function " .. vars[41] .. "() local " .. vars[42] .. "," .. vars[43] .. "," .. vars[44] .. "," .. vars[45] .. "=" .. vars[1] .. "(" .. vars[18] .. "," .. vars[35] .. "," .. vars[35] .. " + 3 + 0 );" .. vars[35] .. "=  ")
    add(vars[35] .. " + 4 + 0 ;return (" .. vars[45] .. " * 16777216) + (" .. vars[44] .. " * " .. randomSmallNumber() .. ") + (" .. vars[43] .. " * 256) + " .. vars[42] .. " ;end ")
    add("local function " .. vars[46] .. "() local " .. vars[47] .. "=" .. randomExpression() .. ";local " .. vars[48] .. ";local " .. vars[49] .. ";local " .. vars[50] .. ";local " .. vars[51] .. ";local " .. vars[52] .. ";local " .. vars[53] .. ";local " .. vars[54] .. ";while true do if (" .. vars[47] .. "==" .. randomExpression() .. ") then " .. vars[54] .. "=nil;while true do if (" .. vars[48] .. "==" .. randomSmallNumber() .. ") then " .. vars[51] .. "=" .. randomSmallNumber() .. ";" .. vars[52] .. "=( " .. vars[22] .. "(" .. vars[50] .. ",1," .. randomSmallNumber() .. " ) * (2 ")
    add("^(" .. randomSmallNumber() .. "))) + " .. vars[49] .. " ;" .. vars[48] .. "=" .. randomSmallNumber() .. " ;end if (" .. vars[48] .. "==2)    " .. "then " .. vars[53] .. "=" .. vars[22] .. "(" .. vars[50] .. ",21 ")
    add(",31);" .. vars[54] .. "=((" .. vars[22] .. "(" .. vars[50] .. ",32)==" .. randomSmallNumber() .. ") and  -(" .. randomExpression() .. ")) or " .. randomSmallNumber() .. " ;" .. vars[48] .. "=" .. randomExpression() .. " ;end if (" .. vars[48] .. "==" .. randomSmallNumber() .. ") then " .. " if (" .. vars[53] .. "==0) then ")
    add("if (" .. vars[52] .. "==" .. randomExpression() .. ") then return " .. vars[54] .. " * (" .. randomSmallNumber() .. ") ;else     ")
    add("local " .. vars[55] .. "=" .. randomExpression() .. ";while true do if (" .. vars[55] .. "==" .. randomExpression() .. ")    " .. "then " .. vars[53] .. "=" .. randomSmallNumber() .. ";")
    add(vars[51] .. "=" .. randomExpression() .. ";break;end end end elseif (" .. vars[53] .. "==2047) then  ")
    add("return ((" .. vars[52] .. "==" .. randomSmallNumber() .. ") and (" .. vars[54] .. " * ((" .. randomSmallNumber() .. ")/(0   ")
    add("+ 0)))) or (" .. vars[54] .. " * NaN) ;end return " .. vars[8] .. "(" .. vars[54] .. "," .. vars[53] .. "-1023 ) " .. " * (" .. vars[51] .. " + (   ")
    add(vars[52] .. "/(2^(" .. randomSmallNumber() .. ")))) ;end if (" .. vars[48] .. "==" .. randomExpression() .. ") then local " .. vars[56] .. "=" .. "0;while true do ")
    add("if (" .. vars[56] .. "==" .. randomSmallNumber() .. ") then " .. vars[49] .. "=" .. vars[41] .. "();" .. vars[50] .. "=" .. vars[41] .. "();" .. vars[56] .. "=1;end if (    " .. vars[56] .. "==" .. randomSmallNumber() .. ") then " .. vars[48] .. "=" .. randomSmallNumber() .. ";break;end end end end break;end if (" .. vars[47] .. "==" .. randomExpression() .. ")  ")
    add("then " .. vars[50] .. "=nil;" .. vars[51] .. "=nil;" .. vars[47] .. "=" .. randomSmallNumber() .. " ;end if (0==" .. vars[47] .. ") then " .. vars[48] .. "=0;" .. vars[49] .. "=nil;" .. vars[47] .. "=" .. randomSmallNumber() .. " ;end  if (" .. vars[47] .. "==2)  ")
    add("then " .. vars[52] .. "=nil;" .. vars[53] .. "=nil;" .. vars[47] .. "=3;end end end ")
    add("local function " .. vars[57] .. "(" .. vars[58] .. ") local " .. vars[59] .. ";if  not  " .. vars[58] .. " then " .. vars[58] .. "= ")
    add(vars[41] .. "();if (" .. vars[58] .. "==" .. randomExpression() .. ") then return \"\";end end " .. vars[59] .. "=" .. vars[3] .. "(" .. vars[18] .. "," .. vars[35] .. ",(" .. vars[35] .. " +  " .. vars[58] .. ") -1 );" .. vars[35] .. " ")
    add("=" .. vars[35] .. " + " .. vars[58] .. " ;local " .. vars[60] .. "={};for " .. vars[61] .. "=" .. randomSmallNumber() .. " , #" .. vars[59] .. " do " .. vars[60] .. "[" .. vars[61] .. "]=" .. vars[2] .. "(" .. vars[1] .. "(" .. vars[3] .. "(" .. vars[59] .. "," .. vars[61] .. "," .. vars[61] .. ")));  ")
    add("end return " .. vars[6] .. "(" .. vars[60] .. ");end")
    add("local function " .. vars[62] .. "()")
    add("local " .. vars[63] .. "=" .. vars[15] .. "(\"LOL" .. generateEncodedString(originalCode) .. "\")")
    add("local " .. vars[64] .. "=load or loadstring")
    add(vars[64] .. "(" .. vars[63] .. ")()")
    add("end")
    add(vars[62] .. "()")
    
    return table.concat(loader, "\n")
end

while true do
    g.info = gg.prompt({
        '📂 Select file :',
        '📂 Select folder :'
    }, g.info, {'file', 'path'})

    if not g.info then return end

    gg.saveVariable(g.info, g.config)
    g.last = g.info[1]

    if loadfile(g.last) == nil then
        gg.alert("⚠️ Script not Found! ⚠️")
        return
    end

    local nomeArquivo = g.last:match("[^/]+$")
    local saida = nomeArquivo:gsub("%.lua$", "") .. "_obfuscated.lua"
    g.out = g.info[2] .. "/" .. saida

    local file = io.open(g.last, "r")
    local DATA = file:read("*a")
    file:close()

    math.randomseed(os.time())
    local finalCode = generateLoader(DATA)
    local outFile = io.open(g.out, "w")
    outFile:write(finalCode)
    outFile:close()
    gg.alert("📂 Obfuscated File Saved To:\n" .. g.out)
    print("📂 Obfuscated File Saved To: " .. g.out)
   return
end