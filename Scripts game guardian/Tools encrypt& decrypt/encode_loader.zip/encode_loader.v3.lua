g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)

if g.data ~= nil then
    g.info = g.data()
    g.data = nil
end

if g.info == nil then
    g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end

local function randomVarName()
    local letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    local length = math.random(3, 6)  
    local name = "v"
    for i = 1, length do
        local idx = math.random(1, #letters)  
        name = name .. letters:sub(idx, idx)
    end
    return name .. math.random(10, 99) 
end

local function safeRandomNumber()
    return math.random(1000, 9999)
end

local function randomSmallNumber()
    return math.random(0, 255)
end

local function randomExpression()
    local operators = {"+", "-", "*"}
    local a = safeRandomNumber()
    local b = safeRandomNumber()
    local op = operators[math.random(1, #operators)]
    return "(" .. a .. op .. b .. ")"
end

function splitCodeIntoParts(code, numParts)
    local parts = {}
    local partSize = math.ceil(#code / numParts)
    for i = 1, numParts do
        local start = (i - 1) * partSize + 1
        local finish = math.min(i * partSize, #code)
        if start <= #code then
            parts[i] = code:sub(start, finish)
        else
            parts[i] = ""
        end
    end
    return parts
end

function generateRandomOrder(numParts)
    local order = {}
    local available = {}
    for i = 1, numParts do
        available[i] = i
    end
    
    for i = 1, numParts do
        local randomIndex = math.random(1, #available)
        order[i] = available[randomIndex]
        table.remove(available, randomIndex)
    end
    return order
end

function generateEncodedString(code)
    local encoded = {}
    for i = 1, #code do
        local byte = string.byte(code, i)
        byte = (byte + 50) % 256
        encoded[i] = string.format("%02x", byte)
    end
    return table.concat(encoded)
end

function generateLoader(originalCode)
    local vars = setmetatable({}, {
        __index = function(t, k)
            local v = randomVarName()
            rawset(t, k, v)
            return v
        end
    })
    
    local codeParts = splitCodeIntoParts(originalCode, 4)
    local encodedParts = {}
    for i = 1, 4 do
        encodedParts[i] = generateEncodedString(codeParts[i])
    end
    
    local randomOrder = generateRandomOrder(4)
    
    local loader = {}
    local function add(line)
        table.insert(loader, line)
    end
    
    add("local " .. vars[0] .. "=tonumber;    ")
    add("local " .. vars[1] .. "=string.byte;local " .. vars[2] .. "=string.char;local ")
    add(vars[3] .. "=string.sub;local " .. vars[4] .. "=string.gsub;local " .. vars[5] .. "=string.rep;local ")
    add(vars[6] .. "=table.concat;local " .. vars[7] .. "=table.insert;local " .. vars[8] .. "=math.ldexp;local " .. vars[9] .. "=    ")
    add("getfenv or function() return _ENV;end ;local " .. vars[10] .. "=setmetatable;local " .. vars[11] .. "=pcall ")
    add(";local " .. vars[12] .. "=select;local " .. vars[13] .. "=unpack or table.unpack ;local " .. vars[14] .. "=tonumber;local      ")
    
   add("function " .. vars[15] .. "(" .. vars[16] .. ")")
    add("local " .. vars[17] .. "=" .. vars[3] .. "(" .. vars[16] .. ",4)")
    add("local " .. vars[18] .. "=" .. vars[4] .. "(" .. vars[17] .. ", \"%x%x\", function(" .. vars[19] .. ")")
    add("local " .. vars[20] .. "=" .. vars[0] .. "(" .. vars[19] .. ",16)")
    add("local " .. vars[21] .. "= (" .. vars[20] .. " - 50) % 256")
    add("return " .. vars[2] .. "(" .. vars[21] .. ")")
    add("end)")
    add("return " .. vars[18])
    add("end")
    
    add("local function " .. vars[22] .. "(" .. vars[23] .. "," .. vars[24] .. "," .. vars[25] .. ") if " .. vars[25] .. " then local " .. vars[26] .. "=" .. randomExpression() .. ";local " .. vars[27] .. ";while true   ")
    add("do if (" .. vars[26] .. "==" .. randomExpression() .. ") then local " .. vars[28] .. "=0;while true do if (" .. vars[28] .. "==" .. randomExpression() .. ") then " .. vars[27] .. "=(" .. vars[23] .. "/((" .. randomSmallNumber() .. ")^ ")
    add("(" .. vars[24] .. "-" .. randomSmallNumber() .. ")))%(2^(((" .. vars[25] .. "-" .. randomSmallNumber() .. ") -(" .. vars[24] .. "-(" .. randomSmallNumber() .. "))) + " .. randomSmallNumber() .. ")) ;return " .. vars[27] .. "-(" .. vars[27] .. "%1) ;end end end end   ")
    add("else local " .. vars[29] .. "=" .. randomExpression() .. ";local " .. vars[30] .. ";while true do if (" .. vars[29] .. "==" .. randomExpression() .. ") then " .. vars[30] .. "=" .. randomSmallNumber() .. "^(" .. vars[24] .. "-" .. randomSmallNumber() .. ") ;return (((" .. vars[23] .. "%(" .. vars[30] .. "+" .. vars[30] .. "))>=" .. vars[30] .. ") and (" .. randomSmallNumber() .. ")) or (" .. randomSmallNumber() .. ") ;end end end end ")
    
  for i = 1, 4 do
        local partIndex = randomOrder[i]
        add("local function " .. vars[30 + i] .. "()")
        add("local " .. vars[34 + i] .. "=\"LOL" .. encodedParts[partIndex] .. "\"")
        add("local " .. vars[38 + i] .. "=" .. vars[15] .. "(" .. vars[34 + i] .. ")")
        add("return {pos=" .. partIndex .. ", val=" .. vars[38 + i] .. "}")
        add("end")
    end
    
    add("local function " .. vars[43] .. "() local " .. vars[44] .. "=0;local " .. vars[45] .. ";while true do local " .. vars[46] .. "=" .. randomExpression() .. ";while true do if (0==" .. vars[46] .. ") then if (" .. vars[44] .. "==0) then " .. vars[45] .. "=" .. vars[1] .. " ")
    add("(" .. vars[17] .. "," .. vars[47] .. "," .. vars[47] .. ");" .. vars[47] .. "=" .. vars[47] .. " + 1 ;" .. vars[44] .. "=1;end if ((" .. randomSmallNumber() .. ")==" .. vars[44] .. ") then return " .. vars[45] .. ";end break;end end end end ")
    
    add("local function " .. vars[48] .. "() local " .. vars[49] .. "=" .. randomExpression() .. ";local " .. vars[50] .. ";local " .. vars[51] .. ";while true do local " .. vars[52] .. "=0;while true do if (" .. vars[52] .. "==0) then if (" .. vars[49] .. "==" .. randomSmallNumber() .. ") then return (" .. vars[51] .. " * " .. randomSmallNumber() .. ") + " .. vars[50] .. " ;end if (" .. vars[49] .. "==" .. randomExpression() .. ") then " .. vars[50] .. "," .. vars[51] .. "=" .. vars[1] .. "(" .. vars[17] .. "," .. vars[47] .. "," .. vars[47] .. " + 2 );" .. vars[47] .. "=" .. vars[47] .. " + ")
    add("(" .. randomSmallNumber() .. ") ;" .. vars[49] .. "=1;end break;end end end end ")
    
    add("local function " .. vars[53] .. "() local " .. vars[54] .. "," .. vars[55] .. "," .. vars[56] .. "," .. vars[57] .. "=" .. vars[1] .. "(" .. vars[17] .. "," .. vars[47] .. "," .. vars[47] .. " + 3 + 0 );" .. vars[47] .. "=  ")
    add(vars[47] .. " + 4 + 0 ;return (" .. vars[57] .. " * 16777216) + (" .. vars[56] .. " * " .. randomSmallNumber() .. ") + (" .. vars[55] .. " * 256) + " .. vars[54] .. " ;end ")
    
    add("local function " .. vars[58] .. "()")
    add("local " .. vars[59] .. "={}")
    
    for i = 1, 4 do
        add(vars[59] .. "[" .. i .. "]=" .. vars[30 + i] .. "()")
    end
    
    add("local " .. vars[60] .. "={}")
    
    for i = 1, 4 do
        add(vars[60] .. "[" .. vars[59] .. "[" .. i .. "].pos]=" .. vars[59] .. "[" .. i .. "].val")
    end
    
    add("local " .. vars[61] .. "=" .. vars[60] .. "[1]")
    add(vars[61] .. "=" .. vars[61] .. " .. " .. vars[60] .. "[2]")
    add(vars[61] .. "=" .. vars[61] .. " .. " .. vars[60] .. "[3]")
    add(vars[61] .. "=" .. vars[61] .. " .. " .. vars[60] .. "[4]")
    
    add("local " .. vars[62] .. "=load or loadstring")
    add(vars[62] .. "(" .. vars[61] .. ")()")
    add("end")
    
    add(vars[58] .. "()")
    
    return table.concat(loader, "\n")
end

while true do
    g.info = gg.prompt({
        '📂 Select file to encrypt:',
        '📂 select folder:'
    }, g.info, {'file', 'path'})

    if not g.info then return end

    gg.saveVariable(g.info, g.config)
    g.last = g.info[1]

    local nomeArquivo = "script_enc.lua"
    local saida = nomeArquivo
    g.out = g.info[2] .. "/" .. saida

    local file = io.open(g.last, "r")
    local DATA = file:read("*a")
    file:close()
    
    math.randomseed(os.time())
   local finalCode = generateLoader(DATA)

      local outFile = io.open(g.out, "w")
    outFile:write(finalCode)
   outFile:close()
    gg.alert("📂 file saved in:\n" .. g.out)
    return
end