g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)

if g.data ~= nil then
    g.info = g.data()
    g.data = nil
end

if g.info == nil then
    g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end

local function randomVarName()
    local letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    local length = math.random(3, 6)  
    local name = "v"
    for i = 1, length do
        local idx = math.random(1, #letters)  
        name = name .. letters:sub(idx, idx)
    end
    return name .. math.random(10, 99) 
end

local function safeRandomNumber()
    return math.random(1000, 9999)
end

local function randomSmallNumber()
    return math.random(0, 255)
end

local function randomExpression()
    local operators = {"+", "-", "*"}
    local a = safeRandomNumber()
    local b = safeRandomNumber()
    local op = operators[math.random(1, #operators)]
    return "(" .. a .. op .. b .. ")"
end

function splitCodeIntoParts(code, numParts)
    local parts = {}
    local partSize = math.ceil(#code / numParts)
    for i = 1, numParts do
        local start = (i - 1) * partSize + 1
        local finish = math.min(i * partSize, #code)
        if start <= #code then
            parts[i] = code:sub(start, finish)
        else
            parts[i] = ""
        end
    end
    return parts
end

function generateEncodedString(code)
    local encoded = {}
    for i = 1, #code do
        local byte = string.byte(code, i)
        byte = (byte + 50) % 256
        encoded[i] = string.format("%02x", byte)
    end
    return table.concat(encoded)
end

function generateLoader(originalCode)
    local vars = setmetatable({}, {
        __index = function(t, k)
            local v = randomVarName()
            rawset(t, k, v)
            return v
        end
    })
    
   local codeParts = splitCodeIntoParts(originalCode, 4)
    local encodedParts = {}
    for i = 1, 4 do
        encodedParts[i] = generateEncodedString(codeParts[i])
    end
    
    local loader = {}
    local function add(line)
        table.insert(loader, line)
    end
    
   
    add("local " .. vars[0] .. "=tonumber;    ")
    add("local " .. vars[1] .. "=string.byte;local " .. vars[2] .. "=string.char;local ")
    add(vars[3] .. "=string.sub;local " .. vars[4] .. "=string.gsub;local " .. vars[5] .. "=string.rep;local ")
    add(vars[6] .. "=table.concat;local " .. vars[7] .. "=table.insert;local " .. vars[8] .. "=math.ldexp;local " .. vars[9] .. "=    ")
    add("getfenv or function() return _ENV;end ;local " .. vars[10] .. "=setmetatable;local " .. vars[11] .. "=pcall ")
    add(";local " .. vars[12] .. "=select;local " .. vars[13] .. "=unpack or table.unpack ;local " .. vars[14] .. "=tonumber;local      ")
    add("function " .. vars[15] .. "(" .. vars[16] .. "," .. vars[17] .. ")")
    add("local " .. vars[18] .. "=" .. vars[3] .. "(" .. vars[16] .. ",4)")
    add("local " .. vars[19] .. "=" .. vars[4] .. "(" .. vars[18] .. ", \"%x%x\", function(" .. vars[20] .. ")")
    add("local " .. vars[21] .. "=" .. vars[0] .. "(" .. vars[20] .. ",16)")
    add("local " .. vars[22] .. "= (" .. vars[21] .. " - 50) % 256")
    add("return " .. vars[2] .. "(" .. vars[22] .. ")")
    add("end)")
    add("return " .. vars[19])
    add("end")
    add("local function " .. vars[23] .. "(" .. vars[24] .. "," .. vars[25] .. "," .. vars[26] .. ") if " .. vars[26] .. " then local " .. vars[27] .. "=" .. randomExpression() .. ";local " .. vars[28] .. ";while true   ")
    add("do if (" .. vars[27] .. "==" .. randomExpression() .. ") then local " .. vars[29] .. "=0;while true do if (" .. vars[29] .. "==" .. randomExpression() .. ") then " .. vars[28] .. "=(" .. vars[24] .. "/((" .. randomSmallNumber() .. ")^ ")
    add("(" .. vars[25] .. "-" .. randomSmallNumber() .. ")))%(2^(((" .. vars[26] .. "-" .. randomSmallNumber() .. ") -(" .. vars[25] .. "-(" .. randomSmallNumber() .. "))) + " .. randomSmallNumber() .. ")) ;return " .. vars[28] .. "-(" .. vars[28] .. "%1) ;end end end end   ")
    add("else local " .. vars[30] .. "=" .. randomExpression() .. ";local " .. vars[31] .. ";while true do if (" .. vars[30] .. "==" .. randomExpression() .. ") then " .. vars[31] .. "=" .. randomSmallNumber() .. "^(" .. vars[25] .. "-" .. randomSmallNumber() .. ") ;return (((" .. vars[24] .. "%(" .. vars[31] .. "+" .. vars[31] .. "))>=" .. vars[31] .. ") and (" .. randomSmallNumber() .. ")) or (" .. randomSmallNumber() .. ") ;end end end end ")
    add("local function " .. vars[32] .. "()")
    add("local " .. vars[33] .. "=\"" .. encodedParts[1] .. "\"")
    add("local " .. vars[34] .. "=" .. vars[15] .. "(\"LOL\" .. " .. vars[33] .. ")")
    add("return " .. vars[34])
    add("end")
    add("local function " .. vars[35] .. "() local " .. vars[36] .. "=0;local " .. vars[37] .. ";while true do local " .. vars[38] .. "=" .. randomExpression() .. ";while true do if (0==" .. vars[38] .. ") then if (" .. vars[36] .. "==0) then " .. vars[37] .. "=" .. vars[1] .. " ")
    add("(" .. vars[18] .. "," .. vars[39] .. "," .. vars[39] .. ");" .. vars[39] .. "=" .. vars[39] .. " + 1 ;" .. vars[36] .. "=1;end if ((" .. randomSmallNumber() .. ")==" .. vars[36] .. ") then return " .. vars[37] .. ";end break;end end end end ")
    add("local function " .. vars[40] .. "()")
    add("local " .. vars[41] .. "=\"" .. encodedParts[2] .. "\"")
    add("local " .. vars[42] .. "=" .. vars[15] .. "(\"LOL\" .. " .. vars[41] .. ")")
    add("return " .. vars[42])
    add("end")
    add("local function " .. vars[43] .. "() local " .. vars[44] .. "=" .. randomExpression() .. ";local " .. vars[45] .. ";local " .. vars[46] .. ";while true do local " .. vars[47] .. "=0;while true do if (" .. vars[47] .. "==0) then if (" .. vars[44] .. "==" .. randomSmallNumber() .. ") then return (" .. vars[46] .. " * " .. randomSmallNumber() .. ") + " .. vars[45] .. " ;end if (" .. vars[44] .. "==" .. randomExpression() .. ") then " .. vars[45] .. "," .. vars[46] .. "=" .. vars[1] .. "(" .. vars[18] .. "," .. vars[39] .. "," .. vars[39] .. " + 2 );" .. vars[39] .. "=" .. vars[39] .. " + ")
    add("(" .. randomSmallNumber() .. ") ;" .. vars[44] .. "=1;end break;end end end end ")
    add("local function " .. vars[48] .. "()")
    add("local " .. vars[49] .. "=\"" .. encodedParts[3] .. "\"")
    add("local " .. vars[50] .. "=" .. vars[15] .. "(\"LOL\" .. " .. vars[49] .. ")")
    add("return " .. vars[50])
    add("end")
    add("local function " .. vars[51] .. "() local " .. vars[52] .. "," .. vars[53] .. "," .. vars[54] .. "," .. vars[55] .. "=" .. vars[1] .. "(" .. vars[18] .. "," .. vars[39] .. "," .. vars[39] .. " + 3 + 0 );" .. vars[39] .. "=  ")
    add(vars[39] .. " + 4 + 0 ;return (" .. vars[55] .. " * 16777216) + (" .. vars[54] .. " * " .. randomSmallNumber() .. ") + (" .. vars[53] .. " * 256) + " .. vars[52] .. " ;end ")
    add("local function " .. vars[56] .. "()")
    add("local " .. vars[57] .. "=\"" .. encodedParts[4] .. "\"")
    add("local " .. vars[58] .. "=" .. vars[15] .. "(\"LOL\" .. " .. vars[57] .. ")")
    add("return " .. vars[58])
    add("end")
    add("local function " .. vars[59] .. "()")
    add("local " .. vars[60] .. "=" .. vars[32] .. "()")
    add("local " .. vars[61] .. "=" .. vars[40] .. "()")
    add("local " .. vars[62] .. "=" .. vars[48] .. "()")
    add("local " .. vars[63] .. "=" .. vars[56] .. "()")
    add("local " .. vars[64] .. "=" .. vars[60] .. " .. " .. vars[61] .. " .. " .. vars[62] .. " .. " .. vars[63])
    add("local " .. vars[65] .. "=load or loadstring")
    add(vars[65] .. "(" .. vars[64] .. ")()")
    add("end")
    add(vars[59] .. "()")
    
    return table.concat(loader, "\n")
end
while true do
    g.info = gg.prompt({
        '📂 Select file to encrypt:',
        '📂 select folder:'
    }, g.info, {'file', 'path'})

    if not g.info then return end

    gg.saveVariable(g.info, g.config)
    g.last = g.info[1]

   local nomeArquivo = "script_enc.lua"
    local saida = nomeArquivo
    g.out = g.info[2] .. "/" .. saida


local file = io.open(g.last, "r")
    local DATA = file:read("*a")
    file:close()
    
    math.randomseed(os.time())
    local finalCode = generateLoader(DATA)
    local outFile = io.open(g.out, "w")
    outFile:write(finalCode)
    outFile:close()
    gg.alert("📂 file saved in:\n" .. g.out)
        return
end