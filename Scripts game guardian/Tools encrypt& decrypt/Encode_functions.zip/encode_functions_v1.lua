g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)
if g.data ~= nil then
  g.info = g.data()
  g.data = nil
end
if g.info == nil then
  g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end

function gerarNomeAleatorio(tamanho)
    local chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    local nome = ""
    for i = 1, tamanho do
        nome = nome .. chars:sub(math.random(1, #chars), math.random(1, #chars))
    end
    return nome
end

function gerarNomesBotoes()
    local botoes = {}
    for i = 1, 20 do
        botoes[i] = "F" .. gerarNomeAleatorio(10)
    end
    return botoes
end

function codificarString(str)
    local resultado = {}
    for i = 1, #str do
        resultado[i] = string.byte(str, i) + 10
    end
    return table.concat(resultado, ",")
end

function processarCodigo(codigo, botoes)
 for i = 1, 10 do
 local padrao_declaracao = "function ch" .. i .. "%(%)"
        codigo = codigo:gsub(padrao_declaracao, "function " .. botoes[i] .. "()")
        
    local padrao_chamada = "ch" .. i .. "%(%)"
        codigo = codigo:gsub(padrao_chamada, botoes[i] .. "()")
    end
    
   codigo = codigo:gsub('"([^"]*)"', function(str)
        return "d(" .. codificarString(str) .. ")"
    end)
    
    codigo = codigo:gsub("'([^']*)'", function(str)
        return "d(" .. codificarString(str) .. ")"
    end)
    
    return codigo
end

while true do
  g.info = gg.prompt({
    '📂 Select file :',
    '📂 Select folder :'
  }, g.info, {
    'file',
    'path'
  })

  gg.saveVariable(g.info, g.config)
  g.last = g.info[1]
  if loadfile(g.last) == nil then
    gg.alert("⚠️ Script not Found! ⚠️")
    return
  else
    g.out = g.last:match("[^/]+$")
    g.out = g.out:gsub(".lua", ".Batman")
    g.out = g.info[2] .. "/" .. g.out .. ".lua"
  end

  local file = io.open(g.last, "r")
  local DATA = file:read('*a')
  file:close()
  
 math.randomseed(os.time())
  local botoes = gerarNomesBotoes()
  
 local funcaoDecodificar = [[

local function d(...)
    local args = {...}
    local result = {}
    for i = 1, #args do
        result[i] = string.char(args[i] - 10)
    end
    return table.concat(result)
end

]]
  
  local codigoProcessado = processarCodigo(DATA, botoes) 
 local declaracoesBotoes = ""
  for i = 1, 10 do
      declaracoesBotoes = declaracoesBotoes .. botoes[i] .. " = nil\n"
  end
  local codigoFinal = funcaoDecodificar .. declaracoesBotoes .. "\n" .. codigoProcessado
  io.open(g.out, "w"):write(codigoFinal):close()

  ClU = '📂 File Saved To: '..g.out..'\n'
  gg.alert(ClU, '')
  print("\n▬▬▬▬▬▬▬▬▬▬▬▬▬\n📂 File Saved To :" .. g.out .. "\n▬▬▬▬▬▬▬▬▬▬▬▬▬")
  return 
end