function tohex(num)
 local charset = {"0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"} 
local tmp = {}
 repeat 
table.insert(tmp,1,charset[num%16+1]) 
num = math.floor(num/16) 
until num==0 
return table.concat(tmp) 
end
Info  = gg.getTargetInfo()
function split(s, delimiter) 
result = {}; for match in (s..delimiter):gmatch("(.-)"..delimiter) do table.insert(result, match); end return result; end
local open = io.open 
local function read_file(path) 
local file = open(path, "rb")
 if not file then return nil end 
local content = file:read 
"*a"
file:close()
return content
 end 
 
Ck = gg.prompt({'String'}, nil, {'text'})

if Ck == nil or Ck[1] == nil or Ck[1] == "" then
    gg.toast("null")
    return
else 
    local str = "string.char("
    local strs = ""
    local Link = Ck[1]
    
    for i = 1, string.len(Link), 1 do
        if i == string.len(Link) then
            strs = strs .. str .. 'tonumber("' .. tohex(string.byte(Link, i)) .. '",16))'
        else
            strs = strs .. str .. 'tonumber("' .. tohex(string.byte(Link, i)) .. '",16))' .. ".."
        end
    end
    
   local A = [[
   
local code = ']] .. strs .. [['
local func = load("return " .. code)
if func then
    local result = func()
  --  print("Result: " .. result)
     local result_func = load(result)
    if result_func then
        result_func()
    end
else
    print("error")
end

]]
    print(A)
    gg.copyText(A) 
end