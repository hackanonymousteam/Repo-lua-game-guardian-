g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)

if g.data ~= nil then
    g.info = g.data()
    g.data = nil
end

if g.info == nil then
    g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end

function gerarNomeAleatorio(tamanho)
    local chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    local nome = ""
    for i = 1, tamanho do
        local r = math.random(1, #chars)
        nome = nome .. chars:sub(r, r)
    end
    return nome
end

function gerarEstrutura()
    return {
        decode = gerarNomeAleatorio(30),
        seed = gerarNomeAleatorio(15),
        offset = math.random(5, 25)
    }
end

function tokenizarCodigo(codigo)
    local tokens = {}
    local pos = 1
    local len = #codigo
    local linha = 1
    local coluna = 1
    
    while pos <= len do
        local char = codigo:sub(pos, pos)
        
   
        if char == '\n' then
            linha = linha + 1
            coluna = 1
            pos = pos + 1
       
        elseif char:match("%s") then
            coluna = coluna + 1
            pos = pos + 1
        
        elseif char == '"' then
            local inicio = pos
            pos = pos + 1
            while pos <= len do
                if codigo:sub(pos, pos) == '"' and codigo:sub(pos-1, pos-1) ~= '\\' then
                    break
                end
                pos = pos + 1
            end
            pos = pos + 1
            table.insert(tokens, {
                tipo = "string",
                valor = codigo:sub(inicio, pos-1),
                inicio = inicio,
                fim = pos-1,
                linha = linha,
                coluna = coluna
            })
            coluna = coluna + (pos - inicio)
        
        elseif char == "'" then
            local inicio = pos
            pos = pos + 1
            while pos <= len do
                if codigo:sub(pos, pos) == "'" and codigo:sub(pos-1, pos-1) ~= '\\' then
                    break
                end
                pos = pos + 1
            end
            pos = pos + 1
            table.insert(tokens, {
                tipo = "string",
                valor = codigo:sub(inicio, pos-1),
                inicio = inicio,
                fim = pos-1,
                linha = linha,
                coluna = coluna
            })
            coluna = coluna + (pos - inicio)
        
        elseif char == '-' and codigo:sub(pos+1, pos+1) == '-' then
            local inicio = pos
            pos = pos + 2
            while pos <= len and codigo:sub(pos, pos) ~= '\n' do
                pos = pos + 1
            end
            table.insert(tokens, {
                tipo = "comentario",
                valor = codigo:sub(inicio, pos-1),
                inicio = inicio,
                fim = pos-1,
                linha = linha,
                coluna = coluna
            })
            if pos <= len and codigo:sub(pos, pos) == '\n' then
                pos = pos + 1
                linha = linha + 1
                coluna = 1
            end
        
        elseif char == '-' and codigo:sub(pos+1, pos+2) == ']-' then
            local inicio = pos
            pos = pos + 3
            local nivel = 1
            while pos <= len and nivel > 0 do
                if codigo:sub(pos, pos+1) == '[[' then
                    nivel = nivel + 1
                    pos = pos + 2
                elseif codigo:sub(pos, pos+1) == ']]' then
                    nivel = nivel - 1
                    pos = pos + 2
                else
                    if codigo:sub(pos, pos) == '\n' then
                        linha = linha + 1
                        coluna = 1
                    end
                    pos = pos + 1
                end
            end
            table.insert(tokens, {
                tipo = "comentario",
                valor = codigo:sub(inicio, pos-1),
                inicio = inicio,
                fim = pos-1,
                linha = linha,
                coluna = coluna
            })
        
        elseif char:match("[%a_]") then
            local inicio = pos
            while pos <= len and codigo:sub(pos, pos):match("[%w_]") do
                pos = pos + 1
            end
            local palavra = codigo:sub(inicio, pos-1)
            table.insert(tokens, {
                tipo = "palavra",
                valor = palavra,
                inicio = inicio,
                fim = pos-1,
                linha = linha,
                coluna = coluna
            })
            coluna = coluna + (pos - inicio)
     
        elseif char:match("%d") then
            local inicio = pos
            while pos <= len and codigo:sub(pos, pos):match("[%d%.]") do
                pos = pos + 1
            end
            table.insert(tokens, {
                tipo = "numero",
                valor = codigo:sub(inicio, pos-1),
                inicio = inicio,
                fim = pos-1,
                linha = linha,
                coluna = coluna
            })
            coluna = coluna + (pos - inicio)
   elseif char == '=' and codigo:sub(pos+1, pos+1) == '=' then
            table.insert(tokens, {
                tipo = "operador",
                valor = '==',
                inicio = pos,
                fim = pos+1,
                linha = linha,
                coluna = coluna
            })
            pos = pos + 2
            coluna = coluna + 2
        elseif char == '>' and codigo:sub(pos+1, pos+1) == '=' then
            table.insert(tokens, {
                tipo = "operador",
                valor = '>=',
                inicio = pos,
                fim = pos+1,
                linha = linha,
                coluna = coluna
            })
            pos = pos + 2
            coluna = coluna + 2
        elseif char == '<' and codigo:sub(pos+1, pos+1) == '=' then
            table.insert(tokens, {
                tipo = "operador",
                valor = '<=',
                inicio = pos,
                fim = pos+1,
                linha = linha,
                coluna = coluna
            })
            pos = pos + 2
            coluna = coluna + 2
        elseif char == '~' and codigo:sub(pos+1, pos+1) == '=' then
            table.insert(tokens, {
                tipo = "operador",
                valor = '~=',
                inicio = pos,
                fim = pos+1,
                linha = linha,
                coluna = coluna
            })
            pos = pos + 2
            coluna = coluna + 2
        elseif char == ':' and codigo:sub(pos+1, pos+1) == ':' then
            table.insert(tokens, {
                tipo = "operador",
                valor = '::',
                inicio = pos,
                fim = pos+1,
                linha = linha,
                coluna = coluna
            })
            pos = pos + 2
            coluna = coluna + 2
        elseif char == '.' and codigo:sub(pos+1, pos+1) == '.' then
            if codigo:sub(pos+2, pos+2) == '.' then
                table.insert(tokens, {
                    tipo = "operador",
                    valor = '...',
                    inicio = pos,
                    fim = pos+2,
                    linha = linha,
                    coluna = coluna
                })
                pos = pos + 3
                coluna = coluna + 3
            else
                table.insert(tokens, {
                    tipo = "operador",
                    valor = '..',
                    inicio = pos,
                    fim = pos+1,
                    linha = linha,
                    coluna = coluna
                })
                pos = pos + 2
                coluna = coluna + 2
            end
        
        else
            table.insert(tokens, {
                tipo = "simbolo",
                valor = char,
                inicio = pos,
                fim = pos,
                linha = linha,
                coluna = coluna
            })
            pos = pos + 1
            coluna = coluna + 1
        end
    end
    
    return tokens
end


function analisarEscopo(tokens)
    local escopos = {}
    local pilha = {}
    local i = 1
    
    while i <= #tokens do
        local token = tokens[i]
           
        if token.tipo == "palavra" and token.valor == "then" then
            table.insert(pilha, {tipo = "bloco", inicio = i})
        elseif token.tipo == "palavra" and token.valor == "do" then
            table.insert(pilha, {tipo = "bloco", inicio = i})
        elseif token.tipo == "palavra" and token.valor == "function" then
            table.insert(pilha, {tipo = "funcao", inicio = i})
        elseif token.tipo == "simbolo" and token.valor == "{" then
            table.insert(pilha, {tipo = "tabela", inicio = i})
            
  elseif token.tipo == "palavra" and token.valor == "end" then
            if #pilha > 0 then
                local bloco = table.remove(pilha)
                bloco.fim = i
                table.insert(escopos, bloco)
            end
        elseif token.tipo == "simbolo" and token.valor == "}" then
            if #pilha > 0 then
                local bloco = table.remove(pilha)
                bloco.fim = i
                table.insert(escopos, bloco)
            end
        end
        i = i + 1
    end
    
    return escopos
end


function encontrarFuncoes(tokens)
    local funcoes = {}
    local i = 1
    
    while i <= #tokens do
        local token = tokens[i]
        
  if token.tipo == "palavra" and token.valor == "function" then
            local nomeIndex = i + 1
            if nomeIndex <= #tokens and tokens[nomeIndex].tipo == "palavra" then
                local parenIndex = i + 2
                if parenIndex <= #tokens and tokens[parenIndex].tipo == "simbolo" and tokens[parenIndex].valor == "(" then
                    table.insert(funcoes, {
                        tipo = "global",
                        nome = tokens[nomeIndex].valor,
                        nomeIndex = nomeIndex,
                        inicio = i
                    })
                end
            end
        end
        
  if token.tipo == "palavra" and token.valor == "local" then
            local nextIndex = i + 1
            if nextIndex <= #tokens and tokens[nextIndex].tipo == "palavra" and tokens[nextIndex].valor == "function" then
                local nomeIndex = i + 2
                if nomeIndex <= #tokens and tokens[nomeIndex].tipo == "palavra" then
                    local parenIndex = i + 3
                    if parenIndex <= #tokens and tokens[parenIndex].tipo == "simbolo" and tokens[parenIndex].valor == "(" then
                        table.insert(funcoes, {
                            tipo = "local",
                            nome = tokens[nomeIndex].valor,
                            nomeIndex = nomeIndex,
                            inicio = i
                        })
                    end
                end
            end
        end
      if token.tipo == "palavra" and token.valor == "function" then
            local objIndex = i + 1
            if objIndex <= #tokens and tokens[objIndex].tipo == "palavra" then
                local colonIndex = i + 2
                if colonIndex <= #tokens and tokens[colonIndex].tipo == "simbolo" and tokens[colonIndex].valor == ":" then
                    local nomeIndex = i + 3
                    if nomeIndex <= #tokens and tokens[nomeIndex].tipo == "palavra" then
                        local parenIndex = i + 4
                        if parenIndex <= #tokens and tokens[parenIndex].tipo == "simbolo" and tokens[parenIndex].valor == "(" then
                            table.insert(funcoes, {
                                tipo = "metodo",
                                nome = tokens[nomeIndex].valor,
                                nomeIndex = nomeIndex,
                                inicio = i,
                                objeto = tokens[objIndex].valor
                            })
                        end
                    end
                end
            end
        end
        
           if token.tipo == "palavra" or token.tipo == "simbolo" and token.valor == "]" then
            local igualIndex = i + 1
            if igualIndex <= #tokens and tokens[igualIndex].tipo == "simbolo" and tokens[igualIndex].valor == "=" then
                local funcIndex = i + 2
                if funcIndex <= #tokens and tokens[funcIndex].tipo == "palavra" and tokens[funcIndex].valor == "function" then
                    local parenIndex = i + 3
                    if parenIndex <= #tokens and tokens[parenIndex].tipo == "simbolo" and tokens[parenIndex].valor == "(" then
                        table.insert(funcoes, {
                            tipo = "tabela",
                            nome = token.valor,
                            nomeIndex = i,
                            inicio = i
                        })
                    end
                end
            end
        end
        
   if token.tipo == "palavra" and token.valor == "function" then
            local parenIndex = i + 1
            if parenIndex <= #tokens and tokens[parenIndex].tipo == "simbolo" and tokens[parenIndex].valor == "(" then
    local anterior = i - 1
                local ehNomeada = false
                if anterior >= 1 then
                    if tokens[anterior].tipo == "palavra" or 
                       (tokens[anterior].tipo == "simbolo" and tokens[anterior].valor == "=") then
                        ehNomeada = true
                    end
                end
                if not ehNomeada then
                    table.insert(funcoes, {
                        tipo = "anonima",
                        nome = nil,
                        nomeIndex = nil,
                        inicio = i
                    })
                end
            end
        end
        
        i = i + 1
    end
    
    return funcoes
end


function encontrarChamadas(tokens, funcoes)
    local chamadas = {}
    local i = 1
    
    while i <= #tokens do
        if tokens[i].tipo == "palavra" then
            for _, func in ipairs(funcoes) do
                if func.nome and tokens[i].valor == func.nome then
   local proximo = i + 1
                    if proximo <= #tokens and tokens[proximo].tipo == "simbolo" and tokens[proximo].valor == "(" then
                        table.insert(chamadas, {
                            nome = func.nome,
                            index = i,
                            tipo = "normal"
                        })
                        break
                    end
                    
                           local anterior = i - 1
                    if anterior >= 1 and tokens[anterior].tipo == "simbolo" and tokens[anterior].valor == ":" then
                        table.insert(chamadas, {
                            nome = func.nome,
                            index = i,
                            tipo = "metodo"
                        })
                        break
                    end
                end
            end
        end
        i = i + 1
    end
    
    return chamadas
end


function isGGFunction(nome)
    local gg_functions = {
        "alert", "toast", "multiChoice", "choice", "prompt", "searchNumber",
        "refineNumber", "getResults", "editAll", "clearResults", "setRanges",
        "getRanges", "setVisible", "isVisible", "sleep", "processResume",
        "processPause", "getTargetInfo", "getTargetPackage", "getFile",
        "saveVariable", "loadList", "saveList", "addListItems", "removeListItems",
        "getListItems", "getSelectedListItems", "getResultsCount", "getValues",
        "setValues", "getValuesRange", "copyMemory", "dumpMemory", "allocatePage",
        "PROT_READ", "PROT_WRITE", "PROT_EXEC", "REGION_CODE_APP", "REGION_C_ALLOC",
        "REGION_C_HEAP", "REGION_C_DATA", "REGION_C_BSS", "REGION_ANONYMOUS",
        "REGION_STACK", "REGION_JAVA_HEAP", "REGION_JAVA", "REGION_ASHMEM",
        "REGION_VIDEO", "REGION_PPSSPP", "TYPE_BYTE", "TYPE_WORD", "TYPE_DWORD",
        "TYPE_QWORD", "TYPE_FLOAT", "TYPE_DOUBLE", "TYPE_XOR", "SIGN_EQUAL",
        "SIGN_NOT_EQUAL", "SIGN_GREATER_OR_EQUAL", "SIGN_LESS_OR_EQUAL"
    }
    for _, v in ipairs(gg_functions) do
        if v == nome then return true end
    end
    return false
end

function codificarString(str, offset)
    if not str or str == "" then return "" end
    local resultado = {}
    local conteudo = str:sub(2, -2)
    for i = 1, #conteudo do
        local byte = string.byte(conteudo, i)
        resultado[#resultado + 1] = tostring(byte + offset)
    end
    return table.concat(resultado, ",")
end


function reconstruirCodigo(tokens, estrutura, mapaFuncoes)
    local partes = {}
    local ultimoTipo = ""
    
    for i, token in ipairs(tokens) do
    if #partes > 0 then
            local ultimo = partes[#partes]
            if token.tipo == "palavra" and ultimo ~= "" and not ultimo:match("%s$") then
                if ultimoTipo == "numero" or ultimoTipo == "palavra" or 
                   (ultimoTipo == "simbolo" and token.valor ~= ")" and token.valor ~= "(" and token.valor ~= ",") then
                    partes[#partes] = ultimo .. " "
                end
            end
        end
        
        if token.tipo == "string" then
     local codificado = codificarString(token.valor, estrutura.offset)
            if codificado ~= "" and not isGGFunction(token.valor:gsub('["\']', '')) then
                partes[#partes+1] = estrutura.decode .. "(" .. codificado .. ")"
            else
                partes[#partes+1] = token.valor
            end
            ultimoTipo = "string"
        elseif token.tipo == "palavra" and mapaFuncoes[token.valor] and not isGGFunction(token.valor) then
            partes[#partes+1] = mapaFuncoes[token.valor]
            ultimoTipo = "palavra"
        else
            partes[#partes+1] = token.valor
            ultimoTipo = token.tipo
        end
    end
    
    return table.concat(partes)
end

while true do

    g.info = gg.prompt({
        '📂 Select file :',
        '📂 Select folder :'
    }, g.info, {
        'file',
        'path'
    })

    if not g.info then return end

    gg.saveVariable(g.info, g.config)
    g.last = g.info[1]

    if loadfile(g.last) == nil then
        gg.alert("⚠️ Script not Found! ⚠️")
        return
    end

    local nomeArquivo = g.last:match("[^/]+$")
    local saida = nomeArquivo:gsub("%.lua$", "") .. ".Batman.lua"
    g.out = g.info[2] .. "/" .. saida

    local file = io.open(g.last, "r")
    local DATA = file:read("*a")
    file:close()

    math.randomseed(os.time())

    local estrutura = gerarEstrutura()
    local mapaFuncoes = {}
    
   local tokens = tokenizarCodigo(DATA)
    
  local escopos = analisarEscopo(tokens)
    
  local funcoes = encontrarFuncoes(tokens)
    
   for _, func in ipairs(funcoes) do
        if func.nome and not isGGFunction(func.nome) then
            if not mapaFuncoes[func.nome] then
                mapaFuncoes[func.nome] = gerarNomeAleatorio(20)
            end
        end
    end
    
  local chamadas = encontrarChamadas(tokens, funcoes)
    
   for _, func in ipairs(funcoes) do
        if func.nomeIndex and mapaFuncoes[func.nome] then
            tokens[func.nomeIndex].valor = mapaFuncoes[func.nome]
        end
    end
    
    for _, chamada in ipairs(chamadas) do
        if mapaFuncoes[chamada.nome] then
            tokens[chamada.index].valor = mapaFuncoes[chamada.nome]
        end
    end
    
    local codigoProcessado = reconstruirCodigo(tokens, estrutura, mapaFuncoes)


    local cabecalho = string.format([[
local %s = %d
math.randomseed(os.time() + %s)

local function %s(...)
    local args = {...}
    local r = {}
    for i = 1, #args do
        local n = tonumber(args[i])
        if n then
            r[#r+1] = string.char(n - %d)
        end
    end
    return table.concat(r)
end

]], 
    estrutura.seed,
    estrutura.offset,
    estrutura.seed,
    estrutura.decode,
    estrutura.offset
)

   local declaracoes = ""
    local declaradas = {}
    for nomeOriginal, novoNome in pairs(mapaFuncoes) do
        if not declaradas[novoNome] then
            declaracoes = declaracoes .. "local " .. novoNome .. " = nil\n"
            declaradas[novoNome] = true
        end
    end

    local codigoFinal = cabecalho .. "\n" .. declaracoes .. "\n\n" .. codigoProcessado

    io.open(g.out, "w"):write(codigoFinal):close()

    gg.alert("📂 File Saved To:\n" .. g.out)
    print("📂 File Saved To: " .. g.out)

    return
end