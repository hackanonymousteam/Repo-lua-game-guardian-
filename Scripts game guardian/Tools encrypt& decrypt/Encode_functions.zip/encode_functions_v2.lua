g = {}
g.last = "/sdcard/"
g.info = nil
g.config = gg.EXT_CACHE_DIR .. "/" .. gg.getFile():match("[^/]+$") .. "cfg"
g.data = loadfile(g.config)

if g.data ~= nil then
    g.info = g.data()
    g.data = nil
end

if g.info == nil then
    g.info = { g.last, g.last:gsub("/[^/]+$", "") }
end

function gerarNomeAleatorio(tamanho)
    local chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    local nome = ""
    for i = 1, tamanho do
        local r = math.random(1, #chars)
        nome = nome .. chars:sub(r, r)
    end
    return nome
end

function gerarEstrutura()
    return {
        decode = gerarNomeAleatorio(30),
        seed = gerarNomeAleatorio(15),
        offset = math.random(5, 25)
    }
end

function tokenizarCodigo(codigo)
    local tokens = {}
    local pos = 1
    local len = #codigo
    
    while pos <= len do
        local char = codigo:sub(pos, pos)
        
        if char:match("%s") then
            pos = pos + 1
        elseif char == '"' then
            local inicio = pos
            pos = pos + 1
            while pos <= len do
                if codigo:sub(pos, pos) == '"' and codigo:sub(pos-1, pos-1) ~= '\\' then
                    break
                end
                pos = pos + 1
            end
            pos = pos + 1
            table.insert(tokens, {
                tipo = "string",
                valor = codigo:sub(inicio, pos-1),
                inicio = inicio,
                fim = pos-1
            })
        elseif char == "'" then
            local inicio = pos
            pos = pos + 1
            while pos <= len do
                if codigo:sub(pos, pos) == "'" and codigo:sub(pos-1, pos-1) ~= '\\' then
                    break
                end
                pos = pos + 1
            end
            pos = pos + 1
            table.insert(tokens, {
                tipo = "string",
                valor = codigo:sub(inicio, pos-1),
                inicio = inicio,
                fim = pos-1
            })
        elseif char == '-' and codigo:sub(pos+1, pos+1) == '-' then
            local inicio = pos
            pos = pos + 2
            while pos <= len and codigo:sub(pos, pos) ~= '\n' do
                pos = pos + 1
            end
            table.insert(tokens, {
                tipo = "comentario",
                valor = codigo:sub(inicio, pos-1),
                inicio = inicio,
                fim = pos-1
            })
            if pos <= len and codigo:sub(pos, pos) == '\n' then
                pos = pos + 1
            end
        elseif char:match("[%a_]") then
            local inicio = pos
            while pos <= len and codigo:sub(pos, pos):match("[%w_]") do
                pos = pos + 1
            end
            local palavra = codigo:sub(inicio, pos-1)
            table.insert(tokens, {
                tipo = "palavra",
                valor = palavra,
                inicio = inicio,
                fim = pos-1
            })
        elseif char:match("%d") then
            local inicio = pos
            while pos <= len and codigo:sub(pos, pos):match("[%d%.]") do
                pos = pos + 1
            end
            table.insert(tokens, {
                tipo = "numero",
                valor = codigo:sub(inicio, pos-1),
                inicio = inicio,
                fim = pos-1
            })
        elseif char == '=' and codigo:sub(pos+1, pos+1) == '=' then
            table.insert(tokens, {
                tipo = "operador",
                valor = '==',
                inicio = pos,
                fim = pos+1
            })
            pos = pos + 2
        elseif char == '>' and codigo:sub(pos+1, pos+1) == '=' then
            table.insert(tokens, {
                tipo = "operador",
                valor = '>=',
                inicio = pos,
                fim = pos+1
            })
            pos = pos + 2
        elseif char == '<' and codigo:sub(pos+1, pos+1) == '=' then
            table.insert(tokens, {
                tipo = "operador",
                valor = '<=',
                inicio = pos,
                fim = pos+1
            })
            pos = pos + 2
        elseif char == '.' and codigo:sub(pos+1, pos+1) == '.' then
            if codigo:sub(pos+2, pos+2) == '.' then
                table.insert(tokens, {
                    tipo = "operador",
                    valor = '...',
                    inicio = pos,
                    fim = pos+2
                })
                pos = pos + 3
            else
                table.insert(tokens, {
                    tipo = "operador",
                    valor = '..',
                    inicio = pos,
                    fim = pos+1
                })
                pos = pos + 2
            end
        else
            table.insert(tokens, {
                tipo = "simbolo",
                valor = char,
                inicio = pos,
                fim = pos
            })
            pos = pos + 1
        end
    end
    
    return tokens
end

function encontrarFuncoes(tokens)
    local funcoes = {}
    local i = 1
    
    while i <= #tokens do
        if tokens[i].tipo == "palavra" and tokens[i].valor == "function" then
            local nomeIndex = i + 1
            if nomeIndex <= #tokens and tokens[nomeIndex].tipo == "palavra" then
                local parenIndex = i + 2
                if parenIndex <= #tokens and tokens[parenIndex].tipo == "simbolo" and tokens[parenIndex].valor == "(" then
                    table.insert(funcoes, {
                        nome = tokens[nomeIndex].valor,
                        nomeIndex = nomeIndex,
                        inicio = tokens[i].inicio,
                        fim = nil
                    })
                end
            end
        end
        i = i + 1
    end
    
    return funcoes
end

function encontrarChamadas(tokens, funcoes)
    local chamadas = {}
    local i = 1
    
    while i <= #tokens do
        if tokens[i].tipo == "palavra" then
            for _, func in ipairs(funcoes) do
                if tokens[i].valor == func.nome then
                    local proximo = i + 1
                    if proximo <= #tokens and tokens[proximo].tipo == "simbolo" and tokens[proximo].valor == "(" then
                        table.insert(chamadas, {
                            nome = func.nome,
                            index = i,
                            inicio = tokens[i].inicio,
                            fim = tokens[i].fim
                        })
                        break
                    end
                end
            end
        end
        i = i + 1
    end
    
    return chamadas
end

function codificarString(str, offset)
    if not str or str == "" then return "" end
    local resultado = {}
    local conteudo = str:sub(2, -2)
    for i = 1, #conteudo do
        local byte = string.byte(conteudo, i)
        resultado[#resultado + 1] = tostring(byte + offset)
    end
    return table.concat(resultado, ",")
end

function reconstruirCodigo(tokens, estrutura, mapaFuncoes)
    local partes = {}
    local ultimoTipo = ""
    
    for i, token in ipairs(tokens) do
   if #partes > 0 then
            local ultimo = partes[#partes]
            if token.tipo == "palavra" and ultimo ~= "" and not ultimo:match("%s$") then
                if ultimoTipo == "numero" or ultimoTipo == "palavra" or ultimoTipo == "simbolo" and token.valor ~= ")" and token.valor ~= "(" then
                    partes[#partes] = ultimo .. " "
                end
            end
        end
        
        if token.tipo == "string" then
            local codificado = codificarString(token.valor, estrutura.offset)
            if codificado ~= "" then
                partes[#partes+1] = estrutura.decode .. "(" .. codificado .. ")"
            else
                partes[#partes+1] = token.valor
            end
            ultimoTipo = "string"
        elseif token.tipo == "palavra" and mapaFuncoes[token.valor] then
            local proximo = i + 1
            if proximo <= #tokens and tokens[proximo].tipo == "simbolo" and tokens[proximo].valor == "(" then
                partes[#partes+1] = mapaFuncoes[token.valor]
            else
                partes[#partes+1] = token.valor
            end
            ultimoTipo = "palavra"
        else
            partes[#partes+1] = token.valor
            ultimoTipo = token.tipo
        end
    end
    
    return table.concat(partes)
end

while true do

    g.info = gg.prompt({
        '📂 Select file :',
        '📂 Select folder :'
    }, g.info, {
        'file',
        'path'
    })

    if not g.info then return end

    gg.saveVariable(g.info, g.config)
    g.last = g.info[1]

    if loadfile(g.last) == nil then
        gg.alert("⚠️ Script not Found! ⚠️")
        return
    end

    local nomeArquivo = g.last:match("[^/]+$")
    local saida = nomeArquivo:gsub("%.lua$", "") .. ".Batman.lua"
    g.out = g.info[2] .. "/" .. saida

    local file = io.open(g.last, "r")
    local DATA = file:read("*a")
    file:close()

    math.randomseed(os.time())

    local estrutura = gerarEstrutura()
    local mapaFuncoes = {}
    
    local tokens = tokenizarCodigo(DATA)
   
    local funcoes = encontrarFuncoes(tokens)
    
    for _, func in ipairs(funcoes) do
        if not mapaFuncoes[func.nome] then
            mapaFuncoes[func.nome] = gerarNomeAleatorio(20)
        end
    end
    
    local chamadas = encontrarChamadas(tokens, funcoes)
    
    for _, func in ipairs(funcoes) do
        tokens[func.nomeIndex].valor = mapaFuncoes[func.nome]
    end
    
    for _, chamada in ipairs(chamadas) do
        tokens[chamada.index].valor = mapaFuncoes[chamada.nome]
    end
    
 local codigoProcessado = reconstruirCodigo(tokens, estrutura, mapaFuncoes)

    local cabecalho = string.format([[
local %s = %d
math.randomseed(os.time() + %s)

local function %s(...)
    local args = {...}
    local r = {}
    for i = 1, #args do
        local n = tonumber(args[i])
        if n then
            r[#r+1] = string.char(n - %d)
        end
    end
    return table.concat(r)
end

]], 
    estrutura.seed,
    estrutura.offset,
    estrutura.seed,
    estrutura.decode,
    estrutura.offset
)

  local declaracoes = ""
    for nomeOriginal, novoNome in pairs(mapaFuncoes) do
        declaracoes = declaracoes .. "local " .. novoNome .. " = nil\n"
    end

    local codigoFinal = cabecalho .. "\n" .. declaracoes .. "\n\n" .. codigoProcessado

    io.open(g.out, "w"):write(codigoFinal):close()

    gg.alert("📂 File Saved To:\n" .. g.out)
    print("📂 File Saved To: " .. g.out)

    return
end